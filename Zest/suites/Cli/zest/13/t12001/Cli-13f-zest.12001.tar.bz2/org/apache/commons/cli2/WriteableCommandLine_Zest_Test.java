package org.apache.commons.cli2;
import org.junit.Test;
import static org.junit.Assert.*;
public class WriteableCommandLine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041", "\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud8f1\udc39\udba1\udcda\udb01\udea8\uda0c\udd87\udaea\uddf3\udab5\udf65\udb0d\uded1\ud8e9\udd67\ud8e4\uddac\ud96a\udc29",
        23, 94864, -224619261, 5772968665313477528L, -60266L, true, true, (char) 11181, (char) 55802,
        Double.longBitsToDouble(0x3feb8132415f810dL), Double.longBitsToDouble(0x3fe6d8be227cd27bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "\ud8a8\udd9f\udb59\udd6c\uda13\udfda\udbb3\udd1e", "\u140a\u21a1\u8175\u6e5b\ucdcb\uc041\u0de0", "\ud8d2\udfe7\udb49\udc17\ud8f1\udc39\udba1\udcda\udb01\udea8",
        10, 55162, -171595776, -3287142286625725673L, 65532L, false, true, (char) 23956, (char) 4979,
        Double.longBitsToDouble(0x3fbabca71cc51248L), Double.longBitsToDouble(0x3fe3011bc3360912L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\ua009\u21a1\u8175\u6e5b\u33f2\uc041", "\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud8f1\udc39\udba1\udcda\udb01\udea8\uda0c\udd87\udaee\udcae\udab5\udf65\udb0d\uded1\ud8e9\udd67\ud86f\udd6d\ud95b\udf96\ud92c\ude67\uda05\udf3b\u4439\udaa0\udd22\uda9c\udd74\uda87\uddcc\uda4b\udff6\ud885\ude13\ud984\ude26\uda11\udfcf\udb27\udff4\uda40\udec5\ud906\udc2c\ud86f\udd02\ud85a\udc0f\ud821\uddfb\udbb6\udd34\udb25\udca4\udbd9\udda5\udaec\ude62\udb6b\udcb2\udb77\udcae\ud8a3\udd1e\udbb1\ude72\ud948\uddcf\ud818\udc8a\uda50\udc3d\udb98\ude7a\ud8e2\udee3\ud978\udcc5\udaf0\udf88\ud819\udc6f\udaed\uddef\ud852\udf24\udb8c\udc78",
        55, 29256, -1759938642, -5106238932152143304L, -69404L, true, true, (char) 581, (char) 14906,
        Double.longBitsToDouble(0x3fe75ad3756e2ee4L), Double.longBitsToDouble(0x3fd3d70c1f62b288L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u01ea\u6064\u1624\u33f2\uc041", "\ud9ef\udea9\u7be7\udb49\udc17\udbf1\udc58\ueeb5\udacb\udf5a\uda9b\uddc3\ud828\ude1a\udab5\udf65\uda46\udc7a\ud8e9\uddb2\ud8e4\uddac\ud96a\udc29",
        23, 94864, -224619261, 5772968905831646104L, -90412L, false, true, (char) 35256, (char) 19052,
        Double.longBitsToDouble(0x3fe6df5e227cd27bL), Double.longBitsToDouble(0x3fe2e776bf54bddfL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041", "\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud8f1\udc39\udba1\udcda\udb01\udea8\uda0c\udd87\udaea\uddf3\udaad\ude80\udb0d\uded1\ud8e9\udd67\ud8e4\uddac\ud96a\udc29",
        23, 94864, -224619261, 5772968665313477528L, -1840L, true, true, (char) 41630, (char) 23799,
        Double.longBitsToDouble(0x3fe4f352acd4e436L), Double.longBitsToDouble(0x3fc5f1090c360198L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 7, "\ud82f\udeca\uda9a\udc06\ud9ab\ude29\udaab\udfea", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041", "\ud9ef\udea9\ud803\ude7f\udb49\udc79\ud8f1\udc39\udba1\udcda\ud914\udef2\ud972\udf78\uda01\udda6\udaf8\udf8f\udb10\udd53\u18a5\ud8e4\uddac\ud96a\udc29",
        23, 94864, -224619261, 5772968665313477528L, -60266L, true, true, (char) 11181, (char) 55802,
        Double.longBitsToDouble(0x3feb8132415f810dL), Double.longBitsToDouble(0x3fe6d8be227cd27bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u5a15\u6e89\u62bb", "\ud856\udd73\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud8f1\udc39",
        26, 11381, 189651165, 5663440710666659840L, 22089L, false, false, (char) 3218, (char) 11936,
        Double.longBitsToDouble(0x3fee476e5d037e70L), Double.longBitsToDouble(0x3fbabca71cc280e8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 13, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041", "\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud8f1\udc39\udba1\udcda\udb01\udea8\uda0c\udd87\udaea\uddf3\udab5\udf65\udb0d\uded1\ud8e9\udd67\ud8e4\uddac\ud96a\udc29",
        23, 94864, -224619261, 5772968665313477528L, -60266L, true, true, (char) 11181, (char) 55802,
        Double.longBitsToDouble(0x3feb8132415f810dL), Double.longBitsToDouble(0x3fe6d8be227cd27bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041\u0de0\u1c1a\ua417\u9486\u4ba6\u147e\u84ae\u9ef0\uae42\u0a79\u9be0\ub370\u9067\u1414\ua0ac\u0de6\u3da3\uad24\u335e\u3da2\uc52d\u1407\u27b1\u4302\u3aed", "\ud906\udc47\udad4\udcf4\ue799",
        56, 82774, 679557919, 7661413165552715075L, 6179L, true, false, (char) 30103, (char) 30370,
        Double.longBitsToDouble(0x3fd56e98dbe232e4L), Double.longBitsToDouble(0x3fdd41a36e2e1620L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "\uda5d\udda1\udb63\udf6c\uda13\udfda\udb02\uded4", "\u140a\u21a1\u8175\u6e5b\u33f2\ubbd0\u0de0\u1c1a\ua417\u9486\u4ba6\u147e\u84ae\u9ef0\u3614\u0a79\u69a1\ub370\u28ba\u4f1c\ua0ac\u0de6\u3da3\uad24\u335e\u3da2\ua3b2\u4b32\u27b1\u4302\u3aed\u78fa\u9d8a\u1533\u15fe\ud305", "\ud96c\udeac\udb64\udd6e\uda64\udd0f\ud853\udf8a\ud888\udcd3\udbd1\ude27\udace\udfa0\udbca\udff7\udbb0\ude2b\ud982\ude06\ud9a2\udf5b\uda24\udcf1\ud9cf\udd83\uda80\udd4d\uda94\ude09\ud9ec\udd4c\ud9bd\udfd5\ud836\udd88\udb7e\udef1\ud895\udd05\ud96b\ude60\udb43\udc18\ud806\ude20\udb8b\udff0\ud85c\udf8c\udbd0\udfd9\uda06\uded6\ud842\udc48\ud9bd\uddee\udad0\udd10\ud8f7\udd35\u158f\ud8db\udc3f\uda38\udd27",
        56, 5863, -911965314, 8696820665207590229L, -61780L, false, false, (char) 56886, (char) 27964,
        Double.longBitsToDouble(0x3fa1611e942780c0L), Double.longBitsToDouble(0x3fe711c0fd233b91L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "\ud849\udeab", "\u0e1b\u6f53", "\udb3c\udff4",
        46, 10826, 1267208813, -6810533045985539646L, -60634L, false, true, (char) 22984, (char) 41673,
        Double.longBitsToDouble(0x3fd78f208d4b636cL), Double.longBitsToDouble(0x3fcba007f5482d34L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 11, "\ud82f\udeca\uda9d\udc89\uda13\udfda\udaa9\udc1a\ud9ab\udee3\ud85f\udcae\uda05\udd9d\uda7d\udc73\udbb7\udeac\uda77\udfde\ud9ed\udee0\ud824\udeb5\udae1\uddf0\ud856\udd73\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud915\ude39\udba1\udcda\uda1b\uddd5\uda0c\udd87\ud8c5\udc40\uda94\udd7e\udb0d\uded1\ud8e9\udd67\ud8e4\uddac\ud96a\udc29\ud92c\ude67\uda05\udf3b\u4439\udaa0\udd22\ud851\uddaf\udb80\udef5\ud976\udcdd\ud885\ude13\ud984\ude26\uda11\udfcf\udb27\udff4\ud9b4\udfe0\ud905\udfc6\udaa6\uddbd\uda0a\udd8a\udbb7\udeee\udb70\udc3e\udb25\udd58\udaf9\udcdb\uda17\ude5e\udb3f\udc25\ud92c\udd48\udb50\ude35\ud963\udeec\ud973\udc5d", "\u2af0\ub10e\u21a8", "\ucabc\ud91f\ude1c\uda95\udd1a\ud923\udde9\ud80d\udc13\ud9d8\udef5\ud996\uddbd\udb69\udc7c\ud914\uded5\ud89e\ude92\ud801\udf3f\u75a8\udbe0\udff0\ud89d\udf0e\udb07\udf5c\ud9a9\udddb\udaaa\udcae\udb60\udce9\uda78\ude1b\ud85c\ude53\udbc2\udd5c\udac2\udf60\uda7c\udff4\ud86a\udf2a\ud9bb\ude79\ud9bd\udcd8\udbc7\ude37\ud99d\udd52\udbab\ude71\ud94a\ude66\ud906\udc35\uda30\uded2\udb56\uddae",
        30, 3244, 1049366317, 5296331226857362693L, -65393L, true, true, (char) 20364, (char) 44425,
        Double.longBitsToDouble(0x3fdb428f33304a8eL), Double.longBitsToDouble(0x3feecc6c7eb3d82dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 6, 8, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041", "\ud87d\udf22\ud958\udf0a\ud848\uddd2\ud90d\udcdf\ud8da\udd94\udb01\udea8\uda53\ude2b\udaec\udc2a\uda03\ude1b\udb18\udfc5\ud971\ude2b\ud842\udd55\ud96a\udc29",
        23, 94798, -224619261, 5772968665313477528L, -60266L, true, true, (char) 11181, (char) 55802,
        Double.longBitsToDouble(0x3fbc0992082b1218L), Double.longBitsToDouble(0x3fe6d8be227cd27bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "", "\uaf3f\u0e1b\u6f53\u61cf\u140a\u21a1\u8175", "\ud824\udeb5",
        47, 69296, 1391761862, -6613939228659320957L, 2024L, true, false, (char) 55579, (char) 41118,
        Double.longBitsToDouble(0x3f33a60c17ae2800L), Double.longBitsToDouble(0x3fe8be9308169f82L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a\ud9ab\udee3\ud85f\udcae", "\u8175\ub73d\u33f2\uc041\u97f2\u1c1a\ua417\u9486\u4ba6\u147e\u84ae\u9ef0\uae42\u1934", "\ud8e9\udd67\ud86f\udd6d\ud95b\udf96\ud92c\ude67\uda05\udf3b\u4439",
        55, 18392, 1245124973, -914185962540470465L, 6209L, false, true, (char) 12304, (char) 20772,
        Double.longBitsToDouble(0x3febe8a120b28c86L), Double.longBitsToDouble(0x3fe5061a60d8b923L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 0, "\ud82f\udeca\ud848\udc68\uda13\udfda\udaa9\udc1a", "\ua009\u21a1\ua716\u4ddb\u3b3f\uc041", "\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud8f1\udc39\udba1\udcda\udb01\udea8\uda0c\udd87\udaee\udcae\udab5\udf65\uda08\udfcc\udb6f\udf5a\ud876\udf4e\ud95b\udf96\ud92c\ude67\uda05\udf3b\ud953\udeb5\ud949\udff4\uda9c\udd74\ud9c0\uddc0\udb1b\udd9b\udab3\udde9\uda4d\udf20\ud880\udfcd\udb27\udff4\uda40\udec5\uda16\uddb4\ud9ed\ude3a\ud839\udc95\udac3\udf3c\udbb6\udde4\ud85d\udca0\udbd9\udda5\udaec\udefb\udb88\udde4\udb77\udcae\ud8a3\udd1e\udbb1\ude72\ud948\uddcf\ud818\udc8a\uda50\udc3d\udb98\ude7a\udbef\udd2b\ud978\udcc5\udaa3\ude9e\ud842\udf0c\udaed\uddef\ud852\udf24\udb8c\udc78",
        55, 29256, -1759938642, -5111854138035195336L, -81601L, false, true, (char) 17679, (char) 7751,
        Double.longBitsToDouble(0x3fc6a03219e62f04L), Double.longBitsToDouble(0x3fe75ad3746e2ee4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 2, "", "\uaf3f", "\ud85f\udcae",
        44, 83229, 518127835, 9116183303819891309L, 94110L, false, true, (char) 0, (char) 58435,
        Double.longBitsToDouble(0x3fec1d21b50c4dbdL), Double.longBitsToDouble(0x3fd78f2080000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 7, "\ud82f\udeca\u0093\000\udb42\udc00", "\u140a\u01ea\u6064\u1624\u33f2\uc041", "\ud9ef\udea9\u9ae4\u7783\udbdb\udf4c\ueeb5\udacb\udf5a\uda9b\uddc3\ud828\ude1a\uda82\udc0b\000\ud8e9\uddb2\000\ud94b\udec5",
        31, 94864, -234881024, 5772968905831646104L, -90412L, false, true, (char) 9800, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 7, "\uda69\uded1\udb63\udefd\uda13\udfda\udaa9\udc1a", "\u2c51\u01ea\u6064\u1624\u33f2\u9e0d", "\ud9ef\udea9\u7be7\udb49\udc17\udbf1\udc58\ueeb5\udacb\udf5a\ud94b\ude98\ud903\udec0\udab5\udf65\uda46\udc7a\ud8e9\uddb2\ud9dd\udeb0\udb51\udf45",
        -2, 94737, -224619261, 5772968905831646104L, -90412L, false, true, (char) 10680, (char) 48379,
        Double.longBitsToDouble(0x3fe6df5e227cd27bL), Double.longBitsToDouble(0x3fe2e776bb58bddfL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 3, 0, "\ud89a\udf9f\ud960\uded0\uda13\udfda", "\u4eb2", "\udaf2\udc71\ud965\udfe5\ud9ed\udee0\ud824\udeb5\udae1\uddf0\ud856\udd73\ud9ef\udea9\u7be7\udb2b\udd17\udbf1\udc58\u0b9a\udad8\udf0c\uda9b\uddc3\ud828\ude1a",
        -5, -1000, 0, -7841365085927409308L, 50366L, false, true, (char) 61853, (char) 34772,
        Double.longBitsToDouble(0x3fa081d7a8cec000L), Double.longBitsToDouble(0x3e0c098000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 11, "\000", "\000\u9624", "",
        -5, -1000, 2118910068, 5442620407452278855L, 77440L, false, true, (char) 7236, (char) 50,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb04d0035ad66e0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 9, 7, "\ud89a\udf01", "", "",
        41, 14950, 0, 0L, -99968L, false, true, (char) 244, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 7, "\ud82f\udeca\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041", "\ud9ef\udea9\ud8d2\udfe7\udb49\udc17\ud8f1\udc39\ud843\udfeb\udb01\udea8\uda0c\udd87\udaea\uddf3\udaed\udce0\ud9cd\udd1d\ud8e9\uddfb\ud8e4\uddac\ud96a\udc29",
        23, 94864, -224619261, 5772968665313477528L, -60266L, true, true, (char) 11181, (char) 55802,
        Double.longBitsToDouble(0x3feb8132415f813fL), Double.longBitsToDouble(0x3fe6d8be227cd27bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 6, 0, "\ud830\ude09\udb63\udf6c\uda13\udfda\udaa9\udc1a", "\u140a\u21a1\u8175\u6e5b\u33f2\uc041", "\ud87d\udf60\ud958\udf0a\ud848\uddd2\ud90d\udcdf\udb51\udc0f\udb01\udea8\uda53\ude2b\udaec\udc2a\udbf9\ude15\udb18\udfc5\ud971\ude2b\ud842\udd55\ud96a\udc29",
        23, 50830, -1106546505, 6726705026559061696L, 52627L, true, false, (char) 52309, (char) 3247,
        Double.longBitsToDouble(0x3fcbdbd5d16ea20cL), Double.longBitsToDouble(0x3fa8ddf37147d1b0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 7, "\ud82f\udeca\u00ee\000\udb42\udc00", "\ua1b1\u01cb\u00ac\u1624\u33f2\u4db0", "\ud9ef\udea9\u9ae4\u7783\udbdb\udf4c\udb62\udd45\udacb\udf49\uda9b\uddc3\ud828\ude1a\uda82\udc0b\000\u6a4b\u00ca\udb8c\udfe5\ud92c\ude97\udaca\udc9e\udb2f\udf99\udaa0\udd5a\ud851\uddaf\uda9b\udeb9\uda4f\ude42\ud869\udef5\udb2d\udd27\uda10\uddce\u12e2\000\000\u1900\uda1d\udffd\uda87\ude79\uda23\udd11\ud9be\ude87\ud976\udeed\ud9fc\ude9d\ud87d\ude68\udbfc\udcee\udbd6\udf42\udba2\udc9f\ud93a\udfc5\ud87f\udf4f\ud876\udf0f\udb71\udfa2\u1c5f\uda41\udc88\ud9d4\udf6b\ud8be\udc1f\udabf\udc78\ud9b6\udf8f\ud8bb\udf65\udb2f\uddb8\u108a\ue5ac\u94a2\udb14\udc6e\ud87c\udc37\ud8a9\udc9f\uda4f\ude54\udbf2\udf65\uda62\uded0\ud944\udcfb\udb0e\udea2\ud8ee\udfba\udb8b\udcda\udb0b\udc0d\udb2f\udff1\udaf1\udf1b\ud8ff\udf02\udaae\ude41\ud8fa\udce3\ud8b2\udf75\ud843\uded5\ud9d5\udd2e\udba1\udd18\udb3a\udcf1\udb8e\udd1f\uda89\udf2f\ud88d\udf14\udbce\udfbf\ud887\ude9c\uda2f\udc03\udb65\udd27\ud96c\ude73\ud97e\udece\ucfbf\ud8d2\udc73\udb39\udf5d\ud9b2\udef1\udb3c\udda3\udb27\udf9e\udaf2\udc06\ud83f\udc0a\ud81f\udf97\ud8de\ude6e\ue39a\uda36\udcb5\udbab\udd43\uda3f\ude4f\u5505\uda29\udf29\udbf6\udcb6\udb21\ude4d\udb7c\udc87\ud9ad\uddd2\ud907\udfcc\ud886\udf01\uda57\ude38\ud88f\ude44\udb23\udd83\udb1b\udc2e\ud8cd\udf74\uda39\udfa5\uda8d\uddb3\ud8e2\udd39\ud8dd\udc55\uda5c\udff8\uda1a\udfb1\ud821\udf14\uda5e\udfb2\ud83f\udd4c\ud8ff\udeed\ud80f\udeec",
        58, 63185, 1731942360, 5229595813517513589L, 59271L, true, true, (char) 13131, (char) 25546,
        Double.longBitsToDouble(0x3fdd85dd03e905a4L), Double.longBitsToDouble(0x3fedad4a2b7c2c4eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 7, "\ud82f\udeca\u00ee\000\udb42\udc00", "\ua1b1\u01cb\u00ac\u1601\u33f2\ubbf2", "\ud9ef\udea9\u9ae4\u7783\udbdb\udf4c\udb62\udd45\udb30\udf9a\udaae\udd50\ud828\ude1a\udb55\udf29\ud873\uddf2\u6aab\u00ca\udb8c\udfe5\ud92c\ude97\udaca\udc9e\udb2f\udf99\udaa0\udd5a\ud964\udfbc\uda9b\udeb9\uda4f\ude42\ud869\udef5\udb2d\udd27\uda10\uddce\u12e2\000\000\u1900\uda1d\udffd\uda87\ude79\uda23\udd11\ud9be\ude87\ud88a\udd96\ud931\uddc5\udbd5\udd11\ud8d1\uddac\ud9ab\uddfe\udaa5\udef0\ud80a\udffb\ud87f\udf4f\ud876\udf0f\udb71\udfa2\u1c5f\uc0c1\ud922\udc47\ud8be\udc1f\udabf\udc78\ud9b6\udf8f\ud8bb\udf65\udb2f\uddb8\u108a\ue5ac\u94a2\udb14\udc6e\ud87c\udc37\ud8a9\udc9f\uda4f\ude54\udbf2\udf65\uda62\uded0\ud944\udcfb\udb0e\udea2\ud8ee\udfba\udb8b\udcda\udb21\uded2\udb2f\udff1\udaf1\udf1b\udb50\udfac\udb92\udf15\ud8f8\ude5d\ud8b2\udf75\ud843\uded5\ud9d5\udd2e\udba1\udd18\udb3a\udcf1\udb8e\udd1f\uda89\udf2f\ud88d\udf14\uda59\udd61\ud94d\udce8\udb2d\udccd\udb5a\udd9a\ud96c\ude73\ud97e\udece\ucfbf\ud8d2\udc73\udb39\udf5d\ud9b2\udef1\udb3c\udda3\udb27\udf9e\udaf2\udc06\ud83f\udc0a\ud81f\udf97\ud8de\ude6e\ue39a\uda36\udcb5\udbab\udd43\uda3f\ude4f\u5505\uda29\udf29\udbf6\udcb6\udb21\ude4d\udb7c\udc87\ud9ad\uddd2\ud918\udd0f\ud886\udf01\uda57\ude38\ud88f\ude44\udb23\udd83\udb38\udc2e\ud8cd\udf74\uda39\udfa5\uda8d\uddb3\ud8e2\udd39\ud8dd\udc55\uda5d\udc1a\uda1a\udfb1\ud821\udf14\uda5e\udfb2\ud83f\udd4c\ud8ff\udeed\ud80f\udeec\udb26\udf7d\ud8f6\udf3d\ud983\udded\udb9f\uddff\uda58\udc25\udb09\udd9d\udaf4\ude73\ud95d\udcab\udacc\udd9a\udb5d\ude1c\ud91e\udd91\udb12\udf93\ud942\udc4a\ud805\udef1\udb1e\udd21\ud9f2\udf35\ud9c9\udc23\udb52\udebe",
        20, 31028, 885843657, -4710638386536401486L, -17258L, true, true, (char) 36920, (char) 57722,
        Double.longBitsToDouble(0x3fe70eb6398f0d4cL), Double.longBitsToDouble(0x3fd6e94398189ad0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 7, "\ud82f\udeca\ud879\udd7b\000\udb42\udc00", "\uc115\u01cb\u00ac\u1601\u33f2\ubbf2", "\ud9ef\udea9\u9ae4\u7783\ud91f\udf4e\udb62\udd45\uda17\ude54\udaae\udda1\ud828\ude1a\udb55\udf29\ud873\uddf2\u6aab\u00ca\udb8c\udfe5\ud92c\ude97\ud9b3\ude92\udae1\uddd7\udb0c\udce1\ud964\udfbc\uda9b\udeb9\uda4f\ude42\ud869\udef5\udb2d\udd27\uda10\uddce\u12e2\000\000\u1900\uda1d\udffd\uda87\ude79\uda23\udd11\ud9be\ude87\ud88a\udd96\ud931\uddc5\udbd5\udd11\ud8d1\uddac\ud9ab\uddfe\uda64\uded0\ud81c\ude6c\ud87f\udf4f\ud876\udf0f\udb71\udfa2\ud9be\ude59\ud832\udd25\ud922\udc47\ud8be\udc1f\udabf\udc78\ud9b6\udf8f\ud8bb\udf65\udb2f\uddb8\uf3e3\ud8fb\udc5a\u9f1f\udb14\udc6e\ud87c\udc37\ud8a9\udc9f\uda4f\ude54\udbf2\udf65\uda62\uded0\ud944\udcfb\udb0e\udea2\ud8ee\udfba\udb8b\udcda\udb21\uded2\udb2f\udff1\udaf1\udf1b\udb50\udfac\udb92\udf15\ud8f8\ude5d\ud8b2\udf75\ud843\uded5\ud9d5\udd2e\udba1\udd18\udb3a\udcf1\udb8e\udd1f\uda89\udf2f\udaff\udf0d\uda59\udd61\ud94d\udce8\udb2d\udccd\udb5a\udd9a\ud96c\ude73\ud97e\udece\ucfbf\ud8d2\udc73\udb39\udf5d\ud9b2\udef1\udb3c\udda3\udb27\udf9e\udaf2\udc06\ud83f\udc0a\ud81f\udf97\ud8de\ude6e\ue39a\uda36\udcb5\udbab\udd43\uda3f\ude4f\u5505\uda29\udf29\udba7\udfbe\udb21\udd90\udb62\udeb9\ud9ad\uddd2\ud918\udd0f\ud886\udf01\uda57\ude38\ud866\udd44\udb23\udd83\udb38\udc2e\ud8cd\udf74\uda39\udfa5\uda8d\uddb3\ud8e2\udd39\ud8dd\udc55\uda5d\udc1a\ud844\udf66\ud81b\uddc6\uda5e\udfb2\ud969\udca8\ud9ba\udf0c\udb3d\udd52\uda82\ude63\ud817\ude20\ud983\udd6d\udb9f\uddff\uda58\udc25\udb09\udd9d\udaf4\ude73\ud95d\udcab\udacc\udd9a\udb5d\ude1c\ud91e\udd91\udb12\udf93\ud942\udc4a\ud805\udef1\udb1e\udd21\ud9f2\udf35\ud9c9\udc23\udb52\udebe",
        20, 31028, 885843657, -4710638386536401486L, -2470L, false, true, (char) 6729, (char) 12286,
        Double.longBitsToDouble(0x3fe9b215c1f5c80dL), Double.longBitsToDouble(0x3fca02e3d6458fa4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.ArgumentImpl|processValues|org.apache.commons.cli2.WriteableCommandLine,java.util.ListIterator,org.apache.commons.cli2.Option|new:org.apache.commons.cli2.option.ArgumentImpl:java.lang.String,java.lang.String,int,int,char,char,org.apache.commons.cli2.validation.Validator,java.lang.String,java.util.List,int",
    "M|org.apache.commons.cli2.WriteableCommandLine|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultSwitch|org.apache.commons.cli2.Option,java.lang.Boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getNormalised||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.ArgumentImpl|processValues|org.apache.commons.cli2.WriteableCommandLine,java.util.ListIterator,org.apache.commons.cli2.Option|new:org.apache.commons.cli2.option.ArgumentImpl:java.lang.String,java.lang.String,int,int,char,char,org.apache.commons.cli2.validation.Validator,java.lang.String,java.util.List,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
