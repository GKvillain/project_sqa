package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 6, 4, "\udb93\udc7d", "\u91d2\u76a1", "\ud80e\udd93\ud9cc\ude51",
        17, 38768, 1242450179, 4191274326632911510L, -66172L, false, false, (char) 46374, (char) 35960,
        Double.longBitsToDouble(0x3fc59724a36b6bccL), Double.longBitsToDouble(0x3fdadc9e03059ceaL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 6, 4, "\udb93\udc7d", "\u91d2\u76a1", "\ud80e\udd93\ud9cc\ude51",
        8, 38768, 1242450179, 4191274326632911510L, -66172L, false, false, (char) 54677, (char) 35966,
        Double.longBitsToDouble(0x3fc59724a36b6bccL), Double.longBitsToDouble(0x3fdadc9e03059ceaL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.io.File:\ud866\udddc\uda2d\uded7\udbd4\ude22\ud922\udfe7\udb2a\udfb3\uda69\udf9e\ud963\ude80\ud80e\udd93\ud9cc\ude51\ud804\ude62\ud971\ude56\012",
        Z.run(T, 1, 4, 9, 8, "\ud866\udddc\uda2d\uded7\udbd4\ude22\ud922\udfe7\udb2a\udfb3\uda69\udf9e\ud963\ude80\ud80e\udd93\ud9cc\ude51\ud804\ude62\ud971\ude56", "\u12c7\uad6c\u3092\u715c\uc41b\u6236\u3e6d", "\ud846\udcb2\uda30\udd72\ud910\udfe6\udb1e\ude54\udb57\udf04\ud877\udf53\ud849\udfaf",
        5, 362, -1141137082, 6111658704547628049L, -9058L, false, false, (char) 3865, (char) 64563,
        Double.longBitsToDouble(0x3fdaed8c2ac3f7fcL), Double.longBitsToDouble(0x3fd52ce4dac6fdacL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 0, 0, "\udb93\udc7d", "\033", "\ud99b\udfbf",
        50, 54800, -700205783, 9086371686684557312L, -100000L, false, false, (char) 0, (char) 5271,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e1b400000000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 11, 4, "\udb93\udc7d", "\u91d2\u76a1", "\ud853\udea5\ud9cc\ude51",
        17, 38768, 1242450179, -4795635446754776480L, -66172L, true, true, (char) 25565, (char) 35960,
        Double.longBitsToDouble(0x3fc59724a36b6bccL), Double.longBitsToDouble(0x3fdadc9e03059d56L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 7, 4, "\ud8b8\udc69\ud8bc\udeb3\udbd4\uddcf\udbd2\udc3f\udbb3\udcc5\udb6e\ude58\ud99b\udfbf\ud80e\udd93\udaed\udc61\uda6b\udfc8\udb2d\udd24\ud8cf\udd7a", "\u3b6c\uabf3\u1741\ubf50\u62f1\u30c3\u88b4\u2ef5\ud33e\ucecd\u8c97\u3f9b\u48d4\u58c4\u16d3\u1830\u7714\uc542\u2d6e\u746c\ub564\u2d8e\u7b34\ua75b\u4511", "\udae0\udd72\ud93d\uddc6\ud94e\uded7",
        48, 33444, -1951430097, -6843879169718819874L, -48856L, false, true, (char) 51778, (char) 13353,
        Double.longBitsToDouble(0x3fe39be15419812cL), Double.longBitsToDouble(0x3fa8d83fae5c8350L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 6, 4, "\udb93\udc7d", "\u91d2\u76a1", "\ud80e\udd93\ud9cc\ude51",
        17, 38768, 1242450179, 4191274326632911510L, 33994L, true, false, (char) 7634, (char) 37837,
        Double.longBitsToDouble(0x3fdadc9e03059ceaL), Double.longBitsToDouble(0x3fee86798ae446c8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.io.File:\udb93\udc7d\uda3f\udd57\udbd4\ude22\ud922\udfe7\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\ud80e\udd93\ud9cc\ude51\0121=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 4, 11, 4, "\udb93\udc7d\uda3f\udd57\udbd4\ude22\ud922\udfe7\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\ud80e\udd93\ud9cc\ude51", "\u68c8\u2abb\u573b\uacfd\uac43\u1741\ubf50\u62f1", "\uda57\udff9\ud8a4\udc81\ud918\udc5d\u55fa\ud98d\udd55\ud832\udcd7\udba8\udd60",
        59, 42415, -426244030, 974618561876305661L, 44710L, true, false, (char) 56332, (char) 47429,
        Double.longBitsToDouble(0x3fd51025aa3e3d82L), Double.longBitsToDouble(0x3fd99c39f301ccf2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 6, 4, "\u00b4", "\u42f6", "\ud99b\udfbf",
        50, -1000, -700252160, 7114837906554880L, 33994L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e282ce750000000L), Double.longBitsToDouble(0x3fe22ffa11da1649L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 0, 6, 4, "\udb93\udc7d", "\u91d2\u76a1", "\ud80e\udd93\ud9cc\ude51",
        52, 38768, 1242450179, 4191274326632911510L, -66172L, false, false, (char) 46374, (char) 35960,
        Double.longBitsToDouble(0x3fc59724a36b6bccL), Double.longBitsToDouble(0x3fdadc9e03059ceaL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 5, 0, 11, "\udb93\udc7d", "\u91d2\u3b68\u381b\u2ec8\u20ac\u1144\u3ddc\u46f9\u83bf\u0ee1\u9707\uacfd\uac43\u8940\ubf50\u62f1\ua8c2\u96a1\u2ef5\u7f5a\u15a8\ucfc1\ua60f\u9889\u0fc0\u2ea9\ub209\u634d\uac55", "\uda1c\udf37\uda2c\udd56\uda98\udcbd\uda93\udf0b\udb3b\uddf7\uda17\ude06",
        14, 72005, -1610029620, -3593522427287665121L, 31075L, false, true, (char) 48327, (char) 14714,
        Double.longBitsToDouble(0x3fc44ea0aa315bbcL), Double.longBitsToDouble(0x3fc1d6881ab073e4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 10, 6, "\ud8e2\uddaf", "\u91d2\u70af", "\ud80e\udd93\udbf9\udc40\ud80b\udce3\ud971\ude56\ud948\udf7e\ud9b9\ude6b\udb21\udd7b\ud97d\udf67",
        47, 80088, -980552554, -5074775118095096660L, 85939L, false, true, (char) 61308, (char) 32601,
        Double.longBitsToDouble(0x3fca722f9a645434L), Double.longBitsToDouble(0x3fdecba398cb0450L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\uda2f\udc45\012",
        Z.run(T, 1, 0, 2, 10, "\uda2f\udc45", "\uc4f5\u9745\u11f8", "\ud9cc\ude51\ud8a3\ude39\ud96a\udf4d\ud8cf\udd60\uda17\udde2\ud8e0\udc5b\ud990\udd8c\uda08\udfb8\udbf3\udeb2\ud8af\udfb4\ud818\udebe\uf27d\udaf1\ude87\ud8a0\udd83\ud91e\udf1e\ud969\udec5\ud93c\ude81\udb11\udcf5\ud9c5\udc04\udb56\ude98\uda59\ude1d\udb99\udc0c\ud886\udd26\udb19\ude81\udb09\udfe5\ud85a\udc72\ud9db\udc4d\ud8ad\udf63\udb99\udf1f\uda6a\udd91\udbf5\udd61\ud9a7\udff8\ud920\ude7f\ud82e\uddae\udad0\udec2\ud860\udfef\uda2a\udcbe\udae4\udc8d\ud9e9\udc68\udbe0\udc43\ud97c\udc11\ud8c6\udd0b\ud8cd\udda3\ud9f4\udfe0\udb71\ude34\udaaa\udce3\ud93b\udceb\ud8d1\udc9f\ud934\udd06\uda2b\uddb6\udb21\udfe4\uda4f\udf9a\uda97\ude29\ud9ac\udd1c\ua461\ud83c\uddfc\ud8cc\udf13\ud88f\udeed\ud934\uddae",
        28, 49921, -1977015654, 1614747042433814954L, -3980L, true, true, (char) 8961, (char) 48523,
        Double.longBitsToDouble(0x3fe2074302c122c7L), Double.longBitsToDouble(0x3feb1141fddbc79bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 6, 4, "\udb93\udc7d", "\u91d2\u99fe", "\ud80e\udd93\ud9cc\ude51\ud942\udeb3\ud971\ude56",
        4, 95099, 858477206, -8264667844926014500L, 33994L, true, false, (char) 7634, (char) 37837,
        Double.longBitsToDouble(0x3fdadc9e03059ceaL), Double.longBitsToDouble(0x3fe18cc579164752L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 4, "\udb0a\udfb9", "", "",
        -5, -1000, 0, 0L, -100000L, true, true, (char) 36032, (char) 43,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f48120000000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 6, 4, "\udb93\udc7d", "\u7fbf\u092e", "\ud80e\udd93",
        -3, 26217, 2115585768, 4015981627475387851L, -67358L, false, true, (char) 52998, (char) 46374,
        Double.longBitsToDouble(0x3fef5e2c6fb499aaL), Double.longBitsToDouble(0x3fcb5b4b26b72438L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 1, 10, 4, "\udb93\udc7d", "\u91d2\u76a1\u17e0", "\ud9cc\ude51\ud91a\udd0c",
        18, 48179, 975857099, 3687131523982589826L, -52272L, false, false, (char) 35995, (char) 7378,
        Double.longBitsToDouble(0x3fdda73605362dbcL), Double.longBitsToDouble(0x3fd82a59ebe01f02L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 0, 4, "\udb93\udc7d", "\u125e\ub191\ua4c3\u0954\u8172\u239d\u23b1\u9dfa\u7ff0\u2a6a\u573b\u0cb2\u602a\u0cb8\ubee6\u62f1\ua8c2\u88b4\u2ef5\u3b9b", "\ud82f\udf92\ud975\udde7\udbdf\udc8f\uda20\udde2\ud888\udd2c\udb62\udf14\ud8f0\udc55\uda6e\udd2b\udaae\ude79\u96c7\udb0f\udc89",
        45, 90760, 701104399, -1104440082596556988L, -40945L, true, true, (char) 64001, (char) 5532,
        Double.longBitsToDouble(0x3fee4d5b5b8a6e91L), Double.longBitsToDouble(0x3fd1b4a70ddf4baaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 9, 6, 4, "\udb1b\udfc1", "\u2989\u76a1", "\ud80e\udd8f\ud9cc\ude51\ud942\udeb3\ud971\ude56\ud8cf\udd60\udad5\udca8",
        47, 6023, -1488556402, -5761010377396362950L, -60236L, false, false, (char) 27533, (char) 24567,
        Double.longBitsToDouble(0x3fe4b5f8611c92acL), Double.longBitsToDouble(0x3fa60684559b9930L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 6, 4, "\udb93\udc7d", "\u92b5\u76a1\u17e0\u0954\u37ab\u239d\u5a4d\u0593\u68c8\u1e0c\u56ee\uacfd\ucd97\uccfb\ubf50\u62f1\ua8c2\u7403\u2ef5\u524d", "\udaee\udd55\udb95\udeba\uda53\udc58\uda69\udc1b\ud953\udc0d\ud8f1\udc1e\ud8f3\ude94\uda2d\udd14\ud8b6\ude7b\uda26\udd16\u547c\ud90e\udfc3\uda30\ude37\uda4e\ude91\ud8d9\udc0e\ud942\ude18\ud9c2\udc4a\udbb6\udd3e\ud912\ude07\ud9ba\udfaf\uda9b\udfa4\uda2c\udd84\ud8fd\udd46",
        21, 12403, 2001251202, -5531467836165237116L, -54713L, false, true, (char) 45821, (char) 22818,
        Double.longBitsToDouble(0x3fd2a9b20b42f506L), Double.longBitsToDouble(0x3faec20a8cfec5a0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 6, 4, "\ud8ed\uddec\udbed\udf37\uda23\udd8d", "\u17e0\u0954\u8172\u239d\uc3b1\u558b\u442b\uc3b2\u9901\u834b\u790c", "\ud9c6\udf13\uda3a\udc84\ud9cd\udd0d\uda33\udec1\udb8d\ude55\ud8f2\ude90\udb11\udf90\ud9d0\udefe\ud95a\udfe3\u1ca2\ud81b\udd46\udb3b\ude80\uda9d\udfcb\ud8c1\udd99\ud8e9\udfa5\uda3c\udd60\udacb\udc23\uda87\ude56\ud912\ude87\ud9ed\udc89\uda59\ude82\ud901\udf50\uda63\udfd1\udb7f\udeca\udb0b\uddf9\uda75\uddc5\udb8b\uddd2\ud872\ude85\uda47\ude76\ud8ed\udfe5\udb98\ude97\uda77\udfcc\ud90c\uddd8\udb58\udea7\uda68\udf0c\udb68\udcd0\ud909\udc4a\uda09\ude2f\ud896\udd0e\ud989\udfa5\udafa\udfe3\ud8d4\udfec\udb1e\udd12\udbfe\udfd4\ud8d7\udc33\udab9\udc5e\ud9cc\udc29\udb3a\udd2a\udbc8\udc8e\ud859\udcbd\ud89f\udc16\uda0d\udf92\uda8e\udc26",
        57, 64264, 366522649, -1147769474222245342L, -46248L, false, true, (char) 46151, (char) 50881,
        Double.longBitsToDouble(0x3fd2f28b466d730eL), Double.longBitsToDouble(0x3feaa0150b6969f7L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 6, 4, "\000", "\u261b", "",
        48, 15378, 0, -3026418947477387544L, 56928L, false, false, (char) 45741, (char) 29437,
        Double.longBitsToDouble(0x3fe380a4bc96c090L), Double.longBitsToDouble(0x3fe758046cacb925L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 9, 0, "\ud90f\uddf2\ud90e\udfb8\udbaa\udcb9\udb47\udf81\udb43\udf22\ud9f5\ude14\ud977\udcc5\ud80e\udd93\ud9cc\ude51\udb1e\udeb6\ud9cf\udd88\ud8f0\udf1d\ud9f6\udd38\udbdd\udd99\udb80\udee5\uda8d\udd12\udbf3\udf1b\ud99a\udeef\ud85c\udc63\u86b8", "\u5f31\ub7a1\u9a7c\uba6e\u3aff\u7073\u234e", "\ucdc1",
        32, 52907, -1820893585, 5620737581986558101L, -77667L, false, false, (char) 45769, (char) 51995,
        Double.longBitsToDouble(0x3fe0474d38e95874L), Double.longBitsToDouble(0x3feccae1dfe77bd1L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.io.File:\udb93\udc7d\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 4, 10, 0, "\udb93\udc7d", "\u91d2\u4baa", "\ud80e\udd93",
        29, 11833, 2115585768, 5336282886118708835L, -47937L, false, true, (char) 41734, (char) 30937,
        Double.longBitsToDouble(0x3fdeb4d93551724aL), Double.longBitsToDouble(0x3fd422e2535b0b2aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 10, 11, "\udb4b\udfd9\udafb\udd2c\udbd0\udc6e\ud922\udfe7\udb10\udd8a\uda17\udf95\ud99b\udfbf\ud80e\udd93\ud9cc\ude51\udb1e\udeb6\ud94a\udc04\ud947\udd75\ud9f6\udc9f\udbdd\udd99\udb80\udee5\uda8d\udd12\udbf3\udeb2\uda22\udd93\ud818\udebe", "\u2ef5\ua85d\ua8bc\u4c36\u2c1b\uc9d1\u7a10\u5462\u3c13\ub874\u27aa\u91f6\u9755", "\udb2d\udfe1\udbad\ude6c\uda94\udeeb\uda0e\udf3c\udbca\ude0e\ud9ca\udc9c\ud99a\udf62\u8670\ud8bc\udc90\udb8b\uddc6\uda81\udcfe\uda2a\udd01\udad0\udf02\udad6\udf63\ud936\ude25\ud962\udf40\udae5\udd59\ud97f\udc9c\u37e6\u27c0\udacd\udde4\uda2d\udd93\uda34\ude72\udb29\udedd\uda1a\udc20\uda81\udf76\ud910\udf6a\ucc6e\u9576\udb50\udd83\ud843\udef6\udadd\ude5c\ud9f5\udde4\udb9e\udd1b\udb5f\udc00\uf0dd\ud9b6\ude73\ud8a5\uded1\ud983\udee2\ud838\ude1c\ud9f4\ude3f\ud989\ude0e\ud88b\udc24\ud8ed\udffc\ud9fc\udf63\ud885\udf31\ud975\udf47\udb2b\udc58\ud97f\udf7f\ud83f\ude3a\ud8d1\udcc9\ud872\udff2\ud8a0\udf55\udbb3\udc9a",
        44, 11625, 1795571704, 1986905920680017670L, 6685L, false, false, (char) 9012, (char) 4069,
        Double.longBitsToDouble(0x3fe842fc05e481a1L), Double.longBitsToDouble(0x3fd498e97a74048cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 1, 4, "\ud9ea\udc44", "\u2929\u76a1\u17e0\u9277\u4f71\ua83b\uaa61\u10a7\ua69a\u943b\u573b\uc33e", "\ud8cb\udf13\ud818\udebe\ud99e\udf6e\udbd6\ude04\ud9b6\udca7\udaa3\udea1\ud887\udf82\ucc7f\udb61\udcdb\uda91\udc5e\uda12\udd14\ud8bf\udcc9\udb1b\udfe5\udb49\udf60",
        49, 92850, -1102536106, 2310249537913838925L, 22882L, true, true, (char) 4036, (char) 52649,
        Double.longBitsToDouble(0x3fdee32dbca5e77eL), Double.longBitsToDouble(0x3fe1b7b20bb7804fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.io.File:\udb93\udc7d\uda0b\udf3c\uda06\udd21\udbc2\udf69\udb6d\udc0c\ud9d7\udda8\ud8d0\udc22\ud80e\udd93\ud9cc\ude51\0121=java.io.File:\udb93\udc7d\uda0b\udf3c\uda06\udd21\udbc2\udf69\udb6d\udc0c\ud9d7\udda8\ud8d0\udc22\ud80e\udd93\ud9cc\ude51\012",
        Z.run(T, 2, 4, 4, 10, "\udb93\udc7d\uda0b\udf3c\uda06\udd21\udbc2\udf69\udb6d\udc0c\ud9d7\udda8\ud8d0\udc22\ud80e\udd93\ud9cc\ude51", "\u4b8f\u2abb\u573b\ua466\u24e5\u67c3\ubf50\u2706", "\uda57\udff9\uda86\udcfd\udb60\udf77\udbff\udc4d\udaa5\udec0\udb71\uddd9\udba8\udddb",
        59, 87783, -426231856, 990211745587111677L, 44710L, true, false, (char) 51394, (char) 42644,
        Double.longBitsToDouble(0x3fddd36a73737582L), Double.longBitsToDouble(0x3fea8dc5f3704d75L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\ud815\udf6c\uda80\udd80\ud889\udc7c\uda24\udfe8\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\uda76\udd47\ud820\udfbd\0121=java.lang.String:\ud815\udf6c\uda80\udd80\ud889\udc7c\uda24\udfe8\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\uda76\udd47\ud820\udfbd\012",
        Z.run(T, 2, 0, 11, 9, "\ud815\udf6c\uda80\udd80\ud889\udc7c\uda24\udfe8\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\uda76\udd47\ud820\udfbd", "\u2b6a\u19b8", "\uda8d\udd12\udbf3\udeb2\ud8da\udd24\ud980\udfd1\ud944\udd52\ud8b7\udfd8\ud89d\udd82\ud8a4\udc1c\ud918\udc5d\u88c6\ud98d\udd55\ud818\udf09\udba8\udd60\ud953\udef1\ud99c\udcf7",
        0, 80357, 337880829, -7951485319879578298L, -31055L, false, false, (char) 1511, (char) 39067,
        Double.longBitsToDouble(0x3feb795fcd077451L), Double.longBitsToDouble(0x3fe6e02849a9ca5bL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.io.File:\ud95b\ude02\ud81b\udd3d\udbd4\ude22\ud922\udfe7\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\ud80e\udd93\udb40\uddaa\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 4, 11, 11, "\ud95b\ude02\ud81b\udd3d\udbd4\ude22\ud922\udfe7\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\ud80e\udd93\udb40\uddaa", "\u5979\u2abb\u573b\u8e27\u1cb9\u1741\u0483\u825e", "\ud41b",
        38, 29365, -1558471518, -7143195062865530006L, 18241L, true, false, (char) 60598, (char) 28931,
        Double.longBitsToDouble(0x3fe7e86c363b1423L), Double.longBitsToDouble(0x3fd4611a6da62ba0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 10, 11, 4, "\ud844\udc6e\u55a3\udb89\udc4d\ud94f\udde7\udb2a\udfb3\uda65\udf9c\ud99b\udfbf\ud80e\udd93\ud9cc\ude51\ud942\udeb3\ud971\ude56\ud9d6\udcb3\ud9f0\udf1f\uda40\ude91\ud940\udd8f\uda8d\udcef\udbf3\udeb2\udae1\udc06\ud818\udebe\ud944\udd80\ud9d2\udc05\udb3d\uddf7\ud9f5\udc51\ud918\udceb\u55fa\ud98d\udd55", "\u6a62\u59f1\u6225", "\udb6b\udd1a\ud9ca\udc23",
        57, 14192, 40919158, 3945449390349907036L, 54749L, true, false, (char) 35382, (char) 62503,
        Double.longBitsToDouble(0x3fe07293ccc126f2L), Double.longBitsToDouble(0x3fe0e8f8ac2d59afL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 3, 10, "\udb93\udc7d\udb08\ude3b\ud85d\udf85\ud8ca\udd8d\uda26\udf46\ud98b\udd58\ud982\udddb\ud80e\udd93\ud9cc\ude51\ud942\udeb3\uda4e\udd4b\ud8cf\udd5e\ud9f6\udd38\udbdd\udd99\ud808\udf46", "\ubf50\u62f1\ua8c2\uc923\u15c6\u6ec9\uceb8\ud675\u5a1d\ud476\u423a\u5473\ud1ed\uc226\ua313\u7b26\u3d69\u647d\ua396\u72f2\u9bf7\u63cd\u871e\u8321\u0f73\u840a\u4aca\u0fdd\u2354\uaf5a\u930d\u432b\u29f4\u76a8\u8bb3\u59a9\u3ae4\u2cea\u871c\u041e\u1b31\ubaa3\u74f5\u6750\u1355\u4815\u7bac\ub39a\u3f5b\u3fee\u8db9\u0507\ua9cf\u684d", "\ud98b\udf32\ud8d1\ude98\ud923\udd13\ud85c\uddc9\ud8a1\ude07\ud930\udf0f\ud906\udd24\udbf3\udd30\ud6e4\uda67\udced\uda24\udd4d\ud838\udf1f\uda81\ude11\uda3f\udc9b\ud8e3\udf78\udbf2\udd6c\ud83c\udeec\udbb2\udc82\ud9b8\udc23\ud933\udd80\udbc8\udda3\udbfb\udc2e\ud8d3\udeaf\udb1d\udc7d\uda65\ude57\udada\udd6a\udb0e\udf22\ud9ce\udc29\ud90b\udd06\udbc4\udd63\uda47\udfdd\ud88a\ude6a\ud97f\ude8b\ud87d\udfa1\ud8bd\udf40\ud8e6\udff2\udb5e\uddf8\udb32\udd62\u2724\udb52\udcd2\udaf3\udc1a\udbad\udd3b\udb75\udf9a\udbec\udf54\ud818\udf49\udbab\udea3\ud8ec\udd0f\udb46\ude5b\ud8de\udf00\udbba\udd83\ud81a\udd86\ud820\udce5\ud973\udc34\uda5f\ude37\ud87b\uddeb\udb28\ude82\ud985\udc9f\ud837\udc07\ud86b\udc6e\udaf8\udf72\uda44\udf70\uda7c\udcce\ud895\udf56\udaf5\udef4\ud812\udcac",
        25, 10293, -135821672, -5467264224397563380L, 90995L, false, false, (char) 14894, (char) 9252,
        Double.longBitsToDouble(0x3fe092f5ba316ca7L), Double.longBitsToDouble(0x3f9079d13e5027e0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 10, 10, 4, "\udb0a\udfb9\000", "", "",
        17, 68300, -998999564, 16049884763258880L, 68422L, false, false, (char) 17008, (char) 41435,
        Double.longBitsToDouble(0x3f31ea1de5715800L), Double.longBitsToDouble(0x3fec8609d785af86L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 10, 10, 4, "\udb0a\udf2c\udb4d\udc22\u2469\000", "", "\uda99\ude71\ud949\udd4c\000\udb0e\udd07",
        3, 62578, -1385075174, -6694892465919644246L, 96608L, false, false, (char) 46282, (char) 39691,
        Double.longBitsToDouble(0x3feb7c9a8c95bd0aL), Double.longBitsToDouble(0x3fdac776c6251da6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 3, 4, "\udb95\udc7e", "\u91d2\u76a1\u17e0\u0954\u8172", "\ud971\ude56\udb29\udd6d\ud9f6\udd38\udbdd\udd99\ud8ae\uddbd\udb8a\uded4\udbf3\udeb2\uda0f\udda8\ud818\udebe\uf27d\udb9c\udd51\ud8c7\udc7f\ud99c\udc39",
        50, -385, -154953706, -2797754502517828920L, -27314L, true, false, (char) 47656, (char) 23495,
        Double.longBitsToDouble(0x3fdf5a0336f34b28L), Double.longBitsToDouble(0x3fdbf6af30afbfd8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 6, 0, "\udb93\udc7d\uda3f\udd57\udbd4\ude22\ud922\udfe7\ud877\uddf6\uda39\udfb5\ud99b\udfbf\ud80e\udd93\udbae\udeec\ud902\udd48\ud81c\udfcc\ud94c\udfad\ud9f6\udd38\udbdd\udd99\ud855\udefc\uda8d\udd12\udbf3\udeb2\ud8da\udd24\ud818\udebe\uf27d\ud9cd\udda9\uda33\udec1\ud939\ude2c\ud952\udfd1\ud9dc\udc74\ud99e\ude5b\ud98a\ude59\uda44\ude9c", "\u64b3\u7b24\u57e7\u25c1\u1aaf\u8de7\u9822\u6274\u4a5a\ub18e\u2565\uc1a6\u1659\u7537\uca1f\u83b6\u9903\ub6e3\ub820\uaa56\u2fa1\u57a2\ub8f6\u2dd1\u8af6\u2358\uc21a\u95ce\u67b9\u15f2\u9262\ua801", "\ud84c\ude23\u728e\ud92b\udf57\ud906\ude82\udbb0\udeae\ud964\udc5a\ud980\udefa\uda96\udd63\ud9b8\udf38\ud96c\udffe\ud9bf\ude46\ud948\udf95\ud8b4\udd06\udaa6\udcbf\udb38\udd3f\udb5a\udfc4\uda6b\udd94\ud908\udeb3\uda2d\udecb\udb61\udefb\ud8b6\udc93",
        11, 68046, 1048045622, 3610806755395856819L, -4254L, true, false, (char) 44353, (char) 40361,
        Double.longBitsToDouble(0x3fe5398666425967L), Double.longBitsToDouble(0x3fbd5cd529f2afa0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "M|org.apache.commons.cli.TypeHandler|createClass|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createDate|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFiles|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createObject|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createURL|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|openFile|java.lang.String|static",
    "C|org.apache.commons.cli.TypeHandler|<init>|",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
