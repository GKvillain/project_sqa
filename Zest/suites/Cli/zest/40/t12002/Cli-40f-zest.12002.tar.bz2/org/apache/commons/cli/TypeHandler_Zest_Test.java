package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 1, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae", "\u5c74\u4430\u82b3\u25c9\u5730\u41d2", "\uda80\udd71",
        8, 85110, -223583386, 2705618127755483242L, 7039L, false, false, (char) 25554, (char) 9449,
        Double.longBitsToDouble(0x3fecab50417b64b9L), Double.longBitsToDouble(0x3fe89473ef112479L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 1, "\udaf3\udc9e\uda07\ude6c\udb05\udfb3\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae", "\u5c74\u1783\u0205\u250b\u5730\u41d2", "\uda80\udd71",
        8, 85110, -223583386, 2705618127755483242L, 7039L, false, false, (char) 25554, (char) 9449,
        Double.longBitsToDouble(0x3fecab50417b64b9L), Double.longBitsToDouble(0x3fe89473ef112479L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 11, 6, 6, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\uda82\uddf1\ud980\udf3d\ud8ae\udea2\ud9cc\udea1\uda85\udfae", "\u5c74\u4430\u82b3\u25c9\u5730\u41d2", "\uda80\udd71",
        8, 85110, -223583386, 2705618127755483242L, 7039L, false, false, (char) 25554, (char) 9449,
        Double.longBitsToDouble(0x3fecab50417b64b9L), Double.longBitsToDouble(0x3fe89473ef112479L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 8, 5, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae\udac2\udd67\ud9c3\udcea", "\ua8d7\u4e95\u5730\u358f\u2a18\ucbab\ub96f", "\ud95a\udf19\uda65\udf80\uda10\udeee\udaa4\ude91\uda1a\udd41\udb90\udd7a\ud8c1\udc6e\u07fa\ud9e0\uddd8\uda04\udeca",
        37, 916, 896256497, 8288734804776557042L, 86948L, false, true, (char) 54611, (char) 26185,
        Double.longBitsToDouble(0x3fe14ff89f525cb6L), Double.longBitsToDouble(0x3fd0eaa21f1191baL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 11, 1, "\udaf3\udc74\udad9\udd55\udaf5\udcfb\udb7d\udc0b\ud8a9\udc30\ud917\udc18", "\u1b75\u3716\u5c74\u4430\u82b3", "\udbc4\udcdf\ud806\udd49\u73fe\uda80\udd71\udbab\udd7a\udadf\ude15\udbc6\ude9c\ud9c0\udf90\uda10\udeee\udaa4\ude91\uda1a\udd41",
        41, 8719, 1778955948, 7257946162194585979L, -75663L, true, false, (char) 25810, (char) 9782,
        Double.longBitsToDouble(0x3fd04904cbc02adcL), Double.longBitsToDouble(0x3fcdaf9db8ab700cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 1, "\udaf3\udc9e\udad9\udd55\uecbd\udb7d\udc48\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae", "\u2187\u4430\u82b3\u37dc\u1370\u41d2", "\ue6d4\udbab\uddd7\udadf\ude15\udbc6\ude9c\ud9c0\udf90\uda10\udeee\udaa4\ude91\uda1a\udd41\udb90\udd7a\ud8c1\udc6e\uda8e\udd5f\uda3b\udcf4",
        -3, 55514, 152657681, 2574650828628259480L, 50340L, true, false, (char) 56679, (char) 19550,
        Double.longBitsToDouble(0x3fe09778b8189401L), Double.longBitsToDouble(0x3fc199a381bb2ff8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 7, 1, "\udaf3\udc6c\udad9\udd55\udaf5\udc8d\udb7d\udc0b\udbc0\udcb6\ud8ae\ude19\ud9cc\udeb3\uda85\udfae", "\u5c74\u0981\u3298\u733f\u5730\u41d2", "\udb61\uded7",
        8, 85110, -223583386, 2705618127755483242L, 7039L, false, false, (char) 25554, (char) 9449,
        Double.longBitsToDouble(0x3fecab50417b64b9L), Double.longBitsToDouble(0x3fe89473ef112479L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 11, 1, "\udb7d\udc7d\ud971\udcb0\ud8c2\ude38\udb67\ude3b\ud971\udd6c\ud8ae\udea2\ud82c\udc0e", "\u3677\u14c2\ucfda\u2599", "\u458c\ud9e0\ude17\u73fe\uda80\udd71\ud996\udf8e\u6865\uda10\udfc1",
        59, 83555, -751680972, 4192357644982970969L, -95573L, true, true, (char) 14917, (char) 41257,
        Double.longBitsToDouble(0x3fdd72479c70806aL), Double.longBitsToDouble(0x3fd44a47bd281e9eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 11, 7, "\udaa6\udcb8\udb0c\udd83\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\uda3f\udf2c\ud9cc\udebb\uda85\udfae\udac2\udd67\ud9c3\udcea\udb41\udcc1\udba1\udfc2\ud860\udf22\u2ea0\ud9e0\udd36\ud914\udd12\ud80e\udf78", "\u85aa\uaa82\u739a\u2618\u9b0c\ub6e4\u59cc", "\udaa8\udeeb",
        -3, 83667, 611914514, 5034284485502519815L, -40084L, false, true, (char) 23745, (char) 44118,
        Double.longBitsToDouble(0x3fe0a8f9f59987feL), Double.longBitsToDouble(0x3fca17cb148f657cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 1, "\ud8a0\udece\udbe9\udc96\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud998\udfa7\ud9fa\udd3a\udac2\udd67", "\012\u82b3\u25c9\ud760\ucfec\u80b6\u6a4f\ud0f9\u0c35\ub5d6\ud6b9\ubb7b\u5c31", "\udb90\udd7a\ud8c1\udc6e\udaa8\udeeb\uda3b\udd84\uda04\udeca\ud8d3\udd38\udba4\uddb7\udb04\udd7a\udbcd\udec7\ud86d\uddac\udbe2\udd33\ud82e\uddcd\udb86\udee2\u8c85\udbbc\ude7b",
        37, 45962, 1421678640, -2602979268928464412L, -87892L, true, true, (char) 14801, (char) 40215,
        Double.longBitsToDouble(0x3fee3dbb238f57daL), Double.longBitsToDouble(0x3fe1123b618432deL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 0, "\ud857\udd4e\udabb\udf9d\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae\udac2\udd67\ud9c3\udcea", "\u82b3\u25c9\u5730\u7921\u876d\u4f2a\ud0f9", "\udbc6\ude9c\udb75\udf0f\uda11\udeab\udaa4\ude91\uda1a\udd41\udb90\udd7a\ud8c1\udc6e\udaa8\udeeb\uda3b\udd84\uda04\udeca",
        24, 86573, 923869974, 44797357624399722L, -98678L, true, true, (char) 20679, (char) 1405,
        Double.longBitsToDouble(0x3fe35bfcf479803aL), Double.longBitsToDouble(0x3fe778bb9658399bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 9, 11, 1, "\udaf3\udc9e\udad9\udd55\ud8e1\udfc4\udaf6\udf43\ud975\udcf1\u8944\ud9cc\ude40\uda85\udfae\udac2\udd67\udb7d\udce7\udb41\udcc1\ud8b7\udfce\ud855\udfd9\ud9aa\udc08\uda1c\udd7f\udb15\udc1f", "\ud0b1\u668f\u6766\u2fb7\u75da\u9b0c\ub69b\u988f\u13d3\u1747\u1864\u06f6\uaaf2\u9745\ucd1f\ub023\u9f4f", "\uda17\ude5d\ud8a2\ude40\udb0b\udc07\ud998\udcaf",
        1, 21011, -1256823308, 7722057769533733736L, -66504L, true, false, (char) 45637, (char) 37709,
        Double.longBitsToDouble(0x3f9d925c0ff3a3a0L), Double.longBitsToDouble(0x3fdaada526ce08e6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 5, "\ud8f2\udf9e", "\u5787\u6047\u67d1\ua08e\u5801\u1b66\u3716\u5c74\u4430\u82b3\u25c9\uc568\000\000\000", "",
        -5, 4168, 18778, 3026418947989022772L, -100000L, false, false, (char) 0, (char) 53661,
        Double.longBitsToDouble(0x3fd7b64b96251cfaL), Double.longBitsToDouble(0x3fe8892001b40b09L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 1, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b", "\ua08e\u5801\u1b66\u3716\u5c74\u4430\u82b3\u25c9", "\ud80e\udf78\u73fe\uda80\udd71\udbab\udd7a",
        45, 29614, 629950810, 3078518662226094132L, -72640L, true, true, (char) 9449, (char) 53661,
        Double.longBitsToDouble(0x3fd7b64b96251cfaL), Double.longBitsToDouble(0x3fe88923cfcb7f5eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 11, 1, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud836\udd07\udad7\ude1a\udbb6\udc72", "\u95de\u303e\u82b3\u25c9\u5730\u41d2", "\uda80\udd71",
        2, 95902, -229325481, 2705618127755483242L, -43393L, false, true, (char) 25723, (char) 57416,
        Double.longBitsToDouble(0x3fe799b6d0ea99eeL), Double.longBitsToDouble(0x3fc6d507bc4490ccL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 6, 11, 1, "\udaf3\udc9e\ud821\udcfc\udaf5\udc8d\udb7d\udc0b\ud811\udd6b\uda53\udf0c\ud94e\ude39\uda85\udfae\udac2\udd67\ud9c3\udcea\udb41\udcc1\ud87c\udf53\ud87f\udef4\u2ea0\ud9e0\udd36\ud914\udd12\ud80e\udf78\u73fe\uda80\udd71\udbab\udd7a\udadf\ude15\udbc6\ude9c\ud97e\ude0f\uda28\udd11\udaa4\ude91\u26ba\udb90\udd41\ud8c1\udc6e\udaa8\udeeb\ud8a7\ude3d", "\ube7f\u023f\u2455\u4f46\u31ea\u2c8d\u0e86\u2845\u0eb1\u59f6", "\u1730\uda88\udc44\udb2a\udf58\ud829\udf5d\ud9e0\udf8b\udae7\uddee\uda6a\ude13\ud982\udf6e\udb86\ude6c\udb42\udf4f\ud834\ude32\ud810\udd79\udbcf\ude90\uda36\udd1e\ud841\udffa\uda2a\ude5f\ud9ad\udfce\ud8d5\ude20\udae1\udf0e\ud8b5\udf63\udb7f\udd15\ud920\udf23\ud957\udd2c\ud8f3\udd88",
        2, 78020, 575895818, 6654378515183680209L, -62004L, false, true, (char) 3319, (char) 19820,
        Double.longBitsToDouble(0x3f90e9969e518f80L), Double.longBitsToDouble(0x3fe57cc6556d2fe9L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 8, 9, "\udaf3\udc9e", "\u5787\u6047\u67d1\ua08e\u5801\u36eb\u3716\u5c74\u4430\u82b3\u25c9\u5730\u41d2\u2a18\ucbab", "\udadf\ude15",
        34, 22594, 716811146, -6888915112740102687L, 64995L, false, false, (char) 43968, (char) 65075,
        Double.longBitsToDouble(0x3fe89473ef112479L), Double.longBitsToDouble(0x3fee300a50d2ae12L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 1, "", "\u12b4", "\ud8ae\udea2\ud9cc\udea1\uda85\udfae",
        39, 21837, -838690892, 5401552460034605090L, -99966L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe00000042ba33eL), Double.longBitsToDouble(0x3fe0b474236643dbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 0, 1, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\udae4\ude9d\ud9cc\udea1\uda85\udfae", "\u5c74\u4430\u82b3\u25c9\u5730\u41d2", "\uda80\udd71",
        8, 85110, -223583386, 2705618127755483242L, 7039L, false, false, (char) 25554, (char) 9449,
        Double.longBitsToDouble(0x3fecab50417b64b9L), Double.longBitsToDouble(0x3fe89471ff112479L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 11, 1, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud97e\udf0a\ud8ae\udea2\ud9cc\udea1\uda85\udfae", "\u5c74\u4430\u82b3\u25c9\u5730\u41d2", "\uda80\udd71\udbab\udd7a",
        45, 29614, 629979738, -6747459413926206270L, -72640L, true, true, (char) 9449, (char) 53661,
        Double.longBitsToDouble(0x3fd7b64b96251cfaL), Double.longBitsToDouble(0x3fe88923c88c81cfL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.io.File:\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae\012",
        Z.run(T, 1, 4, 11, 1, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae", "\u5c74\u4430\u82b3\u25c9", "\ud80e\udf78\u73fe\uda80\udd71\ud955\udeee",
        51, 3333, 636631558, 3078518662226094132L, -72640L, true, true, (char) 9449, (char) 53661,
        Double.longBitsToDouble(0x3fd7b64b96251cfaL), Double.longBitsToDouble(0x3fe88fb27d51e392L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 6, 10, 5, "\udaf3\udc9e\ud82b\udfa3", "\ub2fb\u308f\u96d5\ucdb4\u3b22\u3716\u5c74\ubf76\ub0f0\u256a\u5730\u41d2\u2a18\ucbab\ud0f9\u85aa\uaa82\u739a\u75da\u37a2\ub748\u59cc\u1ed2\u47e8", "\uda12\udc82\ud8d3\udd38\uda5c\udff3\ud8da\udc6d",
        22, -873, 30500033, -5821581433595041642L, -19240L, false, false, (char) 64215, (char) 3621,
        Double.longBitsToDouble(0x3fc3663c425f6634L), Double.longBitsToDouble(0x3fe499a5deb9b4feL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 1, 2, 4, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\udb7d\udc0b\ud975\udcf1\ud8ae\udea2\ud9cc\udea1\uda85\udfae\udac2\udd67\ud8c5\udee5\udb41\udcc1\udba1\udfc2\ud860\udf22\u2ea0\udb32\ude12\uda69\udcf3\ud80b\udf2f\u73fe\uda80\udd71\udbab\udd7a\udadf\ude15\udbc6\ude9c\ud9c0\udf90\uda10\udeee\udaa4\ude91\uda1a\udd41\udb90\udd7a", "\u06f6", "\uf5a2\ud94e\udcc4\ud8dd\udf47\uda2e\udcdd\ud825\udf4a\ud826\udd63\udab7\ude48\udb77\udf5f\ud9b7\udf73\ud8c2\ude40",
        8, 76953, -1905448531, 3123626078498841315L, -24177L, false, false, (char) 3253, (char) 50061,
        Double.longBitsToDouble(0x3fde09b149a5e34aL), Double.longBitsToDouble(0x3fcc1e9b9b7828dcL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 11, 1, "\ud8f2\udf9e", "", "",
        -5, 8441, 0, 15007997L, -100000L, false, false, (char) 218, (char) 25122,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe96000000000ebL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 0, 4, 1, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\000\000\ud883\udce0\ud9cc\udea1", "\u3716\u5c74\u4430\u82b3\u25c9\u5730\u41d2\u2a18\ucbab\ud0f9", "\udbc6\ude9c\ud9c0\udf90\uda10\udeee\udaa4\ude91\uda1a\udd41\udb90\udd7a\ud8c1\udc6e\udaa8\udeeb\uda3b\udd84\000",
        24, 48137, -1444609561, 8731788341947265419L, 23258L, true, false, (char) 52069, (char) 57541,
        Double.longBitsToDouble(0x3fe719769fa2e634L), Double.longBitsToDouble(0x3fbbcefe3256aa90L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 9, "", "\000x", "",
        27, 46644, 16789837, -4979396805339774796L, -69758L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe24c3f4b2c1416L), Double.longBitsToDouble(0x3f0bd60ae8c00000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\udaf3\udc9e\udad9\udd55\udaf5\udc8d\uda82\uddf1\ud980\udf3d\ud8ae\udea2\ud9cc\udea1\uda85\udfae\012",
        Z.run(T, 1, 11, 6, 6, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\uda82\uddf1\ud980\udf3d\ud8ae\udea2\ud9cc\udea1\uda85\udfae", "\u09a0\ub6bc\u82b3\u25c9\u5730\u41d2\u2a18\ucbab", "\udadf\ude15\udbc6\ude9c\ud9c0\udf90\udbbc\ude84\udaa4\ude91\uda1a\udd41\udb13\udc5c\udac5\udc2f\udaa8\udeeb\uda3b\udd84\uda04\udeca\ud8d3\udd38\udab4\udc3f\udafd\udfad\ud96a\udf3f\udaad\udc29",
        28, 26523, 1726842979, 8545876533269919368L, -20079L, false, true, (char) 3552, (char) 27372,
        Double.longBitsToDouble(0x3fd691ae3ca26f60L), Double.longBitsToDouble(0x3fe360ea279cb86eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 11, 6, 6, "\udaf3\udc9e\udad9\udd55\ud892\udddf\uf06c\ud8b8\udec3\ud8ae\udea2\ud892\udc64\uda85\udfae", "\u5c74\u4430\u309a\u7d2b\u5154", "\u181d\uda9f\udcbf\udb1d\udcf2\udadf\ude15\udbc6\ude9c\ud9c0\udf90\uda10\udeee\udaa4\ude91\uda1a\udd41\udbaf\ude6e\udb05\udc70\udaa8\udeeb\uda3b\udd84\ud96e\udde5\uda4f\udd3d\ud906\udd43\ud897\ude0a\ud9b4\udc68\ud9b7\udecc\ud9ec\ude45\ud95a\udcee\ud9a0\udc99\uda30\udc7c\ud870\uddaf\ud8eb\udd22\udb93\udcaf\udb7c\udc99\ud9e4\udf90\udbce\ude42\uda5e\udcc7\ud9ee\udc87\ud9c5\udcc5\uda31\udf06\udaf0\udfba\udacc\udda2\udbd6\udea0\udafc\udd82",
        7, 38691, 2019826087, 1030961661979441824L, 3458L, true, false, (char) 31313, (char) 46313,
        Double.longBitsToDouble(0x3fecfb74e19034c4L), Double.longBitsToDouble(0x3fbb129149ce4420L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 10, 2, 6, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\ud9dd\udd3e\ud9fc\udf15\ud8ae\ude0a\ud9cc\udea1\uda85\udfae", "\u5c74\u4430\ud6e3\ud4e4\u7bcd\uc354", "\u7205",
        8, 52470, -231079488, 2705618127755483242L, 7039L, false, false, (char) 25554, (char) 9449,
        Double.longBitsToDouble(0x3fe45350417bcb5aL), Double.longBitsToDouble(0x3fe89473ef112479L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 11, 6, 6, "\000", "", "",
        35, 78937, 234881236, 127562370057764941L, -100000L, false, false, (char) 41166, (char) 14292,
        Double.longBitsToDouble(0x3fa3229da4987e90L), Double.longBitsToDouble(0x3fa60a0b6e900000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.io.File:\udaf3\udc9e\udad9\udd55\udaf5\udc8d\uda82\uddf1\ud980\udf3d\ud8ae\udea2\ud85a\udd73\udb56\ude5c\ud9ab\udead\ud9c3\udc3a\udb41\udcc1\udaef\ude29\ud860\udf22\u2ea0\ud9e0\udd77\0121=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 4, 6, 6, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\uda82\uddf1\ud980\udf3d\ud8ae\udea2\ud85a\udd73\udb56\ude5c\ud9ab\udead\ud9c3\udc3a\udb41\udcc1\udaef\ude29\ud860\udf22\u2ea0\ud9e0\udd77", "\ucbab\u3afe\u88f2\u5023\u3798\u56f6\u9b0c\u3694\u59cc\u1ed2\u458c\ud257\u06f6\uaaf2\u4e4c\u4b4b\u9c79\u809e\u6efb\uc82c\u5f01\u77b6\u42a7\uce6e\u64bd\u085f\026\u194b\uc732\u6cdc\uabf1\u85ba\u7373\u7483\u3f24\u610d\u1a1f", "\ua24e\ud8c4\udf1e\udaae\udc9e\udb90\uddd8\udbf4\udd0a\uda41\udf3a\udba9\udd59\ud926\ude39\udaa7\udcb8",
        38, 34089, -1532117974, -190784897484960542L, 66639L, true, true, (char) 58986, (char) 56357,
        Double.longBitsToDouble(0x3fe7d1655d069f1eL), Double.longBitsToDouble(0x3fc861764fb9d160L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 11, 7, 11, "\uda41\udeb8\ud83b\udc30\udaf5\udc8d\uda82\uddf1\ud8de\udcac\ud8ae\udea2\ud9cc\udea1\uda85\udfae\udac2\udd67\ud9c3\udc3a\udb41\udcc1\udba1\udfc2\ud860\udf0a\u2ea0\ud9e0\udd36\ud81b\udc35\uda39\udebd\udbe9\udc23\ud859\udc9d\udbab\udd7a\udadf\ude15\udbc6\ude9c\ud9c0\udf90\udab8\udc62\ud83b\ude35\uda82\ude50\udb90\udd7a\ud8c1\udc6e\udaa8\udeeb\ud9fa\udd64\uda04\udeca\ud8d3\udd38\udb5a\udc92\udb2d\udc5f\udabc\udc5f\u6018\ud8f5\udc4d\ud8ea\udd2f\uda92\ude20", "\ucd0b\u1c76\uafbd\ud3c0\ub511\uabb8\u4025\uc532\u92e9\u9cef\u31b7\uc278\u571f\u343c\u19ff\u700d\u898b\u9238\ud587\uacfd", "\udbbb\ude13\udbec\udce2\udbfa\udd7d\uda01\udde8\udbea\udc3e\ud95e\udc63\udb52\udc09\ud93b\udc66\u4473\udb02\udc5d\udbcf\udfb7\ud9b6\udd89\udb2c\udf59\uda69\udde8\ud9b9\udcb9\ud8c8\uddad\ud80f\ude5c\uda4c\udd32\ud9c0\uddc9\udae5\udfa1\udbde\uddef\ud80e\udd42\ud83f\udff9\udb8b\ude0a\uda4d\udcf2\ud87e\udc34\ud8f6\udcdc\uda00\udfbc\u3b07\ud9cc\udc5a",
        10, 91096, -1948022277, 7974701196248344575L, 7002L, false, true, (char) 25670, (char) 41115,
        Double.longBitsToDouble(0x3fd77bf214493d28L), Double.longBitsToDouble(0x3fd4984266d9c5c0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 10, 11, 1, "\udaf3\udc74\udad9\udd55\udaf5\udcfb\udb7d\udc0b\ud8a9\udc30\ud917\udc18", "\u1b75\u3716\u2237\u6422\ub5cc", "\udbc4\udcdf\ud806\udd49\u7452\uda80\udd71\udbab\udd7a\uda95\ude10\ud8e9\udfe7\ud9c0\udfc5\uda10\udeee\udaa4\ude91\uda1a\udd41",
        41, 8719, 1778955948, 7257946162194585979L, -75663L, true, false, (char) 52935, (char) 21832,
        Double.longBitsToDouble(0x3fd04904cbc02adcL), Double.longBitsToDouble(0x3fcdaf9db8ab700cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 11, 1, "\udaf3\udc9e\ud8c5\udc76\ud958\udde1\uda21\uddf9\udbcd\udda2\udbc6\udf0c\uca68\ud879\udc33", "\u95de\u30ca\u829c\u25c9\u5730\u52da\u2a66\ucbab\u6280\u98e9", "\ud8ba\udd55",
        14, 87932, 977715278, -7330531354942540182L, 89880L, false, false, (char) 58912, (char) 27248,
        Double.longBitsToDouble(0x3fca6756b6eb9190L), Double.longBitsToDouble(0x3fe1ef8318f1cb1dL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=java.io.File:\udae9\udd4b\udad9\udd55\012",
        Z.run(T, 2, 10, 4, 1, "\udae9\udd4b\udad9\udd55", "\u7e0c\ub030\u4b4f", "\ud9e3\uded7",
        47, 21836, -1584403365, 7111988553228288802L, -38633L, false, true, (char) 45892, (char) 16257,
        Double.longBitsToDouble(0x3fcd1dc0176ec208L), Double.longBitsToDouble(0x3feb86f6cd6a2559L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.io.File:\udaf3\udc9e\ud93c\udfc7\ud827\udc4b\udac9\udccd\ud975\udcf1\udbe4\udd7d\udb46\udf7b\udb07\ude9a\0121=java.io.File:\udaf3\udc9e\ud93c\udfc7\ud827\udc4b\udac9\udccd\ud975\udcf1\udbe4\udd7d\udb46\udf7b\udb07\ude9a\012",
        Z.run(T, 2, 4, 4, 1, "\udaf3\udc9e\ud93c\udfc7\ud827\udc4b\udac9\udccd\ud975\udcf1\udbe4\udd7d\udb46\udf7b\udb07\ude9a", "\u0fa6\u4430", "\ud8da\udd24\udaca\udcf3\udbf5\udc70",
        57, 38017, 786641963, -4774595157943057611L, -28214L, false, false, (char) 65094, (char) 42030,
        Double.longBitsToDouble(0x3fe2c3aaa5b5883dL), Double.longBitsToDouble(0x3fea367ea17b64b9L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 10, 10, 2, "\udaf3\udcb8\udad5\udf34", "\u61d7\u995b\u7d48", "\ud9c3\udc3a\udaf8\ude6e\udba2\udc20\ud80d\udde2\u05bc\uda8d\uddff\ue46a\ud80f\udc10\uda6a\ude7f\u7205",
        -3, 52473, -231079488, -6372423760674730643L, 7039L, false, false, (char) 25554, (char) 9449,
        Double.longBitsToDouble(0x3fe45350417bcb5aL), Double.longBitsToDouble(0x3fe89473ef112479L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 10, 0, 8, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\ud9dd\udd3e\ud9fc\udf15\ud8ae\ude0a\ud9cc\udea1\udabd\udd29", "\u8dd2\u3730\ud6e3\uc1a1\u0482\uc354", "\u7205\udbab\udd7a\uda36\udf41\ud8a2\udcf0\ud9c0\udf90\uda10\udee0\ud8db\udf0c\uda1a\udd41\udb90\udd7a\ud8c1\udc6e\udaa8\udeeb\udaf6\udf6f\uda04\udeca",
        24, 94417, -879540511, 1148334685477436120L, -23194L, false, false, (char) 27937, (char) 54439,
        Double.longBitsToDouble(0x3fc714203e1c369cL), Double.longBitsToDouble(0x3fc914547b129348L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 10, 10, 6, "\udaf3\udc9e\udad9\udd55\udb0b\udd8e\ud9dd\udd3e\ud8a8\udffb\ud83d\udf6d\ud9cc\ude1e", "\ua65b\u53ee\u4430\ud6e3\ud4e4\u7bcd\uc354\u2ab0\u9b82\ud7b1", "\ud8a2\udcf0\ud9c0\udf90\uda10\udeee\ud866\uddd2\uda1a\udd41\udb90\udd7a\ud8c1\udc6e\udaa8\udeeb\udaf6\udf6f\uda04\udeca",
        24, 85113, 1181162108, 7889505884016461697L, 38755L, false, false, (char) 41253, (char) 61197,
        Double.longBitsToDouble(0x3fe172f86357593bL), Double.longBitsToDouble(0x3f91f88043dd43c0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 11, 10, "\udaf3\udc9e", "\u5787\u6047\u67d1\u8875\u5801\u1b66\u3716\u5c74\u4430\u82b3\u25c9\u5730\u41d2\u2a18\ucbab\ud0f9\u85aa\uaa82\u739a\u75da\u9b0c\ub6e4\u59cc\u1ed2\u458c\ud257\u06f6\uaaf2\u4e4c\ucc08\u0333\u153d\u85e2\uab90\u9772\u6c90\u26fa\u13da\u6030\uc01d\u5f54", "\ud9a3\udd30\ud9a3\ude6c\ud9bf\udd92\udabf\uded0\ud807\udcc5\uda7f\uddf8\uda2c\udfc5\ud988\ude1c\ud968\udeba\udb42\udd9b\ud8b7\udfa3\ud8e1\udf59\ud984\ude00\uda19\ude85\uda85\udce7\udb72\udd99\udbfc\udfc7\ud915\udd8c",
        41, 4677, -803136860, -7733301512392376565L, -73277L, false, true, (char) 28347, (char) 9453,
        Double.longBitsToDouble(0x3fec5542e08bdfabL), Double.longBitsToDouble(0x3fe55b91d93c840cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:\ud854\udf64\uf3cc\udac6\ude2c\uda25\ude5b\udba5\udc1c\ud8ae\ude34\ud870\ude4f\0121=java.lang.String:\ud854\udf64\uf3cc\udac6\ude2c\uda25\ude5b\udba5\udc1c\ud8ae\ude34\ud870\ude4f\012",
        Z.run(T, 2, 0, 11, 3, "\ud854\udf64\uf3cc\udac6\ude2c\uda25\ude5b\udba5\udc1c\ud8ae\ude34\ud870\ude4f", "\u2b7f\ud7b1\ucfda\u2599", "\ud971\udd90\uc762\udae0\udc1e\ud9ef\udec3\ud81d\udec8\ud90c\udce2\ud9ba\ude01",
        56, 83555, -1501288321, 4199493449979423321L, -95573L, true, true, (char) 63087, (char) 41257,
        Double.longBitsToDouble(0x3fbb491e7312b030L), Double.longBitsToDouble(0x3fec0c58ee940f4fL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 3, 2, 8, "\udaf3\udc9e\udad9\udd55\udaf5\udc8d\uda48\udef1\ud980\udf3d\ud8ae\udea2\ud9cc\udea1\uda85\udfae\ud8ac\ude26\ud9d1\udd9e\ud834\udc83\udbe0\udfce\ud860\udf22\u2fe4\ud9e0\udd36\udb7e\udc6d\uf448\u73fe\uda80\udd71\udbab\udd7a\udadf\ude15\udbbf\ude17\ud9c0\udf90\udbbc\ude84\ud853\ude48\uda1a\udd04\udb19\udc29\ud99e\ude27\udaa8\ude7b\uda3b\udd84\uda04\udeca\ud8d3\udd38\udab4\udc3f\udafd\udea0\ud96a\udf3f\udaad\udc29\udb24\udfd0\uda73\ude3b\udb45\ude73\ud8c1\udc6b\udaaa\udfee\udb89\uddc7\ud957\uded5", "\uad50\u48b6\u60ee\u9998\u326e\u2c75\u434c\ub340\u91e3\ucbce\u1fe2\uce78\u3735\u5218\u131f\u12c2\u6b21\u407a\u70db", "\uda71\udf23\uc6ab\ud941\udcee\udbe8\udc3e\udb42\udf15\udbe2\ude64\uda70\udca9\udb8f\udc25\udb5e\udfc5\udbc4\udea4\u5e04\ucd11\ud867\ude0b\udaf5\udcfd\ud898\udffc\udab0\udeb0\ud9de\udf45\udabd\udc9b\ud988\uddde\uda73\uddf8\udab3\udf10\udb1e\udfa6\uc41a\udbce\udc16\udb76\uddb8\ud898\udc8f\ud8f1\udfe5\ud9c4\udeb9\udae5\uddd7\udbdc\udf16\udaf3\udc30\udaea\udceb\ud9f5\udcc0\uda93\udf4b\udb9f\udf04\udb03\uddd1\udb0d\udfb0\ud863\udc29\udb4c\udc9c\ud873\udf80\udabe\ude13\ud846\udfbb\ud962\uddc1\ud97b\udc71\ud9e8\udd46\udad3\uddee\udafa\udc21\udb0f\udfb9\ud89f\udc4e\ud8ef\udf1b\udae1\udd17\ud9bb\udf20\udb39\ude3e\uda7d\udd2e\ud875\ude26\ud898\udc37\ud9ab\ude5c\ud8ef\udfa7\ud989\udd23\udb92\udc06\udaf4\udc18\ud8a4\ude90\uda95\udd8e\udb11\udfe9\udbcd\udf19\ud814\udcd0\ud952\uddda",
        38, 53958, 678970292, -4037457094093303910L, -60221L, false, true, (char) 37205, (char) 14901,
        Double.longBitsToDouble(0x3fc033860910cd44L), Double.longBitsToDouble(0x3fc74f6ca7ffb53cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "M|org.apache.commons.cli.TypeHandler|createClass|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createDate|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFiles|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createObject|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createURL|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|openFile|java.lang.String|static",
    "C|org.apache.commons.cli.TypeHandler|<init>|",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
