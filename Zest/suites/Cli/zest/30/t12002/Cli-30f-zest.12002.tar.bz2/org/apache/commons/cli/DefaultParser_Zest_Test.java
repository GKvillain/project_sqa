package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 6, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\ua004\u7631\u1eb0", "\uda46\udf76\ud858\udc18\uda11\udcf0\ud853\uddff\ud87e\udc28\uda70\udcfa\udac1\uddbb\ud93c\ude3c\ud87e\ude9f\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a\udb60\uddc3\u6b83\ue3a1",
        22, 59202, 1358773209, 4122970452150854584L, 17068L, true, false, (char) 769, (char) 61621,
        Double.longBitsToDouble(0x3fef7944d3ade5fbL), Double.longBitsToDouble(0x3fb04dd4bab05608L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 6, "\ud812\udcec\uda96\uddfa\udad8\udcc3\ud989\udf36\udbed\udf5a\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\ua004\u7631\u0b66", "\uda46\udf76\ud849\udd89\uda11\udcf0\ud853\uddff\ud87e\udc28\uda70\udd60\udac1\uddbb\ud93c\ude3c\ud87e\ude9f\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a\udb60\uddc3\u6b83\ue3a1",
        22, 59202, 1358773209, 4122970452150854584L, 17068L, true, false, (char) 55185, (char) 61621,
        Double.longBitsToDouble(0x3fef7944d3ade5fbL), Double.longBitsToDouble(0x3fb04dd4bab05608L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 6, "\ud962\uddc9\ud9c1\udcc1\udbf9\udfff\ud82f\udf3c\ud948\ude24\ud8c9\udfae\udba3\udde9\uda0e\udf8b\ud90f\udf79\udb02\udf08\ud8d0\udc57\ud837\udef9\ud981\udd81\udb50\udef2\ud8e6\udcab\udbbc\udf31\uda46\udf76\ud858\udc18\ud8bd\udcea\ud853\uddff\ud8b0\udf7e\uda70\udcfa\udac1\uddbb\ud93c\ude3c\ud87e\ude5b\ud9ca\udded\ud8fb\udcc8\udbd4\udfb4\ud90c\udf06\udabb\udfbc\ud97c\ude85\ue3a1\u607f", "\u7f98\u663f\u6bb2\u2997\u2555\u649a\ud549\u0d19\uad3e\u2aad\uc61f\u07aa\u4f6c\u81c8\u9752\u37d5\ucbdf\ud419\u1383\u35ce\u2f96\u1700\u935c\u2730\ua571\ubba9\u2f21", "\ud891\udee7",
        54, 58872, -1857803315, 7885251741416897129L, 21994L, false, false, (char) 5889, (char) 2112,
        Double.longBitsToDouble(0x3fe5dca11a3a90caL), Double.longBitsToDouble(0x3fdb6e7a6fc79374L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 6, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\ua004\u7631\u1eb0\u995f\u0753\u89e3\u8c1c\u0658\uce37\u7748\u05c7\u558a\u5fdf", "\uda47\udeba",
        19, 26354, 1422165189, 3706507000416201074L, 36722L, true, true, (char) 3269, (char) 23791,
        Double.longBitsToDouble(0x3fb7c8f8b5a53d70L), Double.longBitsToDouble(0x3fe0fcc3b0b1c24fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 8, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ufdcc\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\ud8b7\udcd2", "\u283c", "\ud8f6\ude5d\udba4\udd8c\uda46\udf76\ud858\udc18",
        24, 65737, -847213581, -1740308760134989211L, 49257L, true, true, (char) 33566, (char) 2510,
        Double.longBitsToDouble(0x3fda78f7b6918eceL), Double.longBitsToDouble(0x3fc66a98c5c8cdc0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 1, "\ua5f2\ud917\udc9a\udae5\udfac\ud82f\udf40\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773\udb02\udf08\uda9f\udf4d\ud99f\uded0", "\u995f\u0753\u0967\u31bd", "\ud86e\udcff\ud9d7\udfcc\uda24\udece\ud8ae\uddfd\ud9ca\udca7\udb71\udfa0",
        48, 82273, 667334354, -450376080886323077L, -19143L, false, true, (char) 23791, (char) 65,
        Double.longBitsToDouble(0x3fdb4a7aec3f2c04L), Double.longBitsToDouble(0x3fc63849ed669570L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 10, 6, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\000\udba3\udde9\udb85\udd89[", "t\ud6a0\u1eb0", "\uda46\udf76",
        43, 35344, 122475921, -3638693948524256665L, 90976L, true, false, (char) 42376, (char) 33566,
        Double.longBitsToDouble(0x3fe6080066d29d7bL), Double.longBitsToDouble(0x3fc8a4f8c1ed5310L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 6, "\udaf2\ude24\ud9d5\udef6\ud8d1\udf3f\ud82f\udf9f\035\ud9d1\udf87\udba3\udde9\uda10\udf6e\udb7d\udccf\udb05\ude5e\ud961\udfc0\ud837\udef9\ud981\udd81\udb50\udef2\ud8f6\ude5d", "\u8c1c\u1b97\u903d", "\uda9c\udea9\ud93c\ude18\ud87e\ude9f\u0f0a\uda47\udeba",
        19, 26354, 1422165189, 3706507000416201074L, 48660L, true, true, (char) 3269, (char) 23791,
        Double.longBitsToDouble(0x3fb7c8f8b5a53d70L), Double.longBitsToDouble(0x3fe0fcc3b0b1c24fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 12, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\ua004\u7631\u390f", "\uda46\udf76\udba1\udd5f\uda11\udcf0\ud853\uddff\ud87e\udc28\uda79\udf9f",
        58, 49628, -1805797129, 5449374425282262910L, -15730L, true, false, (char) 32222, (char) 40245,
        Double.longBitsToDouble(0x3fc313bd7848c500L), Double.longBitsToDouble(0x3feecbde13c850fdL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 6, "\ud812\udc54\ud828\ude03\ud8d1\udf3f\ud829\udf9c\ud948\ude24\ud8c9\udfae\udba3\udde9\u0ce9\000", "", "\udb50\udef2\ud8f6\ude5d\udba4\udd8c",
        59, 33508, 2046801344, 526030074395280162L, -53509L, false, false, (char) 46813, (char) 42376,
        Double.longBitsToDouble(0x3febf25d06c1f30cL), Double.longBitsToDouble(0x3fe694ebdcc527c6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 0, 9, "\ud812\udcec\000\ud8d1\udef7\ufee7\ud948\udda0\ud8c9\udfae\ud928\udceb\000\000", "\ua004", "\ud8f6\ude5d\u008d\000",
        12, -1000, 122475921, -3638693948119056384L, -100000L, true, false, (char) 42376, (char) 33566,
        Double.longBitsToDouble(0x3fe60f9866d29d7bL), Double.longBitsToDouble(0x3f23e307b0000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 3, 6, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\ua004\u7631\u1eb0", "\uda46\udf76\ud858\udc18\uda11\udcf0\ud853\uddff\ud87e\udc28\uda70\udcfa\udac1\uddbb\ud93c\ude3c\ud87e\ude9f\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a\udb60\uddc3\u6b83\ue3a1",
        0, 389, 1358773209, 4122970452150854584L, 61025L, true, false, (char) 769, (char) 61621,
        Double.longBitsToDouble(0x3fef7944d3ade5fbL), Double.longBitsToDouble(0x3fb04dd4bab05608L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 2, 3, 6, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\udb93\udfb3\udba3\udde9\udb10\ude2e\uaf0c", "\ua004\u7631\u1eb0", "\uda46\udf76\ud858\udc18\uda11\udcf0\ud853\uddff\ud87e\udc28\uda7a\udffa\udac1\uddbb\ud93c\ude3c\ud87e\ude9f\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a\udb60\uddc3\u6b83\ue3a1",
        22, 59202, 1358773209, 4122970452150854584L, 17068L, true, false, (char) 769, (char) 61621,
        Double.longBitsToDouble(0x3fef7944d3ade5fbL), Double.longBitsToDouble(0x3fb04dd4bab05608L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 11, "", "\u230a", "\ud8c9\udfae",
        -5, 44585, 596067675, 2945847425202945536L, 70449L, true, false, (char) 60200, (char) 59249,
        Double.longBitsToDouble(0x3ec8b645e7fc0000L), Double.longBitsToDouble(0x3fe9103a6267cd80L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 12, "\ud9fb\ude09\ud811\ude7f\ud8d1\udf3f\ud82f\udf9f\ud97b\udeb2\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773\ud808\udfeb\ud961\udfe4", "\u4e18\u7f43\u00e2\ub711\u8c1c\u0658\uce37\u7748\u05c7\u558a\u1dfd\u6965\ud112\u2296\uadd1\u85f6\u813c\ud571\u0c79\u5af7\ub0bf\uced6\u7f98\u663f", "\ud91e\ude7c\uda20\udf59\uda1d\uddbd\ud9d6\ude66\uda77\udeef\ud8e5\udce3\udb47\udfc9\udb26\udd7d\udae0\udfba\ud9d9\udcad\ud8ef\ude86\uda6b\udf97\ud808\udcc4\udbff\udfed\udbbc\udf08\udbc2\udd22\ud844\ude2f\uda37\udea8\uda9d\ude16\ud9cf\udeee\ud9d6\udcd1\ud93f\udc26\uda65\udc5f\u4e10\uda95\ude3d",
        -4, 51367, -1898693758, -663711271678627391L, -34578L, false, true, (char) 19865, (char) 54163,
        Double.longBitsToDouble(0x3fe39e4947cdce17L), Double.longBitsToDouble(0x3fd7db598a5af91cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 7, "\ud812\udc77\ud828\ude03", "\ud7e3", "\udb85\udd89\u0773\udb02\udf08\ud961\udfc0\ud837\udef9",
        37, 96181, -1087281617, 8558680479797441634L, -50046L, true, false, (char) 12863, (char) 8963,
        Double.longBitsToDouble(0x3fceffbcc4ae5174L), Double.longBitsToDouble(0x3fd7e4ba0d83e7b0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 6, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773\udb02\udf08\ud961\udfc0\ud837\udef9\u1925\ud922\udc97\ud8f6\ude5d", "\u8c1c\u0658\uce37\u7748\u05c7\u558a\u5fdf\u86d2\u59a2\u1824\u01fd\u85f6", "\ud996\udcd9\u8372\ud81f\udd5d",
        9, 48864, 602022840, -6363906924585011532L, -2655L, false, true, (char) 29167, (char) 365,
        Double.longBitsToDouble(0x3fb10d954c84c960L), Double.longBitsToDouble(0x3fe52d5c0433fa8fL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 6, "\ud812\udcec\uda0e\uddf6\ud8d1\udf3f\ud82f\udf9f\u1b84\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\u57ef\u7631\u1eb0", "\000",
        43, -1000, 117440512, -3638693948524256665L, 91068L, false, false, (char) 4352, (char) 33566,
        Double.longBitsToDouble(0x3fe60f9860000000L), Double.longBitsToDouble(0x3e0ed53100000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 14, "\udbe5\udc6c\ud962\udc5e\ud96d\udf13\ud9e2\udcb0\ud98f\ude27\udbaf\udea8\ud8df\udc26\uda3d\ude48\udb16\udd4e", "\uaacc\u3866\u4b41\uad61\u2dc5\uc5cd\u8c1c\u0658\uce37\u7748\u485f\u558a\u5fdf\u6965\ube0e\uc1ca\u545f\u44f3\u813c", "\u3bd2\ud81f\udd5d\udb5c\udc9e\ud8ad\udc27\udb72\udd2f\ud874\udd91\ud8bd\udc3c\ud95b\udc0e\udaef\ude7f\uda86\udc70\udb5b\udedd\ud8ff\udd3a\udb4c\udd5d\ud806\udfc1\udaf7\udd75\ud8dd\ude66\ud910\ude75\uda67\ude42\ud864\udfcd",
        35, 7122, 883685585, 6511912364032057912L, 83272L, false, false, (char) 60274, (char) 19203,
        Double.longBitsToDouble(0x3fda0dfcc7bee654L), Double.longBitsToDouble(0x3fe00ce6c105dc2cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 12, "\ud812\udcec\ud9f2\ude39\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\ua004\ud730\u1eb0", "\uda46\udf76",
        43, 35344, 122475921, -3638693948524256665L, 91068L, true, false, (char) 42376, (char) 33566,
        Double.longBitsToDouble(0x3fe60f9866d29d7bL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 2, 2, 7, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\udac4\udfc2\ud8c9\udfa6\udba3\udde9\udb85\udd89\u0773", "\u3a04\u7631\u1eb0", "\ud8d5\uddc4\udab8\udf90\uda0e\udde9\ud853\uddff\ud9fa\ude06\udb54\udd9a\udac1\ude2c\ud93c\ude3c\ud87e\ude9f\ud9b0\udf32\uda0a\udc6e\ud938\uddd7\udafe\udd7e\udb60\uddc3\u6b83\ud882\udd0c\u837c\ud81f\udd5d\u3898\udacb\udfc4",
        50, 22799, 1713813111, -4445178044916940623L, -2655L, false, true, (char) 45656, (char) 15089,
        Double.longBitsToDouble(0x3f9ae92054388ac0L), Double.longBitsToDouble(0x3fd79df165ecd170L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 6, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\ua004\u7631\u1eb0", "\uda46\udf76\ud858\udc18\uda11\udcf0\ud853\uddff\ud916\udf54\udad0\udc1b\ud860\udf99\ud93c\ude3c\ud87e\ude9f\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a\udb60\uddc3\u6b83\ue3a1",
        22, 59202, 1358773209, 4122970452150854584L, 17068L, true, false, (char) 769, (char) 61621,
        Double.longBitsToDouble(0x3fef7944d3ade5fbL), Double.longBitsToDouble(0x3fb04dd4bab05608L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 1, 0, 9, "\ud812\udcec\ud828\ude03\ud92b\udc71\ud897\udc31\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\u0773", "\u2394\u7631\u1eb0", "\udbcc\udc58\ud811\udfb4\uda70\udd2d\ud81f\udcff\ud89d\udff9\uda70\udd7d\udac1\uddbb\ud93c\ude3c\ud87e\ude9f\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a\udb60\uddc3\u6bfd\ue3a1",
        22, 59202, 1358773209, 4122970453574680760L, 88702L, false, true, (char) 769, (char) 61621,
        Double.longBitsToDouble(0x3fef7944d3ade5fbL), Double.longBitsToDouble(0x3fb04dd4bab05608L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 10, 4, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\uda7b\ude93\ud844\ude35\uda7b\ude22", "\u2895\u6177\u1eb0", "\udb87\ude37",
        25, 40857, 122475921, -3638693946102111641L, -28924L, true, false, (char) 42376, (char) 33566,
        Double.longBitsToDouble(0x3fdc16399da5a5e6L), Double.longBitsToDouble(0x3fab77f4cf789020L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 6, "", "\u230a", "\ud8c9\udfae",
        -5, 44585, 596067675, 2945636318970412544L, -100000L, true, false, (char) 0, (char) 63231,
        Double.longBitsToDouble(0x3fdc011c5b22f3feL), Double.longBitsToDouble(0x3fe9103a6267cd80L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 9, "\ud812\udcab\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\udb97\ude9c\uc480\ud95c\udead\ud837\udef9\udbf4\udf07\ud8f6\udeee\ud87f\udd3b\udb91\ude03\uda46\udf76\ud858\udc18\uda11\udcf0\ud853\uddff\ud87e\udc28\uda70\udcfa\udac1\uddbb\ud93c\ude3c\udb41\udd8d\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a\udb60\uddc3\u6b83\ue3a1\u837f\ud81f\udd5d\udb5c\udc9e\ud8af\udf27\ud945\uddd5\uda4d\udf2a\udbd8\udc99\ud91e\ude7c\uda20\udf59\uda1d\uddbd", "\u6100\u9ef3\u0d06\ud396\u457c\u510a\u9ac4\u99c4\ua788\u0fb3\u8528\uab47\u059c\ub92d\uaff4\u14d6\u8650\u3d42\u4f42\ud0ce\u8f82\uc11e\u251b\u8233\u5b01\u8833\uc6e5\u21ba\u9b6e\u6928\u40ed\ud11d\u7540\ua82a\u2f74\u465b\u0b5a\u54de\u4887\ubd46\u6349\u9269\uc104\u6636\u142a\ua09f\u2118\u2fe5\u099e\ub0a6\u0cf5\u52d8", "\udba8\udcb0\ud9ed\udfea\ud927\udeed\ud89b\udf7b\udbb8\udf3a\udaf8\udceb",
        26, 11465, -246916712, 4420070751850700884L, 86589L, true, false, (char) 14886, (char) 63726,
        Double.longBitsToDouble(0x3fdc463517749ee6L), Double.longBitsToDouble(0x3fe510e4fb964425L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 0, 6, "\000", "\u755d", "\udba3\udde9",
        -5, 65584, 685883552, 0L, 31213L, false, false, (char) 59237, (char) 51076,
        Double.longBitsToDouble(0x3fd9179ff0000e98L), Double.longBitsToDouble(0x3e33280000000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 5, 2, "\udb9c\udf31\udbf3\udf16\uda1b\udf87\ud93d\udf9e", "\uc4b1\u1006\u742c\u5f05", "\ud9ab\uddac\udb50\udebc\ud8f6\ude5d\udba4\udd8c\uda46\udf76\udb1a\uddba\ud875\udc83\udaf0\udf87\udac3\udd73",
        21, 76653, -35198372, -7755839610996911829L, -40289L, false, false, (char) 38789, (char) 24443,
        Double.longBitsToDouble(0x3fe6a2cea148eab0L), Double.longBitsToDouble(0x3fc531a9fcd751f8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 13, 10, "\ud812\udcec\ud828\ude03\ud8d1\udf3f\ud82f\udf9f\ud830\udd97\ud917\udd63\udba3\udde9\uda37\ude02\ud82f\udf4a\ud9ab\udc01\uda71\udc11\ud8de\udd1a\udbd5\udfeb", "\u0753\u997d\ubf9b\u064d\uce37\u7748", "\ud93c\ude3c\ud87e\ude9f\udbbe\udf9f\udba2\udf07\udaa8\udcad\ud820\udd2a\udb60\uddc3\u6b83\ue3a1\u837f\ud912\udcd7\ud919\udec5\ud8af\ude8b\ud945\uddd5\uda4d\udf2a\ud988\udc31\udba4\udf34\uda20\udf59\uda1d\uddbd\ud9d6\ude66\uda77\udeef\ud8e5\udce3\uda6f\udd3d\uda6f\udd91\ud89a\udddb\udb1e\uddb4\ud915\udc00\ud850\udf51\uda1e\udde2\ud93f\udcb9\ucb49\udafd\ude53",
        11, 16082, -2130008662, -2564550621989407896L, -40934L, true, true, (char) 1856, (char) 61705,
        Double.longBitsToDouble(0x3fe1a8a1dec497f7L), Double.longBitsToDouble(0x3fe5ca0402cfa3abL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 10, 10, "\ud8b7\udd9f", "\u755d\000\000\u6435\u918c\ua776\u1114", "\ud981\udd81\udb50\udef2\ud8f6\ude5d\udb81\udeff\uda46\udf76\ud858\udc18",
        57, -1000, 0, 0L, -100000L, false, false, (char) 21581, (char) 44170,
        Double.longBitsToDouble(0x3ec8800000000000L), Double.longBitsToDouble(0x3e4848c400000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 3, 6, "\ud962\uddc9\000\udbf9\udffd\ud82f\udf3c\ud948\ude24\ud8c9\udfae\udba3\udde9\uda0e\udf8b\ud90f\udf79\udb02\udf08\ud8d0\udc57\ud837\udef9\u7790\udb2a\ude55\ud8e6\udcab\udbbc\udf31\uda46\udf76\uff0c\ud8bd\udcea\ud853\uddff\ud8b0\udf7e\uda70\udcfa\udb66\ude6e\udae5\udfd2\ud87e\ude5b\ud9ca\udded\ud8fb\udcc8\udbd4\udfb4\ud90c\udf06\udabb\udfbc\u3c6f\000\000", "\u7f98", "\udb74\udc4a\ud8ce\udfe0\ud90a\udcef\uda3d\udf8e\ud9d6\ude66\uda77\udeef\ud893\udcae\ud82f\udec2\ud86f\udcd3\uda38\udc38\ud9df\uddc9\ud8d3\udfec\uda06\udc7c\udae7\udc50\ud911\ude76\uda55\udc53\ud960\udfba\uda65\ude5d\ud9c6\udd9c\udbbc\udc04\uda19\udf22\ub21a\udabb\udda9\udbee\udd71\udbfa\udfa1\ud942\udee4\ud891\udee7\ud998\udc51\ud9fa\udcbc\ud97d\udd46\udbaa\udd20\ud9ed\udf57\udbe6\udc54\ud813\udc97",
        0, 11409, -1809584127, -8013571992992740806L, -34435L, false, false, (char) 65026, (char) 61497,
        Double.longBitsToDouble(0x3fe1a3f7444fe70bL), Double.longBitsToDouble(0x3fee249db0e01bbbL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 8, "\ud812\udcec", "\u8b89\ud7e3Z\000\000\000\000\000\u4855\000\000\u3330", "\000\ud9e3\udf30\ud88f\udd9d",
        43, -1000, 10963456, -151176253555230473L, -85794L, true, false, (char) 18722, (char) 41647,
        Double.longBitsToDouble(0x3fc66a98c0000000L), Double.longBitsToDouble(0x3fe4d2e3c9ef6f9eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 11, 13, "\ua5f2\udb95\udfb9\udabc\uddae\ud82f\udf40\ud948\ude24\ud8c9\udfae\udba3\uddf0\udbb8\ude8a\udbf5\udf12\udb02\udf08\uda9f\udf4d\ud99f\uded0", "\u995f\u0753\u0967\u31bd", "\udac5\uddcc\ud9d7\udfcc\uda24\udece\ud8ae\uddfd\ud9ca\udca7\udb71\udfa0",
        48, 82273, 667334354, -450376080886323077L, -19143L, false, true, (char) 26607, (char) 65,
        Double.longBitsToDouble(0x3fdb4a7aec3f2c04L), Double.longBitsToDouble(0x3fc63849ed669570L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 11, "\ua5f2\ud917\udc9a\udb6b\udd0f", "\u526a", "\ud844\udee2\udb02\udeb3",
        43, 78090, -574392432, -6926437791627647441L, 17733L, false, true, (char) 9483, (char) 36550,
        Double.longBitsToDouble(0x3fe9103d607d6380L), Double.longBitsToDouble(0x3fe70be0622142a7L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 4, 9, "\ua5f2\ud917\udc9a\ud9be\udca6\ud82f\udf40\ud948\ude24\ud8c9\udfae\udba3\udde9\udb82\udf9f\ub68a\udb02\ude7b\uda9f\udf4d\ud99f\uded0", "\u995f\u0753\u0967\u8cc1", "\ud83e\udf6e\ud801\udf00\udb6e\ude10\ud8ae\udeca\ud9ca\udca7\udb71\udfa0\udbec\udc62\ud941\udd9e\ud820\udd2a\udac0\udcf8\u6b83\ud9f7\udd9f\ud883\udd1f\udad3\ude63\udb5c\udc9e\ud8af\udf27\uda65\udcc6\ud9bf\uded7\udbc2\udf74\ud91e\ude7c\uda48\ude59\ud9ca\udc34\ud969\udeca\ud8b0\udead\ud8fc\ude94\udb2f\udf74",
        41, 6860, 1647921208, 2650383687330415218L, -80294L, false, true, (char) 61682, (char) 52958,
        Double.longBitsToDouble(0x3fe1fa2485555ed4L), Double.longBitsToDouble(0x3fe4f0deb533ec7eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 7, "\udb1f\udcfc\ud917\udc9a\udae5\udf3e\ud82f\udf40\ud948\ude24\ud8c9\udfae\udbeb\udee5\ud847\udc2f\ud983\udfbe\ud807\udcd4\uda9f\udf4d\ud99f\uded0", "\u995f\u7709\ub4d7\uc99c", "\ud86e\udcff\ud9d7\udfcc\uda24\udece\ud8ae\uddfd\ud9ca\udca7\ud9ee\ude50",
        36, 62668, 667334354, -450376080886323077L, -19143L, false, true, (char) 1063, (char) 33770,
        Double.longBitsToDouble(0x3fdb4e9a4c3f2d94L), Double.longBitsToDouble(0x3fc63849ed669570L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 1, "\ua354\ud917\udc9a\udae5\udfac\ud82f\udf40\ud948\ude24\000\000\udb82\udca0\u0773\udb02\udf08\uda9f\udf4d\u0e42", "\000\000\u00e5\u12b0", "\ud86e\udcff\ud9d7\udfcc\uda24\udece\ud8ae\uddfd\ud9ca\udca7\ud998\udd34",
        48, 3593, 0, 0L, -100000L, false, false, (char) 0, (char) 3016,
        Double.longBitsToDouble(0x3fedc1c9bc5f23e2L), Double.longBitsToDouble(0x3fd0000aec3f2c04L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 1, "\ua674\ud917\udc9a\udae5\udfac\ud82f\udf40\ud948\ude24\ud8c9\udfae\udba3\udde9\udb85\udd89\ud960\uddad\udb02\ude79\udad4\udd4d\ud99f\uded0", "\u3669\u0753\uc411\u377f", "\ud86e\udcff\ud9d7\udf84\uda24\udece\ud8ae\ude20\ud9ca\udca7\udb71\udfa0\uda55\udef8\ud941\udd9e\ud8d6\udec6\udb81\udec6\u6b83\ud9f7\udd9f\ud883\udd1f\udb47\udd9b\ud800\udfb0\ud879\udfbf\ud976\udedf\uda4d\udf2a\udbc2\udf74\u6d92\udaaa\udd0c\ud95f\udc04\ud907\ude55\udbf5\udd6a\ud881\udddb\ud9cd\udc43\ud8d6\udc33\uda23\ude3d\uda10\udcc4\ud991\udd9c\udb52\udddf\ud8ae\udf25\uda65\udd54\ud8d2\udc7a\ud942\udd69\ud866\udcb2\uda7b\udf7c\ud97c\udf95\udaef\ude3a\udabd\udfa0\udbd6\udd51\udb5d\udc37\ud8b8\udc28\ud8ee\uddec\udae7\udfa0\ud871\ude48\ud99d\udd4a\uc193\udbee\udec1\ud8bf\udc74\udb5c\udd9e\udb8c\udd97\udb2f\udf05\udaa9\udff0\udafd\udd65\ud9d6\udfa5",
        34, 58630, 453603642, -7700198384037233025L, -36693L, true, true, (char) 36236, (char) 37106,
        Double.longBitsToDouble(0x3feaff0f3900b4b7L), Double.longBitsToDouble(0x3fedb5adefccba77L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 10, 6, "\ud98c\udce9\ud9d5\udeff\ud8d1\udf3f\ud82f\udf9f\ud948\ude24\000\udba3\udde9\udb85\udd89[", "t\ud6a0\u1eb0", "\uda46\udf76\ud858\udc18\uda11\udcf0",
        56, 88546, -405200281, 47088118727633408L, -58770L, false, false, (char) 53943, (char) 14061,
        Double.longBitsToDouble(0x3fd6a89635c252aeL), Double.longBitsToDouble(0x3fe85271a0e27267L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 10, 11, "", "\u6b59", "\000",
        -5, 44585, 91, 2945846738008178176L, -100000L, true, false, (char) 40928, (char) 0,
        Double.longBitsToDouble(0x3e4c33c194000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 6, "\000", "\u755d", "\udba3\udde9",
        20, 76331, 685886454, 2141600159150290548L, -4397L, true, false, (char) 59249, (char) 7301,
        Double.longBitsToDouble(0x3fe9932fab2207a1L), Double.longBitsToDouble(0x3e33280000000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 4, 3, 6, "\ud812\udcec", "\u8905\u551d\u7712\u6518\u8e4e\ua776\u1114\u8939\ua004\u7631\u1eb0\u995f", "\ud858\udc18\ud8e0\udd58\ud853\ude3d\ud87e\udc28\uda70\udcfa\udac1\uddbb\ud93c\ude3c\ud87e\ude9f\udbaf\udd9f\uda47\udeba\udaa8\udcf2\ud820\udd2a",
        24, 43411, -1655805582, 1469660673154933725L, 87487L, true, true, (char) 9877, (char) 769,
        Double.longBitsToDouble(0x3feacd2ae3ef289aL), Double.longBitsToDouble(0x3fed6f2fdc413752L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 11, "\u798e", "\u6aa2\ud7e3\u526a\u6518\u76e3", "\ud961\udfc0\ud837\udef9\ud981\udd81\udb50\udef2\ud8f6\ude5d\udba4\udd8c\uda46\udf76\uda95\udf17\ud9e3\udf30\ud853\uddff\ud8eb\udd7f\ud8ba\ude7d\ud9ad\ude65\udb00\udd39\ud8e8\udf27\udba7\uddbe\uda6d\udd63\ud96b\uddbe\uda84\ude1f\ud94a\ude4e\udbbe\udcf9",
        13, 51805, 1108963949, -2565767595434536426L, 91802L, true, true, (char) 44600, (char) 7724,
        Double.longBitsToDouble(0x3fe00835a1116b7dL), Double.longBitsToDouble(0x3fe589313a09484eL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 12, "\ud9fb\ude09\ud811\ude7f\ud8d1\udf3f\ud8f2\uddb1\ud922\udca9\ud8bd\udf5d\udba3\udde9\udb85\udd89\u0773\ud808\udfeb\ud834\ude6d", "\u4e18\u050a\u00e2\ub711\u8c1c\u0658\uce37\u7748\u05c7\u558a\u1dfd\u6965\ud112\u2296\uadd1\u85f6\u813c\ud571\u0c79\u5af7\ub0bf\uced6\u7f98\u663f", "\ud91e\ude7c\uda20\udf59\udac2\udf0d\udbe0\udc73\uda77\udea9\ud8e5\udce3\udb47\udfc9\udb26\udd7d\udae0\udfba\ud9d9\udcad\ud8ef\ude86\uda6b\udf97\ud808\udcc4\udbff\udfed\udbbc\udf08\udbc2\udd22\ud844\ude2f\udbb3\udea6\ud9e9\ude26\ud9cf\udeb3\ud9d6\udcd1\ud93f\udc26\uda65\udc5f\u4e10\udb40\udc51",
        -3, 58462, -1898693758, 8147581398028917404L, -34578L, false, true, (char) 19865, (char) 54163,
        Double.longBitsToDouble(0x3fe39e4947cdce17L), Double.longBitsToDouble(0x3febedacc156a60cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 4, 4, 8, "\udbe5\udc6c", "\uc147\u642e\u4cff\uccd9\u08a9\u669f\u93c1\u3641\u5afc\u3866\ud68d\u40be", "\ud858\udc18",
        -5, 85271, -847199454, -4622430005238478235L, -93120L, true, true, (char) 41196, (char) 47246,
        Double.longBitsToDouble(0x3feab7d164c5811dL), Double.longBitsToDouble(0x3fbed5310b919b80L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 1, 0, 13, "\ua3ec", "", "",
        3, 4315, 178916585, 38075379686162592L, 77780L, false, true, (char) 30133, (char) 1552,
        Double.longBitsToDouble(0x3fe46df98c6276c6L), Double.longBitsToDouble(0x3fd7643463fdc45aL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 5, 5, 13, "", "\u16ec\ub813", "\udba3\udde9\udb85\udd66",
        -1, 80483, 487516699, -9146924693543422064L, -59742L, true, true, (char) 39605, (char) 5672,
        Double.longBitsToDouble(0x3fe0808c759179ffL), Double.longBitsToDouble(0x3fd22074c4cf9b00L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 6, "\uda2b\udd8e\ud828\ude03\ud8e1\udd2a\ud8d0\udfa7\ud8ad\udf6b\uda8c\ude65\udba3\udde9\udb85\udd89\u0773", "\ua004\u7631\u1eb0", "\uda46\udf76\ud824\ude6f\uda7a\udfdf\ud82f\ude1e\ud90e\ude30\ud87b\udf9e\uda34\udc68\ud937\udc93\ud87e\ude9f\ud873\udf81\uda6b\ude3e\udaa8\udcf2\ud820\udd2a\udb60\uddc3\ud979\ude71\ud83f\uddd4\udad2\udde5\ud837\udd5c\udb5c\udc9e\ud8af\udf27\ud945\uddd5\uda4d\udf2a\udbd8\udc99\ud91e\ude7c\udb12\udd31\uda1d\uddbd\ud95a\ude48\ud9cd\udc39\ud8e5\udcff\ud9b3\ude7e\ud996\udc59\uda6f\ude59\ua042\udbdd\udd5a\ud9d1\uddbe\ud91b\udc9a\udb58\ude56\ud965\uddd2\udb72\udd89",
        -3, 55715, 1125029762, -8627924060050964097L, 45576L, false, false, (char) 4437, (char) 29675,
        Double.longBitsToDouble(0x3fcfbf2acccecef8L), Double.longBitsToDouble(0x3fc5ccd0bab884dcL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 14, "\udbe5\udc6c\ud962\udc5e\ud96d\udf13\ud9e2\udcb0\ud98f\ude27\udbaf\udea8\ud8df\udc26\uda3d\ude48\udaa2\ude1d", "\u35df\u3787\u2b96\u8a32\u2dc5\uc5cd\u8c1c\u0658\uce37\u7748\u485f\u558a\u5fdf\u6965\ube0e\uc1ca\u95da\u4590\u813c\ud571\u0526\u134a\ub0bf\u23d6\u7498\u54a6\u24d3\ua8a4\uaf40\u957d\ud3d0\u623c\uc3bf\ub49f\u28f2\u8163\u7b63\ucab8\u6731\u4d44\u956a\u061a\u3f3e\u98e6\u833b\u9760\u9b52\u9a49\u6334\u39f0\u3a1f\u165a\u538a\u063f\ud69e\u0f06\ua9db\u3319\u9fe0\u4b2b\u2353\u3702\u4080\u44f2\u383e\u6f57\u9605\u7a69", "\ud8fd\udf1d\ud86e\udc24\ud81b\udd14\udb6d\ude87\uda10\udc80\ud8e1\udf2c\uc99c\ud869\ude26\ud81e\ude19\ud92a\udc02\udb13\udd3f\udbbc\ude16\ud94e\udfd3\uda4a\udc58\ud938\udc8b\ud920\ude58\uda0c\udca5\ud980\udf4c\uda5e\ude4f\ud971\udd34\udba0\udf78\ud898\udca2\ud852\udcd2\udb42\udef1\ud850\ude93\ud809\udcfd\udb8d\ude34\ud9c3\udedd\uda01\udde2\ud8b6\udd38\udabf\udd4e\uda83\uddea\ud8db\uddd0\udba0\udf99\ud9a0\udf08\ufe71\ud990\udc78\udbf0\udc31\uda7c\udd36\udb6b\udecc\udb18\ude5b\ud93e\uddfb\ud89c\udef7\ud92c\uded0\udad2\udd1a\ud96e\udd50\uda4d\udfc6\ud8c7\udcb9\ud9c9\udc4a\ud821\ude4d\udb53\uddaf\ud827\udf61\ud9d1\udedd\ud818\udc10\udb0d\ude91\udb06\udf32\ud816\ude60\udb5d\udcd5\udb79\udc4a\ud9af\udf10\ud9cc\udead\ud312\ud8e1\udead\ud8cb\uddcc\uda1a\uddee\ud9f6\udf16\udabb\udde2\udafc\udced\udaba\uddb1\uf06e\ud829\udc24\uda85\udd38\ud891\udf3d\u04b1",
        11, 93733, -851094953, -8780852848071916974L, 7405L, false, true, (char) 44183, (char) 17491,
        Double.longBitsToDouble(0x3fd3c0c1921997b6L), Double.longBitsToDouble(0x3fe3a3ad43cb4f40L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredArgs||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredOptions||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|getLongPrefix|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleConcatenatedOptions|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithoutEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleShortAndLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleUnknownToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isArgument|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isJavaProperty|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
