package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 6, "\udb89\udc20\udac8\ude31", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        26, 95929, 55082223, -7615609145630694107L, 37859L, false, false, (char) 50870, (char) 1704,
        Double.longBitsToDouble(0x3fe69909ea73eef8L), Double.longBitsToDouble(0x3fd6ee51656de880L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 6, "\udb89\udc20\udac8\ude31", "\u2ebd\ud1c1\u06bd\u933d\uc5d7", "\udb1a\udcc9\ud98b\ude97\udb8e\udfce",
        26, 95929, 55082223, -7615609145630694107L, 37859L, false, false, (char) 50870, (char) 1704,
        Double.longBitsToDouble(0x3fe69909ea73eef8L), Double.longBitsToDouble(0x3fd6ee51656de880L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 11, "\udb89\udc20\udac8\ude31", "\uac12\uc10c\u94fe\u9382\uc5d7\u65de\u372c\u673b\u36d3\u299b", "\uda03\udd20\u802f\udac2\ude39\u46f1\udbc7\udfa2\ud87a\udd0c\uda91\uddbd\ud9d6\udc76\ud8ae\ude12\ud859\udd45\udaf6\udcbc\u0ea9\ud9a6\udd63\ud990\udc53\uda8f\udf45\ud814\udfd6\ud98b\udf5b\ud949\udf77\ud869\udfb8",
        27, 80861, 924961529, 830408149629373990L, -66774L, false, false, (char) 30845, (char) 64081,
        Double.longBitsToDouble(0x3fe33d99c5207fafL), Double.longBitsToDouble(0x3fee7218e0fe428dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 6, "\uda8c\udf44\udb81\udf85", "\ud3ab\ucc59\u6ed5", "\ud840\udf8d\ud8c2\udcda\udb1a\udcc9\uda51\ude9a\udb9a\udece\ud824\ude20\uda1b\udf79\u9031\udb7f\udd68\ud8f5\udea4\uda48\udc47\udbc7\udfa2\ud8ff\udc15",
        21, 66449, 1996010195, -9196509517156140315L, 94848L, true, true, (char) 2953, (char) 15511,
        Double.longBitsToDouble(0x3fe86ce0fe18f01dL), Double.longBitsToDouble(0x3fe2b7b78755acd6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 10, "\udb89\udc20\udb43\udedf", "\u2ebd", "\ud9ad\udee5",
        14, 75983, 2067972563, 2654184626214266189L, -72449L, true, false, (char) 38515, (char) 35143,
        Double.longBitsToDouble(0x3fe1a5ef6e06be73L), Double.longBitsToDouble(0x3fe7516fb79437f6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 6, "\udb89\udc20", "\026\u2ebd\u1054\u94fe\u9382\u97ea\u2d6a\u372c\u727c\u9028\u299b\u095c\ua04f\u20d3\u00d5\uba4a\u3303\u2994\u7120\u2875\u0eca\u46a4\u8a8d\u4b81\u7880\ua98b\ub72c\u7304\u0a79\u5d36\u7b34\u94ef\u5885\ub9d1\uace8\u0697\u87a9\ua143\u08e9\ud712\u1f2c\ub20b\u64bc\u9211\uc574\ubf19\u91fc\uc624\u6b31\u203c\ud487\u2ac1\uac1e\u972b\u5d44\ub30d", "\ud9e8\udeec\udbd3\ude1a\udbd5\udec4\udb4a\udfc9\udae9\ude99\ud818\udcfd\ud9b4\ude1e\ud8be\uddae\uda68\ude55\uda10\udf85\udbe6\uded9\uda2c\ude0c\ud95b\udf13",
        28, 93078, 1084801316, 6600540447583879350L, 3514L, false, true, (char) 11834, (char) 10077,
        Double.longBitsToDouble(0x3fca05652ed74378L), Double.longBitsToDouble(0x3fc074be1ef9e608L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 16, 13, "\udb89\udc20\udac8\ude31\uda83\udc4c\udb6c\uddc2\udb23\udfb2\uda06\uddae\ud961\udc24\ud999\udc6c\ud99f\udc1c\ud840\udf8d\ud8c2\udcda\udb1a\udcc9\uda51\ude9a\udb8e\udfce\ud8b7\udf69\udbf6\udf91\uda03\udd20\uda05\udd9a\ud9e5\udd7c\udb1d\udd7e\udbc7\udfa2\ud87a\udd0c\uda69\udc29\ud9d6\udc76\ud82c\uddd2\udbfa\udcdc\udaf6\udcbc\ud9a0\udc77\udb21\udf5a\uda55\udc84\ud830\ude6f", "\u939d\u6a4e\u5d81\uc84d\u7e30\uae24\u01e6\u6303\ud1fe\u45e8\u1422\u0903\u2703\u14e1\u2ffd\u744c\ubd85\ub922\u0b4e\u1c2e\ub5c6", "\uda6e\udd49\udba6\udf88\ucfda\ud9ea\udcb6\uda21\udf60\ud80f\udf54\ud800\udee2\ud9a2\udf82",
        42, 77513, 1630737969, -2037015277835035632L, 6164L, true, false, (char) 61196, (char) 37906,
        Double.longBitsToDouble(0x3fdec9ae783b3162L), Double.longBitsToDouble(0x3fe40d692cebb363L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 16, 1, 6, "\ud8de\udde2\ud872\udc86", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        26, 95929, -1706525457, 3460648139536466891L, -52511L, true, false, (char) 54287, (char) 35179,
        Double.longBitsToDouble(0x3fd6ee51656de880L), Double.longBitsToDouble(0x3fe4ff47eeaefda4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 6, "\udb89\udc20\udac8\ude31", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        19, 95929, 55082223, -7615609145630694107L, 37859L, false, false, (char) 50870, (char) 37800,
        Double.longBitsToDouble(0x3feba109ea73eef8L), Double.longBitsToDouble(0x3fbbb94595b7a200L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 6, "\udb89\udc20\udba1\ude3e", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9",
        42, 25876, 855638016, 1838825518385364207L, -100000L, true, true, (char) 6511, (char) 32650,
        Double.longBitsToDouble(0x3fe3fc01be816027L), Double.longBitsToDouble(0x3fe69909ea73eef8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 6, 2, "\udb89\udc35\udb28\ude81", "\u1613\u6146", "\ud85d\uddab\ud95e\udf89\ud8d4\udea5\udb00\udec8\uda29\uded0\udb71\udf10\ud8b7\udf69\ud876\udd69\uda28\udde9\udb27\ude80\ud8c4\udcd6\ud802\udf56\udbc7\udf89\uf1a5\uda6b\udd2d\ud9d6\udc76\udb7e\udeda\udb94\udcda\ud83d\udf5d\ud98f\udcef",
        54, 26561, -1358526914, -6576469930101724997L, -15941L, false, true, (char) 17377, (char) 49875,
        Double.longBitsToDouble(0x3fe7fd54e3c46f80L), Double.longBitsToDouble(0x3fe9d9aad73b0fbeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 14, 6, "\udb89\udc20", "\026\u2ebd\u1054\u94fe\u9382\uc5d7\u65de\u372c\u427c\ub827\u299b\ud4e9\ua03e\uc544\000\000\000\u0f11\u4920\u2875\u95e6\u46a4\u8a8d\u4b13\u2ade\u6d7e\uacc5\u06d6\ua8ad\ub5a5\u1fd2\u73cc\u5927\u0783\ub3c2\u21f8\ua0f9\u77c8\u67d0\uc134\u9bd7\u6060\u712b\u2ab5\u6e53\u4be1\u375a\u7b63\ud1a3\u0460\u40d9\u500b\uaf5f\ube9b\ub77b\u1e98", "\ud95b\udec3\ud869\ude38\udacd\udfb1\ud864\ude62\ud84e\udd42\udacb\udc59\uda11\udda1",
        18, 94645, -1311574993, -926767348761260548L, -4196L, false, true, (char) 46637, (char) 58215,
        Double.longBitsToDouble(0x3fd61e0ec541a9a2L), Double.longBitsToDouble(0x3feefaf77afb05e4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 2, 16, 9, "\udb89\udc20\udac8\ude31", "\u2ebd\u69ce\u558b\u933e\uc5d7", "\udb1a\udcc9\udad9\udf5e\udb8e\udfce",
        26, 95929, 55082223, -7615609145630694107L, -27677L, true, false, (char) 60814, (char) 1704,
        Double.longBitsToDouble(0x3fe69909ea73eef8L), Double.longBitsToDouble(0x3fd6ee51656de880L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 6, "\udb05\udd24\udac8\ude8c", "\u4f43\u0c56\uc92e\u4408\ub994", "\udb1a\udcc9\uda91\ude9a\udb8e\udfce",
        22, 85298, 55082223, -7615609145630694107L, -24576L, false, false, (char) 18195, (char) 26359,
        Double.longBitsToDouble(0x3fe0dcc434870b5bL), Double.longBitsToDouble(0x3fe5867853029e2eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 14, 16, "\udb89\udc20\uda3c\udf4c", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udbdf\uddd5",
        0, 15281, 55096009, -7615609145630694107L, 47438L, false, false, (char) 50870, (char) 1704,
        Double.longBitsToDouble(0x3fee9909ea73ee00L), Double.longBitsToDouble(0x3fd6ee51656de880L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 1, 14, 6, "\udb89\udc20\udac8\ude31", "\u2ebd\u23e2\ub748\u9382\uc5d7", "\udadb\udf6d\ud9c9\ude5c\udb8e\udfce",
        7, 96073, 176770031, -1740489373881244379L, 37859L, true, true, (char) 32217, (char) 17703,
        Double.longBitsToDouble(0x3fe69909ea73eef8L), Double.longBitsToDouble(0x3fd6ee51656de880L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 0, 11, "", "\000\000\u2ebd^\u0c1c\000\uc5d3\u656a\uc1d3\000\ub028\ua800\000\000\000\000\000\u8589\u2994\000\u2875\u0eca\000\000", "\udbc9\udebc",
        39, 25050, -1696000379, 3495349965693698430L, 5617L, false, false, (char) 34218, (char) 43516,
        Double.longBitsToDouble(0x3fddf7f71c2a29caL), Double.longBitsToDouble(0x3fdaa2bebc8f1afaL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 6, 6, "\ud88f\udcf5\udac8\ude31", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        26, 95929, 55082223, -7615609145630694107L, -52511L, true, false, (char) 54287, (char) 35179,
        Double.longBitsToDouble(0x3fd6ee51656de880L), Double.longBitsToDouble(0x3fec23afc74f88f5L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 16, "\udb89\udc20", "\u89b8\u2ebd\u1054\u94fe\ucb95\u3447\u65f6\u9f4e\u736a\ua8ef\u299b\u095c\u9af9\u8470", "\u46f1\udbc7\udfa2\ud87a\udd0c\uda69\udc29\ud9d6\udc76\ud921\uddcc\ud840\udca6\uda22\udf6b\ud9f8\uddee\ud9f0\udcd3\ud94d\ude29\ud923\udd07\ud951\udd97\ud9d8\udf76\ud9d3\udcf1\ud852\udd0f",
        34, 69567, 306508099, -7442902584569716828L, -62645L, false, false, (char) 53559, (char) 61926,
        Double.longBitsToDouble(0x3fd1c4164ec3842eL), Double.longBitsToDouble(0x3fe851ec5b742ca1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 14, 5, "\udb89\udc20\udac8\ude31", "\u1c7d\ua320\uc6a4\u937b\uc5d7", "\udb1a\udcc9\udbd7\udd1e\udb2c\uddf2\ud8b7\udf69\udbf6\udf91\uda03\udd20\uda00\ude9a\udac2\ude39\u46f1\uda89\udd88\ud87a\udd0c\uda69\udc29",
        14, 97843, -451503487, -846569603499141194L, 49811L, false, true, (char) 58902, (char) 64914,
        Double.longBitsToDouble(0x3fdb417c2f4ae30eL), Double.longBitsToDouble(0x3fdf3f2a5e6f2476L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 15, 14, 12, "\udb89\udc20\udac8\ude31", "\u2ebd\u309f\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce\ud8b7\udf69\udbf6\udf91\uda57\ude8a",
        32, 16733, 418153849, 6266225079331334036L, 8161L, false, false, (char) 35179, (char) 18053,
        Double.longBitsToDouble(0x3fe5b7a206dbf072L), Double.longBitsToDouble(0x3fdd7a67c78e5704L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 12, 6, "\udb89\udc20\udac8\ude31", "\u2ebd\u6983\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        26, 95929, 2014674159, -7615609222940105435L, 37859L, false, false, (char) 20918, (char) 47536,
        Double.longBitsToDouble(0x3fe6992e4273eef8L), Double.longBitsToDouble(0x3fd6ee51656de880L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 6, "\udb89\udc20\udac8\ude31", "\u5276\u1871\u94ea\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        26, 95929, 55082223, -7615609145630705584L, 37859L, false, true, (char) 51047, (char) 1704,
        Double.longBitsToDouble(0x3fe69909ea73eef8L), Double.longBitsToDouble(0x3fd6ee516457e880L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\udbd6\udfdb\udac8\ude31\ud898\udd57\uda7e\udf28\ud8f3\udcfb\uda22\udf64\ud8e6\udf88\udab2\udc9e\ud8c8\udcf2\uda6c\ude57\udbc1\uddb4\udb9d\udf85\udb7b\udc24\uda40\udd41\uda6d\ude63\ud96f\udf62\ud891\udc62\ud88b\udfa5\ud98e\udd93\udbe7\udcc3\udbc7\udf8a\uda06\udd01", "\u1a54\u8f9b\u3d40", "\uedf7\ud943\udc1f\uebb2\ud889\udcfe\udadf\udc54\udb4a\ude70\ud8d4\ude23\ud88e\uddc1\ud87b\ude39\ud9f3\udf10\ud874\udd37\udaaf\udc10\ud8a0\ude2f\udbb3\udf46",
        39, 69373, -1971227123, -634996507603517609L, -64426L, false, true, (char) 32258, (char) 49860,
        Double.longBitsToDouble(0x3fd8d7b47fb264f2L), Double.longBitsToDouble(0x3fdfce3d349b6808L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 13, 8, 11, "\udb89\udc20\udac8\ude31", "\u2ebd\u1054\u94fe\u243b\uc5d7", "\udb1a\udcc9\u6c7a\udaf6\udfe1",
        24, 95929, -1889239824, -7615609145697802971L, 37859L, false, false, (char) 50870, (char) 1704,
        Double.longBitsToDouble(0x3fe69909ea73eef8L), Double.longBitsToDouble(0x3fd6ee51656cdb0aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 12, "\udb89\udc20\udba1\ude3e", "", "\ud8e6\udf88",
        27, 85652, -1395509132, 8593644149210189550L, -46223L, true, false, (char) 61212, (char) 64372,
        Double.longBitsToDouble(0x3fd79ce7750631d8L), Double.longBitsToDouble(0x3fc28aded9fe00dcL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud9f3\udc13\udbd2\udf14", "\uc5a1\u1054", "\udbf2\udcbd\ud840\udf8d\uda8f\udf83\udb1a\udcc9\uda51\ude9a\udb70\udc84\ud81c\udcf8\ud9ff\udd8c\ud916\ude4d\udbb0\udcf6\udabc\udc5d\udbc9\udc0d\udbd0\uddb5\ud9aa\udc18\ud9ba\udc1a",
        20, 16488, -446116889, 4077674583200039038L, -90378L, false, true, (char) 6488, (char) 9110,
        Double.longBitsToDouble(0x3fba4940ac89b148L), Double.longBitsToDouble(0x3fd6a79ab4e021d0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 11, 14, "\udb7d\ude38\udac8\ude31\udb8e\udc73\uda62\udc1c\ud9ea\ude38\uda15\ude50\ud858\ude0e\udae3\udc1f\ud8c8\udd27\uda5e\uddd9\udb65\udc04", "\uc949\u09c1\ua0e0\u1e01\u4e8f\ud360\u3303\u2994\u1c17\u41ca\u732b\u46a4\ud457\u41ba\ub42e\u5bb0\u0689\u09a1\ub4a6\u08e6\uba75\ua927\u137c\u229e\u2cd8\ua3f2\u2eee\u086d", "\udb41\ude0c\udaee\uddb4\ud87f\ude6d\ud956\udfc7\udbe5\udfdf\ud82b\udc7e\udb0f\udfe0\udbbc\ude72\udb87\ude22\ud8f0\udc23\ud828\udf2e\udade\udc2c\ud9e7\ude78\ud93a\udce1\udb39\udd8a\udbc9\udcf9\ud996\uddbb",
        36, 59482, 558842065, 8570687118662156160L, 68216L, true, false, (char) 10732, (char) 17730,
        Double.longBitsToDouble(0x3fe0e91cf3874a5fL), Double.longBitsToDouble(0x3fdf9b13af80859eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 4, 8, 2, "\udaff\uddda", "\026\u2e74\u208e\u4e3c\u5e95\u1a5c\uc626\uca03\u7351\ua8ef\u299b", "\ud8b6\udc6c\ud82c\uddc8",
        52, 12849, 1458969219, -1857971703533541495L, -54221L, false, false, (char) 63438, (char) 44171,
        Double.longBitsToDouble(0x3fef3ebce416d198L), Double.longBitsToDouble(0x3fa1666c072c2530L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 4, 15, 4, "\udb89\udc20", "\ubd1a\uac12\uc10c\u2170\u9382\uc5d7\u6889\u372c\u673b\u36d3\u299b\u095c\ua04f\u20d3\uc7d9\uba6f\u3303\u2994\u7120\ud032\u95e6\u1c92\ubf31\ua029\ua1f0\u13a0\u2326\u2556\ua8f1\ua6d0\u22aa\ud163\uab0b\u39f9\ua450\ub7fc\u1ded\u4b48\u04f7\uca05\uc597\ucbf9\u49bc\u1caa\u6aae\u5222\uc161\ua34f\u3eca\u9de6\u1e91\u6746\u67ce\uc2fb\ub29a\uba09", "\udb05\ude92\udb44\ude9c",
        40, 58319, -903095454, 5672202517477037979L, 81467L, true, true, (char) 61876, (char) 1821,
        Double.longBitsToDouble(0x3fd28bb09457dc46L), Double.longBitsToDouble(0x3fc46e2b72c76decL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 2, "\uda44\udfb1\udac8\udeb3\udbd4\uddfc\udaa1\ude59\ud8d6\udebd\udaf0\udf6d\ud8e6\udf88\udad3\udd38\ud8c8\udcf2\ud9ec\udc2c\ud923\udd44\udb88\udc12\uda35\udc7e\ud8f5\udcc0\udb37\udf58\udbfa\ude65\uda03\udd20\ud902\udce0\ud9d4\udc24\udb91\udf1b\udbc7\udfd9\ud87a\udd0c\uda91\uddbd\ud9d6\udc76\ud8ae\ude12\udb8f\udfe1", "\u13a0\u2326\u2556\u0523\uce5a\u22aa\ud163\uab0b\u39f9\u5d1b\u497d\u5e25", "\udaf5\udfd2\udaab\udda2\udbfb\udd6b\udb4a\udc35",
        43, 88950, 1945776382, 5850782155932309339L, 78814L, false, false, (char) 50966, (char) 61509,
        Double.longBitsToDouble(0x3fec4d396118e94cL), Double.longBitsToDouble(0x3fde9b1d737a171cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 16, "\udb89\udc20\udac8\ude31\udbd4\uddfc", "\uc10c\u94fe\u9382", "\ud8c2\udcda\udb88\udc12\uda35\udc7e",
        41, 65641, 428134929, 236576346728535794L, -63830L, false, false, (char) 41800, (char) 38779,
        Double.longBitsToDouble(0x3fe8b49de480c8dbL), Double.longBitsToDouble(0x3fc1c60f6c1fb61cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 1, 5, 6, "", "", "\ud953\udf6d",
        24, 91627, 927964067, 2200193048622501727L, -100000L, true, true, (char) 36329, (char) 37890,
        Double.longBitsToDouble(0x3fe000039cef1984L), Double.longBitsToDouble(0x3fcfe8090002f7b4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 16, 13, "\udbb1\udc20\udac8\ude31\uda83\udc4c\udb6c\uddc2\udb23\udfb2\uda06\uddae\ud961\udc24\ud999\udc6c\ud99f\udc1c\ud840\udf8d\ud8c2\udcda\udb1a\udcc9\uda51\ude9a\udb8e\udfce\ud8b7\udf69\udbf6\udf91\uda03\udd20\uda05\udd9a\ud9e5\udd7c\ud809\ude79\udbc7\udfa2\ud87a\udd0c\uda69\udc29\ud9d6\udc76\ud82c\uddd2\udbfa\udcdc\udaf6\udcbc\ud9a0\udc77\udb21\udf5a\uda55\udc84\ud830\ude6f", "\u939d\u6a4e\u5d81\uc84d\u7e30\uae24\u01e6\u6303\ud1fe\u45e8\u1422\u0903\u2703\u14e1\u2ffd\u744c\ubd85\ub922\u0b4e\u1c2e\ub5c6", "\ud8cc\udf05\ud9cc\udcde\ucfda\ud9ea\udcb6\uda21\udf60\ud80f\udf54\ud800\udee2\ud9a2\udf82\u910c\udb61\udc84\ud97c\udfeb\ud9ef\udfbb\udbe7\udff8\u62d1\ud95a\udded\uda26\udf59\ud8aa\udf3d\udb25\udfe2\ud9cc\udfd5\u573b\ud885\uddfd\uda75\udf3e\udae8\udd71\ud921\ude20\ud841\udebf\u8cbd\uda29\udf66\uda48\udd00\ud8f7\uddf5\udb54\ude00\udb2a\udd57\ud917\udf93\ud90d\udc21\u1c53\udabc\udebe\udbc0\ude37\ud87f\ude65\ud845\udd8a\u8560\ud8f9\ude6b\udbb2\udd8d\udb7c\ude0a\ud931\udcfc\ud95c\udede\uda3d\ude08\ue613\udad9\udffd\udbba\udd97\udb64\udfcd\ud91b\udfdf\udb25\uddf2\ud977\uddb6\uda03\udf98",
        48, 86803, -1201635529, -7126361233970519063L, 79470L, false, true, (char) 7374, (char) 30418,
        Double.longBitsToDouble(0x3fc9f4e9637f51fcL), Double.longBitsToDouble(0x3fca0dbca12f5b64L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 9, 6, "\ud8de\udde2\ud872\udc86", "\u2ebd\u1054\u05e4\u7840\uc6ae\u65de\u372c\u736a\u1d93\u31aa\u62b5", "\uda16\udffa\ud9b0\udc7b\udbca\udf44\udb9d\udc2e\ud8a9\udcf5",
        42, 66547, -285691181, -1939192771021610642L, 84044L, false, true, (char) 35225, (char) 24796,
        Double.longBitsToDouble(0x3fe9cf1de85a2275L), Double.longBitsToDouble(0x3faa35b4653517d0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 8, 1, "\ud8de\udde2\ud872\udc86\uda83\udc4c\uda8b\ude83\ud953\udf6d\uda92\udca5\ud8e6\udf88\udad3\udd38", "\u8c55", "\ud986\udc36",
        1, 96125, -1706525457, -493135198050743630L, -85706L, true, true, (char) 36662, (char) 25254,
        Double.longBitsToDouble(0x3fe3e1232a73eef8L), Double.longBitsToDouble(0x3fbb9c058db293f0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 16, 9, 0, "", "", "\u00be",
        -5, 55192, 451189667, 2305843024998054004L, 2126L, false, false, (char) 36292, (char) 19300,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e38000000000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 16, 1, 6, "\udb94\ude7c\ud9bb\udcfe", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        26, 95929, -1706525457, 3460648139536466891L, -52511L, true, false, (char) 54287, (char) 35179,
        Double.longBitsToDouble(0x3fd6ee51656de880L), Double.longBitsToDouble(0x3fe4ff4550aefda4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 10, "\ud8de\udde2\ud872\udc86", "\u2ebd\u1054\u94fe\u9b82\u81b1", "\udb1a\udcb8\ud817\uddbc\uda02\udeac\ud897\udf76\ud966\ude6c\udbcc\ude6b\udbb7\udc2c\uda5a\udc97\udbe2\udda6\ud8fa\udcf9",
        48, 13726, 567715555, -1273467755960034701L, -12410L, true, false, (char) 44088, (char) 12530,
        Double.longBitsToDouble(0x3fd84dad434b8066L), Double.longBitsToDouble(0x3fdb245a50717448L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 10, 4, "\ud8de\udde2\ud872\udc86\uda83\udc4c\udbd6\udecb\ud845\udd3f\uda22\udf95\ud83e\udcb4\udbbe\ude60\ud983\udd13\ud817\udd98\udb57\udf51\ud8db\udd21", "\u574c\u461b\u1dd1\ua211\u53e2\u8912", "\uda11\udc14",
        7, 45831, 2062874142, -2812721872913993034L, 31615L, true, true, (char) 18756, (char) 63490,
        Double.longBitsToDouble(0x3fe02b4038d079afL), Double.longBitsToDouble(0x3fe84dbe66a035b9L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 5, 15, 5, "", "\u202c\u6d9a\u57ff\u4f5e\uc0b2\u9382\uc5d7\u65de\u1172\u736a\ua8ef\ua81c\u53f1\ua04f", "\udac2\ude39\u46f1\udbc7\udfa2\ud8d2\udc97\uda57\uddaa\000\000\000\udbd5\udf4a\ud883\ude48\ud8a9\udedf\ud8ad\udc12\ud9a3\udf9a\ud889\udd28\ud893\udd1a\uda9a\udc12\uda26\udcec",
        36, 62885, -1956104837, 3912090280143754928L, 75386L, false, false, (char) 31420, (char) 27710,
        Double.longBitsToDouble(0x3fc5b535ed0b58c8L), Double.longBitsToDouble(0x3fcb05d4738db964L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 14, 6, "\u3824", "\026\u2ebd\u1054\u0c67\u9382\uc5d7\000\u1d0a\u427c\ub827\u299b\ud4e9\ua03e\uc544\000\000\000\u0f11\u4920\u2875\u95e6\u46a4\u8a8d\u4b13\u2ade\u6d7e\uacc5\u06d6\ua8ad\ub5a5\u1fd2\u73cc\u5927\u0783\ub3c2\u21f8\ua0f9\u77c8\u67d0\uba6c\000\u6060\u712b\u2ab5\u6e53\u4be1\u375a\u7b63\ud1a3\u0460\u40d9\u500b\uaf5f\ube9b\ub77b\u1e98", "\ud95b\udec3\ud869\ude38\udacd\udfb1\ud864\ude62\ud84e\udd42\udacb\udc59\uda11\udda1",
        18, 94645, -1311574993, -926767348761260548L, -4196L, false, true, (char) 46637, (char) 58215,
        Double.longBitsToDouble(0x3fd61e0ec541a9a2L), Double.longBitsToDouble(0x3feefaf77afb05e4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 6, "\udb89\udc20\udac8\ude31", "\u2eac\u23e2\u4d2f\u8610\u4707", "\udadb\udf6d\ud800\uded7\ud8d2\udc12",
        37, 96073, 176770031, -1742459696537180917L, -36893L, true, true, (char) 32217, (char) 17703,
        Double.longBitsToDouble(0x3fe69909ea73eef8L), Double.longBitsToDouble(0x3fd6ee516e03ae02L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 2, "\udbab\udfd1\udac8\ude31\ud840\udc7f\ud892\ude76", "\uab86\u06c5\ubc1f", "\uda48\udeac",
        53, 39359, 1198780176, 1851773985911032815L, -60357L, true, true, (char) 13167, (char) 4147,
        Double.longBitsToDouble(0x3fc409a73afe79a0L), Double.longBitsToDouble(0x3fe69909ea5ceef8L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 2, 2, 6, "\ud88f\udcf5\udac8\ude31", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        42, 95929, 55082223, -7615609143175846619L, -52511L, true, false, (char) 54287, (char) 35179,
        Double.longBitsToDouble(0x3fd6ee51656de880L), Double.longBitsToDouble(0x3fe89dffc74f88f5L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 16, "\udb89\udc20\ud858\udd2b\uda7d\udc5a\u5037\ud897\udec5\ud9ca\udfd9\ud8e6\udf88\udad3\udd38\ud8c8\udcf2", "\u3393\u467c\u299b\u095c\u0638", "\udadb\udf39",
        1, 50376, -2144305453, 6928584064163667073L, -8467L, false, true, (char) 26359, (char) 13646,
        Double.longBitsToDouble(0x3fdd7a67cb8e5704L), Double.longBitsToDouble(0x3fe5af731e9f70c5L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udbd6\udfdb\udac8\ude31\ud898\udd57\uda7e\udf28\ud8f3\udcfb\uda22\udf64\ud846\ude78\udac7\udd82\ud8c8\udcf2\uda6f\udf01\udbc1\uddb4\udb9d\udf85\udb7b\udc24\uda40\udd41\uda6d\ude63\ud96f\udf62\ud891\udc62\ud93f\udff1\ud98e\uddef\udbe7\udcc3\udbc7\udf8a\uda06\udd01\udb81\ude74\ud9ba\udf10\ud821\udd82\u1e9e\udb07\udf40\uf8c4\udabf\ude89\uedf7\ud943\udc1f", "\u87b6\u6966\uc5a7\ub39e\u829f\ucdad\u3301\u9a68\u9626\u5815\u5957\u35d2\u9acb\u2f98", "\udbbc\ude19\ud948\uddad\udb64\udd36\ud947\udefd\ud98e\ude1a\udb4c\uddeb\ud9d5\udc86\uda7d\ude2e\udaac\udd81\ud878\udfce\ud85c\ude9c",
        59, 69436, 1561532780, -4198461250602899460L, -7786L, false, false, (char) 56894, (char) 45629,
        Double.longBitsToDouble(0x3fdd10d7dfda5984L), Double.longBitsToDouble(0x3fd2288daf1c14d8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 13, 14, "\udb7d\ude38\udb0c\udca6\udb6b\udda2\ud9ab\udf22\udab2\udecd\ud892\udf7a\ud87c\ude8b\udae3\udc1f\ud8c8\udd27\ud88f\uddd0\udb65\udc04", "\uc949\u0a2c\ua0e0\u5860\u4e8f\ud360\ua663\u29a9\u1c17\u41ca\ub22b\u46a4\ud457\u7246\ub426\u5bb0\u0689\u09a1\ub4a6\u08e6\uba75\u0f5c\u74da\ubad5\u2cf1\ua3f2\ub2ed\uc8c8", "\udb4c\udea8\udaee\uddb4\ud87f\ude6d\ud956\udfc7\ud81d\udc4a\udb3c\ude3d\udb0f\udfe0\udbbc\ude72\udb87\ude22\ud8f0\udc23\ud828\udf2e\uda25\udfa1\ud9d1\udc7a\ud93a\udce1\uda4f\udefc\udbc9\udd86\udba5\udde4\ud9ce\uddd5",
        7, 8065, 1995518598, 7268797154956010421L, 97703L, false, true, (char) 11830, (char) 56523,
        Double.longBitsToDouble(0x3fc23833548c79f8L), Double.longBitsToDouble(0x3fd2f42cf217c810L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 2, "\uc3d5", "\u52e6\u3f46\u2447\uab86\u06c5\ubc1f\u1845\000\000\ub7ff\ub382\u9baf\u3916\ub86b\u8b23\uba6f\u3303\u2994\u2cc4\u04f5\u9624\u46a4\u1e86\u689d\uc31e\u0dbc\uadec\u7124\uc30a\u7fca\u49d4\u3d0e\ubc17\u729a\u22b6\ubdee\u056e\u278d\ub82d\u34bc\u932c\u54f9\u0206\u322b\u0790\u0a43\u4719\u7c0a\u37fd\u255b\u6782\u4aec\u7998\u961b\u03d9\u22ee", "\ud99c\udc9d\udbd7\udf5e\ud907\udcc8\udac0\udd0f\uda96\udf72\udba9\uddb2\ue0f9\ud818\udfb6",
        41, 1973, -72033040, 1245322694438091780L, 48513L, true, true, (char) 10703, (char) 49772,
        Double.longBitsToDouble(0x3fca07841b3c4a58L), Double.longBitsToDouble(0x3fe2d15b0878fe27L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 2, "\uc3d5", "\u52e6H\u2447\uab86\u00a3\ubc1f\u1845\000\000\ub7ff\ub382\u84ae\u3916\u6d6b\u8b23\uba6fy\000\u4b86\u04f5\u9624\u46a4\u1e86\ud69d\000\u0dbc\uadec\u7124\uc30a\u7fca\u49d4\027\000\u729a\u22b6\ubdee\u056e\u278d\u1d30\u3471\u932c\u54f9\u0206\u322b\000\ud46f\000\u084c\u37fd\u6806\u672d\u4aec\u7998\u961b\u03d9\u22ee", "\000",
        -3, 50719, 16353537, -1572982517601913307L, 92115L, true, false, (char) 45936, (char) 46602,
        Double.longBitsToDouble(0x3fe32fdda4001148L), Double.longBitsToDouble(0x3feb3c05b000009cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 6, "\udb7b\udd20\uda4a\udc52", "\u2e9a\u1054\u94fe\u9382\uc5d7\u6f4e\ud7a2\u736a", "\ud8b7\udf69\udbf6\udf91\ud85d\udf4e\ud8a0\ude8e\udabc\udfdc\u46f1",
        14, 57220, 1613186687, 2395253649526272723L, 54089L, false, true, (char) 8583, (char) 50920,
        Double.longBitsToDouble(0x3fedfc8c00150d27L), Double.longBitsToDouble(0x3fede969ff71fb38L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 2, 16, 9, "\udb89\udc20\udac8\ude31\uda83\udc4c\uda62\udc1c\ud953\udf6d\ud8ba\ude25\ud913\udf66\udad3\udcf4\ud8c8\udcf2\ud840\udf8d\ud8c2\udcda\udb1a\udcc9\udad9\udf5e\udb8e\udfce\ud8b7\udf69\udbf6\udf91\uda03\udd20\uda05\udd9a\ud9a4\udf1b\udbb2\udc85\ue216\ud8b1\ude07\ud870\udfab\ud9ea\udf27\ud82c\uddd2\u27dd\udaf6\udcbc\udbd8\udeb3\ud802\uded5\ud8a3\udee5\udb94\ude55\ud89b\udcd7\uda23\ude4a\udae4\udd8d\udafc\udcf9\uda16\uddc5\ud887\udcf5\ud8e5\udc1a\uda16\udd8c\udbe3\udd55\udb83\udfdf\ud829\udfcc\ud8ea\ude79\udb63\udd84\uda69\ude5e\udbdb\udf47\udb2c\udda5\udad0\udef7\uda59\udde0\ud8b4\udc64\udaaf\udd8b\u0b31\ud958\udefe\ud965\udda7\udaca\udf74\ud819\udd74\udb84\udfdc\ud95a\uded0\uda86\ude14\udaa2\udf50\udbe8\udcbf\udb3a\udece\uda34\ude6b\uda17\uddb6\udb82\udd19\ud842\udf12\ud926\udfed\uda1a\ude5e\ud978\udc5a\udbfd\ude95\udbb1\udd53\uda50\udc2b\uda34\udf09\ud8e5\udef3\ud907\udd07\uda9e\ude8a\ud8e8\udfbf\ud91c\udd6b\ud8b0\udffc\ud89d\ude79\uda1e\udee6\uda73\udd4f\ud877\udce0\ud8f2\ude6c\udb2c\udd71\ud8a6\udd87\uda5b\udddf\udb55\udf5a\udbdb\ude42\ud94b\udc98\ud896\ude80\ud945\udf7c\ud8fa\udfc6\ud83f\ude28\udb4b\uded7\u7a6c\u7944\ud9e9\uddcd\u34b5\udbc3\ude88\udb14\udfae\udb22\udcfc\udb10\udecb\udb8d\ude43\uda92\udf53\ud98f\udc6d\udaa9\udf66\uda41\udc57\udb20\uddf7\udba5\ude01\ud955\udf93\udb79\udfeb\udbf8\ude71", "\uc18c\ub310\u1fcc\u6cc9\u95b2\u1561", "\ud83a\udf03\uda56\udeb9\u8869\ud9b2\udd71\udab8\udc55\ud95a\udddb\udba7\udf23\udbc8\udd3d\ud97b\ude1e\ud8f7\udcbc\ud9e8\udec7\udbb9\udc13\udb19\ude57\ud810\udd6e\ud91e\udf42\uda2c\udf8c\ud975\udd4d\udaed\udc67\ud90f\udfb5\uda38\ude5b\ud924\ude20\udb9b\udce2\udb83\udcd7\ud9ec\udc76",
        46, 10691, -950869131, 3228557311509373496L, 78810L, true, true, (char) 22602, (char) 59440,
        Double.longBitsToDouble(0x3fe8068a6d9b5f22L), Double.longBitsToDouble(0x3f7158a6c3236380L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 5, 5, 2, "\uc3d5", "\u52e6\u3f46\u2447\uab86\u06c5\ubc1f\u1845\000\000\ub7ff\ub382\u9baf\u3916\ub86b\u8b23\u6db2\000\000\000\u04f5\u9624\u46a4\u7e82\u689d\uc31e\u0dbc\uadec\u7124\uc30a\u7fca\u49d4\u3d0e\ubc17\u729a\u22b6\u00ce\000\000\000\000\000\000\ub9a6\u98a8\u0790\ud46f\u4719\u7c0a\u37fd\u255b\u6782\u4aec\u7998\u961b\u03d9\u22ee", "\ud99c\udc9d\udbd7\udf5e\ud907\udcc8\udac0\udd0f\uda96\udf72\udba9\uddb2\ue0f9\ud818\udfb6",
        41, 1973, -72033040, 1245322694438091780L, 48513L, true, false, (char) 0, (char) 4864,
        Double.longBitsToDouble(0x3fca07841b3c4a58L), Double.longBitsToDouble(0x3fe2d15b08000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 4, 4, 6, "\udb89\udc20", "\uca1b\u2eac\u7974\u0f4e", "\udba9\udc46\ud998\ude22\ud99f\udc52",
        59, 60754, 1198721028, 8040564299824674572L, 4437L, true, true, (char) 33215, (char) 8335,
        Double.longBitsToDouble(0x3fa40b4cabf9e680L), Double.longBitsToDouble(0x3f7d1f5327af1e80L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 16, 1, 6, "\ud8de\udde2\ud872\udc86", "\u2ebd\u1054\u94fe\u9382\uc5d7", "\udb1a\udcc9\uda51\ude9a\udb8e\udfce",
        26, 95929, -1706525457, 3460648139536466891L, 62408L, false, false, (char) 22712, (char) 41829,
        Double.longBitsToDouble(0x3fe2a48797ca6908L), Double.longBitsToDouble(0x3f9d0fe408604440L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredArgs||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredOptions||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|getLongPrefix|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleConcatenatedOptions|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithoutEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleShortAndLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleUnknownToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isArgument|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isJavaProperty|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
