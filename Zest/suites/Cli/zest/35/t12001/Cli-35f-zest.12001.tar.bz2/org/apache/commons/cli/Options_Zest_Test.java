package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Options_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7c9a\u3fe3\uc1c8\u9dad\u5f66", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        17, 19253, -1125744537, -3076112774013690193L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3fe8e34955d51188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\uda08\ude25", "\ub84e\u0dc2\u711a\u5c7d\u9eb8\u7874\u5f66\u1749\u6bf0\u284e\u6ced\u9e48", "\uda23\udc5f\uda30\udcf0\udab7\udc72\udbd4\udd36\ud90f\udcca\udb0b\udf88\ud839\udf8e\udbf6\ude68",
        41, 46702, 294184732, -682693549692874045L, 31110L, false, true, (char) 60428, (char) 16461,
        Double.longBitsToDouble(0x3fe2b77c67978b6fL), Double.longBitsToDouble(0x3fd5d4ae2b2cc714L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 11, 1, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7c9a\u3fe3\uc1c8\u9dad\u5f66", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        17, 19253, -1125744537, -3076112774013690193L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3fe8e34955d51188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\ua2bb\u21af\u7c9a\u3fe3\uc1c8\u33ad\u5f66", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        17, -763, 0, -539009361L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3fe8e00150000088L), Double.longBitsToDouble(0x3e4d800000000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 13, 1, 14, "\ud8d4\udf76\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\ucaeb\u7c9a\u2ada\uc1c8\u9964\u5f66", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\udafd\udefd\ud9df\udd90\ua3a4\udab7\udc72\udbd4\udd36\ud90f\udcca\udb0b\udf88\ud839\udf8e\udbf6\ude68\uda4a\udf18\uda5e\udef0\uda0c\udc24\ud809\udd46\udab9\ude62\ud8ae\udced\ubf23\uda3b\ude4a",
        15, 27505, 1551950506, -7378549218280367125L, 18199L, true, true, (char) 52586, (char) 35415,
        Double.longBitsToDouble(0x3fe6201a61794d9aL), Double.longBitsToDouble(0x3fd1ecdd487d220cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 13, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\u1325\u114a\u644c\u70ee\u2b03\u9dad\u5f66", "\uda9b\udf5a\uda4c\udcc6\udaec\udc4a\ud975\udd88\ud9b5\ude58",
        1, 19253, -1125744537, -3076112772784496977L, 79417L, true, true, (char) 20108, (char) 63035,
        Double.longBitsToDouble(0x3fe8e2d20f1b1188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\u93d4\ud964\udc67\ud90a\udd4c\udbbf\udf9f", "\uc72c\u2288", "\ud93b\udda9\ubd88",
        36, 60628, -2066198458, 6202652703678498826L, 68914L, true, true, (char) 34923, (char) 62508,
        Double.longBitsToDouble(0x3fe20eaa7a15dfc5L), Double.longBitsToDouble(0x3fd26d4c42dad96cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 15, "\ud8da\udc13\ud841\udf0c\udb34\udc2e\ud96c\udf66", "\ub8ee\ua792\u1cb7\ub8cf\ub2bc\u1699\ud049", "\ud944\uddcb\uda7e\udef0",
        35, 5819, -1665147180, -8034302788407879187L, 66981L, true, false, (char) 40917, (char) 28100,
        Double.longBitsToDouble(0x3fd6d6cb633111e8L), Double.longBitsToDouble(0x3fc7c32fdc71a4a8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 0, 0, 15, "\000\ud9f6\udc5a\uda16\udd00\udb95\ude08", "\uc72c\u97ae\u7c9a\u3fe3\uc1c8\uc4ce\u5f66", "\000\ud85c\udc0d\000\000\000",
        36, 38405, 0, -3098476544169910609L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3f3a4aaea88c4000L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 11, 12, "\ud852\udcb1\ud88f\udfa8\uda16\udd00\udae6\udeb0", "\uc72c\u0366\ua787\u41d6\u8445\u9dad\u95cb\u1723\u3b59\u7e5e\u3082\u9ea4\u70b3\ua82e\ubc0a\ubf1a\ua852\ub755\u8110\uaf1f\u01ff\u8c54\uafce\u2163\u3be4\ud70b\u4bca\u06c7\ud494\ub639", "\ud8b5\udefb\udbb3\udd4a\udb01\udc12",
        40, 38600, -771360579, 5150217414443641737L, -59937L, false, false, (char) 55449, (char) 8811,
        Double.longBitsToDouble(0x3fe7bc3fb0041c21L), Double.longBitsToDouble(0x3f62a2eff805e800L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\ud8da\udc13\uf6aa\000\000", "", "\u2969",
        0, 11008, -742626780, 1962011571290938758L, -100000L, false, false, (char) 49942, (char) 40127,
        Double.longBitsToDouble(0x3fcdb1f7e0000000L), Double.longBitsToDouble(0x3f47800000000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\uda4e\ude2e\ud841\udf0c\uda16\udd00\ud8de\udec1\ud97f\uddff\ud9b0\udf17\udae8\udfb7\udb2a\udc00\ud922\udf53\uda12\udd22\uda81\udf55\ud894\ude60\udb14\udd87\ud995\udd6f\ud891\ude7d\ud91b\udf5a\ud844\udcbb", "\u7f50\u9064\u7efc\ua718\u34aa\u189b\u2fe8\u3660\u53f3\uafce", "\ud809\udd46\uda4f\udee5\ud96c\uddeb\udb4f\udf32\ud97d\udd3b\ud8ed\udc39\ud88f\udd7e\ud818\udd73\ud8c1\ude68\udbf1\udead\ud883\udc2a\ud94c\ude0e\udafd\udc8c\uda6d\udfe6\udb18\udce4\uda8e\ude58\udaac\uddaa\ud93f\udced",
        9, 23389, 294704910, 474370022817724171L, 91961L, false, false, (char) 52977, (char) 49538,
        Double.longBitsToDouble(0x3fd6ae080c491dccL), Double.longBitsToDouble(0x3f87b34b0efa2cc0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\ud8da\udc13", "\ud3e1\u3380", "\udb2a\udc00\u2969",
        -5, 11008, -742626780, 1962011571315842438L, 37528L, true, true, (char) 49942, (char) 2286,
        Double.longBitsToDouble(0x3fded8fbf0ceee08L), Double.longBitsToDouble(0x3feddde736afd54fL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\uda1e\udde6\udb6d\udcd6\ud8be\uddaf\udb0a\udf41\ud997\udc36\ud9b0\udf17", "\u2773\u0b5f\uc1c8\u9dad\u5f66", "\uda8b\udf5a\udbf7\udff1\udb1c\udc65\ud86e\udd10\uda99\udf2f",
        -1, 19253, -1125744537, -3076112774367130171L, -40836L, false, true, (char) 3941, (char) 32829,
        Double.longBitsToDouble(0x3febafe55f811950L), Double.longBitsToDouble(0x3fc15121325e2950L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 12, 15, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\u3498\u3631\u7c8a\u3fe3\uc1c8\u9dad\u5f66", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        17, 19253, -1125744537, -1171847693169048883L, 12417L, false, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3fe8e34955d51188L), Double.longBitsToDouble(0x3fe61fb4336bd21bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 6, 0, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\u26bf\u1e9e\ub874\u75d1\uc23c\u9dad\u5f66", "\uda9b\udf5a\ue574\ud9a8\ude68\udb59\udceb\uda96\udc56",
        17, 19253, -1125744537, -3076046803316023633L, -8244L, true, true, (char) 46220, (char) 63060,
        Double.longBitsToDouble(0x3fe8e349569f1188L), Double.longBitsToDouble(0x3fe61fb1f760681bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\udba6\udec1\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7c9a\u3fe3\uc1c8\u9dad\u1faa", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa\ud9df\udd90\uda30\udcf0\udab7\udc72\udbd4\udd36\ud90f\udcca\udb0b\udf88\ud839\udf8e\udbf6\ude68\uda4a\udf18\uda5e\udef0\uda0c\udc24\ud809\udd46\uda4c\udce5\udbc2\ude57\udab5\ude7f\udb3b\udd38\udaf4\udcfb\ud84a\ude78\udb0d\udcab\udb45\udf96\udbbc\udeba\ud874\udeb5\ud97e\ude97\ud98b\udf03\ud9c7\udfc9\udb14\udd3c\ud89a\udfeb\u5db8\uda45\udd25\udbfa\udfa9\uda2c\udfa3\ud9c6\udefc\udbc0\ude60\ud8d2\udf4e\ud985\uddb4\udacf\udc14\ud8a8\udfbf\uba2f\uda72\udf97\udaef\udd5d\udbc6\udeed\ud8a3\udf7a\udbe6\udc64\udb5c\udc1a\ud949\udf7a\uda32\udd2a\udb1b\udda5\ud8f1\udc36\udacf\ude83\uda03\udc7d",
        20, 56763, 1821240036, -4735717010452220225L, -91465L, true, true, (char) 43882, (char) 48624,
        Double.longBitsToDouble(0x3fe2fcfefee4fda4L), Double.longBitsToDouble(0x3fe28e3cfc2a5a18L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 15, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7c9a\u3fe3\uc1c8\u9dad\u5f66", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        17, 19253, -1125744537, -3076112774013690193L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3fe8e34953ae3501L), Double.longBitsToDouble(0x3fd2cfca0ec0d036L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 7, 13, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7c9a\u3fe3\u465c\u9dad\u5f66", "\uda6e\udd63\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        33, 42977, 1676365477, 1997626015095938735L, -8134L, true, true, (char) 28393, (char) 57569,
        Double.longBitsToDouble(0x3fe8e34955d51188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 2, 15, "\udb0e\udc6d\ud801\ude08\uda16\udd00\udb48\udcc2", "\u8104\u2288\u7c9a\u38c7\uc1c8\u9dad\u5f66", "\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        17, 19253, -1132869785, -3076112774013690193L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3fe8e34955d51188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 9, 0, 0, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c", "\uda91\udfcb\ud8d8\ude5c\udb6c\udcc7\ud967\udcd1\ud995\udd88\ud882\ude7d\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa\ud9df\udd90\uda30\udcf0\udab7\udc72\udbd4\udd36\ud90f\udcca\udb0b\udf88\ud839\udf8e\udbf6\ude68\uda4a\udf18",
        17, 71732, -158951979, 7501610233025744736L, 95786L, true, false, (char) 32011, (char) 6842,
        Double.longBitsToDouble(0x3feb632282d76cbcL), Double.longBitsToDouble(0x3fb2b300d6c47d40L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 13, 0, 15, "\udad5\udc04\udb67\udca8", "\u3380\ubfc5\uc72c\u2288\u26c3", "\ud8a3\udfbe\udb14\udcbb\ud995\udd9c\ud882\ude7d\uda9b\udf5a\udbbe\udefc\udbdd\udf11\udb8e\udcbb\udab0\udcf6",
        17, 19253, -1125744537, -3076112774013690193L, 57402L, true, true, (char) 60445, (char) 23921,
        Double.longBitsToDouble(0x3feab8113dd51188L), Double.longBitsToDouble(0x3fe61fb437c3681bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 15, "\u0d09\000\uda16\udcec\006", "", "\u2890",
        0, -1000, -754974720, 1962011571315842438L, -99944L, true, true, (char) 49942, (char) 191,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 15, "\ud8da\udc2a", "\ud3e1\u3380\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u9dad\u5f66\u1749\u6bf0\u284e\u6ced\u9e48\u7ec4\u8656\u2f23\u7efc\u31c4\u9540\u189b", "\udbf6\ude68\uda42\udeea\uda5e\udef0",
        57, 93585, -1263812049, -6683817523227096108L, -18395L, false, true, (char) 15208, (char) 49110,
        Double.longBitsToDouble(0x3f9769dd4311b240L), Double.longBitsToDouble(0x3fbb1b01e22b1030L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 11, 1, 15, "\ud8da\udc13", "", "",
        44, -1000, 0, -5425801978531807107L, -100000L, false, false, (char) 47237, (char) 20930,
        Double.longBitsToDouble(0x3f43bb0000000000L), Double.longBitsToDouble(0x3d40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 11, 11, 10, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0\ud997\udc36\ud9b0\udf17\udae8\udfb7\udb2a\udc00\ud88b\ude6c\uda77\uddad\ud8c1\udeb2\ud8a3\udf88\udb14\udcbb\ud995\udd9c\ud882\ude7d\uda9b\udf5a\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa\ud9df\udd90\uda30\udcf0\udab7\udc72\udbd4\udd36\ud90f\udcca\udb0b\udf88\ud839\udf8e\udbf6\ude68\uda4a\udf18\uda5e\udef0\uda0c\udc24\ud809\udd46\uda4c\udce5\udbbe\udff4\ud83c\udf80\udb6d\ude78\udb2b\ude82\ud9a3\udc27\ud87d\udfcd\udbb2\udea4\ud919\udfb8\udb23\udc5e\udb38\ude40\udb55\ude1e\ud8d4\udedb\udbaa\udd12\ud9ad\udd08\uda23\udc83\ud87c\udc6f\ud85f\ude67\udbfd\udec5\ud8a8\udc18\ud986\udc09\udb06\udf35\ud937\ude0c\ud970\udc10\ud876\udf34\ud9c3\udcbb\ud846\udf0f\udba4\udfbb\ud97d\udd50\ud953\udfb1\ud850\ude57\ud98c\udd78\ud8ee\udf18\ud9f7\uddd7\udbaa\udce5\ud93b\udd32", "\ud711\u97cc\u1fa4\u55ae\u7fdc\u8351\u6660\u3537\u424f\u451d\u0682\ud335", "\ud91b\udf58\uda2f\udd28\udb7c\udde8\uda40\udeec\udaf7\udc94\ud926\udc64",
        10, 92236, -191633244, 7385913834631287127L, -22626L, false, false, (char) 19459, (char) 33124,
        Double.longBitsToDouble(0x3feb405ea3e4ced0L), Double.longBitsToDouble(0x3fe64664077632baL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 15, "\udba1\ude9d\ud841\udeb5\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7c9a\u3fe3\u6cb1\u9d8f\u5f66", "\uda9b\udf5a\udb23\udc5f\uda7c\udf8b\udb8a\udde0\udaf8\ude8e",
        44, 86166, 1331037995, -7788067536852159653L, 88008L, false, false, (char) 20550, (char) 59477,
        Double.longBitsToDouble(0x3fe61fb6df60681bL), Double.longBitsToDouble(0x3fda9912aab73840L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 11, 0, 0, "\000", "\ud3db", "\udae8\udfb7",
        37, 14033, -1905338755, 693554754189262848L, -59674L, false, false, (char) 28704, (char) 34845,
        Double.longBitsToDouble(0x3fac2def80000000L), Double.longBitsToDouble(0x3e40b80000000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 15, "\uc8ec\u644d\udb9d\udc91\udae6\udf80\ud94d\udc71\ud95a\udfaf\udae8\udfb7\udb2a\udc00\u2969\uda91\udfcb\ud874\ude7d\ud87b\udc76\udb10\udcc3\uda8c\udd7d\udab0\udcee\uda9b\udfc7\ue574", "\u727c", "\ud92b\udd5e\ud88d\ude4b\ud90f\udcca\uda39\ude3f\ud82f\udc10\ud90c\udf0a",
        10, 75784, 294184476, -8305844724496210886L, 44435L, false, false, (char) 8067, (char) 2114,
        Double.longBitsToDouble(0x3fcf4afb3dd30468L), Double.longBitsToDouble(0x3fb41f2bef9fd870L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 13, 0, 15, "\ud988\udf6b\ud9b8\udc9e\ud96e\udf52\u2c47", "\ua2bb\u21af\u7c9a\u3fe3\uc1c8\u33ad\u5f66", "\uda9b\udf5a\ue574\ud96d\uddf7\udb7b\udcc0\uda77\udefa",
        17, -763, 0, -539009361L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3fe8e00150000088L), Double.longBitsToDouble(0x3e3b000000000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: \ua153\ud3e1\u3380\ub0b5\000\000\u85ec\ud6ac\ucdf7\000\u5f45\u9d86\000\ud248\u0a7b\u6694\u73e8\u51b6\u9af4\u7efc\u18e0\u5922 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: \ua153\ud3e1\u3380\ub0b5\000\000\u85ec\ud6ac\ucdf7\000\u5f45\u9d86\000\ud248\u0a7b\u6694\u73e8\u51b6\u9af4\u7efc\u18e0\u5922 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 1, 1, 0, 0, "", "\ua153\ud3e1\u3380\ub0b5\000\000\u85ec\ud6ac\ucdf7\000\u5f45\u9d86\000\ud248\u0a7b\u6694\u73e8\u51b6\u9af4\u7efc\u18e0\u5922", "\udbb2\udd9a",
        -1, -1000, 1509949440, 1263513802763552539L, -14144L, true, false, (char) 61167, (char) 12113,
        Double.longBitsToDouble(0x3fe7bab5823ec1d8L), Double.longBitsToDouble(0x3fe52573c4e553d7L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000\000\024\000=[ option: \000\000\024\000  :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000\000\024\000=[ option: \000\000\024\000  :: null :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 1, 1, 0, 15, "\000\000\024\000", "\uca3c\000\000\u7042\u2b03\u33ad\u5f66", "\uda9b\udf5a\uda4c\udcc6\u1938",
        39, 14020, -1883284319, 8576148832480821351L, -100000L, false, false, (char) 0, (char) 22467,
        Double.longBitsToDouble(0x3fd982cf497c32fcL), Double.longBitsToDouble(0x3fe8e2d208001188L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 2, 14, "\ua2a8\ud841\udf0c\uda16\udd00\udae6\udeb0", "\u1325\u8230\u644c\u70ee\u2b03\u9dad\u5f66", "\udae5\udf5f\uda4c\udcc6\udaec\udcc5\ud975\udd88\udb5d\udfcd",
        53, 19089, -1125744537, -3076112774750052689L, 79417L, true, true, (char) 22685, (char) 43032,
        Double.longBitsToDouble(0x3fe8e2d4a71b1188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 9, 0, 0, "\000", "", "",
        16, 94124, 0, 0L, -100000L, false, false, (char) 0, (char) 30208,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 15, "\ud8da\udc13\ud841\udf0c\udb34\udc2e\ud96c\udf66\ud997\udc36\uda6c\udf35\u450b\udb9f\ude16\ud8f0\udd23", "\u1699\u634a\u7b4a\u9bad\u2d95\u7fc4\u9e48\ua595\u5e25\ud77c\u7da3\u54de\u0dc2\u181b\ud48b\ub396\uc977\uafce\u02ca\uc951\u9714\ucfcd\ua691\u195f\u1a3b\ub78a\u8ca9\u37ab", "\ud8b3\ude2b\udbf8\uddd7\udaea\udd3d\ud870\udf66\udbaa\uddfe\ua377\udb9e\ude6b\ud8f7\udc4d\ud91b\udd64\udb2c\udc7f",
        54, 56100, 52402022, -2347492016072833643L, 15219L, false, true, (char) 14101, (char) 32405,
        Double.longBitsToDouble(0x3f6e53b8bf16d600L), Double.longBitsToDouble(0x3fdb8fd2876bd774L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 3, 15, "\ud8da\udc3b\udbe2\ude1c\udb34\udc90\ud96c\udf66\ud9a3\uded5\uda6c\udf35\u450b\udb9f\ude16\ud8f0\udd23\ud9b1\udca3\ud8bd\udfe5\ud993\ude51\ud8e0\udc61\ud87a\udd75\u9b4d\ud8ba\udd5f", "\ua595\u2be4\u93d8\u9e11\u54de\u0dc2\u181b", "\u6e69\uda4a\udf18",
        17, 85740, 1214266018, 391300104965991212L, 19366L, false, true, (char) 41361, (char) 16280,
        Double.longBitsToDouble(0x3fd41890a7666206L), Double.longBitsToDouble(0x3fe928181fece538L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 0, 0, 15, "\ud8e4\ude72\ud9f6\udc5a\uda16\udd00\udb95\ude08", "\uc72c\u97ae\u7c9a\u3fe3\uc1c8\uc4ce\ud765", "\000\ud85c\udc0d\000\000\000",
        36, 38405, 0, -3098476544169910609L, -8134L, true, true, (char) 43660, (char) 63035,
        Double.longBitsToDouble(0x3f3a4aaeac852800L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 6, 0, 15, "\ud8da\udc13\ud841\udf0c\ud883\udcea\udae6\udf3b", "\u6f14\u1e9e\ucead\u8814\u21d3\u9dad\u5f66\u5ad4\uc6d0\u284e\u6ced\uaf8d\u6361\u3068\u2f23\u7efc\u12f4\u9522\u189b\u4e2b\u0c4a\ucec5\u5fec\ub15e\u24ed\u588e\u0626\u96de\u4a84\u6089\u638c\u68f6\u4158\u92b0\u86b8\u4736\u1ed9\u7fdf\u2562\ucc4d\u622e\u3d7d\u82a7\u75ce\u5721\u724e\u18ee\u8160\u211b\u2189\u66c0\u9549\u3c05\u3b69\u739a", "\uda8f\udc84\udbc1\uddbd\udb67\udc33\u1471\uda83\uddc7\ud86d\ude62\ud895\uded5\udb7a\udc25\ua161\ud9ba\udd6e\udb48\udc47\uda24\ude6a\uda8d\udeb1\ud861\udc3c\uda69\ude85\udad6\ude7b\ud941\udeb2\udb66\ude4e\ud82b\ude52\udace\udc4e\udabe\ude21\udbbd\udf9f\u68ca\udabb\ude74\uda71\udccb\uda25\uddd5\ud88f\uddef\ud9ae\udc28\ud891\udf41\ud8b4\uddbf\ud98e\udc96\ud8a2\udd4e\udbc1\udc21\ud9ca\udd9a\ud863\udce5\ud94f\udf1e\udb80\ude5b\udb8d\ude86\uda0a\udf43\ud843\udcea\uda60\ude20\udb64\udf24\udbfc\udde9\u1026\ud923\ude1f\uda24\udf17\udb6b\udd3c\udb6c\ude9a\uda68\udd2c\uda9c\udf15\ud960\uddd7\udbc0\udece\udb70\udd0c\u9908\ud926\uddc6\ud9a6\ude47\ud8fe\udf1e\udbd8\udc88\ud9eb\udce5\udb76\udefb\udbe1\udddd\ud90e\udea5\ud946\ude6b\udada\udca2\uda1e\ude8d\ud8dc\udf6d\ud842\udc61\udbc7\uddc0\ud8b0\ude3f\ud9bc\udc1e\udb3a\udcc7\ud9d3\ude3b\ud9cf\uddf3\uda9b\udfae\ud841\udca6\u9012\udb0b\udfa9\ud8a1\udf8b\ud896\ude38\ud98e\udf38\ud882\udd1a\ud80c\ude68\ud9d4\ude7d\ud99c\udd1c\ud9f1\uded1\ud92c\udf43",
        28, 92850, 1754267618, -5190702327496899565L, 59711L, true, false, (char) 41891, (char) 33802,
        Double.longBitsToDouble(0x3fed7ecc7193ccaaL), Double.longBitsToDouble(0x3fdfea609e1b3054L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 11, 11, 13, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7bc1\u3fe3\u465c\u9dad\u5f78", "\uda6e\udd63\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        33, 42977, 1676365477, 1997626015095971503L, -8134L, true, true, (char) 28393, (char) 57569,
        Double.longBitsToDouble(0x3fe8e34955d51188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 12, 12, 13, "\ud8da\udc13\ud841\udf0c\uda16\udd00\udae6\udeb0", "\uc72c\u2288\u7c9a\u5454\u465c\u9dad\u5f66", "\uda6e\udd63\ue574\ud9c8\udd78\udb6f\udc82\uda77\udefa",
        33, 68459, 1676377044, -3766981507938296267L, 81082L, false, true, (char) 28393, (char) 57569,
        Double.longBitsToDouble(0x3fe8e34955d51188L), Double.longBitsToDouble(0x3fe61fb43760681bL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 9, 9, 15, "\ud9a9\udc66\ud801\ude08\uda16\udd00\ud9a3\udd6e", "\u1343\u6ad4\uc5aa\u6612\uc23c\u9dad\u5f66", "\uda9b\udf94\ue574\udb00\udd74\udb6f\udc82",
        5, 65662, 1229604077, -4865684608298028101L, -62603L, false, true, (char) 2373, (char) 64770,
        Double.longBitsToDouble(0x3fc7c8fc1c71a4a8L), Double.longBitsToDouble(0x3fdd51188587ed0cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 0, "\011", "\u6430\u3380u\000\u2288\u7c9a}\000\000\000\000\000", "\ud9c8\udd78",
        8, -1000, -1883280338, 8576148832473696103L, -100000L, false, false, (char) 39167, (char) 182,
        Double.longBitsToDouble(0x3e17c00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: \000\ud3db\u3380\u1c9a\u16ae\uc44e\ud399\u3fe3\u9aaa\u9dad\u5f66\u1749\u6bf0\u284e\u6ced\u9e48\u7ec4\u8656\u2f23\u7efc\u31c4\u9540 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: \000\ud3db\u3380\u1c9a\u16ae\uc44e\ud399\u3fe3\u9aaa\u9dad\u5f66\u1749\u6bf0\u284e\u6ced\u9e48\u7ec4\u8656\u2f23\u7efc\u31c4\u9540 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 12, 1, 15, "", "\000\ud3db\u3380\u1c9a\u16ae\uc44e\ud399\u3fe3\u9aaa\u9dad\u5f66\u1749\u6bf0\u284e\u6ced\u9e48\u7ec4\u8656\u2f23\u7efc\u31c4\u9540", "\udbaf\uddea\udbf6\ude68\uda42\udeea\uda5e\udef0\uda0c\udc24\uda12\udf50\uda0f\uddbe\uda64\udde8\udb32\udfdb\udb2a\udf03\u6410\ud84f\udfa7\ud9be\udfb5\ud87c\uded4\udaa0\udd58\udb14\udc75\udb54\ude32\ud8ba\ude84\ud8b1\udc53\ud8b3\uddab\ud841\udf44\ud992\udd26\u6242\uda25\uddb9\u3d63\uda17\udfae\ud9a5\udc1f\ud948\udfc3\ud882\udef0\udb2f\udc94\ud825\udcda\uda55\udf0d\uda04\udf56",
        27, 35835, 329073603, -806687569505754462L, -73976L, true, true, (char) 7766, (char) 38460,
        Double.longBitsToDouble(0x3fee804b1038e669L), Double.longBitsToDouble(0x3fd4b3ba865ea18cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\u1749\u6bf0\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\u1749\u6bf0\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 12, 1, 15, "\000", "\ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\u1749\u6bf0\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b", "\udbf6\ude68\uda42\udeea\uda5e\udef0",
        57, 93432, -1263812049, -6683817523235782444L, -18395L, false, true, (char) 39966, (char) 64662,
        Double.longBitsToDouble(0x3f9769dd4011b240L), Double.longBitsToDouble(0x3fbb1b01e22b1030L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\uc8ec=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\u21a5  [ARG] :: \ud874\ude7d\ud87b\udc76 :: class java.lang.String ]} ] [ long {\ud4b1\ud320\u33b5\uc72c\u21a5=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\u21a5  [ARG] :: \ud874\ude7d\ud87b\udc76 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\uc8ec=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\u21a5  [ARG] :: \ud874\ude7d\ud87b\udc76 :: class java.lang.String ]} ] [ long {\ud4b1\ud320\u33b5\uc72c\u21a5=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\u21a5  [ARG] :: \ud874\ude7d\ud87b\udc76 :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 3, 0, 15, "\uc8ec", "\ud4b1\ud320\u33b5\uc72c\u21a5", "\ud874\ude7d\ud87b\udc76",
        24, 49837, -1330371173, 6202814263168305162L, -62314L, true, true, (char) 23114, (char) 55622,
        Double.longBitsToDouble(0x3fe57c0e7215dfdfL), Double.longBitsToDouble(0x3fda8bef28ccd96cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u33ad  :: \ud95a\udfaf :: class java.lang.String ]} ] [ long {\u33ad=[ option:  \u33ad  :: \ud95a\udfaf :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \u33ad  :: \ud95a\udfaf :: class java.lang.String ]} ] [ long {\u33ad=[ option:  \u33ad  :: \ud95a\udfaf :: class java.lang.String ]} ]\012",
        Z.run(T, 1, 3, 0, 15, "", "\u33ad", "\ud95a\udfaf",
        54, -1000, -1275068416, -8183367641917364384L, -90373L, false, false, (char) 56861, (char) 2311,
        Double.longBitsToDouble(0x3fd29d040b5ad690L), Double.longBitsToDouble(0x3fc95df9e7b7c6fcL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\uc954=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\uc954=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\uc954=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 0, 15, "\000", "\ud3e1\uc954", "\uda52\ude53\udbea\udc68\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12",
        42, 26639, -725315072, -3950332911643524755L, 87582L, false, true, (char) 39815, (char) 52824,
        Double.longBitsToDouble(0x3fe305a558d4a33eL), Double.longBitsToDouble(0x3fe3c800003b815cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 2, 1, 15, "\000", "\ud3e1\uc954\u1c9a", "\ud86e\udd7f\ud967\udeb5\uabe8\ud832\ude2f!",
        56, 35942, 1442894408, 6620159553860671800L, 75316L, false, false, (char) 10477, (char) 63338,
        Double.longBitsToDouble(0x3fe1f11736af028aL), Double.longBitsToDouble(0x3fe006fef926d4c4L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000 :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000 :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Option:[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000 :: class java.lang.String ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000 :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 6, 15, "\000", "\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d", "\uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000",
        -4, 92738, 1823947516, 7063355518766673674L, 6256L, false, true, (char) 25318, (char) 45038,
        Double.longBitsToDouble(0x3fe005382ec9c810L), Double.longBitsToDouble(0x3fe695ff24e2da86L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\u3886\ud399\u3fe3\uce0f\u2fe6\u00c8\u8b48\u6c73\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\u3886\ud399\u3fe3\uce0f\u2fe6\u00c8\u8b48\u6c73\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\u3886\ud399\u3fe3\uce0f\u2fe6\u00c8\u8b48\u6c73\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\u3886\ud399\u3fe3\uce0f\u2fe6\u00c8\u8b48\u6c73\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 1, 15, "\000", "\ud3e1\uc954\u1c9a\uc72c\u3886\ud399\u3fe3\uce0f\u2fe6\u00c8\u8b48\u6c73\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b", "\udbf6\ude68\uda42\udeea\uda5e\udef0",
        57, 93432, -1263812049, -6683817523235782444L, -18395L, false, true, (char) 39966, (char) 64662,
        Double.longBitsToDouble(0x3f97215e4011b240L), Double.longBitsToDouble(0x3fbb1b01e22b1030L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\ub53e\ua6c9\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\ub53e\ua6c9\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\ub53e\ua6c9\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\ub53e\ua6c9\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 2, 2, 6, "\000", "\ud3e1\uc954\u1c9a\uc72c\uc44e\ud399\u3fe3\uce0f\u4303!\ub53e\ua6c9\u6836\u6ced\u9e48\u7ec4\u8656\u4a12\u7efc\u31c4\u9540\u189b", "\udbf6\ude68\uda42\udeea\uda5e\udef0",
        57, 57344, -1263812049, -6683817523235782444L, -18395L, false, true, (char) 39966, (char) 64662,
        Double.longBitsToDouble(0x3f9769dd4011b240L), Double.longBitsToDouble(0x3fbb1b01e22b1030L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\uc8ec=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\ub6f9\u7bc8\u3fe3\ubd1b\u7e0f\u5b12\u03f9\u679f\u28bb  [ARG] :: \ud9bf\ude86\udb78\udfb4\ud840\udf14\uda30\udc86\ud92b\udd5e\ud88d\ude4b\udbce\udf75\uda39\ude58\ud82f\udc10\ud98f\udd85\ua8a1\ud962\udece\udb8a\udd51\ud894\uddf2\udae4\ude74\uda36\udfbc\uc6b2\ud97d\udee0\ud9d8\udd7b\udbae\udd04\ud979\udf7d\ud8b0\udd1f\udae9\udcae\ud858\ude5f\ud908\udc89\ud983\udcd0\udad0\udeee\ud83e\udfd8\udb0e\udd90\ud8c0\udd6b\uda4e\udef6\ud806\udf9e\udbd6\udf4c :: class java.lang.String ]} ] [ long {\ud4b1\ud320\u33b5\uc72c\ub6f9\u7bc8\u3fe3\ubd1b\u7e0f\u5b12\u03f9\u679f\u28bb=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\ub6f9\u7bc8\u3fe3\ubd1b\u7e0f\u5b12\u03f9\u679f\u28bb  [ARG] :: \ud9bf\ude86\udb78\udfb4\ud840\udf14\uda30\udc86\ud92b\udd5e\ud88d\ude4b\udbce\udf75\uda39\ude58\ud82f\udc10\ud98f\udd85\ua8a1\ud962\udece\udb8a\udd51\ud894\uddf2\udae4\ude74\uda36\udfbc\uc6b2\ud97d\udee0\ud9d8\udd7b\udbae\udd04\ud979\udf7d\ud8b0\udd1f\udae9\udcae\ud858\ude5f\ud908\udc89\ud983\udcd0\udad0\udeee\ud83e\udfd8\udb0e\udd90\ud8c0\udd6b\uda4e\udef6\ud806\udf9e\udbd6\udf4c :: class java.lang.Stri... |this=org.apache.commons.cli.Options:[ Options: [ short {\uc8ec=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\ub6f9\u7bc8\u3fe3\ubd1b\u7e0f\u5b12\u03f9\u679f\u28bb  [ARG] :: \ud9bf\ude86\udb78\udfb4\ud840\udf14\uda30\udc86\ud92b\udd5e\ud88d\ude4b\udbce\udf75\uda39\ude58\ud82f\udc10\ud98f\udd85\ua8a1\ud962\udece\udb8a\udd51\ud894\uddf2\udae4\ude74\uda36\udfbc\uc6b2\ud97d\udee0\ud9d8\udd7b\udbae\udd04\ud979\udf7d\ud8b0\udd1f\udae9\udcae\ud858\ude5f\ud908\udc89\ud983\udcd0\udad0\udeee\ud83e\udfd8\udb0e\udd90\ud8c0\udd6b\uda4e\udef6\ud806\udf9e\udbd6\udf4c :: class java.lang.String ]} ] [ long {\ud4b1\ud320\u33b5\uc72c\ub6f9\u7bc8\u3fe3\ubd1b\u7e0f\u5b12\u03f9\u679f\u28bb=[ option: \uc8ec \ud4b1\ud320\u33b5\uc72c\ub6f9\u7bc8\u3fe3\ubd1b\u7e0f\u5b12\u03f9\u679f\u28bb  [ARG] :: \ud9bf\ude86\udb78\udfb4\ud840\udf14\uda30\udc86\ud92b\udd5e\ud88d\ude4b\udbce\udf75\uda39\ude58\ud82f\udc10\ud98f\udd85\ua8a1\ud962\udece\udb8a\udd51\ud894\uddf2\udae4\ude74\uda36\udfbc\uc6b2\ud97d\udee0\ud9d8\udd7b\udbae\udd04\ud979\udf7d\ud8b0\udd1f\udae9\udcae\ud858\ude5f\ud908\udc89\ud983\udcd0\udad0\udeee\ud83e\udfd8\udb0e\udd90\ud8c0\udd6b\uda4e\udef6\ud806\udf9e\udbd6\udf4c :: class java.lang.Stri...\012",
        Z.run(T, 1, 3, 0, 15, "\uc8ec", "\ud4b1\ud320\u33b5\uc72c\ub6f9\u7bc8\u3fe3\ubd1b\u7e0f\u5b12\u03f9\u679f\u28bb", "\ud9bf\ude86\udb78\udfb4\ud840\udf14\uda30\udc86\ud92b\udd5e\ud88d\ude4b\udbce\udf75\uda39\ude58\ud82f\udc10\ud98f\udd85\ua8a1\ud962\udece\udb8a\udd51\ud894\uddf2\udae4\ude74\uda36\udfbc\uc6b2\ud97d\udee0\ud9d8\udd7b\udbae\udd04\ud979\udf7d\ud8b0\udd1f\udae9\udcae\ud858\ude5f\ud908\udc89\ud983\udcd0\udad0\udeee\ud83e\udfd8\udb0e\udd90\ud8c0\udd6b\uda4e\udef6\ud806\udf9e\udbd6\udf4c",
        31, 66490, -848943406, 2034220216938678125L, 88236L, true, false, (char) 37033, (char) 46366,
        Double.longBitsToDouble(0x3fc32175660c6504L), Double.longBitsToDouble(0x3fdd5f9147048fdcL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \000\000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000\000=[ option: \000 \000\000  [ARG] ::  :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \000\000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000\000=[ option: \000 \000\000  [ARG] ::  :: class java.lang.String ]} ]\0121=java.util.ArrayList:[\000\000] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \000\000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000\000=[ option: \000 \000\000  [ARG] ::  :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 0, 15, "\000", "\000\000", "",
        -5, 55584, -1905338755, 842865135461387432L, -59674L, true, false, (char) 28704, (char) 60815,
        Double.longBitsToDouble(0x3fd385bdf666088cL), Double.longBitsToDouble(0x3fca956860000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ] [ long {\u355c\u35ea=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ] [ long {\u355c\u35ea=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ]\0121=java.lang.String:[ Options: [ short {\000=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ] [ long {\u355c\u35ea=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ] [ long {\u355c\u35ea=[ option: \000 \u355c\u35ea  :: \ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 15, 15, "\000", "\u355c\u35ea", "\ud881\ude48\udbea\udc68\uda91\udfcb\ud9bf\ude10\udaaf\ude46\u00b7\uda3d\udd09\uda7f\ude6c\uda89\udcc7\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\ud88a\udc6f\udadd\uddbb",
        42, 26639, -725315072, -3950332911643524755L, 87582L, false, true, (char) 39815, (char) 52824,
        Double.longBitsToDouble(0x3fe305a558d4a33eL), Double.longBitsToDouble(0x3fe3c800003b815cL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\u5f42  :: \udb10\udc9c\udbea\udc63\ud860\ude32\udbf6\udc11\ud84b\udcb3!\ud995\udd9c\u5fac\ud884\udfef\ud881\udf27\udae6\udf47\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\u5f42=[ option: \000 \ud3e1\u5f42  :: \udb10\udc9c\udbea\udc63\ud860\ude32\udbf6\udc11\ud84b\udcb3!\ud995\udd9c\u5fac\ud884\udfef\ud881\udf27\udae6\udf47\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\u5f42  :: \udb10\udc9c\udbea\udc63\ud860\ude32\udbf6\udc11\ud84b\udcb3!\ud995\udd9c\u5fac\ud884\udfef\ud881\udf27\udae6\udf47\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\u5f42=[ option: \000 \ud3e1\u5f42  :: \udb10\udc9c\udbea\udc63\ud860\ude32\udbf6\udc11\ud84b\udcb3!\ud995\udd9c\u5fac\ud884\udfef\ud881\udf27\udae6\udf47\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\u5f42 :: class java.lang.String ]} ] [ long {\ud3e1\u5f42=[ option: \000 \ud3e1\u5f42  :: \udb10\udc9c\udbea\udc63\ud860\ude32\udbf6\udc11\ud84b\udcb3!\ud995\udd9c\u5fac\ud884\udfef\ud881\udf27\udae6\udf47\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \ud3e1\u5f42 :: class java.lang.String ]} ] [ long {\ud3e1\u5f42=[ option: \000 \ud3e1\u5f42  :: \udb10\udc9c\udbea\udc63\ud860\ude32\udbf6\udc11\ud84b\udcb3!\ud995\udd9c\u5fac\ud884\udfef\ud881\udf27\udae6\udf47\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 1, 15, "\000", "\ud3e1\u5f42", "\udb10\udc9c\udbea\udc63\ud860\ude32\udbf6\udc11\ud84b\udcb3!\ud995\udd9c\u5fac\ud884\udfef\ud881\udf27\udae6\udf47\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12",
        42, 26639, -725315072, 5044481444110467415L, 46225L, false, true, (char) 35168, (char) 52824,
        Double.longBitsToDouble(0x3fe305a558d4a33eL), Double.longBitsToDouble(0x3fe3c800063b815cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    [ARG] :: \uda16\udf27 :: class java.lang.String ]} ] [ long {=[ option:    [ARG] :: \uda16\udf27 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    [ARG] :: \uda16\udf27 :: class java.lang.String ]} ] [ long {=[ option:    [ARG] :: \uda16\udf27 :: class java.lang.String ]} ]\0121=java.util.Collections$SingletonList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    [ARG] :: \uda16\udf27 :: class java.lang.String ]} ] [ long {=[ option:    [ARG] :: \uda16\udf27 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 0, 15, "", "", "\uda16\udf27",
        -3, 4396, 362092814, 49308606922752L, -47608L, true, false, (char) 40325, (char) 55288,
        Double.longBitsToDouble(0x3fe244eec00a6586L), Double.longBitsToDouble(0x3fd385bdf666088cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9a4\ude82\ud92c\udc02\udac0\udc18\uda54\udfdb\ud8a4\udc5a\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\uc954=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9a4\ude82\ud92c\udc02\udac0\udc18\uda54\udfdb\ud8a4\udc5a\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9a4\ude82\ud92c\udc02\udac0\udc18\uda54\udfdb\ud8a4\udc5a\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\uc954=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9a4\ude82\ud92c\udc02\udac0\udc18\uda54\udfdb\ud8a4\udc5a\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ]\0121=java.lang.Boolean:true |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9a4\ude82\ud92c\udc02\udac0\udc18\uda54\udfdb\ud8a4\udc5a\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ] [ long {\ud3e1\uc954=[ option: \000 \ud3e1\uc954  :: \uda52\ude53\udbea\udc68\uda91\udfcb\ud9a4\ude82\ud92c\udc02\udac0\udc18\uda54\udfdb\ud8a4\udc5a\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 12, 15, "\000", "\ud3e1\uc954", "\uda52\ude53\udbea\udc68\uda91\udfcb\ud9a4\ude82\ud92c\udc02\udac0\udc18\uda54\udfdb\ud8a4\udc5a\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12",
        42, 71391, -1257410580, -3936258402607681728L, 87582L, false, true, (char) 33566, (char) 7997,
        Double.longBitsToDouble(0x3fdb9cc991a9467cL), Double.longBitsToDouble(0x3fe3c800003b815cL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 13, 13, 15, "\000", "\ud3e1\uc954", "\ud8e4\udcbc\u5f0b\uda91\udfcb\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda51\ude34\uda71\udff6\ud8ae\udd57\uda83\udc63\udad7\udd12",
        42, 26639, -725315072, -3950332911643524755L, 87582L, false, true, (char) 39815, (char) 52824,
        Double.longBitsToDouble(0x3fe305a558d4a33eL), Double.longBitsToDouble(0x3fe67800028e1f3fL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 6, 6, 15, "\000", "\ud3e1\u5ce2\u52c0\ua551\u6faa.\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\ucbad\u2356\u30ab\u4a74\u79f6\u519b\u386b\ub478\uc349", "\uda75\uddea\uda5e\udef0\ud982\udc27\uda12\udeb7\uda0f\uddbe\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\000",
        -4, 92738, 1823947516, 7063355518766673674L, 6256L, false, true, (char) 25318, (char) 45038,
        Double.longBitsToDouble(0x3fe005382ec9c810L), Double.longBitsToDouble(0x3fe695ff24e24786L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d=[ option: \000 \ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d  :: \uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 3, 15, "\000", "\ud3e1\uc954\u7d09\u10f8\u6faa\u2ed9\ucf6f\u91a1\uc77b\u19f5\u1749\u6bf0\u6836\u36db\u41b5\u7e92\u8656\u4a12\u7efc\u31c4\u9540\u189b\u148d", "\uda5a\udcbf\uda5e\udef0\ud982\udc27\ud954\udd48\udb21\udf6d\uda87\udde8\u00d4\udb2a\udf03\udba3\udf4f\ud8ae\udffc\ud64c",
        -4, 92738, 1823947516, 7063566844864622346L, -97680L, false, true, (char) 25318, (char) 45038,
        Double.longBitsToDouble(0x3fe620f3cec9c810L), Double.longBitsToDouble(0x3fe695ff24e2bc51L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ] [ long {\ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37=[ option: \000 \ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37  [ARG] :: null :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 3, 15, "\000", "\ud3e1\uc954\u7d09\u38c6\ucff3\u669d\ucf31\u91a1\uc77b\u5d36\ubae8\u20f1\u904b\u36db\u924d\u82c5\u8656\ua301\u19a6\u1b29\u9540\u6d86\uca37", "\ud850\udde1\udace\udcb1\ud911\ude2b\uda11\udcd7\uda0f\uddbe\udbd5\udd6f\uda01\udd6b",
        2, 19779, 1881859119, 1933319831L, 52227L, true, false, (char) 33402, (char) 4111,
        Double.longBitsToDouble(0x3fdce39183177fdcL), Double.longBitsToDouble(0x3fe006c2b6c9c810L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ] [ long {\000=[ option:  \000  [ARG] :: \ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 3, 15, "", "\000", "\ud885\udfdb\uda8e\uddc9\uda52\ude53\u2cd9\ud850\udd48\ud9bf\ude10\ud84b\udcb3!\ud995\udd9c\ud8a4\udcb4\udaae\udc43\ue574\ud9c8\udd78\uda55\udc96\udbe7\udeb0\ud942\udeea",
        21, 67668, 477776890, 5970665431769713489L, -59074L, true, false, (char) 61477, (char) 52251,
        Double.longBitsToDouble(0x3fdb3dcd95d75f34L), Double.longBitsToDouble(0x3fd02974dd98d99cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 1, 6, 0, 13, "\ud8da\udc13\ud850\udf94\ud985\udf51\ud97a\udfa0", "\uc72c\u2288\u7c9a\u3fe3\uba86\u5a67", "\udb5d\udcca\udbb1\udf6c\ue574\ud9c8\udd78\udaae\udc51\uda77\udf01\ud9df\udd90\udb49\udd63\udab7\udc72\udbd4\udd36\ud90f\udcca\udb0b\udf88\ud839\udf8e\udbf6\ude68\uda4a\udf18\uda5e\udef0",
        57, 21021, 1746604739, 7474373807415932719L, -4087L, true, true, (char) 5832, (char) 28636,
        Double.longBitsToDouble(0x3fd197ea00e9588eL), Double.longBitsToDouble(0x3facdaadf77f2e90L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @ \000\000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000\000=[ option: @ \000\000  [ARG] ::  :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @ \000\000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000\000=[ option: @ \000\000  [ARG] ::  :: class java.lang.String ]} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @ \000\000  [ARG] ::  :: class java.lang.String ]} ] [ long {\000\000=[ option: @ \000\000  [ARG] ::  :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 0, 15, "@", "\000\000", "",
        -5, 55584, -1905338735, 842865135461387432L, -59674L, true, false, (char) 1312, (char) 39312,
        Double.longBitsToDouble(0x3fc509332f884458L), Double.longBitsToDouble(0x3fb1124900000000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @ \000\000  :: null :: class java.lang.String ]} ] [ long {\000\000=[ option: @ \000\000  :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @ \000\000  :: null :: class java.lang.String ]} ] [ long {\000\000=[ option: @ \000\000  :: null :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  :: null :: class java.lang.String ]} ] [ long {\000\000=[ option: @ \000\000  :: null :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  :: null :: class java.lang.String ]} ] [ long {\000\000=[ option: @ \000\000  :: null :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 1, 4, "@", "\000\000", "\000",
        49, 25265, 196244832, 53142317548175544L, -45091L, false, false, (char) 39312, (char) 19009,
        Double.longBitsToDouble(0x3fe71088b23f4924L), Double.longBitsToDouble(0x3eb0e7ea21300000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.String ]} ] [ long {\000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.Stri... |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.String ]} ] [ long {\000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.Stri...\0121=java.lang.String:[ Options: [ short {=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.String ]} ] [ long {\000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.Stri... |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.String ]} ] [ long {\000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c=[ option:  \000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c  [ARG] :: \ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2 :: class java.lang.Stri...\012",
        Z.run(T, 2, 3, 15, 15, "", "\000\uc1f9\uc954\u1c9a\u3baa\u52a2\u2cd9\uc8e2\u0b3d\ua587\ub14f\u7719\u0430\u6a9c", "\ud9c4\udc6c\udade\ude59\udb6f\uddbc\uda0b\udc2d\udbaf\udc50\uda46\udc51\uda34\udd65\ud98e\udd04\uda5d\udc95\udb94\ude2a\udbb4\ude02\ud86c\udd83\uda28\uded6\ud9a4\udfdd\ua946\ud9c9\ude12\udba9\udd73\udbac\udc04\udb31\udeaa\ud971\ude91\ud827\udcc7\udbd8\udd1d\uda3c\udda8\ucd3f\udb6c\udef5\ud91d\ude67\ud8ee\udd22\udae6\udf78\ud9bb\ude1b\uda62\udc85\ud9d3\udd44\udba6\udc17\uda7a\udcc2",
        30, 12568, 1285315749, 2307836127252805351L, -43774L, true, false, (char) 20365, (char) 54774,
        Double.longBitsToDouble(0x3fb990a831acb1b8L), Double.longBitsToDouble(0x3fcbf44fc3552de4L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \u2e3a  [ARG] :: \uda8e\uddc9\uda52\ude53\ud985\udf61\udb0f\udcd8\ud9bf\ude10\uda9e\udced\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\ud9c8\udd78\uda64\udffd\ud993\udef4\ud892\ude6b\uda06\ude4f\uda6a\udefb :: class java.lang.String ]} ] [ long {\u2e3a=[ option: ? \u2e3a  [ARG] :: \uda8e\uddc9\uda52\ude53\ud985\udf61\udb0f\udcd8\ud9bf\ude10\uda9e\udced\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\ud9c8\udd78\uda64\udffd\ud993\udef4\ud892\ude6b\uda06\ude4f\uda6a\udefb :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \u2e3a  [ARG] :: \uda8e\uddc9\uda52\ude53\ud985\udf61\udb0f\udcd8\ud9bf\ude10\uda9e\udced\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\ud9c8\udd78\uda64\udffd\ud993\udef4\ud892\ude6b\uda06\ude4f\uda6a\udefb :: class java.lang.String ]} ] [ long {\u2e3a=[ option: ? \u2e3a  [ARG] :: \uda8e\uddc9\uda52\ude53\ud985\udf61\udb0f\udcd8\ud9bf\ude10\uda9e\udced\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\ud9c8\udd78\uda64\udffd\ud993\udef4\ud892\ude6b\uda06\ude4f\uda6a\udefb :: class java.lang.String ]} ]\0121=java.lang.Boolean:true |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \u2e3a  [ARG] :: \uda8e\uddc9\uda52\ude53\ud985\udf61\udb0f\udcd8\ud9bf\ude10\uda9e\udced\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\ud9c8\udd78\uda64\udffd\ud993\udef4\ud892\ude6b\uda06\ude4f\uda6a\udefb :: class java.lang.String ]} ] [ long {\u2e3a=[ option: ? \u2e3a  [ARG] :: \uda8e\uddc9\uda52\ude53\ud985\udf61\udb0f\udcd8\ud9bf\ude10\uda9e\udced\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\ud9c8\udd78\uda64\udffd\ud993\udef4\ud892\ude6b\uda06\ude4f\uda6a\udefb :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 13, 15, "?", "\u2e3a", "\uda8e\uddc9\uda52\ude53\ud985\udf61\udb0f\udcd8\ud9bf\ude10\uda9e\udced\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\ud9c8\udd78\uda64\udffd\ud993\udef4\ud892\ude6b\uda06\ude4f\uda6a\udefb",
        51, 4160, -1994300163, 6149907618539278625L, 30423L, true, true, (char) 2415, (char) 14283,
        Double.longBitsToDouble(0x3feae42217ff0f5bL), Double.longBitsToDouble(0x3fec1744effb1270L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \u336d  [ARG] :: \uda77\udfe2\uda52\ude53\uda14\udca9\udb0f\udcd8\ud9bf\ude10\udb81\ude0e\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\uda6d\ude2b\udbcd\udee2\ud993\udeeb\ud838\ude69 :: class java.lang.String ]} ] [ long {\u336d=[ option: ? \u336d  [ARG] :: \uda77\udfe2\uda52\ude53\uda14\udca9\udb0f\udcd8\ud9bf\ude10\udb81\ude0e\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\uda6d\ude2b\udbcd\udee2\ud993\udeeb\ud838\ude69 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ? \u336d  [ARG] :: \uda77\udfe2\uda52\ude53\uda14\udca9\udb0f\udcd8\ud9bf\ude10\udb81\ude0e\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\uda6d\ude2b\udbcd\udee2\ud993\udeeb\ud838\ude69 :: class java.lang.String ]} ] [ long {\u336d=[ option: ? \u336d  [ARG] :: \uda77\udfe2\uda52\ude53\uda14\udca9\udb0f\udcd8\ud9bf\ude10\udb81\ude0e\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\uda6d\ude2b\udbcd\udee2\ud993\udeeb\ud838\ude69 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u336d :: class java.lang.String ]} ] [ long {\u336d=[ option: ? \u336d  [ARG] :: \uda77\udfe2\uda52\ude53\uda14\udca9\udb0f\udcd8\ud9bf\ude10\udb81\ude0e\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\uda6d\ude2b\udbcd\udee2\ud993\udeeb\ud838\ude69 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u336d :: class java.lang.String ]} ] [ long {\u336d=[ option: ? \u336d  [ARG] :: \uda77\udfe2\uda52\ude53\uda14\udca9\udb0f\udcd8\ud9bf\ude10\udb81\ude0e\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\uda6d\ude2b\udbcd\udee2\ud993\udeeb\ud838\ude69 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 2, 15, "?", "\u336d", "\uda77\udfe2\uda52\ude53\uda14\udca9\udb0f\udcd8\ud9bf\ude10\udb81\ude0e\u0c54\ud995\udd9c\ud8a4\udcb4\udaae\udc43\u7d74\uda6d\ude2b\udbcd\udee2\ud993\udeeb\ud838\ude69",
        25, 71895, 837353732, 4542400042100679933L, -62847L, true, false, (char) 62505, (char) 54139,
        Double.longBitsToDouble(0x3fe06351c8b5d7d1L), Double.longBitsToDouble(0x3fde9cc6ffff9c0aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Options|getMatchingOptions|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOptionGroup|org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOptionGroup|org.apache.commons.cli.Option|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOptionGroups||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOptions||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getRequiredOptions||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|hasLongOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|hasOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|hasShortOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|helpOptions||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|toString||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getMatchingOptions|java.lang.String|new:org.apache.commons.cli.Options:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
