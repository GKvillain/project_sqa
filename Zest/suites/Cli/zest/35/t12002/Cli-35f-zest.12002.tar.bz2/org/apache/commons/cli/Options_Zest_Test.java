package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Options_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a\u516a\u0510\u04df\u00a6\uc1ad\u5fc8\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2",
        46, 67466, 1016244366, -7166270042699976703L, 21825L, false, false, (char) 34009, (char) 20356,
        Double.longBitsToDouble(0x3fe09fbd39346371L), Double.longBitsToDouble(0x3fe0e69e55ae071fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\udb08\udd86\ud801\udce7\udbee\udc23\u8aca\ud99d\udca1\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u2102\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u47a6\u515d\u0510\u04df\u00a6\uc1ad\u5fc8\u8ec9\u8340", "\ud97f\udc6c\ud9f9\udc46\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2",
        54, 64352, 1016244366, -7166270042699976703L, -93233L, true, true, (char) 1322, (char) 6004,
        Double.longBitsToDouble(0x3fdc2d5f60f95970L), Double.longBitsToDouble(0x3f9ff74b529641c0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 3, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\udbbc\udef4\ud8fc\udd5c\udb28\udd81\udb3c\udf33\ud962\udfae", "\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5", "\udaca\udf6b\uda6c\ude25\ud844\udef1",
        57, 516, -1679038389, 907080448385576841L, 37957L, true, false, (char) 23779, (char) 5524,
        Double.longBitsToDouble(0x3fcf538aef55c8b4L), Double.longBitsToDouble(0x3fe3182187efab4cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\uda68\udcaa\ud80a\udccd\u5281\ud95a\uddd4", "\u49a5\u4af7\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a\u516a\u0510\u04df\u00a6\uc1ad\u5fc8\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2",
        46, 67466, 1016244366, -7166270042699976703L, 21825L, false, false, (char) 34009, (char) 20356,
        Double.longBitsToDouble(0x3fe09fbd39346371L), Double.longBitsToDouble(0x3fe0e69e55ae071fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 4, "\udb08\udd86", "\u48b4\u71a6\u0137\u0df5\u84a9\u531b\ubf2b\u5293\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a\u516a\u53d0\u9e59\u0134\uc1ad\u5fc8\u0f5b\u8340\ub6e8\u11bb\u5b6d\ua9a9", "\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2\ud9ed\udfd2\udb60\uddc3\udb07\udf7b\udbeb\udf3a",
        58, 63776, -1145051759, -2533739134379611965L, 21825L, false, false, (char) 34009, (char) 20356,
        Double.longBitsToDouble(0x3fe09fbd39346371L), Double.longBitsToDouble(0x3fe0e69e55ae071fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 3, "\udb08\udd86\ud801\udce7", "\u71a6\u0137\u0df5\u84a9\u531b\u0f87\u5293\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u1762\u760a\u516a\u0510\u04df\u00a6\uc1ad", "\ud8f5\udc07\ud856\ude69",
        19, 95215, -1288863320, 8227321446845670357L, 86116L, false, false, (char) 15177, (char) 46173,
        Double.longBitsToDouble(0x3fef163e108edc10L), Double.longBitsToDouble(0x3feae9e490019c8cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 9, "\udb44\udd84\ud801\udce7\udb04\udd2f\udb34\udffe\uda75\ude0b\ud8d2\udea4\uda86\udfc3\udbb9\udf1d", "\ub4fc\u43f2", "\udac5\udf20",
        37, 92157, -333719712, 8711871558556005691L, 4674L, true, true, (char) 57057, (char) 41941,
        Double.longBitsToDouble(0x3fb2c56146ecdf58L), Double.longBitsToDouble(0x3fec4864b4e8a4b9L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 0, "\udb08\ude3a\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b", "\ubf2b\u5293\u0d01\u4444\u122c\u6138\u5e75", "\udbef\udf93\ud9a3\udc0a\udaba\udc6b\uda6c\ude25\uda8f\udeb6\ud98b\udfe0\udab0\udc68\ud86e\ude65\udba2\udd9a\udbe7\ude27\ud8f5\udc07\ud856\ude69\ud8c3\uddda\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud8ff\udf02\udb55\udd57\uda4d\udd33\udbac\udff2\ud9ed\udfd2\udb60\uddc3\udb4f\udc1f\udb5b\ude41\udaa2\udfcd\uda98\udf51\ud92e\udd8b\ud9f1\udf9b\udb60\udc2c\udb31\udf2d\uda5a\udcd9\udaa3\udff8\ud819\udf87\ud97f\ude27\ud946\udfe6",
        37, 82683, -741713612, 513408279246273966L, 2547L, true, true, (char) 64470, (char) 5408,
        Double.longBitsToDouble(0x3fe4ce69096b3f11L), Double.longBitsToDouble(0x3fd54812b64a6862L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 12, "\udb08\udd86\ud801\udce7\udb7c\udeca\udbab\udcd8\udba8\udfdf\ud82c\udd08\ud996\udd70\ud91d\udd29\ud94e\udce4", "\u47c1\ua076\u122c\u6138\u5e75\u2580\ua1bc\u7c00\u7172\u760a\u0e25\u0510\u04df\u00a6\u0d89\u6672\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\ud8ba\udcb4\ud855\udd65\ud9c3\ude6e\uda15\udd94\udb58\ude9d\udb85\udc89",
        46, 67466, 1916508064, -9193620616253919152L, 75566L, true, true, (char) 24171, (char) 58370,
        Double.longBitsToDouble(0x3f9690f40aa22180L), Double.longBitsToDouble(0x3fe09fbd39346371L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 3, "\uda34\udda9\uda21\udc13\udb04\udd2f", "\u0137\u0df5\u84a9", "\udbb9\udfc6",
        29, 97261, -507603448, -889768948902120051L, -83717L, false, true, (char) 38808, (char) 19170,
        Double.longBitsToDouble(0x3fd821ccc80a284aL), Double.longBitsToDouble(0x3fdd3c90ee481964L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\udb0d\udd09\ud801\udce7\udb04\udd2f\ud865\udd98\uda4c\ude42\ud82c\udd08\u2c6b\u5281\ud95a\uddd4\ud972\udd75\udbb9\udfc6\udb34\uddf8\ud9d2\udf5c\uda15\udc3f\udac5\udf20\ud803\udc67\udb17\udd7c\udbf5\ude6d\udbf4\udc25\ud9a2\udf64\udaba\udc6b\uda6c\ude25\ud844\udef1\uda05\ude92\udab0\udc68\ud86e\ude65\udba2\udd9a\udbe7\ude27\ud8f5\udc07\ud856\ude69\ud8c3\uddda\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2\ud9ed\udfd2\udb60\uddc3\udb4f\udc1f\uda59\udd80\ud871\udd72\uda98\udf51", "\u7ddb\u6fd5\u2b0e\uce2a\u77bd\u327e\u3a41\uc61d\u9fef\u34ce\uae8d\u0174\u18af\ucc39\ud10a\u5252\u6a84\u0b1a\u421e\u9389\u6e3d\uab84\u56fd\u43b4\u8ad9\u1351\u2ef9", "\ud8ea\udde0\udb39\udeaa\uda7a\udece\ud825\ude3f\ud8db\ude0f\udbaf\udfb8\udabd\udd7b\ud96b\udc71\ua058\udb34\udff2\ud913\udd1d\ud8d5\udda3\ud89c\udfe0\ud95e\udfa8\u9269\ud93d\udea5\udb2a\udcd9\ud952\udca2\udb0c\udf8a\ud9f2\udfd9",
        55, 28057, 1524573272, 8721988152332711419L, 81350L, false, false, (char) 46251, (char) 61170,
        Double.longBitsToDouble(0x3fec6a8cca051d6cL), Double.longBitsToDouble(0x3fd85141849c3fb0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:[ Options: [ short {} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 15, 14, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\u5237\ud95a\uddd4", "\uc4a2\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u8bd1\ub7bd\u516a\u0510\u04df\u00a6\uc1ad\u5fc8\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2",
        46, 61066, 1016244366, -7166270042699976703L, 89841L, false, true, (char) 19966, (char) 6004,
        Double.longBitsToDouble(0x3fdc2d5f60f95970L), Double.longBitsToDouble(0x3f9ff74b529641c0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 14, 12, "\ud8c7\udc66\ud81f\udc0d\udaaa\udcc4\udb35\udc1b\ud99d\udc9f\ud82c\udd08\u2c6b\u60a2\ud95a\udd27", "\u0d01\u4444\u0c9d\u5318\u1d2f\u68ea\u0643\u8a60\u5992\u2e04\u5174\uada1\u04df\u00a6\uc1ad\ucf7b\uce6d\u83fd", "\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udae0\ude47\udbac\udff2",
        46, 67466, 1016244366, -7166270042699976703L, -11075L, false, false, (char) 32217, (char) 38481,
        Double.longBitsToDouble(0x3fc40bb3d955b1f8L), Double.longBitsToDouble(0x3fe0e69e556b071fL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud830\ude08\u2c6b\u5281\udb08\udcea", "\u0d01\u4444\u122c\u13f4\u5e75\u355c\u37f5\u1051\u9127\u7761\u69e4\u0510\u04df\u00a6\uc1ad\u5fc8\u0f5b\u8340\ub6e8\u11bb\u5b6d\u24ed\u97a2", "\ud9d5\udcc8",
        29, 29654, -943572189, -2589442370221987698L, 21825L, false, false, (char) 34009, (char) 61572,
        Double.longBitsToDouble(0x3fe17a38f254ddabL), Double.longBitsToDouble(0x3fe90d6d1928912fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 14, 14, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a\u516a\u0510\u04df\u00a6\uc1ad\u5fc8\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\ud987\udc2f\ud827\ude60\udb0e\udeb3\ud9d5\udcc8\udb58\uddba\udbac\udff2",
        46, 67466, 1016244366, -7166270042699976703L, 20637L, false, true, (char) 33720, (char) 21812,
        Double.longBitsToDouble(0x3f9ff74b529641c0L), Double.longBitsToDouble(0x3fa61e56802b7820L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 0, 14, 12, "\udb08\udd86\ud801\udce7\ud8a6\udc1f\uda6d\udd05\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u9088\u5c5e\u37f5\u1051\u9127\u760a\u516a\u0510\u04df\u00a6", "\udbe7\ude27\ud8f5\udc07\ud856\ude69\ud8c3\uddda\udb37\udfc9\ud9f4\udde7\udaf5\udfeb\ud898\udfa4\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2\ud9ed\udfd2\udb60\uddc3\udb4f\udc1f\uda59\udd80\ud871\udd72\uda90\udfcb\ud92e\udd8b\uda6e\ude32\udb60\udc2c\udb31\udf2d\uda5a\udcd9\udaa3\udff8\ud819\udf87\udad1\ude2a\udaba\udddf\ud82b\udf84\ud8ed\udfef\u7e99\udab2\udc01\ud95d\udc89\udb17\udf40\u3080\ud382\uda20\udc75\ud946\udf82\ud948\udc2d",
        52, 41761, -1707105530, -1963287508801896818L, -51222L, true, false, (char) 63068, (char) 23696,
        Double.longBitsToDouble(0x3fe23b98c82efd2cL), Double.longBitsToDouble(0x3fdf00ce4782f9acL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 9, 14, 12, "\udb08\udd86\ud801\udce7\uda9e\udf1c\uda22\udfb6\ud97b\ude97\ud84c\udcae\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u2953\u316e\u5e75\u2d2c\u6de7\ub97b\u45f7\u760a\u516a\u0510\u04df\u00a6\uc1ad\u5fc8\u12c8\u82c0", "\udaaa\udd81\udb2d\udfba\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2",
        46, 67466, 1016244366, -7166270042699976703L, -9359L, false, false, (char) 1434, (char) 50804,
        Double.longBitsToDouble(0x3fc85828c1f2b2e0L), Double.longBitsToDouble(0x3f9ff74b529641c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 9, 6, 12, "\udb22\udf98\ud801\udce7\udacb\udf92", "\u0137\u0df5\u84a9", "\uda7b\ude8f\udb7f\udc39\ud9d6\udfb2\uda15\udc3f\udac5\udf20\ud803\udc67",
        20, 59595, 2028390662, 7534299231004740057L, -31950L, true, true, (char) 41941, (char) 64975,
        Double.longBitsToDouble(0x3fcbb37d6cf76658L), Double.longBitsToDouble(0x3fe293f5cd01306fL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 14, 11, 3, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a\uc14c\uc975\u047a\u00a6\uc1ad\u5fc8\u0f5b\u8340", "\ud927\udfc8\udabd\uddaa\ud93e\udf21\ud898\udf65\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbfd\udf3b",
        51, 67284, 1016244366, -7166270042699976703L, 21825L, false, false, (char) 34009, (char) 19467,
        Double.longBitsToDouble(0x3fe09fb921346371L), Double.longBitsToDouble(0x3fe0e69e5550071fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.util.HashSet:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\ud864\ude88\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u5e75\u3caa\u37f5\u1051\u9127\u760a\u516a\u0510\u04df\u00a6\uc1ad\u5fc8\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2",
        46, 67466, 1016244366, -7166270045048786943L, -20300L, false, true, (char) 1434, (char) 6004,
        Double.longBitsToDouble(0x3fdc2d5f60f95970L), Double.longBitsToDouble(0x3f9ff74b529641c0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 11, "\udb4d\uddb1\ud801\udcec\udb04\udd2f\uda54\udfaf\ud985\udc9f\udb1c\udd80\ud930\uddd5\u5281\ud947\udd74", "\u0d01\u4444\u122c\u575b\u8456\u5e9b\u37f5", "\ud8dc\udfde\udb4b\udc91\ud8c8\udd58",
        3, 516, 1423617611, 909072364023163785L, 37957L, false, true, (char) 51558, (char) 65098,
        Double.longBitsToDouble(0x3fd066cd73b87460L), Double.longBitsToDouble(0x3f9a748501568100L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\ud92a\uddd5", "\u48b4\u71a6\u0137\u0df5\u84a9\u531b\ubf2b\u5293\u0d01\u4444\u122c\u6138\u5e75\u2580", "\ud9a2\udf64",
        13, 76242, -921766354, 914817670652991268L, -8061L, true, true, (char) 31137, (char) 11448,
        Double.longBitsToDouble(0x3fdcb787393e7888L), Double.longBitsToDouble(0x3fee3d6ff0fa9c57L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.HashSet:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 8, 12, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f", "\u84a9\u531b", "\udb17\udfaa\ud9d2\udf5c\uda15\udc3f\udac5\udf20\udaaf\udc5c\uda7e\uddc1\udbf5\ude6d\udbf4\udc25\ud9a2\udf64\udaba\udc6b\udaee\ude65\ud854\ude9b\ud9a7\udf16\udac5\udf86\ud86e\ude65\udba2\udd9a\udbe7\ude27\ud8f5\udc07",
        34, 16909, -136229125, -7150596186252164870L, -34877L, true, true, (char) 24666, (char) 15177,
        Double.longBitsToDouble(0x3fe91bc9d3e2c7c2L), Double.longBitsToDouble(0x3fc1db820d74f248L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 0, 0, 0, "\udb08\udd86\ud801\udce7\udb04\udd2f\000\ud96b\uddb4\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a\u516a\u0510\u04df\u00a6\uc1ad\u5fc8\u0f5b\u8340", "\000",
        8, 1378, 70280149, -6103223692458033169L, -2926L, true, true, (char) 15269, (char) 33950,
        Double.longBitsToDouble(0x3feae9e490019c8cL), Double.longBitsToDouble(0x3fef02e2c5913a70L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 1, 8, "\udb08\uddcd\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f", "\u84a9\u531b", "\udb36\udc09\ud9d2\udef4\uda15\udc3f\udbb8\ude19\ud803\udc74\udb17\udd7c\udbf5\ude6d\udbf4\udc25\ud9a2\udf64\udaba\udc6b\uda6c\ude25\uda80\udc27\ud91d\uddc1\ud9ed\ude24\udba6\udc28\ud9f2\udff4\udbe7\ude51\ud8f5\udc07",
        10, 16909, -1375826785, -7181042625297956614L, 7107L, true, true, (char) 24666, (char) 15177,
        Double.longBitsToDouble(0x3fe91bc9d3e2c7c2L), Double.longBitsToDouble(0x3fc1db820d74f248L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4\ud972\udd75\udbb9\udfc6\udb34\uddf8\ud9d2\udf5c\uda15\udc3f\uda8f\ude20\udadf\udf95\udb17\uddee\udbf5\ude6d\udbf4\udc25\ud9a2\udf64\udb38\uddb7\udb2e\udeb4\udbf0\udfc7\uda05\ude92\udab0\udc68\udb58\ude5a\udba2\udd9a\udbe7\ude27\ud8f5\udc07\ud856\ude69\ud8c3\uddda\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9d5\udcc8\ud907\udd71\udbbc\udc90\ud9ed\udfd2\udb60\uddc3\udb4f\udc1f\uda59\udd80\ud871\udd72\uda98\udf51\ud92e\udd8b\ud952\udf6c\ud803\udca0\udb2b\uddf5\uda5a\udcd9\udaa3\udff8\ud819\udf87\ud97f\ude27\ud946\udfe6\ud82b\udf84\ud8ed\udfef", "\u0120\u7343\u2ddb\u2864\u51d5\u59ba\u0556\u5ca3\u87aa\uc7f1\u8635\u6e36\uacd0\ua358\u86f0\ua36c\ua1de\u82ff\u3a32\u8f37\u7952\u1acb\u08d8\uc49d\u377a\u7d27\u4ab9\ua32b", "\uda7a\udcda\ud8e0\udc91\uda02\udca4\ud84d\udff3\udb20\udf38\udb6e\uddd9\ud908\udd2a\udab0\udf34\ud952\ude5b\udbb7\udfaf\udaca\udf4e\ud960\udf42\uda0d\udc68\udbdc\uddae\ud82b\udef3\udaa7\udfe5\ud8b3\udee7\udaf2\uddef\u41b5\uda82\udc12\udb1d\ude32\uda70\udcf3\udafa\ude72\ud8d3\udc07\udae4\udc8c\ud838\uddcd\udba5\udc61\udad6\uddac\udbb0\udd83\udbf5\udf5e",
        9, 21107, -210846470, -4241435683956586990L, 66750L, true, false, (char) 56796, (char) 10355,
        Double.longBitsToDouble(0x3fed4252666a25c3L), Double.longBitsToDouble(0x3fca947e6446240cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 3, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udaac\udcdb\ud99d\udc66\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u2e7c\u1447\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a", "\uda05\ude92\udab0\udc68\ud86e\ude65\udba2\udd9a\udbe7\ude27\ud8f5\udc07",
        1, 16909, -1375826785, -7181042625297956614L, -34877L, true, true, (char) 24666, (char) 24460,
        Double.longBitsToDouble(0x3fe3d16e2ba229e0L), Double.longBitsToDouble(0x3fc1db820d74f248L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 10, 10, 11, "\udaf9\udee0\ud96e\udd35\ud92f\udef7\udafc\udc98\ud99d\udc9f\udaf0\udd03\ud875\udd2b\u5281\uda09\udf0a", "\u3ccf\u4444\u122c\u6138\u5e5d\u2580\u37f5\u1051\u9127\u760a\uab5f\uc838\u629d\u00a6\uc1ad\u5fc8\u0f5b\u90ba", "\udb37\udfc9\ud9f4\udde7\uda07\udfb4\ud899\udc14\ud884\udd65\ud9ef\udc29\udbb4\udf28\udbac\udff2\uda50\udfcb\udbe2\ude03\ud8cd\ude62\ud980\udd6d\ud9de\ude54\uda98\udf51\udabd\udfd3\ud9f1\udf9b\udb60\udc2c",
        -1, 49962, -2040878980, 4879961944358458516L, 36388L, false, false, (char) 1229, (char) 12586,
        Double.longBitsToDouble(0x3feb133e0aba946bL), Double.longBitsToDouble(0x3fe90af987f761c2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\000", "\u48b4\uc6eb\000\000\000\u531b\ubf2b", "\ud9d2\udf5c",
        7, 85304, -326879859, 5119142850860957595L, 25485L, false, true, (char) 64975, (char) 13512,
        Double.longBitsToDouble(0x3fec4864b000a4b9L), Double.longBitsToDouble(0x3fd1bf11a49ba48aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "", "\u76e0", "",
        1, 4158, -2112898579, -8619378547779120105L, -100000L, true, false, (char) 31340, (char) 51609,
        Double.longBitsToDouble(0x3fd8df3a629bd908L), Double.longBitsToDouble(0x3fecda385106ec0cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 0, 14, 12, "\u414b\ufbdf\udb04\udd2f\udb34\udffe\ud99d\udc9f\uda9d\udf61\u0086\ud826\udc93\ud95a\uddd4", "\u4b00", "",
        24, 56141, 1191893325, -1437704244057159418L, -15559L, false, false, (char) 33761, (char) 57057,
        Double.longBitsToDouble(0x3fe92065904b1585L), Double.longBitsToDouble(0x3fcbb37d6e243258L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 6, 0, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\ud9c3\ude37\udb37\udc9d", "\u9bc4\uc173\u122c\u6138\u5e75\u2580\u77ed\u1051\u9127\u760a\u67a3\uce53\u60f8\u00a6\u520a\ucb0a\u0f5b\u8340\ub6e8\u2732\u9839\ua9a9\u984c\u0082\u2200\u2177\u5f51\u447c\u907a\u894a\u8685\ud57d\u6d73\u8d23\uccac\u1002\u5783\u6fd5\ud0e7\u9627\u4a5f", "\ud82b\udf84\ud8ed\udfef\u7e99\ud9d7\ude87\ud879\udfbc\ud9c9\udd51\ud9fb\udd4a\uda80\udf43\ud95d\udc9f\ud8b6\udea5\ud92c\ude20\ud880\udfae\udacf\ude53\ud883\udd7d\ud879\ude71\udb3f\udddb\ud99b\udc39\udb33\ude94\udba9\udf34\ud855\udf8b\uda0f\udc4b",
        15, 38141, 1131042661, 3404340980414521140L, -24173L, true, false, (char) 36416, (char) 1986,
        Double.longBitsToDouble(0x3fcd05fcf868804cL), Double.longBitsToDouble(0x3fd2c1c77539954eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 3, "\udb85\udfab\ud9b0\udd1a\udb04\udd2f\udb34\udffe\udbbc\udef4\ud8d2\udd71\uda95\ude18\udb3c\udf33\ud962\udfae", "\u0d01\u4444\u122c\u6138\u3276\u2580\u37f5", "\ud833\udc83\ud91d\uddfd\ud844\udef1",
        10, 74513, -1679038389, 907080448385576841L, 37957L, true, false, (char) 57367, (char) 57884,
        Double.longBitsToDouble(0x3fcf538aef55c8b4L), Double.longBitsToDouble(0x3fe3182187efab4cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 6, 6, 9, "\ud9bf\ude47\ud801\udce7\udb04\udd2f\udb34\udffe\udbbc\udef4\ud9b4\udca0", "\u74f5\u2401", "\u7a78\ud8d4\udfaf\uda04\udeac\uda6c\udd88\uda71\udfca\udbf5\ude1a\udbf4\udc25\ud8cc\uddba\udbba\udefc",
        14, 7230, 213026404, 1550811825580927051L, 68074L, false, false, (char) 54837, (char) 27794,
        Double.longBitsToDouble(0x3fc3e7889d16113cL), Double.longBitsToDouble(0x3fcf538aedbdc8b4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 3, "\u823f\ud801\udd83\udb04\udd2f\udb34\udffe\ud84b\uddfa\ud8fc\udd5c\udb28\udd81\udb3c\udf33\udb57\udf7d", "\u751e", "\udac5\udf20",
        1, 92325, -334739774, 8711871558556005691L, 62916L, false, false, (char) 57057, (char) 41941,
        Double.longBitsToDouble(0x3fb2c56146ecdf58L), Double.longBitsToDouble(0x3fec4864b63955b9L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 12, "\u0c74", "\u5219\u80aa\u0137\u6a0c\ua816\u222b\ubf2b", "\ud957\ude55\uda6e\uddfb",
        48, 56141, 1191893325, 786792496885583907L, -31950L, true, true, (char) 41941, (char) 64975,
        Double.longBitsToDouble(0x3fec3b175b890c96L), Double.longBitsToDouble(0x3fcd1497346fc468L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:[ Options: [ short {} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 12, "\udb08\udd86\ud801\udce7\udb7c\udeca\udbab\udcd8\udba8\udfdf\ud82c\udd08\ud996\udd70\ud91d\udd29\ud94e\udce4", "\u47c1\ua076\u122c\u6138\u5e75\u2580\ua1bc\u7c00\u7172\u760a\u0e25\u0510\u04df\u00a6\u0d89\u6672\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\ud8ba\udcb4\ud855\udd65\ud9c3\ude6e\uda15\udd94\udb58\ude9d\udb85\udc89",
        46, 67466, 1916508064, -9193620616253919152L, 75566L, true, true, (char) 45173, (char) 58370,
        Double.longBitsToDouble(0x3f9690f40aa22180L), Double.longBitsToDouble(0x3fe09fbd39346371L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.Collections$UnmodifiableCollection:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 9, 9, 6, "\ud908\udc5b\ud801\udce6\udb7c\udeca\udbab\udcd8\udba8\udfdf\ud82c\udd08\ud996\udd70\ud91d\udd29\ud94e\udce4", "\u47c1\ua076\u122c\u6138\u5e75\u2580\ua1bc\u7c00\u7172\u760a\u8c44\uabc9\u04df\u00a6\u0d89\u6672\u377c\u138a", "\udb37\udfc9\ud9f4\udde7\ud8ba\udcb4\ud855\udd65\ud9c3\ude6e\ud981\udc48\udb58\ude9d\udb85\udc89",
        46, 67466, 1916508064, -9193620616253919152L, 75566L, true, true, (char) 24171, (char) 58370,
        Double.longBitsToDouble(0x3f9690f40aa22180L), Double.longBitsToDouble(0x3fe09fbd39346371L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 12, "\u1457\ud801\udd2f\udb7c\udeca\ud801\udea5\uda42\udee4\ud97c\udca7\ud996\udd29\ud91d\udd29\uda2d\udea8", "\u4b41\u0d54\u1253\u6138\u831e\u2580\ua1bc\ub3db\u60e0\u2553\u0e25\u0510\u04df\u00a6\u0d89\u6672\u0f8d\u8340\ub6e8", "\ud9f4\udde7\ud8ba\udcb4\ud855\udd65\udb5b\udf3b\uda15\udd94\u09e8\udb5a\udc2b\ud8f5\udf82\ud88d\udc6d\uda82\udfd7\uda14\ude15\ud8b0\ude78\uda2b\ude1a\ud92e\udd8b\ud8e5\udf95",
        39, 75944, -1686721074, -627287521143724257L, 44877L, false, true, (char) 5585, (char) 31749,
        Double.longBitsToDouble(0x3fe951f182c7f3b3L), Double.longBitsToDouble(0x3fec3c6098dbbbbdL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 13, 13, 11, "\udb08\udd86\ud801\udce7\udb7c\udeca\udbab\udcd8\udba8\udfdf\ud82c\udd08\ud996\udd70\ud91d\udd29\ud94e\udce4", "\u47c1\ua076\u122c\u6138\u5e75\u2580\ua1bc\u7c00\u7172\u760a\u0e25\u0510\u04df\u00a6\u053c\u6672\u0f5b\u8340", "\udb37\udfc9\ud9f4\udde7\ud8ba\udcb4\ud855\udd65\ud9c3\ude6e\uda15\udd94\udb58\ude9d\udb85\udc89",
        46, 59530, 1916508064, -9193620616253919152L, 75566L, true, true, (char) 24171, (char) 58370,
        Double.longBitsToDouble(0x3f9690f40aa22180L), Double.longBitsToDouble(0x3fe09fbd39346371L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 12, "K\000\udb7c\udeca\udbab\udcd8\udba8\udfdf\ud82c\udd08\ud996\udd70", "\ubf2b\u55af\u47c1\000\u2b42\u0fdc\u5de8\u2580\ua1bc\u7c00\u7172", "\ud844\udef1\uda05\ude92\udab0\udc68\ud965\ude1f\udba4\udc44\udbe7\ude27\ud8f5\udc07\ud856\ude69\ud81e\udde8\u04ae\000\ud8ba\udcb4\ud855\udd65\ud9c3\ude6e\uda15\udd94\udb58\ude9d\udb85\udc89\ud9ed\udfd2\udb60\uddc3\ud95f\ude5b\ud862\udf3d",
        54, 83032, -1145051759, -2563575481910941501L, 75566L, true, true, (char) 24171, (char) 58161,
        Double.longBitsToDouble(0x3f9690f40aa22180L), Double.longBitsToDouble(0x3fe09fbd39346371L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 12, "\udb08\udd86", "\u5219\u80aa\ua9dd\u6175\000\u61c6\ubf2b", "",
        48, 21552, -207165477, 606782282061L, 31072L, false, false, (char) 18688, (char) 28710,
        Double.longBitsToDouble(0x3fa7468050000000L), Double.longBitsToDouble(0x3fe80065904b1585L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 12, "\000\000\000\udac1\udd04\000\ud82c\udd08\ud996\udd70\ud91d\udd29\u9ff1", "\u4b9f\uaf52\u122c\u6138\u5e75\u2580\ua1bc\u7c00\u7172\u760a\u559d\000\000\u90e3\u0d89\u6672\uab89\000", "",
        42, 87223, 9443066, -4467570831767774360L, -38291L, false, true, (char) 15139, (char) 51138,
        Double.longBitsToDouble(0x3fed000002c2723bL), Double.longBitsToDouble(0x3fb4201a7f034000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 0, 0, 0, "\ud8c7\udc66", "\000", "\udbc1\udc65",
        35, 13372, -749087721, 4785518655904238568L, 58200L, false, true, (char) 10575, (char) 6359,
        Double.longBitsToDouble(0x3fec1a5212edfef2L), Double.longBitsToDouble(0x3e4ad55400000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ]\0121=java.util.ArrayList:[[ option:   ::  :: class java.lang.String ]] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 2, 14, 12, "", "", "\ud99d\udc9f",
        1, 4158, -368068115, -8619379290802629609L, -15032L, true, false, (char) 100, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fec1a5212edfef2L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 12, 12, 12, "\udb08\udd86\ud801\udce7\ud8a6\udc1f\uda6d\udd05\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u9088\u5c5e\u37f5\u1051\u9127\u760a\u516a\u0510\uab89\u8ca4", "\udbe7\ude27\ud8f5\udc07\ud856\ude69\ud8c3\uddda\udb37\udfc9\ud9f4\udde7\udaf5\udfeb\ud898\udfa4\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbac\udff2\ud9ed\udfd2\udb60\uddc3\udb4f\udc1f\uda59\udd80\ud871\udd72\uda90\udfcb\ud92e\udd8b\uda6e\ude32\udb60\udc2c\udb31\udf2d\uda5a\udcd9\udaa3\udff8\ud819\udf87\udad1\ude2a\udaba\udddf\ud82b\udf84\ud8ed\udfef\u7e99\udab2\udc01\ud95d\udc89\udb17\udf40\u3080\ud382\uda20\udc75\ud946\udf82\ud948\udc2d",
        52, 41761, -1707105530, -1963287508801896818L, -51222L, true, false, (char) 63068, (char) 23696,
        Double.longBitsToDouble(0x3fe23b98c836fd2cL), Double.longBitsToDouble(0x3fdf00ce4782f9acL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 11, 11, 3, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb35\udc2e\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u5e75\u2580\u37f5\u1051\u9127\u760a\uc14c\uc975\u047a\u00a6\u7dad\u5fc8\u0f5b\u8340", "\ud927\udfc8\udabd\uddaa\ud93e\udf21\ud898\udf65\ud884\udd65\ud9d5\udcc8\udb58\uddba\udbfd\udf3b",
        51, 67284, 1016244366, -7166270042699976703L, 44927L, true, true, (char) 1434, (char) 6004,
        Double.longBitsToDouble(0x3fdc2d5f60f95970L), Double.longBitsToDouble(0x3f9ff74b529641c0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.HashSet:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 0, "", "", "\uc6eb",
        -5, -1000, -2105016320, 228697669489664L, -80568L, false, false, (char) 38407, (char) 51609,
        Double.longBitsToDouble(0x3fd8df3a6641d908L), Double.longBitsToDouble(0x3fecdec66106ec0cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 14, 1, 0, "", "", "\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4\ud972\udd75\udb71\udd63\udb36\udc09\000\uda15\udc3f\udbb8\ude19\ud803\udc74\000\udbf5\ude6d\udbf4\udc25\u0e5c\udaba\udc6b\uda6c\ude25\uda80\udc27\ud91d\uddc1\ud9ed\ude24\udba6\udc28",
        55, 25243, -249899800, 8441404981713869389L, -87655L, false, false, (char) 25602, (char) 42642,
        Double.longBitsToDouble(0x3f42b92000000000L), Double.longBitsToDouble(0x3fc9c0000c8de4e8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 3, "\u9e42\000\000\000\000\ud89b\udc0d\udb28\udd81\udb3c\udf33\udae3\udc03", "\u751e", "\udac5\udf20",
        1, 2989, -334739774, 8711871558556005691L, -100000L, false, false, (char) 0, (char) 41941,
        Double.longBitsToDouble(0x3fb2c56140000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f  :: \u40b3\u26ca\u1de8\ua4a5\ub399\u8af7\u0911 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f  :: \u40b3\u26ca\u1de8\ua4a5\ub399\u8af7\u0911 :: class java.lang.String ]} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 3, "\u823f", "\u40b3\u26ca\u1de8\ua4a5\ub399\u8af7\u0911", "\udb13\udfad\uda2e\ude3f\udac5\udf20\ud803\udc67\udb17\udd7c\udbf7\udd94\udbf4\udc25\ud9a2\udf64\udad0\udd32",
        48, 59646, 212997587, 1550811825894582347L, 43839L, false, false, (char) 48681, (char) 57728,
        Double.longBitsToDouble(0x3febaa849bf9369eL), Double.longBitsToDouble(0x3fe9ebc90d09636eL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 2, 12, "\u0c74", "\u5219\u80aa\u0137\u6a0c\ua816\u222b\ubf2b", "\ud957\ude55\uda6e\uddfb",
        48, 56141, 1191893325, 786792496885583907L, -31950L, true, true, (char) 34439, (char) 2482,
        Double.longBitsToDouble(0x3fed7da701c90c96L), Double.longBitsToDouble(0x3fcd0ae9746fc468L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\ub1e2=[ option: \ub1e2  :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\ub1e2=[ option: \ub1e2  :: null :: class java.lang.String ]} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 14, "\ub1e2", "\u3ab0\u80aa\u0137\u6a0c\ua816\u222b\u3999", "\ud957\ude55\uda6e\uddfb",
        48, 56084, 1191893325, 786792496887585754L, 99560L, false, true, (char) 54229, (char) 38406,
        Double.longBitsToDouble(0x3fec3b1589890c96L), Double.longBitsToDouble(0x3fcd1497346fc468L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \u00e0 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  :: \u00e0 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 2, 12, "\000", "\u00e0", "",
        51, 62555, -2006867983, -3217307261572381475L, -20419L, true, true, (char) 57824, (char) 0,
        Double.longBitsToDouble(0x3fd000000f368e14L), Double.longBitsToDouble(0x3fa18075d3b78ce0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u58df=[ option: \u58df  :: \u6e3e\u445b\u0137\u6a0c\ua816\u222b\ubf2b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u58df=[ option: \u58df  :: \u6e3e\u445b\u0137\u6a0c\ua816\u222b\ubf2b :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u58df=[ option: \u58df  :: \u6e3e\u445b\u0137\u6a0c\ua816\u222b\ubf2b :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u58df=[ option: \u58df  :: \u6e3e\u445b\u0137\u6a0c\ua816\u222b\ubf2b :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 2, 12, "\u58df", "\u6e3e\u445b\u0137\u6a0c\ua816\u222b\ubf2b", "\udb95\udfbd\uda6e\uddfb\udac5\udf20\ud803\udc67\udb17\udd7c\udada\udc3f\uda33\udf41\udaac\udcaa\ud92c\udc64",
        26, 59646, 213053775, 1550811829233248331L, 24809L, false, false, (char) 9014, (char) 46869,
        Double.longBitsToDouble(0x3fdfbddd208d8b04L), Double.longBitsToDouble(0x3fd7de8d05b2ce60L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\ud957\ude55\uda6e\udd8f\udac5\udf20\udb45\udce8\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64\uda5b\udee0\ud844\udef1\ud9ac\uddff\uda0f\udfd9\uda2e\ude0b\udba3\udfdc\uda11\udddc\ud956\uddbe :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\u25c1=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\ud957\ude55\uda6e\udd8f\udac5\udf20\udb45\udce8\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64\uda5b\udee0\ud844\udef1\ud9ac\uddff\uda0f\udfd9\uda2e\ude0b\udba3\udfdc\uda11\udddc\ud956\uddbe :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\ud957\ude55\uda6e\udd8f\udac5\udf20\udb45\udce8\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64\uda5b\udee0\ud844\udef1\ud9ac\uddff\uda0f\udfd9\uda2e\ude0b\udba3\udfdc\uda11\udddc\ud956\uddbe :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\u25c1=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\ud957\ude55\uda6e\udd8f\udac5\udf20\udb45\udce8\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64\uda5b\udee0\ud844\udef1\ud9ac\uddff\uda0f\udfd9\uda2e\ude0b\udba3\udfdc\uda11\udddc\ud956\uddbe :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282  :: \u5219\u80aa\u0137\ub3f2\u503d\u25c1 :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\u25c1=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\ud957\ude55\uda6e\udd8f\udac5\udf20\udb45\udce8\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64\uda5b\udee0\ud844\udef1\ud9ac\uddff\uda0f\udfd9\uda2e\ude0b\udba3\udfdc\uda11\udddc\ud956\uddbe :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282  :: \u5219\u80aa\u0137\ub3f2\u503d\u25c1 :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\u25c1=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\ud957\ude55\uda6e\udd8f\udac5\udf20\udb45\udce8\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64\uda5b\udee0\ud844\udef1\ud9ac\uddff\uda0f\udfd9\uda2e\ude0b\udba3\udfdc\uda11\udddc\ud956\uddbe :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 2, 3, "\u8282", "\u5219\u80aa\u0137\ub3f2\u503d\u25c1", "\ud9a6\udf57\ud957\ude55\uda6e\udd8f\udac5\udf20\udb45\udce8\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64\uda5b\udee0\ud844\udef1\ud9ac\uddff\uda0f\udfd9\uda2e\ude0b\udba3\udfdc\uda11\udddc\ud956\uddbe",
        16, 1054, 214050500, -7289016301597207851L, 77404L, true, false, (char) 23608, (char) 33499,
        Double.longBitsToDouble(0x3feeeb3fc1c0b2ccL), Double.longBitsToDouble(0x3fe39e01f5b7f33aL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   [ARG] :: null :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 2, 12, "", "\u2c72", "\000\ud9fc\udcde\ud91d\udd29\u9ff1\ud972\udd75\ud9b7\udce7\000\ud957\ude32\uda6e\uddfb",
        48, 78461, 1191893248, 786792496885583907L, -31950L, true, true, (char) 41941, (char) 5584,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e446fc468000000L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {K=[ option: K  [ARG] :: \u5219 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {K=[ option: K  [ARG] :: \u5219 :: class java.lang.String ]} ] [ long {} ]\0121=java.lang.Boolean:true |this=org.apache.commons.cli.Options:[ Options: [ short {K=[ option: K  [ARG] :: \u5219 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 12, 5, "K", "\u5219", "\ud996\udd70\ud91d\udd29\ud94e\udce4",
        1, 17885, -1187165281, -520093696L, 45561L, true, true, (char) 12358, (char) 12994,
        Double.longBitsToDouble(0x3fda778be3b3651eL), Double.longBitsToDouble(0x3fd9d6f89c5d1b66L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Option:[ option:   ::  :: class java.lang.String ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   ::  :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 2, 6, 14, "", "", "\ud99d\udc9f",
        1, 4158, -368068115, -8619379290802629609L, -15032L, true, false, (char) 100, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe80a5212edfef2L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: \uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd  [ARG] :: \udb8b\udeff :: class java.lang.String ]} ] [ long {\uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd=[ option:  \uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd  [ARG] :: \udb8b\udeff :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd  [ARG] :: \udb8b\udeff :: class java.lang.String ]} ] [ long {\uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd=[ option:  \uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd  [ARG] :: \udb8b\udeff :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 2, 3, 6, "", "\uaade\u1e95\u71a6\u950a\u0218\uba9b\ubdbd", "\udb8b\udeff",
        5, 39365, 33, -8672874059962078318L, 84248L, true, false, (char) 7770, (char) 42451,
        Double.longBitsToDouble(0x3fd35522982e6cfaL), Double.longBitsToDouble(0x3fe587f2c5b972f9L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:   :: null :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 1, 13, "", "\000", "\ud835\udde0\ud83d\udf6a\ud8d2\udfe1",
        -3, 28279, 1114215389, -2365150768619893507L, -38964L, false, false, (char) 38911, (char) 20933,
        Double.longBitsToDouble(0x3fe76ff79464b591L), Double.longBitsToDouble(0x3fe7143ffbc53e91L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    [ARG] :: \ud99d\udc9f :: class java.lang.String ]} ] [ long {=[ option:    [ARG] :: \ud99d\udc9f :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    [ARG] :: \ud99d\udc9f :: class java.lang.String ]} ] [ long {=[ option:    [ARG] :: \ud99d\udc9f :: class java.lang.String ]} ]\0121=java.util.Collections$SingletonList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:    [ARG] :: \ud99d\udc9f :: class java.lang.String ]} ] [ long {=[ option:    [ARG] :: \ud99d\udc9f :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 0, 12, "", "", "\ud99d\udc9f",
        1, 4158, -368068115, -8619379290802629609L, -15032L, true, false, (char) 100, (char) 0,
        Double.longBitsToDouble(0x3fd63fdbfc255616L), Double.longBitsToDouble(0x3fec1a5212edfef2L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f  :: \u40b3\u26ca\u12e8\u8594\u547c\u517b\u1e58 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f  :: \u40b3\u26ca\u12e8\u8594\u547c\u517b\u1e58 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f  :: \u40b3\u26ca\u12e8\u8594\u547c\u517b\u1e58 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f  :: \u40b3\u26ca\u12e8\u8594\u547c\u517b\u1e58 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 2, 2, 13, "\u823f", "\u40b3\u26ca\u12e8\u8594\u547c\u517b\u1e58", "\udb13\udf99\ud823\uddda\udac5\udf20\ud803\udc67\ud823\ude42\udb83\ude4b\udbff\udc40\ud86b\udfba\uda62\ude15\ud9be\ude73\ud844\udef1\uda05\ude92\udab0\udc68\uda81\ude81\ud871\udfac\ud8e5\udc8c\uda3a\udcda\ud993\udfb0\ud95c\udc10\ud8b3\udd7b\uda0a\udd18\uda27\udf09\ud83a\ude03\uda7f\udc6e\uda6a\udd7e\udad8\uded8\udb95\udd9b\udb64\ude28\ud85c\udf97\ud96f\udd0b\ud863\ude28\uda79\udd0c\ud90d\udd63\udb28\udf60",
        54, 23144, 1602651458, 8279667711041349654L, -10746L, false, true, (char) 7080, (char) 27203,
        Double.longBitsToDouble(0x3fa29beee14606f0L), Double.longBitsToDouble(0x3febabe2d7c83e92L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ] [ long {\u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ] [ long {\u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ] [ long {\u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u823f=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ] [ long {\u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911=[ option: \u823f \u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911  :: \udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 3, 13, "\u823f", "\u86e7\u26ca\u1de8\uc795\ub399\u8af7\u0911", "\udb13\udfad\uda2e\ude3f\uda41\udc5e\uda63\udc4f\udb17\ude0e\ud871\uddd5\udbf4\udcf3\ud9a2\udf64\udad0\udd32",
        48, 59646, 212997587, 1550811825894582347L, 43839L, false, false, (char) 1097, (char) 57728,
        Double.longBitsToDouble(0x3febaa849bf9369eL), Double.longBitsToDouble(0x3fecda010d09633eL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \u00e0  [ARG] ::  :: class java.lang.String ]} ] [ long {\u00e0=[ option: \000 \u00e0  [ARG] ::  :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\000=[ option: \000 \u00e0  [ARG] ::  :: class java.lang.String ]} ] [ long {\u00e0=[ option: \000 \u00e0  [ARG] ::  :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 1, 3, 13, "\000", "\u00e0", "",
        51, 62555, -2006867983, -3217307261572381475L, -20419L, true, true, (char) 57824, (char) 0,
        Double.longBitsToDouble(0x3fd000000f368e14L), Double.longBitsToDouble(0x3fc35b2d14ede338L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\0121=java.lang.Boolean:false |this=org.apache.commons.cli.Options:[ Options: [ short {} ] [ long {} ]\012",
        Z.run(T, 2, 13, 11, 12, "\udada\ude87\udb4f\udf9c\udbe2\udf89\uda26\udc00\uda8c\udc58\ud9d7\udfc2\udadf\udfc4\udb18\udf71\ud9f5\udebd\u610a\u4e38\ud90c\uddbe\uda87\udda7\ud90a\udc74\ud8a4\udcaa\ud813\udc2c\ud8a8\udd3f\ud913\udecb\udb1a\udf78\ud9bd\udd7b\udb05\udf60\udae9\ude1b\udaac\udf0d\ud807\udfea\ud9cf\ude1d\ud858\udf15\ud8b0\udcff\udb53\udf2d\ud8e1\udf9d\udbde\udcfb\udbe7\udd77\ud91c\ude64\ud88e\ude20\udbca\udde1\ud8b8\udf24\udb9e\ude1a\uda3b\udfa1\ud846\udfba\ud9ad\ude79\ud8a9\udf6d\ud832\udf57\udbd9\udcbd\udba5\udf96\udbcd\uddc5\ud886\udd95\ud977\udd7a\ud808\udedf\udae0\udd44\ud828\udf90\udaa6\ude53\udb91\udd4a\ud88f\udc30\uda1f\ude75\ud9e9\udecf\u1819\u9276\ud84a\udde1\ud899\udf19\udbea\udf55\ud879\udfde\ud6b6\udb93\udef8\udbc4\ude97\udb98\udda7\ud8c4\udcba\uda2d\ude9e\ud8b2\udc7b\udba8\ude01\uda29\udc4f\ud83e\udce9\uda3e\udc29\ud808\uded1\ud895\udfd0\u02e8\udb46\udd2c\ud80e\udfde\uda92\udd1d\ud94d\ude94\u40ce\ud837\ude4a\uda9c\udf66\ud99d\udd21\uda96\udefd\ud8d7\udfd8\ud900\ude6e\ud886\udd91\uda6e\udec3\uda2a\ude75\ud8a5\udf7b\udbfb\ude65\ud968\udefe\ud8f1\udfb8\udb4a\udf0f\uda80\udfc7", "\u8506\ua781\u63e4\uc9b2", "\udbe6\udfb7\uda10\udd28\ud8c2\uddde\udb12\udd87\udafc\udd3d\ud8bb\udcd3\uda98\udcb3\udb01\udccd\ud856\udc63\udbcf\udfe5\udb82\ude25\u2364\ud911\udde8\uda9d\udeca\udb25\udf8a\ud89d\udee1\udb2e\udebd\ud952\udde1\udbcf\ude7a\uda9d\udf33\uc89b\ud86d\udfa6\ud910\udcf1\u424c\uda6f\udf14\ud9ea\udefc\ud8e1\udcfe\udb86\udcf4\ud8c7\uddb2\ud8f9\udce7\udab8\udc83\ud990\udd4e",
        44, 83224, 1243889485, -3767177367714520711L, 27170L, false, false, (char) 31507, (char) 24666,
        Double.longBitsToDouble(0x3fd36af06af6eb8cL), Double.longBitsToDouble(0x3fd6747ad582c620L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  :: \u00e0 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  :: \u00e0 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 1, 2, 12, "@", "\u00e0", "",
        51, 62555, -2006867983, -3217307261572381475L, -85416L, true, true, (char) 57824, (char) 5626,
        Double.longBitsToDouble(0x3fd595870f368e14L), Double.longBitsToDouble(0x3fa18075b1f74ce0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\ua86c=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\ua86c=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\ua86c=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ] [ long {\u5219\u80aa\u0137\ub3f2\u503d\ua86c=[ option: \u8282 \u5219\u80aa\u0137\ub3f2\u503d\ua86c  [ARG] :: \ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 3, 3, "\u8282", "\u5219\u80aa\u0137\ub3f2\u503d\ua86c", "\ud9a6\udf57\ud957\ude55\ud9e0\uddef\ud879\udfdc\ud805\ude06\uda24\ude87\ud820\uddd8\udb6d\udd5c\udb72\udf11\ud92c\udc64",
        26, 59646, -330837212, 3322105258891103838L, 9449L, true, false, (char) 5124, (char) 29483,
        Double.longBitsToDouble(0x3fe6250e0e4b0cc2L), Double.longBitsToDouble(0x3fe6acd6c36ee544L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a  :: \ud98c\udcd8\ud885\udfc0\ud9cb\udf84\udba0\udc54\udaae\udd41\udb91\udf97\uda62\udf95\udab6\udef6\ud935\ude68\uda37\udd1f\ud8ed\udf50\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud8d1\udf5d\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6 :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a  :: \ud98c\udcd8\ud885\udfc0\ud9cb\udf84\udba0\udc54\udaae\udd41\udb91\udf97\uda62\udf95\udab6\udef6\ud935\ude68\uda37\udd1f\ud8ed\udf50\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud8d1\udf5d\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6 :: class java.lang.String ... |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a  :: \ud98c\udcd8\ud885\udfc0\ud9cb\udf84\udba0\udc54\udaae\udd41\udb91\udf97\uda62\udf95\udab6\udef6\ud935\ude68\uda37\udd1f\ud8ed\udf50\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud8d1\udf5d\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6 :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a  :: \ud98c\udcd8\ud885\udfc0\ud9cb\udf84\udba0\udc54\udaae\udd41\udb91\udf97\uda62\udf95\udab6\udef6\ud935\ude68\uda37\udd1f\ud8ed\udf50\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud8d1\udf5d\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6 :: class java.lang.String ...\0121=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282  :: \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a  :: \ud98c\udcd8\ud885\udfc0\ud9cb\udf84\udba0\udc54\udaae\udd41\udb91\udf97\uda62\udf95\udab6\udef6\ud935\ude68\uda37\udd1f\ud8ed\udf50\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud8d1\udf5d\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282  :: \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a  :: \ud98c\udcd8\ud885\udfc0\ud9cb\udf84\udba0\udc54\udaae\udd41\udb91\udf97\uda62\udf95\udab6\udef6\ud935\ude68\uda37\udd1f\ud8ed\udf50\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud8d1\udf5d\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 2, 3, "\u8282", "\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a", "\ud98c\udcd8\ud885\udfc0\ud9cb\udf84\udba0\udc54\udaae\udd41\udb91\udf97\uda62\udf95\udab6\udef6\ud935\ude68\uda37\udd1f\ud8ed\udf50\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud8d1\udf5d\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6",
        20, 10143, 1738070389, -4344154231574441901L, 96396L, false, false, (char) 16758, (char) 259,
        Double.longBitsToDouble(0x3fdfb682ed563db4L), Double.longBitsToDouble(0x3fedacf80f928263L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\ud483\u00de\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\udb89\ude4e\000\uda8b\udf45\udb45\udce8\000\ud820\udd1fy\udb72\ude67\ud92c\udc64\uda5b\udee0\ud844\udef1\ud324\000\000\000\uda11\udd53\udb1d\uddbc :: class java.lang.String ]} ] [ long {\u5219\ud483\u00de\ub3f2\u503d\u25c1=[ option: \u8282 \u5219\ud483\u00de\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\udb89\ude4e\000\uda8b\udf45\udb45\udce8\000\ud820\udd1fy\udb72\ude67\ud92c\udc64\uda5b\udee0\ud844\udef1\ud324\000\000\000\uda11\udd53\udb1d\uddbc :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\ud483\u00de\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\udb89\ude4e\000\uda8b\udf45\udb45\udce8\000\ud820\udd1fy\udb72\ude67\ud92c\udc64\uda5b\udee0\ud844\udef1\ud324\000\000\000\uda11\udd53\udb1d\uddbc :: class java.lang.String ]} ] [ long {\u5219\ud483\u00de\ub3f2\u503d\u25c1=[ option: \u8282 \u5219\ud483\u00de\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\udb89\ude4e\000\uda8b\udf45\udb45\udce8\000\ud820\udd1fy\udb72\ude67\ud92c\udc64\uda5b\udee0\ud844\udef1\ud324\000\000\000\uda11\udd53\udb1d\uddbc :: class java.lang.String ]} ]\0121=java.util.ArrayList:[] |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u5219\ud483\u00de\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\udb89\ude4e\000\uda8b\udf45\udb45\udce8\000\ud820\udd1fy\udb72\ude67\ud92c\udc64\uda5b\udee0\ud844\udef1\ud324\000\000\000\uda11\udd53\udb1d\uddbc :: class java.lang.String ]} ] [ long {\u5219\ud483\u00de\ub3f2\u503d\u25c1=[ option: \u8282 \u5219\ud483\u00de\ub3f2\u503d\u25c1  [ARG] :: \ud9a6\udf57\udb89\ude4e\000\uda8b\udf45\udb45\udce8\000\ud820\udd1fy\udb72\ude67\ud92c\udc64\uda5b\udee0\ud844\udef1\ud324\000\000\000\uda11\udd53\udb1d\uddbc :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 0, 0, "\u8282", "\u5219\ud483\u00de\ub3f2\u503d\u25c1", "\ud9a6\udf57\udb89\ude4e\000\uda8b\udf45\udb45\udce8\000\ud820\udd1fy\udb72\ude67\ud92c\udc64\uda5b\udee0\ud844\udef1\ud324\000\000\000\uda11\udd53\udb1d\uddbc",
        16, 1054, 214050500, -7289016301597207851L, 77404L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe8000001c0b2ccL), Double.longBitsToDouble(0x3fe39e01f0b7f33aL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u49f4\u0e56\u0cee\u8ed2\ua816\u55b9 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u49f4\u0e56\u0cee\u8ed2\ua816\u55b9 :: class java.lang.String ]} ] [ long {} ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 14, "?", "\u49f4\u0e56\u0cee\u8ed2\ua816\u55b9", "\udaeb\uddf2\ud8d6\udce5\ud919\ude59\ud941\udd48\ud92e\udf46",
        20, 2764, -1348085923, -7409959786604006803L, 99122L, true, true, (char) 58249, (char) 29811,
        Double.longBitsToDouble(0x3fe979a75017b056L), Double.longBitsToDouble(0x3fba7be575ee0048L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \ua6ea  :: \u7215\u2c6b\u60a2\ud95a\udd27\udb80\ude31\udb54\ude00\udb6a\udfce\udb9f\udcaf\000\udbfb\udfdd\ud91c\udc61\ud942\ude72\ud8ae\udc42 :: class java.lang.String ]} ] [ long {\ua6ea=[ option:  \ua6ea  :: \u7215\u2c6b\u60a2\ud95a\udd27\udb80\ude31\udb54\ude00\udb6a\udfce\udb9f\udcaf\000\udbfb\udfdd\ud91c\udc61\ud942\ude72\ud8ae\udc42 :: class java.lang.String ]} ] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \ua6ea  :: \u7215\u2c6b\u60a2\ud95a\udd27\udb80\ude31\udb54\ude00\udb6a\udfce\udb9f\udcaf\000\udbfb\udfdd\ud91c\udc61\ud942\ude72\ud8ae\udc42 :: class java.lang.String ]} ] [ long {\ua6ea=[ option:  \ua6ea  :: \u7215\u2c6b\u60a2\ud95a\udd27\udb80\ude31\udb54\ude00\udb6a\udfce\udb9f\udcaf\000\udbfb\udfdd\ud91c\udc61\ud942\ude72\ud8ae\udc42 :: class java.lang.String ]} ]\0121=java.util.ArrayList:[\ua6ea] |this=org.apache.commons.cli.Options:[ Options: [ short {=[ option:  \ua6ea  :: \u7215\u2c6b\u60a2\ud95a\udd27\udb80\ude31\udb54\ude00\udb6a\udfce\udb9f\udcaf\000\udbfb\udfdd\ud91c\udc61\ud942\ude72\ud8ae\udc42 :: class java.lang.String ]} ] [ long {\ua6ea=[ option:  \ua6ea  :: \u7215\u2c6b\u60a2\ud95a\udd27\udb80\ude31\udb54\ude00\udb6a\udfce\udb9f\udcaf\000\udbfb\udfdd\ud91c\udc61\ud942\ude72\ud8ae\udc42 :: class java.lang.String ]} ]\012",
        Z.run(T, 2, 3, 0, 6, "", "\ua6ea", "\u7215\u2c6b\u60a2\ud95a\udd27\udb80\ude31\udb54\ude00\udb6a\udfce\udb9f\udcaf\000\udbfb\udfdd\ud91c\udc61\ud942\ude72\ud8ae\udc42",
        31, 21392, 1715436385, -797297651577007712L, 65988L, false, true, (char) 2889, (char) 54670,
        Double.longBitsToDouble(0x3fd30b313969aff0L), Double.longBitsToDouble(0x3fde8fba17756c00L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {@=[ option: @  [ARG] :: \u00e0 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 1, 1, 7, 12, "@", "\u00e0", "",
        51, 62555, -2006867983, -3217307261572381475L, -85416L, true, true, (char) 57824, (char) 5626,
        Double.longBitsToDouble(0x3fd595870f368e14L), Double.longBitsToDouble(0x3fb0403aeaad3968L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7  :: \ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud999\udf61\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6\uda86\ude28\ud84c\udd81\udbad\udf8f\ud9c2\udf30\ud928\ude4c\ud8d9\ude91\udb50\uddfc\udb33\udfb1\ud8a9\udfb2\udaee\udd70\ud9bd\udfcc\udaca\udcf3\udbe7\udc4d\udbdb\udd52\udae4\udebb\udbe1\udd15\udaab\uddff\ud8e8\udce5\u0d1a\uda97\udd52\ud968\udc66\ud8b1\ude10\ud8e1\udf33\ud961\udf56\udb29\udcdb\ud9d0\udd45\ud925\udfd5\udbc5\ude39\udb66\udfbd\ud861\udf71\uda2c\ude42\udad7\udc83\udbf1\ude73 :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7  :: \ud847\uddfe\ud90d... |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7  :: \ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud999\udf61\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6\uda86\ude28\ud84c\udd81\udbad\udf8f\ud9c2\udf30\ud928\ude4c\ud8d9\ude91\udb50\uddfc\udb33\udfb1\ud8a9\udfb2\udaee\udd70\ud9bd\udfcc\udaca\udcf3\udbe7\udc4d\udbdb\udd52\udae4\udebb\udbe1\udd15\udaab\uddff\ud8e8\udce5\u0d1a\uda97\udd52\ud968\udc66\ud8b1\ude10\ud8e1\udf33\ud961\udf56\udb29\udcdb\ud9d0\udd45\ud925\udfd5\udbc5\ude39\udb66\udfbd\ud861\udf71\uda2c\ude42\udad7\udc83\udbf1\ude73 :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7  :: \ud847\uddfe\ud90d...\0121=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282  :: \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7 :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7  :: \ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud999\udf61\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6\uda86\ude28\ud84c\udd81\udbad\udf8f\ud9c2\udf30\ud928\ude4c\ud8d9\ude91\udb50\uddfc\udb33\udfb1\ud8a9\udfb2\udaee\udd70\ud9bd\udfcc\udaca\udcf3\udbe7\udc4d\udbdb\udd52\udae4\udebb\udbe1\udd15\udaab\uddff\ud8e8\udce5\u0d1a\uda97\udd52\ud968\udc66\ud8b1\ude10\ud8e1\udf33\ud961\udf56\udb29\udcdb\ud9d0\udd45\ud925\udfd5\udbc5\ude39\udb66\udfbd\ud861\udf71\uda2c\ude42\udad7\udc83\udbf1\ude73 :: ... |this=org.apache.commons.cli.Options:[ Options: [ short {\u8282=[ option: \u8282  :: \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7 :: class java.lang.String ]} ] [ long {\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7=[ option: \u8282 \u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7  :: \ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud999\udf61\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6\uda86\ude28\ud84c\udd81\udbad\udf8f\ud9c2\udf30\ud928\ude4c\ud8d9\ude91\udb50\uddfc\udb33\udfb1\ud8a9\udfb2\udaee\udd70\ud9bd\udfcc\udaca\udcf3\udbe7\udc4d\udbdb\udd52\udae4\udebb\udbe1\udd15\udaab\uddff\ud8e8\udce5\u0d1a\uda97\udd52\ud968\udc66\ud8b1\ude10\ud8e1\udf33\ud961\udf56\udb29\udcdb\ud9d0\udd45\ud925\udfd5\udbc5\ude39\udb66\udfbd\ud861\udf71\uda2c\ude42\udad7\udc83\udbf1\ude73 :: ...\012",
        Z.run(T, 2, 3, 2, 3, "\u8282", "\u4d4e\u80aa\u0137\ub3f2\u503d\u25c1\ubf2b\u27c8\u2477\u68c2\u6eab\u33af\u38a7\u9f48\uc9f1\u06d1\u4344\u5576\u0e25\uc528\u5c28\u53c6\u1772\u660a\u016e\ucf39\ucc6b\u1d9b\u0de3\u1e67\ub325\ua72a\u99b8\ua055\ub0a7", "\ud847\uddfe\ud90d\uddb2\udb78\udd95\uda5b\ude16\ud98f\ude8e\udb06\udc9f\ud999\udf61\ud868\udc69\udbff\udf7d\udbde\ude62\udade\udc64\uda08\udc0f\udac9\udd69\ud80c\ude5e\udb8f\uddc6\uda86\ude28\ud84c\udd81\udbad\udf8f\ud9c2\udf30\ud928\ude4c\ud8d9\ude91\udb50\uddfc\udb33\udfb1\ud8a9\udfb2\udaee\udd70\ud9bd\udfcc\udaca\udcf3\udbe7\udc4d\udbdb\udd52\udae4\udebb\udbe1\udd15\udaab\uddff\ud8e8\udce5\u0d1a\uda97\udd52\ud968\udc66\ud8b1\ude10\ud8e1\udf33\ud961\udf56\udb29\udcdb\ud9d0\udd45\ud925\udfd5\udbc5\ude39\udb66\udfbd\ud861\udf71\uda2c\ude42\udad7\udc83\udbf1\ude73",
        24, 41823, -1825829028, -255444711087920741L, 25960L, false, true, (char) 42776, (char) 37325,
        Double.longBitsToDouble(0x3fda6baa704cf186L), Double.longBitsToDouble(0x3fdf201ed5b81336L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u49f4\u0e56\u5ae8\u865a\u71db\u6239 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u49f4\u0e56\u5ae8\u865a\u71db\u6239 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u49f4\u0e56\u5ae8\u865a\u71db\u6239 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {?=[ option: ?  :: \u49f4\u0e56\u5ae8\u865a\u71db\u6239 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 2, 2, 15, "?", "\u49f4\u0e56\u5ae8\u865a\u71db\u6239", "\udaeb\uddf2\ud95d\ude74\ud919\ude59\ud941\udd48\ud92e\udf46\uda3f\udd0c\ud9dc\udf00\udafc\udea0\uda42\udec5\udba2\udf80",
        19, 30102, -1152706781, 852350477120727199L, 33097L, true, false, (char) 63174, (char) 51234,
        Double.longBitsToDouble(0x3feeedfbd07347a0L), Double.longBitsToDouble(0x3fed9d05d5baecc2L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 12, "\udb08\udd86\ud801\udce7\udb04\udd2f\udb34\udffe\ud99d\udc9f\ud82c\udd08\u2c6b\u5281\ud95a\uddd4", "\u0d01\u4444\u122c\u6138\u358d\u2533\u37f5\u1051\u9127\u760a\ub9b6\u04e2\u04df\u00a6\u8162\000\u0f5b\u8340", "\u009f",
        8, 1378, 70280149, -6103223692458033169L, -2926L, true, true, (char) 15269, (char) 33950,
        Double.longBitsToDouble(0x3feae9e490019c8cL), Double.longBitsToDouble(0x3fef02e2c5913a70L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=org.apache.commons.cli.Options:[ Options: [ short {\u9e42\000\000\000=[ option: \u9e42\000\000\000  :: \ua4a5 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u9e42\000\000\000=[ option: \u9e42\000\000\000  :: \ua4a5 :: class java.lang.String ]} ] [ long {} ]\0121=org.apache.commons.cli.Options:[ Options: [ short {\u9e42\000\000\000=[ option: \u9e42\000\000\000  :: \ua4a5 :: class java.lang.String ]} ] [ long {} ] |this=org.apache.commons.cli.Options:[ Options: [ short {\u9e42\000\000\000=[ option: \u9e42\000\000\000  :: \ua4a5 :: class java.lang.String ]} ] [ long {} ]\012",
        Z.run(T, 2, 2, 1, 3, "\u9e42\000\000\000", "\ua4a5", "\ud8e9\udcf3\udbb9\udfc6\udbc8\udc62\ud947\udfc6\u5e56\udac5\udf20",
        53, 99214, -334739774, 8660080163183382075L, -100000L, false, false, (char) 0, (char) 41941,
        Double.longBitsToDouble(0x3fb2c56140000000L), Double.longBitsToDouble(0x3fdbf000095f981aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Options|getMatchingOptions|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|java.lang.String,java.lang.String,boolean,java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|addOptionGroup|org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOptionGroup|org.apache.commons.cli.Option|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOptionGroups||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getOptions||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getRequiredOptions||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|hasLongOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|hasOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|hasShortOption|java.lang.String|new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|helpOptions||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|toString||new:org.apache.commons.cli.Options:",
    "M|org.apache.commons.cli.Options|getMatchingOptions|java.lang.String|new:org.apache.commons.cli.Options:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
