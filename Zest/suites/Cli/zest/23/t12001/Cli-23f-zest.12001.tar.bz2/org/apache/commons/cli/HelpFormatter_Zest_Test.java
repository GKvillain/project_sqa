package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:                       |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99\ud9a6\udfd3\ud97a\udfbf\uda98\udc53", "\u4c76\ud3be", "\udb69\udcb5\ud975\uddbf",
        22, 39095, -1677116151, -4955343544650244273L, -1330L, true, false, (char) 18854, (char) 508,
        Double.longBitsToDouble(0x3fac3810ad76f070L), Double.longBitsToDouble(0x3fb71018323fd888L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:                                                           |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 12, 7, "\ud924\udf99\ud96c\udd76\udb48\uddbe\uda98\udc53", "\u4c76\u3495", "\udb4f\uddf6\ud8d2\udfd0\ud84d\ude17\ud7fa\udb7a\uddaf\ud9ea\udd3f\udb67\udee6\ud879\udc07\u24c2",
        58, 48919, 263733277, 7056381946248693112L, -31975L, true, true, (char) 17306, (char) 25291,
        Double.longBitsToDouble(0x3fce18193c07e6acL), Double.longBitsToDouble(0x3fabbcfd88fb79f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99\ud9a6\udfd3\ud97a\udfbf\uda98\udc53", "\u4c76\ud3be", "\udb69\udcb5\ud975\uddbf",
        -5, 17649, -1677116151, -4955343544650244273L, -1330L, true, false, (char) 18854, (char) 508,
        Double.longBitsToDouble(0x3fac3810ad76f070L), Double.longBitsToDouble(0x3fb71018323fd888L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:   |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99\ud9a6\udfd3\ud97a\udfbf\uda98\udc53", "\u4c76\ud3be", "\udb69\udcb5\ud975\uddbf",
        2, 39095, -1677116151, -4955343544650244273L, -1330L, true, false, (char) 18809, (char) 508,
        Double.longBitsToDouble(0x3fac3810ad76f070L), Double.longBitsToDouble(0x3fb71018323fd888L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99\ud9a6\udfd3\ud97a\udfbf\uda98\udc53", "\u4c76", "\udb41\udea7\u0097\000",
        -5, -1000, 0, -4955343544650244273L, -1330L, true, false, (char) 18854, (char) 508,
        Double.longBitsToDouble(0x3fac3810ad76f070L), Double.longBitsToDouble(0x3fb7101830000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:       |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud976\udccd\ud9a6\udfd3\ud97a\udfbf\uda84\udf53", "\u4c76\ud3be", "\udb69\udcb5\ud975\uddbf",
        6, 39095, -1677116151, -4955343544650244273L, -1330L, true, false, (char) 18854, (char) 508,
        Double.longBitsToDouble(0x3fac3810ad76f070L), Double.longBitsToDouble(0x3fb71018323fd888L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:                                             |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99\ud9a6\udfd3\ud97a\udfbf\uda98\udc53", "\u4c76\ud3be", "\udb69\udcb5\ud975\uddbf\ud881\udce7\uda63\ude59\uda1e\uddcf\u3b39",
        44, 73152, 947487086, 1022380992892058486L, -25156L, true, false, (char) 29657, (char) 46885,
        Double.longBitsToDouble(0x3fe79011b7e1caacL), Double.longBitsToDouble(0x3fa400e479759e70L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 7, 7, 8, "\uc804\ud8d3\uddbf\ud97a\udfbf\uda98\udc53", "\u67c4\ubaea", "\udb69\udcb5\ud975\uddbf",
        22, 16755, -1978376850, -4939861677901815985L, 17417L, true, false, (char) 9386, (char) 51049,
        Double.longBitsToDouble(0x3feae0fede47652dL), Double.longBitsToDouble(0x3fa5107cb08e0980L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:                        |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99\ud8ee\udfd7\ud82d\ude05\uda98\udc53\u0b7e\udafb\udeac\udbad\udd34", "\u739b\u9cef\u9644\uc800\u0302\u8eb5\u02e1\u7f20\u3608\u1c5d\ucae9\u5493\uac6f\u67cf\u7f23\u3683\u3b47\ua17d\u9401\u3828\u31db\u7030\uba30\u7ac5\uc356\u2d46", "\ue0f3\u69d2\udaed\udf9e\ud938\uddf7\udbfc\ude9a\u1bf9\ud969\udf91\ud9d7\udf44\udba3\udd22\ud9fc\uddcf\ud97a\ude07\udb7c\udd7d\ud950\udef5\uda49\udcc5",
        23, 42725, -77512924, -1304441237797708063L, -55805L, false, true, (char) 29564, (char) 28401,
        Double.longBitsToDouble(0x3fe8e68b3ce2e733L), Double.longBitsToDouble(0x3fdd7a293a82ce0eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:         |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud953\udf2d\ud9a6\udfd3\ud97a\udfbf\uda98\udc53", "\u4c76\ud3be", "\udb69\udcb5\ud975\uddbf\ud881\udce7\uda63\ude59\udb85\udf24\udb6e\udde1\udb47\udf29",
        8, 5086, 238041625, -6741541787323506806L, -81089L, false, false, (char) 12946, (char) 53731,
        Double.longBitsToDouble(0x3feecc2da5889296L), Double.longBitsToDouble(0x3fde7573ffe6edc2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 7, 8, "\ud924\udf99\ud9a6\udfd3\udb5b\udc65\ud83e\udec2", "\u404f\u90c4\uabe8\u7db1\u9916\u7972\u77f0\u2e8e\u8e8e\u73cb\u7f20\u3608", "\uda07\uddf2\uda91\ude25",
        35, 1284, -82751893, -8588093705618708409L, 82618L, true, true, (char) 19618, (char) 16098,
        Double.longBitsToDouble(0x3fcf4184f265f84cL), Double.longBitsToDouble(0x3fe28051b4f2a600L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.StringBuffer:\ud931\udd9c\udbce\udd27\ud97a\udfbf\ud831\udc5f\u4c76\ud3be |a0=java.lang.StringBuffer:\ud931\udd9c\udbce\udd27\ud97a\udfbf\ud831\udc5f\u4c76\ud3be |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 13, 0, 7, "\ud931\udd9c\udbce\udd27\ud97a\udfbf\ud831\udc5f", "\u4c76\ud3be", "\udb69\udcb5\ud975\uddbf",
        33, 39095, 951729523, -4955343544650244273L, -1330L, true, false, (char) 18854, (char) 508,
        Double.longBitsToDouble(0x3fd3870215aede6eL), Double.longBitsToDouble(0x3fb710180209af58L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 8, "\ud924\udf99\ud9a6\udfd3\ud97a\udfbf\u8dda", "\ub40d\u21b0\uabe8\u20a7\u9d3c\u9644\u638f\ub6cb\u8e8e\u6e89\u7ee8\u3608\u57c3", "\uda91\ude25\uaac3",
        52, 56340, 1583543879, -5401105303398719432L, 98700L, true, false, (char) 47666, (char) 22565,
        Double.longBitsToDouble(0x3fead35b2f63b11dL), Double.longBitsToDouble(0x3fbbcc7c05309450L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 7, 8, 3, "\udb30\udf82\ud967\udf35\ud885\uddc3\ud95a\udead", "\u229b\u2ec6\u44e8\ub72b", "\ud829\udd5c\ud9d3\udc57\udb85\udf24\ud9ea\udd3f\udb67\udee6\udbe0\udf5b\ud86c\udc3c\ud80a\udf10\uda07\uddf2\uda91\ude25\uedc3\ud8f0\udefe\uda34\udff0\udaea\udcbc\ufe2f\uda2a\udf0f\uda35\udfeb\udbaf\udfde\ud909\udc32\uda48\udca0\udbdf\ude1a\ud8bb\ude8c\uda14\udd57\udaac\udf76\u9b5f\udbd3\udcb1\udbc3\udfed\ud88f\udc2c\ud9e2\udddc\ud938\udf12\ud998\ude31\ud9bb\udd12\udb31\udc13\udb41\udf29\ud8e5\udd3b\ud959\udd50\udb5e\udc5f\udb23\ude0c\udb6c\uded2\ua4c9\ud937\udf6b\ud830\udf11\udb37\udc39\ud930\udf63\udb19\udf0f\udaf5\udea2\uda7d\udceb\ud956\udf13\udb0e\udde0\udbff\uddf2\uda18\udd9d\udb2b\udca1",
        10, 80178, -619874126, 8659928634705587571L, 96424L, false, false, (char) 2509, (char) 2744,
        Double.longBitsToDouble(0x3fee07426f435d44L), Double.longBitsToDouble(0x3fd659e7200acb6cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:                       |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99", "\u127f\u211b\u5ec3\u4c76\uaabe", "\ud82c\udf89\udbb1\udc92",
        22, 39095, -1677116151, -4955343544650244273L, -1330L, true, false, (char) 18854, (char) 508,
        Double.longBitsToDouble(0x3fac3810dd76f070L), Double.longBitsToDouble(0x3fa9436767081d50L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.StringBuffer:\ud91c\udd0e |a0=java.lang.StringBuffer:\ud91c\udd0e |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud91c\udd0e", "", "",
        59, 35214, -1729518099, -9178095389268483181L, -86581L, false, false, (char) 233, (char) 0,
        Double.longBitsToDouble(0x3fd4d0000e9f7676L), Double.longBitsToDouble(0x3fe8b7c8c16e0ffcL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 14, 8, "\ud924\udf4e\uda25\uddf2\udbbf\udcf0\ud9d8\udede\udb45\ude2c\u4987\udbad\udd34\udb01\udfd9\ud972\udf5d\uda09\udeab\udaa1\udc83\udb93\udd09\ud881\udce7\udacc\uddd8\ud941\udfce\ud8b8\udc2a\udaf4\udf8e\ud890\uded2\u24c2\uf2ef\ud958\ude8b\udb01\udc6e", "\u8e7d\u106e\u324e\u9696\u1f28\u2bc9\ub73b\u9c3c\u567b\u512a\u9b96\ucbc5\u6cd5\ua523\ucf49\ua688\u5bba", "\ud929\udfa3\ud947\ude9a\ud969\udd48\ud8ef\udf50\ud903\udc71\udb35\udf45\uda93\udd6c\uda2e\udfe5\ud815\udc7c",
        55, 95101, -564949357, 2264819996613317328L, 98237L, true, false, (char) 42074, (char) 19805,
        Double.longBitsToDouble(0x3f91764f44174f00L), Double.longBitsToDouble(0x3fe4bc182c9fa028L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:                                   |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 8, "\ud924\udf99\ud9a6\udfd3\ud877\udefd\000", "", "\ud972\udf5d",
        34, 17767, -1898957717, 425929424736548007L, -39917L, true, true, (char) 19503, (char) 37225,
        Double.longBitsToDouble(0x3fe0c9c3cb760e30L), Double.longBitsToDouble(0x3fec55138c387021L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 13, 12, "\uda8c\udf47", "\uc45d\u5a4a\u5ec3\ud02d\u2e89", "\udb69\udcb5\ud989\udd38\ud881\udce7\uda63\ude59\udb2b\udd36\udbf0\ude21\udb67\udee6\ud879\udc07\u24c2\ud8ec\ude67\ud9d6\udd9a\ud8a4\udd1a\udb71\uddc8\ud9b5\udeba\uda35\udc11\udb35\udf03\ud871\udf23\udb1c\ude1e\udaf7\udcd1\ud932\udeb6\udbb8\ude14\ud8b1\udee6\udbec\udcab\udb5b\udf49",
        51, 94282, -1486676891, 2262308531977655228L, -61167L, true, false, (char) 29710, (char) 21547,
        Double.longBitsToDouble(0x3fe707ed0d8445e6L), Double.longBitsToDouble(0x3fd285aef4c26ee6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 3, 7, 13, "\ud924\udf99\ud9a6\udfd3\ud97a\udfbf\uda98\udc53\u0b7e\udafb\udeac\udbad\udd34\ud8e2\udd5e\ud877\udc8f\ud9ab\udc68", "\uaa4a\u6b75\u8e8e\u73cb\u7f20\u3608\u1c5d\ucae9\u5493\uac6f\u67cf\u460d\u8e42\u4e62\ucddb\u115b\u3b61\u8e86\u6b73\ucdf8\u9913\u1da6\u7957\u7f57\u2dad\u02e4\u0292\u8bdb\u5bcf\u5b09\u8357\ud555", "\ud943\udde6\udb11\uddd0\udb1e\udcbf\uda7f\uddbb\ud836\udebb\uda75\udcf7",
        1, 61093, 1464638272, -6913477966636918304L, 23005L, true, false, (char) 18918, (char) 15772,
        Double.longBitsToDouble(0x3fe9c7c90a08234dL), Double.longBitsToDouble(0x3fc868566f00063cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
