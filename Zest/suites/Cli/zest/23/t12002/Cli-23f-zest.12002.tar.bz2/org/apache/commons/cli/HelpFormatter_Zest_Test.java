package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 11, "\udab2\ude5b\udace\udeda\ud918\udfee", "\u25f9\ub231\ucd4b\u8f5c\ud7ca\u0ba6\u6865", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3",
        6, 52417, 495353564, 8543424289754388527L, -41301L, false, false, (char) 55677, (char) 59461,
        Double.longBitsToDouble(0x3fe23b363dbc5237L), Double.longBitsToDouble(0x3fbd19febc505ac8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 11, "\udab2\ude5b\udace\udeda\ud918\udfee", "\u5eba\ub231\ucd4b\u8f5c\ud7ca\u0ba6\u3a66", "\ud890\udec6\ud96e\udd1f\ud95a\udf80",
        51, 78829, -282751721, 5943780030580208385L, 63548L, false, false, (char) 36543, (char) 59557,
        Double.longBitsToDouble(0x3fe5ad179a324523L), Double.longBitsToDouble(0x3fd06943157aef50L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 11, "\udaa1\udd90", "", "\000",
        2, 92835, -1293866300, 702706112768L, 6916L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fccc399652be50cL), Double.longBitsToDouble(0x3fe78c91b017823dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 11, "\udab2\ude5b\udace\udeda\ud918\udfee", "\u26dfB\ucd4b\u8f5c\ud7ca\u0ba6\u6865", "\udb3c\udd9c",
        6, 78846, 3588426, 0L, 63548L, false, false, (char) 36543, (char) 59557,
        Double.longBitsToDouble(0x3fe5ad17981a7f23L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 0, "\udab2\ude5b\udace\udeda\ud918\udf8d", "\u25f9\ub231\ucd4b\u00c4\000\u0b21\u6865", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3",
        6, 52417, 495353564, 8543424288076666927L, -556L, false, true, (char) 44859, (char) 37981,
        Double.longBitsToDouble(0x3fe169e213849961L), Double.longBitsToDouble(0x3fd8d521b8f94046L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 9, "\udab2\ude5b\udace\udeda", ";\u25f9\ub231\ucd4b\u8f5c", "\u645f\ud86f\udf68\ud9fe\udf3f\udb3c\udd9c\udb70\udd20\ud93f\udc80\udabe\uded1\udab2\udf87",
        29, 28114, 1744373096, -156202423847321892L, -93809L, true, false, (char) 48552, (char) 32061,
        Double.longBitsToDouble(0x3fd4c9431a1434b0L), Double.longBitsToDouble(0x3fe23b3638caad37L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 11, "\udab2\ude5b\udace\udeda\ud918\udfee", "\u25f9\ub231\ucd4b\u8f5c\ud7ca\u9963\u20ed", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udbce\udd34\ud85f\udf50\udb05\udea3\ud818\udeb2\ud892\udc19\ud99c\udc99\udad1\ude1c\ud9d9\ude17\ud8a9\udee9",
        44, 24690, -499366580, 7406079136578925127L, -556L, false, true, (char) 16154, (char) 17419,
        Double.longBitsToDouble(0x3fc58b16e9202b1cL), Double.longBitsToDouble(0x3fe2e40e07074316L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 4, "\ud8c8\udc53\ud88d\uddb4\u35e3\udb7c\ude09\uda15\udf05\u3b05\u65f2\uda0a\udf9c\uda22\udc38\ud86c\udc79\ud8a5\udf6c\u645f\ud86f\udf68\uda1b\udf4c\udb6d\udd99\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3\ud818\udeb2\ud892\udc19", "\u5f01\uae1c\u0964\u8e54\uc37f", "\uda58\ude6c\udb8a\udc2e\udbf7\udfd4\ud8f9\udf15\udac6\udcc9\ud8c3\udd55\ud9cb\udd05\udb0d\udcd2\uda6d\udef5\u917f\uad81\ud9b5\udc50",
        28, 69433, -10361662, -8009152468343632539L, 33385L, true, true, (char) 36593, (char) 28247,
        Double.longBitsToDouble(0x3fe0343a79765b66L), Double.longBitsToDouble(0x3fd5f59eea506fc0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 15, 11, "\ud87b\udd0f\udace\udefa\ud918\udfee", "\u25f9\ub231\ucd4b\uaaeb\ub165\u0c0a\u6865", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\udf7f\ud92a\udd5d\udae7\udc18\udb05\udea3",
        6, 52417, 495353564, 8543424289759925039L, -41301L, false, true, (char) 63613, (char) 59461,
        Double.longBitsToDouble(0x3fe23b363b340e37L), Double.longBitsToDouble(0x3fbd2e32bc505ac8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 0, "\u44cb\udace\ude93\ud918\udfee", "\000\000\ucd4b", "\uda5c\udfa8",
        55, 1884, 554393933, 567516388903296877L, -18336L, true, false, (char) 3924, (char) 31639,
        Double.longBitsToDouble(0x3fd689d7c0000182L), Double.longBitsToDouble(0x3f2a850000000000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 15, 11, "\udab2\ude5b\udba1\udf10\ud918\udfee", "\u25f9\ub231\ucd4b\u4f14\u74cb\u0ba6\u7e53", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3",
        6, 917, 495353564, 8543424289754388527L, 27559L, true, true, (char) 13443, (char) 9323,
        Double.longBitsToDouble(0x3fdfdf9380e778e0L), Double.longBitsToDouble(0x3fedd0c267c2ecadL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 13, "\uec86\udbb7\ude23\ud918\udfee\udb7c\ude09", "\ub231\ucd4b", "\uda5c\udfa8\u645f\ud86f\udf68",
        23, 26206, 483073901, -485503766406708918L, 95224L, true, false, (char) 55698, (char) 24540,
        Double.longBitsToDouble(0x3fe8d185c4bdda89L), Double.longBitsToDouble(0x3fd540ec6c34fe46L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 15, 11, "\udbc8\udca9\udace\udeda\ud918\udfee", "\u25f9\ub231\ua1b5\u5b20\ub0db\u0ba6\u6865", "\udb18\uddb0\udbad\udd87\udab8\udc82\udaa6\udc8d\udb28\udf33\udae7\udc90\udb05\udea3",
        48, 56673, 495353564, 8543424289754322991L, -34778L, false, true, (char) 37245, (char) 59461,
        Double.longBitsToDouble(0x3fe23b363dbc5237L), Double.longBitsToDouble(0x3fbd19febc505ac8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 11, "\udab4\udf60\uda3a\udd59\udb63\ude56\udb51\udead\ud985\udf88\udbb4\uded8\u65f2\uda0a\udf9c\ue97a\ud868\udeee\ud99f\udfca\ud9fe\udf19\ud806\udd73\udbf5\udd9a\udb3c\udd9c\u7578\ud901\ude2a\ud819\udc6d\uda89\udf99\udaf1\udf11\udb05\udea3\ud818\udeb2\udb13\udc1f\ud99c\udc99\udad1\ude1c\ud9d9\ude17\ud8a9\udee9\ud806\ude33\uda49\udfbf\ud8c9\udd80\udb4c\udeef\ud96f\udf1f\uda84\udfdc\ud8b9\udd1f", "\u593b\ub139\u9788\ud4ca", "\udb6a\udd71\ud8f3\udd22\ud9a4\udf4a\ud8bf\udf7c\udbd6\udc89\udb1d\udfbb\u8482\udb1b\udcbc\ud876\udd3e\udb4e\udf97\ud874\udcce",
        51, 88349, 1370801671, 4905772577338228817L, -95400L, false, true, (char) 31087, (char) 54383,
        Double.longBitsToDouble(0x3fcbb1a9ed527190L), Double.longBitsToDouble(0x3fe728a56889b509L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 15, 11, "\udab2\ude5b\ud847\ude56\ud845\udcb7", "\u25f9\ub231\ucd4b\u8f5c\ua86c\u0ba6\u6865", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3",
        6, 84425, -424052300, 8543424288633343279L, -41179L, false, false, (char) 55677, (char) 4422,
        Double.longBitsToDouble(0x3fe5d722c6c34862L), Double.longBitsToDouble(0x3fbd19f13c505ac8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 15, "\ud8c2\udc6e\uda1a\udea0\ud8c4\udf00\udb7c\uddcd", "\ub231\ucd4b", "\ud93e\udf1d\udb0b\udcf2\udaba\ude0b",
        14, 3843, 483073831, -485503766406708918L, 60489L, false, false, (char) 41825, (char) 38586,
        Double.longBitsToDouble(0x3fc186a14e729828L), Double.longBitsToDouble(0x3fa7bb76c6564410L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 11, "\udab2\ude5b\ud9be\udd52\udb8b\udc85", "\u25f9\ub231\ucd48\u8f5c\ud6ca\u0ba6\u6865", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3",
        6, 52417, 495353564, 8502891893108054063L, -41301L, false, false, (char) 55677, (char) 59461,
        Double.longBitsToDouble(0x3fe23b363dbc0000L), Double.longBitsToDouble(0x3fbd19febc505ac8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 15, 11, "\udab2\ude5b\udace\udeda\ud918\udfee", "\u25f9\ub231\ucd4b\u800b\u5f0e\u0ba6\u6865", "\ud8e0\udd9e\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3",
        6, 52417, 495353564, 8543424289754388527L, -41301L, false, false, (char) 55677, (char) 59461,
        Double.longBitsToDouble(0x3fe23b363dbc5237L), Double.longBitsToDouble(0x3fbd19feab605ac8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 11, "\udb8c\udd85\udac8\udcec\ud918\udfee", "\u25f9\ub231\ucd4b\u8f5c\ud7ca\u0ba6\u6865", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\uda21\udfb0",
        -3, 52417, 495353564, 8543424289754388527L, -48435L, true, true, (char) 41338, (char) 14616,
        Double.longBitsToDouble(0x3fea3bcf9696ecdbL), Double.longBitsToDouble(0x3fccd2ea028b8d5cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 1, 8, "\udab2\ude5b\udace\udeda\ud918\udfee\udb7c\ude09\uda15\udf05\u3b05\ud935\udee9\ud88c\udf69\udb99\udc20\udbee\udc5a\uda5c\udfa8\u645f\ud86f\udf68\ud9fe\udf3f\udb3c\udd9c\ud986\ude1f\ud93f\udc80", "\u691d\u9faf\u6fc8\u03d6\u51da\uaba5\u5f01\uae1c", "\udaba\uded4\uda4a\udf18\ud96f\udf1f\uda84\udfdc\ud8b9\udd1f\ud874\ude7d\ud82a\ude79\udbf8\ude6a\udb58\udcdb\ud9a3\udec8\ud856\ude1d\udbf0\udc01\ud822\udfb4\udbd7\udfc8\ud89e\ude29",
        29, 49479, -1531434974, -7960853753485955704L, 71600L, true, false, (char) 30714, (char) 5508,
        Double.longBitsToDouble(0x3fda5dfa0afc4a76L), Double.longBitsToDouble(0x3fc0dcc2bc6cd650L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 11, 11, 11, "\udab2\ude5b\udace\udeda\ud918\udfee", "\u25f9\ub231\ucd4b\u1892\ud72b\u0ba6\ub99a", "\udb3c\udd9c\ud96e\udd1f\ud93f\udc80\udabe\uded1\udab2\udf87\udae7\udc18\udb05\udea3",
        6, 52417, 495353564, -215339767229769681L, -41301L, false, false, (char) 60541, (char) 59461,
        Double.longBitsToDouble(0x3fe23b363dbc5237L), Double.longBitsToDouble(0x3fbd19ce3c505ce0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 13, 15, 9, "\udab2\ude5b\ud933\udced\ud919\udc14\udb7c\ude09\uda15\udf05\u3b05\u65f2\uda0a\udf9c\ud9f3\ude38\udbee\udc5a\uda6e\udc39", "\u1877\u8a7b\u418d\u94e9\u672b\u55e3\u691d\u9faf\u6fc8\u03d6\u51da\uac60\u5f01\uae1c\u0964\u8e54\uab80\ua6da\u23b9\ub8f7\u89e7\u3b86\u4891\u1753\u4d81\u56c1", "\udb14\udd39\ud95a\ude1f\ud9a6\udedc\ud804\udcde\udb46\udde2\udbdf\udd34\ud802\udfb8\udb4a\ude88\uda69\udea9\udb25\ude23\ud848\udd1d\ud889\ude1b\uf764\udaec\udc25\uaf5a\uda59\ude1b\ud9d8\ude7e\udb36\ude4e\ud957\udc0d\ud8ef\udfae\udac8\udf32\ud815\udcb3\ud8c5\udda3\ucf35\udbab\udfe8\udb7e\ude6e\ud9d9\udc28\u8fef\ud9ba\udf66\ud9b7\ude41\udba5\udefb\ud93c\uddda\uda15\uddc1\udbb6\ude07\ud9d3\udd1a\ud8e2\udd37\udbd4\udeb8\uda65\ude30\udbb8\udcae\udb4a\ude87\ud88d\udf53\udb80\udc00\ud812\udcd7\ud870\uddb5\uda8c\udf3a\ud9c7\udf4f\udb8b\udd58\ud8b7\udf59\uda29\udfb1\udb51\udc72\uda9e\udfba\uda1a\udfd4\udbdc\udd52",
        58, 66089, -2103285895, 5180629496862488333L, -64884L, false, true, (char) 23817, (char) 9336,
        Double.longBitsToDouble(0x3fce225c7d7c6488L), Double.longBitsToDouble(0x3fbd313ab7a6a8b0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|static",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|renderWrappedText|java.lang.StringBuffer,int,int,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
