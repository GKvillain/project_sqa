package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\u4f05\u5fc3\u9a98\u2972\u0e24\u1ce6\ud6b6", "\uda1e\uded5\ud989\ude49\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\ud83d\udd4c\uda07\udd36\uda53\uddb0\uda35\ude09\udbe0\udd4b\ud8bb\udff2\uda67\udc0c\udb58\udfc2\udb56\udd20",
        34, 43406, -650122271, 2819096243453577051L, 98423L, false, false, (char) 62168, (char) 18652,
        Double.longBitsToDouble(0x3fd65648d9ff2a30L), Double.longBitsToDouble(0x3fc48b585a505bfcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb08\udfcd\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\udb83\uddf5\udb66\udf3d\ud9a7\ude01", "\uc5c6\u6892\ua66d\ub4ff\u0e24\u1ce6\ud6b6\u1635\ub5b6\u8592", "\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\ud9ee\udfd1\uda07\udd36\uda53\uddb0\uda35\ude09\udbe0\udd4b\ud839\udff1\uda67\udc0c\ud8c6\udc9d\ud836\udf7a\udac6\uddb4\udb26\udf83\ud96a\udd98\ud8ba\udf67\uda0a\udef6\udab4\udee2\ud8f0\udee1\uda80\ude45\udbb8\udf1f\udbec\udc5c\ud87d\udf18\ud8e2\ude58\udbc9\uddfe",
        14, 71646, 1432827756, -8513253039585730525L, -64901L, false, true, (char) 20513, (char) 22419,
        Double.longBitsToDouble(0x3fec10215c984100L), Double.longBitsToDouble(0x3fe45a757a2489b2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\udb9f\udd59\uda6e\udf97\000\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\000\u5fc3\u9a98\u2972\u0e24\u3e85B", "",
        12, -329, 1232109427, 2454784559770559225L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fec1b2b1d20968aL), Double.longBitsToDouble(0x3fe9c17efd070e17L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\udb34\udc84\uda50\uddf1\ud9fd\udc6c\udafc\ude15\ud9bd\udfbd\ud9d5\udf6c\ud82e\udc22\udb1a\udd90\ud9a7\ude01", "\u4f05\u5fc3\u9a98\u2972\u0e24\u1ce6\ud6b6", "\ud89c\udff4\ud879\udda8\udbc8\udfc6\udbcd\udf8e\ud927\udef0\ud865\udc68\u7778\ud9ad\udfb5\uda17\udf83\uda07\udd36\ud8af\udf21\uda35\ude5c\udbe0\udd4b\ud8bb\udff2\uda67\udc0c\udb58\udfc2\udb56\udd20",
        34, 43406, -650122271, 2819096243453577051L, 98538L, false, false, (char) 62168, (char) 18652,
        Double.longBitsToDouble(0x3fd5c6ab99ff2a30L), Double.longBitsToDouble(0x3fc48b5859f05bfcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\ud907\udccf\ud8b9\uddad\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\uda2f\udc05\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\u5eb8\u3a8f\u9a65\u2972\u0e24\ubaa0\u1047\u1635\ub5b6\u8592\u0718\u667d\u4ded\ub424", "\udbfb\udcfd\ud83d\udd4c\uda07\udd36\uda53\uddb0\uda35\ude09\udbe0\udd4b\ud8bb\udff2\uda67\udc0c\udb58\udfc2\udb56\udd20\udbd3\udedb\udb26\udf83\ud96a\udd98\ud8ba\udf67\udb1d\udda0\udaa6\udc25\ud8f0\udee1",
        13, 52399, 1687008295, -7703304472721443585L, 27519L, false, true, (char) 24188, (char) 9623,
        Double.longBitsToDouble(0x3fb710627f1ac3e8L), Double.longBitsToDouble(0x3fee2f2eb9fc1ff9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\uda37\udede\ud9a7\ude03", "\u4f05", "\udb7f\udc49\ud8e8\udf0f\ucc3e\ud9c2\udfd9",
        55, 58893, -793393761, 5169932326761693043L, -41895L, false, false, (char) 21858, (char) 29692,
        Double.longBitsToDouble(0x3f65829a2259c100L), Double.longBitsToDouble(0x3fbe0d11008686c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb1b\udebd\ud874\ude78\udae9\uddc0\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud9a1\udf41\ud9b5\udce9\udb1a\udd90\ud9a7\ude01", "\u4f05\u5fc3\u9a98\u2972\u0e24\u1ce6\ud6b6", "\uda0b\udd8b\uda1f\udd13\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\ud83d\udd4c\udb14\udc9d\ud8e6\udf54\ud9b9\udd00\uda17\udfb7\ud95b\udfe9\ud8c7\udebd\udb58\udfc2\udb56\udd20",
        34, 43406, -650154783, 2819096243453577051L, 98423L, false, false, (char) 18905, (char) 18652,
        Double.longBitsToDouble(0x3fd65648d9ff2a30L), Double.longBitsToDouble(0x3fc48b585a505bfcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\udad7\udc29\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\u4f05\u5fc3\u9a98\u2972\u0e24\u1ce6\ud6b6\u1635\ub5b6\u8592\u7818", "\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\ud83d\udd4c",
        -2, 16344, 1700986896, -7599191588557859378L, 91457L, true, false, (char) 28282, (char) 59462,
        Double.longBitsToDouble(0x3fcd3548c36885b0L), Double.longBitsToDouble(0x3fe5f8c0d270066cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\ud915\udcb1\uda5e\udef5\udbc2\udc9b\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udffd\u4d5c\ud83b\udebb\udb1a\udd90\ud929\udd83\udb1b\udd83\ud948\udff6\udbf0\udd19\udb24\ude0a\uae12\ud904\ude9c\ud8e8\ude55\ud936\uddd3\ud9c3\udc7e\udb7a\udce9\ud8ea\udc6f\uda1e\uded5\ud989\ude49\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\ud83d\udd4c\uda07\udd36\uda53\uddb0\uda35\ude09\uda64\udc4a\ud8bb\udff2\uda67\udc0c\udbb3\uddb0\uda04\udc46\uda19\udffc\udb26\udf83\ud994\ude4d\ud8bb\udc39\udb1d\udda0\udb86\udd6e\ud848\udfa3\uda80\udddd\udbb8\udf1f\ud8e0\udc56\ud032", "\u5376\u7439\u37b6\u4511\u5279\ubf73\u483a\u72ce\ubfc0\ucecc\u4f73\u0930", "\uda35\udcd6\ud950\ude46\udbba\udcd7\ud87f\udeca\ud9a5\udf33",
        35, 35983, 2061420487, -6556758891044355564L, -82860L, false, true, (char) 61326, (char) 44356,
        Double.longBitsToDouble(0x3fa6a7df7572e5a0L), Double.longBitsToDouble(0x3fc6b919a0a58fa0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 5, 4, "\udb9f\udd59", "\u666d\u555f\u37b0\u5109\u392c\u92ac\u5630\u1ce7\u7ae9\u76c0\u98f2\u0a42\u4f05", "\ud904\ude9c",
        18, 39324, 1591887426, 3409671456085414893L, 53735L, true, true, (char) 13448, (char) 29516,
        Double.longBitsToDouble(0x3faa88622129b500L), Double.longBitsToDouble(0x3fdb0f24c20560a6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 7, 6, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\ud874\ude48", "\u54fb\u92ac\u5630\u1ce7\u7ae9\u76c0\uccc3\u0a42\u4f05\u5fc3\u9a98\u2972\u0e24\u1ce6\ud6b6\u1635\ub5b6", "\udbc8\udfc6\udbcd\udf8e",
        -4, 16264, -229852654, -5741102506311985301L, 47331L, false, true, (char) 8983, (char) 37661,
        Double.longBitsToDouble(0x3fbefaa0d7b6f9a0L), Double.longBitsToDouble(0x3fede84ae97b0fcdL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 1, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud832\udc61\ud8b2\udec1\udb1a\udd90\ud9a7\ude01", "\u4f05\u7fc3\u9a98\u2972\u0e24\u1ce6\ud6b6", "\ud8a4\udef5\ud977\ude94\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\uda6c\udf6a\uda07\udd36\uda53\uddb0\udbe7\ude23\udbe0\udd19\ud8bb\udff2\uda67\udc0c\udb58\udfc2\udb56\udd20",
        34, 43406, -650122271, -3100942182997752271L, -36279L, false, false, (char) 44863, (char) 20999,
        Double.longBitsToDouble(0x3fd65648d9ff2a30L), Double.longBitsToDouble(0x3fc48b585a505bfcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\udb9f\udd3f\ud8a9\udd70\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\ud82e\udf27\udbeb\udf1b\ud9c4\udcda\ud884\udcf3\ud872\ude0a\udb1a\udd90\ud9a7\ude01\udb44\udd17\udbde\udeaa\uda96\udc36\udb24\ude95\uae12\ud904\ude9c\ud8e8\ude55\ucc3e\ud887\udcdd\udb6d\udff3\ud8ea\udc6f\uda1e\uded5\ud989\ude49\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\ud87c\udf3d\ud83d\uddf7\ud8d0\udd1a", "\u1285", "\udb58\udfc2\udb56\udd20\udb34\udeac\udbb3\uddb0\ud96a\udcdc\ud8ba\udf67\udb1d\udda0\ud827\udfec\ud8f0\uddff\uda80\ude45\udbb8\udf1f\udbec\udc5c\ud87d\udf18\ud8e2\ude58\udbc9\uddfe\udb56\ude98\uda2e\udc29\ud87d\udcb5\ud8a0\udecf\u5f5d\udaa8\udc7b\ud9c3\udc7b\ud9a2\udf42\ud818\udf54\uda35\udf0a\udb9a\udcc9\uda31\udc87\ue33e\udb4a\uddf1\ud81e\udf15\ud975\udc75\ud918\udd30\ud8d5\udded",
        45, 12468, 1686173716, -3464560482470961622L, -55090L, true, true, (char) 22940, (char) 29050,
        Double.longBitsToDouble(0x3fbd15a253ab1af0L), Double.longBitsToDouble(0x3fe18bc0c98c5006L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 14, 13, "\udb9f\udd59\ud862\udc1e\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\udbbe\udcbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\u4f05\ubb9d\u5b30\u2972\u2fec\u1ce6\ud6b6", "\udafd\udc2e",
        46, -837, -1539446333, 1530196042993155144L, -67664L, false, false, (char) 52195, (char) 48315,
        Double.longBitsToDouble(0x3f90d0d8f06cac60L), Double.longBitsToDouble(0x3fd20968a6705fbeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 11, 8, 12, "\udb9f\udd59\ud8b9\udd5c\udb2c\ude9a", "\u9462\u95b5\u54fb\u92ac\u5630\u1ce7\u7ae9\u76c0\u98f2", "\udb24\ude0a\u7934\ud904\ude9c\ud8e8\ude55\ucc3e\ud9c2\udfd9\udb7a\udce9\ud8ea\udc6f\uda6d\udff8\ud989\ude49\udbc8\udfc6\ud945\uddca\udb32\ude7a",
        39, 22346, -1336704592, 6467617675115000354L, -34480L, true, true, (char) 60330, (char) 8983,
        Double.longBitsToDouble(0x3fd070e177dbd506L), Double.longBitsToDouble(0x3fe3eac238ae4a2bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 1, 3, 3, 13, "\udb9f\udd59\ud8b9\udd5c\udadd\udf54\ud866\udf86\ud9cb\udd15\ud822\uddef\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud952\udff1\ud82d\udfc9\udb1a\udd90\ud9a7\ude5e", "\u3080\u3534\u89a7\u28b7\u835f\u8f37\u56ce", "\udb10\udefe\ud989\udf06\udbc8\udfc6\u0c85",
        -4, 16264, -229852654, -5741102505547163646L, -65064L, false, false, (char) 42214, (char) 60336,
        Double.longBitsToDouble(0x3fac17ef8b10ad90L), Double.longBitsToDouble(0x3fed28d9027d5847L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 13, "\udafc\udf09\ud8c1\ude22\udbdb\udf53\udb18\udef6\ud866\udc78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\u4f05\u6ee0\u9a98\u2972\u0e24\ua76b\u975e\u8a4c\u5c5d\uad7f", "\udbcd\udf8e\ud97b\udc39\ud959\ude5d\udba4\uddac\udaaf\udd06\ud9f4\udd46\uda07\uddb1\uda53\uddb0\uda35\ude94\udbe0\udd4b\ud8bb\udff2\uda67\udc0c\udb58\udfc2\ud85d\udc08\udbd3\udef2\udb26\udf83\ud96a\udd98\udb34\udedc\udb0d\ude80\udae4\ude6b\ud8ec\udde1\uda80\ude45\udbb8\udf1f\udbec\udc5c\ud87d\udf18\ud8e2\ude58\udbc9\uddfe",
        49, 77497, -1207112137, -449324483067146247L, 32466L, true, false, (char) 58841, (char) 38033,
        Double.longBitsToDouble(0x3fea7e2a4b7871cdL), Double.longBitsToDouble(0x3fe120c1ada016ecL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 11, "\udb9f\udd61\ud8b9\udd5c\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4", "\u1ce7\u7ae9\u76c0\u98f2\u0a42\u4f05\u5fc3\u9a98\u2972\u845d\ubb51\u6e45\u96f5\ub5b6\u8592\u0718\u2655\u4ded", "\ud912\uddc2\udbfb\udcfd\uda42\udff0\uda07\udd2f\uda45\udec9\uda54\ude74\udba2\udd4c",
        52, 47632, -360479317, 6361250830417081219L, -29313L, true, true, (char) 48535, (char) 43962,
        Double.longBitsToDouble(0x3fcd222f236885b0L), Double.longBitsToDouble(0x3fe5f8c0d270066cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 0, "", "\u3d3f\u666d\u0d4c\u5d3a\u95b5\u54fb\u92ac\u5630\u1ce7", "\udb44\udd17",
        16, 24046, 201326592, 7967016786901220131L, -9465L, false, false, (char) 24322, (char) 49981,
        Double.longBitsToDouble(0x3fd9fc4c241fa16aL), Double.longBitsToDouble(0x3feb9a3dfd8d4970L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\u1f8f", "", "\uce6d",
        42, 34784, 162881323, 288468612696355657L, -43219L, false, false, (char) 19968, (char) 0,
        Double.longBitsToDouble(0x3fb4c00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 13, "\udb9f\udd59\uda6e\udf97\ud881\ude3f\ud800\udd2f\ud874\ude78\uce6d\ud816\udd27\udb57\uded6\ud9a4\udf84\udb5b\ude01\ud82e\udc6b\udb1a\udd90\ud9a7\ude01", "\ub1fd\u1e67\u511b\u298b\u0e24\u3e85\u60dd", "\udb57\udd8d",
        46, 9427, 571549069, 1530347530784652360L, -67664L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4e0d958c000000L), Double.longBitsToDouble(0x3fd20968a6705fbeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 13, "\udb0d\uddf0\uda6e\udf97\000\udb18\udef6\ud874\ude78\uce6d\udb49\udd2b\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udf88\udbd4\udd8d\udb15\udd0a", "\000\u5fc3\u9a98\u2972\u0e24\u3e85\ub954\ub445\ub3e1\u75a5", "\udbcd\udf8e\ud97b\udc39\u3e59",
        16, 29408, 0, -573905408L, -83741L, false, false, (char) 55480, (char) 49215,
        Double.longBitsToDouble(0x3fdfafb42cb470c2L), Double.longBitsToDouble(0x3fedc933730e8d90L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\ud991\udf93\000\000", "", "\ud917\udef4",
        28, 70309, -996297911, -7079448215579844045L, -96525L, false, false, (char) 53586, (char) 37819,
        Double.longBitsToDouble(0x3fe91b7481407ed2L), Double.longBitsToDouble(0x3f41540109900000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:-- |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:usage:  |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 7, 12, 13, "\udb9f\udd59\uda6e\udf97\000\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\udbc6\udd42\ud93a\udef8\ud856\udc51\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\000\u5fc3\u9a98\u3af0\u1389\u2f38T", "\udb57\udd2b",
        46, 65088, 571549069, 1544420857119554632L, -67664L, false, false, (char) 0, (char) 64422,
        Double.longBitsToDouble(0x3fe001225783651dL), Double.longBitsToDouble(0x3fd20968a6705fbeL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:                                   |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 3, 9, 13, "\udb9f\udd59\ud87d\udc7e\ud8b4\udf2c\ud9a0\udeba\ud87e\udd0f\ud874\udcf0\ud97a\udf4b\ud9f9\udd2b\udbca\udcb6\ud951\udc10\ud91b\udd47\ud8e5\ude19\udb75\udd48\ud963\uddda\ud961\uddaa\000\udb24\ude0a\udbc0\udd3c\ud9ee\udcc9\udb06\udc0b\uda8b\udde4BF\udb9e\uddcf\udb68\uddc3\ud989\ude49\udbc8\udfc6\udbcd\udf8e\udbc5\udffe\udb0e\udf64\ud92e\ude02\ud90e\udfe2\ud87a\udc71\u5d3f\uda0c\udd86\ud857\ude08\ud8d4\udf7a\ud937\udf82\udbfd\udd67\udb6a\udd8b\ud9f0\ude8f\ud814\udf78", "\u769c\u5cd5\u9dad\u66db", "\udbd9\udd87\udbc9\udef1\udb3b\uddf1\udb86\ude70",
        34, 10988, 1454136670, -1506036956051775699L, -1187L, false, false, (char) 7116, (char) 44115,
        Double.longBitsToDouble(0x3fa6afc81f4bab70L), Double.longBitsToDouble(0x3feb388759cb6926L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 3, "\udb9f\udd59\uda6e\udf97\000\udb18\udef6\ud874\ude78\ud812\ude5c\ud9f7\udddd\ud8c2\udebc\uda97\udc54\uda61\ude64\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\u10e3\u3fcf\u9a98\u1553\u0e24\u3e85B", "\udb57\ude11",
        46, 9427, 571549069, 1530347530784652360L, -67664L, false, false, (char) 52480, (char) 760,
        Double.longBitsToDouble(0x3e4e0d958c000000L), Double.longBitsToDouble(0x3fd20968a49e5fbeL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 13, "\udb9f\udd59\ud84f\udd8c2\udb18\udef6\udb9e\udece\ud8fe\udeed\udb4d\udda4\udbcc\udf64\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\000\u5fc3\u99f8\u2972\u0e24\u3e85B", "\ud9fc\ude95",
        15, 6606, 571549069, 1530347530784652360L, 63408L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e39832b18000000L), Double.longBitsToDouble(0x3fdfb44cd6705fbeL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 13, "\udb9f\udd59\uda6e\udf97\000\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\uda15\uddf8", "\000\u5fc3\u9a98\u2972\u0e24\u3e85B", "",
        12, -329, 1232109427, 2454784559770559225L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fec1b2b1d20968aL), Double.longBitsToDouble(0x3f27efd070e17000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 13, "\udb9f\udd59\uda6e\udf97\udb86\udd0a\udb18\udef6\ud874\ude78\udadb\udee1\udb4d\udd0c\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\000\u5fc3\u9a98\u2972\u0e24\u5609\u4712", "\udb57\udd2b\ud989\ude49\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\000\000\000\uda35\uddf9\udbe0\udd4b",
        52, 8616, -1952873209, -152851372290887299L, 32010L, true, true, (char) 65517, (char) 63466,
        Double.longBitsToDouble(0x3fd0d6004b452882L), Double.longBitsToDouble(0x3fe9ca15a197f732L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 9, 1, 13, "\udb9f\udd59\uda6e\udf97\000\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\uc219\u6e88\u9e97\u609b\u0e24\u3e85B\000\000\u271c\u0718\u667d\u53a2\ua076", "\uda46\udda8\ud974\ude26\uda89\udd19\ud866\udfbc\uda8a\udcd4\uda19\udd53\ud8f2\udf43\uda16\udcf2\ud92f\udd12\udb3c\udfe2\udb43\uded8\ud85d\uded7\u5727\ud82d\udc81\uda9d\udd35\ud810\udce9\ud85b\udcbc\ud93e\udd23\udbf0\udd97\udaa9\ude2b\ud8b0\udf07\ud840\udca9\uda41\uddfc\ud9c3\udc2a\uda0d\ude0e\ud8f9\ude72\ud859\udc0c\uda13\ude53\ud897\udef4\ud987\udecd\ud8cb\udf86\udaaf\udc48\ud9b0\ude18\ud9fc\udd55\ub5a8\udbd2\udc61\ud9a5\udc02\udaa1\udd3f\ud9b3\udf0e\ud858\udca8\uda84\udf21\uda6b\udd3b\u9d5f\ud97d\udc74\ud958\udd89\uda59\udf22\ud9d7\udfe6\uda9c\ude3d\ud8c5\udd04\udb0a\udf67\uc06a\udaa6\uddf1\udbc7\udfb2\ud9b4\ude17\ud83b\udc8f\ud84e\udd2d\udb42\udf76\udb7a\uddae\ud94d\udc97",
        34, 48219, 1325736514, -2066307478514095693L, -44710L, true, false, (char) 9089, (char) 59434,
        Double.longBitsToDouble(0x3fdbaab9506707beL), Double.longBitsToDouble(0x3fe5b5d9c29713d8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 13, "\ud85f\udce3\udb57\udf54", "\u72ed\u15cc\u6d6c\u0bff\ucf6d\u5630\u1ce7\u692a\u76c0\u98f2\u99b4", "\uae12",
        30, 97936, -1480397924, -6894100939285766946L, 67219L, true, false, (char) 50994, (char) 26448,
        Double.longBitsToDouble(0x3fedb6a7b0aa537dL), Double.longBitsToDouble(0x3fd53bd5cccae898L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 9, 1, "\ud931\udf47\ud92d\udc8c\udad1\udfb7\udb12\udd13\udb34\udc84\uda50\uddac\ud9fd\udc6c", "\u76f7\u1d40\u7ae9\uca19\uaf2b\u0c18\u2fe7\u7abc\u70d1\u6780\u9046\u6e7c\ud6b6\u1635\uae31\u6d41\u0869\u667d\u4ded\u69d8\u76db\ub03d\ua20d", "\uda40\udc8a\uda9d\udc1a\udbe0\udd4b\ud8bb\udff2\ud89e\udc87\udb48\udd43\u7ec6\ud875\udfb9\udb6e\udd54",
        12, 94089, -488771381, -6177244122362448287L, -44024L, true, true, (char) 19111, (char) 43595,
        Double.longBitsToDouble(0x3fc8ab5849270ca4L), Double.longBitsToDouble(0x3fec1699370f1145L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 0, 0, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\udb34\udc84\uda50\uddf1\ud9fd\udc6c\udafc\ude15\ud9bd\udfbd\ud9d5\udf6c\ud82e\udc22\udb1a\udd90\ud9a7\ude01", "\u4f05\u5fc3\u9a98\u2972\u0e24\u9d97\u3fdc", "\ud89c\udff4\ud879\udda8\udbc8\udfc6\udbcd\udf8e\ud927\udef0\ud865\udc68\u7778\ud9ad\udfb5\uda17\udf83\uda07\udd36\ud8af\udf21\uda35\ude5c\udbe0\udd4b\ud8bb\udff2\uda67\udcb0\ud89c\udea4\ud9a6\udd1b",
        34, 43406, -650122271, 2819096243453577051L, 98538L, false, false, (char) 62168, (char) 18652,
        Double.longBitsToDouble(0x3fd5c6ab99ff2a30L), Double.longBitsToDouble(0x3fc24b5859f00038L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 7, 13, "\ud907\udccf\ud8b9\uddad\uda87\udf48\udb18\udeeb\udb23\uded0\uda0c\udfeb\uda29\udf2e\udad4\udcaf\uda1d\udd75\ud884\udcf3\ud82d\udfc9\udb1a\udd90\ud9a7\ude01", "\u5eb8\u3a8f\u9a65\u6ae5\uae08\ubaa0\u1047\u1635\ua169\u8592\u0718\u667d\u4ded\ub424", "\ud8fb\udd5c\udab2\udca7\uda2d\udf31\uda53\uddb0\uda35\ude09\udbe0\udd4b\ud8bb\udff2\uda67\udc0c\udbb9\uded9\udbbd\udf9e\uda13\uddd4\udacb\udc13\ud96a\uddaf\ud8ba\udf67\udb1d\udda0\udaa6\udc25\ud8f0\udee1",
        13, 52399, 1687008295, -7703304717534579457L, 27519L, false, true, (char) 24188, (char) 9623,
        Double.longBitsToDouble(0x3fb710627f1ac3e8L), Double.longBitsToDouble(0x3fee2f2eb9fcacd3L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 13, "", "\u3d3f", "\uce6d",
        15, -1000, -1749811200, 46963082678612809L, -41643L, false, true, (char) 20087, (char) 37666,
        Double.longBitsToDouble(0x3fe91b7481407ed2L), Double.longBitsToDouble(0x3fe2cc5507e8039cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:-1005 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 0, 1, 13, "\ud907\udccf", "\u666d\u0d4c\u5d3a\u95b5\000\000\000\u419d\u7ae9\u76c0\u82b9\000\000", "\ud904\ude9c\ud8e8\ude55\ud9d5\ude8f\ud961\udd7e\udb7a\udce9\u93ed\uc59f\ud861\udc2f\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\022\udbaa\uddb4\ud83d\udd4a\uda07\udd36\uda53\uddb0\uda35\ude09\udb50\udd43\ud8bb\udff2\uda67\udc0c\udb58\udfc2\udb56\udd20\udbbf\udcdb\udb26\udf83\ud96a\udd98\ud8ba\udf67\udb1d\udda0",
        -5, -1000, 402653184, -8472396797303737305L, -15263L, false, false, (char) 60818, (char) 44515,
        Double.longBitsToDouble(0x3fb086bedcc9f000L), Double.longBitsToDouble(0x3fd6498a1cf684c0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 14, 13, "\ud907\udccf\ud8b9\uddad\udb01\udc60\udb18\udef6\ud874\ude78\u296d\udb4d\udcf1", "\u5630\u1ce7\u7ae9\u76c0\u82b9\u08a5\u5eb8\u3a8f\u9a65\u2972\u0e24\ubaa0\u1047\u1635", "\ud989\ude49\udbc8\udfc6\udbcd\udf8e",
        -4, 82832, -229852654, -5741102505547163646L, -65064L, false, false, (char) 42214, (char) 60330,
        Double.longBitsToDouble(0x3fe9c17efd2b0e17L), Double.longBitsToDouble(0x3fef6f504a7d5847L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 2, "\udb9f\udd59\ud8b9\udd5c\ud926\ude24\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\udac7\uddfb\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\uda37\udede\ud9a7\ude03", "\ud124", "\udb7f\udc49\ud8e8\udf0f\ucc3e\ud9c2\udfd9\udb7a\udce9",
        23, 61239, 1203718671, 5291869694629848461L, -49283L, true, true, (char) 47920, (char) 10649,
        Double.longBitsToDouble(0x3fe5c9b5fcdf2810L), Double.longBitsToDouble(0x3f90d0e135ede300L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:74 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 13, "\udb9f\udd59\udb37\udd5b\udbdb\udf53\udb18\udef6\ud874\ude78\u1e6d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud914\udfb0\ud832\udd19\uda37\udede\ud9a7\ude37", "\u4f05", "\udaa1\udcf1\ud8e8\udf0f\ucc3e\ud9c2\udfd9",
        55, 58893, -793416545, 5170117044715159411L, 30558L, false, false, (char) 48315, (char) 53480,
        Double.longBitsToDouble(0x3fe6b65f3de6c40eL), Double.longBitsToDouble(0x3fe91ba8870d14c2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.cli.HelpFormatter$OptionComparator:@? |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 15, 3, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb18\udef6\ud874\ude78\uf06d\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\ud884\udcf3\ud82d\udfc9\uda37\udede\ud9a7\ude03\ud89f\ude26\uda6e\udd61\uda50\udf19", "\u4e1e\u2a51\u1ce6\ud6b6", "\uda1e\uded5\ud989\ude49\udbc8\udfc6\ud8d9\udf94\ud97b\udc39\udae2\udce1\ud908\udcda\uda58\udc1f\udb03\udf0d\ud9a9\udc2c\uda3f\udfed\ud9a3\udeb8\ud81e\ude23\ud978\ude43\udbe4\udfa2\ud9c7\udfce\ud9e2\udf1a",
        -5, 1130, -830203270, 3357063520552244327L, -83463L, true, false, (char) 16177, (char) 55075,
        Double.longBitsToDouble(0x3fd40a6902b8faa6L), Double.longBitsToDouble(0x3fe0e2b8fa2efc6cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 1, 13, "\udb9f\udd59\ud82d\ude77\udbdb\udf53\udb18\udef6\ud874\ude78\uce6d\udb4d\udcf1\udb3d\udf02\ud9bd\udfbd\uda41\udfb2\ud82e\udc53", "\u491b\u0a75\u4f05\u10aa\uca6d\u90b6\u0ede\u1ce6\ud6b6\u1635\u9874\uc010\u073a\u667d\u82a8\uc9e1\u130f\ua5c5\u354b\u2a63\u8014\ub094\ua498\uac37\ub8e7\u1dec\u4f89", "\ud80a\udd68",
        6, 32659, -1790361114, 3132260348652822050L, 14813L, false, false, (char) 35563, (char) 57595,
        Double.longBitsToDouble(0x3feb187d8d4cbe5aL), Double.longBitsToDouble(0x3febf7e79d4e1c9cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 4, "\uda37\udf30\ud8b9\uddcf\ud876\udd49\udbcf\ude17\ud9aa\udc79\udba0\udffa\udae7\uded6\ud99c\udd97\udb3f\udf5f\ud884\udcf3\udbc9\udef7\ud9f8\udd74\ud9a7\ude03", "\u0699", "\udb7f\udc49\ud8e8\udf0f\uda22\udc56\uda90\udc66\udb7a\udce9",
        2, 61239, 1203718671, 2434168605301325981L, -51800L, false, true, (char) 60208, (char) 53861,
        Double.longBitsToDouble(0x3fe5e11680783444L), Double.longBitsToDouble(0x3f90d0d864e5ca60L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\012 |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 1, "\ud847\uddcf", "\u666d\u6dd5\ua6ad\u8a12\ub0aa\u9362\u5630\u937d\u7629\u2cf8\ud51a\u0a9b\u5080\u83a9\uca6d\uccdb\u0ede\u1ce6\ud6b6\uc75c\u84fa\ua97c\u5c5d\u21eb\u39cc\ub424\u3c16\u4129", "\udba5\udc3f\uda53\uddb0\udbd4\udc79\ud8e3\udfbb\udbdd\udd12\udba9\udcd7",
        9, 7224, 785427061, 2678292436079332381L, 39350L, false, true, (char) 62554, (char) 43048,
        Double.longBitsToDouble(0x3fe54fff061b732fL), Double.longBitsToDouble(0x3fd21a1c9c6d0970L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:         |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 13, "\udb9f\udd59\ud811\udf35\ud996\uddd8\udb5d\udc1b\ud874\udda4\ud827\udd04\udb51\udd8c\ud917\udef4\ud9bd\udfbd\ud92f\udd28\udbd0\ude49\ud926\udef5\udac7\udd25", "\uae11\uc648\uca6d\u90b6", "\ud9c2\udfd9\udadb\uddbd\ud8ea\udc6f\u9099\udaea\ude54\uda00\uddf6\udbce\udffa\ud97b\udc39\ud97d\uddef\udb2c\udc92\uda32\ude45",
        8, 17898, -791115656, -828133478627856493L, 23576L, true, false, (char) 24545, (char) 23751,
        Double.longBitsToDouble(0x3fe40e5c87e62d1aL), Double.longBitsToDouble(0x3fde1782395bf01eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 13, "\uda18\ude3d\ud8b9\udd37\udbdb\udf53\udb1b\udebd\ud874\ude78\udae9\uddc0\udb4d\udcf1\ud917\udef4\ud9bd\udfbd\uda5c\udd4d\ud806\udc58\udb1a\udd90\ud9a7\ude01", "\u4f05\u5fc3\u9a98\u2972\u0e24\u1ce6\ud6b6", "\uda0b\udd8b\uda1f\udd13\udbc8\udfc6\udbcd\udf8e\ud97b\udc39\u3e59\ud912\udd43\udbfb\udcfd\ud83d\udd4c\udb14\udc9d\u3b09\uda52\udd8f\uf497\ud95b\udfe9\ud8c7\udebd\udb67\udcb6\udb56\udd2b",
        7, 43406, -650154783, 2819096243453577051L, 98423L, false, false, (char) 18905, (char) 18652,
        Double.longBitsToDouble(0x3fd65648d9ff2a30L), Double.longBitsToDouble(0x3fc48b585a505bfcL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 13, "\udb9f\udd59\ud8b9\udd5c\udbdb\udf53\udb1b\udebd\ud874\ude78\udae9\uddc0/\ud917\ude03\ud9bd\udfbd\ud9a1\udf41\ud812\udff8\udb1a\udd35\u2233", "", "\uae12",
        30, 34080, 1678155353, 6837104434377496096L, 46017L, false, false, (char) 50979, (char) 28413,
        Double.longBitsToDouble(0x3fe7c9108c48153cL), Double.longBitsToDouble(0x3fe094da81b0f24cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptSeparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
