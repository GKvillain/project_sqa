package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class HelpFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 9, "\ud9e8\udd81\uda6a\ude3d\u0b6e\ud894\udeb8\u2383\udbda\udcb9\uda55\uddea\udbb4\udde1\ud827\uddde\ud853\udc04\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udfe1\uda54\udd70\ud960\udd52\udba4\ude89", "\ua884\ud10d\u9fff\u3fa3\uce9c", "\uda5b\udca2",
        1, 50606, -1378915739, 3653543208314783448L, -40082L, false, false, (char) 38187, (char) 13464,
        Double.longBitsToDouble(0x3fe46d52df9a1a93L), Double.longBitsToDouble(0x3fd3ab9f02962b84L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 9, "\ud9e8\udd81\u00f0\000\000\u2383\udbda\udcb9\uda55\uddea\udbb4\udde1\ud827\uddde\ud833\udc99\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udfe1\uda54\udd70\ud960\udd52\udba4\ude89", "\ua83b\ud10d\u9fff", "\uda36\ude89",
        51, 64390, 1801116076, -8007573079996798363L, -49096L, false, false, (char) 43503, (char) 54571,
        Double.longBitsToDouble(0x3fe48df4d6dc35bcL), Double.longBitsToDouble(0x3fe46d52df9a1a93L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 9, "\ud9e8\udd81\uda6a\ude3d\u0b6e\uda41\udfbb\u2383\udbda\udcb9\uda55\uddea\udb44\udde4\ud827\uddde\ud853\udc04\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udfe1\uda54\udd70\ud960\udd52\ud96d\udc0e", "\u4068\ud05c\u9fff\u3fa3\u1094\u2f47\u728c\uaa05\ub8e8\u6f00\u78fb\ud248\u4cf0\ube29\u3ce9\u1c58\u7ab2\u715b\u260c\u3c90\u3f04\ub663\ub438\ub11f\ub177\u5508\u0940\u77ea\u338e\u49c0\u2b3a\uc2bd\u5ba2\u6301\uba94", "\uda95\uddd0\ud8b4\udd3b\uda3b\udeb6\udb6d\ude11\ud883\udfdd\ud848\udd73\ud813\udd05",
        6, 85283, -1471992772, -7545079265505288043L, 65867L, false, true, (char) 24251, (char) 11015,
        Double.longBitsToDouble(0x3fde37911b292ee8L), Double.longBitsToDouble(0x3fc638a36e207588L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 11, "\ud96a\udd7b\uda6a\ude3d\udaad\udca5\uda9a\udc45\udb47\udf3f\udbda\udcb9\uda55\uddea\udbb4\udde1\ud827\uddde\ud853\udc04\uda3b\udd8e\ud868\udeb1\uda4f\udc86\ud843\udf27\uda5e\udeee\ud960\udd52\uda38\ude13", "\ua884\ud10d\u9fff\u3fa3\uce9c\uc3cd\u7220", "\ud9bf\udc29",
        41, 33817, -819673384, -7783057788487920142L, 84691L, false, true, (char) 20266, (char) 48652,
        Double.longBitsToDouble(0x3fe47cf5cd9de262L), Double.longBitsToDouble(0x3fdd30c9b1ea9914L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 9, "\uda63\udd7f\uda6a\ude3d\u0b6e\ud894\udeb8\u2383\udbcb\udef2\uda55\uddea\udbb4\udde1\ud827\uddde\ud853\udc04\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udfe1\udba8\udd7b\uda0c\udd97\udba4\ude1d", "\ua884\ud10d\u9fff\u3fa3\uce9c", "\uda5b\udca2",
        -4, 50606, -1378915739, 3653543208314783448L, -46381L, false, true, (char) 20266, (char) 48908,
        Double.longBitsToDouble(0x3fe9299e5c80bb42L), Double.longBitsToDouble(0x3fde8c48292f59d8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 6, 5, 9, "\ud9f7\udeb0\uda5f\udecf\u0af8\uda3a\udecb\ud8f2\udc76\uc4c9\uda55\ude6d\udbb4\udde1\ud827\uddde\ud853\udc04\uda12\uddad\ud868\udde7\udb4c\udcc4\udb76\udfe1\ud988\udd6a\ud960\udd52\udba4\ude89\udba4\udcfd\udbd3\udc5e\ud865\udede\ud9cf\udcf3\uda3e\udc90\ud8dc\ude80\ud953\ude44\udbb0\udde7\udafb\udc79\uda5b\udca2\uda5f\udfff\udb90\udf66\ua614\udbba\udd2d\ud997\udeb3", "\u8cd1\u9641\u6101\u9b60\u3cba\u3f04\u3074\u78fd\u9082\ucb36\u6b2e\u500b\u7619\u8c4f\u32c6", "\uda71\udfce\udaad\udd3e\udb15\ude17\ud93e\udfe2\udabc\udf63\ud82a\ude97\ud903\udc13\uda8d\udea8\udae6\ude66\ud863\udf60\udab5\udf77\udbcd\udef5\ud98f\udd93\udbfd\udf8d\udaf3\ude6a\ud830\udfbc\ud977\ude6b\udaf4\udcd7\ud88c\udc03\udb79\udec7\ud865\udc78\udb91\udd8c\ud9b6\udf99\udbc1\udde1\uda0b\udfef\udaf7\udeaa\ud995\udd6f\uda3e\udf83\udbd8\udcdf\udb0e\ude88\ud94e\ude67\udaff\udd68\ud8cb\udcbc\ud944\udde1\ud8c4\udd7d\ud8c5\udd49\ud917\udd15\udbbf\udfbe\ud8d7\udf21\ud8d2\udcab\ud810\udfc0\udbda\udd6b\ud8a2\udee0\udb36\udc9e\udb69\udcfb\udacc\ude5b\udbbf\udfe8\udb2a\udcb7\udb6a\udd38\udbea\udfed\ud8bb\udf24\uda88\udc94\udab7\uddcf\ud802\udf77\uda19\udffd\udbb1\udca9\ud93a\udf8e\ud8fc\udc61\ud92a\udf1d\uda38\udf6c\uda29\ude9a\udb9b\uddc6",
        31, 21613, -2105241429, -7338885734258549295L, 65753L, false, true, (char) 56361, (char) 65027,
        Double.longBitsToDouble(0x3fd6c584a5f125bcL), Double.longBitsToDouble(0x3fef90a33c254538L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 9, "\ud9e8\udd81\uda6a\ude3d\uda82\udf6d\ud894\udeb8\u2383\udbda\udcb9\uda55\uddea\ubde0\ud9e3\udeb3\uda55\udd7d\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udfe1\uda54\udd70\ud960\udd52\udba4\ude89", "\ua884\ud10d\u9fff\u3fa3\uce9c", "\udb3a\uddba\ud91f\udf4a\udb2a\udd0a\ud8aa\udfcc\ud9c0\udd30\udbae\udff6\ud9c5\udfd0\udb03\ude91\ud95f\ude79\udacc\uddbb\udbe6\uddcf\udbae\udc1d\u1379\ud8f7\ude82\ua10a\udb29\udfd8\ud84d\udf25\uda50\udc8f\ud88d\udde7\ud8e4\udc63\uda08\udd07\udb74\udf2f\udacc\ude38\uda0d\ude53\uda65\udc92\u7059\udaf1\ude8e\udbfe\udcab\ud913\udf0b",
        13, 78342, 367889837, 6743001986661426030L, -27680L, true, false, (char) 36317, (char) 5962,
        Double.longBitsToDouble(0x3fd8110ecaf5b8f2L), Double.longBitsToDouble(0x3fead2c1beaee116L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 9, "\ud9e8\udd81", "\u3958\ud34f\u1b1b\ud1e2\u24b6\u8287\u8300\u6c08", "\udb76\udfe1\uda54\udd70\ud960\udd52\udba4\ude89\uda39\udebb\udbd3\udc5e\uda50\udeb4\ud9cf\udcf3\ud847\ude35\ud95c\udd8f\udb9b\udd05",
        5, 26180, 1152778339, 7735734640855472290L, -99537L, false, false, (char) 54610, (char) 43503,
        Double.longBitsToDouble(0x3fec2556bd2665f8L), Double.longBitsToDouble(0x3fe6e2ff0e8daa5bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 1, 4, 4, 9, "\ud9e8\udd81\uda6a\ude3d\ud817\udfdb\ud8ac\ude7f\u2383\udbda\udcb9\uda55\uddea\udbb4\udde1\ud827\uddde\uda90\udfe2\ud934\udd1d\udbd7\uddfa\ud95c\udfa0\udb76\udfa4\uda54\udd70\ud960\udd52\udba4\ude89", "\ua884\ud10d\u9fff\u3fa3\uce9c", "\ud867\udce6",
        58, 50606, -1378915739, 3653543208314783448L, -40082L, false, false, (char) 38187, (char) 13464,
        Double.longBitsToDouble(0x3fe46d52df9a1a93L), Double.longBitsToDouble(0x3fd3ab9f06962b84L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:3 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 5, 9, "\ud9e8\udd81\uda6a\ude3d\u0b6e\udb77\ude5f\u2383\udba4\udca1\ud99d\udfdd\udbb4\udde1\ud9cf\udccf\ud853\udc83\uda15\udd31\udba3\udf88\uda4f\udd39\udb13\udc0f\uda54\ude02\ud960\udd52\udba4\ude89\u07b6\uda6e\ude4b\uda50\udf6a\ud947\udc2f\ud846\ude45\ud95c\udd8f\udb9b\udd05\uda36\udf39\udafb\udc19\uda5b\udca2\uda3c\udcce\ud9c7\udded", "\u4cf0\ube29\uc19a\u7e99\u7cb4\u6f95", "\ud8f7\ude82\udbdb\udc03\ud813\udeeb\udb48\udd95\ud9c3\ude12\ud983\udd70\ud990\udc06\udb93\ude3b\uda9e\uddd4\udb4e\udcc9",
        51, 53701, -1222921756, 1295218207415836118L, 7250L, false, true, (char) 55487, (char) 45835,
        Double.longBitsToDouble(0x3fe65441fba87d5aL), Double.longBitsToDouble(0x3fe58df98006a10fL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 15, "\ud892\udfea\udb80\udf11\u0b67\ud894\udeb8\u2383\udbda\udcb9\uda55\uddea\udbb4\udde1\ud827\uddde\ud853\udc04\ud9ea\ude63\ud868\ude82\udb4c\udcc4\uda2d\udee6\uda5e\udff2", "\ub76f\u4c8f\ua884", "\ud95c\udd8f\udb9b\udd05\uda36\ude89\udafb\udc19\ud93b\udd5d\ud8b7\udf8c\udb0b\udd21\ud809\udfb9\udbba\udd2d",
        28, 96534, -2099833513, -4712363538457504111L, -7130L, true, true, (char) 13723, (char) 60847,
        Double.longBitsToDouble(0x3fd94afad2fb7e5eL), Double.longBitsToDouble(0x3fc5a92c256323d8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:                                                      |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 3, 9, "\ud9e8\udd81\uda6a\ude3d\u0b6e\ud894\udeb8\u2383\udbda\udcb9\uda55\uddea\udbb4\udde1\ud827\uddde\ud853\udc04\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udfe1\udafd\udc46\ud960\udd52\udba4\ude89\uda39\udebb\udbd3\udc5e\uda50\udeb4\ud9cf\udcf3\uda03\udcf4\ud95c\udd8f\udb9b\udd05\uda3e\udff7\udafb\udc19\uda5b\udca2\uda5f\udfff\ud9bf\udc29\ua58d\udbba\udd2d\udbae\udff6\ud9c5\udfd0", "\u9641\u715b\u260c\u3c90\u3f04\u47a3\u5454\u1350\u22a5\u1603\u4ce3\u3c63", "\ud9a7\udfb7",
        53, 9530, 140517576, -1120339704329109622L, 96959L, true, true, (char) 43489, (char) 25731,
        Double.longBitsToDouble(0x3fe3316e7366c70bL), Double.longBitsToDouble(0x3fd1a8e3c8dbd84cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 4, 9, "\u4016", "\u3958\ud34f", "\udb95\udf77\ud82a\udf3a\ud853\udc04\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udfe1\uda54\udd70\ud960\udd52\udba4\ude89",
        -1, 52159, 2112478025, -1272955196740213969L, -17887L, true, false, (char) 50803, (char) 56145,
        Double.longBitsToDouble(0x3fda0644f56dfea0L), Double.longBitsToDouble(0x3fe32c86fe31adcfL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:arg |this=org.apache.commons.cli.HelpFormatter:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.cli.HelpFormatter:@?\012",
        Z.run(T, 2, 4, 0, 9, "\ud8c1\udc8e\uda6a\ude3d\u00be\ud87d\udc1d\u2383\udbda\udcb9\ud8ad\udc75\000\000\ud833\udc99\udba0\uddb4\ud868\udde7\udb4c\udcc4\udb76\udf8b\uda54\udd70\ud960\udd52\udba4\ude89", "\ua884\ud10d", "\udb9b\udd05\uda36\ude89\udafb\udc19\uda5b\udca2\uda5f\udfff\ud9a6\udd73\ua58d\udbba\udd2d\udb7d\udd1e\ud9c5\udfd0\udb03\ude91\ud95f\ude79\udacc\uddbb\udbe6\uddcf\udbae\udc1d\u1379\ud8f7\ude82",
        49, 95352, -1453123407, -3823662192269758742L, 24087L, true, false, (char) 17136, (char) 49853,
        Double.longBitsToDouble(0x3fd514acc24bfd60L), Double.longBitsToDouble(0x3fe874622c123b4eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOption|java.lang.StringBuffer,org.apache.commons.cli.Option,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|appendOptionGroup|java.lang.StringBuffer,org.apache.commons.cli.OptionGroup|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|createPadding|int|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getArgName||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getDescPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLeftPadding||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getLongOptSeparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getNewLine||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getOptionComparator||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getSyntaxPrefix||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|getWidth||new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|printHelp|int,java.lang.String,java.lang.String,org.apache.commons.cli.Options,java.lang.String,boolean|new:org.apache.commons.cli.HelpFormatter:",
    "M|org.apache.commons.cli.HelpFormatter|findWrapPos|java.lang.String,int,int|new:org.apache.commons.cli.HelpFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
