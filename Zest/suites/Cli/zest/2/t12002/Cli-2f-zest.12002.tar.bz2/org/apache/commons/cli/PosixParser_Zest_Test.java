package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\u7fa7\u5986\ud235\u3bb0\u50c3\ucf57\ua91c\u0df7\u2b50\ub357\u2ab5\u1c05\u1451", "\udb7a\udc09\ud9b4\ude5e",
        44, 43085, 1379822809, -3667840953633228736L, 99483L, true, false, (char) 40133, (char) 63836,
        Double.longBitsToDouble(0x3fe76a8b543fb34aL), Double.longBitsToDouble(0x3fe811aebde3af89L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\u7fa7\u5986\ud235\u3bb0\u50c3\ucf57\ua91c\u0df7\u2b50\ub357\u2ab5\u7ccb\u1451", "\udb7a\udc09\ud9b4\ude5e",
        44, 43085, 1379822809, -3667840953633228736L, 99483L, true, false, (char) 40133, (char) 63836,
        Double.longBitsToDouble(0x3fe76a8b543fb34aL), Double.longBitsToDouble(0x3fe811aebde3af89L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b\ud81d\udd28\ud8f6\udf16\udaff\udd1e\uda9a\ude96\ud9a7\udcdd", "\ucf57\ua91c\u0df7\u506a\ub357\uae8c\u1c05\u1451\u2448\u5019\u68f2\ua133\u462c\uaba0\ua7db\u6e7c\u61ae\u9d67\u31a5\u5b98\u996c\u69a5\ub802\u040f\u1fa4\u3726\u52bf\u8979\u6de8\u98db\u347b\u9868\u54ab\uc207", "\udb0c\ude97\ud9bd\ude97\ud8ca\udc9d\ud9be\uddcd\udb3b\udc66",
        55, 25985, -1832540380, 6579693296838680437L, 83047L, false, true, (char) 17367, (char) 16715,
        Double.longBitsToDouble(0x3fe4a18d5adbc301L), Double.longBitsToDouble(0x3fd4c95dacd837caL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1", "\u869e\u012a\u7fa7\u5986", "\uda1d\udc7f\udb15\udfd1\uda5a\udcb6\ud85b\udc55\ud818\udf72\uda76\udf0e",
        -2, 94803, -1981017084, 53950171723153051L, -55439L, false, true, (char) 2249, (char) 31524,
        Double.longBitsToDouble(0x3fe0b2db6845cd19L), Double.longBitsToDouble(0x3fd2ef20fe26450aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\ua505\u5986", "\uda1c\udfbf\ud901\udf0b\uda73\uddc5\ud9fe\udd07\udb63\udeb8\uda70\udec4",
        3, 94803, -1991665404, 53950169872047078L, -55439L, false, true, (char) 28329, (char) 28412,
        Double.longBitsToDouble(0x3fe0b291f040cd19L), Double.longBitsToDouble(0x3fe7caf07f1e4647L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udd5a", "\u7fa7\u5986\ud235\u3bb0\u50c3\ucf57\ua91c\u0df7\u2b50\u3872\u3871\u1c05\u1451", "\ud8ad\udd30\udb2b\udd0b\ud87d\udcd3\uda8a\uddd3\udb0e\uddb1\ud80e\udf16\udac9\udf6d\ud9d6\udd5b\udb8b\udfcb\udb63\udc7f\udb51\udd4f\ud8f1\uddf3\udba5\ude66\uda65\udf2c\ud896\udf56",
        46, 76966, -636771004, 8357717653392491655L, -52134L, true, false, (char) 54278, (char) 50260,
        Double.longBitsToDouble(0x3fe7612b82a21235L), Double.longBitsToDouble(0x3fea564a3beb2d10L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud965\uddf1\ud839\udcd8\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\ud8e3\ude4e\uda1c\udfd6\uda42\uddcc\uda5a\udcb6]] |a1=[Ljava.lang.String;:[[\ud965\uddf1\ud839\udcd8\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\ud8e3\ude4e\uda1c\udfd6\uda42\uddcc\uda5a\udcb6]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 1, 7, "\ud965\uddf1\ud839\udcd8\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\ud8e3\ude4e\uda1c\udfd6\uda42\uddcc\uda5a\udcb6", "\ub357\u2ab5\u1c05\u1451\uc06d\u7ba0\u717f\u69f2\u13c6\ub3b5\u7521\ub1c1\ub7ba", "\udb63\udc7f",
        16, -865, -1286944019, -2519881146686689409L, -32307L, true, false, (char) 39039, (char) 14729,
        Double.longBitsToDouble(0x3fdf73ffddc35e12L), Double.longBitsToDouble(0x3fe1b34b4bd7beb0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\udb15\ude88\udab1\ude14\udba4\udf5b\ud85b\udded\udad0\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\u29e3\uda1d\udc7f\uda42\uddcc\uda5a\udcb6\ud9fe\udd07\udb63\udeb8]] |a1=[Ljava.lang.String;:[[\udb15\ude88\udab1\ude14\udba4\udf5b\ud85b\udded\udad0\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\u29e3\uda1d\udc7f\uda42\uddcc\uda5a\udcb6\ud9fe\udd07\udb63\udeb8]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 1, 2, "\udb15\ude88\udab1\ude14\udba4\udf5b\ud85b\udded\udad0\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\u29e3\uda1d\udc7f\uda42\uddcc\uda5a\udcb6\ud9fe\udd07\udb63\udeb8", "\u1c05\u1451\u7720\u5aea\ud613\ua2b0", "\ud803\udfad\ud82b\udd6e\udac9\udf6d",
        11, 97989, 701541641, -6902484455916938969L, 79137L, false, false, (char) 23246, (char) 2297,
        Double.longBitsToDouble(0x3fde83eae2f4ecf8L), Double.longBitsToDouble(0x3fa302f6f3c197a0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1\uda15\udfe6\udb99\udc0e", "\u9d9c\u5998\ud235\u3bb0\u50c3\ucf57\ua91c\u0df7\u2b50\ub357", "\u9a05\ubb67",
        0, 67088, 123949551, -3657802909863512723L, -29009L, false, false, (char) 1381, (char) 40133,
        Double.longBitsToDouble(0x3fd27a0355daa2d4L), Double.longBitsToDouble(0x3faf92e6f0235d70L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 0, "\000\udab1\udd43\u07ca", "\ua7db", "\u29e3\ud816\udefb\000\uda5a\udcb6\ud9fe\udd07\udb63\udeb8\uda70\udec4;\000\udab8\udcfc\ud902\udf70\udbe8\udc86\udaaa\udea1\ud9b4\ude5e\uda75\udca0\ud940\udc6d\000\ud80e\udf00\udac9\udf6d\ud9d6\udd5b\udb8b\udfcb\000\udaae\ude57\ud8e4\udd2d\udab4\udf7a\ud8eb\udf6b\000\ud925\udfe3\udb58\udf97\udafe\udf52\udae6\uddc3\udb2a\udc96\u2ed8",
        16, 9441, 696260751, -7031998396624820191L, -37106L, true, true, (char) 42505, (char) 503,
        Double.longBitsToDouble(0x3fe411760b49f2b0L), Double.longBitsToDouble(0x3fccd20cb787bc14L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 3, 7, 2, "\ud965\uddf1\udab1\ude14\udba8\udf5b", "\u164d\u5986\ud235\u8924\uaa5b\u41fe\u6bf0\u0df7\u95c3\u62e8\u2ab5\u1c05\u1451", "\uda25\udebe\udb2d\udd75",
        9, 43085, 1379822809, -3667840953633228736L, -81266L, false, true, (char) 22214, (char) 58419,
        Double.longBitsToDouble(0x3fcdaa2090fcb1fcL), Double.longBitsToDouble(0x3fe811aebd7aaf89L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 7, 7, "\udb6e\udcf5\udab1\ude14", "\uc25f\u9f03\u5986", "\udb89\udff3\uda42\uddcc\uda4e\udd50\udbb5\udcac\udac4\udf33\udbb4\udd22",
        36, 25763, -795880331, 53950169872047078L, 10097L, false, false, (char) 50601, (char) 38366,
        Double.longBitsToDouble(0x3fe0f9caf840cd94L), Double.longBitsToDouble(0x3fe42f950c27ec47L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 0, "\ud965\uddf1\udab1\ude14\udba4\udf5b\ud85b\udded\udace\udf62\udb8d\udd5a\ud964\udfd7\udab0\ude25\udbe0\udea2\uda1d\udc7f\uda42\uddcc\uda5a\udcb6\ud93a\udd05\udb63\udeb8\uda70\udec4\u499d\ud8f9\ude66\ud9d6\udcce\ud902\udf70\udbe8\udc86\udb7a\udc09\ud9b4\ude5e\ud8ca\ude0a\uda8a\uddb5\udb0e\uddb1\ud80e\udf16\udac9\udf6d\ud9d6\udd5b\udb8b\udfcb\udb63\udc7f", "\ub802\u040f\u1fa4\uce6b\u551c\ub690\u708a\u5389", "\ud985\udd38\ud82f\udee5\uda83\udeae\udbd3\ude37\ud856\udd79\udb3a\udc04\ud94f\udf7e\uda42\udd62\ud8d4\udff8\udb52\udfc4\udaaf\udd62\ud843\udc1e\ud949\ude81\ud953\udec0",
        40, 17083, 624609520, -6187050831598793854L, -27974L, true, true, (char) 32871, (char) 15639,
        Double.longBitsToDouble(0x3fb38f477811e418L), Double.longBitsToDouble(0x3fd5f61ef95e6180L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\u7fa7\u5986\ud235\u3bb0\u50c3\ucf57\ua91c\u0df7\u2b50\ub357\u2ab5\u1c05\u1451", "\udb7a\udc09\ud9b4\ude5e",
        44, 43085, 1379822809, -3811956140655241063L, 99483L, true, false, (char) 40133, (char) 63836,
        Double.longBitsToDouble(0x3fe76a8b543fb34aL), Double.longBitsToDouble(0x3fe811aebde3af89L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\udac8\ude3d\udb8c\udd74\udba4\udf5b", "\u7fa7\u5986\ud235\u3bb0\u50c3\ucf57\u1bde\u0df7\u2b50\u3d1e\uc833\u1c05\u6fe2", "\udb7a\udc09\ud9b4\ude5e",
        44, 8261, -383841549, -4110466848501286848L, 99483L, true, true, (char) 28295, (char) 32584,
        Double.longBitsToDouble(0x3fd6108dea008690L), Double.longBitsToDouble(0x3fe8152535e3af89L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 3, 1, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\u7fa7\u5986\ud235\u4be4\u4644\u7bb8\ua873\u8771\ud3c3\ub357\u2ab5\u9289\u1451", "\udb56\ude07\udb5b\udeb1",
        39, 93794, -421976410, 5916029061356828772L, -30583L, true, false, (char) 28944, (char) 10435,
        Double.longBitsToDouble(0x3fb59806d2502c08L), Double.longBitsToDouble(0x3fc5c57d78e2526cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\uafcb\000\000\u36f6\u50c3\ucf57\ua91c\u0df7\u0828\u6275\u2ab5\u1c05\u1451", "\udb7a\udc09",
        6, 83394, 391277, 5908722710256104982L, -76069L, false, false, (char) 53768, (char) 40133,
        Double.longBitsToDouble(0x3fd27a0355daa2d4L), Double.longBitsToDouble(0x3fafd9a500235d70L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 3, 2, "\uda07\udebb\udab1\ude14\udba4\udf5b", "\u0c3d\u5986", "\uda1d\udc7f\uda42\uddcc\uda5a\udcb6\ud9fe\udd07\udb63\udeb8\ud980\udf4c\u499d\ud8f9\ude66\ud90c\udeb7\ud902\udf49\udbe8\udc86\udb94\udd95\uda2d\udc6a",
        44, 50997, 1379822809, -3667840952137959360L, 96155L, true, false, (char) 40133, (char) 63836,
        Double.longBitsToDouble(0x3fe76a8b562c188eL), Double.longBitsToDouble(0x3fe811acaef0096bL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 6, "\udbf4\udc36\udbb7\udd86", "\ub4f4\u7fa7\u2862", "\udb9a\udd28\uda6d\ude91\uda5a\udcd4\ud9fe\udd07\ud953\ude50",
        23, 82763, -67271141, -8551398358701331611L, -70212L, false, false, (char) 64734, (char) 34900,
        Double.longBitsToDouble(0x3fb03346638a0ed0L), Double.longBitsToDouble(0x3f932d2b41266b80L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 7, 2, "\udb72\udd7b\ud857\udc37\ud9bb\uddc6", "\u7ef2\u48ee\u4e4e\u592a\u912d\u1748\ud3cb\ud201", "\udb14\udd10\ud8f9\ude66\udb56\udf5b\ud902\udf27\ud9e1\udf02\udabd\uddce\ud922\udd55\ud840\udf01\udb73\udec6\udaa5\udeb2\udaf9\ude5b\u878d\ud9d6\udd5b\udb8b\udfcb\udbcd\udc74\udb51\udd4f\ud84d\ude6e\udaf4\ude60\ud859\udf9d\ud810\ude44\udabe\uddf2\uda14\udd74\ud945\ude85\udb2e\ude59",
        59, 12782, 1906260676, -350246873600654069L, 47471L, true, true, (char) 14186, (char) 55090,
        Double.longBitsToDouble(0x3fc49a7202fa2c94L), Double.longBitsToDouble(0x3fa9efe99fa38450L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud806\udcfe", "\000\000\000", "\u29e3",
        40, -828, -2019938560, 7993223575293790248L, 96608L, true, true, (char) 40100, (char) 50891,
        Double.longBitsToDouble(0x3e4e881d8c000000L), Double.longBitsToDouble(0x3fbb734f26cc8028L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\000\udab1\udd43\udba4\udf5b", "\u7fa7", "\u29e3\uda1d\udc7f\uda7e\uddca\uda5a\udcb6\ud9fe\udd07\u5832\000\u0e62\u861b\u9a05\000\000\000\000\uda75\udca0m\000\000\udb19\udf2c\ud9d6\udd5b\udb8b\udfcb\udb63\udc7f\udb51\udd4f\ud8f1\uddf3\udae7\ude67?\ud810\ude44\ud8ba\ude50\udb59\udd92\udb69\udf28\uda34\udfb7\ud928\udf1b\ue8e8",
        47, 11666, -1711705646, -4663754898288609766L, -71368L, false, true, (char) 14975, (char) 31141,
        Double.longBitsToDouble(0x3fd78547cfb44ce2L), Double.longBitsToDouble(0x3fed6c284426b8a4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b\ud85b\udded\udace\udf62\udb8d\udd5a", "\u3bb0\u50c3\ucf57\ua91c\u0df7\ubca3\u05f9\u2b22\u1c05\u1451\u2448\u5019\u9e9b\u82b0\u1378\ub3b5\ub652\ub1c1\ub7ba\u8b25\u31a5\u5b98\u996c\u69a5\ub802\u040f\u1fa4\u0fa3\u6f3c\u67ff\u5472\uc86d\ucf77", "\ud930\ude38\udb57\udffe\uda7a\udf02\udacd\udf4a\ud8e6\uddd6\ud9c2\udc1c\ud818\udeac\udaf0\ude4b\uda1f\uddee\ud8f8\udd8f\udbc2\udfde\ud932\udd53\uda43\udfb8\udbaf\udd19\ud98b\ude74\udb89\udc34\ud9c7\udd87\udaad\ude0f\uda09\udc13\uda67\udc16\ud854\udd2c\uda0d\ude23\udbce\udc5f\u21b2\ud9f3\udf6a\udba5\ude96\ud8ec\udf25\udbc0\udddb\udba0\udf52\uda03\udf3c\ud96a\udf1f\udade\udf99\udb59\udcb7\udb6f\udf6d\uda10\udff5\udb3b\udd63\uda75\ude9a",
        7, 2764, 2014821110, 1985123357943809066L, -40544L, true, false, (char) 10273, (char) 37720,
        Double.longBitsToDouble(0x3fd2f5f3d3120ff8L), Double.longBitsToDouble(0x3fd153675389c79cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 4, 2, "\ud98b\udd65\uda48\udf60\udbaa\uddc3", "\u224e\u5986\u7365\u906b\u50c3\u183c\ud593\u0df7\u2b50\ub357\ub1ac\uca5c\u1451", "\udb7a\udc09\ud9b4\ude5e",
        44, 43085, 1379822809, -3667840953633228736L, 99483L, false, false, (char) 39990, (char) 63836,
        Double.longBitsToDouble(0x3fe76a8b533fef4aL), Double.longBitsToDouble(0x3fe3fe44ce62afdaL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\000", "",
        -5, -1000, 0, -8675570053268266370L, -54359L, true, true, (char) 34330, (char) 40448,
        Double.longBitsToDouble(0x3feb2c4a480000bfL), Double.longBitsToDouble(0x3fe5063001efd41cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud965\uddf1\udab1\ude14\udba4\udf5b]] |a1=[Ljava.lang.String;:[[\ud965\uddf1\udab1\ude14\udba4\udf5b]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud965\uddf1\udab1\ude14\udba4\udf5b]] |a1=[Ljava.lang.String;:[[\ud965\uddf1\udab1\ude14\udba4\udf5b]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\u7fa7\u5986\ud235\u3bb0\u4b22\u6f8a\u404a\u0df7\u2b50\ub357\u2ab5\u1c05\u71e6", "\udb7a\udc09\ud9b4\ude5e\ud87d\udca4\ud939\udc0a\udb07\udd17\ud80e\udf16\udac9\udf6d\ud9bf\udead\udb8b\udf6b\udb63\udc7f\udbe6\uded9\ud8f3\udc94\udbaf\uddeb\ud8eb\udf6b\ud810\ude44\ud84f\udcba\ud982\udc22\ud931\udcc7\ud8a2\udd80\ud875\udf30\ud91f\udc91\uda38\udd6d\ud819\udc00\ud934\ude81\ud8c1\udd8c\ud9fe\udde0\ud83d\udc36\udbfb\ude74\udb5d\udc76\ud816\udebc\ud897\udfb4\ud906\udcee\udbe1\udd6a\ud8f0\udc69\udb91\ude5e\uf328\udb57\udfba\ud86d\udf0a\ud981\udf8f\ud9ef\udeff\ud999\ude0c\uda41\udf19",
        57, 92469, 444499577, 4915048722615277603L, -77331L, false, true, (char) 13914, (char) 60888,
        Double.longBitsToDouble(0x3fed46cb414d0f06L), Double.longBitsToDouble(0x3fe13776b1472805L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud965\uddf1\udab1\ude14\udba4\udf5b]] |a1=[Ljava.lang.String;:[[\ud965\uddf1\udab1\ude14\udba4\udf5b]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud965\uddf1\udab1\ude14\udba4\udf5b]] |a1=[Ljava.lang.String;:[[\ud965\uddf1\udab1\ude14\udba4\udf5b]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 7, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\u7fa7\u5986\ud235\u3bb0\u50c3\u0502\uc5d6\ud6ae\u87cf\ub2ac\uc8b5\u2eb8\u9185", "\udb7a\udc2b\ud9b4\ude5e",
        50, 43230, 1379822809, -3621679055808505461L, 99483L, true, false, (char) 47665, (char) 14173,
        Double.longBitsToDouble(0x3fe76a8a7c3f974aL), Double.longBitsToDouble(0x3fe811aebc99af89L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 6, 2, "\ud93b\udef1\u0e1e\udba4\udf5b\ud85b\udded\udace\udf62\udb8d\udd5a\uda7b\udc12\ud8e7\ude9e\u29c8\udbe3\ude22\uda42\udd7e\uda5a\udcb6\ud9fe\udd07\udb63\udeb8\uda70\udec4\u499d\ud8f9\ude66\ud93a\ude0e\ud902\udf70\udb57\udf5d\udb7a\udc09\ud9b4\ude5e\ud87d\udca4\uda8a\uddd3\udb0e\uddb1\ud80e\udf16\udac9\udf6d\ud9d6\udd5b\udb8b\udfcb\udb63\udc7f\udabe\udd5a\ud8f1\uddf3\udabc\udcea\ud8eb\udfe2\ud810\ude44", "\u2025\u4ee2\u1dd8\u6ea8\u0f36\u68ee", "\ud801\udd56\udbc7\ude70\uda48\udcea\uda18\ude9d\ud87d\uddd5\ud816\udf71\udbdd\udd25\uda24\udcac",
        48, 30770, 279901916, -6529826253664517097L, -73077L, true, false, (char) 58085, (char) 31958,
        Double.longBitsToDouble(0x3fb9a4f0f1731780L), Double.longBitsToDouble(0x3fde679cb9398d14L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 4, 2, 2, "\ud93d\udef1\udab1\ude14", "\u9496\u5fa1\u93d8", "\uda1d\udc7f\uda42\uddcc\uda5a\udcb6\ud9fe\udd07\udb63\udeb8\uda70\udec4\u499d",
        28, 16152, 12561253, -4122029622519096672L, -42750L, false, true, (char) 51104, (char) 34900,
        Double.longBitsToDouble(0x3fb03346542f9078L), Double.longBitsToDouble(0x3fb393e7ffb6cb58L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "", "\u40c5", "\udb8d\udd5a",
        28, 53593, -807347015, -7916410082451980116L, 55010L, false, false, (char) 13666, (char) 37114,
        Double.longBitsToDouble(0x3fdfae48f0000000L), Double.longBitsToDouble(0x3e3f300000000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 2, "\ud965\uddf1\udab1\ude14\uda86\udc8b", "\u7206\u5986", "\ud86d\udc30\udaf0\udeab\u75c8\uda76\ude70\ud847\ude8d\uda60\udcea\ue29d\ud8f9\ude66\u9a05\ud902\udf70\udb9b\udf0d\udb8f\udfac\ud860\udd63\uda26\udc2f\ud860\udd18\udb24\ude1f\ud80e\udf16\ud807\uddcb\ud8f3\udf1d\ud81e\udf81\ud807\udeea\udac1\ude94\udad7\uddc8\ud9c7\udf9f\u1bb7\ud967\udc35\uda38\udc16\ud9b7\udec1\ud9e7\udefc\ud995\udf5b\ud900\udf38\ud889\udd45\ud9c5\udfdb\udb98\udfec\ud8ed\udf68\udbd0\uddef\udabe\ude29\udb98\udc33\ud9ea\udfce\ud95a\udfd9\ud886\udeae\udaf9\ude6f\uda94\udf04\ud948\udd21\udb09\uddf7\ud843\udda4\udb37\udf5a\udbb5\ude5d\udac9\ude55\ud929\udf8e\ud925\udfc4\u4fed\udad3\udf80\ub602\ud97f\udd7e\u88a3\ud8de\udeda\ud8b9\udfcf\ud9b5\udd2e\uda89\udd61\ud842\udee5\uda88\udf61",
        11, 32294, -999941947, 2456890052361581273L, -35047L, true, true, (char) 20736, (char) 1927,
        Double.longBitsToDouble(0x3fe747b1d6d0bf22L), Double.longBitsToDouble(0x3fe175ae44ad70e9L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 7, 2, "", "\uc6b1", "\ud86c\udec7\uda7b\udc12",
        8, 45985, -1843183047, 9289412965826560L, 33160L, true, true, (char) 21951, (char) 0,
        Double.longBitsToDouble(0x3fd0400006cb1292L), Double.longBitsToDouble(0x3ec7e28318000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b\udb00\udd03\ud870\udcfa\ud86c\udec7\uda7b\udc12\ud9a7\udcdd\u29e3\uda1c\udfbf\ud901\udf0b\ud973\udd0d\ud999\udcf2\udb8f\udcac\uda70\udec4\ue29d\ud8f9\ude66\ud800\uded9\ud902\udf70\udbe8\udc86\udb7a\udc09\ud9b4\ude5e\ud87d\udca4\ud87d\udc57\udb93\udf98\ud83c\uddec\ud807\uddba\ud8f3\udf1d\udaca\udc17\ud843\udc43", "\u4476\u2ecc", "\ud87e\ude3e\udb7f\udd01\ud9a6\udc7a\uda56\udeca\uda82\udea8\ud940\udc0d\ud876\ude98\udb5e\ude02\ua799",
        15, 59717, 1810656266, 797786703017072431L, 54203L, false, false, (char) 4828, (char) 27349,
        Double.longBitsToDouble(0x3fe6ee7b600f67ccL), Double.longBitsToDouble(0x3fd338b8634988b8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\ua505\u5986", "\uda1c\udfbf\ud901\udf0b\ud86b\uddc1\ud9fe\udd07\udb63\udeb8\uda70\udec4",
        3, 94803, -1991665404, 53950169872047078L, -55439L, false, true, (char) 49576, (char) 28412,
        Double.longBitsToDouble(0x3fe0b291f040cd19L), Double.longBitsToDouble(0x3fcf2bc1f272ec4cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 1, 7, "\ud965\uddf1\ud839\udcd8\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\udac1\uddda\ud8e3\ude4e\uda1c\udfd6\uda42\uddcc\uda5a\udcb6", "\ub357\u3a86\u1c7b\uc1d9\u9594\u7ba0\u717f\u69f2\u27e3\ub3b5\u7521\u9713\u204c", "\u4ff9",
        50, -865, 89033028, -1507306400080384129L, -32307L, true, false, (char) 36620, (char) 14729,
        Double.longBitsToDouble(0x3fdf73ffddc35e12L), Double.longBitsToDouble(0x3fe1b34b4bd7beb0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \ud965\uddf1\ud839\udcd8\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\ud8e3\ude4e\uda1c\udfd6\uda42\uddcc\uda5a\udcb6]] |a1=[Ljava.lang.String;:[[\ud965\uddf1\ud839\udcd8\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\ud8e3\ude4e\uda1c\udfd6\uda42\uddcc\uda5a\udcb6]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 1, 7, "\ud965\uddf1\ud839\udcd8\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\ud8e3\ude4e\uda1c\udfd6\uda42\uddcc\uda5a\udcb6", "\u87ff\ubfbe\u1c88\u1451\uc06d\u7ba0\u717f\u69f2\u13c6\ub3b5\u7521\ub1c1\ub7ba\u8b25\u31a5\u5b98\u996c\u69a5\ub802\u7400\u2021\u2913\u6143\u3e3b\u2384", "\ud907\udd17\udac4\ude5c\udaad\udd36\ud9b8\udc28\uda58\udfe6\ud979\udee4\ud82f\uddac\udba1\udf61\ud82d\uded5\udab5\ude37\ud883\udc21\udaf1\udffc\ud8cc\udd99\udaf1\uddb6\ud9f6\udd20\ud811\udf27\udaa3\udcdf\ud9b4\ude74\ud942\udeee\udbfb\udfde\ud80c\ude0b\udb40\udf9d\udb16\udee3\udbe7\udf0d\uda07\ude36\udb3b\udc4d\ud89f\udc3a\uda73\udc1b\u6280\udbc1\ude87\udb97\udc76\ud9a8\udd14\udaff\udd49\udae6\udc10\uda41\udc48\udac9\udc69\udb89\udf92\ud973\udc6b\udb74\udc16\uda11\ude71\ud850\ude19\udb03\udfa4\ud9df\udd56\uda68\uddac\uda8b\udf4d\udb3f\udd25\ud83b\udebb\udb85\udf75\ud8f6\ude5e\ud8b2\ude53\u784c\udb0f\udcf1\ud889\uddaa\uda86\udf79\udb1c\udec7\udab1\ude44\ud814\uddc5",
        13, 47713, -1988057515, -8467195255823627863L, -78752L, true, true, (char) 61424, (char) 19754,
        Double.longBitsToDouble(0x3fce352be3244574L), Double.longBitsToDouble(0x3fbd5497ca570558L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 7, "\udbd9\udcae\ud953\udeba\udb91\udef8\ud88e\udce8\udace\udf62\udb8d\udd5a\uda7b\udc12\ud91b\udfdd\ud8d1\udc4e\uda1c\udfd6\uda42\uddcc", "\u2b58\ub357\u3584\u23f2\u1451\u9aed\u6afc\uce82\u7c05\u998a\ub3b5\ua8fa\u5fec\ub7ba\u7b25\u31a5\u5b98\u996c\u69a5\ub802\u6b69\u7fc9", "\ud815\udea8\uda31\udc00\ud814\udd92\ud9fd\udc5c\u0435\ue818\ud884\udee5\udb24\ude89\udb09\udfd0\ud9f3\udc52\udad2\uddb5\ud83f\ude58",
        34, 83537, 921383211, -6584413990288788494L, 76563L, false, true, (char) 48657, (char) 6166,
        Double.longBitsToDouble(0x3fd260cb44066a00L), Double.longBitsToDouble(0x3f9c57f08f13d600L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 2, "", "\uc6b1", "\udb8d\udd5a\uda7b\udc12\ud9a7\udcdd\u29e3\uda1d\udc7f\uda42\udd20\uda6c\udf77\ud9fe\udd07\udb63\udeb8\ud8ca\udfb2\u0f1c\ud8f9\ude66\ud8e3\udd0c",
        -2, -770, -736323072, 532359267047235490L, 99411L, false, false, (char) 244, (char) 38036,
        Double.longBitsToDouble(0x3fc8bd88f4000000L), Double.longBitsToDouble(0x3fe7afdc88003035L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "", "\000", "\uafcb",
        -5, -1000, 0, 0L, -34464L, false, false, (char) 19895, (char) 36923,
        Double.longBitsToDouble(0x3e20404000000000L), Double.longBitsToDouble(0x3feb2c4a4be60000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "", "\u8cc5", "",
        -5, -1000, 0, 0L, 43311L, false, false, (char) 2088, (char) 13666,
        Double.longBitsToDouble(0x3fe9daadf800e48fL), Double.longBitsToDouble(0x3fe6002003658949L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 2, "\u669f\ud8fb\ude94\udbb7\udf5b\udaad\udd39\ud956\udf4c\udb5d\ude37\udbc3\udcb8\udb2e\ude5e\udbeb\udd10\uda1d\udc7f\uda42\uddcc\uda5a\udcb6\ud9fe\udd07\udb63\udeb8\udba4\udc5f\u24e2\ud972\ude9e\ud870\udc25\ud903\ude97\ud814\udef2\udb91\udd0e\ud9b6\udd5e\udb3e\udc77\udb45\udd68\uda21\ude01\ud8c2\uddd0\ud873\udfbf\ud9f5\udfd2\udbdc\udc31\ufc2b\ud9b9\udeeb\ud95d\uded8\ud832\udf6e\uda04\udf67\uda91\udc15\udb9e\udd03\ud99b\udc07\udb80\udf71\udb34\ude6e\uda57\udcdc\ud971\uddff\udaca\udfe3\udbbe\ude24\udb24\udd16\ud864\ude30\ud838\udcf0\ud8a9\udddf\ud823\ude74\uda4f\udee8\udbc4\udc2a\uda8c\uded5\ud9a5\udf04\udb7b\udc50\udbac\uddb7\ud835\udfb6\udb6f\ude17\ud92e\udd8f\uda34\udf03\uda3c\udfa9\udaf9\ude77\ud9b1\udfc0\ud892\udf6b", "\u480f\u8644\ud52c\u9194\u171f\u8cf6\u6adb\uc7d2\uac48\ub9d1\u7a44\u9fe2\u26ab\u11ca\u8d11\ucd2d\ua17f", "\udac6\uddb2\ud9eb\udf2b\ud8f6\udf29\uda5d\udc48\ud821\udde8\udb01\udf56\udbd9\udef9\udab3\udf30\ud82b\udcd3\udb47\udc48\ud9e9\udf8d\u0d7d\ud8c5\uddb2\ud82a\udc5d\ud9ba\udfd6\udb7e\udd85\ud9b7\udfe9\uae83\ud994\uddee\uda46\udcab\ud942\udf81\udb19\udc72\uda81\ude12\uda9b\ude93\udb8e\udd35\ud8f6\udf43\uda70\udc22\udaf6\udee0\ud9be\udc86\ud8f5\uddfd\ud9b5\udf2f\uda2a\ude73\ud9a1\uddbd\ud848\uded2\ud8cc\ude07\udb5d\udc2e\ud900\ude47\uda47\udc59\ud91c\ude23\udb9d\ude5b\ud8fa\udfec\ud98e\udd17\udb53\uddb8\ud8a5\udff4\udb31\ude2e\udb19\udfae\uda27\udde3\uda86\uddd0\udb39\udfd4\udb3e\udd02\ud8f5\udf28\ud897\udcbe",
        19, 55942, 562808135, 4048596751009224993L, 38915L, false, false, (char) 23840, (char) 43926,
        Double.longBitsToDouble(0x3fe90c987562195bL), Double.longBitsToDouble(0x3fdb4cc0a745d69aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 2, "\ud965\uddf1\udab1\ude14\udba4\udf5b", "\u7fa7\u5986\ud235\u3bb0\u50c3\ucf57\ua91c\u0df7\u2b50\ub357\u2ab5\u1c05\u1451", "\udb7a\udc09\ud9b4\ude5e",
        44, 43085, 1379822809, -3667840953633228736L, 99483L, true, false, (char) 40133, (char) 63836,
        Double.longBitsToDouble(0x3fe76a8b543fb34aL), Double.longBitsToDouble(0x3fea50e985e3af89L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processSingleHyphen|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
