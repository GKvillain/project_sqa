package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class PosixParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u135d\ubfa5\u8b92\u8a48\ua4c8\ud1c8\u085e\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\uca33\u2c57\ub74d", "\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -8338764205016811372L, -12127L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fc398266bba6eecL), Double.longBitsToDouble(0x3fc5eb8e4b72957cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 2, "\uda09\ude14\uda2b\uddcf\uda07\udce4", "\ua234\u33b5\u134d\u13ea\u210a\u0f9e\u968a\ud1c8\u5270\u8be7\ua5e0\u3a4e\u51c2\u1ef3\u7d02\u31b0\uabd9\ud5ee\u233a\u9b98\uc2f0\ucd83\u3740\u70c2\u03b0\u2c57\ub74d", "\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\uda46\udda3\ud937\udd35",
        10, 4149, 2058878589, -8843167361509955966L, 77715L, false, false, (char) 33988, (char) 27264,
        Double.longBitsToDouble(0x3fc398266bba6eecL), Double.longBitsToDouble(0x3fd855c72c312322L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda34\udf64", "\u4885\uc719\ud333\ubcdd", "\udb8a\udc88\udb71\udd26\udbe1\udc91",
        19, 11788, 1761569941, 6593537777165217314L, -41086L, true, true, (char) 45869, (char) 55840,
        Double.longBitsToDouble(0x3fb78372e45965f0L), Double.longBitsToDouble(0x3fe5aa7fef765f3fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda0b\udd67\ud96c\udca8\uda24\udc4c\udbb2\udf9b\ud859\udcc6\udaf0\udcdf\ud871\udcee\udab1\udfc5\u91e9\ud9d9\udd64\udb70\udd1b\udbd9\uddb7\ua791\udb05\udc0d\ufac5\udbe5\udf14\ud8a2\udc4d\ud979\udcb3\ud88f\uddb3\udb92\udfe8\ud873\udca7\udad8\uddc4", "\u9b98\ua000", "\uda5e\ude31\udaf5\udec3\u4e14\udaab\udd1e\ud951\ude54\ud9df\ude38\u9c99",
        46, 34270, 1542330134, 8149148573691911187L, -58381L, false, false, (char) 27053, (char) 34010,
        Double.longBitsToDouble(0x3fc77bc750c03eacL), Double.longBitsToDouble(0x3fec2eb90d3adacbL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 5, 0, "\uda34\udfbe\uda05\ude82\ud88d\uddad", "\u62c3\ua148\u8f6f\u8a33\u8b92\u8a48\ua4c8\ud1c8\u085e\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\u819e\uafaa\ua5d8\u6f71\uca33\u2c57\u46da", "\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -8299076233300608876L, -12127L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fef9e099aee9bc2L), Double.longBitsToDouble(0x3fc5eb8e4b72957cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\udabf\udca3\ud967\udf20\udba1\udc50", "\u53b3\u84ad\u0ad0\ubfa5\u9888\u9628\u2b13\u3377\u085e\u9106\ua666\ua0db\u3bdb\u80ed\ubacf\ub560\u185c\uab2b\ud31a\u9b98\uc2f0\u4fe3\ua6bd\u2ab5\u4c8d\ubed8\ub74d\u1ded\u082b\u9621\u9b7b\uce87\u75a5\u85d8\ucff7\ua03f\u768a", "\udb2f\udc2b\ud9b3\udcee",
        53, 88294, 1504304285, -4525254566396303204L, -58534L, false, true, (char) 35000, (char) 2433,
        Double.longBitsToDouble(0x3fe4278704374868L), Double.longBitsToDouble(0x3fe719cdd802d1fbL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 0, "\000\ud924\udee8\ud9e8\udff4", "\ud333\u4166\u12c7\u1500\000\000\ua4b0\u009d\000\000\u54b9\ua0db\u3bdb\u1ef3\000\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\uca33\u2c57\ub74d", "\u9c99\000\000",
        -5, -1000, -1543503872, 1669988352L, 80771L, false, false, (char) 1014, (char) 29855,
        Double.longBitsToDouble(0x3fee9009e8000071L), Double.longBitsToDouble(0x3ec5200304cc0000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda34\udfbe\uda2b\uddcb\ud965\udf2f", "\ua4bf\u2396\u68e1\ubfa5\u8b92\u8a48\ua4c8\ud1c8\u085e\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\uca33\u2c57\ub74d\uc5ee\u07d1\u958c\u1c12\u3f8e\ua40a\u9bd7\ud0ab\ua03f\u385c\u5fef\ud0fa\ub88d\u7889\u18b9\u6916\u0ee2\u6e5d\u01c6\uc07f\u6451\u4d58\u5b0f\u84f4\ubad8\u6c39\u7e18\u7682\u3439\u85c1\u8c99\u0239\u32e1\ubbdb\u7cc8\u4cbd\u6b71\ua0f7\uc236\u7576\u33dc\u392a\u4721\u2405\u38ad\ub7e9\u1689\u8cac\u85de\u2d39\u1ff9\uc450\u7e3f\u55f9\uaebc\ub13a", "\udab3\udf73",
        27, 57971, 293780414, -3979326395940686095L, 85932L, true, false, (char) 11216, (char) 58862,
        Double.longBitsToDouble(0x3feec9712f750336L), Double.longBitsToDouble(0x3fdb2e19d0ca1c74L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 3, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u135d\ubfa5\u495c\u8a48\ua4c8\ud1c8\u085e\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\u1a1f\u2c57\ucb4d", "\u3599\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -8338764205016811372L, -12127L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fc398267ee26eecL), Double.longBitsToDouble(0x3fc5fd080b72957cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 0, "\ud9ae\udfb6\uda2b\uddcb\uda07\udce4", "\ud333", "\uda59\udd43\udb8a\udc88\udb71\udd26\udbe1\udc91\ua791\udab0\udea3\ufac5\udbe5\udf14\ud8a2\udc4d",
        48, -778, 135560047, -3772477458988986757L, -29399L, true, false, (char) 34485, (char) 59495,
        Double.longBitsToDouble(0x3f8562b8de506980L), Double.longBitsToDouble(0x3feab344cb4b0febL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u135d", "\udb71\udd26\udbe1\udc91\ua791\udab0\udea3\ufac5\udbe5\udf14\ud8a2\udc4d\ud979\udcb3\udb39\udd88\udbc1\uded7\ud873\udc78\ud825\udf4b\uf301\udb57\udcf1\udbe8\udc51\ud9ab\ude65\uda57\ude15\ud988\udfe8\u89a3\ud89d\ude46\udb50\ude26\udae2\udfa9\ud951\ude54\ud9e4\uddf5\ud808\udf97\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2\ud8b2\udd85\udaea\udc3f\ud979\uddb8\ud84c\udf51\uda03\ude96\ud801\udf76\udabb\udf53",
        16, 75357, -902276204, -7224925225648739602L, -58910L, false, true, (char) 38638, (char) 19904,
        Double.longBitsToDouble(0x3fd67ce6c25b33c4L), Double.longBitsToDouble(0x3fe117daed6dcfa1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda34\udfbe\uda2b\uddcb\uda07\udce4]] |a1=[Ljava.lang.String;:[[\uda34\udfbe\uda2b\uddcb\uda07\udce4]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u135d\ubfa5\u8b92\u8a48\ua4c8\ud1c8\u085e\u9106\ua666\ua0db\u3bdb\u1ef3\u9902\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\uca33\u2c57\ub74d", "\ud818\ude51\udb72\udf6c\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -8338764205016811372L, -12127L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fc398266bba6eecL), Double.longBitsToDouble(0x3fc5eb8e4b72957cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 0, "\ud848\udc08\uda2b\uddcb\uda07\udce4", "\u0085", "\uda59\udd43\udb8a\udc88\udb71\udd26\udbe1\udc91\ua791\udab0\udea3\ufac5",
        18, -966, -965935104, 4686428473967016815L, -38171L, false, false, (char) 16519, (char) 50785,
        Double.longBitsToDouble(0x3eaf800000000000L), Double.longBitsToDouble(0x3f8562b8de506980L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 6, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "\uc1fd\u84b1\u135d\ubfa5\u8b92\u8a48\ua4c8\u98c9\u07da\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud2ae\u3a68\uc329\ucd83\ua5d8\u2f72\uca7c\u2c57\u786a", "\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        32, 55394, 2055067091, -8338764205016811372L, -12127L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fc398266bba6eecL), Double.longBitsToDouble(0x3fc5eb8e4b72957cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u135d\ubfa5\u8b92\u8a48\ua4c8\ud1c8\u085e\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\ua06c\000\000", "",
        28, 83911, 696733270, 6624257487062669172L, -32564L, true, true, (char) 29855, (char) 17679,
        Double.longBitsToDouble(0x3fc3ae0e23cd66a4L), Double.longBitsToDouble(0x3fc398266bba6eecL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda34\udfbe", "\u4885", "\udb23\udf67\000\uda59\udd43",
        40, 16460, 48152, 1165595150738800596L, -79091L, false, false, (char) 42277, (char) 20555,
        Double.longBitsToDouble(0x3e83ef4205000000L), Double.longBitsToDouble(0x3fe3de5d285e0dcbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u135d\ubfa5\u8b92\u8a48\ua4c8\ud1c8\u085e\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\uca33\u2c57\ub74d", "\u9c99\ud842\udf8d\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -8338764205016811372L, -12127L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fc398266bba6eecL), Double.longBitsToDouble(0x3fc5eb8e4b72957cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 3, 1, 7, "\uda20\ude62\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u13c1\ubfa5\u8b92\u816b\ub4fb\u5ed4\u087b\u9106\ua666\ua0db\u3bdb\u1ef3\u89b7\u30fb\u06d4\u4566\u9002\u9b98\ub9dc\u679e\ua5d8\u6f71\uca33\u2c57\u0eb0", "\uda18\udcab\ud842\udf1c",
        19, 59134, -665806988, -1672752166570286918L, -32564L, true, true, (char) 29855, (char) 17648,
        Double.longBitsToDouble(0x3fc3ae0e23cd66a4L), Double.longBitsToDouble(0x3fc398266bba6eecL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 4, 5, 0, "\ud8e0\ude30\uda2b\uddcb\ud919\udced", "\ud362\u84fc\u135d\ubfa5\uaa17\u3d5a\ua4c8", "\ufafc",
        18, 55394, -965933032, -1761416674003140330L, -38171L, false, false, (char) 16519, (char) 50785,
        Double.longBitsToDouble(0x3febb2f9fab875afL), Double.longBitsToDouble(0x3f8562b8de506980L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda13\udf48\uda2b\uddcb\ud847\udc44\udbc1\udc8a\ud859\udc71\udaf0\udcdf", "\ubfa5\u85f1\u9c73\ua4c8\ud1c8\u085e\u9106\ua666\u7f56", "\udb92\udfe8\ud873\udca7\uda51\ude60\uf301\udb57\udcf1\udbe8\udc51\ud9ab\ude65\u5615\ud9fc\udfe2",
        46, 26318, -324902069, 3303927946217427391L, -32564L, false, true, (char) 40314, (char) 17798,
        Double.longBitsToDouble(0x3fc3ae0e23cd66a4L), Double.longBitsToDouble(0x3fc398266bba6eecL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\uda34\udfbe\uda2b\uddcb\uda07\udce4", "", "",
        27, 79706, -550591880, 3911140927201459224L, -83660L, true, false, (char) 26879, (char) 11810,
        Double.longBitsToDouble(0x3f989d0d3bd8cda0L), Double.longBitsToDouble(0x3feb7a084fbd0814L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 7, 5, 0, "\uda34\udfbe\uda2b\uddcb\udade\udf50", "\ud333\u84fc\u9523\u4c03\u6339\u525e\ua4c8\ud1c8\u085e\u2f8b\ua666\ua0db\u3bdb\u1ef3\uce71\u31b0\u2bcd\u8f6a\ud31a\ub8ed\u498f\u2efd\ua51b\uc53e\uca33\u2c57\uaea0", "\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\ud800\ude5e",
        21, 66155, 2055874401, -8338764206129531283L, -63327L, false, true, (char) 19726, (char) 27144,
        Double.longBitsToDouble(0x3fc0c2a66bb8a01cL), Double.longBitsToDouble(0x3fc5eb8e4b72957cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 0, "\uda34\udfbe\udb35\udf67\ud907\ude43", "\ud333\u84fc\u135d\ubfa5\u8b92\u8a48\ua4c8\u1e52\u07e9\u9106\ua666\ubce2\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6770\uca33\u2c57\ub74d", "\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -2213868709884059343L, 32058L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fc398266bba6eecL), Double.longBitsToDouble(0x3f8e30e4b7295a80L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 0, "\uda34\udfbe\uda05\ude82\ud88d\uddad\ud8f3\udc5c\udab5\uddc2\ud89e\udc1d", "\u86a9\u33a7\u8a48\ua4c8\ud1c8\u085e\u9dc3\ua5d1\ua0db\u3bdb\u1ef3\u7d02\u31b0\u231a\ua4b6\ud50c\u9b98\u819e\uafaa\ua5d8", "\udb50\ude26\udb68\uddc8\ud9e4\udf03\ud924\udd8a\ud8c2\udc3a\ud837\udf0a\uda97\udfd3\udbd2\udf4b\ud87d\ude1e\udba5\udeb2\ud8b2\udd85\udaea\udc3f\ud996\udda7\ud99c\udf89",
        45, 30307, 20797249, 8102331775342730397L, 10605L, false, false, (char) 49441, (char) 49211,
        Double.longBitsToDouble(0x3fafdfe152ab0960L), Double.longBitsToDouble(0x3feda90a53d2a3e0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 7, 0, "\uda34\udfbe\uda05\ude82\ud88d\uddad", "\u62c3\ua148\u8f6f\u8a33\u8b92\u8a48\ua4c8\u7343\uc972\u3a2e\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\u819e\u35be\ua639\u6f71\uca33\u42aa\u46da", "\u9c99\ud842\udf26\udad9\udd78\udbd2\ude1e\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -8299076233300608876L, -12127L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fef9e099aee9bc2L), Double.longBitsToDouble(0x3fc5eb8e4b72957cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 0, 0, "\ucfff\000\ud86a\udff5", "\u62c3\ua148\u008e\000\uc119\u8a48\ubc18\000\u57b4\u9106\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u0e7b\u2140\000\000\000\000\ub509\u6f71\u9b33\u2c57\u46da", "\u9c99",
        46, 34270, 1542330134, -1530331136L, -54334L, false, false, (char) 49663, (char) 36199,
        Double.longBitsToDouble(0x3fdbb0000e823abcL), Double.longBitsToDouble(0x3fca4027b2740000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 0, 5, 0, "\000", "\u4885\uc719\u62c3\ua148\u8f6f\u8a33\u8b92\u8a48\u847d\000\u57b4\000\000\000\u3bdb", "\ud873\udca7\udbdb\ude86\uf301",
        47, 88037, -1922905738, -5653737167434405878L, -3744L, true, true, (char) 46493, (char) 54649,
        Double.longBitsToDouble(0x3fe3f9cd5e564ef3L), Double.longBitsToDouble(0x3fe8b14c3f745beeL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 2, 5, 0, "", "", "\ud845\udee2",
        28, 46483, 706098574, -871165053470072200L, -34464L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd0000000000000L), Double.longBitsToDouble(0x3f9800003bd8cda0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 6, 3, 2, "\udabf\udca3\ud967\udf20\udaf6\udd3a", "\u4e5d\u69c3\ua2b0\ubf85\u9888\u9628\ubcaa\u3377\u085e\u9106\ua666\ua0db\u3bdb\u80ed\ubacf\ub560\u185c\uab2b\ud31a\u9b98\uc2f0\u4fe3\u7bc6\ua595\uceec\u98af\ub74d\u39a5\u082b\u4e6c\u9b7b\ucebb\u0320\u2268\ub020\ua03f\u3e5c", "\udb2f\udc2b\ud9b3\udcee\udbc0\udf30\ud9f8\udcdf\ud937\udc6a\ud80b\uddcb\ud893\uddab\udad2\udc60\udbea\uddb6",
        16, 41582, -1891831818, -1765699693165141502L, 58775L, false, true, (char) 50001, (char) 54506,
        Double.longBitsToDouble(0x3fd76373d2cafd3eL), Double.longBitsToDouble(0x3fdb1c53221d821aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 0, "\u2b8b\udb0b\udc9e\ud965\udeb8\udb22\uddc7\ud859\udc71\uda55\udeaf\ud912\ude20\ud989\udd8a\uda59\udd43\udb8a\udc88\udb71\udd26\udb80\ude1f\uda7b\ude4c\udb6c\udd33\ud9c5\ude34\ud8c1\udf42\ud9f3\uddbb\ud979\udcc4\ud88f\uddb3\udb92\udfe8\ud859\udd09\ud825\udf4b\uf301\udb57\udcf1\udbe8\udc51\udaa5\udc82\uda57\udde5\ud988\udfe8\u89a3\ud86e\udc46\udb50\ude26\udae2\udfa9\ud945\ude01\ud9df\uddde\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud966\uddb4\udb89\udf66\ud8b2\udd85\udaea\udc3f\ud979\uddb8\ud84c\udf51\uda03\ude96\ud801\udf76", "\u0ee2\u6e5d\ucdc4\uc07f", "\udb59\ude75\ud890\udebc\uda3a\udfad\ud844\uddf8\uaa1b\uda98\udec1\ud986\ude35\uda7f\udd8c\ud924\udc50\ud8cc\udedb\udb6c\ude8e\uda2c\udf65\ud852\udf81\ud83f\udc8e",
        40, 43237, -1605219427, 8273575825738870961L, -69247L, true, false, (char) 24153, (char) 41230,
        Double.longBitsToDouble(0x3fea52838e0364e0L), Double.longBitsToDouble(0x3fc3b6b70ef48e28L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 0, "\ud9ae\udfb6\uda2b\uddcb\uda07\udce4\000\udb72\udd10\udaf0\udcdf\ud8b1\udf0e\ud933\udfd0\ud9fa\uddb1\ud85c\udcaa\udb75\ude7f\udbe1\udc91\ua791\udab0\udea3\ufac5\uda40\udfc2\uda43\udd7f\ud979\udcb3\u00de\udb92\udfe8\ud873\udca7\ud825\udf4b\uf2a3\udb57\udcf1\udbc0\udd51\ud9ab\ude65\uda57\ude15\ud988\udfe8\u89a3\udbf0\udc27\udbb2\udd0e\ud9d5\udcff\ud950\udcbe\uda71\udf48\udbd6\udd6a\udae5\udefa\udaad\udcae\ud9e0\udfcf\ud8a2\udd7f\udba6\udeed\udba5\udf68\udb62\udda6\udb6a\udfd7\udbfb\udd8a\ud843\udc2d\u568b", "\u4b69\u6e46\u9401\u9701", "\udb5e\udd0f\uda1b\udcd4\ud9d4\udff9\udb72\udd19\ud8a6\uddc5\udb9d\udcfc\udb8a\udd05\uda91\udec3\ud8b9\uddec\udb19\udc02\udbd8\udc9b\uda37\udcc8\udacf\ude51\ud9ba\udcc1\udb4d\udcbe\ud98a\udccc\ud8c3\udecf\ud869\udec4\ue5fa\ud985\udea5\uda52\udea3",
        53, 84744, 356547692, -2764294834573503746L, 40581L, true, true, (char) 12128, (char) 27504,
        Double.longBitsToDouble(0x3fc5a7f92d727030L), Double.longBitsToDouble(0x3fe1af37814790c2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda48\udead\ud92e\uddcd\ud81b\ude80]] |a1=[Ljava.lang.String;:[[\uda48\udead\ud92e\uddcd\ud81b\ude80]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 0, 5, "\uda48\udead\ud92e\uddcd\ud81b\ude80", "\ud333", "\uda4c\udc7d\ud8e8\udf40\udb71\udd26\udbe1\udc91\ua791\udab4\udfa3\ud9da\udf94\udbe5\udf14\ud8a2\udc4d",
        3, 98764, -121859725, -56036106194478471L, -29399L, true, false, (char) 34485, (char) 14184,
        Double.longBitsToDouble(0x3f8562b8f0e75780L), Double.longBitsToDouble(0x3fece344cb4b0febL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \ud9ae\udfb6\udb1d\udcf4\ud97e\udde3]] |a1=[Ljava.lang.String;:[[\ud9ae\udfb6\udb1d\udcf4\ud97e\udde3]] |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\ud9ae\udfb6\udb1d\udcf4\ud97e\udde3", "\u3c84\u84d3\u135d\u0e77\u3788", "\ua791\ud9fe\udd2a\ufac5\uda22\ude33\ud88a\udc7b\uda01\uddcf\udad1\udc93",
        53, 67380, -1354453893, -202264802259249568L, 75481L, true, true, (char) 41112, (char) 36895,
        Double.longBitsToDouble(0x3fee055415bb77f9L), Double.longBitsToDouble(0x3fa3ed8746272b00L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\ud9ae\udfb6\ud853\udcc0\uda07\udc3d]] |a1=[Ljava.lang.String;:[[\ud9ae\udfb6\ud853\udcc0\uda07\udc3d]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 1, 0, "\ud9ae\udfb6\ud853\udcc0\uda07\udc3d", "\u1cd8", "\uda59\udd43\udb8a\udc88\udb71\udd26\udbe1\udc91\ua791",
        22, 27941, 1539068333, -7129991070646204392L, -10779L, false, false, (char) 51421, (char) 37461,
        Double.longBitsToDouble(0x3fda8093f167ea52L), Double.longBitsToDouble(0x3faf089b37941a60L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud9cb\udd98\uda48\udcdb\uda07\udce4\ud8f3\udc5c\ud859\udc71\udaf0\udcdf\udb23\udf67\udab1\udfed\uda59\udd43\udb8a\udc88\udb71\udd26\udbe1\udc91\ua791\ud962\udddc\ud810\udc12\udbe5\udf14\ud8a2\udc4d\ud979\udcb3\ud88f\uddb3\udb99\udfe8\uda93\udfb7\ud8d7\udc9c\ud808\uddaf\udb57\udcf1\udbe8\udc51\ud9ab\ude65\uda57\ude15\ud988\udfe8\u89a3\ud86e\udc46]] |a1=[Ljava.lang.String;:[[\ud9cb\udd98\uda48\udcdb\uda07\udce4\ud8f3\udc5c\ud859\udc71\udaf0\udcdf\udb23\udf67\udab1\udfed\uda59\udd43\udb8a\udc88\udb71\udd26\udbe1\udc91\ua791\ud962\udddc\ud810\udc12\udbe5\udf14\ud8a2\udc4d\ud979\udcb3\ud88f\uddb3\udb99\udfe8\uda93\udfb7\ud8d7\udc9c\ud808\uddaf\udb57\udcf1\udbe8\udc51\ud9ab\ude65\uda57\ude15\ud988\udfe8\u89a3\ud86e\udc46]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 1, 1, 5, 7, "\ud9cb\udd98\uda48\udcdb\uda07\udce4\ud8f3\udc5c\ud859\udc71\udaf0\udcdf\udb23\udf67\udab1\udfed\uda59\udd43\udb8a\udc88\udb71\udd26\udbe1\udc91\ua791\ud962\udddc\ud810\udc12\udbe5\udf14\ud8a2\udc4d\ud979\udcb3\ud88f\uddb3\udb99\udfe8\uda93\udfb7\ud8d7\udc9c\ud808\uddaf\udb57\udcf1\udbe8\udc51\ud9ab\ude65\uda57\ude15\ud988\udfe8\u89a3\ud86e\udc46", "\u1ded\u082b", "\ud938\udc1e\udb9d\udc80\ud87d\ude1e\udba5\udeb2\ud8b2\udd85\udaea\udc3f\ud979\uddb8\udbe8\udc7c\ud9c8\udc7f\uda32\ude78\udabb\udf53\ud954\ude72\udaca\udde5\uda1d\udd3f\ud928\udeb3\udad2\udc60\ud841\udd01\ud9c2\ude51\udadf\udc3b\udbda\udddd\ud91a\udec5\uda09\udf7b\uda07\uddfb\ud956\ude68\ud94b\udf4d\udbc9\ude52\udbdf\udd3a\uda28\udde4\ud82d\udebe\udad8\ude69\udb84\udd59\ud974\udeed\uda5a\ude51\uda78\ude02\u1dd2\udb02\ude46\ud95d\udea5\ud9c4\udd9d\udbe6\udf98\ud9dc\uddfe\uda30\ude87\ud802\udfde\ud8f7\udc00\udbad\udd3f\uda80\udfff",
        21, 94872, -510097719, -2528824579034216130L, 41348L, false, false, (char) 30480, (char) 12453,
        Double.longBitsToDouble(0x3fdccc77f6d6e662L), Double.longBitsToDouble(0x3fc22e1b565ca390L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda2b\udc5e\uda2b\uddcb\uda07\udce4]] |a1=[Ljava.lang.String;:[[\uda2b\udc5e\uda2b\uddcb\uda07\udce4]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 4, 3, "\uda2b\udc5e\uda2b\uddcb\uda07\udce4", "\ud333\u84fc\u135d\ubfa5\u489c\u8a48\ua4c8\u1f98\u0828\u9106\ua4f6\ua0db\u3bdb\u1ef3\u9902\u31ef\u294b\uaade\ud31a\u9b98\uc2f0\u28c7\ua5d8\u6f71\uca33\u2c57", "\ud9df\ude38\ud818\ude51\udb72\udf6c\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e",
        16, 3631, 1670034018, 8842816204248105507L, -83142L, true, true, (char) 11241, (char) 19726,
        Double.longBitsToDouble(0x3fce6b35242275bcL), Double.longBitsToDouble(0x3fe774db6caf5c72L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u3ea7", "\u0085",
        -5, -1000, 0, 910633216L, -34464L, false, true, (char) 40009, (char) 26879,
        Double.longBitsToDouble(0x3fa1000000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \uda34\udf32\uda0c\udc1b\ud9ce\udfd0\udae9\udc02]] |a1=[Ljava.lang.String;:[[\uda34\udf32\uda0c\udc1b\ud9ce\udfd0\udae9\udc02]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 2, 0, "\uda34\udf32\uda0c\udc1b\ud9ce\udfd0\udae9\udc02", "\u84fc\u135d\ubfa5", "\udbe1\udc91\ua791\udab0\udea3\ufac5\udbe5\udf02\ud8a2\udc4d\ud979\udcb3\ud88f\uddb3\udb92\udfe8\ud873\udca7\ud825\udf4b\uf301\udb57\udcf1\udbe8\udc51\ud821\ude60\uda57\ude15",
        31, 95649, 267071318, -1395443759988509962L, 57655L, true, true, (char) 145, (char) 40265,
        Double.longBitsToDouble(0x3fe8b14c3f745beeL), Double.longBitsToDouble(0x3f93711777549920L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=new org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 7, 7, 0, "\uda34\udfbe\udb35\udf67\ud907\ude43", "\ud333\u84fc\u135d\ubfa5\u8b92\u8a48\ua4c8\u1e52\u07e9\u9106\ua666\ubce2\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6770\uca33\u2c57\ub74d", "\u9c99\ud842\udf26\ud9fa\udcc8\udb9d\udc80\ud87d\ude1e\udba5\udeb2",
        58, 99018, 2058878589, -2213868709884059343L, 32058L, false, true, (char) 19726, (char) 27292,
        Double.longBitsToDouble(0x3fc398266bba6eecL), Double.longBitsToDouble(0x3f8e30e4b7295a80L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda70\udd2f\udb37\udc23\ud907\ude43]] |a1=[Ljava.lang.String;:[[\uda70\udd2f\udb37\udc23\ud907\ude43]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[\uda70\udd2f\udb37\udc23\ud907\ude43]] |a1=[Ljava.lang.String;:[[\uda70\udd2f\udb37\udc23\ud907\ude43]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda70\udd2f\udb37\udc23\ud907\ude43", "\ud333\u84fc\u135d\ubfa5\u8b92\u8a48\u2bc8\u1e52\u07e9\u9106\ua666\ubce2\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\u7024\u978f\uc2f0\ucd83\ua5d8\u6770\uca33\u2c57\ub74d", "\u9c99\ud842\udf26\uda7e\udf6b\ud85b\ude3a\ud87d\ude1e\udba5\udeb2\ud8b2\udd85\udaea\udc3f\ud979\uddb8\ud9d2\udc53\ue5e8\udb8b\udcac",
        26, 14121, 1504304285, -4525254566396303204L, 69999L, false, false, (char) 58678, (char) 34145,
        Double.longBitsToDouble(0x3fc00af35e2e33d0L), Double.longBitsToDouble(0x3fea9350464eb6cbL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 2, 2, 0, "\uda34\udfbe", "\u4885\u4b31\u62c3\ua148\u0d3f\u2a88\uc21f\u8a48\ua4c8\ud1c8\u085e\u9dc3\ua5d1\ua0db\u3bdb", "\ud873\udca7\udaca\udca4\ud99b\udf78",
        25, 88037, -1922905738, -5653736441584932713L, 88937L, true, true, (char) 25894, (char) 50193,
        Double.longBitsToDouble(0x3fe9c64cea19e384L), Double.longBitsToDouble(0x3fd248b4310120e6L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[--, \udade\udc91]] |a1=[Ljava.lang.String;:[[\udade\udc91]] |this=org.apache.commons.cli.PosixParser:@?\0121=[Ljava.lang.String;:[[--, \udade\udc91]] |a1=[Ljava.lang.String;:[[\udade\udc91]] |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 1, 3, "\udade\udc91", "\u154e\u9d4a\u3cb9\u84d3\u135d\u0e77\u3788\u8260\u5631\ud1c8\u9abc\u9106\u2c3f\ucfce\u8b9b\u1227", "\u97b9\uda86\udd11\ud97d\udce3",
        15, 62559, 1383023526, -1463237630526075271L, 44827L, true, false, (char) 61202, (char) 37510,
        Double.longBitsToDouble(0x3fd01b5f33a90b46L), Double.longBitsToDouble(0x3fe14fc157b154ceL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000", "", "\ud93c\uddb4\udb23\udf3e\000\udb76\ude97\ud81c\ude90",
        56, -1000, 271386112, 1761569792L, 94868L, false, true, (char) 48605, (char) 30752,
        Double.longBitsToDouble(0x3fae57a2660fd000L), Double.longBitsToDouble(0x3f4cd8aa1c000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 0, "\ud8d7\udcef\uda2b\uddcb\uda07\udce4\ud8f3\udc5c\udbbe\udd7d\udaf0\udcdf\udb23\udf67\udab1\udfed\uda59\udd43\udb8a\udc88\udb71\udd26\udbe1\udc91\ua791", "\ua666\ua0db\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9b98\uc2f0\ucd83\ua5d8\u6f71\uca33\u2c57\ub74d\u1ded\u082b\u958c\u1c12\ua797\ua40a\u857d\ucff7", "\ud979\uddb8\ud84c\udf6a\uda03\ude96\udb35\ude71\udb8c\udc4d\udaa1\udf1b\ud842\ude6a\uda1d\udcd1\ud928\udeb3",
        39, 79039, -1267590436, 4811801712510913308L, 16344L, true, false, (char) 44694, (char) 43652,
        Double.longBitsToDouble(0x3fd032b77b2a9bb6L), Double.longBitsToDouble(0x3fdcbaec98a97360L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 0, "\u2b8d\udb0b\udc9e\ud965\udeb8\uda90\ude5e\ud859\udc71\uda55\udeaf\ud912\ude20\ud804\udc88\uda8b\udc94\udb8a\udc88\udb71\udd26\ud904\udf38\uda7b\ude4f\udb6c\udd33\udaf4\udc6c\udb32\udc7b\ud865\udc61\udb25\udd62\ud88f\uddb3\udb93\udc16\ud859\udd09\udab1\udf1e\uf301\ud8e9\udeae\udbe8\udc51\udaa5\udc82\uda57\udde5\ud988\udfe8\u89a3\ud86e\udc46\udb50\ude26\udae2\udfa9\ud945\ude01\ud9df\uddde\u9c99\uda25\udc58\ud8c2\udd0d\ud824\udd63\ud966\uddb4\udb89\udf66\ud8b2\udd85\udaea\udc3f\ud99f\udf43\uda39\udd29\udaff\udda2\ud8a7\udf88", "\u0ee2\u6e5d\ucdc4\uc07f\u6451\u4d58\uc3b5\u84f4\ubad8\u6c39\u3581\ubf8c\u3439\u85c1\u8c99\u0239\u95cc\u7500\u524d\u56cc\u9fd3\u984c\uc236\u40e9\u33dc\u392a\u4721\u2405\u1134\ub7e9\u1689\u9ca2\u85de\u48e7\u1ff9\u01d4\u56d9\u55f9\uaebc\u377f\ud065\u65ea\u027f\uc459\ud314\ua5a2\u4bef\ubd91\u9694\u7060\u8d71\ua165\u07cf\u7f29\uad49\u82e3\u6aec\u5cac\u9777\u6fbb\ud56f\u7631", "\uda51\udf58\u822e\ud805\udc6f\ud834\udfca\ud808\udd85\udafb\udd3b\udb1c\ude74\udaa4\udd30\udaf6\udf80\ud9af\udfeb\ud9de\udf66\ud8ea\udfc9\udb81\udf18\u416f\udbc2\udfd1\udb19\udc3c\ud9bf\ude11\ud8f9\uddbf\ud81a\udc94\udb86\udf42\ud84c\ude6b\ud95c\udf91\udadc\ude36\ud921\ude5d\ud891\udff5\udbb9\udedf\udb34\udead\ud93a\udcf4\udb47\udd11\ud83d\udc78\uda63\udcfb\udb9e\udef3\ud9ee\udd14\udb6c\ude99\udbc4\ude73\uda40\udf1e\ud8a1\udc78\udbe6\udea0\ud82d\udc6b\uda0c\udd28\ud9ef\udd4c\ud8fb\udf72\u4f42\ud8ce\udc52\ud8b4\udc2e\ud81b\udfcb\u5a4d\ud93c\udd83\ud809\udf11\ud95d\udccb\ud8fb\udedd\udb78\udcfd\ud8c4\udd55\ud96d\udcd3",
        23, 81319, -598015644, 2633475889516480029L, 80143L, false, true, (char) 62756, (char) 47454,
        Double.longBitsToDouble(0x3fe6f8cf46ce167eL), Double.longBitsToDouble(0x3fee08280843124cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\uda34\udf32\uda0c\udc1b\ud9ce\udfd0\udae9\udc02\ud859\udc71\udaf0\udcdf]] |a1=[Ljava.lang.String;:[[\uda34\udf32\uda0c\udc1b\ud9ce\udfd0\udae9\udc02\ud859\udc71\udaf0\udcdf]] |this=org.apache.commons.cli.PosixParser:@?\0121=void |this=org.apache.commons.cli.PosixParser:@?\012",
        Z.run(T, 2, 1, 2, 0, "\uda34\udf32\uda0c\udc1b\ud9ce\udfd0\udae9\udc02\ud859\udc71\udaf0\udcdf", "\ubfa5\u8b92\u8a48\ua4c8\ud1c8\u9440\u9106\u4455\ua0db", "\udb92\udfe8\ud873\udca7\ud825\udf4b\uf301\udb57\udcf1\udbe8\udc51\ud821\ude60\uda57\ude15\ud988\udfe8",
        59, 26318, -324902069, 3303798203845349823L, -11558L, false, false, (char) 16965, (char) 38906,
        Double.longBitsToDouble(0x3fd5e0c7e2d84b70L), Double.longBitsToDouble(0x3fe1bb08cca01b8fL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.PosixParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 0, "\uda34\udfbe\udb35\udf67\ud907\ude43", "\u5684\u00a0\000\000\000\u6054\ua4c8\u1e52\u07e9\u9106\ua666\ubce2\u3bdb\u1ef3\u7d02\u31b0\u06d4\u4566\ud31a\u9ae3\uc2f0\ucd83\ua5d8\u6770\uca33\u2c57\ub74d", "\u9c99",
        46, 34270, 1542330134, 8149148573691911187L, 76738L, true, false, (char) 15578, (char) 632,
        Double.longBitsToDouble(0x3fec4a8014268b99L), Double.longBitsToDouble(0x3fee9009ec9d7071L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|gobble|java.util.Iterator|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|init||new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|process|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processOptionToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
    "M|org.apache.commons.cli.PosixParser|processSingleHyphen|java.lang.String|new:org.apache.commons.cli.PosixParser:",
    "C|org.apache.commons.cli.PosixParser|<init>|",
    "M|org.apache.commons.cli.PosixParser|burstToken|java.lang.String,boolean|new:org.apache.commons.cli.PosixParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
