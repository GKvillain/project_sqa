package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\uc318\u7e12", "\uda19\udd01\ud950\udce3\ud813\ude33\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        47, 27660, 662190280, 5887897504363093148L, -19643L, false, false, (char) 36660, (char) 32956,
        Double.longBitsToDouble(0x3fea209bd2f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud847\ude88\udaa5\ude4a\ud9c5\udff2\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\000\u7d5b", "\uda19\udd01\ud950\udce3\ud813\udd34\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        47, 27660, 662190280, 5887897504363093148L, -100000L, false, false, (char) 0, (char) 31204,
        Double.longBitsToDouble(0x3fa4e385ec791f50L), Double.longBitsToDouble(0x3fea209bd0f9da6bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\udbbd\ude50\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\uc318\u7e12", "\uda19\udd01\ud950\udce3\ub233\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        47, 27660, 662190280, 5887897504363093148L, -19643L, false, false, (char) 34357, (char) 32956,
        Double.longBitsToDouble(0x3fea209bd2f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud847\ude88\ud052\000\000\ud97b\udc5c\uda21\uddc9\000", "\u2035\u1a95", "\u3378\000\ud950\udce3\ud813\ude33\uc284\ud998\udc4b\udb3d\udf06\ud8cd\udc32\uda73\udcf7\ud96b\udf03\ud906\udee1\ud9b6\udf1b\udae4\udc66\uda5e\udc37\ud9ed\udc46\udad6\udd0b\ud908\udeef\ud8ad\udd58\udaea\udf88\udb78\uddac\udb87\udfec",
        58, 87145, 1309068399, -2483724502450692451L, -24800L, true, true, (char) 14479, (char) 38571,
        Double.longBitsToDouble(0x3fe80e59c9193da0L), Double.longBitsToDouble(0x3fe354ca80435814L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb4b\udc8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\uc318\u7e12\u43d7\u9c6c\u2109", "\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7\ud97a\udc03\ud906\udee1\ud9b6\udf1b\udae4\udc66\uda5e\udc37\ud9ed\udc46\udad6\udd0b\ud908\udeef\ud8ad\udd58\udaea\udf88\udb78\uddac\udb87\udfec\ub50d\ud9dd\udff2\ud868\udd08\ud9f4\udcb0\ud9b0\ude23\ud8b4\ude41\ud858\udf54\udac8\udf9b\uda82\udfbc\ud83c\ude81\udb12\udef1\ud8ef\udf04\udb38\udcb5\udbdb\udf3a\ud8bb\udcdd\ud82a\udc27\uda13\udfac\ud98d\udd27\ud87d\ude7d\ud8d9\udd64\ud926\udf30\udaea\uddce",
        8, 94111, 757741270, -360098169818512444L, 31849L, true, true, (char) 49200, (char) 39991,
        Double.longBitsToDouble(0x3feb4fb63638d916L), Double.longBitsToDouble(0x3fe7bd9c32ec9ad7L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud8bb\udea2\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18]] |a1=[Ljava.lang.String;:[[\ud8bb\udea2\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18]] |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 0, 7, "\ud8bb\udea2\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\uc318\u7e12", "\uda19\udd01\ud950\udce3\ud813\ude33\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        47, 98670, 662190280, 5887897504363093148L, -19619L, false, false, (char) 309, (char) 32956,
        Double.longBitsToDouble(0x3fea209bd2f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 3, "\ud82f\udee9\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\udb1f\udca3\ud80e\ude90\udbff\udc1c", "\uc318\u9305", "\uda19\udfd4\ud950\udce3\ud813\ude33\u5736\u0596\udb3d\udf06",
        6, 72193, -548243172, 3878074354750732323L, -59908L, true, true, (char) 55920, (char) 40771,
        Double.longBitsToDouble(0x3fe0dcd806e4f316L), Double.longBitsToDouble(0x3fa48385e7991f50L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud86a\udf0f\ud862\ude08\uda3c\udeaf\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\ud9bf\udd88", "\uc318\u7e12\u43d7\u9c6c\u2109\u35b3\u25a4\u50f2\u9b68\u3430", "\ud96b\udf03\ud906\udee1",
        45, 8966, -1250386788, -6383437411017280761L, -19643L, false, false, (char) 36660, (char) 42851,
        Double.longBitsToDouble(0x3fe4ef9e22f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 0, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\ud846\udd25", "\uc318\u7e12", "\udb5e\udc50\ud803\udfd7\ud813\ude33\u5736",
        34, 36221, -460120624, 305716669224073461L, -45172L, true, true, (char) 55920, (char) 28036,
        Double.longBitsToDouble(0x3fe0dcd806e4f316L), Double.longBitsToDouble(0x3fa4e385ec791f50L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud847\ude88\udaa5\ude4a\ud963\udf95\ud91c\ude7e\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\u4fad\u74e8", "\ud914\udd56\udbf9\udf39",
        41, 87052, 1496028488, -693414052263420464L, -59908L, true, true, (char) 55920, (char) 47643,
        Double.longBitsToDouble(0x3fe0dcd806e4f316L), Double.longBitsToDouble(0x3fa4e385dc791f50L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 0, 0, 11, "\000\u4e42\000\000\000\000\000", "", "\u00b7",
        -5, -1000, 0, 0L, -99928L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3d9be00000000000L), Double.longBitsToDouble(0x3fc914f960009de0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 11, "\ud847\ude88", "\u9032\u616d\u3349\u743e\u3cf7", "\uda1b\udcfe\uda00\ude92",
        52, 3464, 1966741017, -957972510625519283L, 88976L, true, false, (char) 15779, (char) 36632,
        Double.longBitsToDouble(0x3fe0753e5b000583L), Double.longBitsToDouble(0x3fc38a36c5fed5e0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 6, "\ud848\udd58\udaa5\ude4a\udb64\udf6f\ud915\udfe5\udb48\udf8b\udb15\udc02\ud977\udc4c", "\u5834\uc318", "\udaf7\uddcc\udb7b\udf89\ud82c\udd3c\ud90b\udfcd\uda38\udff9\u0596\udb3d\udf06\ud88c\udc12\uda79\udeb2\ud828\udfa0\ud906\udef9\ud9b6\udf1b\udafc\udf6f\uda5e\udc37\ud9ed\udc46\udad6\udd0b\u24af\ud8ad\udd58\udaea\udf88\udb78\uddac\udb87\udfec",
        31, 68545, 1309068336, 8064550247359894163L, -37392L, false, true, (char) 17267, (char) 51521,
        Double.longBitsToDouble(0x3fbfe9f53ef6ed10L), Double.longBitsToDouble(0x3fd59431bdbebec0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\ud648\u2470", "\uda19\udd01\ud950\udce3\udbc9\ude2e\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        47, 27660, 662190280, 5887897504363093148L, -19643L, false, false, (char) 36660, (char) 32956,
        Double.longBitsToDouble(0x3fea209bd2f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 0, "\ud847\ude88\udad6\udf19\ud8d1\udd78\ud915\udf2d\udb17\udfe0\u46e5\u8d70\ud90f\ude09\udb94\udee2\uda48\udcbf\ud9b7\udee9\ud805\udc47\ud885\udf49\udb9a\udc13\uda19\udd01\ud950\udce3\ud813\ude33\u5736\u0596\udbf5\udcc2\udbe6\udc86\uda50\udfd7\ud96d\udc84\ud906\udee0\ud9b6\udf1b\udad3\udd7f\uda5e\udc37\ud941\udf0f\ud913\udedd\ud8de\uddef\udae7\ude46\udaf8\udc38\uda78\ude22\udb66\ude87\udb88\udc14\ud840\udd2f\ud909\ude1f\ud840\udd35\udab5\udcd0\uda46\ude5e\ud8ef\udc6a\ud867\udd24\ud84c\udd49\ud9a5\ude8d\ud807\udf18\udacc\udfe0\ud844\udea2\ud852\udf7a\u0c0d\ud9ac\ude7b\udade\udee9\udbb1\udda6\ud812\udef1\ucdcb\uda09\udf14\ud8b7\udf7f\uda79\udcbf\ud94b\ude72\ud9c3\ude90\uda4e\udc0e\ud838\udf34\udaa1\udffa", "\u69a0", "\udada\udcfe\uda98\ude75\ud8ed\udc62\udac9\udcbf\uda02\udd2e\ud8b4\ude3d\uda3a\udd51\uda0a\uddf8\uda43\udc70\ud883\udf32\udb02\udd07\ud9df\udcff\udb2c\udf4c\udaec\udc88\uda38\ude2b\udae1\udcae\ud8f9\udc07\uda24\udf45\ud866\udf2e\ud831\udd2d",
        33, 72190, -521467785, 2051131358191410745L, -47619L, false, true, (char) 44024, (char) 26200,
        Double.longBitsToDouble(0x3fe050e8f873480cL), Double.longBitsToDouble(0x3fcee57aa733b3c0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud847\ude88", "\u9032\u77e4\u33d6\u9667\u3cf7", "\uda1b\udcfe",
        -1, 96957, 1032729464, 8447088346239256084L, -67336L, false, true, (char) 31044, (char) 15779,
        Double.longBitsToDouble(0x3f94df041914f960L), Double.longBitsToDouble(0x3fb289de24e28db0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud847\ude88\udaa5\ude17", "\u77e4\u33d6\u743e\u08f7\u3dab", "\uda00\ude92\ud893\udc4e",
        34, 68017, -1477523948, -4642179876870372732L, -67336L, false, true, (char) 31044, (char) 15779,
        Double.longBitsToDouble(0x3fe03d5020c8a7cbL), Double.longBitsToDouble(0x3fecb13bc49c51b6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 1, 4, 0, 4, "\ud847\uddd6\udaa5\ude4a\udb64\udff5\ud9cb\udf7f\ud927\udc60\udafb\udeab\ud841\udd7e\udbae\udc15\ud977\udde2\uda48\udcbf\uda1b\udcfe\uda00\ude92\ud893\udc4e\uda8f\udf18\uda19\udd01\ua791\uda77\udd43\ud927\udd4f\ud928\udc88\udb3d\udf06", "\u51dd\u8f89\u7f8f\u4a5a\u049b\u397f\ud367\u292f\u86cd\u1b63", "\ub50d\ud9dd\udff2\ud868\udd08\ud945\udcba\udbca\udf14\ud9ec\udc50\ud899\ude52",
        38, 2615, 2112075930, 9016824657142264461L, -1635L, false, true, (char) 57808, (char) 26822,
        Double.longBitsToDouble(0x3fb72ad3a3284ac0L), Double.longBitsToDouble(0x3fe20e80b900bbfbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud831\udf88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18\ud977\udde2\uda48\udcbf\uda1b\udcfe\uda00\ude92\udbfb\udd44\uda8f\udef7\uda19\udd01\ud950\udce3\ud813\ude33\u3702\u85f3\udacf\udf00\ud86a\ude9c\uda73\udcdc\ud96b\udf03\ud92d\ude5e\udb6b\udecc\ud921\udc22\uda5e\udc37\ud9ed\udc46\udad6\udd0b\ud908\udeef\ud8ad\udd58\udaea\udf97\udb78\uddac", "\ubf04\u38e9\u810c\ud734\u9485\u9705\u466e\u9ee3\u6a0a\u9268\uc2bd\u6941\u97f8\u7c23\u4d82\ub67e\u9aab\u521e\uba72\u9e92", "\udbaf\udfad\uda11\udc62\uda28\udebf\ud909\ude52\ud9ef\udd7e",
        46, 20976, -292240635, 7871900785153505721L, 2314L, false, true, (char) 36990, (char) 53174,
        Double.longBitsToDouble(0x3fcf120ff2f7dce8L), Double.longBitsToDouble(0x3fcf5f742b2e6160L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\ud8d3\udf11\ud9ed\ude6f\ud84e\ude44\udb6d\udf18]] |a1=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\ud8d3\udf11\ud9ed\ude6f\ud84e\ude44\udb6d\udf18]] |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 4, 4, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\ud8d3\udf11\ud9ed\ude6f\ud84e\ude44\udb6d\udf18", "\uc318\u7e12", "\uda19\udd01\ud950\udce3\ud813\ude33\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        55, 27795, 662190280, 5887897504363093148L, 50761L, false, false, (char) 36660, (char) 32956,
        Double.longBitsToDouble(0x3fea209bd2f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 7, "\ud847\ude88", "\u9032\u77e4\u33d6\u743e\u3cf7", "\uda1b\udcfe\uda00\ude92",
        -5, 3464, 1966741017, -6345917035716761089L, -42096L, true, false, (char) 14510, (char) 36632,
        Double.longBitsToDouble(0x3fc914f9600001e0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18\ud977\udde2\uda48\udcbf\uda1b\udcfe\uda00\ude92\ud893\udc4e\uda8f\udf18\uda19\udd01\ud950\udce3\ud813\ude33]] |a1=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18\ud977\udde2\uda48\udcbf\uda1b\udcfe\uda00\ude92\ud893\udc4e\uda8f\udf18\uda19\udd01\ud950\udce3\ud813\ude33]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 4, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18\ud977\udde2\uda48\udcbf\uda1b\udcfe\uda00\ude92\ud893\udc4e\uda8f\udf18\uda19\udd01\ud950\udce3\ud813\ude33", "\u3430\uad4e\u7a3d\u51dd\u8f89\u7f8f\u246e\ud446\u3880\ud32c\u292f\u86cd\u1b63\uac97\u1296\u8ab9\ubf04\u38e9\u3651\u4cc5\u93b2\ua3cd\u29c7\u5048", "\ud85a\udeb7\udb55\udd88\ud9e0\udd8b",
        -4, 6635, -1224625924, 4633187221598718256L, 80538L, false, true, (char) 52554, (char) 14108,
        Double.longBitsToDouble(0x3fc762f4dd814ba8L), Double.longBitsToDouble(0x3fbeb8b35eb73368L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\ud95b\udf32\ud891\ude80\ud9a5\udd0a\udb6d\udf18\ud977\udde2\uda0b\ude80\uda1b\udcb1\uda00\ude07\ud893\udc4e\udbd5\udc3c]] |a1=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\ud95b\udf32\ud891\ude80\ud9a5\udd0a\udb6d\udf18\ud977\udde2\uda0b\ude80\uda1b\udcb1\uda00\ude07\ud893\udc4e\udbd5\udc3c]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\ud95b\udf32\ud891\ude80\ud9a5\udd0a\udb6d\udf18\ud977\udde2\uda0b\ude80\uda1b\udcb1\uda00\ude07\ud893\udc4e\udbd5\udc3c", "\u25a4\u50a5\u9b68", "\uda73\udcf7\ud971\udc03\ud906\udee1\ud9b6\udf1b\udb66\udd9d\udbe4\udcb4\ud9e3\ude33\udad6\udd0b\ud908\udeef",
        22, 25220, -1846169606, 1403696771714740036L, 83407L, true, false, (char) 15065, (char) 27093,
        Double.longBitsToDouble(0x3fcec5918250138cL), Double.longBitsToDouble(0x3fe69386b407c420L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 6, "\ud847\ude88\ud9db\ude45\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\u8caa\u7e12\u43d7\u9c6c\u2109\u35b3\u17e5\u50f6\u9b68\u3430\uad4e\u7a3d\u51dd\u8f89\u7f8f\u246e\ud446\u3880\ud32c\u292f\u86cd\u1b63\u65bd", "\ud9dd\udff2\ud868\udd08\ud9c1\uddb8\ud953\udcbd\udbd4\udf60\uda94\udf20\uda4e\udfd7\u8674\ud9c2\udffd\ud80c\udeed\udbfd\udd0e\u7998\ud8dd\ude30\ud8bf\udd37\udb02\udc4b\ud884\udce0\ud9c5\udd88\ud801\udf92\ud9c3\udf16\uda20\udea6",
        7, 77761, 1655377197, -7756659867171827071L, -63817L, true, false, (char) 10296, (char) 52964,
        Double.longBitsToDouble(0x3fc01a483d391294L), Double.longBitsToDouble(0x3fd7f7a022326c38L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 7, "\ud847\ude88\ud99d\udf46\uc55d\ud8d9\udde7\udb48\udff7\ud9ed\ude6f\ud841\udd7e\udb6d\udf18\ud977\udde2\ud9a9\udd90\ud9f9\ude04\ud8c3\udfa6\ud893\udc4e\uda8f\udf18\uda19\udd01\ud950\udce3", "\u036b\u12bb\uad4e\u34a6\u51dd\u8f89\u7f8f\ub823\ub632\u0471\ua1aa\u4529\u0eb2\u1b63\u65bd\u75dd\u8ab9\ubf04\u38e9\ua676\u02b2\u655b", "\ud909\udf14\uda8b\udd2c\ud977\udcfc\ud9d4\udcc7\udb20\udfd0\ud818\udcc1\ud968\udf85\ud958\ude98\u1e01\udb41\udc5a\udade\udc8e\ud8f2\udef8\uda88\udc36\udb55\udcf3\udb78\uddc1\uda20\udcea\udaf8\ude77\udbd4\udfc6\uda33\udfe0\ua696\udb52\udc87\ud9f4\udf1d\ud8c3\udff8\udb92\udeed\ud9da\udfe6\ud9b8\udd64",
        18, 66763, 2106739299, -8369656038439809863L, 57499L, false, true, (char) 26842, (char) 59847,
        Double.longBitsToDouble(0x3f7266e269f4ff80L), Double.longBitsToDouble(0x3fde2bd0af5d33c0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\udbd5\udc84\udb48\udf8b\ud9ed\ude6f\ud8d5\udd36\ud82a\uddf0\ud99e\udc28\ud98c\udca1\udbd6\udde8\uda00\ude92\udb93\udc4c\uda5b\udc4e]] |a1=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\udbd5\udc84\udb48\udf8b\ud9ed\ude6f\ud8d5\udd36\ud82a\uddf0\ud99e\udc28\ud98c\udca1\udbd6\udde8\uda00\ude92\udb93\udc4c\uda5b\udc4e]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\udbd5\udc84\udb48\udf8b\ud9ed\ude6f\ud8d5\udd36\ud82a\uddf0\ud99e\udc28\ud98c\udca1\udbd6\udde8\uda00\ude92\udb93\udc4c\uda5b\udc4e", "\ub105\u50f2\u9b68\u33be", "\ud96b\ude1f\ud893\udd86\ud888\udee6\udb0b\udc17\ud81e\udff6\ud84e\udd76\udaca\udc27\u7ab5\ud981\udce2\udafd\udfcb\udbc4\udd51\udb87\udfec\udbb6\udd13\ud98a\udd89\ud837\udef8\ud9d6\udd62\ud930\udda9\udab0\udf45\uda56\udecb\ud8a7\udd06\udb38\udf57\uda7f\udda5\uda16\uddce\ud863\udf8f\ud992\udda3\uf672\uda20\udcb9\ud89f\ude28\udb50\udcf6\uda0a\udf53\udb2f\udfd5\ud898\udd7f\udb06\uddf5\ud89c\udfc7\udb2d\udcc7\ud89c\udf14\udbae\udd8e",
        35, 99195, 1412242556, -3511572777707072095L, 41340L, false, true, (char) 56240, (char) 31641,
        Double.longBitsToDouble(0x3fee9c451fa52800L), Double.longBitsToDouble(0x3febde5b6bf3c54aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18]] |a1=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 2, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\uc318\u7e12", "\u7065\ud957\udc0c\ud813\ude33\u5736\u0596\udb3d\udf06\ud8cd\udc32\udbf5\udcf8",
        47, 27660, 662190280, 5887897504363093148L, -19643L, false, false, (char) 36660, (char) 27329,
        Double.longBitsToDouble(0x3fea209f12f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 10, "\udb0b\udd8b\udbef\ude4f\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud841\udd7e\ud8ee\udff9\uda6b\udcff", "\u0ff9\u044f\u9c6c", "\ufc42\udad8\uddf7\udbff\udcb8\ud8d7\ude25\uda62\udc36\uda82\ude10\ud8ef\udf9b\udb7e\udfa7\udae9\udf0e\ud96f\ude97",
        6, 61559, -1689458085, 3886874323811056013L, -74565L, false, true, (char) 36026, (char) 28139,
        Double.longBitsToDouble(0x3fe37faadc78dde9L), Double.longBitsToDouble(0x3fe6507f895cd26dL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud86a\ude7f\udb6d\udf18]] |a1=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud86a\ude7f\udb6d\udf18]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud86a\ude7f\udb6d\udf18]] |a1=[Ljava.lang.String;:[[\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud86a\ude7f\udb6d\udf18]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\udb48\udf8b\ud9ed\ude6f\ud86a\ude7f\udb6d\udf18", "\uc318\u7d95", "\u6960\ud999\udf99\ud81d\udf36\u5736\u0596\udb3d\udf06\ud9d9\udf34\uda73\udcf7",
        56, 27660, 662190280, 1884348070538896663L, -86933L, true, false, (char) 28955, (char) 31226,
        Double.longBitsToDouble(0x3fa4e385ec791f50L), Double.longBitsToDouble(0x3fea209bd2f9da6bL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 7, "\ud82a\udfd4\udac6\udc5a\ud9c5\udff2\uda05\udfdd\udb48\udf8b\u00bc\000\000", "\000\u2000", "\uda19\udd01\ud950\udce3\ud813\udd34\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        15, -1000, 0, 0L, -100000L, false, false, (char) 0, (char) 31204,
        Double.longBitsToDouble(0x3fa4e385e0000000L), Double.longBitsToDouble(0x3fea209bd0f9da6bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\udbb8\udfd6\ud906\udfc7\udb65\udc02\uda8a\udc55\udb49\udc1f\ud9ed\ude6f\ud841\udd7e\udb6d\udf18]] |a1=[Ljava.lang.String;:[[\udbb8\udfd6\ud906\udfc7\udb65\udc02\uda8a\udc55\udb49\udc1f\ud9ed\ude6f\ud841\udd7e\udb6d\udf18]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 7, "\udbb8\udfd6\ud906\udfc7\udb65\udc02\uda8a\udc55\udb49\udc1f\ud9ed\ude6f\ud841\udd7e\udb6d\udf18", "\u5b79\u7e2f", "\uda19\udd01\ud950\udce3\ub233\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        47, 27660, 662190280, 5887928290688670876L, -19643L, false, false, (char) 34357, (char) 32956,
        Double.longBitsToDouble(0x3fd1e137abf3b4d6L), Double.longBitsToDouble(0x3fbbd5240dca7030L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 8, "", "\ud47d\u34e00", "\udb6d\udf18",
        47, 33450, 686758549, 2271257559210014221L, -100000L, false, false, (char) 48621, (char) 33303,
        Double.longBitsToDouble(0x3fd484facf300a56L), Double.longBitsToDouble(0x3fdd0f660963c926L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 7, "\ud936\udedd\ud818\udd19\ud932\udeae\uda0a\udc77\ud8d7\udcac\ud918\ude3b\ud831\udf7e\ud8ad\udfd9", "\uc318\u7e12\u302a\u7ea4\u3154\u53a5\u7a3d\uac53\uc389\u9a9b\uad4e\u7a3d\u51dd\u8f89\u7eda\u9201\u7ed8\u3880\u3230\u5bf9\u944d\u9633\u65bd\u75dd\u42e4\ubf04\u38e9\u6571\u7c17\ub8b9\u676a\u1848\ua484\ua93a\u2957\u4003\ub494", "\ud9a7\udd5e\udb50\udfb9\u0c8b\u1193\udb85\udcd2\ufd32\udb22\udc86\ud9b5\uddba\ud90a\udd6c\udade\ude94\udba0\udd60\uda02\udd8f\ud848\udf22\udbde\udffc\ud80d\udd02\udbcc\udcf6",
        26, 33463, -1397947971, 6005539387595312703L, 69429L, true, false, (char) 60381, (char) 8648,
        Double.longBitsToDouble(0x3fec5b40d94c40aeL), Double.longBitsToDouble(0x3fef3d337ae6efc6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u00d1", "\ud9ed\ude6f\ud841\udd7e",
        57, 41772, -127225550, 2949605508732231863L, 44248L, true, false, (char) 15182, (char) 48621,
        Double.longBitsToDouble(0x3fe425fc9d484facL), Double.longBitsToDouble(0x3fecc0295dd0f660L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 7, "\000", "", "",
        55, -988, 234881024, 45866110245581106L, 93024L, true, true, (char) 5543, (char) 48108,
        Double.longBitsToDouble(0x3fe0a3a9d1ffa7eeL), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud847\ude88\udaa5\ude4a\udb64\udff5\ud915\udfe5\"\ud9ed\uddb3\ud841\udd7e\udb6d\udf18", "\uc318\u7e12", "\uda19\udd01\ud950\udce3\ud813\ude33\u5736\u0596\udb3d\udf06\ud8cd\udc32\uda73\udcf7",
        47, 27660, 662190280, 5887897505621384348L, -19643L, false, false, (char) 36660, (char) 32956,
        Double.longBitsToDouble(0x3fea209802f9da6bL), Double.longBitsToDouble(0x3fbbd51a4dca7030L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 5, "\uda9b\udc1f\udaa5\ude4a\uda66\udc0d\ud8db\udc9e", "\u743e\u3cf7\u0a68\u2574\uc318\u0e13\ube4c\ube8b\u6db2\u3607\u02d1\u61f4\u97d4\u95b4\uad64\u7a3d\u51dd\u8f89\u6248\u0434\ud446\u1164\ubf00\u1795\u6575\u1b63\ud52b\u75bd\u8ab9\ubf04\u38e9\u7b91\ub616\u37a7\u2937\u7dc1\u9fd6\u17f4\u40a1\ube9f\u5c15\ua56b\u37f2\ua916\u5c22\u53a4\u4ff6\ub1ee\u0175\u870e\u4765\u075e\u217e\u92a1\u7ba3\u2fde\u8232\u84e8\u2b59\u2f47\u25f1\u2bc7\u07fb\ucbba\u2bb1\u256d\u4e10\uc5e4\ub547\u524c\uc138\u9e59\u0459\ua404\ud77e\uc2f1", "\udaca\udc53\ud99a\udf08\udaaa\ude41\ud808\udc9f\udbaf\ude8f\udb8c\udcff\ud946\udd53\udba1\udf42\ud9df\udd24\uda1a\ude08\udafc\udf83\uda7c\udffe\ud89a\udc19\ud8d5\ude36\ud8b5\udfdc\udb12\udc39\ud829\ude7b\ud9dd\udc06\udaf0\udfac\udb64\uddb5\u9be6\udb37\udf21\uda70\udfcc\udb57\udfc4\ud8fb\udc95\ud926\udf45\ud949\udfda\ud85a\udd59\ud934\udd1e\ud8ff\udca0\ud90f\ude42\ud8b5\udeff\uda4c\udf41\udb19\udca0\udb11\ude01\udb15\udf35\ud934\uddd8\udba0\udf8c\ud884\udde8\udb22\udd85\ud8bc\udd93\ud891\udfe7\ud9bd\udecc\udabc\udc6d\ud95e\udc9c\udbde\udfa4\udb46\udeea\ud835\udc56\ud93d\udf08\uda2d\udd23\udb9a\udc0f\ud895\udeef\ud93c\udd0d\ud938\ude42\uda73\uded1\ud941\uddd5\udb3b\udf58\udbcf\udc0e\ud8f1\udde1\ud900\udf09\ud9dc\udcb8\udb95\udc9b\udb69\udfd4\ud91c\udc57\ud921\udf68\udb62\udc9c\udb73\uddc2\udb95\udd8a\udaf8\udc2e",
        -2, 61281, 957496167, 6835336977968919565L, 87191L, false, true, (char) 50649, (char) 37732,
        Double.longBitsToDouble(0x3fcd5f25257fe92cL), Double.longBitsToDouble(0x3fddd62f6e1c0598L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 7, "\ud847\ude88", "\ud494\u4996\u331c\ud2dc\u3cee\u3dab", "\ud879\udff8",
        -3, 89136, -1677634092, -5890630986009398529L, 92249L, false, true, (char) 43040, (char) 17121,
        Double.longBitsToDouble(0x3fde1d32a92c5608L), Double.longBitsToDouble(0x3fbff7799a523d30L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
