package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class Parser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u0711\u6f29\u5966\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        0, 82216, 555965631, 1605619988061683552L, 38193L, true, true, (char) 46037, (char) 48488,
        Double.longBitsToDouble(0x3fed534076573463L), Double.longBitsToDouble(0x3feac9ab2d29875bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u0711\ud6f2\u5966\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\udaf8\udc39",
        42, 82216, 555965631, 2642834554023228796L, 38193L, true, true, (char) 46037, (char) 48488,
        Double.longBitsToDouble(0x3fed534076573463L), Double.longBitsToDouble(0x3feac9ab2d29875bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udac0\udfbf\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud935\udc51\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\u956e\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\u6319\u5124\u0711\u6f29\u5966\u23cb\u1e97\ub365\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        47, 63204, 555965631, 1605619988061683552L, -83167L, false, false, (char) 3000, (char) 4794,
        Double.longBitsToDouble(0x3feac9ab2d29875bL), Double.longBitsToDouble(0x3fc4a9b0cb43c6c4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud8b0\udcea\udb70\udca5\ud93b\ude5b", "\u0a70", "\ud9d1\udd25\udb72\udc78\ud915\udc3e\ud81e\ude51\ud953\udf06\udb52\udc79\udac4\uddeb\uda06\ude24\ud9a8\udd70\ud923\udc7a\ud8b7\udd21\ud96b\udfea\ud80a\udd2a",
        7, 3638, 695249131, -7315495138911086620L, 25234L, true, false, (char) 8177, (char) 46069,
        Double.longBitsToDouble(0x3fe0791beaed1519L), Double.longBitsToDouble(0x3fde22552d2278aeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d8\udf25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598", "\ud8e6\udfe3\ud9e2\udd3e\uad3a\ud8dd\udc84\ud9fe\ude5b\ud1df\udbfa\udff1\ud831\udc3b\u7018\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85\ud9e4\udfcf\ud834\uddff\udbbf\udeb2\ud876\udc2f\uda12\udfa8\udb34\udcfb\ud980\udf91",
        24, 7263, 948569000, 4649589865919647700L, 13367L, false, false, (char) 55106, (char) 16859,
        Double.longBitsToDouble(0x3fe78631d7bc387bL), Double.longBitsToDouble(0x3fe732b4b49f8d45L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 5, "\ud842\udc78\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\udb4f\udc73\udb39\udf7a\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u0711", "\uada2\ud8dd\udc84\ud9fe\ude5b\ud1df",
        28, 90670, 432621203, 8332917798630081988L, 95069L, true, false, (char) 31170, (char) 24813,
        Double.longBitsToDouble(0x3fe6f9091f601648L), Double.longBitsToDouble(0x3fe3a24574d14a66L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 8, "\ud836\udea6\ud882\udd78\ud98a\ude91\ud9f9\udd31\ud9dc\udd23\ud892\udcd9\udb42\udd98\ud91a\udc1a\udbdd\udfe6\udacd\udd87\ud9c6\udc2c\udab3\ude8f\uda1a\udef7\ud873\udc6c\ud961\udcbf\udbcb\uddc5\ud806\uddab\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\ua290\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u82de\uc840\uc598\u514b\u0711\u6f29\u5966\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        0, 82216, 555965631, 1605619988061683552L, 38193L, true, true, (char) 60427, (char) 29164,
        Double.longBitsToDouble(0x3fed534076573463L), Double.longBitsToDouble(0x3fe2c9ab2d29875bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\udad8\ude8f\ud892\udcd9\ud8f4\udf70\udb52\udca8\ud826\udfde\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8", "\udabb\udd9f\udaf8\udfca\ud9ae\udcd9\ud8b7\udd21\ud96b\udfea\ud80a\udd2a\ud9f0\ude69\udb8a\udcaa\ud88e\udf5c\ud865\udc9b\ud86d\udd51\uda41\ude69\ud9a2\udd3a\ud966\udcc1\udbbd\ude3b\ud99a\udd2b\ud925\udf4d\uda31\udc88",
        51, 92393, 402555687, 2500509686167821952L, -3853L, true, true, (char) 63509, (char) 31170,
        Double.longBitsToDouble(0x3fc7e085db7c848cL), Double.longBitsToDouble(0x3feb00b241418a81L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud942\uddee\udba1\udcd3\ud891\ude61\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud563\ua8d8\ucbbb\u974f\uc53f\u0442\u2c5e", "\ud80a\udd2a\ud9f0\ude69\udb8a\udcaa\ud88e\udf5c\ud951\uddf2\ud880\ude50\udb0c\udf77\ud986\udf77\ud821\udd6c\ud94b\udf16\uda2b\udf2b\ud925\udf4d\ud821\udd20\ud93b\udd70\uada2",
        11, 30280, -1317740928, -7288616506042819842L, -69129L, false, true, (char) 65009, (char) 3653,
        Double.longBitsToDouble(0x3fcffce2c702a008L), Double.longBitsToDouble(0x3fc7e085db7c848cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6", "\ub053\u1726\u062d\ud6c2\u9e76\u36ab\ucdc7\ucec1\u8524\u3dd0\u3f7e\u786e\u241e", "\ud994\udd16\udb39\udf6e\ud9d1\udd25\udb72\udc78\ud915\udc3e\uda24\udfd5\ud953\udec4\udb52\udc79\ud93f\udea9\udaa5\ude12",
        30, 52932, 1865180820, -3909895110288411804L, 79422L, false, false, (char) 19806, (char) 12894,
        Double.longBitsToDouble(0x3fe7a75e99320867L), Double.longBitsToDouble(0x3fcb64d125502674L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udacb\udc86\udbb0\ude18\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud938\udf1d\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud92c\udd94]] |a1=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udacb\udc86\udbb0\ude18\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud938\udf1d\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud92c\udd94]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 0, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udacb\udc86\udbb0\ude18\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud938\udf1d\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud92c\udd94", "\ud5c9\u45e9\ubdce\u8186\uc53f\u0442\u2c5e\u6257\u82cd\ud184\u36f7\u54e4\u6208\u8b9a\u889c\u8cee\u1edf\ub91a\uc598\u5124\u0711\u6f29\u0827\u8699\u1f30\uc170\uc168\u52ea", "\uda81\udf67\uda55\udf46\udb63\udf34\uda94\udf4b",
        51, 82216, 555965631, 1605619988061683552L, 38193L, true, true, (char) 46037, (char) 41499,
        Double.longBitsToDouble(0x3fed534070791763L), Double.longBitsToDouble(0x3fe65855dd29f52aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud84e\udd93\u7370", "\u98ec\u3b1f\ud6c2\u9e76\u1bc3\u0e33\ucec1", "\u816e\udb5d\udfa5\ud971\ude51\ud8dc\uddea",
        50, -792, 151219625, 8169747936906462696L, -56378L, true, false, (char) 7821, (char) 33757,
        Double.longBitsToDouble(0x3feea758d6941154L), Double.longBitsToDouble(0x3fe8eb796364c9bdL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 1, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud8f3\ude1f\ud858\ude35", "\uac2d\ud0bb\u28a8\u5ad0\u3ff7", "\ud985\udf8b\ud862\udc86\ud9b6\udea9\ud972\ude23\ud992\udeac\udb41\udee0\ud914\udfcc",
        42, 24213, -552101732, 4435771076216611070L, 13595L, false, true, (char) 20879, (char) 13553,
        Double.longBitsToDouble(0x3fe7a203e128489fL), Double.longBitsToDouble(0x3f86db76eeb0de80L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud802\udf4c\ud89a\udd17\ud98a\ude91\uda43\udff6", "\ud6c2\u9e76", "\ud85e\udc86",
        43, 54918, -252184120, 2804108711562341102L, -9920L, true, true, (char) 17595, (char) 58031,
        Double.longBitsToDouble(0x3fde8716087c4194L), Double.longBitsToDouble(0x3fe54c89ec6b0c8cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 5, "\ud836\udea6\udb48\udcf0\ud98a\udf1d\uda43\udff6\udb65\udd0e\ud8a9\udd02\ud8f4\udf70\udb9f\uddd0\uaa1e\udbac\udfca\udb63\udf8a\ud9fc\udc11\ud86e\udf93\uda01\udfdf\ud9a1\udf63\ud9fc\udfda\ud835\udda1\ud815\uddbf\ud994\udd16\udb06\udd74\ud9aa\udc7b", "\u35de\u323b\u3910\ud75c\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u634a\u8b9a\u889c\u8cee\u1edf\uc840\ud5e0\u17dd\u869d\u77a6\u4b3e\u23cb\u0197\uc1c7\uc168\ub205\u252a\ua3ea\ub214\ud33e\u5e2d\uc264\u18b5\u1eb5\u7405\ua947\u1d85\u36ad\ud769\u4f39\uceca\u0e07\u79c1\u9b62", "\u13c4\ud9e7\udfb1",
        7, 72892, -827661936, -6754065955942143675L, -2073L, true, true, (char) 35599, (char) 63983,
        Double.longBitsToDouble(0x3fd11fffb90621e6L), Double.longBitsToDouble(0x3fe1538177b1ab17L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud82d\udc88\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\udb16\udc79\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9fe\ude2b", "\u8fa7\u184a\u8ba5\u84b0\u8047\u5436\ud4be\u663b\u3ddd\u61c6\uadc2\uc3b5\ud6b1\u8b9a\u889c\u8cee\u1ed4\uc840\uc598\u5124\u0711\u6f29\u5966\u3d5c\u81fb\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85\ud9e4\udfcf\ud834\uddff\udbbf\udeb2\ud876\udc2f\uda12\udfa8\udb34\udcfb\ud980\udf91\udb8c\udefb\ud840\udea6\udb62\udcd4\ud957\udec0\uda44\udd7c\udbaa\udc3c\ud962\uddf1",
        51, 30726, -366182353, -8127444820573929038L, 79334L, false, false, (char) 15888, (char) 17821,
        Double.longBitsToDouble(0x3fe3e6726467b4d5L), Double.longBitsToDouble(0x3fe17128a6dbf43fL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udadb\uddcf\udbaf\udce9\ud87f\udfd4\ud85e\udc86\udab3\udebc\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udcc1\ud839\udd79\ud9b0\udd25]] |a1=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udadb\uddcf\udbaf\udce9\ud87f\udfd4\ud85e\udc86\udab3\udebc\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udcc1\ud839\udd79\ud9b0\udd25]] |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 4, 1, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udadb\uddcf\udbaf\udce9\ud87f\udfd4\ud85e\udc86\udab3\udebc\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udcc1\ud839\udd79\ud9b0\udd25", "\u6211\u2726\ucbbb\u9740\uc53f\ube70\ud7d1\u2fca\u82bf\u01b7\u29a6\u394c\uaff5\u5d5c\ua95c\ub833\u43de\uc840\u722d\u5124\u0711\u6f29\u5966\u23cb\u1e97\uc170\uc168\ub205", "\ud804\ude0e\uda55\udf54\udbff\udd42\ud890\udc85\ud9e4\udfcf\ud877\udd00\uda60\udcf8\ud876\udc2f\uda12\udfa8\udb34\udcfb\udab6\uddf9\u3337",
        58, 92331, 2080023466, -8330007472532385959L, -73055L, false, true, (char) 46599, (char) 16470,
        Double.longBitsToDouble(0x3fdba65ed826c2ccL), Double.longBitsToDouble(0x3fe95e145b71395fL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |a1=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 11, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u0711\u6f29\u5966\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        0, 82216, 555965631, 1605619988061683552L, 38193L, true, true, (char) 46037, (char) 48488,
        Double.longBitsToDouble(0x3fed534070eeac6bL), Double.longBitsToDouble(0x3fb4ba3b6f9e2eb0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udab1\udd98\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\ud6d6\ud041\u2c5e\u70a0\u5ed8\uae9d\u29a6\u394c\u1fe1\ubc4e\u889c\u783e\u1f8b\uc840\uc598\u5124\u0711\u6f29\u5974\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        0, 82216, 555965631, 1605619988061683552L, 39059L, true, false, (char) 4666, (char) 51120,
        Double.longBitsToDouble(0x3fba1c8da480e860L), Double.longBitsToDouble(0x3fe7023156b2e9a0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udbc9\udcdd\ud882\udd78\ud98a\ude91\ud8fe\udf26\uda47\udd67\udbdf\udc84\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\ud897\udf44\ud914\udc14\ud8ba\udce5\ud97c\udd6b\ud954\udc33\udb29\udd9a\ud815\uddbf\ud994\udd16\udb4e\udd6e\ud9d1\udd25", "\u2538\ubb97\u59b0\u33a7\u26d4\u95a2\u2c5e\u6257\u6b58\u4de5\u29a6\u394c\u6208\u8b9a\u889c\u6aef\u1edf\uc840\uc598\u5124\u0711\u6f29\u5966\u23cb\u1e97\uc170\u5861\ub205", "\uda81\udf67\ud8ea\ude42\ud8fd\udf69\ud8c7\ude00",
        0, 82216, 555965631, -6608945732262101152L, -30433L, true, true, (char) 46037, (char) 48488,
        Double.longBitsToDouble(0x3fbb1a03b2bd2a10L), Double.longBitsToDouble(0x3fe5f9ab2db68855L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\uda51\udd32\ud861\udf35", "\u6532\u3b1f\ud6c2\u9e76", "\ud85e\udc86",
        43, 54918, -252184120, -4473708286268380434L, 58267L, true, false, (char) 24523, (char) 12551,
        Double.longBitsToDouble(0x3feb85b4946b74bbL), Double.longBitsToDouble(0x3fe33161e64b0960L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\000", "\ub008\u6532\u3b1f\ud6c2\000\000\000", "",
        15, -800, -1056964608, 3476896484753270437L, -3197L, true, true, (char) 58031, (char) 46920,
        Double.longBitsToDouble(0x3fef4d1e53704987L), Double.longBitsToDouble(0x3fbadd00133161e0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud8bf\udeaa\ud8ae\udd36\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |a1=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud8bf\udeaa\ud8ae\udd36\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |this=org.apache.commons.cli.BasicParser:@?\0121=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud8bf\udeaa\ud8ae\udd36\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |a1=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud8bf\udeaa\ud8ae\udd36\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud8bf\udeaa\ud8ae\udd36\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8eb\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u4476\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u6e78\uc098\uaf37\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\ud8f9\udf16\udbde\udf40",
        0, 82216, 555965631, 1605619988061683552L, 38193L, true, true, (char) 46037, (char) 15074,
        Double.longBitsToDouble(0x3fc297b5b023eafcL), Double.longBitsToDouble(0x3feacfb3fd29875bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 5, "\udaa7\udcff\ud882\udd0f\ud98a\ude91\ud9d9\ude20\ud991\udeca\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\ud8ad\udc94\uda6f\uddaf\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\ud89e\udc60\ud8f4\udedb\uda49\ude0e\ud914\udfb0\ud81e\ude51\ud953\udf06\udb16\udd3a\ud887\uddc7", "\u3e0a\u6257\u26a8\uce75\u6f96\u394c\u6208\ubc08\u889c\u7960\u6978\ub943\uc59f\u8d30\u9fe8", "\uada2\ud8dd\udc84\uda40\udd55\ud1df\udbfa\udff1\ud880\udeb8",
        48, 48615, -1847573052, 1461536897793194493L, 43637L, true, false, (char) 46279, (char) 43343,
        Double.longBitsToDouble(0x3feccbebc63ff596L), Double.longBitsToDouble(0x3fe59a55abaa680eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |a1=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25]] |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\uafe6\u73ef\ucc40\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u53f3\u889c\u8cee\u1edf\u69bb\uc3f4\u5124\u0711\ua87d\u5966\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\udb4e\ude26",
        0, 82216, 555965631, 1605619988061683552L, 38193L, true, true, (char) 45976, (char) 48488,
        Double.longBitsToDouble(0x3fed53407350a263L), Double.longBitsToDouble(0x3fe2c9ab2d29875bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=void |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "\032", "\ub053\u6532\u3b1f\ud6c2\u9e76\u1bc3\u0e33\ucec1\u2713\u5ad0\u3ff7\u7b19\ub0e3", "\ud9ff\uddeb\udb14\udda9\ud9d1\udd25\udbda\udc6c\ud915\udc3e\ud81e\ude51\ud953\udf06\udb52\udc79\udac4\uddeb\udabb\udd9f",
        30, 73468, 2909844, -3909895110288411804L, -51650L, true, false, (char) 19806, (char) 12894,
        Double.longBitsToDouble(0x3fe7c948d8320867L), Double.longBitsToDouble(0x3e49502674000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 4, "\ud836\udea6\ud882\udd78\ud98a\ude91\udbcf\udd7c\udbff\udcc3\ud892\udcd9\ud930\udffd\udb40\udd4b\ud968\udf6c\ud891\udc8e", "\u5ad0\u3ff7\u786e\u241e\u3157\u215e\u2854", "\udb72\udc78",
        5, 46744, 742157419, -2350650967461001653L, -17318L, false, true, (char) 30696, (char) 51837,
        Double.longBitsToDouble(0x3feb2319fb56da38L), Double.longBitsToDouble(0x3fcbcf0263ad01f0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud85f\udf5a\udaf2\udcd2\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udac0\udfbf\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud935\udc51\udbcb\uddc5\ud835\udda1\udb83\ude7c\ud994\udc60\uda29\udde6\ud9c6\udfc3", "\ud63e\ua8d8\ucbbb\u9740\uc53f\u12e6\u2c1c\u6257\u82cd\u956e\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\ub604\u26ee\u596c\u6f29\u13a5\u23cb\u1e97\ub365\uc168\ub205", "\uda81\udfa6\uda55\udf46\udbff\udd42\ud890\udc85\ud89a\ude69\ud945\udeb7\ud9b8\udf4f\ud87a\udf73\uda12\udfa8\uda44\udd83\udb12\udf9a\udb8c\udefb\ud8d2\udc70\udb62\udcb7\ud957\udec0\uda44\udd7c\udbaa\udc3c\uda36\uddba\ud85a\udfcd\ud913\uddb8\udbae\udcd8\ud817\udd7b\u94f0\ud978\udcd7\ud982\udea9\ud9af\ude1a\ud8e1\udea1\uda67\udf63\ud998\ude20\udb70\udd55\uda74\udd20\ud9a8\udd5d\udb6f\udf9c\udbda\udc44\ud9a8\udd14\ud88b\udc98\ud8bd\ude77\ud92a\udf24\ud917\udcb1\ud8ba\ude04\uda32\ude73\ud820\udf7e\ud884\udfe0\u282b\udbfb\udf17\udb81\udca0\ud9a7\uddc1\ud907\udd56",
        29, 6415, -1708137099, -3547213927505610370L, -15169L, false, false, (char) 23824, (char) 22259,
        Double.longBitsToDouble(0x3fa939ae0129d2a0L), Double.longBitsToDouble(0x3feeb240cc1e52bfL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 4, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udac0\udfbf\ud87f\udfd4\ud866\ude86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud935\udc51\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9a98\ua493\u0442\u2c5e\u6257\u82cd\u956e\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\u6319\u5124\u0711\u6f29\u5966\u23cb\u1e97\uab19\u541a\ub1ab", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        47, 63204, 555965631, 1605619988061683552L, -83167L, false, false, (char) 3000, (char) 4794,
        Double.longBitsToDouble(0x3feac9ab2d29875bL), Double.longBitsToDouble(0x3fc4a9b0cb43c6c4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 5, "\ud836\udea6\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udac0\udfbf\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud935\udc51\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\u956e\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\u6319\u5124\u0711\u6f29\u5966\u23cb\u1e97\ub365\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        47, 63204, 1193499839, -6357578656680525044L, -83167L, false, false, (char) 3000, (char) 25786,
        Double.longBitsToDouble(0x3fd25a322a530eb6L), Double.longBitsToDouble(0x3fc4a9b0cb43c6c4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 5, "\000\000", "", "\ud8f4\udf70",
        -5, 36888, 0, 121521804673024L, -98208L, false, false, (char) 49710, (char) 5861,
        Double.longBitsToDouble(0x3f3da14000000000L), Double.longBitsToDouble(0x3fd0000000003872L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 5, "\ud836\udea6", "\000", "\000",
        -5, -1000, -24270870, 2446018123146634323L, -100000L, false, false, (char) 11481, (char) 5861,
        Double.longBitsToDouble(0x3f3da14000000000L), Double.longBitsToDouble(0x3fdc5ae000000072L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 5, "\ud842\udc78\ud882\udd78\ud98a\ude91\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\udb4f\udc73\udb39\udf7a\ud9d1\udd25", "\ud5c9\ua8d8\ucbbb\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u0711", "\uada2\ud8dd\udc84\ud9fe\ude5b\ud1df",
        28, 90670, 432621203, 8332917798630081988L, 95069L, true, false, (char) 31170, (char) 24813,
        Double.longBitsToDouble(0x3fe6f9091f601648L), Double.longBitsToDouble(0x3fe3a24574d14a66L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 2, 5, "\ud942\uddee\udba1\udcd3\ud891\ude61\uda43\udff6\ud970\udc52\ud892\udcd9\ud8e9\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud563\ua8d8\ucbbb\u974f\uc53f\u0442\u2c5e", "\ud80a\udd2a\ud9f0\ude69\udb54\udd6f\ud88e\udf5c\ud951\uddf2\ud880\ude50\udb0c\udf77\ud986\udf77\ud821\udd6c\ud94b\udf16\uda2b\udf2b\ud925\udf4d\ud821\udd20\ud93b\udd70\uada2",
        11, 57936, -1317740928, -7288616506042819842L, -69129L, true, true, (char) 64806, (char) 3653,
        Double.longBitsToDouble(0x3fcffce2c702a008L), Double.longBitsToDouble(0x3fc7e085db7c848cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\000", "", "",
        -5, -1000, 1635647488, -573508348858750998L, 73139L, false, false, (char) 60928, (char) 8956,
        Double.longBitsToDouble(0x3fe7760f56000040L), Double.longBitsToDouble(0x3fe2f3b42dddb197L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud836\udea6\udb0a\udeff\ud98a\udf68\uda43\udff6\ud970\udc52\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\ud9d1\udd25", "\ud5c9\ua8d8\u706a\u9740\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u23e1\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u0711\u6f29\u5966\u23cb\u1e97\uc170\uc168\ub205", "\uda81\udf67\uda55\udf46\udbff\udd42\ud890\udc85",
        0, 82216, 555965631, 1605619988682440544L, 24149L, true, true, (char) 46037, (char) 48488,
        Double.longBitsToDouble(0x3fed534076573463L), Double.longBitsToDouble(0x3feac9ab2d29875bL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\ud802\udd2f\uda98\udf90\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\udaa0\ude8d]] |a1=[Ljava.lang.String;:[[\ud836\udea6\ud882\udd78\ud98a\ude91\ud802\udd2f\uda98\udf90\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\udaa0\ude8d]] |this=org.apache.commons.cli.BasicParser:@?\0121=null |this=org.apache.commons.cli.BasicParser:@?\012",
        Z.run(T, 2, 2, 4, 11, "\ud836\udea6\ud882\udd78\ud98a\ude91\ud802\udd2f\uda98\udf90\ud892\udcd9\ud8f4\udf70\udb52\udca8\udbaf\udcb9\ud87f\udfd4\ud85e\udc86\udab3\ude18\ud914\udc14\ud8ba\udce5\ud93b\ude5b\udbcb\uddc5\ud835\udda1\ud815\uddbf\ud994\udd16\udb39\udf6e\udaa0\ude8d", "\ud5c9\ua8d8\uc8c5\u97f2\uc53f\u0442\u2c5e\u6257\u82cd\uae9d\u29a6\u394c\u6208\u8b9a\u889c\u8cee\u1edf\uc840\uc598\u5124\u0711\u6f29\u5966\u23cb\u1e97\uc170\uc168\ub205\u1b03\ubd22\u59a6\ud33e\u141b\uc476\u18b5\u1eb5\u7405\ua947\u1d85\u36ad\uc8b1\u4f41\uceca\u0e07\uc09a\u0596\u2b63\uab46\uaf67\u27e4\u541c\u6320\u1721\ud1c6\ua27e\ub8b8\u3dbe\u6dc3\u4365\u572a\u44cf\u1c57\uab44\u1003\u9bb6\u6c8e\u69da\ube89\u4ec6\u23c4\u9414\u771e\u607d\ud563\ud0e9\u97e6\u890f\u7942\u5590\u9edf\u3082\u3583\u523c\u8579\u0556\u1d1a\uaf28\u8f94\u31b9\u2182", "\u8ca2\ud828\udf0c\ud929\uddeb\ud88f\udf28\ud9b0\udf6d\ud9a2\udf56\ud957\ude7a\udb0e\uddc3\uf188\uec5f\ud999\udd77\ud95a\udfa8\uda35\ude16\ud8fa\ude8c\u9203\udacc\ude9c\ud90c\udcbf\ud92f\udc06\ud8ae\udcb3\ud864\udf0e\udbaf\udcb0\ud833\uddb1\ud8cc\udd46\udb59\udd89\ud9bf\udcd8\udb32\udd38\u56a7\ud82a\uddbc\u35c5\udb42\udd37\udbb5\udf0f\u37ee\udbc6\ude99\ud983\udf02\udbd6\udc6b\ud860\udffe\ud841\udca7\ud805\udc99\udb6d\udfc1\ud98d\udd8f\ud92d\udd50\ud83e\udd80\ud8e7\uddae\uda9c\udeb3\udbbf\udf83\udb68\udf5f\ud984\udf46\udbd1\uddf9\udaf9\udd2d\ud977\udf43\u10bc\ud827\ude80\ud9a8\udc07\udae3\udc50",
        23, 47675, -1231653085, 1403744640418539931L, -15490L, false, false, (char) 55513, (char) 52087,
        Double.longBitsToDouble(0x3fbd5465a9e86860L), Double.longBitsToDouble(0x3fdf1c98d1d4f0b6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|checkRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|flatten|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|getRequiredOptions||new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|parse|org.apache.commons.cli.Options,[Ljava.lang.String;,java.util.Properties,boolean|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processArgs|org.apache.commons.cli.Option,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processOption|java.lang.String,java.util.ListIterator|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|setOptions|org.apache.commons.cli.Options|new:org.apache.commons.cli.BasicParser:",
    "M|org.apache.commons.cli.Parser|processProperties|java.util.Properties|new:org.apache.commons.cli.BasicParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
