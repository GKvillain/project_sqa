package org.apache.commons.cli2;
import org.junit.Test;
import static org.junit.Assert.*;
public class WriteableCommandLine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\udab8\udeee\ud899\udfdc\ud9b5\udcad\udafd\udffb\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u1cf1\u60dd", "\ud9b9\udc5f\u0949\ua9fd\ud979\udd8d\u6555\ud96e\udf0a\ud93b\udcf7\ud8b7\udc4b\ud97e\udf07\ud97b\ude01\ud95c\uddd3\ud873\udcfc\udb9b\udf7b\uda46\ude35\ud997\udcfd\udb27\udf51\ud930\udef9\udad5\udc58",
        53, 18446, -1385257744, -4658898034587146394L, 19540L, false, false, (char) 63906, (char) 38847,
        Double.longBitsToDouble(0x3fedc1d1e1ebf9f5L), Double.longBitsToDouble(0x3fdb7b457a51449cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\udab8\udeee\ud899\udfdc\ud9b5\udcad\udafd\udffb\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u1cf1\u60dd", "\ud9b9\udc5f\u0949\ua9fd\ud979\udd8d\u6555\ud96e\udf0a\ud93b\udcf7\ud8b7\udc4b\ud97e\udf07\ud97b\ude01\ud95c\uddd3\ud852\udefa\udb9b\udf7b\uda46\ude35\ud997\udcfd\udb27\udf51\ud930\udef9\udad5\udc58",
        53, 18446, -1385257744, -4658898034587146394L, 19540L, false, false, (char) 63906, (char) 38847,
        Double.longBitsToDouble(0x3fedc1d1e1ebf9f5L), Double.longBitsToDouble(0x3fdb7b457a51449cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\udab8\udeee\ud899\udfdc\udaa4\udf86\udbbd\udf49", "\u7849\u74c6\uc656\ucf7d\u86ea\u6f81\u3ad1\u28d9\uaa61\u6f54\ub64e\u7558", "\ud83a\udf54\ud9a3\udfbe\ud934\uddbc\u0949\ua9fd",
        19, 12110, 1775291598, 6334998734452309496L, -3725L, true, true, (char) 9567, (char) 36988,
        Double.longBitsToDouble(0x3fcaccaaff245d38L), Double.longBitsToDouble(0x3fbdd61467998380L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 16, "\ud887\ude68\ud9b3\uddee\u609f\udbe0\udd02\udab8\udeee\ud899\udfdc\udbf5\udcad\udafd\udffb\ud870\udc59\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e", "\u57a0\u1c23\u7af9\u1cf1\u6167\ucdb7\u9c97\u614a\ubf21\u266a\ud790\u0fe6\ub237\ua7fb\u9c48\u0662\u1678\u9c65\u89cf", "\ud997\udcfd\udb27\udf51\udb16\ude6d\ud959\udc91",
        44, 18446, -292313872, -4658898867810801818L, 19540L, false, false, (char) 63906, (char) 10004,
        Double.longBitsToDouble(0x3fe5bba6a9ebf9f5L), Double.longBitsToDouble(0x3fe87da2bd28a24eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 19, 16, "\ud814\udddf\u7623\ud8bd\ude5a\udba8\udfc7\ud902\udef3\ud899\udfdc\ud897\ude5f\ud95f\udd00\uda2e\ude07\uda59\udcb2\ud9b5\udcd8\udbbb\udd2b\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u4492\u22c3\u6291\u3f21\ubed6\u72af\u2699\u0c03\ua43d\ua1a9\u5306\ucad2\u647a\u7ee2\u9a60\u88ec\u799f\u0c75\u2076", "\uda59\udc5a\ud95e\udd42",
        56, 57256, -1084734228, -2041565053819504104L, 62040L, false, false, (char) 48714, (char) 63906,
        Double.longBitsToDouble(0x3fe38aaa73b83a3cL), Double.longBitsToDouble(0x3fdebf9f536f68aeL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\uda50\udeda\ud82d\udddc\ud9b0\uddf9\uda7b\udfc7\ud93c\udeaa\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\uda00\udc78\ud808\udc56\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u1cf1\u60dd", "\ud930\udfe4\ua412\ua9fd\uf58f\ud833\ude4e\ud98f\udfd4\ud93b\udcf7\ud8b7\udc4b\ud97e\udf07\ud97b\ude01\ud95c\uddd3\ud873\udcfc\udb9b\udf7b\uda46\ude35\ud997\udcfd\udb27\udf51\ud930\udef9\uda1d\udc5c",
        53, 18446, -1385257744, -4658898034587146394L, -38378L, false, false, (char) 63906, (char) 38847,
        Double.longBitsToDouble(0x3fe05039e1ebd1f1L), Double.longBitsToDouble(0x3fbe3d55ecb06088L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\udab8\udeee\ud899\udfdc\ud9b5\udcad\udafd\udffb\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u1cf1\u99c1", "\ud9b9\udc5f\u0949\ua9fd\ud979\udd8d\ud8f7\ude44\ud96e\udf0a\ud93b\udcf7\ud8b7\udc4b\ud97e\udf07\ud97b\ude01",
        27, 8309, 1700241795, 1679307019939590089L, 73296L, false, false, (char) 42686, (char) 40391,
        Double.longBitsToDouble(0x3fca8ea79c23be8cL), Double.longBitsToDouble(0x3fe7a0aaeac23b89L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 8, "\uffaa\u7623", "\u8b93\u8e27\u8710\u2892\u43e7\ua831", "\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e\ud98e\udcd7",
        18, -155, 1902516284, -7737177168176548721L, -21025L, true, true, (char) 5732, (char) 58275,
        Double.longBitsToDouble(0x3fecf7b7e425a07cL), Double.longBitsToDouble(0x3fec34811cce1eb0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 19, 4, 16, "\ud814\udddf", "\u7538\u3689\u6141", "\ud93c\udf5e\ud9a6\udd7a\ud8a4\udd3d\udba2\udf46\uda30\udd60\udbb8\ude7b",
        43, 56049, 483997899, -8822420833072901950L, -41206L, false, false, (char) 14787, (char) 63940,
        Double.longBitsToDouble(0x3fec0cfc4d55625eL), Double.longBitsToDouble(0x3fe0da85a305d92dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 16, 16, "\udafd\uddad\u08a5", "\u3689\u76ad\u90c2\u39fc\u6f8e\u28c5\u4b61", "\udbb8\ude7b\udbf3\udef4\ud808\udc56\ud8b6\ude7e\udb6d\udfc7",
        26, -255, -361416745, -7780519268003416945L, -21025L, true, true, (char) 5732, (char) 58275,
        Double.longBitsToDouble(0x3fecf7b7e425a07cL), Double.longBitsToDouble(0x3fec34811cce1eb0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 4, "\ud814\udddf\uda20\udf43\ud869\udc54\udbe0\udd02\udab8\udeee\ud873\udf15\ud9b5\udcad\udafd\udffb\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda06\udd4c\udb96\udfe2\ud9e1\uddcb\ud807\udff7\uda72\udd6d", "\u6f54\ub64e\u7af9\ucf04\u9899", "\ud93e\uddee\u0949\udb81\udf02\udbfe\uddee\udb72\udc96\ud997\udc52\udb08\udd59\uda5b\udebd\uda43\udd89\ud97b\ude01\ud95c\uddd3\ud883\udd04\ud9fa\ude14\ud93d\udc8c\ud959\udc5c\ud910\udedf\ud930\udef9\udad5\udc58\ud95e\udd42\ud966\udd00\ud8d0\udc03\uda32\udd1c\ud91d\uddcf\udb3c\uddd2\ud9de\udd3a\ud99b\udec5\ud8bb\ude76\udb8c\uddf6\udbf6\udf5f\ud807\uddeb\udaac\udd5f\ud9c0\ude8b\ud873\udde6\ud8c9\udfe4\udb7d\uddb0\udb1a\udda8\ud81e\uddd1\udab4\ude3c\ud942\udea9\ud828\ude6a\ud8ed\udceb\udaac\ude45\udb94\udde9\uda1a\ude47\ud95b\udcdc\uda5e\udd30\udaaf\ude03\udb82\udc09\udb62\udfa8\ud8a4\udd87\udb82\ude91\ud869\udcdd\ud8be\udccf\ud802\udd9e\udaa7\udca6\ud91b\ude04\u2eb8\ud8c7\udd94\uda3d\udc9b\udac9\udcee\udb16\ude65",
        48, 4031, -1136480864, -6437068000321673428L, 4715L, false, false, (char) 48438, (char) 35116,
        Double.longBitsToDouble(0x3fd94b295a96f880L), Double.longBitsToDouble(0x3fc9a27ec98d5f8cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 4, 16, 16, "\ud8e6\udee3\u7623\ud869\udcf0\udbe0\udd02\udab8\udeee\ud899\udfdc\ud9b5\udcad\udafd\udffb\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u1cf1\u60dd", "\ud9b9\udc5f\u0949\ua9fd\ud979\udd8d\u6555\ud994\ude1d\ud93b\udcdb\ud8b7\udc4b\ud9ca\udfad\ud97b\ude01\ud95c\uddd3\ud873\udcfc\ud957\udc3a\uda46\ude35\ud98f\udd98\udb27\udf51\ud930\udef9\udad5\udc58",
        53, 18446, -1385257744, -4658898034587146394L, 19540L, false, false, (char) 63906, (char) 38847,
        Double.longBitsToDouble(0x3fedc1d1e1ebf9f5L), Double.longBitsToDouble(0x3fdebe32ea51449cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 4, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\udab8\udeee\ud91d\udea6\ud84a\udc10\ud83d\udc01\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud9d8\udc1d\ud9c4\udc21", "\u6f54\ub64e\u7af9\u1cf1", "\udb9d\udea1\ud9b9\udc5f\u0949\ua9fd\ud979\udd8d\u6555\ud960\udf03\ud93b\udcf7\ud8b7\udc4b\ud97e\udf07\ud97b\ude01\ud95c\uddd3\ud873\udcfc\udb9b\udf7b\uda46\ude35\ud997\udcfd\udb27\udf51\ud930\udef9\udad5\udc58\ud95e\udd42\udac4\udf6e",
        21, 4772, -475338906, 8447831632637061332L, 19540L, false, false, (char) 63906, (char) 38847,
        Double.longBitsToDouble(0x3fedc1d1e1ebf9f5L), Double.longBitsToDouble(0x3fdb7b457a8beaecL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 16, "\ud814\udddf\u75e2", "\u3689\u76ad\u90c2\u302f\u5037\ua831\u016b", "\ud804\uddd1",
        43, 69337, -1494957199, 6186186531522282708L, 35127L, false, true, (char) 54041, (char) 19658,
        Double.longBitsToDouble(0x3fec0cfc4fdba35eL), Double.longBitsToDouble(0x3fe3281ff9d199d2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 0, "\u9a94", "\000", "\000\udafd\udffb\ud93c\udf5e",
        -5, -1000, 765221498, 163541600436224L, -100000L, true, true, (char) 62824, (char) 34965,
        Double.longBitsToDouble(0x3fe996f493819f89L), Double.longBitsToDouble(0x3feedd1af26503ffL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\udab8\udeee\ud899\udfdc\ud9b5\udcad\udafd\udffb\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9a4\udccd\ud9c5\udcb4\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u1cf1\u60dd\ucdb7\u3dc7\u32b4\ua8d8\u266a\ud790\u0fe6\ub237\ua7fb\u9c48", "\ud95c\uddd3",
        14, 6795, 390994134, 6364061027087205495L, 62040L, false, false, (char) 48714, (char) 63906,
        Double.longBitsToDouble(0x3fe38aaa73b83a3cL), Double.longBitsToDouble(0x3fdebf9f536f68aeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 12, 12, "\ud814\udd9a", "\u4e37", "\ud9b0\uddf9",
        22, -966, 0, -265275871133433734L, -47897L, true, false, (char) 37848, (char) 20050,
        Double.longBitsToDouble(0x3fba766bfeb93cb0L), Double.longBitsToDouble(0x3fe79f53a8009406L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 16, 16, "\ud814\udddf", "\000", "",
        -5, 21332, 1859757090, -61764152L, -100000L, false, false, (char) 19906, (char) 55832,
        Double.longBitsToDouble(0x3feeb80000000000L), Double.longBitsToDouble(0x3fc1f280cccb7a48L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 16, "", "", "\udab8\udeee",
        16, 2828, -1427041025, 7987596653605795807L, -47897L, false, false, (char) 0, (char) 4096,
        Double.longBitsToDouble(0x3fba766bfeb93cb0L), Double.longBitsToDouble(0x3fe79f53ac8f9406L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 12, 12, "\000", "", "",
        21, -1000, -1757478912, 146028888064L, -100000L, true, false, (char) 62704, (char) 62106,
        Double.longBitsToDouble(0x3fe7f8e6c8000090L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 16, "\ud814\udddf\u7623\ud869\udcf0\udbe0\udd02\uda08\udc35\udbcb\ude0f\ud9b5\udcad\udafd\udffb\ud93c\udf5e\ud9a6\udd7a\ud9b5\udd90\ud839\udd2a\uda30\ude01\udbb8\ude7b\ud9f9\ude78\ud808\udc56\ud8b6\ude7e", "\u6f54\ub64e\u7af9\u1cf1\u60dd", "\ud9b9\udc5f\u0949\ua9fd\ud979\udd8d\u6555\ud96e\udf0a\ud93b\udcf7\ud8b7\udc4b\ud97e\udf07\ud97b\ude01\ud95c\uddd3\ud873\udcfc\udb9b\udf7b\uda46\ude35\ud997\udcfd\udb27\udf51\ud930\udef9\udad5\udc58",
        53, 18446, -1385257744, -4658898034587146394L, 63673L, true, false, (char) 42484, (char) 35808,
        Double.longBitsToDouble(0x3fdb7b457a51449cL), Double.longBitsToDouble(0x3fd4ce9fecc6f8caL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 16, 8, "\udafd\uddad\u08a5\ud869\udcf0\udbe0\udd02\udab8\udeee\ud899\udfdc\ud9b5\udcad\ud935\udda4\ud80a\udc7a\ud820\udfb8\ud92c\udc63\udb89\udd59\uda30\ude41\udbb8\ude7b\udbf3\udef4\ud820\udf48\ud8b6\ude7e\ud8dc\udddd\ud91c\udfdd\ud8ce\udebe\u0e92\u1c96\udacc\ude96\udaa7\udd82\uda07\ude0b", "\ubf21\u266a\ud790\u0fe6\u0bb5\u683d\u534d\u495d\ub3d5\ubc7b\u6884\u7e8a\u43f2\uc97c\u5c85\ud0b7\ud14e\u3f36\uc417\u91d1\u4657\u0d5e\u3067\u3db5\u82c4\u7341\u3a31\u55d9\u299a\u5201\u46c1\ud690\ub810\ub49b\u6326\u4682\u0e34\u8b1e\u8fd5\u4005\u0b93\u185d\u5d9b\u03bc\u05c6\uc1ef\u135f\u7482\u6130\ucf72\u63a7\u6411\u8d53\u4498\u6990\u0a3e\u8945\u2f76\ud02d\u0c86\uc7ea\uc57c\u40a6\u5016\u5850\u144a\u2e3e\u9267\uc838", "\ud81c\udc95\ud8bc\ude7a\udb57\ude64\uda4a\udc96\ud998\udfe3\udaef\udca0\udaa6\udce0\ud851\udf34\uda51\udfbf\ud8c0\uded3\ua99e\ud88b\ude94\ud9bf\udebc\uda64\udecd\u6ffa\udaa7\ude7b\ud9b7\udc09\ud99e\udc38\ud88f\udd04\ud842\udf41\ud9b4\ude5b\u4546\u51c7\udac7\udd44\udab6\udd42\udb5d\uddb2\ub65c\ud9de\udf2f\ud846\udcc7\ud9a0\udf55\ud841\uddd6\ud90d\ude7a\ud9f7\uddf6\ud909\udcaf\udbe6\udf32\ud931\udeed\udada\udf19\udb78\udda2\ud9aa\ude45\ud8e0\uddb9\udb15\udd0b\uda42\udd86\ud83c\udca5\udb67\udc54",
        53, 75126, 453963902, 6427892030197231604L, 5621L, false, false, (char) 54344, (char) 46477,
        Double.longBitsToDouble(0x3fda093dbccd10c8L), Double.longBitsToDouble(0x3fbbb46ccebceba0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getCurrentOption||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|setCurrentOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|<init>|org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.GroupImpl|looksLikeOption|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int,boolean",
    "M|org.apache.commons.cli2.WriteableCommandLine|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addProperty|org.apache.commons.cli2.Option,java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|getCurrentOption||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setCurrentOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultSwitch|org.apache.commons.cli2.Option,java.lang.Boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getCurrentOption||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|setCurrentOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|<init>|org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.GroupImpl|looksLikeOption|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
