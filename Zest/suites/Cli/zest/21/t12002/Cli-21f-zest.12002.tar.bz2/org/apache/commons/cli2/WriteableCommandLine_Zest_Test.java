package org.apache.commons.cli2;
import org.junit.Test;
import static org.junit.Assert.*;
public class WriteableCommandLine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda98\udfd5", "\u8470\u5145\u6fb1\u1958\ud788\u3df5\uce64\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca", "\ud838\udd73\uda82\udd90\udace\udd53\udb41\udd5d\ud841\udf9b\ud880\udd90",
        36, 48565, -1295932, 6779970678798467712L, 39915L, false, false, (char) 40762, (char) 50786,
        Double.longBitsToDouble(0x3fb5fd8894dffc38L), Double.longBitsToDouble(0x3fcedd14228b179cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda98\udfd5", "\u8470\u5145\u6fb1\u1958\ud788\u3df5\u0961\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\u6819\u8123\ua53b\u19fd\uaaca", "\ud838\udd73\uda82\udd90\udace\udd53\udb41\udd5d\ud841\udf9b\ud880\udd90",
        36, 48565, -1295932, 6779970678798467712L, 39915L, false, false, (char) 40762, (char) 50786,
        Double.longBitsToDouble(0x3fb5fd8894dffc38L), Double.longBitsToDouble(0x3fcedd14228b15b0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda98\udfd5\udb31\udf69\udb1a\uddc8\ud803\udfc7\ud898\udd03\uda4d\udf1f", "\u3df5\uce64\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca\u1c90\u015f\u4573\u1e71\u8acf", "\ud880\udd90\ud9f1\ude4f\ud9db\uded5\udb4c\uddc2\ud9ec\udcf4\ud96e\udffe\ud877\uddf9\ud815\udf57",
        34, 3978, -1769152318, 8720104321747930462L, 36549L, false, false, (char) 40585, (char) 46154,
        Double.longBitsToDouble(0x3fbc55065edbdc58L), Double.longBitsToDouble(0x3f90890493047da0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud98a\udc27\udb84\udfe8\ud950\udc66\uda98\udfd5", "\u8470", "\udb00\udd9c\uda77\udf98\udb9a\udc75",
        5, 77703, 1725862912, -718475317498854957L, 7153L, true, true, (char) 32920, (char) 65333,
        Double.longBitsToDouble(0x3fd2ab0754180164L), Double.longBitsToDouble(0x3fe98601e00965d2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda98\udfd5", "\u8470\u5145\u6fb1\u1958\ud788\ucaf5\uce64\u32af\uc5eb\u31af\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca", "\ud838\udd73",
        23, 98515, 304510028, 4805494375855333252L, -53769L, false, false, (char) 63281, (char) 58548,
        Double.longBitsToDouble(0x3feb018f9a8b2f58L), Double.longBitsToDouble(0x3fc85fccc2ba5a30L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 4, 0, "\udba2\udf61", "\u9d89\u8f14\u1718\u0819\ua25c\u8b0c", "\ud898\udd03\uda4d\udf1f\udb00\udd9c\udab4\udf56",
        41, 89601, -2145764795, 7412524764252042881L, 79307L, true, false, (char) 22454, (char) 32920,
        Double.longBitsToDouble(0x3fec171d992ab075L), Double.longBitsToDouble(0x3f880164f889dc00L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61", "\u9d89\u8f14\u1718\u0819\ua25c\u8b0c", "\ud898\udd03\uda4d\udf1f\udb00\udd9c\udab4\udf56",
        41, 12465, 0, 7349874591869138561L, 79307L, true, false, (char) 22313, (char) 32920,
        Double.longBitsToDouble(0x3fec171d992ab075L), Double.longBitsToDouble(0x3f880164f889dc00L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda98\udfd5", "\u8470\u5145\ube65\u77b0\ud712\ub1fc\uce64\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca", "\ud838\udd73\uda82\udd90\udace\udd53\ud927\udef5\ud91e\ude81\ud898\udc14",
        36, 14143, -1295932, 6779970678798467712L, -82679L, true, false, (char) 35223, (char) 40585,
        Double.longBitsToDouble(0x3fdb09b365cc7b1aL), Double.longBitsToDouble(0x3fe24cf033ff7f32L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 12, 14, "\uda14\udc5a\ud87a\udfc7\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda99\udc82", "\u312d\u1e46\u10bf\u3cdf\u7e37\u8708\u835e\uc3da\u250a\u9aaf\u144f\ud08f\u2339\ua618\u8123\u459c\ud677\uaaca", "\ud85d\udf91\ud8a8\udf24\ud913\udd8d\uda1e\udcec\ud8c5\udd9e\ud8e5\ude28",
        -4, 93192, -3989938, 7428489025139819136L, -3548L, false, true, (char) 20963, (char) 51546,
        Double.longBitsToDouble(0x3fc5d2d19579e410L), Double.longBitsToDouble(0x3fcd8aa44a6ffe1cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda98\udfd5", "\u8470\u5145\u6fb1\u1958\u477e\u3df5\uce64\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca", "\ud838\udd73\uda82\udd90\udace\udd53\udb41\udd5d\ud841\udf9b\ud880\udd90",
        36, 48565, -1295932, 6779970678798467712L, 39915L, false, false, (char) 40762, (char) 50786,
        Double.longBitsToDouble(0x3fb5fd8894dffc38L), Double.longBitsToDouble(0x3fcedd14228b179cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 16, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud9e9\udec5\ud982\udf0a\ud9b8\udc08\ud956\udd30\uda98\udfd5", "\u8470\u5145\u6fb1\u1958\ud788\u3df5\uce64\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca", "\ud838\udd73\uda82\udd90\udace\udd53\udb41\udd5d\ud841\udf9b\ud8c4\ude02",
        5, 48673, -1295932, 6779970678798467712L, 39915L, false, false, (char) 40762, (char) 50786,
        Double.longBitsToDouble(0x3fb5fd8894dffc38L), Double.longBitsToDouble(0x3fefd74508a2c5e7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 14, "\udb93\udc61\udb69\udc8f\ud8d2\udd67\ud99c\udd97\ud814\ude4e\udb7f\udee8\ud950\udc66\udbe0\uded8", "\u8470\u5145\u6fb1\u1958", "\ud8f7\udd2c\uda0c\udd30\udb0e\udc82\ud8dc\udebc\udb22\udee7\ud9dc\ude12\u5dc8\u0365\ud94a\udcdf\ud9c5\udcae\udace\uddec\udb59\udd04\uda34\udf76\udb4a\udee2\ud838\udd73\uda82\udd90\udace\udd53\udb41\udd5d\ud841\udf9b\ud880\udd90\ud9f1\ude4f\ud95d\uded6\udb4c\uddc2\ud9ec\udcf4\ud8b3\udc00",
        42, 68698, 794316640, -115366761824722750L, -14843L, true, false, (char) 59938, (char) 35223,
        Double.longBitsToDouble(0x3fe09abe114877afL), Double.longBitsToDouble(0x3fe9345334244d1eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 11, 18, "\ud88f\udf2a\ud87a\udff4\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb76\udc2a\ud997\udd0a\uda98\udfd5\udb31\udf69\ud82d\udf71\ud803\udfc7\ud898\udd03", "\ub007\u3df5\uce64\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u3a4a\uaaca\u3b6e", "\udbbc\uddc4\uda9b\uddd9\udb41\udd5d\udb62\udd4c\ud815\udd2a\ud9db\udcd6\ud9db\uded5\udb4c\uddc2\ud9ec\udcf4\ud827\udcfb\ud877\uddfd\uda5d\udcfb\ud8ea\ude2a\udb58\ude72\ud84a\ude8b\udac7\udfcf\ud86b\udcc9\udbaf\udd4f\ud9ba\udd3a\uda0f\udd89\ud8ef\udc5d\uda35\udfb0\ud8f3\udd65\ud991\uddf2\ud88d\udc19\ud8c0\udde9\udb99\uddfa\ud860\uddd1",
        59, 28862, -1170423532, 1336934631103137951L, 53052L, true, false, (char) 49007, (char) 31089,
        Double.longBitsToDouble(0x3fe282bda5c06675L), Double.longBitsToDouble(0x3fd2053ba3185a62L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\udb53\udf14", "\u8470\u5145\u6fb1\u1958\ud788\u3df5\uce64\u32af\uc5eb\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca\u1c90\u015f\u4573\u1e71\u8acf\u01cf\u6ab7\u8fcd\uccfc\u2503\u79ac\u5aed\u708a\ub04c\u3d3e\u0f7d\u30a5\u2bc7\ua01b\u71ac\u63c8\ud6e8\u241b\u02f9\uc082\u10f4\uc8db\ucaf5", "\udba6\udd82\ud8b0\udd90\uda37\udf77\ud8fa\udc1c\udb7c\udccf\ud950\udf18\ud93b\udcc3\ud977\udcbe\ud800\udf1f\udb04\udee1\ud9d8\udd66\udb83\uddc2\ud8c9\udcf6",
        21, 48976, -289964439, 6939057060388450218L, 99076L, false, false, (char) 19235, (char) 1841,
        Double.longBitsToDouble(0x3fe3a5f8926dd94bL), Double.longBitsToDouble(0x3fe7f3384f8a7a0fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 0, 0, "", "\000", "\udb84\udfe8",
        32, 87609, -2090889534, -6243599987068136615L, 96131L, false, false, (char) 37158, (char) 59012,
        Double.longBitsToDouble(0x3f40001a059b7800L), Double.longBitsToDouble(0x3fdd3f6078d6c130L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 19, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\ud89f\udcca\ud950\udc66\uda98\udfd5", "\u8470\u5145\u6fb1\u1958\ud788\u3df5\uce64\u32af\uc5eb\u9aaf\u59a4\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca", "\ud838\udd73\uda82\udd90\ud8ba\udd53\udb41\udd5d\ud841\udf9b\ud880\udd90",
        36, 48565, -1295932, 6779970678798467712L, 39915L, false, false, (char) 40762, (char) 50786,
        Double.longBitsToDouble(0x3fb5fd8894deb438L), Double.longBitsToDouble(0x3fcedd14228b179cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 8, 3, "\udbe2\udf20", "\u9d89\u8f14\u1718\u0819\ua25c\u8b0c\u7f17\u8470\u5145\u6fb1\u1958\ud788\u3df5\uce64\u9414\uc5eb\u9aaf", "\u5dc8\u0365",
        44, 9474, 11673898, 2841995718481051089L, 46047L, true, false, (char) 1076, (char) 28291,
        Double.longBitsToDouble(0x3fed6891378442b0L), Double.longBitsToDouble(0x3fe7e4d7f765b0b1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 4, 0, "", "\u2df9", "\udb84\udfe8\ud950\udc66\uda98\udfd5\udb31\udf69",
        -4, 59969, 0, 3107444800417169408L, -100000L, false, false, (char) 58880, (char) 0,
        Double.longBitsToDouble(0x3fe40b36f0d3f607L), Double.longBitsToDouble(0x3fbac000148b0ff0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\ud8f3\udf09\010\uda1e\udd57\u00b0\u9997\000\000\000", "\u8470\uc01b\u6fb1\u190b\ud788\u3df5\u0099\u326a\uc5eb\u9aaf\u144f\000\000\u5d03", "\ud9de\udd34",
        10, 77042, 811620361, -1279520926689394567L, -100000L, false, false, (char) 36709, (char) 47104,
        Double.longBitsToDouble(0x3f4ffd8a01785c00L), Double.longBitsToDouble(0x3fdda19584140420L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud910\udca1\udbe8\udd68\udb84\udfe8\ud950\udc66\uda98\udfd5\udb31\udf69\udb1a\uddc8\ud803\udfc7\ud808\udcfb\uda4d\udf1f\udb00\udd9c\udab4\udf56\ud9b1\udf37\ud9ad\udc96\ud9ba\udebb\udbc6\ude0f\ud9bb\udccf\uda7f\ude94\udb82\udc9e\u5dc8\u0365\ud802\udd03\udbe5\uded1\ud9de\udd34\u665f\ud860\udde2\udb4a\udee2\ud838\udd73\ud812\udff8\udace\udd53\udb41\udd5d\ud841\udf9b\ud880\udd90\ud9f1\udde2\ud9db\uded5\udb4c\uddc2\ud9ec\udcf4\ud96e\udffe\ud877\uddf9\uda5d\udcfb\uda14\udd80\udb58\udead\ud84a\ude8b\udac7\udfcf\ud86b\udcc9\udba1\udc4f\ud9ba\udd3a\uda0f\udd89\u0ce8\ud8c7\udd8f\udb1c\uded5\u1739\ud9fe\udc14\u4ccb\uda7d\udf23", "\u48ba\u3334\u7427\u9367\u0682\u0ebc\u974f\uaa60\u1f0b\u060b\ucebf\u8c21\ud707\uc126\u09d3\u64ee\uc5e1\ud3f3\u6ba0\u259e\u0720\ua988\u6b93\uad94\u3352\u0f4d\u2732\uc9d1~\uc838\u51dd\u2bed\u416b", "\udb05\udff4\udba6\udcc7\udbe5\uddd8\udbc7\udc54\ud8f0\udd6c\udb72\uddeb\ud920\udf9f\ud921\ude64\ud910\uddb0\uda00\ude25\ud973\udf7f\uda32\udf7a\ud9f5\udfa5\ud804\udf21\uda2b\udd5b\ud97e\udf87\udbd0\udf0d",
        31, 99247, 308548489, -2827096436899040716L, 84693L, true, false, (char) 33440, (char) 63832,
        Double.longBitsToDouble(0x3fe79e6086da9af4L), Double.longBitsToDouble(0x3fdb47262112f7b6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "", "", "\ud814\ude4e",
        22, 90643, -1213628391, -8980302169532381468L, -100000L, true, true, (char) 52812, (char) 37158,
        Double.longBitsToDouble(0x3fe22f342400801aL), Double.longBitsToDouble(0x3fd8166de3a7ec0eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\udb08\udfcd\u94c6\ud945\udfc4\ud9f4\udd77\udb49\udc44\uda86\udddc\ud91a\udfc5\udb83\udf89\ud817\udca7\u34cb\ud95e\udc0e\udb47\ude02\ud99f\ude81\ud8f5\udeb1\ud97e\ude31\udac7\uddbf\u0365\ud802\udd03\udbe5\uded1\ud9de\udd34\u665f\uda1f\ude02\ud832\uddd7\udae1\udc9c\udba6\udc0a\ud82e\ude85\uda8a\ude95\udb92\udcd4", "\ua779\uba93\uceb5\u03a2\u2224\u9fe8\u95cd\u1112\u4846\u75ff\u1d7c\u7168", "\ud927\udcdb\ud8b8\udead\ub317\udb7b\udc6a\udada\ude27\ud8f5\uded4",
        39, 92787, 1850634871, -7710975065146015660L, 89046L, true, false, (char) 57087, (char) 57444,
        Double.longBitsToDouble(0x3fb9d106623c3050L), Double.longBitsToDouble(0x3fe9f32ae9876b34L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 12, 14, "\udba2\udf61", "\u9d89\uce13\u1718\u0819\000\ud449", "\ud898\udd03\uda4d\udf1f\udb00\udd9c\udab4\udf56",
        41, 12465, 0, 7349874591869138561L, -100000L, false, false, (char) 22313, (char) 32920,
        Double.longBitsToDouble(0x3fec171d992ab075L), Double.longBitsToDouble(0x3f880164f889dc00L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 12, 14, "\000", "\000", "",
        -5, -1000, -2097115454, 77945066487808L, 96608L, false, true, (char) 45610, (char) 6603,
        Double.longBitsToDouble(0x3ecd000000b00000L), Double.longBitsToDouble(0x3fec900006814eddL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 14, "\udba2\udf61\ud87a\udf17\uda1e\udd57\ud99c\udd97\ud814\ude4e\udb84\udfe8\ud950\udc66\uda98\udfd5", "\u8470\u5145\u5552\u70dd\ud788\u3df5\uce64\u32af\ua0a7\u9aaf\u144f\ud08f\u2339\ua618\u8123\ua53b\u19fd\uaaca", "\ud838\udd73\uda82\udd90\udace\udd53\udb41\udd5d\ud841\udf9b\ud880\udd90",
        36, 48565, -1295932, 6779970680392885888L, 39915L, false, false, (char) 40762, (char) 50786,
        Double.longBitsToDouble(0x3fb5fd8894dffc38L), Double.longBitsToDouble(0x3fcedd143e8b179cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 14, "\udad0\udeb4\ud95d\udc17\ud948\udd34\uda8a\udd3f\uda1c\udfe3\ud9ad\uddb0\ud8b7\udd4f\ud881\ude48\ud846\uddda\udac5\udf1b\udb55\udccd\ud898\udd03\udbcf\udd4c\udb48\udda0\ud874\udf56\ud8f5\uddb8\uda0c\udf18\ud9ba\udebb\udbc6\ude0f\ud859\ude6a\ud8f5\udf0d\ud8fb\uddf1\ud893\udde9\uf5f7\udb26\udcef\udbe5\uded1\ud925\udde4\ud93a\udf6d\ud860\udde2\udb5f\udec6\ud838\udd73\uda82\udd90\udace\udd53\ud819\udd2e\ud841\udf9b\ud880\udd90\ud978\udc47\ud9db\uded5\udb4c\uddc2\ud9ec\udcf4\uda3f\ude4c\ud9ac\ude61\uda0b\udfa8\udac9\udf5e\udb58\ude72\u38cd\udb50\udfd2\udbb6\udfc4\ud968\udcf7\ud995\udfe1\uda0f\udd89\u214c\udaef\udd79\udb38\udfa1\ud36e\ud9ca\udf3d\udb7a\udd12\uda69\udf05\ud947\udc5f\udace\udc6c\ud978\udeff\udbf1\udcb7\ud9da\uddd8\ud985\udde8\uda56\udfd8\ud96a\udfd2\ud920\udd83\ud851\udc12\u4a8a\uda88\uddfa\udbc6\ude34", "\u82bb\u0bcf\uc5d8\u4dfd\u4832\ud04b\u2fe5\u3295\u4737\u78f0\uacb3\u7d1e\u0b9a\u3d3a\u95d1\ua931\u8f6e\u9a30\u3dc0\u7f17\u9fdd\u5de6\u2d4d\ubf3e\u2ee1\u56d2\u1fc2\uc378\uc8f1\uc206\u4a2c\u6af8\uad71\u4826\u4a4a\u8475\u8e6c\ucab3\u3b1e\ub3c4\u754d\u427a\ub25a\u950e\ubd55", "\ud8bf\udde9\udaad\udf5d\udaef\udd68\ud8b0\udc20\udb4d\uddee\uda8b\udec3\udb11\udc4c\udbf1\udd8a\udad4\udd28\ud971\ude6d\ud9e3\ude86\uda08\ude3c\udacc\udfb3\u41b0\uda55\udd21\u8d2d",
        14, 52722, 1930869885, -2818287785846346023L, 25902L, true, false, (char) 799, (char) 59280,
        Double.longBitsToDouble(0x3fa729d33b1092a0L), Double.longBitsToDouble(0x3fd90d4e42a50d10L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 14, "\udad0\udeb4\ud95d\udc17\ud84e\udf17\000\uda1a\udf2c\ud9ad\uddb0\ud8b7\udd4f\ud881\ude48\ud846\uddda\udac5\udf1b\udb55\udccd\ud898\udd03\udbcf\udd4c\udb48\udda0\ud874\udf56\ud8f5\uddb8\uda0c\udf18\ud9ba\udebb\udbc6\ude0f\ud859\ude6a\ud8f5\udf0d\ud8fb\uddf1\ud893\udde9\uf5f7\udb26\udcef\udbe5\uded1\ud925\udde4\ud93a\udf6d\ud860\udde2\udb5f\udec6\ud838\udd73\uda82\udd90\udace\udd53\ud819\udd2e\ud841\udf9b\ud880\udd90\ud978\udc47\ud9db\uded5\udb4c\uddc2\ud9ec\udcf4\uda3f\ude4c\ud9ac\ude61\uda0b\udfa8\udac9\udf5e\udb58\ude72\u38cd\udb50\udfd2\udbb6\udfc4\ud968\udcf7\ud995\udfe1\uda0f\udd89\u214c\udaef\udd79\udb38\udfa1\ud36e\ud9ca\udf3d\udb7a\udd12\uda69\udf05\ud947\udc5f\udace\udc6c\ud978\udeff\udbf1\udcb7\ud9da\uddd8\ud985\udde8\uda56\udfd8\ud96a\udfd2\ud920\udd83\ud851\udc12\u4a73\ud803\ude57\000", "\u82bb", "\ud9e0\udcde\udafe\ude44\udab8\udc5e\ud9b9\udf43\ud94d\udc5d\ud974\udf0c\udb2d\ude69\uda56\ude61\udba5\udf9b\udb33\udde1\u2984\udaa3\udf9b\u7827\ud988\udc33\ud8c9\ude00\ud921\uddfb\ud9cb\ude0e\ud948\udc6d\uda21\ude1a\udbc7\ude18\ud92e\uddc5\ud86e\uddd5\ud98c\udfd8\ud936\udfaa\ud88d\udf75\ud92d\udd94\uda4c\udcfe\ud80d\udc94\udbe1\udd33\udb24\udde7\ud868\udd45\uba25\udb99\udfa0\ud98a\udc7a\ud9bf\ude61\ud887\ude6b\ud89d\udfb5\ud9d1\ude8a\ud912\udfae\uda8c\udcdb\udb3c\ude36\udb98\udc1f\ud839\udf93\udb76\udf6e\ud8bf\udde9\udaad\udf5d\udaef\udd68\ud8b0\udc20\udb4d\uddee\uda8b\udec3\u462d\000\000\000\ud9e3\ude86\uda08\ude3c\udacc\udfb3\u41b0\uda55\udd21\u8d2d\ua943\ud8d6\udec2\ud902\udf45",
        11, 72641, 915542559, 1841387094535644877L, 69619L, false, false, (char) 38106, (char) 43636,
        Double.longBitsToDouble(0x3fd528688b10a13aL), Double.longBitsToDouble(0x3fd98a82c705fddeL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 14, "\udad0\udeb4\ud95d\udc17\ud84e\udf17\000\uda1a\udf2c\ud9ad\uddb0\ud8b7\udd4f\uda5b\udc2b\ud846\ude0a\udac5\udf1b\udb55\udccd\ud898\udd03\udbcf\udd4c\udb48\udda0\ud874\udf56\ud8f5\uddb8\uda0c\udf18\ud984\udcde\udbc6\ude0f\ud859\ude6a\ud8f5\udf0d\ud8fb\uddf1\ud893\udde9\uf5f7\udb26\udcef\udbe5\uded1\ud925\udde4\ud93a\udf6d\ud860\udde2\udb5f\udec6\ud838\udd73\uda82\udd90\udace\udd53\ud819\udd2e\ud841\udf9b\ud880\udd90\ud978\udc47\ud9db\uded5\udb4c\uddc2\ud9ec\udcf4\uda3f\ude4c\ud99a\udc2c\uda0b\udfa8\udac9\udf5e\udb58\ude72\u38cd\uda33\udce5\ud8df\udc16\ud968\udcf7\ud995\udfe1\uda0f\udd89\u214c\udae5\udf6e\udb38\udfa1\ud892\udd7c\uda04\uddeb\udb7a\udd12\uda69\udf05\ud947\udc5f\udace\udc6c\ud978\udeff\udbf1\udcb7\ud9da\uddd8\ud985\udde8\uda56\udfd8\ud96a\udfd2\ud920\udd83\udbb6\udfc4\ud922\ude64\ud803\ude57\000", "\u82bb", "\ud8ea\udce2\ud80d\ude4a\udabc\ude38\ud9b9\udf43\uda0c\ude9c\ud81f\uddfb\ud80d\udd7d\uda56\ude61\udba5\udf9b\udb33\udde1\u2984\udaa3\udf9b\ud957\udc29\udb1d\udc5e\ud8af\udfea\ud921\uddfb\ud9cb\ude0e\ud948\udc6d\uda21\ude1a\udbc7\ude18\ud92e\uddc5\ud86e\uddd5\ud98c\udfd8\ud936\udfaa\ud88d\udf75\ud92d\udd94\uda4c\udcfe\ud80d\udc94\udad0\udc7f\uda44\udd6e\udb7c\udc92\uda44\udd29\udb99\udfa0\ud98a\udc7a\ud9bf\ude61\ud887\ude6b\ud89d\udfb5\ud9d1\ude8a\ud912\udfae\uda8c\udcdb\udb3c\ude36\udb98\udc1f\ud839\udf93\udb76\udf6e\ud8c9\udee9\udaad\udf5d\udaef\udd68\ud8b0\udc20\udb4d\uddee\uda8b\udec3\u462d\000\000\000\ud9cc\udf95\uda08\ude3c\udacc\udfb3\u41b0\uda55\udd21\u8d2d\ua943\ud8d6\udec2\ud902\udf45",
        11, 72641, 915542559, 1841387094535644877L, 69619L, false, false, (char) 38106, (char) 43636,
        Double.longBitsToDouble(0x3fd528688b10a13aL), Double.longBitsToDouble(0x3fd98a82c705fddeL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getCurrentOption||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|setCurrentOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|<init>|org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.GroupImpl|looksLikeOption|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int,boolean",
    "M|org.apache.commons.cli2.WriteableCommandLine|addOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addProperty|java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addProperty|org.apache.commons.cli2.Option,java.lang.String,java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addSwitch|org.apache.commons.cli2.Option,boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|addValue|org.apache.commons.cli2.Option,java.lang.Object|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|getCurrentOption||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|getUndefaultedValues|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setCurrentOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultSwitch|org.apache.commons.cli2.Option,java.lang.Boolean|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.WriteableCommandLine|setDefaultValues|org.apache.commons.cli2.Option,java.util.List|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|getCurrentOption||new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|looksLikeOption|java.lang.String|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|setCurrentOption|org.apache.commons.cli2.Option|new:org.apache.commons.cli2.commandline.WriteableCommandLineImpl:org.apache.commons.cli2.Option,java.util.List",
    "C|org.apache.commons.cli2.commandline.WriteableCommandLineImpl|<init>|org.apache.commons.cli2.Option,java.util.List",
    "M|org.apache.commons.cli2.option.GroupImpl|looksLikeOption|org.apache.commons.cli2.WriteableCommandLine,java.lang.String|new:org.apache.commons.cli2.option.GroupImpl:java.util.List,java.lang.String,java.lang.String,int,int,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
