package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 7, 6, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4", "\uaff5\u2f08\u3ad3\u46d2\u82d3\ucda7\u7ffe\u20d5\u4068\ua81e\u765c\u7542\u525d\u0c64\ud31b\u585d\uad90\u74d5", "\ud9ed\udd02\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c",
        5, 40629, -2023818154, 5250889500649599092L, -95038L, true, true, (char) 6669, (char) 3837,
        Double.longBitsToDouble(0x3fef25ae9a7567c7L), Double.longBitsToDouble(0x3fca77b91fa62450L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 7, 6, "\ud80f\ude37\udb40\udc40\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4", "\u8959\u206d\u3ad3\u46d2\u82d3\ucda7\u7ffe\u20d5\u4068\u3f1b\u62b3\u7542\u525d\u0c64\ud31b\u585d\uad90\u74d5", "\ud9ed\udd02\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c",
        5, 40629, -2023818154, 5250889500649599092L, -95038L, true, true, (char) 6669, (char) 3837,
        Double.longBitsToDouble(0x3fef25ae9a7567c7L), Double.longBitsToDouble(0x3fca77b91fa62450L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 7, 6, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4", "\uaff5", "\ud999\udc3b\udae5\ude72\uda89\udd4f\uda62\udc60\udbc1\ude8b\uda4a\udec6\u9a94\ud9a9\udea0\udb02\ude80\ud9cc\udfd7\ud87a\ude00\ud819\udcd5\ud8af\udcff\ud8fc\udc01\ud80f\udda7\ud845\udfab\udb35\udcaf\ud9ed\udd02\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c",
        5, 40629, -2023818154, 5250889500649599092L, -95038L, true, true, (char) 6669, (char) 3837,
        Double.longBitsToDouble(0x3fef25ae9a7567c7L), Double.longBitsToDouble(0x3fca77b91fa62450L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 12, 2, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8", "\u1804", "\uda64\uddd4\ud9c4\udd53\udbbd\ude21\ud9b9\udeb8\ud89a\udceb\udb2c\udd3b\uda89\udd70\uda62\udc60\udbc1\ude8b\uda4a\udec6\ud9b1\udd98\ud9d9\udfd9\udb2d\udd6b\ud9cc\udfd7\udb6a\ude78\ud819\udcd5\ud8af\udcff\ud8fc\udc01\ud80f\udda7\ud845\udfab\udb35\udcaf\ud9ed\udd02\udb98\uddfc\ud811\udd9d\ue56c",
        26, 93891, -1091370595, 6033353713599315030L, -87596L, true, true, (char) 34236, (char) 50912,
        Double.longBitsToDouble(0x3fe2b9ddb7118febL), Double.longBitsToDouble(0x3fe89dae9bad3f02L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 4, "\udbb9\udf8d\udb9f\udc8f", "\u7d48\u4e2e\u404e\u3869\u1804\u408c\u66aa\u839b", "\udbd0\udce3\ud8f7\udda9\ud86c\udf27\u88e6",
        49, 8577, 586782770, 2119674029182262859L, 79329L, true, false, (char) 22721, (char) 53415,
        Double.longBitsToDouble(0x3fc01a94fe5cd70cL), Double.longBitsToDouble(0x3fe6e675ed0d9b3fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 7, 6, "\udbb9\udf8d\udb34\udfcb\ud86f\udca7\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ue69e\ud936\uddbb\u73d4", "\uaff5\u2f08\u3ad3\u46d2\u82d3\ucda7\u7ffe\u20d5\u4068\ua81e\u9ea0\u7457\u525d\u0c64\ud31b\u585d\u009f\000", "\ud9ed\udd02",
        45, 26336, 1187739968, -4298674189977565493L, -19933L, false, false, (char) 28556, (char) 31058,
        Double.longBitsToDouble(0x3fd17310c6000000L), Double.longBitsToDouble(0x3fda5113ccae776cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 3, 9, 6, "\udb4d\ude41\udbbd\udcc1\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4", "\uaff5\u2f08\u3ad3\u6ed3\ub87a\ucda7\u7ffe\u769c\u61e3\ua81e\ud366\u7542\u525d\u3405\ud31b\u585d\u314f\u360f", "\ud9ed\udd02\udb98\uddfc\ud80e\udf3a\ue609\udbf9\udf14\uda17\ude2c",
        5, 40629, -2023818154, 6024664211568246809L, -97924L, true, false, (char) 8860, (char) 62141,
        Double.longBitsToDouble(0x3fe62a0c9670c917L), Double.longBitsToDouble(0x3fee8d2c5a955d89L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 7, 6, "\udbb4\udc8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud89e\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4\ua036\uda64\uddd4\ud9c4\udd53\udaa2\udc70\udaa0\udcd1\ud9c4\udd3d\udae5\ude72\uda89\udd4f\uda62\udc60\udbc1\ude8b\uda4a\udec6\ud949\udee4\udbd7\ude5f", "\u0c64\ud31b\u585d\uad90\u74d5\ub438\u5d34\ud4c5\uaad2\u5056", "\uda17\ude2c\uda55\uddc7\ud893\udc2c\ud847\udd3a\ud953\udc79\udbd4\udf57\ud887\udfd4\u3466\udb78\udd29\ud841\udfbc\udbe0\udeb1\udabb\ude01",
        30, 827, -51097623, -3603030103197999896L, 73851L, true, true, (char) 27980, (char) 22562,
        Double.longBitsToDouble(0x3fd9ca576f5977e4L), Double.longBitsToDouble(0x3fe180ded3513938L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 2, 6, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4", "\u7388\ubb0e\u3ad3\u2c28\u5c96\ucdbb\u7ffe\u20d5\u4068\ua81e\u765c\u7542\u525d\u0c64\ud31b\u585d\uad90\u74d5\ub438\ub534\ud4c5\uaad2\u5056\u0d28\u7be4\u833c\ua483\u8a79\ud3af\uc68b\u9295\uc89e\u6e54", "\udbe0\udeb1\udabb\ude01\u6e8e\udb93\uddd0\udb18\ude2b\uda0b\ude81\udb76\udc6b\ud873\udc25\ud852\uddac\udba1\udf3e\udbc0\ude60\uda76\udc27\ud9fb\udd07\uda46\ude65\uda3f\ude76\ud811\udd03\uda7e\udc91\uda50\ude39\ud81f\udc77\ud8d5\udeb3\ud936\ude1c\uda72\udf69\udb3a\udfae\udade\udc1d\ud917\udfc8\udb61\udf27",
        -5, 6634, 527571659, 4343127656435133085L, -42780L, true, true, (char) 10595, (char) 11072,
        Double.longBitsToDouble(0x3feedce8f602efb7L), Double.longBitsToDouble(0x3fcef8cf9e067b70L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 6, 11, "\udbb9\udfc7\udbbd\udc8f\ud86f\udd91", "\u3fc0\u6ff2", "\u73d4",
        22, 10117, 1290519755, -3774617789657186526L, 18585L, false, true, (char) 31218, (char) 63933,
        Double.longBitsToDouble(0x3fe08081e4450c1aL), Double.longBitsToDouble(0x3fe5052602eb8d07L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 9, 7, 6, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4", "\uaff5\ub33c\u3ad3\u46d2\u82d3\ucda7\u7ffe\u20d5\u4068\ua81e\u765c\u7542\u525d\u0c64\ud31b\u585d\uad90\u74d5", "\ud9ed\udd02\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c",
        5, 40629, -2023818154, 3449449649293332740L, -95038L, true, true, (char) 6669, (char) 3837,
        Double.longBitsToDouble(0x3fef25ae9a7567c7L), Double.longBitsToDouble(0x3fca77b91fa62450L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 0, 7, "\udb48\udcb3\ud97d\uddd2\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4\ua036", "\u2f08\u3ad3\u46d2\u82d3\ucda7\u7ffe\u20d5\u4068\ua81e\u765c\u7542\u8bc9\u0bba\ud31b", "\ud80f\udda7\ud845\udfab\udb35\udcaf\ud9ed\udd02\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c\uda55\uddc7\ud893\udc2c\ud847\udd3a\ud953\udc79\udbd4\udf57\ud887\udfd4",
        19, 9797, -1880367529, -5344788620026316828L, -86078L, false, true, (char) 898, (char) 8021,
        Double.longBitsToDouble(0x3fe99776a532f7c5L), Double.longBitsToDouble(0x3fe569c07c509af3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 1, 6, "", "\u3eef\u26f5\u7d48\u3fc0\u6ff2\u38fe\u1804\ub97d\u667d\ub9d4\uaff5\u2f08\u3ad3\u46d2\u82d3\ucda7\u997a\u20d5\u4068\ua81e\u765c\u7542\u525d", "\ud888\udca4\ud8fc\udc01\ud80f\udda7",
        41, 11495, -251626020, -4041183199259305024L, -97287L, true, false, (char) 32063, (char) 34352,
        Double.longBitsToDouble(0x3fb594ee81743af0L), Double.longBitsToDouble(0x3fbd123788b98860L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 11, 7, 0, "\ud96e\udfc8\ud9fd\udc0e\ud886\udd5a\udbea\udc5f\udac3\udd54\udbe0\udde2\ud943\udd2b\ud976\udf1c\uda44\udd04\u9b8f", "\u6e8d\uc208\u2f2a\u46d2\u6f81\u3bd8\u98ff\ube67\u4068\u75c0\u7664\u32d6\u32ff\u82f1\ud31b\u585d\uc644\u74d5", "\ud999\udfac\udb58\udea6\ud8bb\ude36\ud836\udc8a\ud869\udcdb\uda17\ude2c",
        18, 10836, 1484868003, 2584625574830005254L, -71721L, true, false, (char) 45442, (char) 4386,
        Double.longBitsToDouble(0x3fd3eda70086d054L), Double.longBitsToDouble(0x3fecc93ff9cb75c1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 8, 9, 6, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\udb94\ude5d\udaaf\udd46\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud979\udca6\ud92a\udd9a", "\u0478\u2ef3", "\udab1\udf18\uda89\udd4f",
        46, 94575, 203059728, -6575206783025439072L, 79329L, true, false, (char) 60609, (char) 10600,
        Double.longBitsToDouble(0x3fc01a94fe5cd70cL), Double.longBitsToDouble(0x3fddccebda97e32aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 12, 4, "\udb0b\udc35\udbc0\udc4b\ud86f\udd91\ud879\ude61\ud8cc\udf20\ud809\udcc8\ud93f\udcd2\ud9f5\udeeb\ud971\udfce\u73d4", "\u9b37\u2f08\u3ad3\u46d2\u8292\ucda7\u7ffe\u20d5\u1712\u92e3\u760c\u7542\u525d\u0c64\ud31b\u585d\uad90\u74d5", "\ud9ed\udd02\udb02\udef8\ud80d\udf01\ue56c\udbf9\udf14\uda17\ude2c",
        5, 67589, -2023858346, 5250889500649599092L, -95038L, true, true, (char) 6669, (char) 3837,
        Double.longBitsToDouble(0x3fef25ae9c1267c7L), Double.longBitsToDouble(0x3fca77ae9fa62450L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 3, 1, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\udb68\udede\uda7b\udfac\uda66\udfea\uda07\udf66\ud903\udc1d\u73b0\ua036\uda64\uddd4\ud8a0\ude81\udaca\ude07\udbf1\ude79\ud999\udc3b\udae5\ude72\uda89\udd4f\uda62\udc60\uda6e\udda2\u978d\ud949\udee4\ud9d9\udfd9\udb2d\udd6b\ud9cc\udfd7\udb6a\ude78\ud819\udcd5\ud892\udd09\ud8fb\udf75\ud80f\udda7\ud9b7\ude48\udbd1\ude3e\ud9ed\udcf6\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c\uda55\uddc7\ud893\udc2c\ud847\udd3a\ud953\udc79\ud9b8\udd8e\ud887\udfc1\u3466", "\u331f\u8686\u23fa\u07e1\u3e32\u71ae\ud51d\uc300\ua562\u4a85\u072e\u247c\u1c67\u773a\u7604\uc480\uc1fc\u5f08\u68f6\u8909\u9c42\u7cfe\u695c\u2a93\u5565\u177f", "\ud989\udcb8\uda42\udc5f\udb5c\uddfa\ud96e\udf31\ud891\udd13\ud8ac\udf67\ud82c\udc03\uda07\ude4c\udae1\ude20\ud9a7\udeab\udb5f\udfc8\ud832\ude44\udb7c\udc13\uda4e\ude56\udab8\udd5a\udacd\udf9a\uda4c\udd76\udb48\udd86\ud909\udd94\uda44\udded\udb71\udcd4",
        53, 25670, 1376702946, 4173779287191781489L, 90291L, true, true, (char) 34069, (char) 23365,
        Double.longBitsToDouble(0x3fe3b4f31b2afb07L), Double.longBitsToDouble(0x3fe1f9138152c411L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.io.File:\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4\012",
        Z.run(T, 1, 5, 7, 6, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\ud971\udfce\u73d4", "\uaff5\u2f08\u3ad3\u0ed3\ua5e4\ucdc4\u7ffe\u20d5\ud1cc\u28d3\ua3b8\u7542\u525d\ub2b6\ud31b\u585d\uad90\u74d5", "\ud9ed\udcff\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c",
        5, 40629, -2023818154, 5250889500649599092L, -46501L, false, false, (char) 48981, (char) 54746,
        Double.longBitsToDouble(0x3fef25ae9a7567c7L), Double.longBitsToDouble(0x3fca77b91fa62450L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 9, 10, 7, "\udb1a\udfea\udafa\udf1a\ud86f\udd91", "\u59a2\u6ff2", "\u73d4",
        22, 10117, 1290519755, -3774617789657186526L, 18585L, false, true, (char) 27634, (char) 63950,
        Double.longBitsToDouble(0x3fe08081e4450c1aL), Double.longBitsToDouble(0x3fe5052602eba0d0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 12, 2, 7, "\udb3f\udf3f\ud876\ude41\ud86f\udd91\u3e5c\ud8d2\udf54\uda68\ude4d\ud93f\udcd2\ud845\udde3\u2c8e\u73b5\ua036\uda64\ude18\ud9c4\udd53\udaba\udc77\udbf1\ude79\ud999\udc3b\ud8cf\udf4f\ud80c\udd49\uda62\udc60\uda73\udf04\ud86b\udde0\ud949\udee4\ud827\udfbf", "\u0c64\ubf44\u1ee3\ud241\ua84f\u2454\u99f4\u513e\ucad0\u10f2", "\udadd\udcef\uda8b\uddc2\ud9c4\udfab",
        41, 85638, 1265764003, 8239943647280282708L, -97924L, true, false, (char) 8860, (char) 55549,
        Double.longBitsToDouble(0x3fe8670e367607b7L), Double.longBitsToDouble(0x3fe656840445b244L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 7, 11, "\ud8b6\uddcb\udbfd\udce4\udade\udf68\udaaa\udfa0\ud8cc\udeb2\ud809\udcc8\ud9cf\udee1\ud976\udeda\uda0e\uddd9\ud8a1\udecd", "\u742e\u2f08\uc037\u3cc0\ua058", "\udbc1\ude8b\uda4a\udec6\ud949\udee4\ud9bf\udde1\udb2d\udd6b\ud9cc\udfd7",
        15, 76560, -2094883749, 2914908262653077557L, -30473L, false, true, (char) 50912, (char) 9131,
        Double.longBitsToDouble(0x3fd4097df5328cfaL), Double.longBitsToDouble(0x3fe65e22c1b90b3fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 0, "", "\u9904\u26f5\u7d48\000\u6f8b\u009e\000\u5f0e\u66aa\ub9d4\uaff5\u2f08\u3ad3\u46d2\u82d3\ucda7\u7ffe\u20d5\u4068\ua81e\u765c\u7542\u525d", "\uac02\000\000",
        43, 11495, -241861156, -4041183199259305024L, -97287L, true, false, (char) 32476, (char) 34352,
        Double.longBitsToDouble(0x3fb594ee81743af0L), Double.longBitsToDouble(0x3fbd123788b98860L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.io.File:\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8c5\udf41\udadb\udd89\udade\uddaa\ud8ec\udfb2\ud965\udef5\udbbb\udda3\ua01e\uda64\uddd4\ud9c4\udd53\udaca\ude07\udbf1\ude79\ud999\udc3b\0121=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 5, 8, 1, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8c5\udf41\udadb\udd89\udade\uddaa\ud8ec\udfb2\ud965\udef5\udbbb\udda3\ua01e\uda64\uddd4\ud9c4\udd53\udaca\ude07\udbf1\ude79\ud999\udc3b", "\ubb89", "\ud949\udee4",
        40, 5555, -2047884381, 634587482573868259L, -90175L, true, true, (char) 39042, (char) 17754,
        Double.longBitsToDouble(0x3fddccebdaede32aL), Double.longBitsToDouble(0x3fe0870756c7bb90L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 0, "\udbb9\udf8d", "\u26a1", "g",
        36, 59947, 0, 0L, -100000L, false, false, (char) 23898, (char) 57643,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 2, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\udb1e\ude5b\ud8cc\udf51\ud809\udcc8", "\u1804", "\uda64\uddd4\ud9c4\udd53\udbbd\ude21\ud9b9\udeb8\ud89a\udceb\udb2c\udd3b\uda89\udd70\ud97e\udc66\udbc1\ude8b\uda4a\udec6\ud9b1\udd98\udada\ude38\udb2d\udcfd\ud9cc\udfd7\udb6a\ude78\ud819\udcd5\ud8af\udcff\ud8fc\udc01\ud80f\udda7\uda5b\udd56\ud83d\udef1\ud901\udfdd\udb98\ude66\ud811\udd9d\udae7\udd63",
        26, 93891, -1091370595, 5916260124604882065L, 45290L, true, true, (char) 34545, (char) 48096,
        Double.longBitsToDouble(0x3fe2b9daaf118febL), Double.longBitsToDouble(0x3fe89dae9fe9a402L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ufb13\ud971\udfce\u73d4\ud839\uddff\udb80\udf61\012",
        Z.run(T, 1, 0, 7, 4, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ufb13\ud971\udfce\u73d4\ud839\uddff\udb80\udf61", "\u76cc\u0c04\u4e94\ucdc8\u7ffe\u20d5\u4068", "\ud998\udedf\ufe38\uda49\udec2\ud819\udcd5\ud8af\udcff\ud8fc\udc01\udb0f\ude3f\ud8d0\udc53\udbb3\udfa5\ud9d7\udf05\udb0c\ude55\ud9e4\udfa6",
        56, 45921, 2101298891, -4687401011936311491L, -28366L, false, false, (char) 23075, (char) 34236,
        Double.longBitsToDouble(0x3fda5113ccae776cL), Double.longBitsToDouble(0x3fe88c7f5b13b5d3L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 3, 1, 8, "\udbb9\udf8d\udb9f\udc8f", "\uaeb0\u20de\u404e\u3869\u1804\u408c\u0561\u8b12\u98fe\u2f08\u8d3c", "\udb46\uddc5\ud991\udde0\uda71\udc9f\udbfa\udf99\udb1e\ude08\ud9d9\udf84\udb2d\udd6b\udb0e\udfcf\udb6a\ude78\ud819\udcd5\ud8af\udcff\uda70\udc01",
        54, 27400, -1247806120, -6336802054835219149L, 29482L, true, false, (char) 13545, (char) 44446,
        Double.longBitsToDouble(0x3fd409b2d90ac89eL), Double.longBitsToDouble(0x3fe8b8f57d10cce3L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 4, "\014\000", "\u6cce", "\ud93f\udc7e",
        37, 11904, 2002866477, 362554770194919492L, 56831L, false, false, (char) 20328, (char) 62324,
        Double.longBitsToDouble(0x3fa9560004d22f90L), Double.longBitsToDouble(0x3eba800000000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 10, 10, 4, "\ud8b8\udcbe\udb9f\udc00", "\ub493\u2220\u1660\u426e\u1804\u408c\u66aa\ud295", "\uda67\udf70\udb69\udd5a\uda5e\udff8\udb5f\udd23",
        34, 43338, 830052375, 6802314818405452426L, -14295L, true, false, (char) 22721, (char) 53415,
        Double.longBitsToDouble(0x3fc01a94fe5cd70cL), Double.longBitsToDouble(0x3fe6e675e9f49b3fL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 0, "\udbb9\udf8d", "\000\000\000\000\000", "",
        -5, -1000, 0, 2090629516L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e0348be40000000L), Double.longBitsToDouble(0x3eba975800000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 4, 2, 6, "\uda77\udf8c\udb9f\udc8f\ud86f\udd91\ud9a0\uddcd\ud8cc\udf51\udaf0\udf1c\ud89f\udd84", "\u408c", "\ud966\udcc9\udaca\ude07\udbd0\udce3\ud8f7\udda9\ud86c\udf27\uda17\udfa0\udad6\uddea\udafd\udd7a\ud9eb\udc33\udb1e\ude08\ud9d9\udf84\udb2d\udd6b\ud94f\udc84\u2b81\ud9bb\ude1c\ud8af\udcff\udbf9\udce0\udab8\udc82\udb92\udcc7\udb35\udc7b\ud91f\ude52\ud936\udf6c\uda90\uddcb\udbba\uddb1\uda86\udceb\udaa1\udee7\uda6e\ude1c\udac1\ude36\ud96b\uddb8\uda67\ude04\ud954\udf08\ud958\udf17\udb45\udcdb\ud82d\uddfa\ud8e9\udcc8\udbac\udef8\udb37\udc65\udabf\udfe6\ud87b\udcd9\udaed\udc97\udb34\uddc6\u772b\ud828\uddcf\ud95b\udc1b\udb3d\udfd9\ud90b\udd11\uda87\ude98\ud8e3\udf8d\ud9a0\udf0a\udaf7\udd31\udb42\ude2b\ud8f5\udeda\udb62\udc24\ud90e\udd38\ud8e7\uddf0\udad6\udeb1\ud810\udffc\udbe2\udce1\ub100\ud91b\udd50\ud99c\udde6\ud823\udde5\ud8a0\udd99\uda60\udd6a\udaff\udf4c\ud841\udd39\ud934\udc62\uda33\udc46\ud807\udd6d\uda31\udf5d",
        51, 50773, -730542304, 8120823977604648948L, -94923L, false, true, (char) 56945, (char) 61414,
        Double.longBitsToDouble(0x3fe444506e5acf17L), Double.longBitsToDouble(0x3fd43f69860e4c60L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\ud8cc\udf51",
        -5, -1000, 0, 666107904L, -100000L, false, false, (char) 30, (char) 17549,
        Double.longBitsToDouble(0x3f3f272000000000L), Double.longBitsToDouble(0x3fc9c01ac344065cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 1, 7, "\udbb9\udf8d\udb9f\udc8f", "\u7d48\u4e2e\u404e\u3869\u1804\u408c\u66aa\u839b", "\uda90\udf24\uda18\udc3f\ud874\ude5e\u88e6",
        49, 8577, 1537212691, 2119709041755659851L, 79329L, true, false, (char) 22721, (char) 53415,
        Double.longBitsToDouble(0x3fc01a94fe5cd70cL), Double.longBitsToDouble(0x3fe6e675ed0d9b3fL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 4, "\000", "", "",
        -2, 64122, 0, 0L, -96507L, false, false, (char) 0, (char) 17549,
        Double.longBitsToDouble(0x3fdf57c9c93e7db6L), Double.longBitsToDouble(0x3fc9cddad744065cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 1, 10, "\udbb9\udf8d\udb34\udfcb\ud86f\udca7\u3e5c\ud913\udd68\ud809\udcc8\ud93f\udcd2\ue69e\ud936\uddbb\u73d4", "\uaff5\uac5d\u75ae\u46d2\u82d3\ucda7\u7ffe\u903d\u4068\ua7f7\u97cf\u7457\u525d\u0c64\ud31b\u585d\u009f\000", "\ud9ed\udd02",
        45, 26336, 1187739968, 6849423737624676043L, -19933L, false, false, (char) 28556, (char) 37335,
        Double.longBitsToDouble(0x3fd17310c6000000L), Double.longBitsToDouble(0x3fda5113ccae776cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 0, 7, 6, "\udba6\udf19\udbbd\udc8f\udac9\udd1e\udbcb\udd1e\ud823\udf2f\udab0\udf4c\ud817\udcde\ud93d\udf60\ud953\ude7f\ud84e\udd51", "\u8e14\u34dd\u88e4\u46d2\u82d3\u9491\u7ffe\u20d5\u1bf7\u81e3\u1c47\u95dbF\u3e41\u32d0\u585d\u1133\u74d5", "\ud9ed\udd02\udb98\uddfc",
        10, 25512, -271844473, 6861286999490936477L, 3717L, false, true, (char) 50438, (char) 37556,
        Double.longBitsToDouble(0x3feb1392d135baf7L), Double.longBitsToDouble(0x3fb208adad6de470L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 11, 8, 7, "\uda46\udd53\ud875\udf88\ud886\udd5a\ud9a7\udf7e\udace\uddae\udbe0\udde2\ud943\udd2b\ud976\udf1c", "\u66aa\ub9d4\u6e8d\uc208\u2f2a\u46d2\u6f81\u3bd8\u98ff\ube67\u4068\u75c0\u7664\u32d6", "\ud819\udcd5\ud8af\udcff\ud997\udefc\ud80f\udda7\ud8c9\udf32\ud97d\udc7e\ud999\udf89\udb58\udea6\ud8bb\ude36\ud836\udc8a\ud869\udcdb\uda17\ude2c\u5607\u56bf\udb8e\udf36\ud858\udd61\ud8c3\udeeb\udbe9\udd65\ud80f\udc30\udaeb\udc5a\ud8fb\udd8a\ud921\udf55\ud9dd\udf61\ud97e\ude9e\ud9f4\ude89\udb3e\udf9a\ud841\udf6e\ud924\ude9e\ud870\udd96\uda37\udd4c\ud9ec\udf11\udb97\ude21\udb48\uddfd\udacc\udce1\ud84a\udc15\u7e2c\udac1\udd33\ud921\udc2f\udb45\uddbd\udbe8\udfc9\ud857\udcca",
        35, 28910, 1938189937, 6622287758670588253L, 47461L, true, false, (char) 55836, (char) 10871,
        Double.longBitsToDouble(0x3fbbf1c4e29e3190L), Double.longBitsToDouble(0x3fed486c780aa4daL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.io.File:\ud926\udff0\udafa\udf1a\udb32\udf4c\u3ee5\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 11, 2, "\ud926\udff0\udafa\udf1a\udb32\udf4c\u3ee5", "\u3718\u38fe\u0812\ub3ef\u66aa", "\uda12\udefd\udbf1\ude79\ud94e\ude13\udae5\ude72\uda89\udd4f\udb89\udd53\uda5f\udd82\ud8d9\udec6\ud949\udee4\ud98b\udef1\ud8f4\udfe4\ud8e2\udd2a\udbdb\udd4d\ud9ab\udd63",
        -4, 50960, 1445955641, -5591369215971394332L, -74620L, false, false, (char) 54235, (char) 20662,
        Double.longBitsToDouble(0x3fe6b9baa12a9aa0L), Double.longBitsToDouble(0x3fdcc54ee761babcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\ud81b\udd56\0121=java.lang.String:\ud81b\udd56\012",
        Z.run(T, 2, 0, 0, 1, "\ud81b\udd56", "\u26f5\u0f08\u09d9\ub07e\u4256", "\ua01e\uda64\uddd4\ud9c4\udd53\udaca\ude07\udbc6\ude34\ud999\udc3b",
        14, 69902, -1677602291, 1169912905879679504L, -75072L, false, false, (char) 20508, (char) 2019,
        Double.longBitsToDouble(0x3fcc6119d16c16e4L), Double.longBitsToDouble(0x3fd9f832210bcb5eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 10, 10, 0, "\udbb9\udf8d", "\u26a1", "g",
        36, 23997, 0, 0L, -34464L, false, false, (char) 23898, (char) 57760,
        Double.longBitsToDouble(0x3e04fbe080000000L), Double.longBitsToDouble(0x3fdec63d33a85e40L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 7, 7, 6, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\u3e5c\ud8cc\udf51\ud809\udcc8\ud93f\udcd2\ud976\udf1c\uda61\udf46\uda24\udc96", "\uaff5\u2f08\u3ad3\u46d2\u82d3\ucda7\u7ffe\u20d5\u4068\ua81e\u765c\u7542\u0b62\u5b45\ud31b\u585d\uad90\u74d5", "\ud9ed\udd02\udb98\uddfc\ud811\udd9d\u8e91\u1056\uda17\ude2c",
        27, 40629, -2023818154, 5250889498114363301L, 74289L, true, false, (char) 17700, (char) 3849,
        Double.longBitsToDouble(0x3fef25ae9a7567c7L), Double.longBitsToDouble(0x3fca77b91fa62450L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 3, 0, "\udbb9\udf8d\udbbd\udc8f\ud86f\udd91\udb4e\ude3a\udb68\ude7f\udb61\uddb9\uda66\udf78\uda07\udf66\ud903\udc1d\u73b0\ua036\uda64\uddd4\ud8a0\ude81\udaca\ude07\udbf1\ude79\ud999\udc3b\udae5\ude72\uda89\udd4f\ud941\udfaf\ud931\udefc\u982c\ud949\udee4\ud9d9\udfd9\ud8a9\udd4a\ud9a6\ude7f\uda94\ude1e\ud800\udfd5\ud892\udd09\ud8fb\udf75\ud80f\udda7\ud9b7\ude48\udbd1\ude3e\uda92\udfa9\udb98\uddfc\ud811\udd9d\ue56c\udbf9\udf14\uda17\ude2c\uda55\uddc7\ud893\udc2c\ud847\udd3a\ud953\udc79\ud9b8\udd8e\ud887\udfc1\u3466", "\u331f\ucd06\u23fa\u07e1\u3e32\u71ae\ud51d\uc300\ua562\u4a85\u072e\u247c\u1c67\u814c\u75d0\ua3ec\uc1fc\u5f08\u9925\u10d3\u17a5\ubfca\u695c\u2a93\u5565\u177f", "\ud989\udcb8\uda42\udc5f\udb5c\uddfa\ud96e\udf31\ud891\udd13\ud8ac\udf67\ud943\uddcd\udac2\udd39\ud85d\udc4d\ud9a7\udeab\udb5f\udfc8\ud832\ude44\udb7c\udc13\uda4e\ude56\udb68\udd08\udacd\udf9a\uda4c\udd76\udb48\udd86\ud886\ude86\uda44\udded\udb71\udcd4\ud969\udc28\uda3c\udda1\udbe1\udeb7\udb64\udd8f\ud86b\udf06\udb97\udde9\ud8af\ude9d\udb19\udfec\ud9fe\udd62\ud94a\udf6f\uda08\udfad\udbac\udd70\ud83c\ude52\ud979\udc19\ud8da\udd2a\udbe0\ude6c\udb48\udf8f\ud9c6\udcd1\ud99b\udf32\udbd4\udf8f\ud935\udf3f\ud8fd\udc90\ubbf7\ud979\ude2a\ud807\uddf2\ua3ee\ud997\udd8c\ud90b\udf2b\uda32\udd5e\uda6a\udf3e\ud92a\udc20\ud960\udcaf\ud9e9\udc5e\ud9d0\udcb4\udb9b\udfcd\ud925\uddb9\udb4b\udcaf\ud947\ude80\uda34\udeef\ud847\udda3\ud8a8\udeaa\u84a6\udb92\udee8\uba19",
        52, 14476, 1223439633, -6935734329681019554L, 39663L, true, false, (char) 19298, (char) 56926,
        Double.longBitsToDouble(0x3fe7917e65a8f3ffL), Double.longBitsToDouble(0x3fe04b0dfc8efe75L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "M|org.apache.commons.cli.TypeHandler|openFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createClass|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createDate|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFiles|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createObject|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createURL|java.lang.String|static",
    "C|org.apache.commons.cli.TypeHandler|<init>|",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "M|org.apache.commons.cli.TypeHandler|openFile|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
