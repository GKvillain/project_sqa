package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u08ff\u3dee\ub6f4\u93b9\u91e3\uab97", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\ud998\ude0d\ud8f0\udce6",
        -3, 11708, -103619133, 385080416023467249L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 0, 8, "\ud9cc\udcb8", "\ud730\u47b0\u5cc3\u2e53\ub6f4\u93b9\u91e3\u8394", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\ud998\ude0d\ud8f0\udce6",
        -3, 99548, -1046506586, 385164623152272625L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u08ff\u3dee\u0530\u3d77\u7e59\u8596", "\ud901\udeec",
        21, 64602, -719022956, 5212327930706273528L, 89891L, true, false, (char) 55880, (char) 32538,
        Double.longBitsToDouble(0x3fe4b5758fad451aL), Double.longBitsToDouble(0x3fc106f07b842534L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 4, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u08ff\u3dee\ub6f4\u93b9\u91e3\uab97", "\ud95b\udf94\ud88b\udf00\udbb6\udd3f\ud998\ude23\udb88\udd27",
        34, 86378, -103619133, 385080416023467249L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fdc96275b18a626L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 0, 0, "\000", "\ud68f\u4498\u08ff\u3dee\000\u8646\000\000", "\ud95b\udf94",
        9, -1000, -719022956, 5212244367644819456L, -100000L, true, false, (char) 55880, (char) 15934,
        Double.longBitsToDouble(0x3fe4b5758800001aL), Double.longBitsToDouble(0x3fe978000599cd5eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 12, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u3220\u3dee\ub6f4\u93b9\u6ac7\ube54", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\udbd9\udd51\ud9e9\udf8c",
        -3, 11708, -1127029309, 417651751487171434L, 21194L, true, true, (char) 50772, (char) 49219,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eb8c0e4d0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 12, 8, "\ud841\udd7b", "\u37d9", "\ud9e0\udc41\udbb6\ude9d\udb77\udceb\ud906\ude85",
        1, 60197, -1465057411, -8090779142578023817L, -60840L, false, true, (char) 4055, (char) 3692,
        Double.longBitsToDouble(0x3fce20ab1cd47c24L), Double.longBitsToDouble(0x3fe4b5758fad451aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 6, 5, 9, "\ud9b9\uddb8", "\u613d\ucdac\u45eb\u3e90", "\uda18\udea4\uda71\udf38\uda36\udf69\udabb\udc9e\ud95b\udf94\udbeb\udc02\ud875\udd8c\ud813\udd0b\ud9cc\udcc5\udb2e\ude98\udac6\ude75\ud910\udea3\ud894\udfb4\ud9a9\udebe\ud933\udccd\uda1b\udfe1\udb86\udc00\ud9f7\udd01",
        1, 41839, 611700054, 4168805135994433183L, -88316L, false, false, (char) 8290, (char) 9860,
        Double.longBitsToDouble(0x3fe63e6a039a3aceL), Double.longBitsToDouble(0x3fe373f57e2b5455L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 0, 8, "\ud9b9\uddb8", "\ud6ae", "\ud9e0\udc7d\udbb6\ude9d\udb77\udceb\udafe\udf77\ud8ce\udf99\udab4\udede\ud9f5\udc66\ud95b\udf81",
        18, 64560, -719022956, 5212244367822592248L, 89891L, true, false, (char) 55880, (char) 325,
        Double.longBitsToDouble(0x3f9c194a204621a0L), Double.longBitsToDouble(0x3fe97ddde599cd5eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 11, 3, 8, "\ud9b9\uddb8", "\ud730\u4498\u08ff\u3dee\ub6f4\u93b9\u91e3\uab97", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\ud998\ude0d\ud8f0\udce6",
        -3, 27920, -103619133, 385080416023467249L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 6, 6, 0, "\ud951\udef2\ud96c\udd14\ud97a\udf2a\ud88f\ude86\uf805\udba1\udeb1\ud9a2\ude42\udbb6\udee5\ud887\ude55\uda98\ude32\uf91d\u01b9\udaab\udcbc\ud971\udeb8\udbeb\udc02\ud96d\udd88\udaf7\udf69\ud903\udf4b\udb66\udd97\udb66\udd8e\udab8\udea2\ud8c3\udfb1\ud8df\udec5\ud932\ude6a\ud9f0\udea8", "\u564d\u97df\u3ad6\ua895\u9c92\u6316\u62ba\u50c2\u1ba2\u6097\u01f4\u4ff5\u4381\u1d2a\u8bad\u83e2\u27f6\ub4d9\ua70c\u902f\u3b2e", "\u3396",
        34, 47775, 1059319626, -8981429096679298512L, 61790L, true, true, (char) 50340, (char) 25527,
        Double.longBitsToDouble(0x3fe99a8a10d7dc48L), Double.longBitsToDouble(0x3fe359c6aa2c566dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 8, 6, "\ud9b9\uddb8", "\u1cd1\u44e7\u08ff\u3dee\ub6f4\u93b9\u91e3\uab97", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\ud998\ude0d\ud8f0\udce6",
        -3, 11708, -103619133, 378606491559122161L, 40950L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 8, 9, "\ud9b9\uddb8", "\u84e9\u6bc6\u4b77\u5026\ub6f4\u0627\u6000\ua6a4", "\ud95b\udf7f\udb4f\udf44",
        8, 79240, 1895734500, 763527602615140116L, -36991L, false, true, (char) 34021, (char) 29077,
        Double.longBitsToDouble(0x3fd974e78f02cb68L), Double.longBitsToDouble(0x3fde65939fb44a6aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 9, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u235e\u451c\ub6f4\u93b9\u91e3\uab97", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\ud998\ude0d\ud8f0\udce6",
        -3, 11708, -103619133, 385080416023467249L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 3, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u08ff\u3dee\u3731\u0152\uc49d\uab97", "\ud95b\udf94\udbeb\udc02\ud963\udee3\udb60\udd95\ud8f0\udce6\udb66\udd97\udb66\udd8e\udb3f\udd65\uda67\udce9\ud8df\udec5\ud932\ude6a\uda1d\ude43\ud873\udf29\ud9f3\udcc8\udbc5\udc53\ud984\uddf7\ud990\udfad\ud8c1\ude30\ud928\udffd\udbb0\udcd3\udbe3\ude38\udb87\ude1c\udbae\udde9",
        4, 41682, 391950306, 8818531235281704980L, 78107L, true, false, (char) 64200, (char) 62356,
        Double.longBitsToDouble(0x3fe8f65f9a1a4726L), Double.longBitsToDouble(0x3fcfac198cee2ebcL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 0, 0, "\udb8f\udfe4", "\ud730\u4498\ub8fe\u3dee\ub6f4\u93b9\u081c\u89ea", "\ud95b\udf94\uda82\udfdd\ud96f\uddda\ud998\ude0d\ud8f0\udce6\ud90e\udeab\uf08b\udb3f\udca7\uda67\udce9\ud8df\udec5\udbdf\udc5f\ud9fc\udfed\ud981\udc9b\udac6\udef0\udbd6\udd36\ud9a3\udf45\udafa\udd6f\uda7f\ude99\uda5f\udce8\uda23\udc2f\ud8db\udde1\ud813\udd41\uda67\udd31\udb6e\udc82\ud824\udddc\udadd\udc25\udb6e\udf18\ud8b5\udd5e\ud990\udc2b\udbaa\ude4e\ud9c5\udeb4\ud8ae\udd18\ud9bf\udc59\udae5\udeaf\ud9ce\udefa\udaa6\ude7d",
        51, 76947, -693430186, -4990040458201093946L, 97178L, true, false, (char) 37880, (char) 61870,
        Double.longBitsToDouble(0x3fe611c03f941ac1L), Double.longBitsToDouble(0x3fe9574460d720fbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 11, 0, 8, "\udb5b\udea9", "\ud730\u4498\uc66c\u3da3\ub6f4\u62eb\u92b8\uab97", "\ud95b\udf94\udbeb\udc02\udb4c\udf17\ud900\udfc7\ud8f0\udce6",
        -3, 11708, -103619133, 385080416023467249L, -13622L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 2, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u08ff\u3dee\ub6f4\u93b9\u91e3\uab97", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\ud998\ude0d\ud8f0\udce6",
        -3, 11708, -103619133, 385080416023467249L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 0, 10, "\ud9b9\uddb8\ud96c\udd14\u662e\ud88f\ude86\uf805", "\ub6f4\u93b9\u91e3\uab97\u0bf6\ubd02\ub7c2\u0db8\u119e\u81c8\u2a5e\ud586\uc8f3\u0e71", "\ud818\udf00\ud9f0\udea8\ud9ee\udef2\ud877\udc33",
        43, 7824, 1651887584, 4122065557801971359L, 518L, false, true, (char) 1277, (char) 46733,
        Double.longBitsToDouble(0x3fdd761c450e8da8L), Double.longBitsToDouble(0x3fcab1d90d1656acL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.io.File:\ud9b9\uddb8\012",
        Z.run(T, 1, 5, 3, 2, "\ud9b9\uddb8", "\ud730\u2624\u7e59\u3dee\ub6f4\u93b9\u91e3\ub22a", "\ud95b\udf8c\udbeb\udc02\ud96d\udd88\ud998\ude0d\u00ef",
        -3, 11708, -103619133, 385080416023148273L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 12, 1, 0, "\ud9b9\uddb8", "\uce8f", "",
        -5, -1000, 0, 1999115549638806217L, -99875L, true, true, (char) 12515, (char) 16424,
        Double.longBitsToDouble(0x3fc29ead628f5490L), Double.longBitsToDouble(0x3fcf090abc502a60L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\ud9b9\uddb8\012",
        Z.run(T, 1, 0, 4, 8, "\ud9b9\uddb8", "\u35f5\u0593\ua2dc", "\udb77\udceb\uda18\udea4\uda8c\udf35\ud92e\uddb2\udab3\udcb3\udb46\udf45\ud8bf\ude59\udbb3\udc8b\ud9a3\udd64",
        56, 11792, 706002708, -445040787385215847L, -26475L, false, false, (char) 60057, (char) 61105,
        Double.longBitsToDouble(0x3fbd3417b8c106f0L), Double.longBitsToDouble(0x3fde4893b8b2c4eaL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 0, 8, "\udb36\udd42\ud94b\udd29\u662e\ud8b4\udd86\udb28\ude2c\ud909\udeb0", "\u93b9\u91e3\u49a8\ua36d\ubd02\u35e8\u5d9f\u085c\ua259\u0348\ubb55\uc8f3\u3911\u7484\u61ba\u0ed7\u687c\u02f3\u3c71\uad9d\u9dcb\u11fb\ua895\u2540\uaa7c\u320d\u4c74\u7cbb\u7566\u0483\u124f\u4aa9\ub0ff\u81c6\u670c\u1f54\u806e\u983c\u9861\uaa7d\ua9c6\u6073\ua3c9\u1b18\u5bf4\u6fff\ub718", "\ud8ba\udd85\udb49\ude77\uda6b\udeba\ud82c\udcb0\udb47\udd67\ud98c\ude78\ud89a\udd25\udbb1\udd00\udbaf\udd63\uda90\udc16\uda4e\udf62",
        2, 47297, -597605061, 45336580824805342L, -17660L, false, true, (char) 59705, (char) 48331,
        Double.longBitsToDouble(0x3fd299814cdbfc66L), Double.longBitsToDouble(0x3faaffe577212360L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 2, 7, 0, 8, "\ud9b9\uddf3", "\u1f2c\u4549\u085d\u3dee\ub6f4\u7881\uabda\uae0d\u42d5", "\ud5d0\ud952\udf87\ud9d7\udf16",
        56, 56208, 706002708, -457876262789573479L, 72572L, false, true, (char) 55271, (char) 61105,
        Double.longBitsToDouble(0x3fd99cd5ec41f3b0L), Double.longBitsToDouble(0x3fde05939e94c4eaL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 4, 8, "\ud9b9\uddb8", "\u380c\u4498\u08ff\u95a2", "\uda8c\udd24\ud918\udc2c\ud9e5\udf2e\udbc7\udef1\udb78\udc3f\ud88e\udddf\ud919\udd7e\ud8d0\udc64\udb0b\udf8f\uda96\udeb0\ud939\udfa8\ud8dd\ude19\ud973\udcbd\ud8df\uddec\udb7f\ude10\ud986\udf17\ud9ee\udef2\uda19\udd24\ud90b\udcb9\uda12\udd0b\ud990\udfad\u8028\udb25\udde0\ud8ae\udd9b",
        49, 11659, 1541722259, -7491556758320045444L, -84482L, true, true, (char) 57629, (char) 32182,
        Double.longBitsToDouble(0x3fd8048750da2334L), Double.longBitsToDouble(0x3fea8cd61751bbb5L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 8, "\ud952\udca3", "\ud730\u4498\u08ff\u3dee\u8a37\u8a43\u5517\uab97", "\ud94e\ude91\udbeb\udc02\ud835\udc8c\ud977\uddad\ud8f0\udce6",
        -3, 23420, -101275034, 385080416023467249L, 21194L, true, true, (char) 65201, (char) 36310,
        Double.longBitsToDouble(0x3fdce883fbc0b29aL), Double.longBitsToDouble(0x3fc926bc5a7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 0, 2, 0, "\ud9b9\uddb8", "\ud6cb\u4498\u08ff\u3dee\ub6f4\u93b9\u91e3\uab97", "\udab2\udd92\udad7\uddd7\udaef\udf82\ud998\ude0d\ud8f1\udce6",
        10, 1106, -838896386, 385197698695419121L, 21194L, true, true, (char) 61105, (char) 2808,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eba7ce4d0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 3, 8, "\uda3e\udfea", "\u02c7\u2a2e\u97e4\u3db6\ub6f7\u93b9\u1e0a\u1e79", "\ud95b\udf94\udafe\udeab\udaee\udc38\ud998\ude0d\ud806\udef1",
        10, 11859, 954546115, 385080416052397578L, -31352L, false, false, (char) 54401, (char) 53011,
        Double.longBitsToDouble(0x3fe4cc581a432319L), Double.longBitsToDouble(0x3fe5b1170e1175dfL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 0, "", "\u9384", "\uaac1",
        9, -924, 1813968128, 1027284107007986453L, -67619L, false, false, (char) 2458, (char) 17520,
        Double.longBitsToDouble(0x3fc29ead60000000L), Double.longBitsToDouble(0x3d55300000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u3220\ub5ed\u720a\u4d5b\ud1c7\ube54", "\ud85c\udce9\udbeb\udc02\ud96d\udd88",
        49, 9723, -1475285003, -7352009505274441989L, -36227L, true, true, (char) 7314, (char) 9117,
        Double.longBitsToDouble(0x3fec4c1dff7df0c6L), Double.longBitsToDouble(0x3fcb9f3b0d585d58L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u3220\u3dee\ub6f4\u93b9\u6ac7\ube54", "\ud95b\udf94\udbeb\udc02\ud96d\udd88\udbd9\udd51\ud9e9\udf8c",
        -3, 11708, -1127029309, 417651751487171434L, 21194L, true, true, (char) 50772, (char) 49219,
        Double.longBitsToDouble(0x3fe107cec5e05939L), Double.longBitsToDouble(0x3fc92c4eb8c0e4d0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 0, 12, "\ud9b9\uddee\ud96c\udd14\u662e\ud88f\ude86\uf805", "\ub6f4\u93b9\u6ac7\ube54\u0c0d\ubd02\u89c1\u68ae\ud69d\u3911\u697b\ud586\uc8f3\u1d4c\u82ec\u4068\ua6f3\u687c\u325b\u4e3a\u1032\ub6af\u617f\ua895\u3cb6\ub002\u9aa1\uad0c\ud73d\u4bd3\ubb4e\u09b9\u8fa2\u2241\u2bed\u6ef7\u9cb8\u6ec3\u4999\uc55d\u012b\ua483\u4eb8\ua95a\ub02a\u23df\u103b", "\udab7\udd3e\udbcf\udef2\uda21\udc73\udb56\ude32\uda5a\udef5\udb0f\udd4c\ud861\udc05\ud94a\udf6a\udaf5\udfce\ud805\udcb4",
        31, 21552, -788576780, -3857186839889911325L, 63182L, true, false, (char) 10994, (char) 62597,
        Double.longBitsToDouble(0x3fd89ee4c9b6e05cL), Double.longBitsToDouble(0x3fc5f864be383b3cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 6, 8, 11, "\ud9b9\ude3b\ud96c\udd14\u662e\ud93e\udc7e\ud90a\ude36\udaa5\udebe\udb2d\udfc8\uc046\uc824\udac1\udd78\ud8c7\udeb2\ud9e5\udf45\udb39\udda9\ud8a5\udd8e\udb2a\udccf\ud952\udc88\udbd9\udd51\ud9e9\udf8c\udae5\udc16\udbd1\ude86\udba0\udd5f\ud9aa\ude65\udb89\udd40\ud899\udcc3\uda17\udd83\udb9a\ude88\ud91b\udcec\ud87b\udf20\ud81c\udf62\ud990\udfad\ud992\udfc8\udb0a\udd5a\ud83d\uddf9\ud85b\udc1e\udbb8\udc95\uda6c\udd9b\ud8c9\uddb6", "\uc3d8\u0d18\u5f7a\ucc79\uabfd\u1d8e\u1108\u8496\u3eea", "\ud9fa\udc89\uda5d\ude39\udbbe\udcc4\uda17\udf79\ud871\udd4e\ud989\udd1d\ud92b\udfba\udbeb\udc99\ud850\udd1a\ud8ec\udf30\ud91a\ude3f\udb46\udfa3\udaae\udc08\u96df\udb09\udc89\udbd2\uddf7\ud840\udd91\ud926\udc95\udad9\udd0d\ud9c5\udfe8\ud94e\udee8\ud8c6\udde0\udb75\udfad\udab7\udde9\ud8b5\udd42\ud8f0\udef7\udacc\udf18",
        11, 55381, 15144567, -4424946222074701983L, -88073L, false, false, (char) 16313, (char) 14200,
        Double.longBitsToDouble(0x3feeb137d3ceda48L), Double.longBitsToDouble(0x3fcb41b6ea212ffcL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 8, "\ud841\udd7b", "\u37d9", "\ud9e0\udc41\udbb6\ude9d\udb77\udceb\ud906\ude85",
        1, 60197, -1465057510, -8090779142578023817L, -60840L, false, true, (char) 4055, (char) 23539,
        Double.longBitsToDouble(0x3fe74ccac7351a57L), Double.longBitsToDouble(0x3fe4b5758fad451aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.io.File:\ud841\udd7b\0121=java.lang.String:\ud841\udd7b\012",
        Z.run(T, 2, 5, 0, 8, "\ud841\udd7b", "\uc6d7", "\uda0e\ude6e\udbb6\udf49\udb77\udceb\ud906\ude85\ud8ef\udd1c\ud9e5\udf2e\ua252\ud09f",
        28, 97072, -719022956, 5212244367822592248L, -61061L, true, true, (char) 55880, (char) 15166,
        Double.longBitsToDouble(0x3feddfc05fad4540L), Double.longBitsToDouble(0x3fed309e5348650eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 2, 10, 10, 8, "\ud827\ude11\udba7\udc97\udb20\udc8d\ud86b\udc59\udaf3\udf90\ud83c\ude1c\ud9e0\udc41\udbb6\ude9d\ud96a\udf26\ud906\ude30\ud8ef\udd1c\ud9e5\udf2e\uda34\ude57\ud09f", "\u2bf3\u7c10\ud586\uc8f3\u0e71\u62ee\u803f\u158a\u52f5\uc8e9", "\ud945\udf24\uda6d\udc4c\u7795\udacc\udeb4\ud852\udf11\ud923\udce5\udbb8\udcb0\ud862\udfaf\ud8b6\ude1c\udaac\udea6",
        56, 48307, -1627054373, 4106182624748947382L, -48590L, true, true, (char) 31710, (char) 62431,
        Double.longBitsToDouble(0x3fde54252de7a66cL), Double.longBitsToDouble(0x3fddcbddbb1d62c2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 1, 8, "\udbc8\ude84", "", "",
        56, -1000, 6178816, 9079256848778919938L, -99902L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 8, 2, 12, "\uda3b\udc50\ud88d\udd24\udbec\udd0c\ud812\ude59\ud82e\udd6c\ud908\uddb0\ud9e0\udc7d\udbb6\ude9d\udb91\udeec\ud972\ude95\ud8ce\udf99\udab4\udede\ud833\udca2\ud95b\udf75\ud942\udd9c\uda82\udcd2\ud998\ude0d\ud8f0\udce6\udb66\udd97\udb66\uddc7\udba7\ude99\ud967\ude89\ud8df\udec5\uda34\udfb9\ud807\udf00\ud837\udcfc\ud875\uddc7\uda54\ude76\udb55\udc6c\ud9d2\udc0a\uda93\udcc3\uda13\udd67\ud892\udcf0\ud8b6\udec7\ud8bf\udc93\udb95\ude11\uda8a\udf21\ud8b7\udf9e\udab0\udfd7\ud994\udc6c", "\u07ce\uc8d3\uae49\u741e\u0341\ucad5\u87fd\uaff5\uc268\u97ae\u0d34\u7b21", "\ud80e\ude7c\ud99f\udfc1\udb75\udfed\ud83f\uddaf\ud8b3\uddee\ud895\ude1a\u7ed6\udb82\udfbf\ud848\ude4c\ud9df\udf9a\ud819\udc21\ud946\udfe6\ud8d1\udea7\ud9b2\udc56\ud92d\udf9e\ud817\udf21\uda80\udffb\ud9fc\ude95\udae3\ude24\ud8f4\udf71\ud95f\udd74\uda56\udc38\udb34\udea5\udb33\ude8d\ud986\udff7\udbfe\udeb9\udae1\udf6e",
        6, 1841, -1762714864, -1098664389543004779L, -46126L, true, true, (char) 40282, (char) 56203,
        Double.longBitsToDouble(0x3fe73657fdac908bL), Double.longBitsToDouble(0x3fe3c45c6066c61fL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 10, 0, 8, "\ud9b9\uddb8", "\u305f\u10c2\u08ff\u3dee\u3731\u0152\u3ad2\uab97\u46ff\u2a62\u11c2", "\udb60\udd95\ud8f0\udce6\udb66\udcae\udb66\udd8e\ud90e\udf2c\uda67\udd44\ud8df\udec5\u7bc1\uda1d\ude43\ud873\udf29",
        52, 98193, -1220141536, 6407791533847724745L, -85268L, true, true, (char) 12918, (char) 59048,
        Double.longBitsToDouble(0x3fe5cf65a3727cdcL), Double.longBitsToDouble(0x3fef120acf70175cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\ud913\udf82\0121=java.lang.String:\ud913\udf82\012",
        Z.run(T, 2, 11, 0, 8, "\ud913\udf82", "\u1f2c\u4549\u085d\u5cee\uc952\uc24e\u248d\u1852\u11a9", "\ud5d0\ud952\udf87\ud9d7\udf16",
        56, 56208, 706002708, -457876263739452263L, -10428L, false, true, (char) 55271, (char) 45490,
        Double.longBitsToDouble(0x3fde5cfb5c413d46L), Double.longBitsToDouble(0x3fde05939e94c4eaL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 6, 0, 8, "\ud9b9\uddb8", "\ud730\u4498\u08ff\u3dee\ub6f4\u682f\u2e5e\uc6db", "\udb39\ude62\udbeb\udc02\udb9d\udfc1\udabb\udf8a\ud8e3\udfe6\ud9e2\udf92",
        3, 5867, 89658521, 2236552820154244917L, 18240L, false, false, (char) 62385, (char) 34402,
        Double.longBitsToDouble(0x3fc35cc72c3dc468L), Double.longBitsToDouble(0x3fe8a516100f73c2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 9, 0, 10, "\ud9b9\uddd8\udbbc\udfdf\ud8f3\udf2f\ud88f\ude04\uda4b\udd40\ud908\uddb0\udb52\udc16\uda51\ude67\udb67\udd0c\ud80c\udf81", "\u0d64\u11af\u33a2\u119e\u81c8\u2a5e\ud586\uc8f3\u0e71\u62ee\u61ba\u1036\ua63f\u5019\u2b2d\ud687\u4d70\uc806\u9046\u04cb\u2bf0\u2710\ud18a\u4c9a\u1b83\uc82a\u5e4e\ub51e\u36ed\u3fa1\u6455\u6ba2\ud304\u0145\uc80a\u1060\u0ca8\u4490\u58b6\u02bd\uc372\uab3b\ud224\u99ab\ud6ac\ua35f\u533b\u5b48\u9168\uc472\u5e18\u6f29\ucd66\u59cd\u3390\u15d2\u7fa0\ua666\u5ae2\ua08a\u014e\u746b\ub28f\ubd57\ua9b0\u1456\u304d\ubdc1\u710f\u7cb8\u5926\u3128\ub9b2\u80e3\u1815\uab5f\ua754\u5d4b\u9feb\u7e79\u77f9\u6a35\u2593\u12bc\u9d79\u4f89\u64b2\u7f54\uabc3\u5f87\ud13b\u1e37\u0975\ua89b\u2533\u694e\ud615\ua931\u661e\u7b25\u4722\u8c92\ub6e8\u70d3\u9082\u751e\ub756\u8e89\uc74e", "\ud8dc\udee8\ud810\udc59\ud881\udeeb\uda90\udd68\ud894\udfbf\udaac\uded0\udb39\udf64\ud8c7\ude24\ud902\ude92\udb2a\ude72\ud9f7\ude82\ud84c\ude69",
        52, 72286, 483563014, -8721612653280848569L, -54698L, false, false, (char) 10462, (char) 30983,
        Double.longBitsToDouble(0x3fdc243fa8ead7c8L), Double.longBitsToDouble(0x3fd07d4048d6908cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.cli.TypeHandler:@?\012",
        Z.run(T, 1, 10, 4, 8, "\ud883\udf4b\udb42\udd4b\ud808\ude61\ud825\ude91\uf805\ud909\udeb0\uda2a\udf06\udb61\udf64\udba4\udc6f\udab4\udf59\uda2a\ude7d\ud9e5\udf2e\udbc7\udef1\udb78\udc3f\uda04\udc3f\ud919\udd7e\ud82b\udcf2\udb8b\udfae\ud972\udea4\ud9cd\ude22\ud9ab\uddbf\ud973\udcbd\ud8df\uddec\udb7f\ude10\ud986\udf17\ud9ee\udef2\uda19\udd24\ud90b\udcb9\uda12\udd0b\ud990\udfad\u8028\udb25\udde0\udbdf\ude33\ud8bc\udf5a\uda10\udef3\ud94b\uddfd\udaad\uddb7\ud927\ude0b\ud9ef\udeb0\ud80a\udf73\ud867\udf8b\ud853\udf09\ud867\ude06\uda4d\ude3a\uda56\ude75\udabc\udf4a\udb5a\udcb2\ud928\udca3\ud93f\udd7e\ud9a7\udeca\uda5f\udccb\udb2a\udf91\ud8cd\udd27\u0b18\ud9a9\udead\udae3\udd66\u8ca0\ud820\udc73\ubabf\ud853\udcbf\ud9c3\udd92\ud874\udc20\ud865\udccc\udb0f\udfd2\ud99a\udfb0\udbd6\ude25\udbbe\udde6\ud9e5\udd9c\ud82f\udf66\udbc3\udf85\ud892\udf19\udaa7\udfd8\ub314\ud8aa\udc5b\udbe8\udfb8\udb49\udf84\ud8f5\ude54\ud9af\ude3f\ud981\udec2\ua469\udb2a\udc13\uda55\ude61", "\u87c4\uaf29\u9571\u9e85\ud27c\u38db\u98fa\u9327\u260e\u0d8a\u5913\u0287\u244c\u51f4\u74d6\uc668\u3e4d\ub4ab\u6e07\u99f7\u2293\ua574\uc37d\u6b8b\u0b3a\u8499\u4e7d\u936d\u340f\u6434\u9259\u7006\u37ff\u6ba6\ua2d7\u3c04\u5eac\u4cbd\u5dcb\u9a4a\u6077\u9531\uc1fd\ud2aa\u39b0\u5408\u1dec", "\ud850\udebb\udbec\ude0e\udab0\uddc9\udbaf\udf03\udb49\udc75\uebe6\udab0\udeb0\ud8d9\udeba\udbea\udc89\udbbe\udd80\uda15\udd7f\udbc6\udea9\ud8e3\udfeb\udb91\udda7\uda21\udf95\udb09\udd2f\ud9b4\udc1e\ud96b\udf46\ud840\udfbf\ud9b2\udc3e\udb83\udf42\ud818\udeb1\udbb5\udd6b\uda8c\udd6c\udb6f\udebd\ud8bb\udcab\udbce\udfef\udad2\udd18\ud8e7\uddab\udba2\udce9\ud998\udd86\uda3c\udc64\ud998\udc06\uda18\udc4f\udb66\udf90\ud955\ude0e\udbc3\udfd8\uda52\udfdf\ud8ed\udf79\uda6c\udd5f\uda92\udeb1\ud93d\udecc\ud930\udfe3\udad0\uddee\ud882\udfd0\ud9cd\udfae\udb44\ude89\udadd\udd86\udb6c\udd01\ud902\udefa\ud935\udccb\ud97d\udd6a\udb7b\ude0b\udb7a\ude57\uda80\uddfc\ud8c2\udd2f\ud96c\udd04\ud83b\udfbc\udacf\udc0c\ud8ef\udeb5\ud911\ude45\ud8c4\ude58",
        6, 54949, -1679173549, -1157348061318565786L, -37507L, true, false, (char) 11739, (char) 4941,
        Double.longBitsToDouble(0x3fea1c182fa654a2L), Double.longBitsToDouble(0x3fe5ff8377faccf9L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!org.apache.commons.cli.ParseException\012",
        Z.run(T, 1, 0, 2, 0, ".", "\ud6cb", "\ud9e0\udc41\udbb6\ude9d\udb77\udceb\uda18\udea4\ud8ef\udd36\ud933\uddb5\000\udab2\udd92",
        49, -846, -719060992, 5212248766087207160L, -64414L, false, true, (char) 55880, (char) 15934,
        Double.longBitsToDouble(0x3fe4b5758fad451aL), Double.longBitsToDouble(0x3fe979bc1d99cd5eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 2, "\ud9b9\ude11", "\u9d0f\u335c\u7ea2\u3dee\ub6f4\u93b9\u91e3\u7a4f\u2b4f\u8bf3\u11ba\u68ae\u119e\u2720\u830d\uab57\u5b69\u0e71\u62ee\u93b4\u0ed7\u687c\u8178\u2b2d\u564d\u97df\u1292\ua895\u322a\u85f3\u69fe\ud535\u773e\u456a\u9c64\uacc30\u0695", "\ud83a\udd37\uda3f\ude8a\udbac\ude08\udbe5\udfdb\ud9e3\udd4b\ud839\udd6b",
        34, 88179, -1481973024, 4726770026282705168L, -53787L, true, true, (char) 29060, (char) 348,
        Double.longBitsToDouble(0x3fe4319108df6409L), Double.longBitsToDouble(0x3feedf45d8d3709dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "M|org.apache.commons.cli.TypeHandler|openFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createClass|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createDate|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFile|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createFiles|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createNumber|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createObject|java.lang.String|static",
    "M|org.apache.commons.cli.TypeHandler|createURL|java.lang.String|static",
    "C|org.apache.commons.cli.TypeHandler|<init>|",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Class|static",
    "M|org.apache.commons.cli.TypeHandler|createValue|java.lang.String,java.lang.Object|static",
    "M|org.apache.commons.cli.TypeHandler|openFile|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
