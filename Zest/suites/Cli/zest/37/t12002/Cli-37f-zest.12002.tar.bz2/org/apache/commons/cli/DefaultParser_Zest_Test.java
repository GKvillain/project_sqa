package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\u2d22\u3fff\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 30529, -1713481566, 2872766391121209723L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f768d8dfa3L), Double.longBitsToDouble(0x3fe6d76e432edb14L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8c2\udc68\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\u2d22\u3fff\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 30529, -1713481566, 2872766391121209723L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f768d8dfa3L), Double.longBitsToDouble(0x3fe6d76e432edb14L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud960\udfcd\ud822\udde8\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud911\ude76", "\u95e7", "\udacb\udf8b\uda2d\ude0f\ud9b1\ude9b\uda32\udf2f\udbe0\udefe\ud949\udcc5\ud88a\udca8\ud961\udef5\uda12\udd1c\ud8af\udcfc\ud988\ude48\udb36\udcad\ud8fd\ude57\ud81d\udd16\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44Q\udb6a\ude75\ud8ae\udde0\000\ud88c\uddfb\ud9bc\udc29\udbd2\udc26\ud8d5\udc03\udaf5\ude38\ud997\udce8\udaac\udc33\uda4a\udf02\udb0c\udc84",
        12, 38682, -107457746, -1828009225480089571L, -7838L, false, true, (char) 24099, (char) 59386,
        Double.longBitsToDouble(0x3fa68caa258ac610L), Double.longBitsToDouble(0x3fd49aa5d8469a3eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 15, 5, 14, "\ud9a7\uded2\udb4f\udddb\ud9fc\udc15\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\u4abd\ud8d2\udd67\ud9b7\ude17\ud85f\udcfd", "\u3de6\ub6dc\u2cdb\ud1c4", "\uda32\udf2f\udbe0\udefe\ud949\udcc5\ud88a\udca8\ud961\udef5\uda12\udd1c",
        54, 51018, 336748415, 2728640533612769534L, -78034L, false, false, (char) 50530, (char) 39186,
        Double.longBitsToDouble(0x3fcbe6a1c29689a0L), Double.longBitsToDouble(0x3fc83e12228a1474L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\udeee\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8", "\u621f\u49e3\ua311\ub07d\u6134\u205c\u2d9a\u4c57\u9838\u2692\u9093", "\ud822\ude08",
        42, 75044, 223128176, -8976622453945435412L, -40722L, true, false, (char) 36897, (char) 30343,
        Double.longBitsToDouble(0x3fe366feba68e05fL), Double.longBitsToDouble(0x3fe72ab9b71635baL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\udf2e\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7", "\u49e3\ua311\ub07d\u6134\u0390\ubc40\ub4bd\u9838\u3f6c\u820d\u1fa8\u297a\u6ee9\u3991", "\ud976\udff9\ud9b7\ude17\ud85f\udcfd\udbae\ude06\ud98b\udfa0\udaf3\udd24\udb62\udfe2\udb72\udc8e\udaf6\udc40",
        33, 27822, 1328443013, -6944777547915184435L, -92312L, false, true, (char) 41597, (char) 28782,
        Double.longBitsToDouble(0x3fa8edf019d08610L), Double.longBitsToDouble(0x3fcfc4bbce8ef6e0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8dd\ude85\ud893\udd03\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2", "\ub998\ucf67\ubbf6\u0839\u6b3a\u1f9a\u297a\u6ee9\u3991\u9893\u06e9\u3a25\u5b9d\u1edd\u4f3f\u3cc5\u95e7\u07ab\u2cf0\u6144\ua238\u9e59\u8c5d\u3c16", "\udb82\uded3\uda18\udf88\ud8af\udcfc\ud988\ude48\udb36\udcad\ud8fd\ude57\ud81d\udd16\udabb\udfe9\udb33\udfd5\ud8fd\udcd6\udb1a\udc6f\udb32\ude1a\udbff\udcb6\ud98d\udecb\udbf5\udef2\ud8de\udeb1\ud9bc\udc29\udabb\ude1a",
        20, 60829, 2081633438, -5998775856821773411L, -99784L, false, false, (char) 11843, (char) 30275,
        Double.longBitsToDouble(0x3fe994aa86a81207L), Double.longBitsToDouble(0x3fe7dcd72b6f0b4aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\udaed\ude81\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\udb8c\udfa9\uda13\udc2b\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud92e\udff2\uda93\udf14\ud801\udc00\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\u1a93\u8c5c\u8c5d\u3c16\ua925\ud28d\uc54e\u362e\u2d22\u3fff\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 30529, -1713481566, 2872766391137986939L, 12441L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f768d8dfa3L), Double.longBitsToDouble(0x3fe6d76e432edb14L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\uded2\udbab\udfa8\000\000\000\000\ud9f1\udeb7\u7232\uda46\udcb4\u113b\u87da\ud9e3\ude27\000\000\ud9ec\udf76\udbd1\udfca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\udb76\udef7\000", "\u95e7\ub5c8\000\uc71c\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\u1e08\u3602\u52f3\u3fff", "\ud81d\udd16",
        58, 12034, -1396759340, -450051398511452335L, 25307L, false, false, (char) 40609, (char) 35671,
        Double.longBitsToDouble(0x3f3a4e0000000000L), Double.longBitsToDouble(0x3fe368f000d8dfa3L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 12, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud840\udf6f\ud8e0\udda6\ud9e3\ude2c\ud9d6\udfbc\u7232\ud9c3\udce6\u118f\ud8f5\udd24\ud843\uded4", "\ubc40\ub4bd\u9838", "\udb8f\uded7\ud976\udfd7\ud822\ude08\ub01a\udac3\udfe9",
        39, 97344, 902396652, -1776082427220075164L, -98383L, false, true, (char) 46943, (char) 41258,
        Double.longBitsToDouble(0x3fde54b8eb69c118L), Double.longBitsToDouble(0x3fe25002bb72029aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232", "\ua311\u5f6d\u6134\u0390\ubc40\u09b7\ub97c\u6a1e\u9093\u1f9a\u297a\u6ee9\u9baa\u9889\ud396\u1ea2\u92ab\u613a\u4f5d\ua5f7\u306b\u07ab\u2cf0\u33c5\u9288\u9366\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\u2d22\u3fff\u0749\u68fd\u3270\ubd9b\u239f", "\ud9aa\ude71\u475b",
        20, 30529, -1713481566, 2872766391121209723L, 49703L, true, false, (char) 39278, (char) 45147,
        Double.longBitsToDouble(0x3fe895691f13bdcbL), Double.longBitsToDouble(0x3fe6d76e432edb14L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\uda29\udd5a\ud95a\udf00\ud9f1\udeb7\uda0e\udd2a\uda9a\udef5\uda3a\udf2a\uda06\udd71\ud81a\udf11\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud91a\udebe\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud900\udc35\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ucde9\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\u2d22\u3fff\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b\ud8ae\udde0\ud813\udd83\ud88c\ude9d\ud9bc\udc29",
        -5, 41188, -727562041, 7606134138369478112L, 95216L, false, true, (char) 44717, (char) 16905,
        Double.longBitsToDouble(0x3fe491916d2dfdefL), Double.longBitsToDouble(0x3fdf2134f1c0dc24L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 4, 1, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\ude6e\ud9d0\udce0\ud9ce\ude81\ud81a\udf1e\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\uda2c\ude40\ud908\udc47\uda90\udcf6\ud95e\uddd7\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\u2d22\u7f4e\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 22113, -81517065, 2872766391121209723L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f768d8dfa3L), Double.longBitsToDouble(0x3fe6d76e41a5db14L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u05f1\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\u2d22\u3fff\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b\ud8ae\udde0\ud813\udd83\ud88c\ude9d\ud9bc\udc29\udbd2\udc26\ud8d5\udc03\udaf5\ude38\ud997\udce8\udaac\udc33\uda4a\udf02\udb0c\udc84\ud85b\udfc5\u64ad\ud9d2\udc6b\ud9d9\udcc6\udad6\udd07\udba6\udfe6\ud936\udcb7\ue565\uda24\udde5\ud86c\udfc6\udb29\udfa2\ud927\udc26\ud94b\udd6f\ud939\udce0\uda6f\udc52\udb26\udc31\udb30\ude1c\udbb1\udf3a\ud81f\udfc5\uda00\ude79\ud9ca\udfd2\ud925\udd8d\ud806\udda5\uda0b\udd46\ud851\udede\ud81b\uddf4\udaaa\udef9\uda74\udeec",
        15, 5829, 605905103, -8575166371469784358L, -62391L, true, false, (char) 46366, (char) 44667,
        Double.longBitsToDouble(0x3fe04e3441515659L), Double.longBitsToDouble(0x3fc0fb89277b45d4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\udab8\udedc\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\ude96\udbf5\udcca\ud968\ude48\ud9c8\udcbf\ud910\udc57\ud931\uddc8\ud976\udfd7\ud822\ude08\ud869\ude54\ud871\udc51\udbc8\udf7f\ud8d2\udcfa\ud9ac\udfbd\ud85f\udcfd", "\ubfae_\u2cb5\ud1e8\ua292\u9e59\u8c5d\u3c16\ua925\u6956\ub7c9\u362e\u2d22\u3fff\u0436", "\uda30\uddf1\udb15\udec7\udbf7\udfb1\udb0a\udc44\ud9aa\ude71\u475b\ud8ae\udde0\ud813\udd83\ud9a1\uddce\udbe0\ude7f\udbd2\udc28",
        -2, 64303, 1765324469, 2845164320834031920L, -99784L, false, true, (char) 11843, (char) 35034,
        Double.longBitsToDouble(0x3fe0973bdd832d04L), Double.longBitsToDouble(0x3fc544fc19c67510L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 10, "\uda5b\uded3\udbb2\udc2c\udadc\ude16\ud861\uddbf\ud8bc\uddf3\ud95a\uded8\uda32\uded7\uda77\udc18\udac7\udce5\u1179\ud9d5\udd53\udbf6\udff2\ud819\udcee\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\udbc8\udd62\u03b2\ud908\uddfd\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\udb30\udfe6", "\u95e7\uc0da\u4d89\u033c\u1c66\u3142\u1ff3\u2e0c\u0c1a\u5e56\ub7c9\u362e\u489b\u3ff9\u0749", "\ud8f9\udfe8",
        25, 69660, 599857315, 3844415550713654495L, 23440L, true, true, (char) 47209, (char) 40609,
        Double.longBitsToDouble(0x3fdb5d4a2f896ce4L), Double.longBitsToDouble(0x3fe04537f26d1eedL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\uded2", "\uce6d\ud537\u397b\u42c6\u9ca3\u621f", "\ud81a\udea2\ud819\udd79\ud975\udfbd",
        2, 62394, -30705052, -5362011701055761855L, 33373L, false, true, (char) 30267, (char) 33130,
        Double.longBitsToDouble(0x3fe3853260528a46L), Double.longBitsToDouble(0x3fe7641b3e7135c9L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9d8\ude5b\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\udb4c\udefb\udb67\udd95\udaf0\ude5e\uda34\udc67\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u4e5c\ub7c9\u362e\u2d22\ucd94\u075b", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 30529, -1143056222, 1807412977236277986L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe36b1d90d8dfa3L), Double.longBitsToDouble(0x3fe6d76e432edb14L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 13, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\u74d3\u3649\u2d22\u3fff\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 30529, -1713481566, 2872766391121209723L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f768d8dfa3L), Double.longBitsToDouble(0x3fe6d76e432edb14L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 1, 15, 7, "\uda59\udf6c\udbb2\udc2c\uda6e\udede\ud874\udc62\ud8bc\uddf3\ud96a\uddd8\ud9f1\udeb7\udb59\udc2f\uda4c\uddfe\u113b\u87da\ud81a\udf70", "\ubcb6\ub4bd\u9838\u2692\u9093\u1f9a", "\ud908\udc47\udad7\udd9a",
        18, 87005, 902404101, -1776082430284326798L, -75581L, false, true, (char) 37443, (char) 60103,
        Double.longBitsToDouble(0x3fe72ab9b7dd35baL), Double.longBitsToDouble(0x3f60d7949d4f2e00L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 0, "\000", "\ud4e6", "\ud9f1\udeb7",
        29, 10794, -586052864, 0L, -36094L, false, false, (char) 0, (char) 31332,
        Double.longBitsToDouble(0x3fe627f15a41b596L), Double.longBitsToDouble(0x3f37454000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 1, 15, 10, "\ud9a7\uded2\ud867\udddb\uda6e\udf03\ud86e\udf62\ud8bc\udea7\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\udbbf\ude0f\ud976\udf00\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u648b\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\u2d22\u3fff\u0749", "\udabb\udfe9\ud8b5\ude17\ud9f0\udeed\ud8dd\udd84\uda99\ude1e\u475b",
        -3, 30386, 688258466, 1819639340695153019L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f768d8dfa3L), Double.longBitsToDouble(0x3fe6d216432edb14L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 12, 10, "\ud988\udfd2\udb31\udfb4\uda6e\udede", "\u39a2\u42c6\u9ca3\u621f\u90b4\ua2d6\ub07d\u718b\ud592", "\udb65\udd27\ud956\udc1f\ud90f\udfbd\ud860\ude00\ud9d3\uddf0\ud822\ude08\ud98e\ude97\ud845\udc9f\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd\udbae\ude06\ud98b\udfa0",
        35, 29648, -530599316, 6313677689244506853L, 59365L, false, true, (char) 14844, (char) 44941,
        Double.longBitsToDouble(0x3fe0430c3f2c87fcL), Double.longBitsToDouble(0x3fd9520e99d563feL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 9, 5, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\udbbb\uddf4\uda48\udcc5\udb89\udd91\ud822\ude00\ud908\udc47\udad7\udd9a\udba2\udc7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\ua577\ub190\u0749", "\ud81a\udc57\udb20\udcc8\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 30529, -1713481566, 2872766391121209723L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f76ad8dfa3L), Double.longBitsToDouble(0x3fe6d768db2edb14L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud89b\udf36\udbb2\udc2c", "\ud537\u397b\u42c6\u9ca3\u621f\u49e3", "\ud819\udd79",
        47, 8326, 1472180993, -131953942181032252L, 27619L, true, true, (char) 43437, (char) 18002,
        Double.longBitsToDouble(0x3fb4a29197641b38L), Double.longBitsToDouble(0x3fe389ae4872e75aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8", "\u621f\u49e3\ua311\u477e\u6134\u0390\ubc40\ub4bd\u9838\u2692\u9093", "\ud822\udde8",
        42, 6452, -1975080336, -8978198182957057300L, -100000L, false, false, (char) 36897, (char) 30343,
        Double.longBitsToDouble(0x3fe366feba68e05fL), Double.longBitsToDouble(0x3fe72ee1b71635baL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 10, "\ud9a7\udec3\udbb2\udc2c\uda6e\udede\udbf7\udd45\ud95e\udc85\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\udb0a\udf02\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud960\udfcd\ud822\udde8\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud911\ude76", "\u95e7", "\udacb\udf8b\uda2d\ude0f\ud9b1\ude9b\udb60\udca6\udbe0\ude66\ud949\udcc5\ud88a\udca8\ud961\udef5\uda12\udd1c\ud8af\udcfc\ud988\ude48\udb36\udcad\ud91d\ude57\ud81d\udd16\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44Q\udb6a\ude75\ud8ae\udde0\000\ud88c\ude03\ud9bc\udc29\udbd2\udc26\ud8d5\udc03\udaf5\ude38\ud997\udce8\udaac\udc33\uda4a\udf02\udb0c\udc84",
        12, 38682, -107457746, -1828009225480089571L, 88176L, false, false, (char) 25374, (char) 59386,
        Double.longBitsToDouble(0x3fa68caa258ac610L), Double.longBitsToDouble(0x3fd49aa5d8469a3eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 15, 5, 3, "\ud9a7\uded2\udb4f\udddb\ud9fc\udc15\ud86e\udf62\ud8bc\uddf3\ud850\ude58\ud9f1\udeb7\udb75\ude93\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud834\udeac\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ue479\ufc9b\ud993\ude69\ud8d2\udd67\udb4b\udce6\udbb7\udf24\udaf3\udd55\ud964\udf92\udae6\ude34\udb57\ude09\udb72\udc79\udacb\udf8b\uda2d\ude0f\ud9b1\ude9b\uda32\udf2f\udbe0\udefe\ud949\udcc5\ud88a\udca8", "\u2d22\u3fff\u0749\u68fd\u3270\u98b7\u239f\uba27\ud13b\u2e33\u988a\u3675\ubb3e\u7fe1\ua757\uac9d\ud450\u50aa\u94b6\u7131\ucbba\u7dda\u7177\u03fb\ub407\u65f3\ud0e3\u3548\u40ac\uc93d\u0a05\ub864\u0eaf\u5a42\u887e\uce64\u747c\u657d\ua1e1\uae9f\u6f84\u6bd9\u6ed7\uad24\u8e9b\u9a06\ud1b2\u5633\u57ba\u75f7\u9e1c\u08d5\u2911", "\ud92a\udc98\udb34\udc0c\uda25\uddc3\ud9b7\udff3\ue4e3\uced1\ud83a\udd46\udab2\udfe4\ud8e6\ude5d\ud918\udfe9\uedf2\ud909\udf38\ud95b\udcd9\ud84d\udc07\udba8\udcc8\ud9e4\udd97\ud893\uddb8\ud975\udc64\ud909\udf21\udabc\udd21\udb96\udea5\uda72\udfcc\uda51\udf50\uda82\udcc7\ud89a\udea3\ud871\udf2d\ud8fe\udfd6\ud991\udce4\udb0e\udd97\udbf8\udfdb\udaf8\udff0\uda00\udfc8\udae8\udea2\ud9d1\udff3\ud885\udc50",
        17, 92198, 1237930258, -5147313830721375401L, 30373L, false, false, (char) 50771, (char) 50593,
        Double.longBitsToDouble(0x3feac3172a004b43L), Double.longBitsToDouble(0x3fe559dc34bc5912L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 14, "\ud9a7\uded2\udbd1\udd7b\uda28\udc12\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud81b\ude6c\u7232\uda5d\udeb4\ud81a\udcd5\uda01\udcc9\ud875\udda6\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\ud985\uddac\udb84\udfe0\u17ae\ud956\udf88", "\u3de6\ub6dc\u2cdb\ud1c4", "\uda53\udd3f\udbd1\ude9a\ud8d2\udd92\udab4\udf1e\ud8a9\udeb5\uda0a\ude24",
        54, 51018, 929745175, 2728641225102504190L, -78034L, false, false, (char) 50530, (char) 39186,
        Double.longBitsToDouble(0x3fcbe6a1d85e0eb8L), Double.longBitsToDouble(0x3fe29cd66176651fL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 15, 5, 14, "", "\u7273\ud186", "\000",
        -5, -1000, -586088448, 6347817804837383716L, -99838L, false, true, (char) 3, (char) 27684,
        Double.longBitsToDouble(0x3fe627f15800b596L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 0, 7, 10, "", "\ucc82\ud186", "\ud9f1\udeb7\u7232\uda5d\udeb4",
        10, 55497, 1278935040, 6892547943069384866L, -70722L, true, true, (char) 30257, (char) 11496,
        Double.longBitsToDouble(0x3fe96ae8a8fd2c00L), Double.longBitsToDouble(0x3fd20a8aa5739704L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 4, 7, 10, "", "\u1c74\uce6d", "\ud9f1\udeb7\u7232\000",
        10, 32505, 1278963236, 6892547944359197090L, -70722L, true, true, (char) 21792, (char) 54846,
        Double.longBitsToDouble(0x3fe96ae8a8fd2c3bL), Double.longBitsToDouble(0x3fd20a8aa5739704L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 9, 11, 0, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\udaed\ude81\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\udb8c\udfa9\uda13\udc2b\ud89b\ude1d\uda3c\udd53\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud92e\udff2\uda93\udf14\ud801\udc00\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\u1a93\u8c5c\u8c5d\u3c16\ua925\ud28d\ub634\u362e\u2d22\u3fff\u8460", "\ud965\ude2e\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u73ae\udbf4\udff9\ucd67",
        12, 45048, -361371269, -206188903728527161L, -96448L, false, true, (char) 37210, (char) 57467,
        Double.longBitsToDouble(0x3fe6d76e432edb14L), Double.longBitsToDouble(0x3fc68efbaa8691c4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 1, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\ude6e\ud9d0\udce0\ud9ce\ude81\ud86f\ude7b\ud828\ude6e\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48", "\u02ff\u4c19\u4fc7\u3991\u3422", "\ud9b7\ude17\ud85f\udcfd\udbae\ude06\ud98b\udfa0\ud884\udc5d\udb62\udfe2\udb72\udc8e\udacb\udf8b\ud8c2\udedc\uda81\uddde",
        10, 45915, 2091079021, 7017227153523351048L, 9808L, false, true, (char) 15517, (char) 10286,
        Double.longBitsToDouble(0x3fdd125de74609f8L), Double.longBitsToDouble(0x3fe196067cd45fb3L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 3, 2, 10, "\ud8a1\uded4", "\uce6d\ud537\u397b\u42c6\u9ca3\u621f", "\ud81a\udea2\uda7e\udc4e\ud975\udfbd",
        36, 39858, -30705123, -21602361087274277L, 33373L, false, true, (char) 63623, (char) 26635,
        Double.longBitsToDouble(0x3fe38535c8528a46L), Double.longBitsToDouble(0x3fc2506cf9c4d724L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 15, 10, "\udbb2\uded2\udbb2\udc2c", "\ud537\u9555\u8e40\u9ca3\ub7f3\u9361\ua311\u5ac5\u8c63\u32f8\ube14\u2ad1\u9838\u2692\u62f1\u9978\u291c\u6ee9\ud571\u9893\u5af4\u6ca5\u2821\u60e8\u11ff\u5ff4\u27f7\u954e\u7249\ud178\ua292\u9e59\u8c5d\u6277\u5f98\u0d01\u93e2\ud674\u2cdd\uae44\uc6f7\u83d8\u8690", "\udbf8\udc02\ud98e\udde7\uda32\udc8c\ud91a\ude5a\u050d\ud93b\uddec",
        20, 19090, 1871642088, 6186484586048453867L, -70707L, true, true, (char) 48149, (char) 11843,
        Double.longBitsToDouble(0x3f9b5b147102cbc0L), Double.longBitsToDouble(0x3feaf58d96c3ee9cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud8a6\udcdd\ud8a3\udd07\ud95a\uded8", "\u621f\u49e3\u0659\u477e\u60ae\u0390\ubc40\ub4bd\u9838\u2692\u9093", "\ud833\udfe8\ud8dd\uddf6\uda34\udf97\udbc8\udf7f\ud98f\udc98\u5764\uda87\udd19\000\ud98b\udf03\udaf3\udd24\udb62\udfe2",
        34, 5832, 901405413, 7120629811192083691L, -97286L, false, true, (char) 35091, (char) 34983,
        Double.longBitsToDouble(0x3fdc36c99a71f2eaL), Double.longBitsToDouble(0x3fe1858993742cc3L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 12, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8", "\u621f\u49e3\ua311\u477e\u6134\u0390\ubc40\ub4bd\u9838\u2692\u9093", "\ud822\udde8",
        42, 6452, -1975080336, -8978198182957057300L, -100000L, false, false, (char) 36897, (char) 7128,
        Double.longBitsToDouble(0x3fe366feba68e05fL), Double.longBitsToDouble(0x3fe72ee1b71635baL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 11, 10, "\ud9a7\uded2\udbb2\udc2c\uda66\ude13\ud86e\udf62\ud8bc\uddf3\ud95a\uded8", "\u8dbb\u49ce\u2867\u47b2\ub09c\u0390\ubc40\u621b\u5c91\u2692\ubcfc", "\ud822\ude6b\ud9b5\udc39\ud8e7\udcc1\udbc8\udf49\ud8d2\udcfa\ud9b7\ude17\ud911\ude76\uda7b\udf93\uda50\udef8\udaf3\udd0c\ud939\udedd\udae1\udd56\ud80b\udfec\uda2d\ude0f",
        36, 71625, -1356870883, -7463964421281392515L, 10100L, true, true, (char) 56724, (char) 42611,
        Double.longBitsToDouble(0x3fe52b91a210e991L), Double.longBitsToDouble(0x3f905fdfb505c1a0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 10, "\ud9a7\uded2\udbb2\udc2c\ud8f5\udfd5\ud9d0\uddea\udae3\udfd2\ud95f\udef6", "\u621f\u1a04\u81f1\u32c5\u6134\u0390\u9311\ub4bd\u7b92\u863a\u9093", "\ud81c\udee6\uda9e\udfef\ud889\udc01\udbc8\udf5d",
        31, 57918, 5903985, 6684036738085687513L, -81000L, false, true, (char) 28770, (char) 22519,
        Double.longBitsToDouble(0x3f96354534efdea0L), Double.longBitsToDouble(0x3fb225fc5bafe0a0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 8, "\ud9a7\uded2\udbb2\udc2c", "\u230d\u397b\u42c6\u9ca3\u621f\u49e3\ua311\u477e\u6134\u0390\ubc40\ub4bd\u9838\u9628\u9093\u1f9a\u90b0\u6ec9\u6150\u4e54\ud67a\uc285\u92ab\ua6db\000\u3c28\u95e7\u07ab\ud2dc\u35fc\ua292\u74aa\u47b3\u404d\u0226\u4dac\u5018\ud4f4\u21cd\ub45b\u75d8\u1fd3\u4539", "\ud807\udebb\ud983\udebd\ud884\udfa4\ud90f\udea4\ud9f0\udc17\ud89e\udd37\udaa7\udc38\udbe6\udd8f\udab7\ude3a\udbea\udfcb\udabb\uddeb\udbb2\udf81\udad6\udf5e",
        7, 94772, -1196261767, -3942191335193382951L, -34948L, false, false, (char) 37031, (char) 57084,
        Double.longBitsToDouble(0x3fd68a84345248c6L), Double.longBitsToDouble(0x3fec4da977971633L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 15, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf70\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\ufcc3\ud948\udcb1", "\uc2a7", "\ud9f2\udef6\udbf5\udcca\ud86b\udf53\udb35\udd93\udbf5\ude7c\ud931\uddc8\udbd4\udc26",
        56, 77402, -1495131109, -8486305142136174510L, 36817L, false, false, (char) 4096, (char) 23073,
        Double.longBitsToDouble(0x3fd1fc0474d9bfaeL), Double.longBitsToDouble(0x3fe34702fae5dc21L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 15, 4, "\udbd7\ude0c\udbb2\udc2c\uda6e\udede\ud8d7\uddaf\udaae\udd63\ud84a\ude9b\ud9f1\udecd\u7232\uda5d\udeb4\u113b\u87da\ud836\udda2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud960\udfcd\ud822\udde8\uda21\ude4b\uda34\udf97\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud911\ude76\000\ud98b\udf03\udaf3\udd24\udb62\udfe2\udb72\udc8e\ud80c\udc4c\uda2d\ude0f\udac4\udd45\ud966\uddd4\ud9ec\udcd5\uda6d\udef2\ud842\udf9e\ud9d4\udcd7\udb98\udd86\ud9e6\ude18\ud982\ude49\ud9f9\udc22", "\ub75c", "\udb9d\ude80\ud939\udd58\udad1\uddea\ud819\udcaf\udae6\udffe\ud816\udf09\ud9ad\udcda\ud95f\ude36\ud930\uddeb\udb9f\udc31\ud8a8\udc2b\ud8b3\udd4f\ud8cb\udeb2\udadd\uddbf\uda19\udceb",
        13, 14476, -1485249570, 8384954214329097402L, -70155L, true, true, (char) 47495, (char) 47119,
        Double.longBitsToDouble(0x3fd36a3b55702586L), Double.longBitsToDouble(0x3fdbfc6295fe1140L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 5, "\ud8e8\udd99\udbb2\udc64\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8", "\u621f\u49e3\u75af\u477e\u6134\u0390\ubc40\ub4bd\u9838\u7694\u9093", "\ud822\udde8\ud908\udc47\uda34\udf97\udbc8\udf7f",
        8, 61652, 5903985, -2076045312L, -81000L, false, false, (char) 51255, (char) 3673,
        Double.longBitsToDouble(0x3fe8b1add45f17bdL), Double.longBitsToDouble(0x3fc7a0402a91ae94L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\udac8\udfe3",
        -3, 36254, 989765120, -293192532843495350L, -100000L, false, true, (char) 16549, (char) 27684,
        Double.longBitsToDouble(0x3fe627f15800b500L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 14, "\uf016", "\ud12e\u99f8\u3d7d\000\000\000\u65b5\ua28c\ub07d\u6134\uba7b\u6c0d\ud41e\u9838\u2692\u4e6b", "\udab4\udcd1\ud924\udc6c\udaba\ude53\ud9cc\udc22\uff99\uda4f\udc9d\ud892\udc0e\ud961\udd0b\uda3d\udccc\uda97\udf4b\uda43\ude2f\ud877\udd22\udb10\udd45\ud974\ude6e\udb61\udf2d\ud9bb\uded1\ud95e\udce3",
        24, 90538, -2111298843, -4008240909030979456L, 3966L, true, false, (char) 60273, (char) 22207,
        Double.longBitsToDouble(0x3fdd0800dc9e7350L), Double.longBitsToDouble(0x3fe6e7e1c3aee907L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 9, 9, "\ud9da\udd82\udbb1\udfb7\uda6e\udede\uda49\ude4f\ud8e2\uddb4\ud9de\udc74\udaeb\udd65\uda0f\udd75\uda5d\ude6e\ud9d0\udce0\ud9ce\ude81\ud86f\ude7b\ud828\ude6e\ud849\udc3c\ud9f2\udef6\udbf5\udcca\ud80d\udd4a\ud84d\udc9c\uda91\udf1a\ud827\uddb2\udaf3\uddcd\udb9f\udec1\ud908\udc47\uda90\udcf6\ud95e\uddd7\udbbd\udf0e\ud836\ude79\udb5a\udf38\udbae\ude06\uda9f\udf49\ud8b4\udfdb\udb62\udfe2\udbf4\udcce\udacb\udf8b\udb03\udc10\uda59\udeb7", "\u247b\u5e56\u469b\u799d\u5b20\u8a93\u36a1\u76fd\u57ba\ua51c\u114c\u0791\u31b8\u9c30\u70c7\u83b1\uaf58v\u4d52\u16d5\u0c4c\u51c7\u04c6", "\ud942\udfcd\uda72\udd32\ud841\ude1a\udb82\udd56\ud958\udcea\udb22\udfa9\ud900\ude07\ud99a\ude52\ud82d\ude4a\ud99d\udc44\ud886\uddf3\uda53\ude12\udaa7\udef5\udb24\udddd\ud9ad\udc50\ud9bb\udc73\ud925\udf36\uda51\udf2c\udae7\udf29\udaae\udc13\udb77\ude80\ud9e1\udff8",
        29, 64619, -1183754782, 993777955917567185L, 48195L, false, false, (char) 20648, (char) 21821,
        Double.longBitsToDouble(0x3fefba2f987778d7L), Double.longBitsToDouble(0x3fea9aae29e8ab3aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 13, 1, "\ud9a7\uded2\ud94a\udc78\uda33\udcb2\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\ud9c5\ude62\ud9b8\udfe2\uda6f\udfc1\ud92d\udfaa\ud828\ude6e\ud975\udfbd\ud9f2\udef6\ud86f\udec8\ud985\udc2b\udaa0\udc09\uda91\udf1a\udbbc\udd8e\ud949\udd18\udb9f\udf3d\ud908\udc47\uda90\udcf6\ud95e\uddd7\ud8d2\udcfa\ufd15\ud85f\udcfd\udbae\ude06\ud98b\udfa0", "\u2d64", "\uda81\uddde\ud9ad\uddf4\uda2f\udd11\ud949\udcc5\ud88a\udca8\udb1a\udf51\udb3a\ude0b\ud865\udc2a\udaca\udddd\udb36\udcad",
        22, 54793, -1060127837, 6896042586051781844L, -97351L, true, false, (char) 40900, (char) 40161,
        Double.longBitsToDouble(0x3feec999c7cdbd2bL), Double.longBitsToDouble(0x3fe9f4aeab642b2eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 10, "\ud9a7\udefb\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8", "\u71d9\u2a2b\u33d2\u89ce\u4d90\u0390\ubc40\ub4bd\u9838\u2692\u9093", "\ud82e\uddfb",
        42, 6452, -1968264592, -8978198182957057300L, -100000L, false, false, (char) 36897, (char) 7128,
        Double.longBitsToDouble(0x3fe366febadd0e72L), Double.longBitsToDouble(0x3fe72ee4ff1635baL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 10, "\ud9a7\uded2\udbb2\udc2c\uda6e\udede\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9f1\udeb7\u7232\uda5d\udeb4\u113b\u87da\ud81a\udea2\ud819\udd79\ud975\udfbd\ud9f2\udef6\udbf5\udcca\ud968\ude48\ud94e\ude61\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd", "\u95e7\u07ab\u2cf0\ud1c4\ua292\u9e59\u8c5d\u3c16\ua925\u5e56\ub7c9\u362e\ub2c3\000\u0749", "\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b",
        20, 30529, -1713481566, 2872766391121209723L, 49703L, true, false, (char) 30488, (char) 47275,
        Double.longBitsToDouble(0x3fe368f768d8dfa3L), Double.longBitsToDouble(0x3fe6d76e432edb14L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 12, 10, "\uda2a\udfc4\udb32\udc81\uda6e\udede\ud86e\udf62\ud9d6\ude9f\ud95a\udeff\ud9f1\udeb7\u7232\uda5d\udeb4\uda52\udd20\u879f\ud81a\udea2\udaa5\ude70\ud925\ude34", "\ua91b\u4450\u9093\u538a\u33ce\u15ba\u2f2c\u9fb2\u06e9\u6ca5\u92ab\u696b\uc194\u36d8", "\udb52\ude3d\udb81\udd91\uda2d\ude0f\ud9b1\ude9b",
        48, 50572, 2091079021, 7027641722125164040L, 19586L, false, true, (char) 7461, (char) 15338,
        Double.longBitsToDouble(0x3fea62216176dd9eL), Double.longBitsToDouble(0x3fefda25c224bde7L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 3, 15, "\ud9a7\uded2", "\uce7b\ud537\u397b\u42c6\u328d\u40df", "\ud965\udddb\ud811\udea3\u8b8b\ud9f2\udef6\udbf5\udcca\ud86b\udf53\udb35\udd93\udbf5\ude7c\ud931\uddc8",
        51, 63896, 893423402, -6421539218363083152L, 65140L, true, false, (char) 90, (char) 4096,
        Double.longBitsToDouble(0x3fcbeea84be2511cL), Double.longBitsToDouble(0x3fec7c909a68e05fL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 10, "\u664d", "\ud6e8\ua0b3\ubd78\u0364\u4e3a\ud440", "\ud831\udce9\udbef\udec4\ud975\udfbd\udb92\udd00\udbdf\udcca\ue010\udb64\udf85\ud90f\udfbd\udba5\ude9c\uda8e\udf53\uda87\uddf6\uda58\udee1\ud944\udcab",
        41, 24852, -1152029610, -678799337895495640L, -27105L, true, true, (char) 46131, (char) 28770,
        Double.longBitsToDouble(0x3fbad863c7f0a7a0L), Double.longBitsToDouble(0x3fe4724f26074530L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 15, 10, "\udbfe\udf9f\ud9e1\udee9\uda6e\ude7a\ud86e\udf62\ud8bc\uddf3\ud95a\uded8\ud9d8\ude5b\udb4d\udfe1\udb02\udcad\u113b\u87da\ud86e\udf4e\udb68\udf61\u9337\udb4c\udefb\udb67\udd95\udaf0\ude5e\uda34\udc67\ud90f\udfbd\ud931\uddc8\ud976\udfd7\ud822\ude08\ud908\udc47\udad7\udd9a\udbc8\udf7f\ud8d2\udcfa\ud9b7\ude17\ud85f\udcfd\udbae\ude06\ud822\uddab\udaf3\udd24\udb62\udfe2\udb72\udc8e\udacb\udf8b\uda2d\ude0f\ud9b1\ude9b\uda32\udf2f\udbe0\udefe\ud95d\ude7a\ud9ca\udca8\ud961\udef5\uda12\udd1c\ud8af\udcfc\uda86\udfb5\udb36\udcbf\ud8fd\ude57\ud81d\udd16\udabb\udfe9\udb33\udfd5\udbf7\udfeb\udb0a\udc44\ud9aa\ude71\u475b\ud8ae\udde0\ud813\udd83\ud84f\udc9e\udbda\uddec\udb66\udedb\ud861\uddf1\udaf5\udd83\ud997\udce8\udaac\udc33\ud91d\udc8b\ud9b3\udd5f\ud85b\udfc5\u64ad\ud8c5\ude06\ud9f1\uddff\uda94\udf10\u909b\ud80e\udd8f\udb1c\udf15\udbe4\udefe\udb99\ude4c\ud923\udf65\udaaa\udc19\udbce\ude24\ud872\udfe7\udbfd\udc79\ud9dc\udced\ud800\uddf5\ud99f\udd65\ud9ba\udfbb\ud92e\uded6\udb51\udce4\ud8a5\ude40\udb3a\udfea\uda48\udf7f\ub363", "\u3560\u3692\ub9ee\ud24c\u6be4\u980c\u4185\u6121\u55d2\u71a7", "\udafe\udf2a\ud83d\ude24\uda30\udc2a\udbd4\ude5a\udbab\udca1\udbdb\udff4\udb53\udc85\udad7\ude07\udb57\udfb2\udade\udfd2\udad8\udf8e\ud90e\udc6d\uda5a\udd29\uc137\ufe83\uda32\udd5b\uf159\ud9fa\udfb1\udb68\uddb9\udb65\udfa1\udac7\udf2c\udbee\ude1b\udaf8\udf78\udad8\udf85\ud8ac\ude12\udabe\ude7d\udb20\udf9d\ud930\ude7f\udaeb\udc54\ud811\uddbf\ud87c\ude65\udb2d\udc08\ud8df\udc0c\uda70\udc5b\udaa5\udd08\udaa3\udfe6\ud961\udc0e\udb01\udc66\udac4\udd12\uda22\udf74\udbd1\udc3c\ud996\udce5\u7b69\ud9ef\udee3\udbad\udc07\udace\udf08",
        44, 26558, 914959881, 8617277640288097372L, -11991L, true, true, (char) 38767, (char) 53941,
        Double.longBitsToDouble(0x3fe5865115c91985L), Double.longBitsToDouble(0x3fc8a400092786ecL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredArgs||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredOptions||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|getLongPrefix|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleConcatenatedOptions|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithoutEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleShortAndLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleUnknownToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isArgument|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isJavaProperty|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
