package org.apache.commons.cli;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u49d8\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\ud92d\udf2b\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684875580, 7347326319986839359L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ef6L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\ub9c4\u3664\u62dd\ub5e9\u49d8\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\ud92d\udf2b\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684875580, 7347326319986839359L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ef6L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 2, "\ud86b\ude7b\ud98c\udf53\uda86\udc38\udb80\udfb7\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u8d34\u51d1\u62dd\u6138\ucce1\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud80f\udd3e\udaac\udfa7\ud92d\udf2b\u020e\ud912\uddac\ud953\udc0f\udb43\udf43\ud976\udc1c\ud921\ude01",
        33, 46876, 684875580, 7347326319986839359L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac6fe16ef6L), Double.longBitsToDouble(0x3fd7baec23f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 9, 3, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\ub146\u9178\u41f2\uaa89\u8295\uc461\u49d8\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\uda13\uddcc\ud89b\udc57\udaa2\udf2b\uda38\udf08\ud838\udfef\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684875580, 7347326319248641855L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ef6L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 3, "\udb48\udda9\uef54\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10\udb24\udc91\uda2a\udfa9\udb94\udcdc\udb2a\ude71\ud9ff\udcde\ud87d\ude53\ud9f8\udef4\udb2c\udecd\udbf5\ude92\ud9be\ude18\ud95a\udd0b\udae7\uddbe\udb19\udd52\ud8c8\udc77\ud86d\udf95\uda29\uddb6\udb45\udf32\uda46\udcd3\u914b\ud92d\udf2b", "\ube7f\ua806\u26f0\u7add\uc0ba\uc1bc\ub79d\u5335\u2141\u8076\u2217\u2c07\u8792\u36c8\u8b89\ua8fd\u0a4b\u2a1e\u6408\u1038\u9200\ud70d", "\ud811\udda4\udada\udf9f\udb66\ude86\udb6c\udf36\udacd\udc19\u3994\ud932\udd3f\ud8ac\ude94\udacb\udf3b\uda1c\udc47\u56fc\ud827\udca5\ud8ca\udfb5\ud8ad\udf42\udb60\udf9e\udbeb\udf40\ua4da\uda97\uded3\uda90\udc78\ud84f\udc7e\udb1c\udc81\uda70\udf26\ud98b\ude12\udbf9\udedc\udb31\udf52\udb79\udf0e\u443a\udbcb\udd7b\uda11\udcca\ud92c\udf5a\udb0b\uddf0\ud94b\udd1d",
        55, 49313, 1128456540, -1020228438572007678L, -60852L, false, false, (char) 55887, (char) 62737,
        Double.longBitsToDouble(0x3fed6992bc913da1L), Double.longBitsToDouble(0x3fcb686dd7e77ca4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 14, "\uda34\ude00\udb16\udf7c\ud971\uddd1\uda46\udd5c", "\ubb7f\u1794\u24f9\u983f\u1fb8\u7742\u97d0\u509d\u07cd\ua682\ubed1\u55d4\u351f\u5bf7\u2172\u4c11\u0d9d\ud5c5", "\u020e\ud9a6\udefc\ud808\udf35",
        25, 46697, 1454918624, 2769701625255498546L, 93116L, true, true, (char) 8283, (char) 33615,
        Double.longBitsToDouble(0x3fed929a82dee2deL), Double.longBitsToDouble(0x3fdf066c92f9d496L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 11, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10\udb24\udc91\uda2a\udfa9\udb94\udcdc\udb2a\ude71\ud9ff\udcde\ud87d\ude53\ud8ed\udfaa\ud9af\udf28\ud9d0\udd61\ud9c6\udd2a\ud95a\udd0b\udae7\uddbe\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaad\udc1a\ud92d\udf2b\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7", "\uc1bc\ub79d\u5335\u2141\u8076\u2217\u2c07\u8792\u36c8\u8b89\ua8fd\u0a4b\ucbc7\ub376\u4eea\u5324\ubf60\u409d\u0911\ubb0d\u2336\uce45\uc93b\u12bf\u0566\u198f\u3487\ucf32\ua864\ua3ad\u6fa9\ucc88\u84ac\u267c\ud11b", "\udb38\ude23\uda74\udd6e\uda48\udfd8",
        25, 95474, -471676751, -3701072821150871989L, -6110L, false, false, (char) 41896, (char) 8619,
        Double.longBitsToDouble(0x3fe402b1cd66414dL), Double.longBitsToDouble(0x3fcf4125154ccda0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211", "\udb7a\udd4b\uda09\udd2c\ud95a\udd0b\udb57\udd93\udb5d\udd49",
        3, 4814, 537332673, -5612707569998219679L, -4501L, false, true, (char) 12569, (char) 61685,
        Double.longBitsToDouble(0x3fef042dccf4cfe6L), Double.longBitsToDouble(0x3fe4a70b7f3cfbeaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 11, 12, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u49d8\u0135", "\udbc2\udcc6\ud828\ude68\ud98d\udfa7\ud88b\udda8\udb7a\udf9c\ud912\udc47\ud896\udd4e\uda24\udfeb\udab4\udf9b\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud94b\udd0a",
        33, 61796, 684909628, 7347326319986839359L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ff4L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 3, 3, "\uda42\ude1b\ud913\udfd9\uda86\udcbf\ud9e8\udd4d\ud8f2\udc2c\udbd8\udc64", "\u243f\u9178\uc9be\u1188\u636b\ub5e9\u27c9\u685a", "\udb19\udd52\ua49f\ud9be\udcc0",
        6, 99029, 333239734, -3386998956245656891L, 93104L, false, true, (char) 57497, (char) 39377,
        Double.longBitsToDouble(0x3fe4de5b7f3cfbeaL), Double.longBitsToDouble(0x3fe2e146924efc90L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 6, "\udad2\udc03\udb34\udffd\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10\udb24\udc91\udb31\ude8c\udb93\udff1\udb2a\ude71\ud9ff\udcde\ud87d\ude53", "\u49d8\u2350\u8a32\u5c6f\u4100", "\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\ud92d\udf2b\u285a\uda51\udecf\uda57\ude93\udb98\udc3a\udb29\udd24\ud867\udff0\udba2\udf26\ud967\ude56\udb68\udda3\ud904\udc5e\udb2e\udd64\ud9d4\udd08\ud8c6\udf63\ud867\udfe9\udbc9\udc9b\udb23\udeaf\udbe9\udd35\udaaf\udcc3\ud9aa\udc90\uda36\udcfe\ud98b\udeb3\ud821\udd5f\ud9b6\ude0b\u589b\uda25\ude0c\uda8c\udf41\uda90\udd86\uda67\udd52\uda29\udec5\ua73b\ud904\udd20\ud8d5\ude44\ud829\udfd5\udaef\udf1e\ud898\udf77\ud9e5\uded9\ud8e5\udc39\ud915\udede",
        19, 8017, 1132268701, -6981662409542261188L, 69957L, true, false, (char) 44033, (char) 15583,
        Double.longBitsToDouble(0x3f893fb3957037c0L), Double.longBitsToDouble(0x3fb7176d0cf3b300L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u49d8\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\ud92d\udf2b\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud920\udd0a\udba2\udf26\ud967\ude56\udb68\udda3",
        36, 31423, 1941053271, 6003315179761614354L, 15194L, false, false, (char) 29375, (char) 4730,
        Double.longBitsToDouble(0x3fa578fd0b267400L), Double.longBitsToDouble(0x3fdd2a499ec851b8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 3, "\000", "\u7781", "\udb24\udc91\uda2a\udfa9\udb81\udfdc",
        55, 1424, 0, 815595520L, 73449L, false, false, (char) 69, (char) 0,
        Double.longBitsToDouble(0x3fee2eb800002007L), Double.longBitsToDouble(0x3e49c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 10, 10, "\ud8bd\udef3\uda8c\udc55\uda66\ude58\udabc\udd57\udbe5\udec5\udaf6\udc10\udb24\udc91\ud9bb\udfcd\ud91e\udf8f", "\u4b6d\u84ac\ub5e9\u97ed\u4774\u0f77", "\udb6f\ude66\udaaa\udd85\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\ud92d\udf2b\udb13\udf28\ud90c\udff4\ud956\ude4a\ud8ce\udfac\ud9ec\udf9e\ud920\udd25\udad1\ude3e\uda6b\udd56\udb68\udda3\ud8ed\udcf3\ud998\udea7\ud9ad\ude28\udb97\udc41\ud867\udfe9\udbc9\udc9b\udb23\udeaf\udbe9\udd35",
        56, 35315, 764068346, -3848606711214239979L, 22450L, true, true, (char) 25645, (char) 30503,
        Double.longBitsToDouble(0x3fc96e66f20fe6dcL), Double.longBitsToDouble(0x3fd8905eb80f55caL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 0, 8, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211\u5d29\u4da4\u019c\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\udbad\udd4b\ud97e\udde6\ud921\uddd0\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684875580, -1113530008029373911L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd9690c63236e8cL), Double.longBitsToDouble(0x3fdfd80843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 2, "\udb48\udcdf\ud98c\udf53\uda86\udc38\ud9e8\udd4d", "\u320f\u77cf\u243f", "\ud87d\ude53",
        19, 27347, -1000437020, -226989825336135954L, 30790L, true, false, (char) 49512, (char) 58227,
        Double.longBitsToDouble(0x3faa1003db6b21b0L), Double.longBitsToDouble(0x3fe386b0e4eed0c8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 10, "\uda0c\udd24\ued2e\u21a6\ud912\ude5e", "\u320f", "\udb2a\ude71\ud9ff\udcde\ud87d\ude53\udbe3\udfa5\ud91a\udd9e\u497e\ud8f6\udd22\ud819\ude4a\udae7\udd8f\udbfd\udf5b\u147a\ud900\udd82\ud801\udfb4\uda1a\udc7d\udab9\udf5f\ud9d1\udda6\ud920\udcaa\u020e\ud99a\ude70\udaf2\udc5f\ud9af\udda7\udb9b\uddd6\ud943\ude6e\udba2\udf26\ud967\ude56",
        20, 44716, 934383423, 8336760320136580953L, 96248L, false, true, (char) 50242, (char) 57612,
        Double.longBitsToDouble(0x3fd7bae843f41c5eL), Double.longBitsToDouble(0x3fd871d2e4294282L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\uda30\udc8a\udb8a\ude98", "\u243f\uc309\u5006\u5211\u62dd\ub5e9\u49d8\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udd4a\udb7a\udf9c\ud806\udf3e\udaac\udfa7\ud92d\udf2b\u020e\ud912\uddac\ud952\udf7c\ud9b5\udde0\udb49\udde0\ud920\udd0a",
        33, 61796, 684875580, 7347326319986839359L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ef6L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 1, 3, "\ud8c0\udf70\ud98c\udeec\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u3017\u905e", "\udb19\udd52\ua49f\udaed\udf14\ud9c6\udfc8\ud8cb\udcc9\ud806\udf31\udaac\udfa7\ud8fe\ude2b\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684875580, 7347326319986850879L, -96071L, false, true, (char) 575, (char) 40873,
        Double.longBitsToDouble(0x3fd7ceac63236ef6L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 1, 9, 3, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u49d8\u6dd1", "\udb19\udd52",
        43, 81885, 537332677, -5612707569998178890L, -4501L, false, true, (char) 12569, (char) 61685,
        Double.longBitsToDouble(0x3fef042dccf4cfe6L), Double.longBitsToDouble(0x3fe4a70b7f3cfbeaL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 3, "\udb48\udda9", "\u7781\u567a\ua282\u320f\u77cf\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u49d8\u2d9e\u29e7\u5c6f\uaf38\u1d95\u21ac", "\ud806\udf3e",
        0, 71622, -1282208113, -1569914635175525548L, 4412L, false, true, (char) 50394, (char) 26627,
        Double.longBitsToDouble(0x3fe9e7df525c28d2L), Double.longBitsToDouble(0x3fe9fb2fb75737b1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 14, "\ud9f8\udda1\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u49d8\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\ud92d\udf2b\u020e\ud912\uddac\udb90\ude7b\ud8ee\udce1\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684875580, 7347326319986839359L, -96071L, false, true, (char) 33412, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ef6L), Double.longBitsToDouble(0x3fd7bae849adea5eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 3, "\udb48\udda9\ud98c\udf53\uda69\udf6a\udbec\uddd1\udbcf\udd10\udb68\uddd6", "\u234e\u8cce\u41f2\u5211\u62dd\ub5e9\u49d8\u9f6d\u2150\u4def\u4719\u1d95\u21ac\u79ba\u7be2\ub410", "\ud822\udfde\uda34\udfb4\ud988\ude54",
        34, 20108, 1052492231, -2605605160089917310L, 93116L, true, true, (char) 22280, (char) 33529,
        Double.longBitsToDouble(0x3fed94b2669803a7L), Double.longBitsToDouble(0x3fe2e7b0917ceac6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 3, 3, "\udb48\udda9", "\000", "\000\ud9f0\udc37\udb94\udcdc",
        0, 1644, -659261276, 7882171501953010763L, 59398L, false, true, (char) 0, (char) 65253,
        Double.longBitsToDouble(0x3fa3f2a297507f40L), Double.longBitsToDouble(0x3fee2ebd70342007L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 9, 9, 3, "\udae6\udeff\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10\udb24\udc91\uda2a\udfa9\udb94\udcdc\udb2a\ude71\ud9ff\udcde\ud87d\ude53\ud8ed\udfaa\ud9af\udf28\ud9d3\udf61\ud9c6\udd2a\ud95a\udd0b\udae7\uddbe\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\uda6e\udc35\ud890\udd22\udaac\udf70\ud92d\udf2b\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7", "\uc1bc\u1369\u15a5\u085e\u8076\uc2e0\u4c77\u7961\u35fa\u8b89\ud43b\u0a4b\u6d48\u112b\u3ce2\u6171\u7546\u3ca8\ua7fe\u672e\u301c\u7f3f\u392a\u45a0\u1ef7\u3a04\u1f0d\ua16e\u8b80\u48ed\uccba\u40de\u128c\u3391\uc52a", "\udbda\udd51\udb5b\udf5d\ud8e3\ude5a\udab2\udcad\ud87b\udf08\ud83c\udccf\uda22\udcf1\ud8f9\udf9d\ud824\udedc\udb42\udc33\udadd\udf72\udbb3\uddbf\ud90b\udee5\ud9ce\udf08\ud919\uddcc\ud847\udd2b\ud819\udc92\ud825\udd9a\ud862\udf58\u3c18\udbde\ude5f\ud9a2\udff6\uda0e\udc1f\udb1e\udf08\ud96e\udc60\ud94c\udfa6\udb43\udd3e\ud8cf\ude52\ud8dc\udc12\udb01\udd38\ud83c\udf30\ud9c2\udcc5\udb3f\udf49\ud930\udcc3\ud90c\udd1b\udb27\ude69",
        18, 8316, 1318822813, 6392214745948416917L, 39583L, false, false, (char) 49518, (char) 24511,
        Double.longBitsToDouble(0x3feb26a162133ddcL), Double.longBitsToDouble(0x3fea91419913210cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 3, "\udb48\udda9\ud98c\udf53\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10", "\u243f\u9178\u41f2\u78a4\000\000\000\u2d44", "\udb19\udd52\ua49f\udaed\udf14\u00c5\udb7a\udf68\ud806\udf3e\udaac\udfa7\ud92d\udf2b\u020e\ud912\uddac\ud952\udf7c\ud8ce\udfac\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684851260, 7347326319986839359L, -100000L, false, true, (char) 935, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 2, "\u00e8", "", "\uda06\udcf2",
        40, 83186, 1957120509, 2252804487046400L, -100000L, false, false, (char) 8448, (char) 6403,
        Double.longBitsToDouble(0x3fef77e6ca77cf0aL), Double.longBitsToDouble(0x3fe731bd48000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "", "\u9cd9", "\udaf6\udc10",
        50, 83186, 1957120509, -574091399583832612L, -40920L, true, false, (char) 8810, (char) 6403,
        Double.longBitsToDouble(0x3fef77e6ca77cf0aL), Double.longBitsToDouble(0x3fe731bd4c27e545L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 15, "\udb48\udda9\uef54\uda86\udc38\ud9e8\udd4d\ud8ae\udcea\uda3b\udd4c\udba7\uddd2\ud888\udf4f\ud9b5\udc56\udb2a\ude71\uda22\udc8f\ud91f\udf2e\ud9f8\udef4\udb2c\udecd\udbf5\ude92\ud9be\ude18\ud95a\udd0b\udae7\uddbe\udb19\udd52\ud8c8\udc77\ud86d\udf95\uda29\uddb6\udb45\udf32\uda46\udcd3\ud813\udcdf\ud92c\udeb0", "\ubeb2\u600e\u26f0\u7add\uc0ba\uc1bc\u4e93\u2615\u2141\u8076", "\udbc9\udc9b\udb2b\udc6c\udbe9\udd35\udaaf\udcc3\u2a51\udbe1\udf32\ud9a3\udffd\udb08\ude94\ud991\ude99\ud8c4\ude07\uda02\ude77\ud9ad\udded\ud811\udda4\udada\udf9f\udb66\ude86\udb01\ude2a\ud9de\udc05",
        22, 92097, 847167330, -3572179678458124053L, 47024L, true, false, (char) 30847, (char) 35732,
        Double.longBitsToDouble(0x3fda682389f9f0d8L), Double.longBitsToDouble(0x3fe3e4ff8a5909bcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 3, "\udb48\udda9\uef54\uda86\udc38\ud9e8\udd4d\udbe5\udec5\udaf6\udc10\ud9ad\ude35\uda2a\udfa9\udb94\udcdc\udb2a\ude71\ud9ff\udcde\ud9ea\udc84\ud9f8\udef4\udb2c\udecd\udbf5\ude92\udb3c\uded8\ud95a\udc89\udae7\uddbe\udb19\udd52\ud8c8\udc77\ud86d\udf95\uda29\uddb6\udb45\udf32\uda46\udcd3\u914b\ud92d\udf2b", "\ube7f\ua806\u26f0\u7add\uc0ba\uc1bc\ub79d\u5335\u2141\u8076\u2217\u2c07\u8792\u36c8\u8b89\ua8fd\u0a4b\u2a1e\u6408\u1038\u9200\ud70d", "\ud811\udda4\udada\udf9f\udb66\ude86\udb6c\udf36\ud844\ude55\udbe9\ude42",
        7, 75664, 1151781680, -4998111177355102673L, -25419L, true, true, (char) 64307, (char) 23016,
        Double.longBitsToDouble(0x3fcc97b8fd090cd8L), Double.longBitsToDouble(0x3feb17c579b08ab8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 15, 15, 12, "\udb48\udda9\ud98c\udf53\uda78\udf72\uda84\udc20\udade\udd91\udb17\udc7f", "\u243f\u9178\u41f2\u5211\u62dd\ub5e9\u49d8\u0135", "\ud9ae\udc91\ud828\ude68\ud98d\udfa7\udb91\udcfd\uda8c\ude0f\ud9de\udc8b\ud87f\udd54\uda0f\udc7a\udab4\udf9b\ud912\uddac\ud952\udf7c\udb20\udfb5\ud982\udca9\ud94b\udd0a",
        33, 61796, 684909628, 7851729478252334911L, -96071L, false, true, (char) 63753, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ff4L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 15, 3, 3, "", "\u9d60\u7781", "\000",
        22, 42509, -133666070, 8991126438565419684L, 17835L, true, false, (char) 14733, (char) 30619,
        Double.longBitsToDouble(0x3fc705a140000000L), Double.longBitsToDouble(0x3fa3f28042f07f40L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000", "", "",
        -5, 32704, 114, -134217728L, -100000L, false, false, (char) 0, (char) 12445,
        Double.longBitsToDouble(0x3e1ddf8000000000L), Double.longBitsToDouble(0x3e84000000000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 0, 4, 12, "\000", "\ub651", "\udb24\udc91\u73a3\udb81\udfdc\udb2a\ude71\ud9fd\udc40\u5ab3\u03fe\ud97c\udedd",
        2, 55226, -821396498, 4010836410302332646L, 25259L, false, true, (char) 15524, (char) 0,
        Double.longBitsToDouble(0x3fe38000010f56beL), Double.longBitsToDouble(0x3fe6ef4dacc08b1bL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 3, "\000", "\u18ce", "\udb24\udc91\uda2a\udfa9\udb81\udfdc\udb2a\ude71",
        9, 24400, 11697436, 3502956083145186560L, -654L, true, false, (char) 13967, (char) 33683,
        Double.longBitsToDouble(0x3fe80003f3c5d700L), Double.longBitsToDouble(0x3f20038000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 8, "\000", "\uc8f0", "\udb24\udc91\uda12\udfa9\udb81\udfdc\udb2a\ude71\udbff\udd02\ud82d\udcd5\ud8be\udd46\ud9b5\ude88\ud9d0\udce8\uda57\udee4\udb4d\ude12\ud820\ude2e\udb3f\udfe6\ud832\udec7\ud9e1\udefe\ud88b\udd49\uda7e\udd08\ud864\udf45\udbbf\udcd0\ud9f7\udd09\u0bbd\uda97\udf1f\ud91d\udcc3\udb64\udfd7\ud8bc\udd18\udbfd\ude46\ud8dd\udd22\udaf2\udcc5\udbe6\ude7d\udbe5\udc6f\udb8e\udf2b\udaf2\udd76",
        54, 55085, -709613452, -5992395371890822024L, -13692L, false, true, (char) 63931, (char) 36260,
        Double.longBitsToDouble(0x3fc8c7bf5bfbdc3cL), Double.longBitsToDouble(0x3fe2dae6b8c373f1L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.cli.DefaultParser:@?\0121=null |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 3, 3, 3, "\000", "\u4d81", "\udb24\udc91\uda2a\udfa9\udb81\udfdc",
        55, 48432, 1249006683, 503326769152L, 10217L, false, false, (char) 41695, (char) 37934,
        Double.longBitsToDouble(0x3fee493870167f07L), Double.longBitsToDouble(0x3e49c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 13, 13, 4, "\udb47\udddf\ud98c\udf53\uda86\udc38\ud951\udd05\ucbee\udaf6\udc10\udb24\udc91\udb7c\udd51\udb94\udcdc", "\u7ea8", "\ud865\udf64\uda30\ude44\ud873\udce1\udae7\udd74\udb19\udd52",
        43, 81885, -686248730, -631662477736437496L, -72266L, true, true, (char) 31820, (char) 22506,
        Double.longBitsToDouble(0x3fd0a2a1583faf98L), Double.longBitsToDouble(0x3fc4711c692843dcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 3, "\udb48\udda9\ud98c\udf53\udaf0\uddae\ud9e8\udd4d\uda19\udd1f\udaeb\udfaa", "\u243f\u9178\u41f2\u1bf6\u62cf\ub5e9\u49d8\u2d9e", "\udb19\udd52\ua49f\udaed\udf14\ud88b\udda8\udb7a\udf9c\ud806\udf3e\udaac\udfa7\udb88\ude19\u020e\ud912\udd17\uda7d\udfba\ud8fb\udd1e\ud8fc\udca7\ud920\udd0a",
        33, 61796, 684875580, 7347326319986839359L, -96071L, false, true, (char) 575, (char) 62977,
        Double.longBitsToDouble(0x3fd7ceac63236ef6L), Double.longBitsToDouble(0x3fd7bae843f41c5eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.cli.DefaultParser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 2, "\ud85b\udcaa\ud98c\udc63\u280c\ud9e8\udd4d", "\u1872\u78c6\u2357\ucaa7\u7eaf\u02eb\u62dd\u481f\u3c37\u2e39\ua5b2\u5c25\uaf38\u1d95\u6457\u13ba\u7be2\ub410\u0414\ud1ff\u0522\u2af5\u15af\u4e4b\u7cc9\u5212\u1d74\u728c\u1bc5\u9552\u739a\u4e19\u688c\u38fe\u513b\u1849\u37ab\u362d\uc2c9\u622a\u0a95\u3dba\u16d9\ub43b\u777b\u9281\ub340\ubad1\u6e1e", "\ud840\ude20\uda5f\udd1c\ud8b6\udc1f\udb84\udd63\udaaa\udc3f\udb3f\uddbd\udbbc\udc29\udbdf\udc2a\uda08\udda6\udaa0\udf37\ud93c\uddae\uda16\udf57\ud9bc\udd75\ud89a\udeb9\uda59\udd25\udbcd\udebc\ud8c2\udc36\udac0\udca8\ud9c4\udc62\udbc5\udd87\ud871\udfda\udba6\udfbc\uda9d\udd96\udafc\uddbd\ud8ca\udf8d\ud8ca\uddca\ud839\ude4c\ud981\udc69\ucd18\uda48\udf7e\ud999\udcd8\udae6\udeaf\udb63\ude9a\ud87b\udc92\udaf9\udddc\ud9fa\uddc9\udae9\uded6\ud874\udc74\ud82f\udcf3\ud844\udc73\udba6\udd18\ud8ae\udec6\ud996\ude63\uda8d\udd8f\udb8c\udf74\udb4f\udf90\ud90a\ude68\ud8d6\uddde\uda0c\udf8c\uda10\udfd3\ud948\udc71\ud985\udf69\udbb2\ude99\uda3f\udcbc\uda24\udf24\ud828\udfaf\ud8e8\udc8f\ud8de\udebb\uda25\udfcd\ud98b\udca5\ud81d\udee1\ud974\udce1\ud896\udf9b\udb7d\udd5f\ud904\udc45\udac4\udecb\ud949\udead\ue519\udbf6\uddc7\udb77\udcda\udbf9\udfae\uda5e\udd95\udb06\udc68\udbaf\ude06\uda80\udeb5\ud9e6\ude12\ud8cb\udc41\ud964\udfce\uda1b\ude6c\udb70\udd8c",
        55, 36656, -1082026413, 6814496789244979800L, 38922L, false, false, (char) 54192, (char) 61076,
        Double.longBitsToDouble(0x3fea87ad48129e9eL), Double.longBitsToDouble(0x3f7733328ded1480L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.cli.DefaultParser:@?\0121=void |this=org.apache.commons.cli.DefaultParser:@?\012",
        Z.run(T, 2, 4, 4, 12, "\000", "\ub651", "\udb04\udfaf\u73a3\udb81\udfdc\uf3fa\ud9fd\udc40\u5ab3\u03fe\ud97c\udedd\ud9d0\udd41",
        16, 35502, 933845846, 19702037188968448L, 77356L, true, false, (char) 0, (char) 46818,
        Double.longBitsToDouble(0x3fd0f56635bbd36aL), Double.longBitsToDouble(0x3fc811637caf5db0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredArgs||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|checkRequiredOptions||new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|getLongPrefix|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleConcatenatedOptions|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleLongOptionWithoutEqual|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleOption|org.apache.commons.cli.Option|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleProperties|java.util.Properties|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleShortAndLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|handleUnknownToken|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isArgument|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isJavaProperty|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isLongOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
    "M|org.apache.commons.cli.DefaultParser|isShortOption|java.lang.String|new:org.apache.commons.cli.DefaultParser:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
