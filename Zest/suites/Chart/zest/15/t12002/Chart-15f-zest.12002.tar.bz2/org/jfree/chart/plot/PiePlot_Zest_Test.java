package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class PiePlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u3ef4\u41b1\u2fd0\u4202\u592d\ud2c0\u3c75", "\ud815\udffa\ud975\udd67",
        35, 46600, 850154766, 149466391609175635L, -69298L, false, false, (char) 5335, (char) 28646,
        Double.longBitsToDouble(0x3fdeb995d496348aL), Double.longBitsToDouble(0x3fcac2b2d2c88a08L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 0, "\uda22\uddfb\ud8b9\udfc5\udba3\ude30\ud974\ude20\uda72\ude80\uda0e\udfc8\ud8b8\ude1e", "\u4830", "\uda24\uddf9",
        10, 65308, 1319480089, 5511599794619049963L, 70209L, false, false, (char) 6082, (char) 34816,
        Double.longBitsToDouble(0x3fe7219566530213L), Double.longBitsToDouble(0x3fc82537204ac59cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 8, 15, "\ud865\udef9\ud92b\udd1e\000\uda87\udfc3\uda72\ude80\ud8e1\udcc6\ub900", "", "",
        -5, -1000, 1768965120, 2630910852399672089L, 57675L, false, false, (char) 52147, (char) 52893,
        Double.longBitsToDouble(0x3fdf8009ca1cf418L), Double.longBitsToDouble(0x3fe7219560530213L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 12, 16, 15, "\ud82e\udf97\ud92b\udd1e\ud9b4\ude5f\udbe8\udd9a\uda05\udf40\ud906\ude84\ud8ff\udc4c", "\ua69d\u41b1\u3b12\u72d5\u31fb\ud275\uc39c", "\ud815\udffa\ud975\udd67",
        35, 70664, 850154766, 8406816308438366782L, -40114L, false, false, (char) 5466, (char) 28646,
        Double.longBitsToDouble(0x3fdeb995d4574264L), Double.longBitsToDouble(0x3fcac2b2d2c88a08L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u9e84\u41b1\u2fd0\u4202\u592d\ud2c0\u3c75", "\ud815\udffa\ud975\udd67",
        35, 46600, 850154766, 149466392501015885L, 37749L, true, false, (char) 25196, (char) 34612,
        Double.longBitsToDouble(0x3fcb67db8b628dc0L), Double.longBitsToDouble(0x3fdccd55b8c6bc18L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 15, 15, 15, "\ud865\udf1a\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\udaf0\udf2e\udb05\udd2a", "\u3ef4\u41b1\u2fd0\u4202\u592d\ud2c0\u3c75", "\ud815\udffa\ud975\udd67",
        35, 46600, 850154766, 149466391609175635L, -69298L, false, false, (char) 5335, (char) 28646,
        Double.longBitsToDouble(0x3fdeb995d696348aL), Double.longBitsToDouble(0x3fc702a91242abfcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 15, "\ud8b5\ude7a\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\udb3f\udf01", "\u3ef4\u41b1\u2fd0\u860c\u59e3\ud2c0\u3c75\u74a0", "\ud975\udd67\udb39\udd82\ud8f3\udd29\ud9d0\udc0a\ud900\udf03\ud9c8\udcc8\ud8fb\udc1f\udb70\udfd9\ud8d6\udea2",
        -3, 1843, 440788459, 1555503611772030166L, -30393L, false, true, (char) 50340, (char) 46290,
        Double.longBitsToDouble(0x3fd4b5cc5c2d2bcaL), Double.longBitsToDouble(0x3fc937da9deb3254L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 16, "\ud865\udef9\udb66\udc7c\udab9\udf52\uda37\udc2d\uda72\ude80\ud8e1\udcc6\uda76\ude1d\ud9dd\udd7b\ud982\udeae\udbfb\ude8d\uda28\udfa3\ud92e\udf58\uda24\uddb1\udac0\ude6c\udb46\udda1\ua4f9\ud91e\udf5b\ud815\udfb6\ud903\udff1\ud975\udd67\udb39\udd82\ud8f3\udc88\ud898\uddb8", "\u839a\ud336\u88eb\u6a4e\uc616\u10d5\ua3e0", "\uda9b\udc21\udb62\udd2b\udbad\udd42\ud9d6\ude29\ud8fd\ude1d\ud83a\udd20\udbb9\ude1a\ud86a\udeaa\uda95\uddc0\ud832\udc4e",
        54, 94080, 1812636350, -4528546428672416667L, -75095L, false, true, (char) 45091, (char) 2483,
        Double.longBitsToDouble(0x3fe1e60e14aa7ffaL), Double.longBitsToDouble(0x3fdbab678b2c673cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 0, "\ud865\udf23", "\u65c0\u53bc\u4924", "\ud982\udeae\udb45\ude13",
        45, 93595, -2144544382, 7597647571566845819L, 91819L, true, true, (char) 5773, (char) 45202,
        Double.longBitsToDouble(0x3fdd64cc8bf16d38L), Double.longBitsToDouble(0x3fd0e7a0c5c86558L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 11, 15, "\ud865\udef9\udaf9\udda6\ud900\udd11\ud974\ude45\uda72\ude80\ud8e1\udcc6\uda64\udf73", "\u0497\u9d9c\uc4e9\u0462\u254f\u673f\uc557\u94af\ub242\u4be4\u4def\uadb5\u4663\u5d8e\u456a\u45c7\u839a\ud336\u913c\u8c54\u05a9", "\uda65\udede\udb70\udf9c\uda8c\udd87\udaa2\udf5a\uda56\udc2b\udaf2\udeb8\udb50\udc93\ud919\ude92\ud975\ude8b\ud9c3\udf4f\u416b\ud9ed\udc83\ud96c\udddc\ud883\udf63\ud985\udf3b\udbc2\udf61\u9b7c\ud9a2\udf11\ud90b\udcdb\ud801\udeac\uda17\udc41",
        8, 9821, -143847282, 4105021657132863437L, 50328L, true, true, (char) 53126, (char) 63985,
        Double.longBitsToDouble(0x3fe1ab9be5596045L), Double.longBitsToDouble(0x3fd4bec8ba7b4beaL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 0, 8, 0, "\udb55\udf71", "\u65c0\u00a0\000", "",
        -5, 22772, 3338765, 8681251231712991618L, -99877L, false, false, (char) 0, (char) 46170,
        Double.longBitsToDouble(0x3e1c267680000000L), Double.longBitsToDouble(0x3ec9140000000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 2, 16, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u3ef4\u41b1\u2fd0\u4202\u592d\ud2c0\u3c75", "\ud950\ude37\ud975\udd67",
        35, 70048, 850154766, 149466391609175635L, -69298L, false, false, (char) 52438, (char) 28881,
        Double.longBitsToDouble(0x3fe75ccaea3c14fdL), Double.longBitsToDouble(0x3fc1e55ef2c88a08L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 15, 9, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u3ef4\u41b1\u1c76\ua449\u1e2e\u915b\u3c7a", "\ud815\udffa\ud975\udd67",
        35, 60008, -197372658, 5626668459978813137L, -69298L, false, false, (char) 5335, (char) 28646,
        Double.longBitsToDouble(0x3fa7ccaea4b50e90L), Double.longBitsToDouble(0x3fcac2b2d2c88a08L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 0, 8, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud94c\udc20\uda72\ude80\ub34d\uda76\udda4", "\u3ef4\u41a4\u2fd0\u4202\u592d\ud2c0\u3c75", "\ud815\udffa",
        28, 32870, 2047620600, 3651386916543333092L, -22221L, true, true, (char) 23696, (char) 25196,
        Double.longBitsToDouble(0x3fc6445048a39eb8L), Double.longBitsToDouble(0x3fcdff510bf16158L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 16, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud8d5\uddf1\uda72\udeb4\ud8e1\udcc6\uda76\ude1d", "\u3ef4\u41b1\u2fd0\u4202\u592d\uc7c9\u5375\u74a0", "\ud975\udd67\udb39\udd82\ud8f3\udd29\ud810\udc54\ud900\udf03\ud9c8\udcc8\ud8fb\udc1f\udb70\udfd9\ud8d6\udea2",
        -3, 1843, 440788459, 2849600211355273482L, 20653L, true, false, (char) 62548, (char) 26356,
        Double.longBitsToDouble(0x3fdd535e97a1b1aaL), Double.longBitsToDouble(0x3fd9bf36028fdf40L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 15, 16, 15, "\uda75\udffd\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\udb2c\udc1a\uda76\ude1d", "\u3ef4\u41b1\u1c8d\u9270\u58f8\ub98d\u0921", "\ud815\udffa\ud84d\udca5",
        38, 46600, 1798831118, 7499339217709421917L, -69298L, false, false, (char) 5335, (char) 28646,
        Double.longBitsToDouble(0x3fdeb995d4977c14L), Double.longBitsToDouble(0x3fcac2b2d2bc8a08L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 12, 3, 15, "\udb9c\udf81\ud915\udd77\u78f3\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u3ef4\u445c\u2fd0\u4202\u592d\ud2c0\u3c75\u6c9f", "\ud975\udd67\ud9c2\udc19",
        34, 36766, 1170679524, 3006506290184190145L, -22221L, true, true, (char) 23696, (char) 25196,
        Double.longBitsToDouble(0x3fc644504b36512cL), Double.longBitsToDouble(0x3fd1a69a8aa6dd42L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 12, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u3ef4\uceb0\u2fd0\u1274\u592d\ud2c0\u35c2", "\uda56\udeba\ud975\udc86",
        22, 46600, 850158862, 6706707446376263251L, -69298L, false, false, (char) 5335, (char) 28646,
        Double.longBitsToDouble(0x3fddfde95496348aL), Double.longBitsToDouble(0x3fe94b9434d28f30L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 10, 7, "\ud865\udef9\ud84e\udf5a\u7962\ud974\ude20", "\u4646\u43d7", "\ud83f\ude0e\uda70\udc1e\uda24\uddf9\udac0\ude6c\udb46\udda1\ud915\udd8d\ud84f\udf3f",
        20, 5150, 1288214753, -5288209104269199880L, 97348L, true, false, (char) 8826, (char) 14713,
        Double.longBitsToDouble(0x3fa95c33b7729600L), Double.longBitsToDouble(0x3fee9a009deb995dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 16, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\000\000\uda76\udda4", "\u3ef4\u1a0e\000\000\000\000\uc897", "\u630c\ud975\udd67",
        35, 54352, 0, 0L, -69298L, false, false, (char) 5335, (char) 28646,
        Double.longBitsToDouble(0x3fdeb9900496348aL), Double.longBitsToDouble(0x3f15960000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 0, "\000", "[", "\000\ud9dd\udd7b",
        47, -1000, 0, -2144544382L, 88283L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3d16800000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 16, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\ud9c6\ude65", "\u5520\u41b1\u2fd0\u4202\u5f0a\ud2e9\u3c75", "\ud815\udffa\udabb\udea3",
        1, 46600, 850154766, 6706707449060617903L, -69298L, false, false, (char) 5335, (char) 28646,
        Double.longBitsToDouble(0x3fdeb995d496348aL), Double.longBitsToDouble(0x3fcac2b2cec88a08L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 11, "\ud865\udef9", "", "\ud8e1\udcc6",
        37, -1000, 971290437, 2072883828459893261L, -44318L, false, false, (char) 27115, (char) 0,
        Double.longBitsToDouble(0x3e4fad31bc000000L), Double.longBitsToDouble(0x3fcdd7cc4384ced0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 12, 12, "\uda24\ude0b\u5bd7\udb74\ude7c\ud8f2\udfac\uda72\uddff\ud8f4\udc28\uda76\ude1d", "\u3ef4", "\uda6a\udc0a\ud9ec\udc25\uda32\udf7c",
        2, 45625, -1925143889, 6276816777058490615L, -22221L, false, true, (char) 23696, (char) 13370,
        Double.longBitsToDouble(0x3fdc9228217fbe3aL), Double.longBitsToDouble(0x3fd8d9b714186046L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 15, "\ud86e\uded2\ud92b\udd1e\u7962\ud974\ude20\ud877\udd09\ud8aa\ude15\ud859\udcce\ud9dd\udd7b\ud982\udeae\udbfb\ude8d\ud83f\ude0e\uda70\udc1e\ud960\udfb6\ud95e\udf0d\udb46\udda1\ud915\udd8d\ud865\ude8a\ud81f\udc0d\ud815\udffa\ud941\ude0d\udb39\udd3e\ud81f\udc2e\ud9d0\udc0a\ud900\udf03\ud9c8\udcc8\ud8fb\udc1f\ud8cf\uddc7\ud99c\ude73\udac9\udec6\uda32\uddc6\ud953\udf77\uda9c\udf90\uda65\udede\ud9b1\uddbd\ud9a0\udce4\ud87e\udd40\udac6\udee8\ud961\udce5", "\u39fc\u6242\u4953\u8f89", "\udaec\udef3\ud9cf\uddfe\udbe7\udee0\ud8a0\udd95\udab1\udf2c\udaea\udf05\udb46\udf22\ud92d\udeba\uda42\udd57\udb14\udece\udb20\ude1d\udb37\udcaa\udb25\udcdc\udaf5\ude8d\ud8da\udd3d\ud9f1\udec6\udb36\udc16\ud953\udfa0\ud9b4\uddc2\uda7d\udf6e\ud8ac\udc3d\uda43\ude6e",
        58, 636, -1983741392, 692503683275718610L, -99360L, false, true, (char) 21524, (char) 64447,
        Double.longBitsToDouble(0x3f6cf41806ce4c00L), Double.longBitsToDouble(0x3fe37752d7151dfcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 3, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u3ef4\u41b1\u9966\u5349\u592d\ud2c0\u92f9", "\ud815\udffa\ud975\udd67\udb39\udd82\uda01\udc8d\ud943\udce8\ud900\udf03\ud9c8\udcc8",
        50, 17490, 694210610, 2546481533936283603L, 48043L, false, false, (char) 29710, (char) 28942,
        Double.longBitsToDouble(0x3fe6fe19523fac11L), Double.longBitsToDouble(0x3fd7c8075bf88c6aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 16, 3, "\ud801\ude1b\ud92b\udd1e\u7962\ud860\ude10\ud930\udc1c\ud80a\udf01\ud983\udfb6\udafe\udc2b\uda35\udee1\u4216\ud83f\ude0e\uda70\udc1e\ud821\ude3f\udade\udcb6\udb46\udda1\ud915\udd8d\ud865\ude8a\ud81f\udc0d\ud8bc\uddee\ud975\udd67\udb39\udd82\ud8f3\udd29\ud9d0\udc0a\ud900\udf03\ud8e8\udc79\ud8fb\udc1f\udb5b\udcd9\ud8d6\udea2\udac9\udf3d\uda32\uddc6\ud953\udf77\uda47\udd46\u5736\udbe0\udeed\ud8c9\ude7c\ud9b8\udc60\udb56\udd51\udbad\udfbb\ud8ed\uddd8\udaaf\udcaa", "\u2b7f\u5d8e\u86f1\u39ba\ub28f\uc8b3\u9ecf\u9f17\u5b26\u70eb\u0a07", "\ud884\udd04\ud9a7\udda6\ud9da\ude38\u2bc7\udb64\udf59\uda0a\ude4c\udad2\udda0\udb91\udd17\uda33\udfb0\ud930\ude5f\ud80c\udf69\ud983\udf99\uda3e\udcc4\ud9f2\udf95\udbbd\udd2f\udb7a\udfde\udb2b\udd87\udb05\udcb5\ud850\udd73\uda9e\udcc1\u3763\ud99d\udc7e\udaf2\ude95\uda5c\udcc8\uda20\udc8d\uda75\udcf2\udae1\udf06",
        12, 21764, 518672548, -1319104204890569796L, 15398L, false, true, (char) 55736, (char) 5399,
        Double.longBitsToDouble(0x3fe18f8eb755fe03L), Double.longBitsToDouble(0x3fe6b7f934edc83cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 15, "\ud94a\udd28\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u999e\u4661\u2fd0\u4202\u592d\uc5b8\uac77", "\ud815\udffa\ud975\udd67\udaa3\udd96",
        38, 36766, 34800356, 3006555527689271489L, 3588L, true, true, (char) 8422, (char) 6662,
        Double.longBitsToDouble(0x3fe8d2d894d615cfL), Double.longBitsToDouble(0x3fc644504c56cab0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 12, "\ud865\udef9\ud92b\udd1e\u7962\ud934\udd82\udb92\udf51\udb59\udca1\udbf3\udfa9", "\ud203\u41b1\u2fd0\ud4c2\ub3fb\u9ffc\u90cc\u74a0\ud691\ubde8\u78e5\u6da8\u470d\uc11c\u3d57\ucf2a\u839a\ud336\u913c\ucf25\ubf11\uc1d8\ua3e0\u4608\u84e7\u8d67\u5ae1\u53a2", "\ud90e\ude28\udb6d\udfa2\ud9a5\udc88\udb84\udc35\ud8d0\udc59\udb75\udf23\uda5c\uddf5\udab4\udc13\udbe4\udcb6\udbc1\udd46\ud868\udd9d\ud81e\udee9\ud9f2\udc87\u7857\ud967\ude4f\uff28\udb73\udc53\uda38\udd43\udb9f\udf48\ud938\udfc9\ud928\uddf9\udb07\udc07\ud84d\udeac\udafb\udf6c\ud962\udf22",
        55, 14635, -1913463859, 3521975756510638549L, 91351L, true, false, (char) 6123, (char) 10879,
        Double.longBitsToDouble(0x3fe84ccee0cb0d12L), Double.longBitsToDouble(0x3fe6c5cf1e258de0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 11, "", "\u2b55", "\000",
        -5, -1000, 971290368, 2017714731887030797L, -100000L, false, false, (char) 0, (char) 43800,
        Double.longBitsToDouble(0x3fe0494d28004c6fL), Double.longBitsToDouble(0x3e1c267680000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud95c\uddb9\uda26\udf3b\ud81d\uddd9\ud97b\ude67\udb98\udd18\ud8fe\udc14\ud85d\udd71\ud802\udcce\udb28\udf27\udbba\udc9f", "\u401a\u363e\u0552\u12af", "\ud9fd\udccb\ud954\udff1",
        -4, 46600, -1257280700, 149664817978867795L, -75026L, false, true, (char) 15209, (char) 11946,
        Double.longBitsToDouble(0x3fe76b1592632997L), Double.longBitsToDouble(0x3fef467286dd6072L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 12, 16, 4, "\ud82e\udf97\ud92b\udd1e\ud9b4\ude5f\udbe8\udd9a\udbd5\udcaa\ud906\ude0e\udaa9\udc44", "\ua69d\u41b1\u3b12\u72d5\u31fb\ud275\u6647\ubbc7\u5226\u6a36\u1be2", "\ud9d0\udc0a\ud844\uddc4\ud8fd\udcdc\ud8fb\udc1f\udbd0\uddd7\udbe4\udea9\uda11\udf41\uda32\uddc6\udad3\udc54\uda9c\udf70\uda65\udede",
        34, 39897, 1124806917, 924674520717629653L, 36425L, false, true, (char) 58631, (char) 22929,
        Double.longBitsToDouble(0x3faad7e8a95bf820L), Double.longBitsToDouble(0x3fc1606826eb14f8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 13, "\ud82e\udf97\ud952\ude1e\ud9b4\ude5f", "\u219e\uc800\u8c81\ubcee\ua69d\u41b1\u3b12\u72d5\u31fb\u0821\u619a\u74a0\u5226\u2cd2\u8a4c\ub3b7\u151a", "\ud8fd\udcdc\ud8fb\udc1f\udbd0\uddd7\uda52\udce1\udac9\udf3d\uda32\udd31\udad3\udc54\uda9c\udf70\uda65\udede\ud82d\udcbb\u7df1",
        26, 15110, -1979380937, -6967817198661138534L, -83037L, true, true, (char) 60900, (char) 57387,
        Double.longBitsToDouble(0x3fd70617fbdc13d4L), Double.longBitsToDouble(0x3fd000c29a2b3556L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 12, 2, 10, "\ud82e\udf97\ud92b\udd1e\ud9b4\ude5f\udbbf\udd85\uda87\uddf8\ud906\udde2\ud8ff\udc4c\ud91d\udcf9\ud8ae\udf81\uda49\udf71\udb11\ude17\uda3b\udeb3\udb88\udf7f\ud888\udcb2\udb46\udd56\ud9f1\udcfd\ud865\ude8a\ud80a\udd0d\ud815\udffa\ud98e\udf35\udb3a\udfe6\udace\udde2\ud90b\udf78\uda44\udc5b\ud8fd\udd3d\ud8fb\udc37\udbd0\uddd7\udb90\ude78\udbcc\udc62\uda04\udfac\udad3\udc54\ud9a2\udce5\ud8ee\udc30\udb6a\udfd4\uda8d\udd4d\uda2d\udd87\ud813\udd09\ucd17", "\u3eec\ubc15\u600a\u9fe1\u978c\ud667\u85c6\u1882\u7b4b\ub04e\ud2d1\u0841\u62df\u0090\u7f46\u0bbe\u009f\ua903\u92a4\u20bf\u4589\u75d7", "\ud992\udd27\ud903\uddbc\ud8eb\udc1d\ud820\udcb8\udb3d\udd2f\ud8a1\udf6b\udb87\udcfc\uda4c\udf8c\ud9f3\udc6c\uda49\udfda\udb5e\udfda\ud83d\udfe5\udb23\udfa5\udac0\udf42\uda13\udf93\udb27\udfd8\u0b98\udb82\udda1\udb09\udfe2\ube09\udb98\udd15\ud8b5\udec9\ud8bd\udee2\ud842\udd23\uda46\udda5\ud921\udc7e\udbd8\ude8d\ud8c0\udcc4\udb3e\udf46\ud8c4\udc17",
        51, 79575, 1720766232, -4491439691046692353L, 1005L, false, true, (char) 41018, (char) 39893,
        Double.longBitsToDouble(0x3fa884e88a0b4b90L), Double.longBitsToDouble(0x3fda7ca2fcc0aaaaL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 16, 16, 15, "\ud85f\ude75\ud960\udd96\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\ubfff\u0604\u2fd0\u4202\u592d\u2733\u29c1", "\ud815\udffa\uda18\udfba",
        35, 46600, 850154766, 149466389195904333L, -69467L, false, false, (char) 5335, (char) 28522,
        Double.longBitsToDouble(0x3fedd21c01a56f63L), Double.longBitsToDouble(0x3fcac2abfa5cb608L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 7, "\uda1b\ude2a\u638b\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d\ud9dd\udd7b\ud982\udeae\udabf\udf8c\ud83f\ude0e\uda70\udc1e\uda24\uddf9\ud8a1\udf7d\udb31\udc8e\udb9d\udd27\ud865\ude8a\ud81f\udc0d\ud815\udffa\ud975\udd67\udb39\udd82\ud8f3\udd29\ud931\udc9b\ud926\udd01\ud9a6\udee4\uda67\udd87\udb70\udfd9\ud941\udda8\uda97\udf73\ud96a\udc0c\ud953\udf77\udbb2\udc7a\ud923\udc27\udbd5\udd94\uda33\udf66\uda8c\udc54\udb7c\udf56\ud95d\udfba\ud99a\ude8f\ud944\ude9b\uda54\udfe2", "\u31d6\uc293\ud0aa\u9984\ubfd9\u3f2b\uc827\u46b3\ua89d\uaa37\uc8bd\u22c8\u9b9d\ub0a6\u43d9\u6582\u8bd1\u88a9\u1fb3\u610d\u0fe4\u667c\u038d\u96b5\u7b4f\u0637\u4c70\u4870\u5069\ua611\u1276\u7fd9\u591e\u49f5\u9713)\u634c\u2a9d\uc2a1\u510a\u847d\u523a\u7d41\u575c\u3c17\u972f\u9a68\u17a2\uc1c2\u634f\u48a5\ua44d\u0a2a\u29fb\ub99d\u9c3f\u9f65\u43da\u5c59\u8c5b\ub365\u7777\u7ba1\u34b0\u9ab9\u48c4\u65d2\u4605\ua1ff\ud379\u883f\ub38c\u8351\u2383\u00c6\ua36b\u42cd", "\udadf\ude38\udac8\udeca\ud9c3\udd3d\ud943\udd28\uda4c\udc09\ud905\ude1e\ud9aa\ude89\ud971\udd95\u3f03\uda01\ude3a\ud962\udf50\ud8a4\udc6b\ud85b\udf6c",
        34, 95070, -698023281, 4717191744050834276L, 43820L, true, true, (char) 60154, (char) 186,
        Double.longBitsToDouble(0x3fad9c769814c0e0L), Double.longBitsToDouble(0x3fb26ee369a2fed0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 0, "\udb55\udf71", "\u35d5", "\udbc9\uded0\ud9e2\udd1b\ud8d9\udf72",
        21, 71949, 830079169, -2889827671883434402L, -71973L, false, false, (char) 35674, (char) 33329,
        Double.longBitsToDouble(0x3fe2907dc21b9af8L), Double.longBitsToDouble(0x3fd000000b728344L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\u3600", "",
        -5, -1000, 0, 23552L, -100000L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\udb55\udf71", "\u594e\u68a2\000", "",
        -5, 22772, 10936441, 8681251231712991618L, -99877L, false, false, (char) 0, (char) 51267,
        Double.longBitsToDouble(0x3feb8d58d0e133b4L), Double.longBitsToDouble(0x3ec9140000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 15, "\ud865\udef9", "\u65c0\uc5f0\u8fcf", "\udbe0\udf5e\udbc2\udc85\ud95e\ude73\u91f3\udadd\udd69\ud83d\ude2a\ud8be\udfdd\ud926\udc30\ud865\ude8a\ud81f\udc0d\ud950\ude37\ud880\udd94\udafe\udcc9\udaba\udec7\ud9d0\udc0a",
        1, 87259, -1318586175, -5159005236544614350L, -22221L, true, false, (char) 32569, (char) 30598,
        Double.longBitsToDouble(0x3fc6445045d1d660L), Double.longBitsToDouble(0x3fe92d41aa07e7adL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 9, "\ud865\udef9\ud92b\udd1e\uec87\ud9e5\udfba\uda72\udec4\ud8e1\udcc6\udac4\ude24\udb82\udf33", "\ucfbe", "\udbb6\udedb\udb71\udf8f\uda08\udda7\ud8c7\udc51\ud820\udc0c\ud899\udcf8",
        28, 32870, 2060269048, 4091895252956215629L, -5915L, false, true, (char) 28821, (char) 22856,
        Double.longBitsToDouble(0x3fe1e0a7ec8f2af7L), Double.longBitsToDouble(0x3feb417f6a7310f8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 13, 15, 0, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ub34d\uda76\udda4", "\u9dc4\u1a0e\000\u7639\u1e2e\u333e\000", "\ud815\udffa\u98e1",
        -5, 44400, -197372658, 5626668459978813137L, -69298L, false, false, (char) 10711, (char) 211,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3ec2d2c88a080000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 15, "\u07d3\ud9db\udfe6\udbf5\udccd\uda13\ude4f\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u3ef4\u445c\u2fd0\u4202\u592d\ud2c0\u3c75\u6c9f", "\ud975\udd67\ud9c2\udc19",
        34, 81742, 1170692410, 3006506290184190145L, -22221L, true, true, (char) 23696, (char) 25196,
        Double.longBitsToDouble(0x3fc644504b36512cL), Double.longBitsToDouble(0x3fd1a69a8aa6dd42L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 15, "\udb9c\udf81\ud915\udd77\u78f3\ud974\ude20\ud9e9\udc79\ud8e1\udcc6\uda50\udeff", "\u3ef4\u445c\u2fd0\u4202\u9935\ud2c0\u3c75\u574b", "\ud97b\udc78\ud9a6\udd0b",
        16, 73069, 1170679524, 3006506290737838273L, -22221L, true, true, (char) 5581, (char) 25196,
        Double.longBitsToDouble(0x3fc6445040ed352cL), Double.longBitsToDouble(0x3fd1a69a8aa6dd42L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.plot.PiePlot:@?\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 15, 15, 10, "\udbb0\udeea\uda34\udf12\ub9d4", "\u1476", "\ud98c\udde5\udaa4\udc47\uda30\udd3a\000\uda24\uddf9\udac0\ude6c\udb46\udda1\ud961\uddf2\udb3b\udea3\udbce\ude07\uda8a\udea7\udbfe\udcba\udb8e\udc1e\uda16\udd6c",
        5, 65798, -574519949, 7839812949335233364L, 41883L, false, false, (char) 42605, (char) 48907,
        Double.longBitsToDouble(0x3fcc59a89380b5d0L), Double.longBitsToDouble(0x3fb4bde6118582c0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 12, 12, 16, "\udb74\udf8a\u5bd7\udaa8\udf35\udbb5\udf6f\uda72\uddff\ud8f4\udc28\uda76\ude1d", "\u3ef4", "\uda6a\udc0a\ud9ec\udc25\uda32\udf7c",
        2, 45625, -683629905, -9154926014818117385L, -22221L, false, true, (char) 23830, (char) 13370,
        Double.longBitsToDouble(0x3fdc9228217fbe3aL), Double.longBitsToDouble(0x3fd8d9b714186046L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\0121=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud94a\udd28\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\uda76\ude1d", "\u999e\u4661\u2fd0\u4202\u592d\uc5b8\uac77", "\ud815\udffa\ud975\udd67\udaa3\udd96\u2243\ud9d0\udc0a\ud900\udf03",
        4, 56049, -1629648878, 2538459383932906359L, 71281L, false, true, (char) 25253, (char) 7988,
        Double.longBitsToDouble(0x3fe9a98b5185b02fL), Double.longBitsToDouble(0x3fc4873cb1e83870L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.PiePlot:@?\0121=null |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 13, 13, 0, "o", "", "",
        -5, -1000, 0, 23772L, 31072L, false, true, (char) 44, (char) 27003,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 15, "\ud865\udef9\ud92b\udd1e\u7962\ud974\ude20\uda72\ude80\ud8e1\udcc6\ud9a9\udc31", "\u3ef4\u41b1\u2fd0\u4202\u302e\ud2c0\u3c75", "\ud815\udffa\ud975\udd67\udb39\udd82\ud8f3\udd29\ud9d0\udc0a\ud900\udf03\ud9c8\udcc8\ud8fb\udc1f\udb70\udfd9\ud8d6\udea2\udafa\udc57\uda2a\ude64\uda91\uddd6\uda9c\udf9b\uda65\udede\ud8cf\ude2c\ud992\uddf9\ud826\udf37\ud891\ude55",
        12, 34319, -704454514, -6836108523864305191L, -77801L, false, true, (char) 37896, (char) 33798,
        Double.longBitsToDouble(0x3fdb0b27c231db8cL), Double.longBitsToDouble(0x3feaaf542c119cb7L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 15, "\ud865\udef9", "\u65c0\uc5f0\u8fcf", "\udbc9\udf8b\ud848\udfa4\ud95e\ude73\u91f3\udadd\udd69\ud83d\ude2a\ud8be\udfdd\ud926\udc30\ud865\ude8a\udaf5\udeb7\u5a6c\udbd2\udc3c\ud9fa\ude4d\ud90f\udddc\ud9f2\udeaf\ud900\udf03\udb8c\udcca\ud8fb\udc1f\udb70\udfd9\ud8d6\udea2\udb84\udf8c\udba2\udd2d\ud9de\udf67\udb4f\udd17\uda65\ude97\ud838\udfa0\ud9f5\udc47\u8db6\ud937\udefd\ud998\udf6f\uda54\udc6d\ud91f\udc2e\u49f3\uda17\udf8d\udb66\uddf2\uda5d\ude02\ud99d\uddff\ud90c\udc9d\udbcd\ude9f",
        -2, 2555, -773637549, -282992026403380916L, -37069L, true, false, (char) 36001, (char) 10433,
        Double.longBitsToDouble(0x3fec9b92dc561375L), Double.longBitsToDouble(0x3fdaf1b705fd0f26L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 0, "\u07d3\ud9db\udfe6\u00db\000\000\ud8e1\udcc6\ub979", "\u3ef4", "\ud9ee\udc77",
        12, 91667, 698723097, 2088251275L, -60863L, false, true, (char) 104, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc82000004ac59cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.plot.PiePlot|getMaximumExplodePercent||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|initialise|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlot,java.lang.Integer,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|clone||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|draw|java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Point2D,org.jfree.chart.plot.PlotState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawItem|java.awt.Graphics2D,int,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlotState,int|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawLabels|java.awt.Graphics2D,java.util.List,double,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawLeftLabel|java.awt.Graphics2D,org.jfree.chart.plot.PiePlotState,org.jfree.chart.plot.PieLabelRecord|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawLeftLabels|org.jfree.data.KeyedValues,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,float,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawPie|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawRightLabel|java.awt.Graphics2D,org.jfree.chart.plot.PiePlotState,org.jfree.chart.plot.PieLabelRecord|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawRightLabels|org.jfree.data.KeyedValues,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,float,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawSimpleLabels|java.awt.Graphics2D,java.util.List,double,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|equals|java.lang.Object|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getArcBounds|java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,double,double,double|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getBaseSectionOutlinePaint||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getBaseSectionOutlineStroke||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getMaximumExplodePercent||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|initialise|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlot,java.lang.Integer,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
