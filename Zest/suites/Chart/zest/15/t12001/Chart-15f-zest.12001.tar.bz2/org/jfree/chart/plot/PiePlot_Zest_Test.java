package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class PiePlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71", "\u2070\u4974\u4c02\u81dc\u409d\uc5c4\u675d\u9006\u566b", "\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8\ud883\udcc9\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\udac2\udf0d\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3",
        30, 12968, 1920563632, -6006967802993711815L, -74335L, false, true, (char) 1737, (char) 47603,
        Double.longBitsToDouble(0x3fec1466cab81070L), Double.longBitsToDouble(0x3feef1e386ff2770L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 16, 8, "\u9435\ud9a9\udfd9\udb11\udcbf\ud9c0\uddc0\udb92\udc71", "\u2070\u4974\u4c02\ud4c4\u4065\uc5c4\u675d\u9006\u566b", "\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\ud8f1\udd3e\udb98\udd62\ud9ba\uddf1\udacf\udfe5",
        43, 20967, 208144716, 5158868808865646238L, 74602L, true, true, (char) 38342, (char) 14704,
        Double.longBitsToDouble(0x3fdb054a1d38e4f2L), Double.longBitsToDouble(0x3fd39aca20ab32b2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 10, "\ud92a\udde0\ud901\udcbe\ud8ca\ude9c\ud833\udee2\ud978\udd6b", "\u2070\u0e74", "\ud909\udd87\udae4\uddb9\uda7c\udebf",
        14, 35613, -1185298460, 7245238356150732050L, 11808L, false, true, (char) 58837, (char) 26906,
        Double.longBitsToDouble(0x3fc3e257f05a5f2cL), Double.longBitsToDouble(0x3fefa4a6b6368db8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0", "\u96c5\u2070\u4974\u4c02\u81dc\u409d\uc5c4\u675d\u9006", "\ud897\ude15\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8",
        19, 3830, -1928124361, 3463072630490544259L, 27862L, false, false, (char) 36029, (char) 38342,
        Double.longBitsToDouble(0x3fe7059481b054a1L), Double.longBitsToDouble(0x3fe4e393cd39aca2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 16, "\u9435\ud9aa\udca4\udb11\udcbf\ud9a8\udf18\u1356", "\u7d4e\u323a\u4c02\uc77d\u409d\uc5c4\u675d\ucbdf\uc84c\u3a64\u0c28\ud23b\u4f06\u8ffb\u9d86\u6dd1\u1906\u3756\u3f52\u3001\ucf2b\u783b\u90af\u60b3", "\ud9eb\udf4a\ud88f\udcc3\udae0\udd59\udb1c\udfdc\u786f\u90d0\udab6\udf02\ud9ec\udd5f\udaa4\udc76\ud85a\udfcf\uda67\ude72\udb06\udc33\u5c7a\udb21\ude47\udbf8\ude30\uda2b\udd3c\ud967\udea5",
        0, 47757, 1605730083, 2176453427176244510L, -70868L, false, true, (char) 64237, (char) 6313,
        Double.longBitsToDouble(0x3fe541cf25040afbL), Double.longBitsToDouble(0x3f5a46ce2ba31000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71", "\uc1bd\u4974\u82a1\u8b49\u409d\uc5c4\u675d\u9006\u566b", "\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8\ud883\udcc9\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\udac2\udf0d\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3",
        12, 12968, 1920563632, -3139936710168795334L, -81602L, true, false, (char) 63710, (char) 27606,
        Double.longBitsToDouble(0x3fee0e9c1f95a7daL), Double.longBitsToDouble(0x3fa5cf8d2d107830L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\u9435\ud85c\udcfb\uda3e\udec3\udaaf\udc7b\udb92\udc71", "\uccbb\u4974\u4c02\u81dc\u409d\uc5c4\u675d\ua7b1\uae1e", "\udac4\udf75\ud910\udd7d\ud9fe\udd07\ud89b\udfb3\ud8d1\udeb1\udb46\udfe8\ud883\udcc9\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud959\udce0\udb8a\udeb7\ud8de\udd07\udab8\udcb0\ud879\udf33\uda36\ude0f\uda64\udeae",
        30, 12968, 1920518320, -6006967803121156807L, -74335L, true, false, (char) 30681, (char) 47603,
        Double.longBitsToDouble(0x3fec1466cab81070L), Double.longBitsToDouble(0x3feef1e386ff2770L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 10, "", "\u0e8d\u8b52\u4da7\u0f1d\000\000\u4974", "\ud909\udd87",
        58, 36066, -91863420, -7355214482104888604L, 27966L, false, false, (char) 0, (char) 43775,
        Double.longBitsToDouble(0x3fbb515a56713260L), Double.longBitsToDouble(0x3fc3e257f1980b2cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 0, 0, 1, "\000\ud9a9\udfc0\udb10\udfc4\ud8d4\udc69>", "\u80e9", "\ud95c\udd09",
        -4, 74073, 664617066, 565223163750L, -63136L, false, false, (char) 157, (char) 0,
        Double.longBitsToDouble(0x3fe67130049f12bfL), Double.longBitsToDouble(0x3fb980b2c1b957b8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 14, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\u4291\udad9\udf38\uda31\udf68", "\u45e9\u81dc\u409d\uc5c4\u4c68\u8881\u6942\u3a64\u4135", "\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8\ud850\uded0\uda07\udecd\ud89d\ude0a\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\ud816\udc38\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3\udae0\udd59\udbf2\uddc8\udaf9\udc80\ud92a\uddb2\udadb\udd89\uda5b\udd15\udbdc\udfbc\ud9f8\udcdd\ud800\udd18\udb15\udfea\u857a\udb21\ude47",
        9, 37295, 1658732894, -9152620823209977701L, -28875L, false, true, (char) 55643, (char) 47146,
        Double.longBitsToDouble(0x3fe9d02210d4a7e2L), Double.longBitsToDouble(0x3fca3240ac7ffb08L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71", "\u2070\ucd04\u4c02\u81dc\u409d\uc5c4\u12cc\u9330\u566b", "\ud9e4\ude72\uda86\udeed\ud80e\udfb3\udbdc\udde7\udb2c\udeae\udb46\udfe8\ud883\udcc9\uda8a\udcb0\udaa3\udc65\ud926\udd57\udbf5\ude99\udbfc\ude58\ud831\udf45\udac2\udf0d\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3",
        47, 11436, 1920563632, -6006967802993711815L, -97549L, false, true, (char) 1737, (char) 47603,
        Double.longBitsToDouble(0x3fec1466cb35f0f0L), Double.longBitsToDouble(0x3fdd53c70dffb360L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71", "\u8424\u4974\u7502\u81dc\u409d", "\udb26\ude8d\ud9d8\udfa5\uda81\ude59\ud897\ude15",
        36, 86627, -1727315327, 5001717574087254125L, -54621L, false, true, (char) 2261, (char) 52788,
        Double.longBitsToDouble(0x3febb25a3a0a3f71L), Double.longBitsToDouble(0x3feafe8af5ea8fdcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71", "\u2070\u4974\u4c02\ua357\u79c3\u18d6\ud124\u6c86\u566b", "\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\ub4bc\ud883\udcc9\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\udac2\udf0d\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3",
        30, 12968, 1920563632, -6006967802993711815L, -74335L, false, true, (char) 1737, (char) 47603,
        Double.longBitsToDouble(0x3fec1466cab81070L), Double.longBitsToDouble(0x3feef1e386ff2770L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 1, "\u93d6\ud9aa\udca4\ud8d2\udc22\ud9c0\uddc0\udb92\udc71", "\u2070\u4974\u4c02\u81dc\u409d\uc5c4\u675d\u9006\u566b", "\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8\ud873\udc7d\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\udac2\udf0d\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3",
        30, 12968, 1920563632, -6006967802993711815L, -74335L, false, true, (char) 1737, (char) 47603,
        Double.longBitsToDouble(0x3fe41466ca1f944fL), Double.longBitsToDouble(0x3feef1e386ff2770L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\ud885\udf70", "\u4c16\u498e\u4c47\u756a\u641e\u0dd6\u6763\u9006\u566b", "\ud9e4\ude72\ud910\udd7d\ud944\uddcb\udb91\udcf7\ud9da\udeb4\ud90f\ude84\ud84f\udc41\uda26\udf4c\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\uda91\udd6a\ud879\udf33\ud9eb\udf4a\udb60\udc97",
        33, 12968, 1920563506, -3743627513926672552L, -74335L, false, true, (char) 1654, (char) 47603,
        Double.longBitsToDouble(0x3fec1466cab81070L), Double.longBitsToDouble(0x3feef1e386ff2770L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 7, "\u9435", "\000", "-",
        -5, -1000, 0, 760986331L, -83510L, false, false, (char) 64134, (char) 20992,
        Double.longBitsToDouble(0x3fe17f5aa422fe4aL), Double.longBitsToDouble(0x3fc91c6cc0000010L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 1, "\ud9a6\udfb0\udbbe\udf6f\udb67\udcca\ud9c0\uddc0\udb92\udc71\u1725\udac5\udf7c\ud9f3\udeeb\udaba\uddc1\ud88e\udc28\ud95c\udd29\ud909\udd87\udae4\uddb9\uda7c\udebf\u5a06\ud85c\udf1b\ud8cf\udeba\ud904\ude32\uda89\udfa5", "\u7c0b", "\ud883\udcc9\ud89d\udeee\uaa08\ud834\udc65\uda9f\ude74\udb4b\udc2b\ud812\udefe\udac2\udf0d\ud879\udf33",
        2, 67479, -955185686, 6098302900188576176L, 37927L, true, false, (char) 9641, (char) 20861,
        Double.longBitsToDouble(0x3feed7d776a25351L), Double.longBitsToDouble(0x3fec1466cab81070L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 3, "\u9435\ud95d\udc84\udb7c\udcd6\ud9c0\udd81\udb92\udc71", "\u2070\u4974\u4c02\u21dc\u40bf", "\ud96d\ude31\ue962\ud866\uddac",
        32, 99514, 206142454, 5232537079965657922L, 21132L, true, false, (char) 46287, (char) 26770,
        Double.longBitsToDouble(0x3fd4c93c47b219f8L), Double.longBitsToDouble(0x3fe4f23cbb764b47L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 2, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71\u1725\udac5\udf7c\ud9e4\udeeb\udaba\uddc1\ud88e\udc28\ud95c\udd29\ud909\udd87\udae4\uddb9\uda79\udc9e\udafd\udd57\ue962\ud866\uddac", "\u4f06\u8ad0\u4e69\u14ba\u1906\u37ef\u3f52\u3001\ucf2b", "\ud832\udc11\udac2\udf0d\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3\u5154\udb1c\udfdc\u786f\ud92a\uddb2\udadb\udd89\ud9ec\udd5f\ud915\udcb5\ud9f8\udcdd\udbd6\udcc2\udb05\udfd8\uda55\udf79\udb45\udddc\udbf8\ude30\ueba5\udbd3\ude61\uda85\udff4\ud8c4\udd9d\ud89f\udcff\ud92f\ude79\ud877\uddf8\ud8bd\udf8e\ud89b\udf14",
        41, 51024, -1435367347, 9207791841849279973L, 66195L, true, false, (char) 21415, (char) 52322,
        Double.longBitsToDouble(0x3fdd9b2c80245544L), Double.longBitsToDouble(0x3fecd863d7f0e03aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\ud996\ude53", "\u8b52\u4da7\u67ba\u96c5\u2070\u4974\u4c02\u81dc\u409d\uc5c4\u675d\u9006\u566b\u3a64\u0c28\ud23b\u941a\ud0cb\u9d86\u6dd1\u1906\u37ef\u3f52\u3e28", "\udb8a\ude0f",
        40, 73718, 1064432502, -3360061313926775969L, 62080L, false, true, (char) 26901, (char) 37339,
        Double.longBitsToDouble(0x3fb541565d72cab8L), Double.longBitsToDouble(0x3fd2aaf537b5f5dcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 1, "\u95e4\uda21\udd98\uda82\udd35\ud8ee\udf10\ud980\udf26", "\u240f\u4974\u4c02", "\udae4\uddb9\uda7c\udebf",
        35, 35678, -346795292, -123244056973800414L, 11808L, false, true, (char) 58932, (char) 26906,
        Double.longBitsToDouble(0x3fc3e257f1980b2cL), Double.longBitsToDouble(0x3fabf8fbe368d130L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 1, "\ud8e4\udc73\u0237\udb23\udd65\ud9c0\uddc0\udb92\udc71", "\u2070\u4974\u0bb7\u90fe\u409d\u1ef3\u75e9\u9006\u5b7f", "\ud9e4\ude72\ud910\udd7d\ud9fe\udd07",
        21, 94013, 314524366, 201453204061760614L, -11990L, false, true, (char) 348, (char) 45612,
        Double.longBitsToDouble(0x3fe4f23cbb764b47L), Double.longBitsToDouble(0x3fe051fb8b5fd15eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc47", "\u2070\u4974\u4c02\u81dc\u409d\ucfd6\u67b5\u9006\u566b", "\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8\ud883\udcc9\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb5c\udf39\ud832\udc09\uda33\ude59\ud866\udf7a\ud9eb\udf4a",
        26, 78850, 1419871968, 8248757987928372892L, 55733L, true, true, (char) 20861, (char) 1737,
        Double.longBitsToDouble(0x3fe5129a8b828cd9L), Double.longBitsToDouble(0x3fe5c08387de3c70L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71\udbc5\udf24\ud9df\udea9\ud9e4\udeeb\udaba\uddc1\ud999\ude1f\ud95c\udd29\ud909\udd87\ud997\udd54\udbfb\ude00\ud85e\ude5a\ud93b\udfcf\uda2a\udf96\uda0b\udf7f", "\u65d2\u5808\u6df1\u2204\u37ef\u3f52\u080e\u78a7\u7424\u90af\u783a\u9fd6\u0172\u6151\uce76\ucb06\ud4f8\u4183\u3410\u8390\u8c60\u9718\uc327\u4699\u6c7a\u0efe\u7259\u269c\u7f30\u8ff5\ub284\ucfab\ua761\ubabc\u43ff\u792d\ubb8a\ud6f0\u6175", "\u97a9\ud96e\ude71\ud9c9\udf21\udbff\ude4a\ud82e\udfa6\ud834\udca4\uda44\udf61\uda03\udcb7\uda0c\uddbc\ud8ca\udd47\udba6\udd03\ud8d6\uded5\ud99e\udc24\ud968\udc78\udaa8\udf96\udb48\udc22\uda61\udef1\uda5f\udd3c\ud831\udc55\ud847\ude3a\udbba\udd2b\ud8a4\udf49\ud9f5\ude12\udb3e\udd5c\ud803\udc7e\ub3bd\ud80e\uddcb\udb59\udef7\udb85\ude8f\ud9a4\ude85",
        22, 66873, -1630575727, 853431340628874906L, -77803L, false, true, (char) 48038, (char) 42817,
        Double.longBitsToDouble(0x3fc94eb426752c8cL), Double.longBitsToDouble(0x3fcd5f465b4eab0cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 1, "\u9435\ud9aa\udca4\udb11\udcbf\udb00\udcdf\ud955\ude00", "\u2149\u48d5", "\ud909\udcee\udb9f\ude65\uda7c\udf28",
        35, 35678, -346795292, -123244056973800414L, 11808L, false, true, (char) 58867, (char) 26906,
        Double.longBitsToDouble(0x3fd9f12bf8cc04b2L), Double.longBitsToDouble(0x3fab957be368d130L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 0, "\000", "\u4140\u4da7\u67ff\u96c5\u2070\u3273\u4c02\u2120\000\u82f3\u675d\u8f82\u566b\u3a64", "\ua8b5\ud9fe\udd07\ud89b\udf59\ud9f2\udc71\udb46\udfe8\ud883\udcc9\ud89d\udeee",
        14, 25430, 0, 0L, 27862L, false, false, (char) 94, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44e6b288000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 6, "\u933c", "\u8b52\u403e\u67ff\u96c5\u2070\u4974\u4c02\u81dc\ubadb\000\u66f3\u9006\u566b\u3a64\000\u05a1\u4f06\u8ad0\u9d86\u6dd1\u1906\u37ef\u2c66\000", "",
        24, -1000, 1258291200, 4571702784107129354L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fedf800012a1053L), Double.longBitsToDouble(0x3feed7d776a25351L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 6, "\ud99f\udecd\ud94a\udf94\udb11\udc46\ud9c0\uddc0\udb92\udc71\u1725\udac5\udf7c", "\u6123\u81dc\u409d\uc5c4\u675d\u9006\u566b\u3a64\u0c28", "\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8\ud883\udcc9\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\udac2\udf0d\ud879\udf33\ud9eb\udf4a\udad4\udfd1\udae0\udd59\udb1c\udfdc\uc064",
        27, 88465, -1981128619, 1176455172229843498L, -8190L, false, true, (char) 4904, (char) 33870,
        Double.longBitsToDouble(0x3fe7f93b801fd619L), Double.longBitsToDouble(0x3fe7f0a73c0f732dL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 12, 14, 1, "\uda90\udc09\udba7\ude05\udb10\udfd2", "\u67ff\u96c5\u2070\u20e5\ub76c\ub6b6\u409d\uc5c4\u275d\u4f29\u566b\u3a64\u0c28\ud23b\u4f06\u8ad0\u9d86\u3fe4\u5a2e\u37ef\u3f52\u3001\ucf2b\u783b\u90af\u60b3\u9fd6", "\ud8b7\udcc3\udae0\udd59\udb1c\udfdc\u786f\ud92a\uddb2\udadb\udd89\ud9ec\udd5f\ud915\udcb5\ud9f8\udcdd\udbd6\udcc2\udb05\udfd8\u5c7a\udb21\ude47\udbf8\ude30\ud8cb\udfcd\udb8c\udd30\ud9a5\udc23\ud902\ude9d\uda75\udccb",
        10, 18728, -722301468, 1511973561121613955L, 95906L, true, false, (char) 54379, (char) 13641,
        Double.longBitsToDouble(0x3fe196b008fdb33aL), Double.longBitsToDouble(0x3fa5508b472b8b80L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 1, 1, "\ud970\udd13\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0", "\u96c5\u2070\u4974\u4c02\u81dc\u409d\uc5c4\u675d\u9006", "\ud897\ude15\ud9e4\ude72\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\udb46\udfe8",
        19, 3830, -1928124361, 3463072630490544259L, 27862L, false, false, (char) 36029, (char) 38342,
        Double.longBitsToDouble(0x3fe7059481b054a1L), Double.longBitsToDouble(0x3fe4e393cd39aca2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\ud979\udd65", "\u7a79\u4915\u4c02\u81dc", "\uda7c\udebf\udae3\udd2d\ue962\ud866\uddac",
        32, 99514, 201625800, 5232537079965657922L, 74602L, true, false, (char) 35434, (char) 14704,
        Double.longBitsToDouble(0x3fdb054a1d38e4f2L), Double.longBitsToDouble(0x3fd39aca20aa0ab2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 0, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb92\udc71", "\000\000\u4c02\u81dc\u409d\uc5c4\u675d\u9006\u566b", "\u3c28\ud910\udd7d\ud9fe\udd07\ud89b\udf59\udb2c\udeae\ud8e8\uded9\000\ud892\ude88\ud87e\udd71\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\udac2\udf0d\ud879\udf33\ud9eb\udf4a\ud8b7\udcc3",
        30, 33528, 1920563456, -6006967802993711815L, -74335L, false, true, (char) 1737, (char) 47603,
        Double.longBitsToDouble(0x3fec1466c8b81070L), Double.longBitsToDouble(0x3e4bfc9dc0000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 2, 15, 13, "\u9435\ud9a9\udfd9\udaff\udecd\ud9a2\ude6d\udb92\udc71", "\u2070\u4974\u4c02\ud4c4\u4065\uc5c4\u26e2\u7a0b\u5d18", "\ud9e4\ude72",
        20, 31976, 1164553026, 2759757060099883726L, -68588L, true, true, (char) 52788, (char) 16061,
        Double.longBitsToDouble(0x3fe051fb8b5fd15eL), Double.longBitsToDouble(0x3fdea8fdcdc16520L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 1, "\u9435\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0", "\u96c5\u2070\u0e7f\u4ef6\u81dc\u409d\uc5c4\u675d\u9006", "\ud897\ude15\ud9e4\ude72\ud910\udd7d\uda58\udef5\ud800\ude62\udb42\udf6d\udb46\udfe9",
        19, 3830, -1928124361, 3463072631245518979L, 27862L, false, false, (char) 36029, (char) 38342,
        Double.longBitsToDouble(0x3fc55c31bb6c0fe0L), Double.longBitsToDouble(0x3fe50d8665396cd6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 12, 12, 15, "\u938a\ud9aa\udca4\udb39\udcbc\ud8e1\udf2f\uda52\uddd6\udbdc\udd8d\ud817\udeec\udb35\udc59\udaa4\udca1\uda60\ude0c\ud95c\udd29\udadf\udcb6\udb3f\ude53\ud905\ude76\ud96d\ude31\ue962", "\ud23b\u4f06\u8ad0\u9d86\u6dd1\u1906\u37ef\u3f52\u3001\ucf2b\u783b\u90af\u60b3\u6e4a\u0f30\u59e2\u1f64", "\u786f\ud92a\uddb2\ud9b9\uddf9\udb81\udfed\udb6c\udf48\ud9e4\udf61\ud9d7\udea8\ud8cd\udc50\ud83d\udd3c\ud83f\udfc5",
        47, 60494, -395779404, -990338829007698916L, -81976L, true, true, (char) 53620, (char) 63510,
        Double.longBitsToDouble(0x3fe73383a30b9297L), Double.longBitsToDouble(0x3fd42e73b1782c06L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 1, "\ud99d\udd6c\ud85f\udc00\uda3e\udec3\udaaf\udc7b\udb92\udc71", "\uccbb\u4974\u4c02\u81dc\u829d\uc5c4\u675d\ua7b1\uae1e", "\udac4\udf75\ud910\udd7d\ud9fe\udd07\uda09\udc16\ud8d1\udeb1\udb46\udfe8\ud883\udcc9\ud89d\udeee\ud8b7\ude79\ud800\udd0b\ud959\udce0\udb8a\udebd\ud8de\udd07\uda0f\udddc\ud8ff\udd66\uda36\ude0f\uda64\udeae",
        30, 12968, 1920518320, -6006967803121156807L, -74335L, true, false, (char) 30681, (char) 47603,
        Double.longBitsToDouble(0x3fec1466cab81070L), Double.longBitsToDouble(0x3feef1e386ff2770L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 0, "", "", "\udb92\udc71",
        58, 73757, -1705355979, -7184948253159336388L, -17974L, false, false, (char) 63748, (char) 7727,
        Double.longBitsToDouble(0x3fe17f5aa522fe4aL), Double.longBitsToDouble(0x3fc91c7393003010L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\u9435\ud85c\udcfb\uda3e\udec3\udaaf\udc7b\udb92\udc71", "\uccbb\u4974\u4c02\u81dc\u409d\uc5c4\u675d\ua7b1\u30c9", "\udac4\udf75\ud910\udd7d\ud9fe\udd07\ud89b\udfb3\ud8d1\udeb1\udb46\udfe8\ud883\udcc9\ud89d\udeee\ud87e\udd71\ud800\udd0b\ud959\udce0\udb8a\udeb7\ud8de\udd07\udab8\udcb0\ud879\udf33\uda36\ude0f\uda64\udeae\udae0\udd59\udb1c\udfdc\udbf1\udf6e\ud92a\uddb2\ud84d\udd17\uda07\udf63\ud935\udec5\udb34\udf44\udbd6\udc54\udb05\udfd8\u5c7a\udb21\ude47\udbf8\ude30\ucd81\uda2a\ude14\ud8ba\udd96\ud964\udf7e\ud990\udeee\ud893\udce4\ud83a\udc0c\ud9e5\udeee\ud42d\ud860\udee5\ud8a0\udd63\ud8f8\udf9a\ud96d\udd85\ud828\udd91\uda7d\ude3c\udb81\udcc6\ud9cf\ude9a\udb49\udf6a\ud803\udee0\ud9f8\udcd1\ud9fc\ude62\udbe8\udfb6\ud97b\udfcc\ud930\udfb3\udbc0\udfc8\uda85\udd10\ud931\udda6\udb61\udfc2\uda29\udc9f\udb9f\udf52\udbf8\uddfc\ud942\uddfe\uda43\udecc\uda32\udfa9\uc33a\ud9a4\udf4a\ud87c\ude61\ud897\udeaa\udac2\udea1",
        53, 77733, -1861408282, -6492669915444222664L, -98896L, true, true, (char) 5964, (char) 22177,
        Double.longBitsToDouble(0x3fda4a609da9e3eaL), Double.longBitsToDouble(0x3fd597560c846844L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\0121=org.jfree.chart.plot.PiePlot:@? |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud85f\udcf4\ud883\udfa6\uda3e\udeee\udaaf\udc7b\udb92\udc71", "\u0433\u4974\u4c02\u81dc\u409d\u21d1\u48fb\u2c70\ud5df", "\ud908\udf78\udaa0\udf36\udb06\udedf\ud89b\udfb3\ud8d1\udeb1\udb46\udfe8\ud876\uddc9\ud89d\udeee\ud87e\udd71\udb9f\udf8d\ud996\udedf\ud928\udc0f\udb66\udd5e\ud97b\udfbc\ud871\uddb5\uda36\ude0f\uda64\udeae",
        30, 91280, -1128100837, -3115201324125844972L, -31905L, false, false, (char) 29713, (char) 30735,
        Double.longBitsToDouble(0x3fec157ecab80a70L), Double.longBitsToDouble(0x3fe6404b807b5613L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 12, 12, 3, "\u95e4\uda21\udd98\uda82\udd35\ud8ee\udf10\ud980\udf26", "\ud288\u4974\u4c02\u81dc\u409d\uc5c4\u675d\ube2f\ud5ff\u3a57\u0c28\ud23b\u4f06\u8ad0\u63f7\u6dd1\u1906\u37ef\ua3c3\u3001\u5c05\u503a\u85de\u2db5\u8c4d\u3053\u09af", "\ud93d\ude79\ud88e\udd07\ud98d\udc4d\ud844\udc9a\udb63\udc13\udbb9\udd01\ucb4d",
        34, 80075, -1115507477, -7639970982196771176L, -98045L, false, true, (char) 52116, (char) 3145,
        Double.longBitsToDouble(0x3fe9ac0c9989ebacL), Double.longBitsToDouble(0x3faf7f980a4d6ff0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 1, "\000", "\u4140\u4da7\u67ff\u96c5\u2070\u3273\u4c02\u2120\000\u82f3\u675d\u8f82\u566b\u3a64", "\ua8b5\ud9fe\udd07\ud89b\udf59\ud9f2\udc71\udb46\udfe8\ud883\udcc9\ud89d\udeee",
        14, 25430, 0, 0L, 27862L, false, false, (char) 94, (char) 130,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44e6b288000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.PiePlot:@?\0121=null |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 13, 13, 0, "", "\u92fe", "\u1725\udac5\udf7c",
        14, 25690, -1730161092, 36421322670080L, -17974L, false, false, (char) 493, (char) 60625,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 4, 11, "\000", "\u4140\u4da7\u67ff\u96c5\u2070\u71af\u4c02\u2120\024\u82f3\u675d\u8f82\u566b\u3a64", "\ua8b5\ud907\udd4d\ud887\udd2b\ud9f2\udc71\udb46\udfe8\ud883\udcc9\ud89d\udeee",
        14, 25430, 0, 0L, 27862L, false, false, (char) 94, (char) 130,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44e6b288000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.PiePlot:@?\0121=null |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 2, 13, 13, 0, "", "\000", "\000\000",
        41, -1000, 0, 0L, -99894L, false, false, (char) 493, (char) 60625,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\u9435\ud9aa\udca4\udb11\udcbf\udb82\uddc1\udb92\udc71", "\u2070\u4974\uaaca\u890d\u409d\u9851\u08d6\u73c3\u566b", "\ud855\udfe8\ud910\udd69\ud8d5\udd13\ud88f\udf0d\udaee\udc26\ud818\uded30\ud902\udec1\udb1a\udf06\ud800\udd0b\ud84c\ude22\udb8a\ude0f\ud832\udc11\udac2\udf0d\udafd\udc8f\ud8da\udce3\udb97\udeb2",
        1, 12968, 1920563632, -6006967802993713863L, -74335L, false, true, (char) 1737, (char) 47603,
        Double.longBitsToDouble(0x3fc5d3738b12ca00L), Double.longBitsToDouble(0x3feef1e386ff2770L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.plot.PiePlot:@?\012",
        Z.run(T, 1, 14, 3, 16, "\u9435\ud9aa\udc34\ud9b5\udff8\ud9c0\uddc0\udb92\udc71\udbb3\udcbb\udac5\udf50\ud921\ude49\udaba\uddc1\ud898\udd28\ud95c\udd29\uda1f\udf93\uda05\udfdc\ud990\ude9f\udb26\ude8d\ud9d8\udfa5\uda81\ude59\udad4\udc19\udba3\udf52\uda36\ude7f\udaed\udc6f\udb4f\udfc8", "\u7f68\u2dd6\u9598\uacca\u3784\ub89d\u60b3\u9353\u0ea8\uaac5\uce76\u6279\ucda1\u7ce1\u599f\u1d1a\u3656\u048d\ua19d\u3b52\u6e2b\u26e1\u9a86\u25b9\u6866\u5327\ucdb2\u0fb5\u3900\u5890\ud412\u4145\u5924\uc216\ub718\u8b4c\u74fe\u4f3a\u2112\u0e20\ubbd7\uc0d0\u79ef\u8854\u04f1\ub0e6\u0a5e\u772c\uc8b7\ua2e6\u39c9\u03eb\u4cfb\u3b30\u489b\ub722\u9d10\u6da8\u890b\u5413\u20cb\u2843\ud24d\u2de5\u4774\u6cea\ucb96\u809e\u9426\u7632\u4804\ua0b5\u2835\u88d7\u3e52\u5be8", "\ud9be\ude4a\udb33\udddb\ud857\udf08\uda69\ude40\ud88f\udeb7\udaf2\udf79\ud92f\ude33\ud924\udcc4\udb86\udfe7\uda19\ude2e\uda26\udf49\ud8e6\udef6\udb39\udfee\uda60\udfa2\udb61\ude5a\udb6f\udf72\u8cf6\ud8e2\udcf5\udb84\udeb1\uda45\udd88\udb51\udffa\ud9ad\udcc2\udb33\udcc0\ud9be\uddee\udb01\udedf\ud9d3\udd4f\udae9\ude01\ud832\udc4c\ud883\udcb6\ud906\udc8c\udb6f\udd9d\ud9ea\ude09\uda5a\udee9",
        0, 66795, 1777838686, 8105938524720898041L, 62326L, true, false, (char) 38754, (char) 18081,
        Double.longBitsToDouble(0x3fc8985e6fd48410L), Double.longBitsToDouble(0x3fb1dd36ae68bf60L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 1, 3, "\u9435\ud95d\udc84\udb7c\udcd6\ud9c0\udd81\udb92\udc71", "\u6650\u4752\u61ec\u21dc\u40bf", "\ud96d\ude31\ud837\ude62\ud866\uddac",
        32, 98746, 206142454, 5232537079959694146L, 11140L, true, false, (char) 59836, (char) 45769,
        Double.longBitsToDouble(0x3fcb64d641641d1cL), Double.longBitsToDouble(0x3fe8efb8533c5e01L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.plot.PiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 6, "\ud839\udc3e\ud9aa\udca4\udb11\udcbf\ud9c0\uddc0\udb4e\udf30", "\u1ff1\ucd04\u4c02\u4fdd\u26d5\u1bc5\u5333\u9330\u566b\u43e0\u10f9\u2044\u8cd9\u6188\u366b\uce1c\u1906\u8f46", "\ud8da\uddbc\udbf5\ude02\udb58\uddee\uda30\uddd6\udaca\ude96\ud879\udf59\ud9eb\udf4a\ud89c\udf3b\uda37\ude85\uda39\udc6e\u786f\udbd4\ude26\ud802\udd6d\uda84\ude8d\ud90f\ude3f\uda9c\udeb0\udae4\udd71\ud9f6\udde4\ud96a\udfc1\ud96a\udced\ud9d0\udcae\ud88d\udc90\udac9\udeb7\u054c\ud953\ude07\ud89d\udf27\ud968\udc1c\ud9e9\udccd\uda55\udf72\udbf5\udcde\ud868\ude06\uda6b\udfbf\ud9ea\ude76\u74a9\udb66\udd47\ud8bf\uddaa\ud939\udcf1\udbf4\udfda\udb99\udf65\u5d65\udb2a\udd87\ud8eb\udd85\uda72\uddc3\ud848\udee8\ub6f1\ud815\udc42\u66fc\u20af\uda4e\udd7d\ud8c4\udf3b\ud8a6\ude8b\ud89d\udec4\ud9e9\uddaf\u162b\u991e\ufd59\ud8fd\udde3\uda41\udd85\udadc\udda8\udbdd\udfce\ud8bb\udd32\ud919\udf38\uda9a\uddcd\ud9a6\udc0a\udbdd\udd5d\ud98b\udcc1\ud89a\udc01\ud934\udeb9\ud8c0\ude9e\udadd\udc35\udb67\udc53\ud978\udf06\ud8a1\udc03\udbfa\uddc0\ud919\ude71\ud92f\udfbb\udb57\udc08\udb28\udfd3\ud877\udf99\ud010\ud95f\ude41\ud9d5\udd4f\uda4e\udd67\ud843\ude4e\ud989\udee3\ud8ad\uddce\ud8a6\ude1a\ud87e\udd24\ud9d6\udc95\udb5d\udc8d\ud82a\udc6c\udb72\udd94\ud9b7\udf45\udbf6\udf3d\ud904\ude00\ud829\udc0c\ud838\udff3\ud80a\udfba\udb9f\ude98\ud8b1\udcd9\ud9e5\udd8d\udb60\udea7\ud864\udc27\u96e2\udabe\udca0\uda8a\udc06\udbaa\udc86\ud8af\udfdd\ud95a\ude70\udab6\uddd9\ud94f\udd59\ud862\udfc6\uda19\udc0d\ua713\udb6a\udf31\ud838\udeec\ud936\udf08\uda88\udd3e\ud8ab\udcea\uda9c\udfba\udb19\udde7\ud9f1\udc5b\ud964\udee7\udaca\udf61",
        12, 50189, -1487825962, 176534467864758802L, -82815L, false, true, (char) 18351, (char) 25242,
        Double.longBitsToDouble(0x3fd77bcb99332586L), Double.longBitsToDouble(0x3fdf47e29fca3f9aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.plot.PiePlot|getMaximumExplodePercent||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|initialise|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlot,java.lang.Integer,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|clone||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|draw|java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Point2D,org.jfree.chart.plot.PlotState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawItem|java.awt.Graphics2D,int,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlotState,int|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawLabels|java.awt.Graphics2D,java.util.List,double,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawLeftLabel|java.awt.Graphics2D,org.jfree.chart.plot.PiePlotState,org.jfree.chart.plot.PieLabelRecord|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawLeftLabels|org.jfree.data.KeyedValues,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,float,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawPie|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawRightLabel|java.awt.Graphics2D,org.jfree.chart.plot.PiePlotState,org.jfree.chart.plot.PieLabelRecord|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawRightLabels|org.jfree.data.KeyedValues,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,float,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|drawSimpleLabels|java.awt.Graphics2D,java.util.List,double,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlotState|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|equals|java.lang.Object|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getArcBounds|java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,double,double,double|new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getBaseSectionOutlinePaint||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getBaseSectionOutlineStroke||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|getMaximumExplodePercent||new:org.jfree.chart.plot.PiePlot:",
    "M|org.jfree.chart.plot.PiePlot|initialise|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.PiePlot,java.lang.Integer,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.PiePlot:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
