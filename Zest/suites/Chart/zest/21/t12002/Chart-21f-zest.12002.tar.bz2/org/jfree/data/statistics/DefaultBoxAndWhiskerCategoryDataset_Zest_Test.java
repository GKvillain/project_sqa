package org.jfree.data.statistics;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultBoxAndWhiskerCategoryDataset_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ua45a\u2870\uc3d3\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b435b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 6, 7, "\uda70\udde7\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u7fae\u7e08\u6ab0\u4313\u6dd9", "\ud8d9\udff9\udbbd\uddd0\ud808\udfbe\uda17\udde2\ud94e\uddb9\ud9c7\udd39\u318a\udbb3\udd3e\uda46\udd4a\uda36\udfcb\ud9bd\uddc6\udae9\udf75\uda28\udf3a\udbe0\udeb5\ud957\udee0\udbc6\udcd5\ud80d\udf2c\u2f12\ud9ba\ude28\udaa5\udf7b\udb68\udc13\ud80a\udc47\udbda\ude15\ud891\udd4b\uda65\udde9\udbf9\udd17\uda43\udd37\uda3e\udc3b\udad1\ude0c\ud9ea\udd27\udb8a\udf7d\ud966\udeba",
        37, 30964, -1692914717, -6956872335070647785L, 56052L, false, true, (char) 27732, (char) 23712,
        Double.longBitsToDouble(0x3feb50460dbe71b8L), Double.longBitsToDouble(0x3fc1caf960e83278L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 6, 7, "\ud842\uded1\ud911\udfa4\ud890\udd32", "\u7b95\u96d8\u6259\uc201\u6ecd\u4c6d\u11a2\u89a4\ua02a", "\ud808\udfbe",
        39, 96647, -1802825319, -6474331178197355646L, -55753L, true, false, (char) 25095, (char) 3129,
        Double.longBitsToDouble(0x3fd23c1882478086L), Double.longBitsToDouble(0x3fe095c1c9d2df51L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 9, "\udb84\ude4f\ud8c0\udc7e\udb14\udc12\ud873\ude3c\ud203\ud820\udcfc\udbc6\udd77\ud9e4\udd4d\ud810\udee3\udbb1\udea2\ud8d1\udfd3\ud96c\udcf0\udb1c\udfce\udafc\udd93", "\u4c5e\ub9eb\u2a49\u028a\u05da\u3b4a\ubd05\u2fcc\uaeef", "\ud834\ude1f\ud97e\udee6\udac2\udc56\ud970\udd80",
        6, 14612, 915735331, -6698427462972880355L, -31770L, false, true, (char) 6902, (char) 19090,
        Double.longBitsToDouble(0x3fe358c7b2071ecbL), Double.longBitsToDouble(0x3fdce2081c368a12L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 6, 7, "\uda78\udde5\u9d52\udb6b\udf05", "", "\udb98\ude49\ud810\udee3\udbb1\udf17\ud8d1\udfd3\ud8ab\udef4",
        2, 32900, 4974313, 4498814552537402508L, -13443L, true, true, (char) 47454, (char) 933,
        Double.longBitsToDouble(0x3fcd25ff844d2960L), Double.longBitsToDouble(0x3ea6000000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 7, "\udb60\udfd0", "\ucf95\u7c20\u7b95\u96d8\u6259\u835e\u6f5d\u4313", "\udaa8\uddd3\000\udbbd\uddad\ud808\udfbe\ud9c3\udc78\000\000\u30b7\udbb3\udd3e\uda46\udd4a\uda4a\udd15",
        -5, -1000, -1056964608, 3586844179282890663L, 5620L, true, true, (char) 40523, (char) 27943,
        Double.longBitsToDouble(0x3f9453c7cf5bc620L), Double.longBitsToDouble(0x3feb539d6cb16e45L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 6, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\u3606\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ua45a\u2870\uc3d3\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b435b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 0, 16, "\uda78\udde5\u9d52\udaf4\udc7a", "\u7b95\u00a1\u6259\u835e\u6f5d\u4313\u6eac\u3aa7\000\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ucb76\000\000\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u3510\000\ucd08", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 31,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e38000000000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 7, 14, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\u37b9\u0f92\u472f\u5cb4\u5cb3\u2a8a\u028a\u05de\u3b4a\ube18\u33ba\ua485\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ua45a\u6c20\u6acc\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u64f7\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b435b00dL), Double.longBitsToDouble(0x3fc7d9a56f64c984L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 11, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ua45a\u2870\uc3d3\uc988\u38ab\u6402\u4794\ub09f\u341e\ua936\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360448720680382L, 7074L, true, false, (char) 46056, (char) 5690,
        Double.longBitsToDouble(0x3fbe8f23e6ac8a68L), Double.longBitsToDouble(0x3fe928b29c8eb31eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 6, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e\ub7dd\011\u3e4a\u8d38\u073a\ubd05\u2fcc\uaeef\uc36b\u6480\u1ac6\u480c\ud406\u8890\ua45a\u2870\uc3d3\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u9265\u34f0\u371c", "\uda05\udfaa\udb77\udde0\ud96e\uddac\ud839\ude5b\uda77\ude1d\uda08\udeea\ud975\udd4c\ud827\udd4f\ud932\udeec\udbc9\ude34\ud96b\udcd5\udb7b\udd8b\ud909\udec0\ud814\udfb6\ud852\ude44\udbec\ude7c\ud948\udd01\uda25\udc20\ud921\ude4b\ud9d2\udd72\udad3\uddbb\ud943\udc80\ud9e1\udf7f\ud9b4\udde9\udafe\udd6e\udb96\udd5b\udb91\udef5\ud99b\udfbb\udad8\uddb6\udbc3\udc29",
        40, 38127, 1752096530, 3262480719346640713L, 22990L, true, true, (char) 32765, (char) 54676,
        Double.longBitsToDouble(0x3fd117a6346db108L), Double.longBitsToDouble(0x3fc6d9816bec18a8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 6, 7, "\uda78\udde5\ud8c0\udc7e\udb6b\udf9d", "\u7b95", "\ud810\udee3\udbb1\udf17",
        51, 16297, -1948566873, 2253259671094421225L, 1516L, true, false, (char) 27393, (char) 2815,
        Double.longBitsToDouble(0x3fee99ec5a6bd939L), Double.longBitsToDouble(0x3fcd25ff844d2960L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 9, "\ud915\udd27\ud8c0\udc7e\udb14\udc12\ud873\ude3c\ud203\ud820\udcfc\udbc6\udd77\ud91c\udd4a\ud810\udee3\udbb1\udf17\ud856\udfd5\ud95b\udc5b\udb1c\udfce\udafc\udd93\ud8d9\udff9\udbbd\uddd0\ud808\udfbe\uda17\udde2\ud94e\uddb9\ud9c7\udd39\u318a\udbb3\udd3e\uda46\udd4a\uda36\udfcb\ud9bd\uddc6\udae9\udf75\uda28\udf3a\udbe0\udeb5\ud957\udee0\udbc6\udcd5\ud80d\udf2c\udb15\uddb6\ud823\ude40\ud9b1\ude5a\uda24\ude3b\udbd3\udf0c\udbda\ude15\ud891\udd4b\uda65\udde9\udb87\udfbe\uda43\udcf3\uda3e\udc3b\ud9e6\udc31\ud9a7\udf5a\udbad\ude58\ud966\udeba\uc3ed\ud85f\uddc8", "\u9dca\u35f3\u1b20\u6e60\u5c2f\uc837\ud631", "\ud827\udd4f\ud932\udeec\udbc9\ude34\ud96b\udcd5\udb76\udf8b\ud8ea\udcc0\ud814\udfb6\ud85f\udfec\udb53\udec7\uda2c\udee8\udb76\udecc\ud941\udecc\udb60\udec0\udb58\udebd\ud9a8\ude3a\udaca\udf2b\ud970\udf7b\uda36\udcd7\ud80e\udded\udb31\udf78\uda28\udc72\ueda9\udbc0\udf71\udab7\uded9\udaf2\ude4a\ud81f\udcce\u6db2\ud94b\ude4e\udaea\udee4",
        20, 88958, -1234782696, -8127046336594949844L, 66541L, true, false, (char) 6596, (char) 27731,
        Double.longBitsToDouble(0x3f9ce11ab2ed4d00L), Double.longBitsToDouble(0x3fd276baf5424f5aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\ubf18\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ua45a\u2870\uc3d3\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u8822\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b435b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 13, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u9708\ud619\u835e\u985e\u4313\u2aa1\u70ff\uaccb\ud1ed\ube33\u6dd5\u774b\ub6a8\uab40\u5e97\u6cd6\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\uba1f\ud406\u34cb\ua45a\u2870\uc3d3\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u4446\ua332\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe2152ffc35b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 4, 6, 7, "\udaca\udfd6\ud9e3\udf50\udb00\udca9", "\u8dea\uc6ef\u69b5\u835e\u6f5d\u4313\ud727\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49", "\udbb3\udd3e\uda46\udd4a\uda36\udfcb\ud9bd\uddc6\udae9\udf75",
        0, 2415, -486788362, 2002391751809587235L, 57622L, true, false, (char) 45019, (char) 36011,
        Double.longBitsToDouble(0x3fc149b472c7b5c0L), Double.longBitsToDouble(0x3fedfbbbf15718f6L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 14, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\ud7da\u8a69\uaa10\u6f5d\u4313\u6eac\u70ff\u7dae\u2ccd\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u12a9\ubd05\u6e19\u033c\uc40b\u655f\u6d71\u034c\ud406\uca56\ua45a\u6bbf\uc004\u3649\u99b4\u6402\u4794\uba1b\uce6e\u3afc\u4b5f\u30eb\u37a0\u82f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 77425L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe2108edc35b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 13, 1, "\ud9a4\udf40\ud8c0\udc68\udae3\uded9\udad4\udc1b\ud1fb", "\u0247\u2f4e", "\ud96c\udcf0",
        2, 25228, -1974737175, 4498824229098720396L, -13443L, true, true, (char) 47454, (char) 933,
        Double.longBitsToDouble(0x3fcd25ff8c4d2960L), Double.longBitsToDouble(0x3fec25eaa117a4aaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 5, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ua45a\u2870\uc3d3\uc988\ub1da\ubd15\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        42, 60888, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b435b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 8, 6, 7, "\udb42\udde9\ud8c0\udc78\udb14\udc12", "\u2e37\u014e\u0ae1\uc23f\u6f6d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e", "\ud9c7\udd39\u40c1\udbb3\udd3e",
        4, 69891, -1531903192, -770203399474374935L, 2311L, true, false, (char) 14372, (char) 22290,
        Double.longBitsToDouble(0x3fc28604ac8c9404L), Double.longBitsToDouble(0x3fedb1b4aa1da30aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 2, 6, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u6259", "\ud8d1\udfd3\ud96c\udcf0\udb1c\udfce\ud815\udfc0\000\udb9c\udfad\ud808\udfbe\uda17\udde2\ud94e\uddb9\ud9c7\udd39\ud966\udfd6\udbb3\udd3e\uda46\udd4a\uda36\udfcb\ud9bd\uddc6\udae9\udf75\uda28\udf3a\udbe0\udeb5\ud957\udee0",
        23, 88050, 807791434, 2666584614764872483L, -86205L, false, false, (char) 36011, (char) 791,
        Double.longBitsToDouble(0x3f3b914000000000L), Double.longBitsToDouble(0x3e3038f658000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 3, 6, 7, "\uda78\udde5\u2082\ud99a\udfe4", "\u7b95\u96d8\u621e\u1067\u6f92\u4313\uc6f4\u70ff\uaccb\u3368\ua422\u4c5e\ub885\u1b3c\u028a\ua358\u3b4a\ua269\u3c74\uaeef\uc36b\ubf96\u8749\u47fd\ud406\u8890\ua45a\u2870\uc3d3\uc988\u0d69\u6402\u4794\uba1b\u7304\u5492\ua0ab\u30a1\u37a0\ub2f4\ucbbc\u255f\u9265\u77b2\u76c9", "\ud861\ude05\udb77\udde0\ud96e\uddac\uda6e\uddf6\uda77\ude1d\uda31\ude1f\ud946\ude57",
        3, 36180, 1847535258, 3393025412334199362L, 542L, true, true, (char) 26124, (char) 44920,
        Double.longBitsToDouble(0x3f34e5be660b6800L), Double.longBitsToDouble(0x3fd9f7892b285844L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 1, 4, 6, 1, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\ud2a5\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u2608\u54b5\ud406\u8890\ua45a\u3237\ub0f0\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b435b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 16, 7, "\uda78\udde5\u5448\ud956\udd1a", "\u8991\u9669\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e", "\ud9c7\udd39\u318a\udbb3\udd42",
        4, 69891, -1531903192, -770203399474374935L, 2311L, true, false, (char) 14372, (char) 22290,
        Double.longBitsToDouble(0x3fc28604ac8c9404L), Double.longBitsToDouble(0x3fedb1b4aa1da30aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 17, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7ac1\u96d8\u6259\u835e\u6f5d\u4313\u071d\u711e\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\uc54d\u3147\uc3d3\u9972\u0fd7\u6402\ud72f\uc1c5\u4a1d\ub955\uab5f\u8fed\u37aa\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        -3, 90279, 146914775, 8194360451879646654L, 24497L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b535b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 6, 7, "\u2bae\ud8c0\udce0\udb14\udc12", "\ucb6c\ud60d\u6935\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ubbd6\u1ba7\ub9eb\u6064\ua1c4\u05ee\u61eb\ubd05\u2fcc\uaeef", "\udae3\ude77\udb7e\udfa7\ud957\udc9a\udb8b\udd77",
        51, 18522, 2016871294, -1052821938157200134L, 51942L, false, true, (char) 6902, (char) 27282,
        Double.longBitsToDouble(0x3fbac63d9038f4f8L), Double.longBitsToDouble(0x3fdce20818368a12L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 3, 11, 2, "\u0bb0", "\u3de0\u32dd\u7ac9\u96d8\u7fae\u7e08\u6ab0\u4313\u6dd9\u70ff\u2097\ub74c", "\uda17\udde2\ud8cb\udf3d\udb5e\udcb9\udbfb\udd92\ud967\udef8\ud925\udfff\uda36\udfcb\ud9bd\uddc6\udae9\udf75",
        33, 81896, 904697267, 6252706914214535515L, -16338L, true, false, (char) 32094, (char) 9487,
        Double.longBitsToDouble(0x3f943dc7e41bc620L), Double.longBitsToDouble(0x3feb51c42cb16e45L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 7, "\ud941\udec3\ud80f\udf45\udb14\udc12", "\u7b95\u96d8\u5892\u7d5a\u6ab0\u2dd2", "\udafc\udd93\ud8d9\udff9\udbbd\uddd0\ud808\udfbe\uda17\udde2\ud94e\uddb9\ud9c7\udd39\u318a\ud840\uddd3\ud994\ude8c\uda36\udfcb\ud9bd\uddc6\udae9\udf75\udb12\ude2e\udb98\uddc4\ud957\udeac\udbc6\udcd5\ud80d\udf2c\u2f12\ud9ba\ude28\udaa5\udf7b\udb68\udc13\ud80a\udc47\udbda\ude15\ud891\udd4b\uda65\uddf5\udbf9\udd17\ud83d\uded4\uda3e\udc3b\udad1\ude0c\ud9ea\udd27\udb8a\udf7d\udb58\ude25\udab8\udf00\ud8c5\udf71\udaa5\uddae\ud9ac\udfc7\uda5a\udc3d",
        56, 71964, -588421134, -7004909991102399017L, 78987L, true, true, (char) 54010, (char) 62695,
        Double.longBitsToDouble(0x3fe24ad9e9b79df0L), Double.longBitsToDouble(0x3fd9200167f56262L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 6, 17, "", "\u1059\u4eff\u7729\u7b95", "\ud861\udcda\udb6e\udd99",
        51, 41681, -1948566873, 2253259671094421225L, 1516L, true, false, (char) 27165, (char) 2815,
        Double.longBitsToDouble(0x3fee99ec5a6bd939L), Double.longBitsToDouble(0x3fcd25ff844d2960L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 10, 0, "\udb60\udfd0", "\000", "\000\uda48\udc03\000",
        -5, -1000, 1867229440, -8369030993603973188L, -100000L, false, false, (char) 0, (char) 27165,
        Double.longBitsToDouble(0x3fd99f9651a67b16L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 7, 7, "\uda70\udde7\ud8c0\udc7e\udb14\udc12", "\u7b95\u96d8\u7fae\u7e08\u6ab0\u4313\u6dd9", "\ud8d9\udff9\udbbd\uddd0\ud808\udfbe\uda17\udde2\ud94e\uddb9\ud9c7\udd39\u318a\udbb3\udd3e\uda46\udd4a\ud9b4\udf8b\u87ef\ud849\udd99\uda28\udf3a\udbe0\udeb5\ud957\udee0\udbc6\udcd5\ud80d\udf2c\u2f12\ud9ba\ude28\udaa5\udf7b\udb68\udc13\ud80a\udc47\udbda\ude15\ud891\udd4b\uda65\udde9\udbf9\udd17\uda43\udd37\uda3e\udc3b\udad1\ude0c\ud9ea\udd27\ud8af\udd90\ud966\udeba",
        37, 30964, -1692914717, -6956872335070647785L, 56052L, false, true, (char) 27732, (char) 23712,
        Double.longBitsToDouble(0x3feb50460dbe71b8L), Double.longBitsToDouble(0x3fc1caf960e83278L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 6, 6, 7, "\uda70\udde7\ud95a\ude82\udb14\udc12", "\u7ab5\u96d8\u7fae\u7e08\u6ab0\u4313\u6dd9\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de", "\uda36\udfcb\ud9bd\uddc6\udae9\udf75\uda28\udf3a\udbe0\udeb5\ud957\udee0\udbc6\udcd5\ud80d\udf2c\u2f12\ud9ba\ude28\udaa5\udf7b\udb68\udc13\ud80a\udc47\udbda\ude15\ud891\udd4b\uda65\udde9\udb40\udf1a\u7b68\udb5c\udf25\ud9cc\udefc\uda51\udf42\ud827\udf7d\ud966\ude7b\uc3ed\uda67\udf4d\udaa5\uddf0\ud9ac\udfc7\uda8f\udd3d\ud81d\uddad\ud950\udda0\udaa9\udd34\uda14\udd3d\ud839\ude5b\uda77\ude1d\uda08\udeea\ud975\udd4c\udabe\uddfa\ud99e\udccf\ud88e\ude34\ud829\udf1b\udb51\udcc8\uda78\udd5b\udbd3\udcae\u891a\ud9ad\uddf2\ud8e1\udd09\udafe\udd4f\udbde\udd9a\udb31\udd63\u0b89\ud9ad\ude24\ud8c0\ude8a\uda07\udd98\ud87c\udce6",
        -5, 19079, 299467472, -3486998631876312935L, -24338L, true, true, (char) 8479, (char) 29746,
        Double.longBitsToDouble(0x3fd7f3fe54e391beL), Double.longBitsToDouble(0x3fe06ed55765145bL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 10, 0, "", "\u0fc1\u4eff\u7729\u57f7", "\u4bf4",
        -5, -1000, 1867186176, 61707509358198784L, -67779L, false, false, (char) 36548, (char) 27393,
        Double.longBitsToDouble(0x3fd99f9657a67b16L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 1, "\uda90\udfc1", "\uc170", "\ud947\ude69",
        30, 5885, 957405995, 6430269290556795377L, -79979L, false, false, (char) 36548, (char) 13060,
        Double.longBitsToDouble(0x3fd99f965c332916L), Double.longBitsToDouble(0x3f92997311bc2c00L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 14, 7, "\uda78\udde5\u9d52\udb6b\udf17", "", "\uda71\udd56\ud810\udee8\u6b8d\udac1\ude09\ud9a5\ude13",
        6, 32900, 4974313, 4498814552088218764L, -13443L, true, true, (char) 47454, (char) 933,
        Double.longBitsToDouble(0x3fcd25ff844d2960L), Double.longBitsToDouble(0x3ea6000000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 6, 7, "\udb60\udfd0", "\ucf95\u7c20\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u00a7\uacbd\000\ua3ff\u4c5e\u7982", "",
        51, 84083, 1247282409, 12403672277319680L, -100000L, true, true, (char) 49517, (char) 30104,
        Double.longBitsToDouble(0x3fca5bea2d29af20L), Double.longBitsToDouble(0x3fc28604ac8c9404L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 2, 2, 7, "\udb60\udfd0", "\ucf95\u7c20\u7b95\u96d8\u6259\u835e\u6f5d\u4313", "\udaf9\udd1cq\udbbd\uddad\ud808\udfbe\ud9c3\udc78\000\\\u30b7\udbb3\udd3e\uda46\udd4a\uda4a\udd15",
        11, -1000, -1056964608, 3586844179282890663L, -43145L, false, true, (char) 52408, (char) 10276,
        Double.longBitsToDouble(0x3fedb1b4aa1da30aL), Double.longBitsToDouble(0x3f9453c7cf5bc620L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 6, 6, 7, "\ud942\udda1", "\u5122\u0809\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u00a7\uacbd\000\ua3ff\u4c5e", "\000\u30b7\udbb3\udd3e",
        44, 59155, 0, -1056964608L, 2311L, true, false, (char) 14372, (char) 22290,
        Double.longBitsToDouble(0x3fc28604ac8c9404L), Double.longBitsToDouble(0x3fedb1b4aa1da30aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 7, "\ud931\udc24\ud89e\udd22\udb14\udc12\ud873\ude7a\ud833\uddc1", "\u923e\u51a7\u6ea4\u50f5\u6eac", "\uda0d\ude65",
        42, 54660, 14982251, 0L, -95629L, false, false, (char) 0, (char) 15731,
        Double.longBitsToDouble(0x3fee3e08059406c7L), Double.longBitsToDouble(0x3fc1c23c56fe0518L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 4, 4, 7, "\udb60\udfd0", "\ucf95\u7c20\u7b95\u96d8\u6259\u835e\u6f5d\u4313", "\udaa8\uddd3\000\udbbd\uddad\ud808\udfbe\ud9c3\udc78\000\000\u30b7\udbb3\udd3e\uda46\udd4a\uda4a\udd15",
        -5, -1000, -1056964608, 3586844179282890663L, 5620L, true, true, (char) 40523, (char) 27943,
        Double.longBitsToDouble(0x3f9453c7cf5bc620L), Double.longBitsToDouble(0x3feb539d6cb16e45L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 13, 0, "\udb60\udfd0", "\ucf95\u7c20\u7b95\u96d8\u6259\u835e\u6f5d\u4313", "\udaa8\uddd3\000\udbbd\uddad\ud808\udfbe\ud9c3\udc78\000\000\u30b7\udbb3\udd3e\uda46\udd4a\uda4a\udd15",
        -5, -1000, -1056964608, 3586844179282890663L, 5620L, true, true, (char) 15937, (char) 36989,
        Double.longBitsToDouble(0x3f9453c7cf5bc620L), Double.longBitsToDouble(0x3feb539d6cb16e45L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 6, "\udb9a\udf3f", "\ucf95\u7c20\u7b95\u96d8\u6259\uca5e\u6f5d\u4313", "\udaa8\uddd3\000\udbbd\uddad\ud808\udfbe\ud9c3\udc78\000\000\u30b7\udbb3\udd3e\uda46\udd4a\uda4a\udd15",
        -5, -1000, -1056964608, 3586844179282890663L, 8334L, false, false, (char) 52408, (char) 10276,
        Double.longBitsToDouble(0x3fedb1b4aa1da30aL), Double.longBitsToDouble(0x3f9453c7ef5bc620L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 8, "\uda68\udfd4\ud8c0\udc7e\udb14\udc12", "\u989f\000\u1213\u00ad\u6ea2\001\000\000\u7d0f\ucf42\ua3ff\u4c5e\ub9eb\u521d\u284c\u05de\u2a6b\u3606\u2fcc\uabc7\uc36b\u3cdf\u00c7\u2f68\ud406\u8890\ua45a\u2870\uc3d3\uc988\u0d69\u6402\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u36d2\u52f8\u4c56\000\u95b0\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146866391, 8194360451879646654L, -99942L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe000000435b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 6, 15, 17, "\uda78\udde5\ud943\udf7f\ud93b\udebb", "\u7b95\u96d8\u6259\u835e\u6f5d\u4313\u6eac\u70ff\u37b9\u0f92", "\udbe3\udec5\ud94e\uddfa\ud9c7\udd39\u318a\udbb3\udd3e\uda60\udd63\udae2\udf18\udb82\udfa0\udae9\udf75",
        43, 58239, -220885081, -2354957354299533102L, 71924L, false, false, (char) 14101, (char) 27943,
        Double.longBitsToDouble(0x3f9453c7cf5bc620L), Double.longBitsToDouble(0x3feb539d6cb16e45L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 9, 13, "\uda78\ude02\ud8c0\udc7e\udb9e\udc17", "\ud088\u9698\uaa59", "\ud8d1\udfd3\ud96c\udcf0\uda9b\udf4c\udbfb\udd09\u8e1e\udbd6\udc4c\uda7f\udc93\udbe3\udec5\ud894\uddfd\ud9c7\udd39\udbf6\udec9\udbb3\udd3e\ud93e\udeff\udbfd\uded8\udb83\udc64\udae9\udf75\uda28\udf3a\udbe0\udeb5\ud957\udee0",
        23, 88050, 807791434, -1182582394950106000L, -20669L, false, false, (char) 36011, (char) 791,
        Double.longBitsToDouble(0x3fd9b3e1b77e0da6L), Double.longBitsToDouble(0x3fe358c7b2071ecbL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 10, 0, "", "", "\ud203",
        32, 50761, 373100542, 5149169827512900539L, 53103L, true, false, (char) 48023, (char) 59112,
        Double.longBitsToDouble(0x3fe11c5258000000L), Double.longBitsToDouble(0x3fbac00010e8c720L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 3, 3, 7, "\uda78\udde5\uda1b\ude2c\ud969\udd06", "\u7ac1\u96d8\u531a\u835e\u6f5d\u4313\u071d\u711e\uaccb\u3368\ua422\u5a59\ubd98\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uac9a\u501f\ud664\u480c\ud406\u8890\uc54d\u3147\ud268\u9972\u6398\u6402\ud72f\uc1c5\u4a1d\ub955\uab5f\u8fed\u37aa\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\ud9a9\udcbc",
        -3, 90279, 146914775, 8194360451879646654L, 24497L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b535b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 17, 7, "\ud931\udc24\ud89e\udd22\ud886\ude81\ud873\ude23\ud833\uddc1\ud820\udcfc\udbc6\udd77\ud942\uddbd\ud9d8\udeb4\udbb1\ude5e", "\u00a7\uacbd\u48a5\ua29b\u4c5e\ucd79\000\000\u050b\u3b4a\ubd05\u3147\000\u02ab\ubc8d\u4fcf\u42c6\ua941\ud655\ub750\uc352\u3e76", "\udb6f\udc95\ud852\udcf3\ud9a3\udce8\udafc\udd18\udbea\udcc1\ud8d2\udeb8\udac6\udd10\ud9ef\udea2\udac6\udeb7\udbf1\uddab\u0452\ud9b1\udc85\ud89a\udf6e\ud8e3\ude1e\ud934\udf37\ud972\ude11\ud923\udcdc\ud84f\udcbe\u7d9a\ud944\udfab\uda52\uddfe\udb09\ude08\udbee\ude7a\ud9e6\uddb3\udb2f\udc36\ud941\udd58\ud80a\ude53\ud83d\udf57\udbd0\udfca\udbe5\ude3d\ud91c\udd1f\udacd\ude85\udb53\udc2f\ud87f\ude22\ud93a\udddd\ud831\udd50\ud918\uddef\udbaa\udd82\udbaf\udd2b\udab1\udeaf\udb75\udf03\udb8e\udd02\ud8aa\udfb4\udbf2\udf14\udb2c\ude34\uda14\ude83\ud5ff\ud936\udedd\ud813\udd60\uda22\udd62\udb50\udcb9\ud949\udeb8\uf941\ud867\ude21\ud863\udfc8\ud948\udde6\uda4e\ude4d\ud96c\udfb7\udb36\udf04\ud935\udef3\uda71\udf1b\udb89\uded1\ud8e8\udfa5\uda75\udeda\udb73\udd1e\udb1c\udfdc\ud9b4\udf11\uda4b\udece\ud815\udc0e\u526f\ud973\udd31\uda6a\udeb7\ud8a3\udf4e\udb66\ude07\udab5\udf13\udb6a\udc78\udbff\udca0\u99e5\ud8e7\udcd7\ud8cb\udfc0\uda73\uddb7\uc28b\ud8d9\udf45\udbd0\ude12\udb88\udc0e\ud9ac\udced\udb59\udd50\ud804\udcc2\ud985\udd8e\udb52\ude0b\udac7\udf47\udab9\udc9a\udb02\udd0c\u91ef\ud8b8\udc0e\udb4f\udf54\ud81e\udd97\ud986\udc99\ud810\udf16\ud9c9\udc09\uda0a\udf4c\ud804\udf35\ud88f\udf10\ud8ad\uddd8\ud907\ude1d\udbf7\udd33\ud8cb\udf4c\udbb3\ude88\ud9a4\udec7\u60c6\ud815\udfc7\ud9a4\udcb9\udacd\udd22\udbde\udcdd\udb3c\udeea\uda09\ude42\uda44\uddd1\ud976\udc3b\udaf3\uddec\uda00\udf89\ud87a\udc45\ud89f\udd08\ud9b0\ude0e\ud897\udc9b\uda6e\udd1c\uda31\udd64\ud9ad\udf63\ud9f4\udf2f\ud920\udfd6\ud80e\udd85\udb2c\udcc9\ud9aa\ude44\ud884\udfd4\udab5\udee9\uda90\udc8a\uda38\udcfb\ud93d\udd13\udad6\ude0b\udbfa\udc14\udb78\udc15\udbd1\udc6a\udad5\ude71\uda6e\udfb2\uda9e\udcc4\ud883\ude78\udb84\udc31\ud94c\udf67\uda53\udd46\ud81b\udf4d\u07bf\ud898\udebb\u91de\ud846\udfe6\uda9c\udcf2\ud89f\udd8e\uc775\udba7\ude11\ud9d8\uddac\udb9f\udd92\ud873\udf66\ud865\ude00\ud800\udc36\udbdf\udce8\ud890\udcdf\udb5f\uddf5\uda3f\udfd5\udbb8\udfb3\udaeb\udf33\uda71\udd36\ud8e6\udca3\udac0\ude8e\uda22\udea7\udb7a\udea2\ud970\udf2e\uda29\udd25",
        21, 90114, -1362655456, -2437682689884937679L, -71371L, false, true, (char) 41131, (char) 1123,
        Double.longBitsToDouble(0x3fef2de6d42105a2L), Double.longBitsToDouble(0x3fdc4643c28fb7dcL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 7, "\uda78\udde5\ud8c0\udc7e\udb14\udc12", "\u7b95\u3037\u6259\u835e\u6f5d\u4313\u6eac\u70ff\uaccb\u3368\ua422\u4c5e\ub9eb\u2a49\u028a\u05de\u3b4a\ubd05\u2fcc\uaeef\uc36b\u3cdf\u1ac6\u480c\ud406\u8890\ua45a\u2870\uc3d3\uc988\u0d69\u53c8\u4794\uba1b\u4cc8\ua954\u6aea\u308d\u37a0\u52f8\u43bf\u255f\u9265\u77b2\u96c9", "\uda05\udfaa",
        6, 90279, 146914775, 8194360451879646654L, 27034L, false, false, (char) 57234, (char) 56110,
        Double.longBitsToDouble(0x3fe21178b435b00dL), Double.longBitsToDouble(0x3fc7c5656f64c984L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|java.util.List,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|org.jfree.data.statistics.BoxAndWhiskerItem,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|updateBounds||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|clone||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|equals|java.lang.Object|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnCount||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnIndex|java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnKey|int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnKeys||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getItem|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxOutlier|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxOutlier|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxRegularValue|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxRegularValue|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMeanValue|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMeanValue|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|java.util.List,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|org.jfree.data.statistics.BoxAndWhiskerItem,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|updateBounds||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
