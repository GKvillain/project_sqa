package org.jfree.data.statistics;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultBoxAndWhiskerCategoryDataset_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be", "\uda0a\ude70",
        17, 17210, -590032508, -5864514068553771321L, -43554L, false, true, (char) 51760, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 11, 14, 2, "\ud90a\udff0\udbb1\uddc5\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud888\udc43", "\ud2fd\u53be", "\uda0a\ude70",
        17, 35258, -588854878, -5864514068553771321L, 57578L, false, true, (char) 51760, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 6, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be", "\udad9\udfd8",
        8, 17260, -590032619, -5864514068553771321L, -43554L, false, true, (char) 51760, (char) 7978,
        Double.longBitsToDouble(0x3fef9250f2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud964\ude71", "\uba24\u53be\u5f77\u3ee4\u4fdf\u5e51\u8720\u4fd4\u3f11\u8c31", "\udada\udd76\ud899\udf4e",
        4, -860, 1245507360, -7991963052583390548L, -50128L, false, true, (char) 63239, (char) 58140,
        Double.longBitsToDouble(0x3fecba28ef07cc6fL), Double.longBitsToDouble(0x3fe4a931780f83afL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 2, "\ud997\ude56\u0f9f\udb9e\ude82\udb9d\udce4\udbfe\udc2b\udb0f\uddd2", "\u3d20\u5362", "\uda42\udca2\ud938\udc6a\udbff\udfa9\ud98f\udf71\ud86c\udebb\ud974\udd36",
        15, 77402, 1204786989, 3636623992966186796L, -50128L, true, false, (char) 30961, (char) 41807,
        Double.longBitsToDouble(0x3fbf6b5a3fe67948L), Double.longBitsToDouble(0x3fe33d8d58cb4f2cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 2, "\ud8d9\udd65\ud9b6\udd01\udb9e\ude82\ud88b\udde1\ud9cd\udfb9\ud80d\udc45\ud905\udedb\udbc9\udd5c\udbc1\udd7e\udae8\udc41\uda5c\udeb3\ud921\ude3d", "\u01b8\ud632", "\ud8e9\ude62\uda8f\udcc2\udada\udd76\ud899\udf4e\ud9d0\udf6c\ud8f8\udd47\udbfc\udf7f\udae2\udd68\udb76\udcd7\udac7\udf9c\udbe9\udc7b",
        43, 69528, 895324406, 5848619451337997606L, 47606L, true, false, (char) 44172, (char) 57112,
        Double.longBitsToDouble(0x3fbcdc3353f119f0L), Double.longBitsToDouble(0x3fde786753854988L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 8, 2, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be", "\uda0a\ude70",
        17, 17210, -590032508, 44208643838574592L, -46914L, false, true, (char) 17359, (char) 15106,
        Double.longBitsToDouble(0x3fed20146f20940aL), Double.longBitsToDouble(0x3fef9251e2ac9116L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 16, 0, "\udb4d\udc91\u1033\ud88b\udd97", "\u7e0b\ub1fd\u7427\u3d20\u53be\u76e0\u3ee4\ud12a\uabab\u0e8d\u4fd5\u3f11\u8c31\u8b7f\u14e3", "\ud9d0\udf6c\ud8f8\udd47\udbe8\udf7f\udae2\udd68\udb76\udcd7\udac7\udf9c\udaef\udc7f\ud844\uddbf\udaaa\udce9\udad0\udd63\uda2e\udedd\udb41\udd19\ud97f\udc6a\udaec\udd16\udbc0\udf1e\ud88e\udd81\ud88c\udda1",
        59, 66273, -816203643, -4929936452164227447L, -74517L, false, false, (char) 15548, (char) 4583,
        Double.longBitsToDouble(0x3f59cbc49dd05400L), Double.longBitsToDouble(0x3fa3ce8bf26a3240L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 14, 2, "\ud994\udc35", "\u3b0f", "\ud905\udedb\udbc9\udd5c",
        8, 88798, -2074035716, -7635716294301117489L, -98678L, false, true, (char) 60507, (char) 1224,
        Double.longBitsToDouble(0x3fd72b3921449136L), Double.longBitsToDouble(0x3feb0636bc7e6751L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 0, "\udb4d\udc91", "\u3b0f\u7b6d\u7e0b\ubf77\u0652\u3d20\u53be\u5f77\u0c86\u34be\u8921\u0963\u4fd5\u3f11\u8c31\u8b7f\u14e3\u45d4\u3512\ud64b", "\000",
        -5, 57138, -487244496, -2978561716646839154L, -47629L, true, true, (char) 1714, (char) 52393,
        Double.longBitsToDouble(0x3fc6c1228930a1f0L), Double.longBitsToDouble(0x3fedf55c026fcfd1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 16, 1, "\udb4d\udc91\ud89b\ude1f\uda0e\udf93\uda89\udcbb\ud9ec\udcc2\ud80d\udc45", "\u6d0d\u53be", "\uda0a\ude70",
        17, 17210, -590032508, -5864514068553771321L, -43554L, false, true, (char) 51760, (char) 33578,
        Double.longBitsToDouble(0x3fef9199e2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 10, 2, "\udb4d\udc91\u1033\ud929\udd4e\ud9af\udd0a\ud9ec\udcee\ud80d\udc45", "\u3d20\u21de", "\uda0a\ude70",
        17, 17210, -590032508, -5864514068553771321L, -67618L, false, true, (char) 51760, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 14, 2, "\udb1e\udde9\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\udbcb\udc44", "\u6c1e\uae67", "\uda0a\ude70",
        8, 2444, -591670908, -5864514068553771321L, -91646L, false, true, (char) 17359, (char) 15106,
        Double.longBitsToDouble(0x3fed20146f20940aL), Double.longBitsToDouble(0x3fef9251e6cf2116L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb4b\udcda\ud9ec\udcc2\ud80d\udc45\udac9\udf3d\udbb8\udd61\udad3\udce8\uda4d\ude57", "\ud129\uabab\u0e8d\u4fd5\u3f11", "\uda8f\udd43\udada\udd76\ud899\udf4e\ud905\udf72\udae7\udc70\udbfd\udc51\udae2\udd68\ud89c\udf4b\udac7\udf9c\udbba\udd64\udbe2\uddea\udaae\udd90\ud8fe\uddff\udb33\udc92\ud9cd\udfd1\udb1c\udda9\udb5c\udeec\ud898\udf81\udbea\ude4b\ud977\udd02\udb6c\udddf\ud8eb\udfce",
        30, 38371, -902342081, 8319382713593052380L, -50255L, false, true, (char) 59751, (char) 49159,
        Double.longBitsToDouble(0x3fc92ca8cdec3354L), Double.longBitsToDouble(0x3fedd636c316466eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 16, 2, "\udb4d\udca0\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80c\udf8f", "\u3d20\u53be", "\uda0a\ude70",
        17, 17210, -590032508, 6024988947704338119L, -43554L, false, true, (char) 51760, (char) 33796,
        Double.longBitsToDouble(0x3fef9251e491e116L), Double.longBitsToDouble(0x3fe6ce77f53080c5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud89e\udfae", "\u3d20\u53be", "\uda0a\ude70",
        17, 17210, -590032508, -5864514068553771321L, -43554L, false, true, (char) 51760, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 16, 2, "\udbae\udf0d\ud88a\uded8\ud94e\ude5b", "\ud180\u3a3a\u6795\ua5a8\u0f22\u2d44\u3b13\ua286\u676c", "\ud86c\udebb\udb7d\udefa\ud9bf\uddde\udac2\udc5e\ud979\udca2\ud96f\udd87\ud8a5\udfde\ud8fa\udef0\ud814\udc8f\uda22\udc57\udb84\udf91",
        34, 77799, -558374782, -4820771593537388423L, -96025L, true, true, (char) 11246, (char) 701,
        Double.longBitsToDouble(0x3fe50034b7f2ef1aL), Double.longBitsToDouble(0x3fe104e91642fc41L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 9, 2, "\udb4d\udca0\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud8d8\udca6\ud928\udc76\udbc9\udd5c\uda4c\ude76\ud993\udd59\udbda\udeb2\ud84c\udc51\ud995\udd77\u2b43\udbff\udea9\ud999\ude16\udb15\udd8b", "\ud0e3\u45d4\u3512\ud64b\u5a7e\u2e15\u3403\u76c9\u8fe1\u0d81\u0c11\u518d\u4f04\ube06\u29e8\u104b\u2278\u077d\ud7c6\ua7d4\u7748", "\ud848\udd87\ud990\udcbf\ud8ba\udc80\ud821\uddce\ud95c\udc7f\ud929\udc99",
        51, 88751, -819064663, -1164016476397699829L, 73878L, false, false, (char) 60091, (char) 29116,
        Double.longBitsToDouble(0x3fbb775c5ba53ad8L), Double.longBitsToDouble(0x3fe5d151ab146b22L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 13, 14, 2, "\udb4d\udc91\u1033\udb6c\udff9\udaaf\udd05\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be\uaaaa\u3f5e\ud12a\uabab\u0e8d\u88d4\u05ca", "\uda8f\udd43\udada\udd76",
        21, 73894, -1811232860, 5349413376280112019L, 51330L, false, true, (char) 40010, (char) 62210,
        Double.longBitsToDouble(0x3fac71f23b38c710L), Double.longBitsToDouble(0x3fe24eb08c770928L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 14, 2, "\ud836\udd00\udb02\uddb1\uda0d\udc32\u3d76\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be", "\udaac\udc62",
        37, 48542, -120270460, 896473709069659495L, -43554L, false, true, (char) 51799, (char) 20778,
        Double.longBitsToDouble(0x3fdb8d216559222cL), Double.longBitsToDouble(0x3fa2345c76824dd0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 14, 2, "\udb4d\udc91\udbf2\ude39\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be", "\ud928\udf64\ud924\udd6a\udbff\udfa9\ud98f\udf71\ud86c\udebb\udbd2\ude45\ud95c\uddb9\ud95e\udd21\udada\udde6\ud899\udf4e\ud9d0\udf6c\ud8f8\udd47\udbfc\udf7f\udae2\udd68\ubad5\ud9a8\udf66\uda38\udc8b\udada\udd50\ud8ee\udc64\ud9dc\udee5\uda2a\udfff\udb0f\udd5b\ud9ff\udda6\udb5d\ude39\ud8c6\udfef\udb49\uddc9\ud945\uded0\uda2a\udc30\ud953\udf97\udaad\udcd9\udb40\udfd6\ud9f3\udec2",
        42, 22542, 1763947578, -3608198156220440419L, 44168L, false, false, (char) 8392, (char) 4576,
        Double.longBitsToDouble(0x3fd3e6004dd064e6L), Double.longBitsToDouble(0x3fd5efc1fd815570L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 16, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u2c5a\u53be\u5f77\u3ee4\ud12a\uabab\u4ddf\u4fd5\u3f11\u8c31\u8b7f", "\ud899\udf4e\ud9d0\udf6c\ud8f8\udd47\udbfc\udf7f\udae2\udd68\udb76\udcd7\udac7\udf9c\ud989\udcac\uda39\udd9e\ud942\udc2d\ud805\udc07\uda0b\udd6e",
        12, 84079, -1292520229, -8746825023997581658L, -6893L, false, true, (char) 4227, (char) 17278,
        Double.longBitsToDouble(0x3fc721a3f4ea21c0L), Double.longBitsToDouble(0x3fe439bd1912c961L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 8, "", "\u65ec", "\000",
        -5, 47098, 251, -2847890604419925508L, 91744L, false, false, (char) 32974, (char) 29744,
        Double.longBitsToDouble(0x3fec3806a6c7ae9dL), Double.longBitsToDouble(0x3fd72b3921449136L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 0, 0, "\udb4d\udc68\u1033\u9886", "", "\uda64\ude6a\udb89\udf83\000\ub9fc\u7c00\000\uda81\udf3f",
        53, 55988, -1365438585, -5507243980404085390L, -100000L, false, false, (char) 0, (char) 164,
        Double.longBitsToDouble(0x3e4fc80000000000L), Double.longBitsToDouble(0x3e96000000000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 10, 10, "\udaa3\udcc4\udbb0\udfc7\udad2\udf5e\ud9f4\udc85\ud9ec\udcc2\ud80d\udc45\ud89b\udf86", "\u0804\u5e86\u3ee4\u6a0f\u67da\u18fc\u4fd5\u3f11\u8c31\u8b7f", "\ud899\udf4e\ud9d0\udf6c\ud8f8\udd47\udbd5\udc6a\udac9\ude68\udb5c\uded7\udac7\udf9c\uda18\udc13\ud882\udfbc",
        47, 11471, -1061431872, -2508855094591037871L, 6749L, true, false, (char) 4352, (char) 57203,
        Double.longBitsToDouble(0x3f50ebb4e5cbd000L), Double.longBitsToDouble(0x3fde5431fc5896aeL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 2, "\ud9c9\udf0f\ud95b\udf29\udb90\udd46\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u1610\u6879\u6c0c\ua056\ud12a\uabab\ub724\u11c3\u3f11\u8c31\u2a04\u146e\u45d4\u56f7\ud64b\u5af3\uc30b\ubf7e\u3c40\uc75d\u7514\u8980\u4968\u43dc\uacc1", "\ud846\ude83\udb74\udf4a\ud968\udcf7\uda94\udf53\ud877\udf97\ud98e\udffc\uda97\udd41\u96d4\udad6\uddf4\ud87b\udff2\uda99\udc1e\udbcc\udc2f\uab5d\ud9a6\ude09\ud801\udc72\ud858\udcf3\udb1c\udd71\ud852\udc9a\ud9b4\udc10\uda8e\udd77\ud958\udf60\ud8ab\udd08\uda75\uddbc\ud879\ude55\uda56\uddd9\ud89f\udddc\udbc7\udcda\ud8ff\udfb0\ud9fa\udc35\ud97f\udca3\ud87e\udf21\udbc0\udf2c\ud992\udd99\udad6\udcbd\ud9f4\udc95\ud9d5\udd5d\ud93c\udd47\udac5\udecf\ud850\udfa8\ud983\udf1e\ud812\udeab\uda66\udec4",
        54, 49862, 923847121, 2611235743368216311L, -12612L, true, false, (char) 11251, (char) 30010,
        Double.longBitsToDouble(0x3fda2d6f66bbf458L), Double.longBitsToDouble(0x3fe2fb0addf4036cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 8, 11, 11, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud974\udd9a", "\u3d20", "\ud921\ude3d\uda0a\ude70",
        39, 55095, -1384770761, 1598750958464145050L, 77985L, true, true, (char) 31897, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e2ac9116L), Double.longBitsToDouble(0x3fe342ec4d458f18L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:0 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 6, 5, 15, "\udb4d\udc91\udb78\udd4d\ud90c\uddb1\udb5f\uded1\ud9ec\udda3\ud80d\udc45", "\u6d18\u53be", "\uda0a\ude70",
        17, 17210, -590032508, -5864514068553771321L, -87550L, false, true, (char) 51300, (char) 15106,
        Double.longBitsToDouble(0x3fed20146f20940aL), Double.longBitsToDouble(0x3fef9251e2ac9116L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 3, 3, 0, "\udb4d\udc91\ud96d\udcc8\udbb0\udff5\udb9d\udce4", "\ucde2\u06cf", "\udbda\udeb2\ud921\ude3d\uda0a\ude70\ud938\udc6a\udbff\udfa9\ud98f\udf71\ud87d\uddbb\ud84a\udd41\udb63\udcc2\uda8f\udd43\udada\udd76\ud899\udf4e\ud9d0\udf6c\ud991\udcf2\ud891\udc61\udae2\udd68\udb76\udcd7\udac7\udf9c\ud8d0\udf10\ud81c\udfc7\uda28\udea7",
        27, 6207, 1024736487, -2553042361389899474L, 12527L, false, false, (char) 37353, (char) 55911,
        Double.longBitsToDouble(0x3fd85fa04b5d813eL), Double.longBitsToDouble(0x3fea54e3e1f91c35L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 8, 13, 2, "\udb4d\udc91\udb33\udf6a\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud949\udf24", "\u3c6c\u53be", "\ud9fd\uddaa",
        8, 47533, -590032508, -5864514069118992953L, 87518L, true, true, (char) 61479, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 14, 2, "\udb4d\udc91\ud9bd\udee1\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be", "\udb4c\udcec\ud938\udc6a\udbff\udfa9\ud98f\udf71\ud86c\udebb\udbd2\ude45\ud95c\uddb9\uda8f\udd43\udada\udd76",
        45, 73972, -703936604, 5341040560861272050L, 51330L, false, true, (char) 29270, (char) 54108,
        Double.longBitsToDouble(0x3fde78e71d22ee08L), Double.longBitsToDouble(0x3fe21ab9b5a255b6L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 14, 8, "", "", "\uda3d\udc0b",
        2, 5368, 98, 37960638285890198L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd000000001b9a8L), Double.longBitsToDouble(0x3e45cace48000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 2, 2, 6, "\udb4d\udc91\ud923\udee3\ud8f8\udd35\ud9ce\udfcb\ud9ec\udcc2\ud80d\udc45", "\u3d20\u53be", "\uda0a\ude70",
        17, 17210, -599338620, -5864514068553771342L, -43554L, false, true, (char) 51760, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e2aceb16L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 12, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u3d20", "\ud936\udfd8\uda0a\ude70",
        17, 17210, -590032508, -5864514065630603577L, -43554L, false, true, (char) 51760, (char) 33578,
        Double.longBitsToDouble(0x3fef9251e5b60a16L), Double.longBitsToDouble(0x3fe9134135308062L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@? |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 3, 15, 11, "\udb4d\udc91\ud80a\udc1f\ud894\uddaa\ud924\udeb8\ud9ec\udcc2\ud910\ude68\ud905\udf4a", "\u53be\u05a0\ub906", "\udbff\udfa9\ud98f\udf71",
        52, 43030, 1218129333, -4143779353746887840L, 93643L, false, true, (char) 30426, (char) 8750,
        Double.longBitsToDouble(0x3fe56488b76a68b8L), Double.longBitsToDouble(0x3fd308062960ab1aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 12, 6, "", "\u0086\000\000\ub536\ubf77\u05f0\u3d20", "\udb40\ude3c\uda0a\ude70",
        17, -958, 0, -5864514648374356281L, -100000L, false, true, (char) 17359, (char) 15106,
        Double.longBitsToDouble(0x3fed20146f20940aL), Double.longBitsToDouble(0x3fef9251e2ac9116L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 7, 1, "\uf82d\u1033\udb9e\ude82\udaec\udfcb\ud89d\udfd5\ud80d\udc45\ud905\udedb\udbc9\udd5c\udbc1\udd7e\uda22\udd5e\udbda\udeb2\ud9ea\udf21\uda2c\ude62\ud938\udc6a", "\u805a\u6204\u8b7f\u14e3\u84a4\u7d21\ua85e\u42ec\ua71c\u2d62\u4c0f", "\udb0d\udc81",
        33, 55868, -266024625, -2715375525711079016L, 56467L, false, false, (char) 18006, (char) 47853,
        Double.longBitsToDouble(0x3fef0a9b5be24debL), Double.longBitsToDouble(0x3fec7853d3b1048bL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 11, 14, 2, "\udafa\ude09\udbcf\udec4", "\u7b6d\u6d73\ubf77\ub081\ud2fd\u64bb\ud670", "\ud938\udc6a\ud966\udddc\ud9cf\udf90\ud86c\udebb\udbd2\ude45\ud95c\uddb9\uda8f\udd43",
        30, 52366, 42797894, -7779185897895039200L, 59004L, false, false, (char) 27744, (char) 55371,
        Double.longBitsToDouble(0x3fdb221ac2c8e6fcL), Double.longBitsToDouble(0x3fe071a3319416d7L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 6, 6, 2, "\udb4d\udc94\ud93e\udc6f", "\u7b6d\u7e0b", "\ud975\udf74\uda0b\udf75\ud855\udc88\ud92f\uded3\udad9\udfd8\ud934\ude6a\ud9f1\udfc7\ud810\uddcd\udba8\ude99\udbd2\ude45\ud95c\uddb9",
        0, 14775, 800906366, 183815553256441764L, 86354L, true, true, (char) 37235, (char) 11070,
        Double.longBitsToDouble(0x3fe8f5ff516da447L), Double.longBitsToDouble(0x3fbfdc59eafaa880L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 6, 6, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udc7f\udbf1\udfc1\ud80d\udc45", "\u3d20\ua0ff", "\udad9\udfd8",
        40, 17260, 1579732651, -6612392583457788658L, 37852L, true, false, (char) 37155, (char) 8735,
        Double.longBitsToDouble(0x3fdf9f0986412814L), Double.longBitsToDouble(0x3fef9250f2ac9116L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=java.lang.Boolean:false |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 4, 4, 9, "\udb4d\udc91\ud891\uddc5\udb9e\ude82\udb9d\udce4\ud9ec\udcc2", "\u0652\u3d20\u53be\u75f9\u3ee4\uad04\u9dab\u9f47\u4f66", "\udb8f\udf05\ud98f\ude71",
        6, 11580, 36481046, -7779185897897030880L, 80944L, true, true, (char) 45707, (char) 8492,
        Double.longBitsToDouble(0x3fe403269a449ff0L), Double.longBitsToDouble(0x3fd79a23f88da624L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 11, 2, "\ud8aa\udce1\u1056\udb9e\ude82\udb9d\udce4\udbfe\udc2b\udb93\uded0", "\u3d20\u5362", "\uda42\udca2\ud938\udc6a\ud8ca\udcae\ud98f\udf71\ud86c\udebb\ud974\udd36",
        15, 77402, 1204786989, 3636623992966186796L, -50128L, true, false, (char) 30961, (char) 41807,
        Double.longBitsToDouble(0x3fbf6b5a3f2503c0L), Double.longBitsToDouble(0x3fd07a4c01969eb6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=void |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\012",
        Z.run(T, 2, 8, 2, 2, "\udb4d\udc91\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud866\ude32\ud932\udddc\udbc9\udd5c\udbc1\udd7e\udae8\udc41\udbda\udeb2\ud921\ude3d\uda0a\ude70\ud938\udc6a\udbff\udfa9\ud98f\udf71\ud8d7\udf90\000\udadd\udd6b\uda8f\udd43\udada\udd76\ud899\udf4e\ud9d0\udf6c\ud8f8\udd47\udbfc\udf7f\udafa\uddbb\ud880\ude42\udaff\udf02\udb7d\uddcc\udb5d\ude71\ud906\udd02\ud847\udf1e\udb33\udf74\ud977\udd5c\ud98f\udf16\uda07\udd17\ud920\udee0\ud8f2\udcc4\ud98f\udd42\udaa5\ude6b\ud9e1\udfab\ud8e4\udde3\udaf8\udcbc\ud883\udfa4\udbd0\udd0b\ud8d4\udc23\udb32\ude80", "\u16ae\u067a\u4bb2\u9d94\ub561\u2b44\u5e68\ud691\u9821\uac6f\uac86\u7077\u0189\u1da6\u1e41\u6f31\ucb3c\u3617\u48cb\uc6c8\u3d8d\ucf22\u3235\ub057\u918c\u6bb9\ud429\uab11\u1d3d\u460f\ubbab\u3ec9\ub7bd\uabb9\u475b", "\ud9a0\ude09\udaa6\udeec\udb4c\udce7\ud9d6\udea0\ud948\ude45\ud8e4\udef7\ud9e0\ude3a\ud912\udcb9\ud81b\udda5\ud852\udd2d\ud88b\udfb1\ud93f\udd77\ud862\ude0f\ud903\uddca\u351c\ud8c2\udf0a\udb10\udcd9\udbf3\ude1e\udab7\udc63\udb3a\udf11\u2e0d\ud9dc\udffc\ud807\ude06\udb07\udc73\udac5\udd4d\ud8f3\udf3d\udb8a\udeaa\udb96\udfe3\u47c3\udb4e\udd69\ud99b\udf15\ud9b2\udd90\udad1\udcc6\udbc7\udd68\udbaf\udc9f\uda48\udc1a",
        47, 58481, -2146315092, 6013978573815040844L, 67210L, false, false, (char) 1255, (char) 18100,
        Double.longBitsToDouble(0x3feee74b09735a99L), Double.longBitsToDouble(0x3fd678e15712467eL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 9, 2, "\udb4d\udca0\u1033\udb9e\ude82\udb9d\udce4\ud9ec\udcc2\ud8d8\udca6\ud928\udc76\udbc9\udd5c\uda4c\ude76\ud993\udd59\udbda\udeb2\ud9a2\udcbc\ud995\udd77\u2b43\udbff\udea9\ud999\ude16\udb15\udd8b\ud970\udce8\ud95c\uddb9\udabe\udd43\udada\udd76\ud899\udf4e\ud9d0\udf6c\udbfe\udd6a\ud88e\udd95\udae2\udced\udb76\udcd7\udac7\udf9c\ud893\udf31\udbd6\uddeb\uda9d\udd64\udbdf\udc2a\ud89d\udd50\ud9ce\ude11\ud94c\uddd5\ud981\udd8a\uda25\ude9e\ud807\ude48\ud923\udc30\udb36\udf81\uda66\udcdf\ud89f\udf7b\ud848\udd87\ud8c2\udf98\ud8ba\udc44\ud821\uddce\ud95c\udc7f\ud929\udc99", "\u4ecc\u9209\u0c95\u1c23\u3195\u57fd\u606a\u09f3\u535d\u457a\u25b4\u16b9\ub43e\u5d75\uc333\u1176\u7310\u0103\u2960\u990e\u31ae\u17c1\ua346\u19a8\u53b8\u97b8\u580f\u5028\u4b14\u2555\u2ae8\u9063\u2350", "\ud9c2\ude8f\u7833\ud8b8\udd64\ud986\udd20\ud91f\udee0\ud8a0\udd7f\udabb\udf7f\udbc3\udd9f\ud9a2\udf43\ud972\udfbf\uf017\udbc0\ude31\udbcf\udd1e\udb11\ude6b\ud845\udcab\ud84b\uddc0\udb7c\udedf\uda4d\uddd4\ud833\ude27\udaf8\udf3e\ud895\ude53\ud987\udd3d\udb3d\udd98\uda90\ude41\ud88a\udf9d\ud899\udc2d\ud920\udc9e\udb1f\udc52\udba2\ude09\udb9f\udca8\uda78\ude0d\ud8ee\udfa6\uda63\udfb4\uda8b\ude1d\udbe1\udf77\udab6\udd9f\ud81a\ude8b\ud978\udc63\ud998\udeaf\uda9a\udc75\uda35\udd4f\udb56\ude67\ud9a2\udd55\ud862\udf59\udbb1\ude2e\ud8bc\udf78\udbe0\udef0",
        28, 44085, -730471655, -5222027946999734265L, -47069L, false, true, (char) 14123, (char) 50530,
        Double.longBitsToDouble(0x3fde44816a8eda64L), Double.longBitsToDouble(0x3fd40c4476318374L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 2, "\udbd1\udcf4\ud8a8\udf78\ud873\udddc\udb9d\udce4\ud9ec\udcc2\ud80d\udc45", "\u42ef\u4117", "\uda0a\ude70",
        14, 85929, 1427499818, 2502330049221096462L, 22127L, true, false, (char) 3039, (char) 33705,
        Double.longBitsToDouble(0x3fef9199e2ac9116L), Double.longBitsToDouble(0x3fe91345c5308062L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|java.util.List,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|org.jfree.data.statistics.BoxAndWhiskerItem,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|updateBounds||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|clone||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|equals|java.lang.Object|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnCount||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnIndex|java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnKey|int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getColumnKeys||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getItem|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxOutlier|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxOutlier|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxRegularValue|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMaxRegularValue|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMeanValue|int,int|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|getMeanValue|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|java.util.List,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|add|org.jfree.data.statistics.BoxAndWhiskerItem,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
    "M|org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset|updateBounds||new:org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
