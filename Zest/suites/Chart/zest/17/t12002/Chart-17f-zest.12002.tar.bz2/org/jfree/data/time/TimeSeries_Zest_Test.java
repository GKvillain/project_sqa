package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimeSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0", "\ud8b3\udd1e\udbf8\udd5b\uda0d\udfcd\u4b8f\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbe3\udec9",
        -2, 11338, 1365267232, -8015634367883025424L, 14633L, false, true, (char) 40882, (char) 55300,
        Double.longBitsToDouble(0x3fe256e582ed7ddfL), Double.longBitsToDouble(0x3fe330a4c50d251cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0\uc476\ucd77\ubacb\u4cf9", "\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbe3\udec9\ue12a\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1\ud842\udf70\udb16\udd4a\u970c\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\udae7\udce5\udad0\udc9e\udacc\udd66\ud80f\udf2f\uda28\udfbd\ud836\udd1e\u0506\uda20\udce2",
        57, 17894, 1907114099, 2964239280910375873L, -57894L, false, true, (char) 52039, (char) 63385,
        Double.longBitsToDouble(0x3fd1a326300d2b0aL), Double.longBitsToDouble(0x3fe8e77feb740e91L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\ud809\udcd0\ud8a3\udf8e\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0\uc476\ucd77\ubacb\u4cf9\u9a56\u257b\u5f5b\u9536\u7367\u9ec7\u8dfa\ub138\u6df3\u578b\u901f\u22ae\u4ef2\u696a\u32b3\uc879\ua240\u25ab\u7880\u8392\u7b2b\ub0e0\ub5e6\u4780\u3e32\uc7de\u9d70\u4b79\u6355", "\ud9be\ude0f\uda0e\udcab\ud9d6\udd2d\udb83\udc98",
        48, 69051, 1320142583, -2099796108740329419L, 29818L, false, false, (char) 24913, (char) 63315,
        Double.longBitsToDouble(0x3febea3ba4870767L), Double.longBitsToDouble(0x3fd7debb1ef8b7f4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\ud833\udead", "\u3b7f\u53a5\ub916\ucf64\uac05\u86d1\u998a\ua92c\u0e1e\u8372\u8d8c\u355f\u7cbf\uaaae\u1f3d\u1a12\u0aaa\u26c0\uc476\ucd77", "\uda0d\udfcd\u4b8f\udb65\ude87\udb3f\ude66\uda7a\udd99\u0535\udb3d\udf12\ud927\ude28\ud999\udcc2\ud92d\udc64",
        45, 43968, 1450020995, -3201964687720747245L, 63863L, true, false, (char) 48782, (char) 12018,
        Double.longBitsToDouble(0x3fe81a8b03f090c2L), Double.longBitsToDouble(0x3f95d43366f676e0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 3, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0", "\ud8b3\udd1e\udbf8\udd5b\uda0d\udfcd\u4b8f\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud9ba\udd4d\ud9d4\udd01\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc2c\ud9d2\ude53\udbe3\udec9",
        -2, 11338, 1365267232, -8015634367883025424L, 14633L, false, false, (char) 55061, (char) 55300,
        Double.longBitsToDouble(0x3fe256e582ed7ddfL), Double.longBitsToDouble(0x3fe330a4c4944b1cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\ud818\udd51\ud9d8\udd61\ud922\udd27\ud9e3\udc3a\ud89b\udf9b", "\u0e1e", "\ud934\udddf\uda95\ude15",
        34, 60202, -465405762, -3951918653091999294L, 84214L, true, false, (char) 52893, (char) 64979,
        Double.longBitsToDouble(0x3fe49b9f314688f4L), Double.longBitsToDouble(0x3fc69e6e74cf4508L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud884\udda2\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u0e54\udb49\ude22\ud9ef\ude9f\000\000", "\uaaae\u1f3d\u1a12\u0aaa\u26c0\uc476\ucd77\u0c67\000\u115d\u24e8\u5f5b\u9536\u7367\u9ec7\u8dfa\ua8a1\u601a\u578b\u901f\u22ae\u966e\u696a\u32b3\uc879\u2340\u25ab", "\udb12\udc74\ud806\udd66\000\udbb0\udf30\udb16\udd4a\u970cJ\udbd7\udf6a\udab1\udc23\udb77\udc95\udb2c\udce8\udab3\udd4a\uda79\udf31\udbe8\udf17\udbcb\udd03\udb22\udf1b\udb4b\udef4\ud992\ude40\ud9c7\udf75\ud9ed\udda3\ud948\ude0a\ud91d\udcaa\ud882\udc58\udb9f\ude0e\ud95c\udfde\ud9be\uddf8\uda39\ude11\uda50\udc96\ud8d9\udfc0\ud9f4\ude40",
        0, 19192, 1622769496, 6952519285138459940L, 68324L, true, true, (char) 55910, (char) 58964,
        Double.longBitsToDouble(0x3fe2cebcb9e37dadL), Double.longBitsToDouble(0x3fdd271398af5198L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 11, 1, "\ud801\uddd0\udbdd\uddbc\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9b9\udd7c", "\u13a2", "\udaf1\udcb4\ud802\udcb2\u8c6e\ubd01\uda68\udc90\uda10\uddc4\ud96c\udde7",
        59, 25260, 1429606850, -6167369730851705289L, 79356L, true, true, (char) 32353, (char) 32332,
        Double.longBitsToDouble(0x3feabf0cdae907d7L), Double.longBitsToDouble(0x3fee18fb09ccfdbfL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 14, "\ud986\udde0\ud8b3\ude34\udbdf\ude2b", "\u51fa\ucf64\uac05\u86d1\u998a\u03c0\ubac5\u2311\u9a4b\u64d4", "\uda62\udde3\udbdc\udd48\uda6a\udfe1\uda11\udec7",
        4, 35144, 203754599, 4354420316469364985L, 60442L, false, false, (char) 22133, (char) 32353,
        Double.longBitsToDouble(0x3fe0018aaf57e19bL), Double.longBitsToDouble(0x3fe7483ebbc31f61L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 0, 2, "\ud809\udcd0\ud8b3\uddc7\udb13\udcc5\ud859\udd48\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud829\ude17\ud814\udc2a\u9c3d\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\udb76\udf03\uda68\udcb0\uda10\uddc4\ud96c\udde7", "\u26c0\ubabd\ucd77\ubacb\u4cf9\u9a56\u1072\u9494\u9536\u7367\u57c7\u8dfa\ua8a1\u5eea\uab7a\u9038\u22ae", "\ud969\udeb9\ud9d2\uddce\udbe3\udec9\ue12a\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1",
        44, 94464, 1144788763, -6795860876954095649L, -76858L, true, true, (char) 65509, (char) 25089,
        Double.longBitsToDouble(0x3fb8ea8d28841f60L), Double.longBitsToDouble(0x3fea7749ef67e8d8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 11, "\ud951\udde9\u1e70\udbdf\ude2b\udbd6\udf85", "\ua00a\uac05\u86d1\u738a", "\ud935\udc53\udbe4\udf85",
        4, 53640, -1020092180, -5867845189766677466L, 26566L, false, true, (char) 24281, (char) 22786,
        Double.longBitsToDouble(0x3fe8c064c0f9743fL), Double.longBitsToDouble(0x3fec9b9f35da3e65L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udbb4\udcde\uda8d\udf90\ud969\udf0a\ud9ef\udcda\udab9\udecc\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda6d\udf73\udb76\udef7\uda2d\udd35", "\u26c0\uc476\ucd77\ubacb\u4cf9\u9a56\u257b", "\udab1\uddfa\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2",
        51, 41982, 1089422760, 6227792751292864021L, -34858L, false, true, (char) 51002, (char) 48782,
        Double.longBitsToDouble(0x3fea94368f035134L), Double.longBitsToDouble(0x3fef84861050d4ebL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\ud809\udc8a\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\udab3\ude33\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u7b76", "\ud8b3\udd1e\udb5e\udd6c\uda4b\udec2\ud891\udf01\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud959\udf26\udbe8\udf16\uda6a\udfd1\udb95\udd90\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbe3\udec9\ue12a\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1\ud838\ude2b\udb23\udd35\u970c\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\uda45\udd95\uf063\ud99d\udfb8\ud892\udf59\udbb1\udc8d\udb5b\udd93\ud9ae\udd91\ud9c0\udf8f\uda8c\ude2d\udbc3\ude63\ud828\ude3c\ud828\udfd3\ud91e\uddab\udb8e\ude4c\ud9ad\uddd3\udae9\udeb1\ud812\udc01\ud926\udd33\ud8ee\uded1\ud9c5\udd22\ud884\udc91\uda58\uded7\udb6f\udef0",
        7, 95331, 268670806, 8252531286099710254L, 75558L, false, true, (char) 61523, (char) 40122,
        Double.longBitsToDouble(0x3fd61178c7fd2ff2L), Double.longBitsToDouble(0x3fe99958289d8722L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 0, "\000", "\u46d4", "\000",
        -5, -1000, 0, 945815552L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc347346bb967e4L), Double.longBitsToDouble(0x3fe7672230005427L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 3, 2, "\ud809\udcd0\ud8b3\uddc7", "\u53a5\ub916\ucf64\uac05\u86d1\u998a\ua92c\u0e1e\u8372\u69f2\u3590\u7cbf\uaaae\u1f3d\u1a12\u0aaa\u26c0\uc476\ucd77\ubacb\u4cf9\u9a56\u257b\u5f5b\u9536", "\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\ud827\ude6c\uda82\udd8b\udb95\udd9a",
        46, 34459, -1382728310, 8410975424287130695L, -60048L, true, false, (char) 62446, (char) 27134,
        Double.longBitsToDouble(0x3fe80b058f4a00bbL), Double.longBitsToDouble(0x3fe256e582ed7ddfL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7\udad8\ude4b\uda6a\udfe1\uda11\udec7\ud980\udf45\ud99f\ude25\ud8b3\udd1e\ud904\udec2", "\u85c2\u1c06\u7367\u9ec7\u8dfa\ua8a1\u601a\u578b\u901f\u22ae\u4ef2\u696a\u32b3\uc879\ua240", "\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1\udbb0\udf67\udb16\udd4a\u970c\ud8a2\udc60\udbef\uddb4\udab1\udc23\udafc\udc97\udb4c\udc2a\uda9e\ude11\uda51\uddd5\ud8df\udc49",
        34, 62331, 1469227366, 355102144952836966L, 45841L, false, true, (char) 42388, (char) 61136,
        Double.longBitsToDouble(0x3fe33a8c4aa99513L), Double.longBitsToDouble(0x3fcb6e85103e80f8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\ud809\udcd0", "\u697f\u53a5\ub916\ucf64\ud321\u09c7\u998a\ua92c", "\u8c6e",
        43, 53640, 966987359, 6483279770234034926L, 35618L, false, true, (char) 24281, (char) 63101,
        Double.longBitsToDouble(0x3fe3c86128f974dbL), Double.longBitsToDouble(0x3fe49b9f354688f4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 0, "\ud809\udcd0", "\u697f\u53a5\ub916\ucf64\uac05\u86d1\u998a\u3e2c\u0e1e\u8372\u8d8c\ubf71", "\ud96c\udde7",
        29, 25108, 0, -8112925766308147344L, -70669L, false, true, (char) 12573, (char) 22133,
        Double.longBitsToDouble(0x3f4abf8802d18c00L), Double.longBitsToDouble(0x3feabf0cd8000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0\uc476\ucd77\ubacb\u4cf9", "\udaa1\udc23\udb6c\uddda\ud917\udd8d\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc12\ubd97\udb5e\udfca\ue1ca\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1\uda63\ude80\u7c61\ud811\udee5\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\udae7\udce5\udad0\udc9e\udacc\udd66\ud80f\udf2f\uda28\udfbd\ud836\udd1e\u0506\uda20\udce2",
        57, 17894, 1907114099, 2964239280910375873L, -57894L, false, true, (char) 52039, (char) 63385,
        Double.longBitsToDouble(0x3fd1a326300d2b0aL), Double.longBitsToDouble(0x3fe8e77feb740e91L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 2, 2, "\uaa1e\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udb8c\uded6\ud9d8\uddac\ud969\udf75\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7\ud9dc\udee7", "\uc476", "\udbf8\udd5b\uda0d\udfcd\u4b8f\udaa1\udc23\udb55\udf4a\ud86e\udeb9\ud900\udff0\ud9d4\udc35",
        24, 75297, -2098091069, 4049129164368489656L, 24300L, false, true, (char) 52889, (char) 38701,
        Double.longBitsToDouble(0x3fea3ba5cb7c851bL), Double.longBitsToDouble(0x3feed37c34ed13dcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 0, "", "\ua537\u697f\u53a5\ub916\ucf64\uac05\u86d1\u998a\ua92c", "\u2ee2",
        -5, 45800, 966987359, 6483279772537961586L, 35618L, false, true, (char) 24281, (char) 63101,
        Double.longBitsToDouble(0x3fe3c86128f974dbL), Double.longBitsToDouble(0x3fe49b9f354688f4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\u86d2\ud87a\udff2\ud8f5\udebd\ud89b\udff9\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0\uc476\ucd77\ubacb\u4cf9\u9a56\u257b\u5f5b\u9536\u7367", "\ud8f1\udfcd",
        26, 81931, 942761350, 4679070380259643523L, 5069L, true, true, (char) 1266, (char) 14592,
        Double.longBitsToDouble(0x3fd62cb2c641b7a2L), Double.longBitsToDouble(0x3fe81a8b03f090c2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 5, 5, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b", "\u0e1e", "\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7\ud9dc\udee7\uda6a\udf49\uda11\udec7\ud980\udf45\ud99f\ude25\ud8b3\udd1e\udbf8\udd5b\uda0d\udfcd\u4b8f\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5",
        23, 63995, -745515499, -3670593045942042230L, -49753L, false, true, (char) 12018, (char) 4195,
        Double.longBitsToDouble(0x3fef84861050d4ebL), Double.longBitsToDouble(0x3fabd9dbb98aef10L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0\uc476\ucd77\ubacb\u4cf9", "\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbe3\udec9\ue12a\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1\ud842\udf70\udb16\udd4a\u970c\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\udae7\udce5\udad0\udc9e\udacc\udd66\ud80f\udf2f\uda28\udfbd\ud836\udd1e\u0506\uda20\udce2",
        59, 17894, 1907114099, 2964239280910375873L, -49593L, false, false, (char) 63625, (char) 6646,
        Double.longBitsToDouble(0x3fec629ddf22d077L), Double.longBitsToDouble(0x3fd1a326300d2b0aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0\uc476\ucd77\ubacb\u4cf9", "\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbe3\udec9\ue12a\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1\ud842\udf70\udb16\udd4a\u970c\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\udae7\udce5\udad0\udc9e\udacc\udd66\ud80f\udf2f\uda28\udfbd\ud836\udd1e\u0506\uda20\udce2",
        57, 17894, 1907114099, 2964239280910375873L, -57894L, false, true, (char) 52039, (char) 63385,
        Double.longBitsToDouble(0x3fd1a326300d2b0aL), Double.longBitsToDouble(0x3fe8e77feb740e91L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf19\u9c55\ud9fd\ude1c\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0\uc476\ucd77\uce9f\u4cf9", "\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbc3\udee0\ue12a\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66\ud86a\udfd1\ud842\udf70\udb16\udd4a\u970c\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\udae7\udce5\udad0\udc9e\udacc\udd66\ud80f\udf2f\uda28\udfbd\ud836\udd1e\u0506\uda20\udce2",
        57, 17894, 1907114099, 2964239282135112641L, -57894L, false, true, (char) 52039, (char) 63385,
        Double.longBitsToDouble(0x3fd1a326300d2b0aL), Double.longBitsToDouble(0x3fe8e77feb740e91L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 0, 2, "\u00bd\000\udbdf\ude16\udbd6\udf85\u362c\ud9d8\uddac\ud9c1\uded7\ud9c4\udda1\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda57\ude68\ud96c\udd4d", "\u26c0\uc476\ucd77\ubacb\u4cf9", "\udaa1\udc23\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud999\udcc2\ud92d\udc64\udafa\udcd5\uda26\udd7d\udb95\udd9a\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbe3\udec9\ue12a\ud87a\udd40\udaad\udfeb\udb12\udc74\ud806\udd66P\ud842\udf70\udb16\udd4a\u970c\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\udae7\udce5\udad0\udc46\udacc\udd66\ud80f\udf2f\uda28\udfbd\ud836\udd1e\000\uda20\udce2",
        57, 17894, 1907114099, 9877925355330497L, -57894L, false, false, (char) 52039, (char) 63385,
        Double.longBitsToDouble(0x3fd1a326300d2a00L), Double.longBitsToDouble(0x3fe8e77feb740e91L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 0, 2, "\000", "\u697f\u53a5\u00de", "\ud89b\udf9b",
        30, 19584, 945824589, 42137614205071074L, -18950L, false, false, (char) 25581, (char) 26089,
        Double.longBitsToDouble(0x3fde85536ee11ed2L), Double.longBitsToDouble(0x3fb9fa8583c86128L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 0, 10, "\ud809\udcd0\ud9ee\udc04\udbdf\udec0\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\uda4c\udf93\ud9e2\udc54\uda68\udc90\uda46\udec6\ud821\udf70\udb56\udcee\udb7a\udde4\uda11\udec7\ud980\udf45\udb7b\udd0b", "\u9a56\u257b\u5f5b\u9536\u7367\u9ec7\u8dfa\ua8a1\u601a\u578b\u901f\u22ae\u4ef2\u696a\u32b3\uc879\ua240\u25ab\u7880\u7e3c\u9d13", "\ud842\udf70\udb16\udd4a\ucc92",
        39, 81666, 1699571499, 2692459244848272653L, -97142L, false, false, (char) 45254, (char) 31595,
        Double.longBitsToDouble(0x3fe17e4367662199L), Double.longBitsToDouble(0x3fbce8057f638d60L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 11, 11, 2, "\ud833\udead", "\u3b7f\u53a5\ub916\ucf64\uac05\u86d1\u998a\ua92c\u0e1e\u8372\u8d8c\u355f\u7cbf\u22b6\u8d7c\u1a12\u0aaa\u26c0\uc476\u4143", "\uda0d\udfcd\u4b8f\udb65\ude87\udb3f\ude66\uda7a\udd99",
        18, 65954, 131589586, 2261250015243643843L, -77963L, true, true, (char) 52889, (char) 1413,
        Double.longBitsToDouble(0x3fb1dd2e5b165960L), Double.longBitsToDouble(0x3fe906de8f035160L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 3, "\ud833\udead\u3e16\udbdf\ude3b\ud9df\udf4f\uda88\udd74\ud9d8\udd06\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47\udb33\udc75\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7\udae2\udd4b\uda6a\udfe1\uda11\udec7\ud980\udf45\ud99f\ude25\ud9dc\udfeb\udbf8\udd5b\uda0d\udfcd\u4b8f\udb7d\udc87\udb3f\ude66\ud963\udf8d\udad4\uddbb\udb3d\udf12\ud927\ude28\ud999\udcc2\ud92d\udc64\udafa\udcd5\ud8bf\udeed\ud807\udef0\udbe9\udf55\ud98f\ude0f\ud9d2\ude53\udbe3\udec9\uda26\udd00", "\u7b2b\ua006\ub5ab\ud446\ud5a1\ud566\u2a34\ub19e\u4050\uab1c\u9b3b\ud20f\u750c\uc17f\u4ecb\u13e0\uaf7f\u8ac2\ub237\u4009\u3eeb\u0113\u985c\u5cf1\u18b7\ub94c\u94be\u31e5\u950d\u4570", "\udaf2\udc5e\ud97a\ude51\ud977\udf2a\ud96f\udf10\uda66\udc89\ud8f3\udfec\ud8ab\ude4b\ud9a7\udf6d\ufa79\ud984\ude41\udbf5\udf73\ud807\udfdd\ud956\udc47\ud854\udf36\ud94a\udfda\ud9e3\ude89\ud95f\udfd2\udaf5\udcac\udacf\ude0e\ud9a5\udc8a\ud80f\udff7\udbac\ude93\ud84e\udf03\udb88\udd8f\udb9e\ude7c\ud877\uddb2\udb7e\uded4\uda12\udde3\ud8d9\udd13\ud9d3\uddc3\ud9c3\ude56\uda2d\udc67\udbfa\udc2f\uda69\udf44\ud945\ude54\uda14\udf04\ud911\udc33\ud9a5\udfbb\udbef\udccd\ud990\udff1\udae9\udcd0\ud849\ude86\udabe\udfba\ua0f5\ud945\udf70\ud837\udf0f\ud9c6\uddb4\uda0e\udc59\ud88f\ude3a\uda33\udc6b\ud8f0\udc6d\udb64\uddda\udace\udcf0\udb62\udf8c\udae1\udf49\udb8d\udc96\ud87e\ude72\ud825\udcd5\udad7\udd17\uda8c\udcd6\ud980\udcf6\udbdc\uddd0\udaac\udc73\u7b9e\uda6f\udf20\udba1\ude06\udaf2\uddcb\ud853\udc6a\ud9ea\udfe6\ud8ff\udca4\ud8d9\udd5a",
        19, 60831, -63521568, -3458895933876814159L, -89083L, true, false, (char) 58201, (char) 65208,
        Double.longBitsToDouble(0x3fee7d1d898ed643L), Double.longBitsToDouble(0x3fd36f56e7a0ca60L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 11, 5, "\udafe\udef7", "\u3b7f\u6bdb\u763a\u065d\uac05", "\udb49\ude22\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\uddb2\uda68\udc90\ud989\ude51\uda57\uddf0\udae2\udd4b\uda6c\udd82\uda11\ude2f\ud980\udf45\ud878\udd32\ud9dc\udfc3\udbf8\udd5b\uda0d\udfcd\u4b8f\udb65\ude87\udb3f\ude66\uda7d\udd99\u0535\udb3d\udf12\ud81b\udd83\uda3f\uddd2\ud9fc\udc41\ud914\udf9c\uda82\udd88\udb95\udd9a\ud950\udcb1\ud9dd\udf8e\ud9d2\ude53\udbe3\udec9",
        -2, 11338, -288782304, -5421559908777690586L, 72195L, true, true, (char) 51702, (char) 31432,
        Double.longBitsToDouble(0x3fc63fec78aeba74L), Double.longBitsToDouble(0x3fd893dcf7b34a3cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 12, 2, "\ud833\udead", "\u3b7f\u53a5\u71f3\ubc42\uac05\u92f8\u7cce\u7bc7\u21ae\u1af4\u8d15\ucc96\u7cbf\uaaae\u1f3d\u1a12\u0aaa\u26c0\uc476\ucd77", "\uda0d\udfcd\udb39\udf81\ud83a\udd5d\udb4b\uddfe\uda7a\udd99\ud8f9\udf36\udae2\udcc3\uda10\ude13\ud99e\udef2\ud92d\udc64",
        45, 43968, 1450020995, -3201964687720747245L, 63863L, true, false, (char) 48782, (char) 12018,
        Double.longBitsToDouble(0x3fe81a8b03f090c2L), Double.longBitsToDouble(0x3fea0ea19f02f50cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 2, "\ud833\udead", "\u3b7f\ub381\u9d72\ucf64\uac05\u86d1\u998a\ua92c\u0e1e\u8372\u8d8c\u7053\u7cbf\uaaae\u1f3d\u1a12\u0aaa\u26c0\uc476\ucd64", "\ud8e0\udd32\u4b8f\udb65\ude87\udb3f\ude66\uda7a\udd99\u0535\udb3d\udf12\ud927\ude28\ud999\udcc2\ud92d\udc64",
        45, 43968, 1450020995, -3201964687720747245L, 63863L, false, false, (char) 48782, (char) 12018,
        Double.longBitsToDouble(0x3fe81a8b03f090c2L), Double.longBitsToDouble(0x3f95d43366f676e0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 15, 15, 2, "\ud833\udead", "\u3b7f\u53a5\ub916\ucf64\u38d4\u5995\u998a\ua92c\u0e1e\u8372\u8cee\u355f\u7cbf\uaaae\u1f3d\u1a12\u0aaa\u6a01\uc472\ucd77\u7b4e\u4cf9\u9a56\u257b\ua5aa\uc2b6\u55c3\u84d1\ud51f\u87cb\u0427\u578b\u901f", "\uda58\udf76\ud9db\udc12\ud9d2\ude53",
        59, 15383, -606997628, 5863778109874159363L, -86429L, true, true, (char) 63972, (char) 5350,
        Double.longBitsToDouble(0x3f9e157501e9d4c0L), Double.longBitsToDouble(0x3fd8f82836a44094L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 3, 15, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\ud86a\udeb9\udbbb\udec1\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\uda0c\uddc8\udb49\udf0c\ud9ef\ude9f\ud81e\ude47\udbbe\udfda\uda57\udd93\uda7f\udc3d\uda10\uddc4\ud96c\udde7\udae2\udd4b\ud85f\udc9c\uda11\udef2\ud980\udf45\ud99f\ude25\ud8b3\udd1e", "\u257b\u3db1\u9536", "\ud9d4\udd01\ud8f1\udfcd\ud999\udcc2\ud906\uddd0\ud805\udc4a\ud874\udc07\udb95\ude0b",
        46, 33757, 451368986, -4674686527352781822L, -61298L, false, true, (char) 31410, (char) 30011,
        Double.longBitsToDouble(0x3fabd9dbe981c660L), Double.longBitsToDouble(0x3fe9ecbec74a00bbL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 13, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\ud980\udc38\uda22\udc63\uda0a\udd62\udb63\uddc3\ud95e\udcc2\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud9da\ude30\ud80d\udd8d\udb90\ude10\uda68\udc90\uda10\uddc4\ud96c\udde7", "\u26c0", "\ud8b3\udd1e\udbf8\udd5b\uda0d\udfcd\u4b8f\ud81e\udca3\ud98e\udc57\udba5\ude3d\ud9a9\ude26\ud9d4\udd01\ud8f1\udfcd\uda35\udf71\ud991\udc9c\udafa\udcd5\uda82\udd8b\uda1c\udd7e\uda58\udfd0\ud9db\udc2c\ud9d2\ude53\udbe3\udec9",
        -2, 11338, 1368115551, -8015634367480372240L, -7051L, true, false, (char) 55061, (char) 55300,
        Double.longBitsToDouble(0x3fe256e582ed7ddfL), Double.longBitsToDouble(0x3fe7ac1faa33c442L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 9, 15, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb49\ude22\ud9ef\ude9f\ud81e\ude47", "\u7cbf\uaaae\u1f3d\u1a12\u0aaa\u26c0\uc476\ucd77\ubacb", "\u4b8f\udaa1\udc23\udb6c\uddda",
        58, -979, -509893940, 564937145121346281L, 70618L, false, true, (char) 53617, (char) 44162,
        Double.longBitsToDouble(0x3fe96e9c818acd0fL), Double.longBitsToDouble(0x3fef4c2cdc4774b9L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\udaa0\udcd4",
        22, -468, 464300857, -7215992000166756301L, -90963L, false, true, (char) 39543, (char) 54880,
        Double.longBitsToDouble(0x3fc40778397e6400L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 3, 2, "\udad9\udd3b\uda0a\udff3\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud9aa\udf9c\uda3e\udf27\uda34\udd72\ud946\udca4\udbb5\udccd\u4c08\ud9a1\udc79\uf2d0\ud9ff\udd63\uda3e\udf4e\uda91\uded4\u6689", "\ud06c", "\uda23\udc87",
        35, 35185, -1997245805, 8395146511398386844L, 53109L, true, true, (char) 38819, (char) 55025,
        Double.longBitsToDouble(0x3fc5e6e1cf562590L), Double.longBitsToDouble(0x3fe903b98f035160L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 11, 1, "\ud801\uddd0\udbdd\uddbc\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9b9\udd7c", "\u13a2", "\udaf1\udcb4\ud802\udcb2\u8c6e\ubd01\uda60\ude90\uda10\uddc4\ud96c\udde7",
        59, -764, 1426063360, -6167369730851705289L, 96729L, false, false, (char) 64377, (char) 57367,
        Double.longBitsToDouble(0x3fc38e9034cf4508L), Double.longBitsToDouble(0x3fb9757f0aa0e7c0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 8, 5, "\uda13\uddca\udbdd\uddce\udbdf\ude2b", "\u0dc3\ucf64\u1106\u13a2\u6abd\ucd51\u0cc5\u86f8\u707b\u4c53", "\ud96c\udde7\udae2\udd4b\uda6a\udfe1\uda17\udeca",
        31, 21975, 1044828536, -2347800868849022880L, -7031L, false, false, (char) 47803, (char) 15964,
        Double.longBitsToDouble(0x3fd8c5f56f37102cL), Double.longBitsToDouble(0x3fd56847e7863f70L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 14, "\ud986\udde0\ud8b3\ude34\udbdf\ude2b", "\u51fa\ucf64\uac05\u86d1\u998a\u03c0\ubac5\u2311\u9a4b\u64d4", "\ud888\udf76\udbdc\udd48\uda6a\udfe1\uda11\udec7",
        4, 35144, 203754599, 4354420316469364985L, 60442L, false, false, (char) 22133, (char) 32353,
        Double.longBitsToDouble(0x3fe0018aaf57e19bL), Double.longBitsToDouble(0x3fe74c53fbc31f61L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 14, 5, "\ud951\udde9\u1e70\udbdf\ude2b\udbd6\udf85", "\ua00a\uac05\u11c8\u73d7", "\ud935\udc53\udbe4\udf85",
        4, 53640, -1020092180, -4150173831128273888L, 26566L, false, true, (char) 24281, (char) 22786,
        Double.longBitsToDouble(0x3fe8c064c0f9743fL), Double.longBitsToDouble(0x3fec9b9f35da3e65L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 10, 10, 11, "\ud992\ude09\u0efc\udbdf\ude2b\udbd6\udf85\udaa0\udcd4", "\u0a8a\u6231\u9e0b\u4ff0", "\udbe4\udf85",
        34, 42480, 194685412, 4364333165388806807L, 32787L, true, true, (char) 12599, (char) 63914,
        Double.longBitsToDouble(0x3fe29e76dc2abc72L), Double.longBitsToDouble(0x3fec9b9f35da3e65L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 2, 0, "\000\000\udbac\ude16", "\u3947\000", "",
        -5, -1000, 945815552, 197843373522944L, -99881L, false, false, (char) 59196, (char) 26863,
        Double.longBitsToDouble(0x3fb465bad0bfe4a0L), Double.longBitsToDouble(0x3fd77560fb670b10L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 11, 5, "\udafe\udef7", "\ubb39\u0d43\u7666\u065d\uac05\u86d1\u998a\ua92c\u0e1e\u8372\u8d8c\u34ff\u7cbf\u01c0\u5337\u1a12\u5afa\u2628\u517b\u39e9\uc052\u4cf9\u9a56\u257b\ud34c\u8492\u10a1\u2f51\u3402\u1cc1\u68fe\u7ade\ud157\u22ab\u4ef2\ub296\u3e2f\ua33f\ud51a\u256c\u7880\u5bb9\u5ed0\u76f4\ub5ab\u1f4a\ud463\u6a72\u3371\u5442\ub1bf", "\udbb7\udc2d\ud986\ude1a\ud993\udc38\udbda\uddcb\udaaa\udd94\ud9a3\uddc6\u13d2\ud9ce\udec4\udabb\ude92\ud9e6\udd4e\udae1\udeac",
        24, -51, -2042245468, 6676937284777039329L, -67815L, true, true, (char) 460, (char) 21390,
        Double.longBitsToDouble(0x3fbf0987594a2b38L), Double.longBitsToDouble(0x3fd9a3998d31bda4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 13, 0, "", "\ua537\u3f6a\u0fe4\ub401\u22bf\u778b\u86d1\u998a\ua92c", "\ud80d\udd8d",
        7, -1000, 956301312, 6483213799536368366L, 35618L, false, true, (char) 24281, (char) 63101,
        Double.longBitsToDouble(0x3fe3c86128f974dbL), Double.longBitsToDouble(0x3eccd40000000000L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbdf\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\u9c55\udb99\ude2c\ud9fd\udf61\udba4\udf0a\udbea\udcfe\ud9e1\udcfd\uda68\udc90\uda10\uddc4\udbb1\udfdf", "\uaca2\u64b9\ucd77\ubacb\u4cf9\ua88e\u9a51\u5f5b", "\ud9ad\ude5c\ud8be\udd9e\uda9a\udc1d\udafc\uddbf",
        -1, 26316, 1083598264, 6227792751292864021L, -34858L, true, false, (char) 56742, (char) 48800,
        Double.longBitsToDouble(0x3fe906de8f035160L), Double.longBitsToDouble(0x3fef84861397230dL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 2, 2, "\ud809\udcd0\ud8b3\uddc7\udbc6\ude2b\udbd6\udf85\udaa0\udcd4\ud9d8\uddac\ud969\udf4c\ud9ef\udcda\ud89b\udf9b\ud8cc\udfa7\udb49\ude95\ud9ef\ude9f\ud81e\ude47\u8c6e\ud9d4\ude12\uda68\udc90\uda10\uddc4\ud96c\udde7\ud9dc\udee7\uda6a\udf49\uda11\udec7\ud980\udf45\ud99f\ude25\ud8b3\udd1e\udbf8\udd5b\uda0d\udfcd\udbef\udd1a\uda94\udeea\udb6c\uddda\ud86e\udeb9\ud900\udff0\ud9d4\udc35\ud8f1\udfcd\ud942\udcb2\ud91e\udc67\udafa\udcd5\uda82\udd8b\udb95\udd9a\uda58\udf76\ud9db\udc12\ud9d2\ude53\udbe3\udec9\ue12a\ud87a\udd40\ud998\udfdd\udaaa\ude6a\ud806\udd31\ud86a\udfd1\ud842\udf70\ud9f6\ude1b\u88e5\ud90d\udd35\udbef\uddb4\udab1\udc23\udb77\udc95\udae7\udce5\udad0\udc9e\u1ba4\ud883\uddd5\uda28\udfbd\ud836\udd1e\ud940\udf45\uda20\udd92\udba7\udc29\udb11\udde2\udbb7\udf25\uda60\ude58\uda47\udf81\ud889\udd61", "\u392e\u7abb\u4eb6\u8d86\uaae6", "\ud9ea\ude89\ud90d\udd56\udaed\udfa0\ud83c\udeca\uda8d\udea2\ud8e5\udf4c\ud8ba\udd07\ud9c8\udee0\ud830\udfe5\ud9c7\udd45\u0cf7\ud8fa\udfc7\ud8ae\udd88\ud953\udf53\ud8b0\udcf9\u830a\uda0a\udcad\u6542\uda86\uddc8\udaa8\uddfd\ud936\ude71\udbea\udedd\ud805\udea9\u6ad5\udb07\uddc8\uda58\udf91\udb6a\udee3\ud8c4\ude7c\u0a38\ud900\udf6e\ud912\udd50\ud85d\udc54\u0fdf\u9b00\uda4d\udfee\udb50\udd9a\udbc0\udf54\ud97c\ude32\ud881\udf27\ud823\udd80\udbc8\udf8f\ud9a7\udfa4\ud831\udd8e\ud8e8\udf47\u4418\ud82c\udfd7\ud935\udd69\udb06\udd6d\uda01\udd51\ud8f5\ude81\uda4c\udd10\udb6a\udf40\ud94d\udd04\ud9c6\udc26\ud927\udc65\udaf9\udc2c\ufbe3\udaf2\udedf\ud810\udf1e",
        18, 99492, -1615636511, -6726787096643546404L, 67220L, true, true, (char) 52936, (char) 8481,
        Double.longBitsToDouble(0x3fe8a93da7639993L), Double.longBitsToDouble(0x3fcdc9c526786370L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addAndOrUpdate|org.jfree.data.time.TimeSeries|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clear||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|equals|java.lang.Object|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
