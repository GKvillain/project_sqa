package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimeSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u68bc\u5bf1\u0502\ud23f\ub14d\u8295", "\uda16\ude0d\ud90f\udeb7\uda61\ude58",
        45, 88751, 2023583228, 1861307781573072993L, 12280L, false, true, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fede0ca1d963fccL), Double.longBitsToDouble(0x3fe0315770e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\u7c66\udad7\udeeb\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u68bc\u5bf1\u0502\ud23f\ub14d\u8295", "\uda16\ude0d\ud90f\udeb7\uda61\ude58",
        45, 88751, 2023583228, 1861307781573072993L, 12280L, false, true, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fede0ca1d963fccL), Double.longBitsToDouble(0x3fe0315770e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\ud9cc\udff7\udad7\uded3\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\udab8\udd22\ud98a\ude96\ud80e\ude74\udb1f\udd0d\ud9e4\uddea\uda17\udd13", "\u5bf1\u0502\ud23f\ub14d\u1753\u058f\u8a57\u2a73\u2c8a\u67d1\u2ed2\ucf6f\u0ca4\u582d\u2241\u8d51\u09ca\u7faa\uc50b\u8b84\u76bc\u9877\u1d7e", "\ud91b\udf68\udbb5\udeeb\ud9a2\udd0c\ud823\ude0d\udb10\udcf4\udbff\udf81\udbec\ude8e\ud850\udcda\ud9f7\udcc3\ud982\ude65\udbba\uddfb\ud809\udc79\ud8ce\udc6d\ud8c0\udc8c\ud8f0\udd5b\u4c60\ud98f\udf15\udb9e\udd46\udb86\ude48\ud832\ude48\udbc5\udfb9\ud900\udcdd\ud9bd\udfbf",
        17, 84349, 84394542, 5000973051086214970L, 62940L, true, true, (char) 54535, (char) 38464,
        Double.longBitsToDouble(0x3fb7f60c8ebe91d8L), Double.longBitsToDouble(0x3fc39d2b1ffcbd10L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 9, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud88b\udc71\ud98c\udde4\udbeb\udd88\u3f83\ud8e7\uddfa\ud9db\udcbd\ud98e\udf41\udb3a\udf54\ud89e\udc29\u316b\ud87e\udde5\udaa6\udefd\ud945\udc5a\ud98d\udf75\ud8b8\udf36\u0ea7\ud80e\ude74", "\u8ba6\u4d7f\u68c0\u9a76\ub021\u0813\u5734\uc0e1", "\uda16\ude0d\ud90f\udeb7\uda61\ude58\ud8c0\udc02\ud8a5\udf1d\udba2\udc7e\u63fc\ud803\uddb7",
        54, 28949, 1483230471, -5318376750021646670L, 15306L, false, false, (char) 7279, (char) 8100,
        Double.longBitsToDouble(0x3fbfcd5dd508d750L), Double.longBitsToDouble(0x3fe202c6984436b4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb01\udc14\uda78\udc4b\udb4d\udea5\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\ude78\ud922\udec0\u9d4f\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\ud8b5\udc7c\u1884", "\000", "\udb66\udc8b",
        22, 69078, -1633590091, -7180848104236840728L, -100000L, false, true, (char) 10798, (char) 29237,
        Double.longBitsToDouble(0x3fe5be92ae987851L), Double.longBitsToDouble(0x3fe963758c86582aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 2, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\u23b8\udbbb\udf5b\udab3\udd3c\uda15\udea1", "\ucc85\ub7e4\u7b07", "\udadb\udf0f\uda2c\udd50",
        46, 23386, -2118401563, -997575789499663477L, 86020L, false, false, (char) 19557, (char) 59716,
        Double.longBitsToDouble(0x3fdd6a2fc96b8a6eL), Double.longBitsToDouble(0x3fb8c1a18744e2c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 8, 14, "\udb01\udc14\uda8b\udddc\udb5b\udc7c\ud9a0\udd9b\ud85b\udd84\ud8f7\udd45\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\udb58\ude60\udae7\udd5c\udac0\ude9a\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74\udb1f\udd0d\ud83c\udc75\uda17\udd13\ud84c\udfce\uda1a\udea6\uda21\udfa9", "\ub1c0\ubd15\u058f\u6090\u2a73\u6bb7\u53a6\u89df\u1321\u8243\ua7f9\u8bfa\u7e0d\u09ca", "\u4c6f",
        50, 24488, 1804393990, -7452981417734769850L, -16234L, false, true, (char) 19677, (char) 11588,
        Double.longBitsToDouble(0x3fe9e396be73eb51L), Double.longBitsToDouble(0x3fb969a907096ba0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "", "\u8b89", "\ud89e\udfaf\udab3\ude0a\udad7\udea2\u00b4\u4e96\udb2f\udd21\ud89e\udc29\u316b",
        39, 99438, 1616758477, 6581207867719192025L, -84101L, true, false, (char) 60967, (char) 0,
        Double.longBitsToDouble(0x3e43600000000000L), Double.longBitsToDouble(0x3fc15b590d000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 8, 14, "\udb01\udc14\udba0\ude4d\ue311\ud9c3\udc7c\ud96d\uddeb\ud89e\udfaf\ud9ad\ude07\udad7\udea2", "\ub2e2\u4c6d", "\ud932\udce2\ud9a0\udf3c\udb8e\udf36\uc3c0",
        21, 72437, -299375077, -2758283060486437895L, -82957L, false, false, (char) 51927, (char) 45865,
        Double.longBitsToDouble(0x3fc6a96e22ca7a84L), Double.longBitsToDouble(0x3fcd138b08a8b7b4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 8, 14, "\udb01\udc14\uda78\udc4b\ud8f6\udc8d\ud9a0\uddb2\ud8eb\udfea\ud8a1\udd42\ud8d3\udf1a\udad7\udf1e\ud922\udec0\udaac\udd31\uca8d\ud8f2\udd9c\ud999\udce1\ud87e\udde5\ud932\udce2\udb4f\udc7a\ud8b1\udfe3\udab2\udde3\udadc\udc10\ud80e\ude74", "\u9115\uc698\u68bc\u5bf1\u0502\ud10f\uc533\u8295", "\uda16\ude0d\ud90f\udeb7\uda61\ude58",
        45, 88751, 2023583228, 1861307780415445089L, 12280L, false, true, (char) 28699, (char) 41875,
        Double.longBitsToDouble(0x3fc416d9f6ed4d90L), Double.longBitsToDouble(0x3fe0315771e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\ud9a7\udee6\ud87e\udde5\ud932\udce2", "\u9780", "\ud80e\ude85\udab4\udf76\uda17\udd13\ud84c\udfce\uda1a\udea6\udb4f\udd20\udad1\uddc4\ud8a9\udeeb\uda8c\udf75",
        5, 23014, -1189857565, -5604722438800314978L, 68452L, true, true, (char) 29237, (char) 49420,
        Double.longBitsToDouble(0x3fe4c6728f2c6eb8L), Double.longBitsToDouble(0x3fc0cb055acad8c4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 9, 1, "\udb01\udc5f\uda81\udfe3\uda70\udf66\ud9a0\uddae\udb78\udfd4\uda73\udd2e\udab3\ude0a\udaa8\udde5\udb90\udd38\ud986\ude08\uefb4\udba4\udc29\ub921\ud8d2\udf4f\uda6b\udd66\udb8f\udfdc\udb67\ude5c\ud9bb\udf21\uda50\udc1b\ud80e\ude74", "\u91dd\u26e2\u68bc\ua059\u98e9\u888e", "\ud94b\udeee",
        0, 2544, 65085107, -410353467959716414L, 32088L, true, true, (char) 29237, (char) 952,
        Double.longBitsToDouble(0x3fab38e1627b27f0L), Double.longBitsToDouble(0x3fc0cb055acad8c4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb01\udc14\uda78\udc4b", "\u81f8\u2af3\ud1e7", "\u4ee5",
        54, 47908, 421484528, -6203610925119153202L, -24816L, true, true, (char) 22747, (char) 30610,
        Double.longBitsToDouble(0x3fe0dc0ddc2cee27L), Double.longBitsToDouble(0x3fefcecdc6a412baL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 14, "\uda58\udf80\ud902\udd36\udb5b\udc7c\ud9a0\udd9b\udbf7\udc0e\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd4a\ud89e\udc29\udbff\udca4\ud87e\udde5\ud9b4\udda4\udb4f\udc70\udb8e\udf11\udb21\udc37\udb4f\udd7c\ud876\ude0b\ud812\uddfb\ud9e4\uddea\uda17\udd13\ud84c\udfce", "\u3c8d\ub210\u41d6\u873b\u8cbd\u3503\u8619\u9192\u8402\u31fb\uaae2\u1cf0", "\ud8ad\uddce\udbfb\udd1d\udb4f\udd88\udb1b\ude5b\ud873\ude7b\ud9dc\udf7e",
        46, 28219, -1602047773, -8986019574868544708L, -40909L, false, false, (char) 29415, (char) 50472,
        Double.longBitsToDouble(0x3fec3493d2ae5135L), Double.longBitsToDouble(0x3fe30ae92dbd7a90L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 8, 14, "\udb08\ude9c\ud9ec\udc4a\udb5b\udc7c\uda5e\udd9a\ud8eb\udfea\ud89e\udfaf\ud8c6\ude74\ud922\udde3\ud809\udfe8\ud175\ud9a3\udf53\ud89e\udc29\u316b\ud87e\udde5\ud9c4\udfe1\udb4f\udc7a\udb8e\udf11\uc3c0\udab2\udfbb\uda1a\udc5a", "\u6a2b\uc681\u68bc\u5bf1", "\udb49\udecb\udb28\udcc6\ud8ee\udc32\ud830\udc49\uda16\ude00\ud90f\udeb7\ud89a\ude8b\uda92\udd45\ud9f6\udee8",
        12, 37548, -1906986575, 998996492824982104L, -12826L, false, false, (char) 28927, (char) 32098,
        Double.longBitsToDouble(0x3fe0315770e36b8cL), Double.longBitsToDouble(0x3fd5d6550f0eb964L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 8, 8, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b", "\u9ae7\u9ec1\ubbab\u8534\u0ac2\uae81\u65b6\u3344\u36ed\ubcab", "\udadc\udc10\ud80e\ude74\udb1f\udd0d\ud9e4\uddea\uda17\udd13\ud84c\udfce\uda1a\udea6\udb4f\udd20\udad1\uddc4\ud86b\udd48\u76f8\ud8f3\udda9\uda11\udc12\udae4\udef4\ud8bf\udd67\ud902\udf2c\uda61\ude58",
        45, 88751, 2023583228, 1861307781573072993L, 12280L, false, true, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fede0ca1d963fccL), Double.longBitsToDouble(0x3fe0315771826b8cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\u713b", "\u6a2b\uc681\u68bc\u5bf1\u0502\ud23f\ub14d\u8295\u058f\u8a57\u2a73", "\udaad\udc98\ud8a8\udf61\uda95\udd17\udab8\udf16\ucdb0\ud8ad\uddce\ud9f5\ude1b\ud841\udc5e\ud9e2\udc2c\ud856\udc2f\ud9dc\udf7e",
        46, 27990, -161500957, 2341741133720255699L, -40787L, false, false, (char) 44972, (char) 36467,
        Double.longBitsToDouble(0x3fd00575138ceebcL), Double.longBitsToDouble(0x3fa1faad9f63a250L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb5b\udf83\udb60\ude0c\udb5b\udc7c", "\u21f7\ud1e7\u9f6a\ua2d5\u8534\u0ac2\uae81\u65b6", "\udb4f\udc7a\udb8e\udf11",
        41, 23386, -2118401563, -1285806165594694612L, 86020L, false, false, (char) 25426, (char) 59743,
        Double.longBitsToDouble(0x3fcad45f92d52dc4L), Double.longBitsToDouble(0x3fc653d423a27160L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 12, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\ud8fb\udd98\udb2d\udd16\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u68bc\u5bf1\u0502\ud23f\ub14d\u8295", "\uda4f\udf66\ud90f\udeb7\uda61\ude58",
        45, 88751, 2023583228, 1861307781573072993L, 12280L, false, true, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fede0ca1d963fccL), Double.longBitsToDouble(0x3fe0315770e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "", "", "\ud8eb\udfea\ud89e\udfaf\udab3\ude0a",
        41, 7884, 0, 4899916394077784556L, -100000L, false, false, (char) 59693, (char) 22747,
        Double.longBitsToDouble(0x3fde5b5adc370376L), Double.longBitsToDouble(0x3fa67713bf9d9b80L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 8, 14, "\uda03\udcf8\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea", "\u9ec1", "\udb2f\udd21\ud89e\udc29\u316b",
        39, 99438, 1616758477, 6581207867719191992L, -84101L, true, false, (char) 35555, (char) 23985,
        Double.longBitsToDouble(0x3fe52095d4d857a2L), Double.longBitsToDouble(0x3fc15b590d03187cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud8b8\udff3\udab3\ude0a\ud8c3\udcd7\ud922\ude31\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u6866\u5bf1\u0502\uaaa7\uc578\u8295", "\ud9e6\udcd4\ud980\udd17\ud81b\ude1c",
        27, 59308, 2023583228, -7570918688001023647L, 12280L, false, false, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fe8dd521d963fccL), Double.longBitsToDouble(0x3fe0315770e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 14, "\ud96a\ude0a\ud91f\ude6b\ud887\ude3f\ud9a0\udd42\uda78\ude9a\ud89f\udc0a\udb87\udfd0\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21", "\u3344\u36f9\ua903\u69ef\u0baa\u8c5b\u143e\u997c", "\ud84c\udfce\uda1a\udea6\udb4f\udd20\udad1\uddc4\ud86b\udd48\u76f8",
        59, 27687, -1189857690, -5604722438800314978L, 68452L, true, true, (char) 29237, (char) 49420,
        Double.longBitsToDouble(0x3fe4c3c28f2c6eb1L), Double.longBitsToDouble(0x3fc0cb055acad8c4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud88b\udfaf\udab3\ude0a\udb49\udffa\ud922\udec0\u4ee5\udb2f\udd21\ud9f9\udc76\ud8ce\udcef\ud87e\uddf0\ud932\udce2\udbbb\udc35\udb92\udd56\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\uce4e\u52a3\uc4dd\ud228\ub14d\u8295", "\uda16\ude0d\udb0b\ude56\uda61\ude89",
        45, 88751, 2023583228, 1861307781573072993L, 12280L, false, true, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fede0ca1a789e8fL), Double.longBitsToDouble(0x3fddef7881c6d718L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 15, 0, 14, "\udb01\udc14\ud920\ude28\ud826\udcd5\ud9a0\udd30\ud8eb\udfea\udb7e\udd40\udb90\udc6a\ud9d8\udc36\ud820\udf81\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud8da\uded3\u80df\udb58\udcbf\udb8e\udf11\uc3c0\udadc\udc10\ue899", "\u694f\ubfb3\u5480\u5bf1\u0502\ud23f", "\ud9aa\udcfb\ud812\udda6\uda16\ude0d\ud90f\udeb7\ud9a2\udc19\ud95c\udfd9\ud966\udec0",
        20, 24365, 433530658, 8696832374189700760L, -12826L, false, false, (char) 28927, (char) 32098,
        Double.longBitsToDouble(0x3fe0315770e3d5a7L), Double.longBitsToDouble(0x3fc6e0bd6705f650L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 1, 13, "\udb01\udc14\ud948\udd65\ud93a\udc1e\u1e33\ud8c7\udf71\ud98e\udc0f\udb46\udcdd\ud832\ude8c\ufc59\u4ee5\ud943\udcaa\ud89d\udf76\u316b\ud923\ude98\ud939\ude32\ud8a6\udca6\udb8e\udf11\uc3c0", "\ub8f4\u96cd\u9596\u16a7\u68bc\u5bf1", "\ud8c4\uddfe\ud848\udd87\udbc3\udfea\uda6d\udd93\ud840\ude19\udbc7\udebf\ud887\udc9c\uda7c\udc4f\udafd\udeff",
        38, 78489, -766138783, 8669973229268481688L, -98484L, false, false, (char) 28927, (char) 21750,
        Double.longBitsToDouble(0x3fe0342c4d136b8cL), Double.longBitsToDouble(0x3fce05ecb8949f60L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8b5\udf39\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udabc\udf9e\ud80e\ude74", "\u6a2b\uc681\u68bc\u5bf1\u0502\ud23f\ub14d\u8295", "\uda16\ude0d\ud90f\udeb7\uda61\ude58",
        45, 88751, 2023583228, 1861307781573072993L, 12280L, false, true, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fede0ca1d963fccL), Double.longBitsToDouble(0x3fe0315770e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 8, 11, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9d9\uddd7\udb12\ude78\ud89e\udfaf\udbb3\uddf0\udad7\udea2\ud99a\udcfc\ud9e1\uddad\udb2f\udd21\udb22\udfcc\ud992\udc4a\ud852\udd1d\ud932\udce2\uda05\udcf5\ud866\udf05\uc318\ud95f\uddec\udb50\ude00\uda40\udf9d\ud9e4\uddea\uda17\udd13\ud84c\udfce\ud9de\udea8\udb46\udc20\ud9af\udc52\udb0e\udd2f\u4cfa\uda20\uded2\udb89\udf8b\uda06\udc82\ud9bb\udc7c\ud90f\ude20\udb9a\udeb8\ud80c\udc17\ud9e7\udfc1\ud9f2\ude01", "\u61e5\uc83c\ub08d\u6a37\u2bfc\ub378", "\ud8da\udfe1\ud98e\ude8b\uda0c\ude49\udbe1\ude9b\ud923\udd51\udad6\udeec\u3176\udb3d\udf86\ud9d3\udde0\udb16\udddd\ud8d9\udf14\udbc5\udec3\udb51\udc7f",
        53, 91405, 1926712975, 6052335348537692710L, 30817L, false, false, (char) 54795, (char) 64348,
        Double.longBitsToDouble(0x3fe1e8925ebdd598L), Double.longBitsToDouble(0x3fe2d36df2371727L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud85c\udee4\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\udbf9\uded7\udb2f\udd21\ud89e\udc29\u316b\ud9e6\udf4e\ud941\udf16\uda2e\ude2a\udaf3\ude28\uc3c0\udadc\udc10\ud8d3\udcf5", "\u6a2b\uc681\u68bc\u5bf1\u0502\ud23f\u4cdc\u8257", "\uda16\ude0d\ud90f\udeb7\uda61\ude58",
        45, 23215, 2023583228, 1861307781573072993L, 12280L, false, true, (char) 44208, (char) 37163,
        Double.longBitsToDouble(0x3fec7ad05715ad34L), Double.longBitsToDouble(0x3fe0313bc0e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u68bc\u5bf1\u0502\ud23f\ub14d\u8295", "\uda16\ude0d\ud90f\udeb7\uda61\ude58",
        45, 88751, 2023583228, 1861307781573072993L, -19208L, false, true, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fede0ca1d963fccL), Double.longBitsToDouble(0x3fe0315770e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 2, 6, "\udb01\udc14\ud98f\udd12\udb50\ude3f\ud9a0\udd9b\ud8eb\udfea\uda77\udfb6\udaa6\udc43\udad7\udea2\ud922\udec0\ud930\udf32\udb2f\udd21\ud8d1\udda2\ud86b\udd71\ud83f\udf59\ud9bf\udef8\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74\udb1f\udd0d\ud9e4\uddea\uda17\udd13\ud84c\udfce\uda1a\udea6\udb4f\udd20\udad1\uddc4\ud86b\udd48", "\u4380\u8a57\u2a73\u6b91\u53a6\u89df\u74b9\u1cf0\u582e\u2241\u8d51", "\ud9e2\udc2c\ud856\udc65\ud9dc\udf7e\uda9a\udc9b\ud961\ude8e\udaeb\udddb\ud8ba\udf2d\udbe9\udef0\udae6\udeae\ud999\udf84\uda27\udc26",
        17, 15650, -228069006, -7233636351538268501L, -54787L, false, true, (char) 6538, (char) 12798,
        Double.longBitsToDouble(0x3fcacead4a589798L), Double.longBitsToDouble(0x3fe91b6f3c655b6aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 0, "", "\u8b89\u61f6\u00b1\000", "\ud922\udec0",
        -5, 68184, -501315092, 1810262264146272187L, 16429L, false, true, (char) 59693, (char) 34501,
        Double.longBitsToDouble(0x3fde5b575c370376L), Double.longBitsToDouble(0x3fa67713bf9d9b80L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\ud9cc\udff7\udad7\uded3\ud922\udec0\u4ee5\udb2f\udd21\udbef\uded1\u6732\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\udab8\udd22\ud98a\ude96\ud80e\ude74\udb1f\udd0d\ud9e4\uddea\uda17\udd13", "\u5bf1\u0502\ud23f\u77cf\u0113\u058f\u8a57\u2a73\u2c8a\u67d1\u2ed2\ucf6f\u0ca4\u582d\u2241\u8d51\u09ca\ubbcf\ub42a\u8bd3\u76bc\u88a9\u5317", "\ud91b\udf68\udbb5\udeeb\ud9a2\udd0c\ud823\ude0d\udb10\udcf4\udbff\udf81\udbec\ude8e\ud850\udcda\ud9f7\udcc3\ud982\ude65\udbba\uddfb\ud809\udc79\ud8ce\udc6d\ud8c0\udc8c\ud8f0\udd5b\u4c60\ud98f\udf15\udb9e\udd46\udb86\ude48\ud832\ude48\udbc5\udfb9\ud900\udcdd\ud9bd\udfbf\ud848\udedb\uda23\ude57\udb88\ude79\ud8ab\udc92\udb5f\uddaa\ud9b7\udc8e\ud8b1\udfc5\uda5c\udc0e\udba6\udf54\ud9e6\ude71\ud9de\uddac\ud898\udc81\ud83b\udf65\udb76\ude68\ud9d0\udf52\udab4\udd6a\ud91e\udc2c\ud833\udcaf\uda8f\udc3f\ud961\ude73\udb81\udc5b\ud8b5\udc20\udbea\udd9e\ud977\udf0b\ud92f\udffc\ud943\udeb2\ud8fe\udf88\udbf2\udd47\uda90\uddb8\ud8fb\udd0f\ud8cd\uded5\ud939\udd32\uda54\udcab\ud90b\ude48\ud9f2\uddd8\uda8f\udcd5\ud819\udd1d\uda74\udf92\ud891\udfa1\uda3f\udc01\udae3\udff6\uda8e\udf93\udbfe\udcd3\ud867\uddfd\udb25\udf53\udab5\ude96\uda4a\udc99\u09d8\ud8cd\udc8c\udbbc\udcf9\ud81d\udd5c\uda20\udc28\ud8b0\udc8e",
        9, 47355, -32940512, -7914258297650775455L, -41558L, false, false, (char) 3860, (char) 48959,
        Double.longBitsToDouble(0x3febbf1630a4b6bfL), Double.longBitsToDouble(0x3fe1d356a29ebedcL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 4, 7, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud88b\udc71\ud98c\udda4\udbeb\udd88\u3f83\ud8e7\uddfa\ud9db\udcbd\ud98e\udf41\udb3a\udf54\ud89e\udc29\u316b\ud87e\udde5\udaa6\udefd\udba2\ude5f\ud98d\udf75\ud8b8\udf36\u0ea7\ud80e\ude74", "\u8ba6\u4d7f\u68c0\u9a76\ub021\u0813\u5734\uc0e1", "\uda16\ude0d\ud90f\udeb7\udbfe\udc28\ud87b\udd42\ud8a5\udf1d\udba2\udc7e\udb6a\ude5b\udb33\udc6f",
        9, 28949, 1483230471, -5318376750021646670L, 15306L, false, false, (char) 7279, (char) 8100,
        Double.longBitsToDouble(0x3fbfcd5dd508d750L), Double.longBitsToDouble(0x3fe202c6984436b4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 14, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud88b\udc71\ud98c\udde4\udb04\udd15\ud92f\udcc5\ud8e7\uddfa\ud8e3\uddda\uda4a\udf37\udaae\udcb1\ud896\udf56\u316b\ud87e\udde5\udaa6\udefd\udb8e\udf6b\ud98d\udf75\uda08\udcc4\u0ea7\udbec\udc01", "\u2605\u4d7f\u68c0\u9a76\ucb33\u0813\u5734\u96cf", "\uda16\ude0d\ud90f\udeb7\uda61\ude58\ud8c0\udc02\ud8a5\udf1d\udba2\udc7e\u63fc\ud803\uddb7",
        54, 28949, 1483230471, -5318376750021646670L, -89715L, false, true, (char) 7325, (char) 8100,
        Double.longBitsToDouble(0x3febf9abba06023bL), Double.longBitsToDouble(0x3fe202c6984436b4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud88b\udc71\udaf6\udd24\udb14\udcb7\udbf0\udc88\ud8e7\uddfa\ud9db\udcbd\ud98e\udf41\udb3a\udf54\ud89e\udc29\ud8a1\udcf4\ud9df\udcbc\udab2\udf61\ud945\udc5a\ud98d\udf75\udbb0\udf38\u0ea7\ud80e\ude74", "\u8ba6\u4d7f\u2c9b\u25b8\uaf86", "\uda8d\udeff\ud9bb\udd45\uc2c4",
        42, 64936, 1985720159, -5271889622737239773L, -65184L, true, false, (char) 49539, (char) 18326,
        Double.longBitsToDouble(0x3fd07583090cb0d0L), Double.longBitsToDouble(0x3fe595b18f101943L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 9, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud88b\udc71\ud98c\udde4\udb70\udd8a\uda60\ude6d\ud8e7\uddfa\ud9db\udcbd\ud98e\udf41\udb3a\udf54\ud89e\udc29\u316b\u6d74\ud819\udc0f\ud945\udc5a\ud98d\udf75\ud8b8\udf36\udadb\udcf0\udbc9\udd99", "\u9ae0\u4d7f\u68c0\u9a76\u3022\u0813\u7f7b\u1af4", "\uda16\ude0d\ud90f\udeb7\uda61\ude58\ud8be\udd02\ud8a5\udf1d\udba2\udc7e\u63fc\ud803\uddb7\ud814\ude23\ud9cc\ude77\ud850\ude44",
        48, 50602, -64465136, 3093477710308892166L, -69877L, true, true, (char) 49954, (char) 27083,
        Double.longBitsToDouble(0x3fcae2fcd718a6a8L), Double.longBitsToDouble(0x3fdd509eef6b2b36L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 12, 15, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud88b\udc71\ud98c\udde4\udbeb\udd88\u3f83\ud80b\udc8c\ud9db\udcb3\uda57\ude26\udb3a\udf54\ud89e\udc29\ud8a6\udcaa\uda6f\uddc8\ud8cc\udff7\ud945\udc5a\ud98d\udf75\ud8b8\udf36\u13a7\ud80e\ude74", "\u8ba6\u4d7f\u68c0\u9a76\ub021\u0813\ua3a6\uafbd", "\uda16\uddd9\ud90f\udeb7\uda61\ude58\uda13\udc53\udb41\udcb8\udb96\udfa5\u63fc\ud803\uddb7",
        54, 28949, 1483230471, -5318376750021646670L, 15306L, false, false, (char) 7279, (char) 8100,
        Double.longBitsToDouble(0x3fbfcd5dd508d750L), Double.longBitsToDouble(0x3fe202c6984436b4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 13, 14, "\udbe1\udf6e\uda73\udf9b\udbb7\udeec\udb26\udfa2\ud98f\udc90\udbeb\udd88\udb5b\udea9\ud8dd\udefd\u8fa8\ud98e\udf41\udb3a\udf54\ud80d\udfe0\uda74\ude2f\ud87e\udde5\udaa6\udef4\ud945\udc5a\ud98d\udf75\udb60\udc67\ud847\udee7\ud942\udce9", "\u8ba6\u4d7f\u68c0\u9a76\ub021\u0813\u8721\u51e8", "\ud9ab\udcf0\ud90f\udeb7\uda61\ude58\ud8c0\udc02\ud8a5\udf1d\udb34\ude49\udac2\udcdb\ud803\uddb7",
        54, 28949, 1483230471, -5318376750022860367L, -64310L, false, false, (char) 7233, (char) 14162,
        Double.longBitsToDouble(0x3fbf95679508d750L), Double.longBitsToDouble(0x3fe202c6984436b4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 3, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud88b\udc71", "\u49ee\ua316\ua2c7\u24e9\u38f5\uae81\u65b6", "\ud945\udc5a\ud98d\udf75",
        51, 34941, -2118401563, -1285806165594694612L, -24504L, false, false, (char) 25426, (char) 36224,
        Double.longBitsToDouble(0x3fe73d2692f42cdcL), Double.longBitsToDouble(0x3fd990a56e07200cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 15, 15, 9, "\udb01\udc46\uda78\udc4b\udb5b\udc7c\ud88b\udc71\ud98c\udde4\udbeb\udd88\u3f83\ud8e7\uddfa\ud9db\udcbd\ud98e\udf41\udb3a\udf54\ud89e\udc29\ud880\udee4\ud87e\udd3f\udaa6\udefd\udb52\udd42\ud88b\udf78\uda17\udddb\u0ea7\ud80e\ude74", "\u8ba6\u4d7f\u68c0", "\ud82b\ude5e\udb53\udec6\uda8d\udeff\ud9bb\udd45\uc2c4\uda16\ude0d\ud90f\udeb7\uda61\ude58",
        6, 85611, 714960380, -4909899960917665695L, -12826L, false, false, (char) 28755, (char) 14783,
        Double.longBitsToDouble(0x3fe0315770e36b8cL), Double.longBitsToDouble(0x3fe6e886387f3577L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 10, 10, 14, "\udb01\udc14", "\ud215\ud688\ubf20\u2ab8\ud6ea\ua2c7\u2664\u123f\ua67c\ua533\u33af", "\ud98d\udf75\ud8b8\udf36\u0ea7\ud853\udcb5\udb1f\udeb9\ud9e4\uddea\udb99\udff4\ud8a9\uddb0\ud865\udc6f\udab0\udc2b\udb5d\udcde\udb47\udd8b\udbca\udf8f\uda8d\udeff\ud98c\udc45\uc2c4\uda16\ude0d\u60e4\ud809\uddcd\ud8c0\udc24\ud8a5\udf1d",
        11, 2080, 1104877313, -5605616667004463803L, 46952L, false, true, (char) 24474, (char) 1277,
        Double.longBitsToDouble(0x3fe0363820e36b8cL), Double.longBitsToDouble(0x3fd3b10c70fe6aa6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c", "\u59a4\ud2c9\u3db6\ua2c7\u24e9\u38f5\uae81\u65b6\u3344\ud073", "\ud90c\udfb9\u0ea7\ud891\udcec\ud8ef\udd1e\uda7a\udfe6\uda21\ude04\ud8a9\uddb0\ud9e2\udcec\ud9da\udf05",
        24, 24607, -1583621108, -4834889518488763890L, 47165L, false, true, (char) 1965, (char) 39497,
        Double.longBitsToDouble(0x3fe5be966545bf2cL), Double.longBitsToDouble(0x3fd07583010cb0d0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "", "\000\u61f6\u514a", "\000",
        18, 39271, 1156331794, -2153131924709746704L, 54614L, true, false, (char) 93, (char) 0,
        Double.longBitsToDouble(0x3fbcb70000000568L), Double.longBitsToDouble(0x3fe0dc0800000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 8, 0, "", "", "\000",
        -5, 77008, -2143248854, 773094113280L, -4236L, false, true, (char) 6618, (char) 9403,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 2, 11, "\ud944\uddd0\udba0\ude21\ue311\ud9c3\udc7c\ud994\udc7f\ud9b2\uddb1\udbcc\udfbb\ud95c\udebd\ud9f8\udf66\uda25\udca9\ud880\udfbc\ud878\udcf3\udb3d\ude77\uda95\ude50\ud91f\udfe4\ud9a0\udf3c", "\u862d\ua071\u402c\uc740\u0ce2\u1f41\uc0d8\ub4be\ua22f\ud23f\u614b\u8295\u2231\u70a6\u02c8\u9dc7\u92e7", "\udbe8\udd25\ud89c\udfdf\ud831\ude19\ud819\udeb0\ud9e3\udd5a\ud939\udf89\udab0\udf4a",
        -3, 1176, 1061513483, -7250248492381474427L, 30892L, true, false, (char) 4259, (char) 37867,
        Double.longBitsToDouble(0x3fe1583d509551dfL), Double.longBitsToDouble(0x3fc186ec8ab53a94L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 8, 14, "\udb01\udc7e\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\ud9a7\udee6\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\ud882\udf28\uda54\udd92\ud80e\udc78\ud80e\ude85\udab4\udf76\uda17\udd13\ud84c\udfce\uda1a\udea6\udb4f\udd20\udad1\uddc4\ud8a9\udeeb\uda8c\udf75\ud97d\udc48\ud897\udebd\uc2b5\uda16\ude0d\ud90f\udeb7\uda61\ude58\udaad\udc98\ud8a8\udf61\uda95\udd17\udab8\udf16\ucdb0\ud9e0\udfc9\ud97d\udd1e\ud841\udc5e\ud9e2\udc2c\udba0\udc14\ud8cd\uddc7\udb01\udedd\uda34\udf2b\ud8e3\udcba\uda5c\udf02\udbd6\udf6b\udb63\uddc1\udad2\udce7\uda86\udd27\udb35\udff8\ud825\udfc9\uda69\ude12\udad6\udc5a\udb36\ude2e\ua074\ud9bd\udd03\ud95c\udd10\udae4\uddbd\udbd3\udf7a\ud809\udfc8\udb0d\udc34\udbc7\udcca\udb15\udcc6\udbc7\udf84\udb6c\uded5\udab4\udc82\ud8d6\udddb\uda78\udead\ud90c\udd86\udbfd\ude74\udab1\uddcf\ud96f\udcad\uda67\udccd\ud8d0\udcb1\ud919\udcb5\ud9e6\udf91\ud99b\udc25\uda14\udee0\ud9f9\udd52\udaf4\uddea\udb3e\ude07\ud9b8\uddcf\udaa0\udddb\ud86b\udf5e\ud93a\udfeb\ud8f6\ude81\uafa8\ud88f\udc36\ud849\udffe\ud809\udd8d\ud81e\udd84\ud89a\ude83\udaf4\udeb2\ud951\udef8\udad4\udd0c\uda23\udc98\udaeb\udf23\u8935\ud9d4\udf88\ud9ca\ude02\ud968\ude36\u05a6\ud9bf\udf27\ud852\udd5a\ud92e\udc43\udb85\udce3\uda3a\udfb3\ud92b\ude8e\ud868\udf9f\udafe\udd2d\udb13\udcc6\udb5a\udd06\ud8e7\ude7e\udb08\udd70\ud901\ude38\udb50\ude8e", "\u6c46\u19fe\u9e45", "\ud8d9\udccf\ud91b\udccd\uda9d\udcd7\udba5\udf3d",
        43, 2889, 1442999580, 6835045201182918964L, -10551L, true, true, (char) 7362, (char) 21625,
        Double.longBitsToDouble(0x3fe118ec03d13331L), Double.longBitsToDouble(0x3fd405228a514904L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 7, "\udb01\udc5f\uda81\udfe3\uda70\udf66\ud9a0\uddae\udb78\udfd4\uda73\udd2e\udab3\ude0a\udaa8\udde5\udb90\udd38\ud986\ude08\uefb4\udba4\udc29\ub921\ud8d2\udf4f\uda6b\udd66\udb8f\udfdc\udb67\ude5c\ud9bb\udf21\uda50\udc1b\ud80e\ude74", "\u91dd\u26e2\u68bc\ua059\u98e9\u888e", "\ud94b\udeee",
        -3, 2544, 65085107, -410353467959716414L, 32088L, true, true, (char) 29237, (char) 952,
        Double.longBitsToDouble(0x3fab38e1627b27f0L), Double.longBitsToDouble(0x3fc0cb055acad8c4L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 13, 14, "\ud873\udd7c\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud8b3\udeaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\uda61\udf65\uda54\udcd4\ud99e\udfdc\udadc\udc10\u713b", "\u6a2b", "\uda51\udd21\udad1\uddc4\ud86b\udd48\udab0\ude9a\uda20\uded2\udb89\udf8b\uc238\uda16\ude0d\udb56\udebb\uda61\udc60\udaad\udc98\ud8a8\udf61\uda95\udd17\uda33\udecd\ucdb0\udaef\uddcf\ud9f5\ude1b\ud841\udc5e\ud9d0\udc2c\ud856\udc2f\ud9dc\udf7e\udaa0\udc1d\uda27\udc5c",
        53, 30095, 1867578579, 8040658794085820083L, -40787L, false, false, (char) 44972, (char) 36467,
        Double.longBitsToDouble(0x3fecf9f4718c6bacL), Double.longBitsToDouble(0x3fa1fae81f63a250L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 12, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8b5\udfea\000\000\udad7\ude78\ud922\udec0\ud8d4\udc49\u9113\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u68bc\u5025\ub42a\ud23f\ub14d\000", "\uda4f\udf66",
        -5, -1000, 78577664, -2473094778091208452L, -100000L, true, false, (char) 12009, (char) 54749,
        Double.longBitsToDouble(0x3fc0cb055acad8c4L), Double.longBitsToDouble(0x3fede0ca1d963fccL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud8b8\udff3\udab3\ude0a*\000\u4e96\udb2f\udd21\ud99a\udc27\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u6866\u5bf1\u0502\uaaa7\u4c98\000", "\ud9e6\udcd4\ud980\udd17\ud81b\ude1c",
        47, -1000, 2023583228, -7570918688001023647L, 12280L, false, false, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fe8dd521d963fccL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 11, 11, 8, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud8b8\udff3\udab3\ude0a\ud8c3\udcd7\ud922\ude31\u4ee5\udb2f\udd21\ud89e\udc29\u316b\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\uc3c0\udadc\udc10\ud80e\ude74", "\u6a2b\uc681\u6866\u5bf1\u0502\uaaa7\uc178\u8295", "\ud9e6\udcd4\ud980\udd17\ud81b\ude1c",
        27, 77036, -309032278, -7570918688001023647L, 12280L, false, false, (char) 44208, (char) 7396,
        Double.longBitsToDouble(0x3fe8dd521d963fccL), Double.longBitsToDouble(0x3fe0315770e36b8cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 13, 14, "", "", "\ud98f\udc90\udbeb\udd88\udb5b\udea9\ud8dd\udefd\u8fa8\ud98e\udf41\udb3a\udf54\ud80d\udfe0\ud8d2\udd3e\u580b\u5bed",
        -5, -1000, 421308141, 1156446491285389865L, -24504L, false, false, (char) 25426, (char) 38658,
        Double.longBitsToDouble(0x3fe73d21edf42cdcL), Double.longBitsToDouble(0x3fe4fa59f7039006L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 8, 14, "\udb01\udc7e\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5\udb2f\udd21\udab2\udf18\ud9a7\udee6\ud87e\udde5\ud932\udce2\udb4f\udc7a\udb8e\udf11\ud882\udf28\uda54\udd92\ud80e\udc78\ud80e\ude85\udab4\udf76\uda17\udd13\udaa8\udf27\ud87d\udc8c\udb4f\udd20\udad1\uddc4\ud8a9\udeeb\uda8c\udf75\ud97d\udc48\ud897\udebd\uc2b5\uda16\ude0d\ud90f\udeb7\uda90\ude91\udaad\udc98\ud8a8\udf61\uda95\udd17\udab8\udf16\ucdb0\ud9e0\udfc9\ud97d\udd1e\ud841\udc5e\ud9e2\udc2c\udba0\udc14\ud8cd\uddc7\udb01\udedd\uda34\udf2b\ud8e3\udcba\uda5c\udf02\udbd6\udf6b\udbe6\ude9b\udad2\udce7\ud86f\udcbc\udb35\udff8\ud825\udfc9\uda69\ude12\udad6\udc5a\udb36\ude2e\ua074\ud9bd\udd03\ud95c\udd10\ud82e\ude02\udbd3\udf7a\ud809\udfc8\udb0d\udc34\udbc7\udcca\udb15\udcc6\udbc7\udf84\udb6c\uded5\udab4\udc82\ud8d6\udddb\uda78\udead\ud90c\udd86\uda26\udfa8\udba2\udd21\ud895\udecc\ud98c\udca6\udbc8\udd7f\ud919\udcb5\ud9e6\udf91\ud99b\udc25\udb25\udc68\ud9f9\udd9a\udaf4\uddea\udb3e\ude07\ud9b8\uddcf\udaa0\udddb\ud86b\udf5e\ud93a\udfeb\ud8f6\ude81\uafa8\ud88f\udc36\ud849\udffe\ud809\udd8d\ud81e\udd84\ud89a\ude83\udaf4\udeb2\ud951\udef8\udad4\udd0c\uda23\udc98\udaeb\udf23\u8935\ud9d4\udf88\ud9ca\ude02\ud968\ude36\u05a6\ud9bf\udf27\ud852\udd5a\ud92e\udc43\udb85\udce3\uda3a\udfb3\ud92b\ude8e\ud868\udf9f\udafe\udd2d\udb13\udcc6\udb5a\udd06\ud8e7\ude7e\udb08\udd70\ud901\ude38\ud9fc\udea1", "\u6c46\u19fe\u9e45", "\ud8d9\udccf\ud91b\udccd\uda9d\udcd7\udba5\udf3d\uda58\udf73\uda45\udca0\ud900\ude4d\ub37a\udac6\udf16\udae0\uddd1\ud98b\udd27\udbe4\uddcd\udaa6\ude73\ufe62\ud939\udd27\ud9c0\udca8\udaf2\udfdb\ud83c\ude41\ub345\ud8cb\udedf\udaa6\udc38\udadd\udc91\udb04\udf33",
        43, 39420, -1806560147, -5358280462429948075L, 61292L, true, false, (char) 35852, (char) 4955,
        Double.longBitsToDouble(0x3fe100f45a1fcd96L), Double.longBitsToDouble(0x3fd502c63e54ef9eL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 0, "\udb01\udc5f\u9ff7\uda65\ude52\u0a80\000\uf808\000\udb71\udeb7\u008b\ud986\ude08\uefb4\000\000\u9f00\ud913\udd5a\ud83b\uded1\000\ud9bb\udf21\uda50\udc1b\uc1e5", "\u91dd\u1dbc\000\ua059\u98e9\000", "\ud94b\udeee",
        11, -1000, 65077248, -410353467959716414L, 32088L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e489c0000000000L), Double.longBitsToDouble(0x3fc0cb055acad8c4L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 8, 14, "\udb01\udc14\uda78\udc4b\udb5b\udc7c\ud9a0\udd9b\ud8eb\udfea\ud89e\udfaf\udab3\ude0a\udad7\udea2\ud922\udec0\u4ee5", "\u65b6\u3344\u36f9", "\uc3c0",
        31, 72437, -299375077, -2758283058657721351L, -37320L, false, false, (char) 59743, (char) 46034,
        Double.longBitsToDouble(0x3fc6a96e22ca7a84L), Double.longBitsToDouble(0x3fcd138b199ba3b4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addAndOrUpdate|org.jfree.data.time.TimeSeries|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clear||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|equals|java.lang.Object|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
