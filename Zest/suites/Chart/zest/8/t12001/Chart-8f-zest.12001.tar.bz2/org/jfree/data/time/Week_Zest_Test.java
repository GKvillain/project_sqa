package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class Week_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u2cab\u4126\ua0a9\u7ec3", "\ud813\udebb\ud94a\ude99",
        3, 27908, -92857573, -7164151581840100081L, 28277L, false, true, (char) 56934, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c855986799bdL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbe2\udd46\u1e94\ud967\udf6c\ud926\uded7\ud997\udf1e\ud92e\udd24\ud98b\udfd5\uda24\udd06\uda48\udcea\udb83\udffd\udb1a\udea1\ud8a2\uddc9\ud898\udf79\ud9d7\uddba", "\u3c48\u3dc3\uc76b\u46bf\u2cab\u4126\ua0a9\u0663", "\ud813\ude95\ud94a\ude99\uda05\udcc5\udbce\uddab\ud9e0\udec7\uda08\udd41\udb09\udc8c\udbe5\ude83\udbcb\udd9b\udb73\udeca\ud955\uddc5\udab7\udc27\udb1e\udede\ud991\udc34\ud8c7\udcb2\udbf2\udf9f\udb13\udee8\ud128\udab4\ude37\uda15\udcf8\udac1\uddb9\udabf\uddf4\ud94c\udc7b\uda77\uddae\ud9e8\udd14\ud816\udfec\uda9d\uddab\udac3\ude91\udb98\udc7c\udbdd\udcb4\ud82d\udc13\udae1\udf3d\udaa5\udce5\udbce\udc88\ud97b\udc40\udb85\udcd7\ud9f9\udd72",
        14, 16976, 635035273, 5193503188094367835L, -2395L, true, true, (char) 658, (char) 38823,
        Double.longBitsToDouble(0x3fe4d4e179c1db6bL), Double.longBitsToDouble(0x3febec53ecaa173aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79", "\ud4a4", "\udb14\udf30\ud84a\udefd\ud874\udc3f\ud9e5\udfb1",
        27, 16794, 880303760, -1806594159041858359L, 54031L, false, false, (char) 13046, (char) 52367,
        Double.longBitsToDouble(0x3fd0f9c9341deebcL), Double.longBitsToDouble(0x3fd154bb1a25f170L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 7, 1, "\ud851\udf4c\udb2c\udf72\ud877\udc69\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda22\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda38\uddea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u2cab\u4126\ua0a9\u7ec3", "\udbdf\udec1\ud97e\udc99",
        3, 27908, -92857573, -7164151581840100081L, 28277L, false, true, (char) 56934, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c855986799bdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 31, -408\0121=java.lang.Long:1791046799999 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 3, 13, 5, "\ud851\udf4c\udb2c\udf72\ud99b\udc73\ud933\uddcd\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\uab17\u1ba3\u3752\u2cab\u4126\ua0a9\u7ec3", "\ud813\udebb\ud94a\ude99",
        3, 27908, -91415781, -7164151579993138216L, 28277L, false, true, (char) 39168, (char) 17810,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c8559c6799bdL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ue87c\udb8b\ude85\ud967\udf6c\ud926\uded7\000\000\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\uc245\uda37\udc7a", "\ud047\000\ubeb2\u3752\ubafe\u4126\000\000", "\ud813\udebb\u0097",
        2, -1000, 7805723, -7164151581840100081L, 28277L, false, true, (char) 18009, (char) 46681,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c850006799bdL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 47, 25940\0121=java.lang.Long:107418 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 3, 14, 15, "\ud851\udf48\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud9be\udf97\ud926\uded7\uda13\udc4d\ud9dc\udde0\udaf0\ude40\ud832\udf3c\ud8c2\udec8\udbe6\udc44\udb39\udcc0\ud8b4\ude1b\udbb3\udca6\uda99\udf49", "\ud047\ucf82\ubb66\ua6e0\u8876\u410c\ua0a9\u7ec3", "\udabb\udc2a\ud950\udf65",
        57, 5395, -1250443891, 153797062123468149L, 28277L, true, true, (char) 56934, (char) 26714,
        Double.longBitsToDouble(0x3fd6e682d0d0ba92L), Double.longBitsToDouble(0x3fe5c8559bf31e25L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Long:107418 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 14, 5, "\ud977\udf4e\udb2c\udf72\uda39\udea1\ud8a6\udea3\uda77\udd39\uda36\udf02\ud80f\udcd8\ud8f1\udf41\ud9d7\ude42\udbec\udcd5\uda24\udd06\uda48\udcea\udaa8\udc6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u96c5\u1ba3\u3752\u3f09\ua0ef\ua0a9\uc382", "\ud88d\ude78\udacb\udf91",
        34, 5235, -92857573, -7164151581840100081L, 50342L, false, false, (char) 61990, (char) 45524,
        Double.longBitsToDouble(0x3fe5c855987d99bdL), Double.longBitsToDouble(0x3fe288ae658d7c1bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 7, "\ud85f\ude6d\udb2c\udf72\ud876\udfa0\ud9a7\udeb3\udbca\udf0a\ud967\udf6c\udba0\udef4\udaef\udd8a\udaa2\udd64", "\u7f31\u5bf1\u8506\u3663\u0997\u23b1", "\ua772\udbec\uddba\ud8a0\ude15\ud84a\udefd\udb06\udca8\udbc5\udea1",
        -4, 84807, -1439146352, 6243181749262811923L, 8662L, false, false, (char) 13046, (char) 61583,
        Double.longBitsToDouble(0x3fd0f9c9361deebcL), Double.longBitsToDouble(0x3f9f4ba33d729380L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 28, -408\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 16, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\ud969\udeef\u5c71\udaa7\uded4\udada\ude7e\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\ud902\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u2cab\uc51f\ua0a9\u5ce8", "\ud9e5\udc1c\udb05\ude40",
        43, 91592, -92857573, -7164151581840100081L, 28277L, false, true, (char) 56952, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe3d29d733899bdL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 2, 18, 5, "\udba9\ude78\ud933\udf8f\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udd8d\u385d\uda24\udd06\uda8f\udd8e\ud9d8\udc0a\ud8c3\udc52\ud869\udfea\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u2cab\u4126\ua0a9\ubef4", "\ud813\udebb\ud94a\ude99\uda05\udcc5\udbce\uddab\ud9e0\udec7\uf43c\udb09\udc8c\udbe5\ude83\uda29\udcaa\udb33\udef1\ud92a\uddc5\udab7\udc27\udb41\udfd7\ud991\udc34\ud8c7\udcb2\udb0b\uddca\udb17\udce7\udb45\udcaf\udadb\ude9b\udb70\udcef",
        31, 71574, 500646989, 8074842309350289067L, 9451L, false, true, (char) 7261, (char) 17073,
        Double.longBitsToDouble(0x3fccfd7aee2fc778L), Double.longBitsToDouble(0x3fdc986ab0637304L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 8, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbf7\udcdb", "\u13ae\u55b7\u01dd\u38d1\uc17e\u7744\u5bf1\u348d\u740d", "\udb2f\udc42\uda97\udfe9",
        -1, 28450, -244894480, 6921593786185923326L, -80745L, true, true, (char) 27343, (char) 11434,
        Double.longBitsToDouble(0x3fe8d8beda18fa77L), Double.longBitsToDouble(0x3fd0f9c9354ae0bcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udaa8\udc32\ud96c\udf6c\ud9f2\udc55\uda36\udf19\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9e5\udeba", "\ud047\u465b\uac47\u3752\u2cab\u58c3\ub84c\u4768", "\ud88e\udd5d\ud971\udcd9\uda05\udcc5\udbac\uddd8\ud821\udde7\udbfb\udf2b",
        15, 74942, -118363371, -7490096333264107943L, 25806L, true, true, (char) 23916, (char) 39972,
        Double.longBitsToDouble(0x3fafc9e1a44bbc80L), Double.longBitsToDouble(0x3fdd6a8adf1c16caL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 17, 1, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u2cab\u4126\ua0a9\u7ec3", "\ud813\udebb\ud94a\ude99",
        3, 27908, -92857573, -7164151581840100081L, 28277L, false, true, (char) 56934, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c855986799bdL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 29, -408\012",
        Z.run(T, 2, 2, 1, 5, "\ud845\udf2f\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\udbdc\udfa1\ud9dc\udde9\ud95a\udc62\uda24\udd06\ud8c4\udfc5\ud90c\udc94\ud8da\udfb1\ud87d\udd98\ud898\udf79\ud9d7\uddba", "\u5336\u8d9b\u1ba3\u3752\u2cab\u4126\ua0a9\u7ec3", "\ud813\udebb\ud924\udc05",
        34, 27908, -92857573, -7164151581840100081L, 28277L, false, true, (char) 39989, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c855986799bdL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 7, 6, 5, "\ud961\udc13\ue334\ud955\ude1d\ud8bc\udc03", "\u4967\u7787\ubd5d\u38d1\uc17e\u7744\u5bf1\u348d\u740d\u0997\u23b1\uccf7\ud4a4\ud74d\u7814\u1ba3\u3752\ubabb\u4126\ua0a9\u7ec3\u1cc0\ud277\u03ea\u05e3\u077e\uc5c9", "\udb12\ude70\udacc\udf99\udafb\uddef\udb33\udef1\ud92a\uddc5\udab7\udc27\udb1e\udede\ud991\udc34\ud8c7\udcb2\udbbd\udfa3",
        33, 35161, -271736713, 325918621018998127L, 49027L, true, true, (char) 25352, (char) 15749,
        Double.longBitsToDouble(0x3fe50823183dfb4fL), Double.longBitsToDouble(0x3fdba7398be55246L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 17, 5, "\ud851\udf4c\ud846\udd9f\ud876\udfa0\ud932\udc38\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\ua028\000\uda8b\udf24\ud8da\udfb1\000\000\000", "\000\u4b69\u1ba3\u3752\u2bad\u4126\ua0a9", "\000\udb64\uddf1\ud94a\ude99\uda05\udcc5",
        -2, 5939, 0, -648518345071402482L, -100000L, false, false, (char) 26628, (char) 26669,
        Double.longBitsToDouble(0x3e35c80000000000L), Double.longBitsToDouble(0x3fb9e66f76d147a0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 29, 7604\0121=new org.jfree.data.time.Week:Week 29, 7604\012",
        Z.run(T, 2, 17, 0, 9, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4", "\u13ae\u255c\u1b3b\u38d1\uc17e\ucbbe\u96a5\u4fd7\u77ea\uce11", "\uda97\udfe9\uda3a\udd26\ud869\udf92\udb15\udc13\ud84a\udefd\ud874\udc3f\udbc5\udea1\ud8e8\udcd0\udaf2\udce2\uda40\udc33\udaf7\udeb4\ud813\udebb\ud94a\ude99\uda05\udcc5\udbce\uddab\udb1e\udec6\ud87d\udc29\udb09\udc8c\udbe5\ude83\uda7f\udddf\udb33\udef1\ud92a\uddc5\udab7\udc27\udb1e\udede\ud991\udc34\ud8c7\udcb2\udb1d\udf94\ud98d\udca1\udac4\udc75\ud9ae\uddd0\ud84e\udcb5\ucf93",
        55, 73659, 326472765, 5871560286195317460L, 3909L, true, false, (char) 18028, (char) 3336,
        Double.longBitsToDouble(0x3fc25cf03b847a10L), Double.longBitsToDouble(0x3fd6cda0fb57f5eaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 3, 27908\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 5, 18, 5, "\ud91b\udc54\udb2c\udee5\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u2cab\u4126\ua0a9\u7ec3", "\ud813\udebb\ud94a\ude99",
        3, 27908, -92857573, -7164151581840100081L, 28277L, false, true, (char) 56934, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c855986799bdL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 20, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud973\udfff\uda5a\udfc2\udbd6\udda9\udba7\udd5a\ud880\uddb4\udb29\udf88\udaa5\udc1e\ud8da\udfb1\udb02\udd3b\ud8e7\udc5f\udbca\uddf8", "\ud047\u4bc3\ua382\u7f4f\u2cab\uc41c\ub2af\u7ec3", "\u957e\ud94a\ude99",
        3, 27908, -348244453, -7164150636947294961L, 28277L, false, true, (char) 31334, (char) 58078,
        Double.longBitsToDouble(0x3fef61c96b937e41L), Double.longBitsToDouble(0x3fe5cb9c286799bdL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 2, 14, "\ud851\udfc5", "\u14ea\ube7e\u3731\u13ae\u55b7\u01dd\u38d1\uc17e\u7744\u5bf1\u348d\u740d", "\udb2f\udc42\uda97\udfe9",
        -1, 28450, -244894480, 6930975309020379902L, -42223L, true, false, (char) 14313, (char) 58534,
        Double.longBitsToDouble(0x3fc93cdda65d480cL), Double.longBitsToDouble(0x3fdaf112008868ccL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 4, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbd8\udd8c\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd21\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba\udb2f\udc42\uda97\udfe9\uda3a\udd26\ud869\udf92\udb15\udc13\ud84a\udefd\ud874\udc3f\udbc5\udea1\ud888\udf8f\udb46\ude4c\uda48\udda7\udaf7\udeb4\ud813\udebb\ud94a\ude99\uda05\udcc5\udbce\uddab\ud9e0\udec7\uf43c\udb09\udc8c\udbe5\ude83\uda29\udcaa\udb33\udef1\ud92a\uddc5\udab7\udc27\udb1e\udede\udb45\uddcf\ud820\udd2a", "\u3fb3\u91e1\uc4ea\u581c\ua40d\u7410\u0c53\u4e57\u2e96\u49ea\u9b8f\ua835", "\ud829\udfc2\ud9b9\udd12\udb3f\udf3e\ud9d1\uded5\uda8f\udde6\udb5c\udfb8\uda53\ude00\ud924\uddc5\udbb9\udfcb\uda34\udf6a\ud8b8\udef3\ud811\udd83\u05fe\ud860\udd8a\ufe78\ud935\ude77\udb7c\udcbe\ud882\udd6e\ud99b\udcea\u6717\udbe4\udc33\ud9a7\udea8\udbd9\udfe2\ud833\udcc3\ud9ca\udca2\udb12\udf8e\ud98c\ude90\udb9c\udfff\ud8ce\ude1f\udac9\udcb0",
        1, 3191, 721168554, -1782088676949533798L, -99244L, false, false, (char) 64498, (char) 6130,
        Double.longBitsToDouble(0x3fe78ceff5666eacL), Double.longBitsToDouble(0x3fd9d0a4d98b37eeL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Long:1791097199999 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 9, 12, 11, "\udb1a\udc3f\udb05\uded3\ud876\udf94\udb6d\udfd5\uda9c\udcb5\ud83b\udfd1\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\ud8fd\udc06\uda48\udcea\ud82e\udc01\ud9b5\udea5\ud9ed\udf67\udb1c\udda4", "\ud4a4\ud047\u4bc3\ub3da\u3fe9\u86cd\ubdc2\u02e5\u1d33\u2c28\u8d68\u5328", "\udb68\udebf",
        19, 57744, -1092995825, 6920631547902378369L, 78599L, false, false, (char) 21403, (char) 45524,
        Double.longBitsToDouble(0x3fdb90ab3fa8e7c8L), Double.longBitsToDouble(0x3fdd9d667dc9a79cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 17, 16980\012",
        Z.run(T, 2, 2, 16, 18, "\ud8e1\ude54", "\u912e\u7bff", "\uda36\udf4d\uda93\udda4\ud8d6\udc2b\udbc2\udeff",
        19, 43957, -1654460030, 180382671672558149L, -4070L, true, false, (char) 23251, (char) 36978,
        Double.longBitsToDouble(0x3fce0077154bc59cL), Double.longBitsToDouble(0x3fe7f3017b1b5929L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:1791097199999 |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 12, 7, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d", "\ua1f1\u024f\ub10d\u6d13\u4ca5\u5278\ud4a4\ud047\u4bc3\u1ba3\uaf4f\uc357\ub34b\ua093\u7ec3\u1cc0\ud277\ua4b9\u831c\ua760\u2c8b\u948b\uc441\ucad3", "\udb33\udef1\ud92a\uddc5\udab7\udc27\udb1e\udede\ud991\udc34\ue54a\ud8f9\udfe1\ud8f2\ude33\ud898\udd05\udaa9\udc83\u1e84\uda6c\udf1f\ud843\udf2a\udbda\ude9a\udb9a\ude1d\ud812\udd81\uda1e\uddf6\ud9f9\udfef\uda1f\udd01\udbea\ude72\uda5d\udcbb\ud8c4\udd6b\udaa8\udfe1\udbc4\udce2\udadc\udf07",
        53, 61182, 466856929, -6867785302772659240L, 53093L, true, false, (char) 64579, (char) 24527,
        Double.longBitsToDouble(0x3febe98e281ce83aL), Double.longBitsToDouble(0x3fae4c8dd4574360L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 16, 14, "\ud892\udce9\udabe\udc26\ud876\udfa0\udba2\udeaf\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0", "\u1bf0\u5bf1\u348d\u0403\u0997\u23b1", "\udbe7\udd39\ud869\udf92\udb15\udc13",
        44, 49581, -1273372688, 7300395866303990567L, 6051L, true, true, (char) 15872, (char) 52437,
        Double.longBitsToDouble(0x3fb10d1998d8bed8L), Double.longBitsToDouble(0x3fe0c1559d0f9c93L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 19, 5, "\ud851\udf4c\ud912\udd70\ud876\udfa0\udb69\udcc8\ud870\udd1a\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\ud8e1\udf96\u0a7e\uf0fe\ud953\ude12\ud8f4\udf25\ud84c\udc34", "\ubf31\u0366\uadbb\uce03", "\u2282\udb7f\udf02\udbf3\ude5a\ud9de\udd62",
        12, 69327, -1486428356, 1699506386997025563L, 17489L, false, false, (char) 16582, (char) 37399,
        Double.longBitsToDouble(0x3fd8c6e9ec0964acL), Double.longBitsToDouble(0x3fe90de16b937e41L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 24664\012",
        Z.run(T, 1, 19, 18, 5, "\udb03\uddbb", "\u14ea\ube7e\u3731", "\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c",
        33, 82614, 1675032389, 5499837677970677690L, -62931L, false, true, (char) 14504, (char) 46777,
        Double.longBitsToDouble(0x3fe7f3017b1b5929L), Double.longBitsToDouble(0x3fd79b4199287160L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 9, -12566\0121=new org.jfree.data.time.Week:Week 9, -12566\012",
        Z.run(T, 2, 0, 0, 12, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbe2\udd46\udbea\udf93\ud967\udf6c\ud8ef\udd5c\000\000\000\000\uda48\udcea\udb83\udffd\udb1a\udea1\u91ab\ud868\udd34\ud9d7\uddba", "\u3c48\u3dc3\uc76b\u46bf\u2cab\u4126\ua0a9\u0663", "\ud813\ude95",
        22, 17863, 400291908, -398820240887318756L, 38738L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe00000036e682dL), Double.longBitsToDouble(0x3f3f904000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbe2\udd46\u1e94\ud967\udf6c\ud926\uded7\ud997\udf1e\ud92e\udd24\ud98b\udfd5\uda24\udd06\uda48\udcea\udb83\udffd\udb1a\udea1\ud8a2\uddc9\ud898\udf79\ud9d7\uddba", "\u3c48\u3dc3\uc76b\u46bf\u2cab\u4126\ua0a9\u0663", "\ud813\ude95\ud94a\ude99\uda05\udcc5\udbce\uddab\ud9e0\udec7\uda08\udd41\udb09\udc8c\udbe5\ude83\udbcb\udd9b\udb73\udeca\ud955\uddc5\uda96\udd99\udb0c\udeaf\ud991\udc34\ud8c7\udcb2\udbf2\udf9f\udb13\udee8\ud128\udab4\ude37\uda15\udcf8\udac1\uddb9\udabf\uddf4\ud94c\udc7b\uda77\uddae\ud9e8\udd14\ud816\udfec\uda9d\uddab\udac3\ude91\udb98\udc7c\udbdd\udcb4\ud82d\udc13\udae1\udf3d\udaa5\udce5\udbce\udc88\ud97b\udc40\udb85\udcd7\ud9f9\udd72",
        14, 16976, 635035273, 5193503188094367835L, -2395L, true, true, (char) 658, (char) 38823,
        Double.longBitsToDouble(0x3fe4d4e179c1db6bL), Double.longBitsToDouble(0x3febec53ecaa173aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week -4, 24647\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 5, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbe2\udd46\u970a\ud967\udf6c\ud926\uded7\ud997\udf1e\ud92e\udd24\uda03\udfd1\uda24\udd06\uda48\udcea\udb83\udffd\uda51\uddbd\uda0b\udd19\ud898\udfb0\ud9d7\uddba", "\u8923\u8a64\uc72e\u12cc\u7dd6\u1e1e\ua0a9\u530a", "\ud813\ude95\ud94a\ude99\uda05\udcc5\udbce\uddab\ud9e0\udec7\ud96b\udd77\udb0b\udf2b\udbe0\udd2e\ud8f3\udd8f\udb73\udeca\ud845\udc3d\udb19\udd8d\udae9\udc9c\ud991\udc34\ud8c7\udcb2\udbf2\udf9f\udb42\udfe8\ud128\udab4\ude37\uda15\udcf8\udac1\uddb9\udabf\uddf4\ud94c\udc7b\uda77\uddae\ud9e8\udd14\ud816\udfec\uda9d\uddab\udac3\ude91\udb98\udc7c\udbdd\udcb4\ud82d\udc13\udae1\udf3d\udaa5\udce5\udbce\udc88\ud97b\udc40\udb76\udfeb\ud9e0\udd31\ud9d5\udd10\udb0b\udff1\ub8c4\ud942\udfe1\uda66\udde6\ud8ba\udd20\udb60\uddec",
        -4, 90183, 154488484, -6040033787991673599L, 42911L, true, true, (char) 51522, (char) 38294,
        Double.longBitsToDouble(0x3fc146ff577c9cccL), Double.longBitsToDouble(0x3fdd7ae1fcf72f46L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 20, 16, "\ud851\udfaf\udb2c\udf72\ud876\udfa0\ud908\ude84\udb68\udea7", "\u55b7\u0137\u395c\ua9a2\u98b7\u00d0\ua3a8\ub286\u1e1c\ua737\u37b3\ud5fa\u06fa\u8d21\u1ac0\ub451\u3ebe", "\uc268\ud87c\uddf3\udaf7\udeb4\ud813\udebb\udbd1\ude9f\uda05\udcc5\uf8e4\ud8f2\uddd8\uf43c\udb09\udc8c\uda53\udcbb\uda23\ude97",
        -5, 47724, 1425382081, -8095274155890603044L, 47965L, true, false, (char) 21958, (char) 9385,
        Double.longBitsToDouble(0x3f8fa3297428bc40L), Double.longBitsToDouble(0x3fe564c28daea1e3L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 27, 16794\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 5, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud965\udcb4\udbca\udeb7\ud967\udf6c\ud936\uddd7\uda36\udf4d\uf2f0\ud914\udcc8\ud8b5\udd84\ud940\udc75\ud9e1\udf0c\uda64\ude7c\udb02\udd3b\ud898\udf79", "\ud4a4", "\udb14\udf30\ud84a\udefd\ud874\udc3f\ud9e5\udfb1",
        27, 16794, 880303760, -1806594159795800631L, -59687L, false, false, (char) 53666, (char) 61448,
        Double.longBitsToDouble(0x3fd154bb193d10feL), Double.longBitsToDouble(0x3fe380c5129dbe95L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 2, 17651\0121=new org.jfree.data.time.Week:Week 1, 17651\012",
        Z.run(T, 2, 17, 0, 0, "\ud851\udef3", "\u14ea\ube7e\u3731\u13ae\u55b7\u22b7\000\uc17e\u7744\u5bf1\u0082\u72f6\u0997\u23b1\uad23\ud4a4\ud047\u0b21\u1ac0\u3752\u632f\000\u1e16\uca89\u1cc0\ud277\u87e5\u05e3\ua7c9\u2c8b\u948b\uc441\ucad3", "\ud9e8\udc8b\u01f6\ud845\ude34\ud98a\udfc0\ud8b1\udc9b\udb98\udda5\udaeb\udffc\uda8c\udd85\ud8e3\udc2a\uda1e\udd01\ud97c\udc81\udb0b\udeae\uda4d\udfd0\udb94\udd7a\ud851\udd32\ud8b6\udd6c\ud9c2\udf8d\udb24\ude10\ud8de\uddc5\uda7b\udeee\udab8\ude2c\udb53\udf45\ud95b\ude05\ud8f5\udc9d\ud8d1\ude84",
        8, 59418, -615804797, 5816038179484981185L, -70212L, true, true, (char) 51626, (char) 47465,
        Double.longBitsToDouble(0x3fee437b356b726eL), Double.longBitsToDouble(0x3fd83edc383075eeL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 27, 16794\0121=new org.jfree.data.time.Week:Week 27, 16794\012",
        Z.run(T, 2, 5, 5, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\uda0b\udccd\uda85\ude05\ud952\udd43\ud926\uded7\uda36\udf4d\ud9dc\ude0e\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79", "\ud455", "\udb14\udf30\ud84a\udefd\ud874\udc3f\ud9e5\udfb1",
        27, 16794, 880303760, 5093483420048870096L, 54031L, false, false, (char) 59637, (char) 52470,
        Double.longBitsToDouble(0x3fd7b9e9341deebcL), Double.longBitsToDouble(0x3fd154b5ba25f170L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:1790467200000 |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 8, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud93f\udde6\ud9d7\uddba", "\ud047\u0b21\u1ac0\u3752\u2cab\u9e7b\u26a4\uca89", "\ud813\udebb\ud94a\ude99\uda05\udcc5\udbce\uddab\ud9e0\udec7",
        1, 12023, 1269948942, 3106099135522198912L, -21377L, true, false, (char) 1711, (char) 24189,
        Double.longBitsToDouble(0x3fdb9dbbf31fc396L), Double.longBitsToDouble(0x3fed4e8243f7d433L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 1970\012",
        Z.run(T, 1, 3, 0, 5, "\ud851\udf4c\ua992\ud836\udf7a\ud96a\udcb42\000\ud8c4\udc01\ud9fb\uddfc\ud9dc\udde0Q\000\000\000\000\udb02\udd3b\ud8c6\ude4f", "Q", "\udb14\udf23",
        7, 96070, 1696539, 0L, 10639L, true, false, (char) 12954, (char) 27343,
        Double.longBitsToDouble(0x3eb9800000000000L), Double.longBitsToDouble(0x3fe0c7d0050f9c93L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 7, 7, 6, "\ud82c\udca2\udb2c\udf72\udaf9\udee1\ud96a\udd13\udbca\udeb7\ud967\udf6c", "\u7654\u466e\u31f4\u01ab", "\udb02\udd3b\ud898\udf79\ud9d7\uddba\udb2f\udc42",
        31, 87429, -357036966, -1051814755914758830L, 23675L, false, false, (char) 23357, (char) 27368,
        Double.longBitsToDouble(0x3fa79a3c26b97ed0L), Double.longBitsToDouble(0x3fd97210335e2840L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 5, "\ud851\udf4c", "\u14ea\ube7e\u3731\u13ae\u55b7\u01dd\u38d1\uc17e\u7744\u5bf1\u348d\u740d\u0997\u23b1\uad23\ud4a4\ud047\u0b21\u1ac0\u3752\ud496\u334b\u2637\uca89\u1cc0\u648a\ud283\u05e3\ua7c9\u2c8b\u948b\uc441\ucad3", "\udae2\udf27\udbb3\udfbd\uda0c\uddd7\uda36\udce5\udabb\udc73\uda8e\udea5\ud82d\udd9d\ud855\ude12\ud95a\udee3\udad0\udc01\ud98b\udfa1\udb8f\ude71\udbe5\udefc\ud8be\udff9\ud9f3\udf62\udb89\udfb3\ud9ee\udda1\udb7f\ude49\ud8f6\udf4f\ud93b\udc88\ud883\ude13\udb93\udca4\udbc6\udf8b\ud800\udc43\udbb1\udcf9",
        12, 81553, -1231168644, -6816323035048626817L, 77557L, true, false, (char) 35724, (char) 40688,
        Double.longBitsToDouble(0x3fea1bf17c4f849aL), Double.longBitsToDouble(0x3fe3244da36ebde8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:1790442000000 |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Long:1791046799999 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 11, 13, 1, "\ud851\udf4c\udb2c\udf72\ud877\udc69\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda22\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda38\uddea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u2cab\u4126\ua0a9\u7ec3", "\udbdf\udec1\ud97e\udc99",
        3, 40972, -92857573, -7164151581840100081L, 28277L, false, true, (char) 56934, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c855986799bdL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 1, "\udaa1\udd2c\uda2e\udcc2\ud877\udc69\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\ud95f\udeed\ud832\uddf2\uda2a\udf53\u6e1e\udb76\udeb4\ud9c4\ude3b\ud8da\udfb1\udb02\udd3b\ud898\udf79\udad8\udcdb", "\uaaa6\u2cc8\u1ba3\u3752\u2cab\uade3\u36b1\u2e13\u1cc0\u418f\u9474\ud3e3\ua7c9\u2c9f\u948b\uc441\ucad3\uabc4\u64b8\u8605\u2424\u695b\u206d\u7041\ub985\ud7a6", "\ud8be\udee6\udb39\uddf9\udaac\ude85\udb72\uddf9",
        36, 23516, 1996303099, -4194242026586566728L, -97903L, false, false, (char) 10604, (char) 39265,
        Double.longBitsToDouble(0x3fec110a78d61cecL), Double.longBitsToDouble(0x3fe690b2f8d5782eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 49, -13597\0121=new org.jfree.data.time.Week:Week 49, -13597\012",
        Z.run(T, 2, 17, 1, 11, "\ud851\udf4c\udb2c\udf72", "\ube7e\u3731\u13ae\u05b7\u38df\u992e\uc17e\u3844\ua6a5\uc6ef\u740d\u0997\u23b1\u9623\ud4a4\ud047\u8779\u1b70\u3752\u2cab\u4126\ua0a9\u7ec3\u1cc0\ud277\u9474\ud3e3\ua7c9\u2c8b\u53fb\u7d41\ucad3\uabc4\u64b8\u61df\u0a4d\u197d\u2112\ub26b", "\udab7\udf5b\uda6f\uddd6\ud9f9\udcdc\ud928\udf00\u24df\udb1d\udc50\ud929\udfa6\ud9f4\udfb7\udb00\udfad\ud8af\udef5\ud943\udcd7\udb2d\ude2e\ud82b\udc83\udab5\udf8c\ud938\ude49\ud8cc\udd1e\ud951\udf08\udab2\udd6c\ud9d1\udd06\ud893\ude9c\ud84a\udf02\ud8d9\ude43\udaa1\udd29",
        28, 44307, -1605049136, 71892855949900197L, -92702L, true, true, (char) 55935, (char) 260,
        Double.longBitsToDouble(0x3fee456a76af2fdaL), Double.longBitsToDouble(0x3fe3e67eb34e1e97L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 6, 7, 1, "\ud851\udf4c\udb2c\udf72\ud877\udc69\ud96a\udcb4", "\u13ae\u05b7\u01dd\u38d1\uc17e\u4090\u5c58", "\ud898\udf79\ud9d7\uddba\udb2f\udc42\uda97\udfe9",
        -1, 28450, -1100532496, 4828332103138130479L, 54031L, false, false, (char) 13046, (char) 52367,
        Double.longBitsToDouble(0x3fd0f9c9341deebcL), Double.longBitsToDouble(0x3fd154bb1a25f1e2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=null\012",
        Z.run(T, 2, 9, 8, 5, "\uda7b\udfe1\udb1a\udf03\ud99b\udd2e\ud933\uddcd\udbca\udeb7\ud95f\udf60\ud9aa\udf5b\uda36\udf4d\ud9dc\udde0\u385d\ud813\udda6\ud9e9\ude6b\uda6b\udfd7\ud867\udc93\ud8b9\udd38\ud898\udf79\ud9d7\uddba", "\ud047\uab17\u051f\uae5c\u2cab\u9625\ua0a9\u7ec3", "\ud890\udd2b\ud94a\ude09",
        3, 27908, -1735582949, 2528930352814798272L, -89160L, true, true, (char) 19134, (char) 25055,
        Double.longBitsToDouble(0x3feb79243b937e1dL), Double.longBitsToDouble(0x3fe5c855989c99bdL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 1970\0121=new org.jfree.data.time.Week:Week 1, 1970\012",
        Z.run(T, 2, 3, 19, 5, "\ud851\udf4c\udb2c\udf72\ud99b\udc73\ud933\uddcd\udbca\udeb7\ud967\udf6c\000\000\000\000\000\000\000\ud994\ude2a\026\ud898\udf79\udba0\udd3f", "\ud047\uab17\uaf28\u3752\u2cab\u4126\ua0a9\u7ec3", "\ud813\udebb\ud94a\ude99",
        -5, 65352, -91415781, 0L, 28277L, false, true, (char) 39168, (char) 17810,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c8559c6799bdL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 22352\012",
        Z.run(T, 1, 5, 0, 2, "\ud851\udf4c\udb2c\udf72\ud99b\udc73", "\u3731\u13ae\u55b7\u01dd\u38d1\uc17e\u7744\u5bf1\u348d\u740d\u0997\u23b1\uad23\ud4a4\ud047\uab17\u1ba3\u0220\u7b3f\u991c\u1fb1\u64a4\ua8d5\u8ec2\u9e0a\u05e3", "\udb22\udec8",
        1, 87888, 1269915740, -508355810286906094L, 50012L, false, true, (char) 45524, (char) 23916,
        Double.longBitsToDouble(0x3fb9e66f7f9c34e0L), Double.longBitsToDouble(0x3fe0500757f89a9fL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 6, 6, 7, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\ud969\udeef\u5c71\udaa7\uded4\ud803\udf34\uda55\udca1\ub678\ud97a\ude71\ud9e1\udda7\ud9a4\udf6c\ud8da\udfb1\ud902\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u9006\u7d4d\uc51f\ua0a9\u5ce8", "\ud9e5\udc1c\udb05\ude40",
        43, 91592, -92857573, -7164151581840100081L, 28277L, false, true, (char) 56952, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe3d29d733899bdL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 0, 0, "", "\u1720", "\u5c71\udaa7\uded4",
        41, 18847, 1436799825, -8671030043032124969L, 27362L, false, true, (char) 50364, (char) 58856,
        Double.longBitsToDouble(0x3fe5d2629800d629L), Double.longBitsToDouble(0x3fd003d00eb56230L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 8, 8, 6, "\ud851\udf4c\ud8e2\udd0c\ud9e0\ude13\udb16\udc68", "\u13ae\u55b7\u01dd\u38d1\uc17e\u7744\u5bf1\u348d\u740d", "\udb2f\udc42\uda97\udfe9",
        -1, 2798, -244894634, 6921593786185923326L, -80745L, true, true, (char) 27343, (char) 14131,
        Double.longBitsToDouble(0x3fe8d8598a18fa77L), Double.longBitsToDouble(0x3fd0f9c9374ae0bcL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, -15488\0121=new org.jfree.data.time.Week:Week 1, -15488\012",
        Z.run(T, 2, 16, 0, 1, "\ud9cb\udf49\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\uf982\ud87e\udc1e\ud898\udf79\ud9d7\udd7f", "\u702b", "\ud84a\udefd",
        49, 35123, 951115129, -2785383374016455024L, -80745L, true, true, (char) 27311, (char) 11434,
        Double.longBitsToDouble(0x3fe8d8beda18fa77L), Double.longBitsToDouble(0x3fd0f9c9341deebcL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 5, "\ud851\udf4c", "", "",
        9, 38723, 1704324433, -1024530744415628463L, -100000L, false, false, (char) 27320, (char) 40273,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e41475800000000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 24, 4664\0121=new org.jfree.data.time.Week:Week 24, 4664\012",
        Z.run(T, 2, 0, 0, 0, "\000", "|", "",
        34, 49224, -251368820, 6161003802972409886L, 56672L, false, true, (char) 30311, (char) 50372,
        Double.longBitsToDouble(0x3fc9e475b9a84efcL), Double.longBitsToDouble(0x3e47340000000000L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week -4, 24647\0121=new org.jfree.data.time.Week:Week -4, 24647\012",
        Z.run(T, 2, 5, 5, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbe2\udd46\u970a\ud967\udf71\ud926\uded7\ud997\udf1e\ud92e\udd24\uda03\udfd1\uda24\udd06\udb77\udc21\ud937\udd78\uda51\uddbd\uda0b\udd19\ud898\udfb0\ud9d7\uddba", "\u8923\u8a64\uc72e\u12cc\u7dd6\u0769\ua0a9\u530a", "\ud813\udeaa\ud94a\ude99\uda05\udcc5\udbce\uddab\ud9e0\udec7\ud96b\udd77\udb0b\udf2b\uda84\udde1\ud997\udff4\udb73\udeca\ud845\udc3d\udb19\udd8d\udae9\udc9c\ud991\udc34\ud8c7\udcb2\udbf2\udf9f\uda90\ude6f\ud806\udedc\udab4\ude37\uda15\udcf8\udac1\uddb9\udabf\uddf4\ud94c\udc7b\uda77\uddae\ud9e8\udd14\ud816\udfec\uda9d\uddab\udac3\ude91\udb98\udc7c\ud82d\uddfd\udb33\udda4\udb9e\udced\udbcd\udf0c\udbce\udcee\ud97b\udc40\udb76\udfeb\ud9e0\udd31\ud9d5\udd10\udb0b\udff1\ub8c4\ud942\udfe1\uda66\udde6\ud8ba\udd20\udb60\uddec",
        -4, 90183, 154488484, -6040033787991673599L, 42911L, true, true, (char) 51522, (char) 38294,
        Double.longBitsToDouble(0x3fc146ff577c9cccL), Double.longBitsToDouble(0x3fdd7ae1fcf72f46L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 9, 9, 14, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\udbe2\udd46\u970a\ud967\udf6c\ud926\uded7\ud997\udf1e\ud92e\udd24\uda03\udfd1\uda24\udd06\uda48\udcea\udb83\udffd\uda51\uddbd\uda0b\udd19\ud898\udfb0\ud9d7\uddba\udb2f\udc42\udaad\udce9\udbd2\uddad\ud9b7\ude1c\udb0e\udd32\ud98a\uddd2\udb58\ude9b\udaa2\udf78\ud8e8\udcd0\uda9d\udcec\u4a73\ud9bf\udc8e\ud813\ude95\ud94a\ude99", "\u948b", "\udbe0\udd2e\ud8f3\udd8f\udb73\udeca\ud845\udc3d\udb19\udd8d\udae9\udc9c\ud991\udc34\ud8c7\udcb2\udbf2\udf9f\udb42\udfe8\udbbc\udd2b\udab4\ude37\uda15\udcf8\udac1\uddb9\udabf\uddf4\ud94c\udc7b\uda77\uddae\ud9e8\udd14\ud816\udfec\uda9d\uddab\udac3\ude91\udb98\udc7c\udbdd\udcb4\ud82d\udc13\udae1\udf3d\udaa5\udce5\udbce\udc88\ud97b\udc40\udb76\udfeb\ud9e0\udd31\ud9d5\udd10\udb0b\udff1\ub8c4",
        50, 595, 1125661996, -5727454354263551398L, 76476L, true, true, (char) 57646, (char) 45882,
        Double.longBitsToDouble(0x3fec70aafe609c2fL), Double.longBitsToDouble(0x3fdc1da39efb14faL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 2, 18, 5, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud926\uded7\uda36\udf4d\ud9dc\udde0\u385d\uda24\udd06\uda48\udcea\udaa4\udf6c\ud8da\udfb1\udb02\udd3b\ud898\udf79\ud9d7\uddba", "\ud047\u4bc3\u1ba3\u3752\u3ce3\u418c\ua0a9\u7ec3", "\ud813\udebb\ud94a\ude99",
        3, 27908, -92857573, -844475404732412409L, 28277L, false, true, (char) 56934, (char) 26714,
        Double.longBitsToDouble(0x3feb73416b937e41L), Double.longBitsToDouble(0x3fe5c855986799bdL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 17651\0121=new org.jfree.data.time.Week:Week 53, 17650\012",
        Z.run(T, 2, 17, 0, 0, "\ud851\udef3", "\u14ea\u265d\u133a\u13ae\u55b7\u22b7\000\uc17e\u7744\u5bf1\u0082\u72f6\u0997\u23b1\uad23\ud4a4\ud047\u0b21\u1ac0\u0744\u632f\000\u1e16\uca89\u1cc0\ud277\u87e5\u05e3\ua7c9\u2c8b\u948b\uc441\ucad3", "\ud9e8\udc8b\u01f6\ud845\ude34\ud965\udfc0\ud8b1\udc9b\udb98\udda5\udaeb\udffc\uda8c\udd85\ud8e3\udc2a\uda1e\udd01\ud97c\udc81\udb0b\udeae\uda4d\udfd0\udb94\udd7a\ud851\udd32\ud8b6\udd6c\ud9c2\udf8d\udb24\ude10\ud8de\uddc5\uda7b\udeee\udab8\ude2c\udb53\udf45\ud95b\ude05\ud8f5\udc9d\ud8d1\ude84",
        59, 80954, -615804797, 5816038179048773569L, -64068L, true, true, (char) 51626, (char) 47465,
        Double.longBitsToDouble(0x3fee437b356b726eL), Double.longBitsToDouble(0x3fd83edc383075eeL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Long:1791046799999 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 13, 5, 18, "\ud851\udf4c\u4e27\udb46\uddfa\ud96a\udcb42\000\ud844\udc70\ud9fb\uddfc\ud9dc\udde0Q\ud8ee\udd04\000\udab5\ude99\udbd8\udf79\udad4\udf92\ud8c6\ude4f\ud9d7\udd7f\uda76\ude45:\u1dcd\000\udb14\udf23\ud84a\udefd\ud874\udc3f\ud9d6\udddcE\000\ud9e2\udf10\udb4d\udec7\ud813\udebb\ud94a\ude99\ud8b3\udc7c\ud9a8\udf9a\uda7d\udd0a\uf43c\ud945\udf2b\ud84d\uddae\ud86d\udfb9\u4245\udb87\ude98\ud988\udcf8\udb9d\udcaa\ud878\ude4b\ud96c\ude50\ud9e2\udcb3\ud962\udcca\u6cbc\ud982\udc0d\ub9e8\ud94f\udcca\ud812\udec5\udaf4\udecf\uda2b\udc0e\udb9b\udeb9\udb2d\udd87\ud96f\udc82\udbb8\uddda\ud969\ude87\ud96d\udf48\ud9a0\udf20\ud9e5\udcce\udaa7\udf8d\ud97c\ude23\uac38\uda9c\udfce", "\u9085\u13e5\u016f\u34c9\u96f2\ud510\u4498\uce4a\u2cc2\uac60\u530d\uc4a6\u8ebf\u6cf9\u2ecf\u945e\u4d8a\ua497\u34e1\u48f7\u0834\u6d5e\u9baa\uc893\u0b4d\u33f0\u4174\u7597\uc438\u279e\u30c8\u735c\u9876\u1bb1\u9682\ud523\u789a\u170b\u10e7\u6720\u5dc1\u3a6b\u584e\u2359\ud5c3\u6f70\uc9a3\ub897\uad4a\u1b21\u4945\u25ce\u91f3\u11db\ua1b4\u657a\u5c79\u289a\ua294\uc4c2\ud6d0\u7670\uae09\ud1b0\ub4a6\u7168\u5c82\uc450\u82e3\u55c4\u71a7\u24be\u7b71\ub3b0\u2cfc\u32e6\ua6ab\u91b8\ub054\ua119\uc415\u6038\u36dc\uc8aa", "\udb8a\ude41\uda9d\udc50\u1dbf\udb86\ude8c\udb62\udd52\udaf8\uddbd\uda97\udd71\ud917\udef7\ud9a3\uddfc\udb45\uddac\udb77\udc9d\u4749\ud8b4\udf70",
        10, 41516, -97529317, -3204992458770879781L, -28307L, false, false, (char) 32582, (char) 14452,
        Double.longBitsToDouble(0x3fe4c380f75eccb2L), Double.longBitsToDouble(0x3fd7c01eb66c106eL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 53, 17650\0121=new org.jfree.data.time.Week:Week 53, 17650\012",
        Z.run(T, 2, 0, 0, 0, "\ud851\udef3", "\u14ea\u265d\u133a\u13ae\u55b7\u22b7\000\uc17e\u7744\u5bf1\u0082\u72f6\u8b12\u23c4\uad23\u35a0\ud047\u0b21\u1ac0\u22e8\u632f\000\u1e16\uca89\u1cc0\ud277\u87e5\u05e3\ua7c9\u2c8b\u948b\uc441\ucad3", "\ud856\ude8a\u01f6\ud845\ude34\ud965\udfc0\ud8b1\udc9b\udb98\udda5\udaeb\udffc\uda8c\udd85\ud8e3\udc2a\uda1e\udd01\ud97c\udc81\udb0b\udeae\uda4d\udfd0\udb94\udd7a\ud851\udd32\ud8b6\udd6c\ud9c2\udf8d\udb24\ude10\udb8a\udc50\uda6a\udeb1\udab8\ude2c\udb53\udf4e\ud95b\ude05\ud8f5\udc9d\ud8d1\ude84",
        59, 80954, -615804797, 5816038179048773569L, -64068L, true, true, (char) 51626, (char) 47465,
        Double.longBitsToDouble(0x3fea637b35e402ebL), Double.longBitsToDouble(0x3fd83edc383075eeL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:22\0121=new org.jfree.data.time.Week:Week 27, 22121\012",
        Z.run(T, 2, 9, 0, 0, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud973\udfff\uda5a\udfc2\udbd6\udda9\udba7\udd5a\ud880\uddb4 \000\ud89e\ude2f\udb02\udd3b\ud8e7\udc5f\udbca\uddf8", "\ud047\u4bc3\ua382\u7f4f\u2cab\uc41c\ub2af\u7ec3", "",
        11, 69327, 879122863, 1719240653365196315L, -100000L, false, false, (char) 16582, (char) 52739,
        Double.longBitsToDouble(0x3fe2ccc0691b91c3L), Double.longBitsToDouble(0x3fef61c96b937e41L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:22\0121=java.lang.Integer:22\012",
        Z.run(T, 2, 9, 9, 1, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\ud967\udf6c\ud973\udfff\ud898\uddc1\ud934\udc6e\udba7\udd5a\ud880\uddb4 \000\ud89e\ude2f\udb02\udd3b\ud8e7\udc5f\udbca\uddf8", "\ud047\u4bc3\ua382\u7f4f\u2cab\uc41c\ub2af\u7ec3", "\u91f2\ud94a\ude99\uda05\udcc5",
        -2, 2547, 9687796, 1269948928L, 42062L, true, false, (char) 58078, (char) 23833,
        Double.longBitsToDouble(0x3fec9bf2093592deL), Double.longBitsToDouble(0x3fc85fcab8aa764cL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:23\0121=new org.jfree.data.time.Week:Week 19, 15536\012",
        Z.run(T, 2, 9, 0, 19, "\ud851\udf9e\udb2c\udf72\ud876\udfa0\ud96a\udd04\udbca\udeb7\udb25\udebd\ud96f\uddb0\uda5a\udfc2\ud86f\udf2e\udba3\udea7\ud995\udf13\u080a,\ud89e\ude2f\udb02\udd3b\ud8e7\udc5f\udbca\uddf8", "\ud047\u4bc3\ua382\u7f4f\u2cab\u388f\u8627\u7e58", "",
        11, 85471, -345209716, 1719032846378226459L, -100000L, false, false, (char) 16582, (char) 59891,
        Double.longBitsToDouble(0x3fe2ccc0691b91c3L), Double.longBitsToDouble(0x3fe761c968665977L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:23\0121=java.lang.Integer:23\012",
        Z.run(T, 2, 9, 9, 17, "\udb84\udf05\ud975\udded\ud860\uded0\ud96a\udd04\udbca\udeb7\udb25\udebd\ud96f\uddb0\uda5a\udfc2\ud86f\udf2e\udba3\udea7\ud995\udf13\u080a,\ud89e\ude2f\udb02\udd3b\ud8e7\udc5f\udbca\uddf8\udb20\udc11\udb52\udc01\uda3a\udd26\ud869\udf92\ud91b\udfc0\ud826\udefb\ud874\udc3f\ud98b\uddc3\udaf1\ude1e\udb46\udde1", "", "\uda34\udf55\udb9f\udcab\udba1\udc60\udac6\udeec\000\udbe5\ude75\ud94c\ude7c",
        13, 77489, 959271195, 6446703768696813670L, 49381L, true, false, (char) 55692, (char) 40480,
        Double.longBitsToDouble(0x3fd552cd3cffed58L), Double.longBitsToDouble(0x3fe52d791c429c55L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:24\0121=new org.jfree.data.time.Week:Week 27, 4738\012",
        Z.run(T, 2, 9, 5, 0, "\ud851\udf4c\udb2c\udf72\ud876\udfa0\ud96a\udcb4\udbca\udeb7\uda3a\udef5\udaf1\udffb\uda5b\udc18\udbd6\udda9\udba7\udd5a\ud880\uddb4\udba6\udcb2-\ud8b2\udf2f\udb02\udd3b\ud8e7\udc5f\udb0e\uddda", "\uafc8\u4b85\ua382\u7f4f\u2cab\uc41c\u33df\u9fe3\000", "\ud94a\ude99",
        27, 4738, -1787468894, 41605292361777152L, 28277L, false, true, (char) 31334, (char) 58078,
        Double.longBitsToDouble(0x3fef61c96b937e41L), Double.longBitsToDouble(0x3fd99bc1094b9892L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:24\0121=java.lang.Integer:24\012",
        Z.run(T, 2, 9, 9, 0, "\ud851\udf4c\ud95f\udf8b\ud9c1\udc11\ud96a\udcb4\udbca\udeb7\uda3a\udef5\udaf1\udffb\udbd8\udc03\udbd6\udd28\udba7\udd5a\ud880\uddb4\udba6\udcb2-\ud8b2\udf2f\udbe6\udd87\ud9d7\udc57\udb0e\uddda", "\uafc8\u4b85\ua382\u7f4f\u2cab\uac02\u33df\u9fe3\000", "\ud916\udf3f",
        45, 4166, -1787468845, 41605292361777152L, 28277L, false, true, (char) 31334, (char) 58078,
        Double.longBitsToDouble(0x3fef61c96e894141L), Double.longBitsToDouble(0x3fd99e5db94b9958L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone,java.util.Locale",
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone",
    "C|org.jfree.data.time.Week|<init>|",
    "C|org.jfree.data.time.Week|<init>|java.util.Date",
    "C|org.jfree.data.time.Week|<init>|int,org.jfree.data.time.Year",
    "C|org.jfree.data.time.Week|<init>|int,int",
    "M|org.jfree.data.time.Week|compareTo|java.lang.Object|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|equals|java.lang.Object|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|evaluateAsYear|java.lang.String|static",
    "M|org.jfree.data.time.Week|findSeparator|java.lang.String|static",
    "M|org.jfree.data.time.Week|getFirstMillisecond||new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getFirstMillisecond|java.util.Calendar|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getLastMillisecond||new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getLastMillisecond|java.util.Calendar|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getSerialIndex||new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getWeek||new:org.jfree.data.time.Week:",
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone,java.util.Locale",
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone",
    "C|org.jfree.data.time.Week|<init>|",
    "C|org.jfree.data.time.Week|<init>|java.util.Date",
    "C|org.jfree.data.time.Week|<init>|int,org.jfree.data.time.Year",
    "C|org.jfree.data.time.Week|<init>|int,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
