package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class Week_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 15, 1, 16, "\ud97d\ude0d\udb26\ude33", "\u7a57\u5e58\u597d\ua7c1\u00b1\uba58", "\udb9e\udf7a\udae1\uddec\udb03\udffc\udae3\udc76",
        21, 4949, 753416148, 5687092294207221086L, -84814L, true, true, (char) 21590, (char) 8409,
        Double.longBitsToDouble(0x3fdc0f21c64de8ecL), Double.longBitsToDouble(0x3fe204378f84a90fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 15, 13, 17, "\ud888\ude53\udb63\udce3\udb5f\udc66\ud97e\udf34\u55dc\uda07\uddfb\ud875\udea8\ud8bd\udd9a\ud922\udcbe\udb0c\ude4d\ud95b\udd57\ud8cd\uddf8\udb9e\udf7a\uda34\udd01\uda31\udf4b\udae3\udc76\uda7c\udd7e\ud8a2\udd36\ud95b\udc3c\udab6\udcf5\uda7e\udf16\ud882\udefd\ud85e\udff9\uda5c\ude80\udb32\udff8\ud99e\udec9\udb2b\udfaf\uda85\udc03", "\u71d9\u05d6\u0abf", "\ud854\udf48",
        38, 79839, -646163214, -2683917564359211085L, 31723L, false, false, (char) 40143, (char) 61444,
        Double.longBitsToDouble(0x3fc0c218775c950cL), Double.longBitsToDouble(0x3fa91f4bf294fb70L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 15, 0, 0, "\ud97d\ude0d", "\uac2c", "\u0d9e\uda16\ude6a\udb23\ude39\udb0c\ude4d\ud95b\udd57\ud804\udd14\000\udabc\udd5d\udb03\udffc\u6292\000\ud9cd\udc56\000",
        -5, 50822, 1204551874, 798263035343293853L, -100000L, false, false, (char) 0, (char) 42048,
        Double.longBitsToDouble(0x3fec20007c8c92edL), Double.longBitsToDouble(0x3fe92ad00e174671L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 4, 1970\012",
        Z.run(T, 1, 17, 1, 1, "\ud97d\ude0d\ud9cc\udc32", "\u7a57\u5e58\u58df\ua7c1\ub04f\000", "I",
        -5, -1000, 539058834, 1665293949L, -100000L, false, true, (char) 34775, (char) 18380,
        Double.longBitsToDouble(0x3fd0000002c0a5ecL), Double.longBitsToDouble(0x3fc9058220000070L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 15, 1, 16, "\ud8d0\udf45\ud9a8\udc4f", "\u7a57\u5e58\u597d\ua7c1\ua0a6\u2576\ubabc\u0bd4\u2f1e\u6986\u826c\ua8a6\u95ed\u7421\u550d\u89d9\u44a5", "\udb81\udd7d",
        18, 22648, -193579584, -8723143562489815488L, 97413L, false, false, (char) 11335, (char) 9761,
        Double.longBitsToDouble(0x3fed4bbf6eb90929L), Double.longBitsToDouble(0x3fd4fa0eacd9cdf0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 16, "\ud97d\ude0d\udb26\ude33\udb5f\udc66\ud97e\udf34\udb8b\udfb7\udac2\udc43\ud940\udfa6\ud83b\udf23\udb23\ude39\ud846\ude8a", "\u25df\u9808\u826c", "\ud9cd\udc56",
        38, 18359, 1628777822, 5173552686793243474L, -34112L, false, false, (char) 10205, (char) 8093,
        Double.longBitsToDouble(0x3fd4086f1f09521eL), Double.longBitsToDouble(0x3fe6d45df62c290cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 43, 18957\012",
        Z.run(T, 1, 0, 0, 16, "\000\000", "", "\ud913\udea6",
        10, 51622, -595202971, 6999042002169225487L, -6959L, false, false, (char) 38290, (char) 19336,
        Double.longBitsToDouble(0x3fe3eb3b08000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Long:107418 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 14, 13, 11, "\ud996\udc50\udb26\ude33", "\u7a57\u9385\u590f\ua7c1\u00b1\uba58", "\udb7a\udf95\ud805\udd3d\ud993\udd26\uda82\udc74\ud8fb\udf75",
        27, 37636, 1324129359, 7053249847385663170L, 87920L, false, true, (char) 44041, (char) 33169,
        Double.longBitsToDouble(0x3fe6efdf2b1da509L), Double.longBitsToDouble(0x3fc1eed2e582d940L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 15, 0, 4, "\ud97d\ude0d\udb26\ude33", "\u3182\u5e58\u597d\u33f8\u009c\ud7a8\u7e45\u5c59\u264e\u9808\u4bc2\u3fdb\ua3ae\u96d8\u31d0", "\ud882\udef6\ud85e\udff9\uda98\ude7e\udb32\udff8\ud9da\udff6\udbb1\udd11\ud841\udc80\ud963\udde9\ud9c0\udf9c\ud9ad\udf4e\udb5f\udf40\uda5d\udc3a\udb14\udfe4\ud8e5\udfe3\uda64\ude7f\ud853\udf5c\ud926\udef8\udb5e\udfb5\ud97f\udcbd\uda89\udc5a\udb9b\udfbb\ud8e0\udf3d\udb6f\udcc0\udb7a\udfe4\ud986\udcb9\udaa1\udfd6\ud9af\udc44\ud887\udebc\udb8f\udeca\udafc\udcd8\uda10\udccd\udad8\udd73\ud914\udc05\ud85f\uddfd\ud8d2\udd1c\ud994\udf51\ud9b5\udc55\ud8ad\udca6",
        34, 54490, 1218484145, -8780145927566485154L, -21670L, true, true, (char) 60036, (char) 6774,
        Double.longBitsToDouble(0x3fb8224bf47df990L), Double.longBitsToDouble(0x3fafee2ca958a7e0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 10, 28478\012",
        Z.run(T, 1, 19, 12, 16, "\ud97d\ude0d\udb26\ude33", "\u7a3a\u5e58", "\udb23\ude39\udb0c\ude4d\ud95b\udd57\ud8cd\uddf8\udb9e\udf7a\udae1\uddec",
        58, 87962, 1734421351, 7152383049935108052L, -22850L, false, false, (char) 33566, (char) 22705,
        Double.longBitsToDouble(0x3fd6052f69905822L), Double.longBitsToDouble(0x3fa46383b26f4760L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Long:1790467200000 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 11, 1, 16, "\ud97d\ude0d\udb26\ude33", "\u55e6\ub5fe\u597d\ua7c1\u00b1\uba58", "\udb9e\udf7a\udae1\uddec\udb03\udffc\udae3\udc76",
        21, 4949, 753416148, 5687092294207221086L, -84814L, true, true, (char) 21590, (char) 8409,
        Double.longBitsToDouble(0x3fdc0f21c64cacb0L), Double.longBitsToDouble(0x3fe204378f84a90fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 18, 19, 16, "\ud97d\ude0d\udb26\ude33", "\u7a57\u5e58\u597d\ua7c1\u00b1\uba58", "\udb9e\udf7a",
        45, 68278, 539058834, 7449282981694430845L, -59985L, false, true, (char) 34775, (char) 33566,
        Double.longBitsToDouble(0x3fd9d0b142c0a5ecL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 15, 1, 17, "\ud97d\ude0d\udb26\ude33\udb5f\udc66", "\u2a73\u64a3\ucf2a\ucd09\uc554\uc08f\u94e5\u787a\u9808\u09ca\u59d5\u95ed\u7421\ubaae\u9699\u9551\u6673\u0401\u3871", "\ud8a3\ude42",
        20, 87266, 248482831, -3516901767609417219L, -6327L, true, true, (char) 55761, (char) 17901,
        Double.longBitsToDouble(0x3fc094339f989e60L), Double.longBitsToDouble(0x3fd72439cca5196cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 18, -6476\012",
        Z.run(T, 2, 15, 1, 16, "\ud97d\ude0d\udb26\ude33\udb5f\udc66", "\u5e58\u8ca2\ua7c1\u00b1\uba58\ubabc\u0bd4\u25df\u9808\u826c\u48a8\u95c2\u7421\u550d\u89d9\u206e\u3bda\u7073\ua7f0", "\udbb1\udd11",
        20, 31240, 1080291246, -5602500146880645310L, 19382L, false, true, (char) 51575, (char) 286,
        Double.longBitsToDouble(0x3fdd70fc455520e6L), Double.longBitsToDouble(0x3fda8b6f0734914eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 7, 1, 20, "\ud97f\udd87", "\u07e3\ua2b9\u26cc\u8c22\u24f9\u0116\u0389\u6b83", "\udae1\ude34\udb03\udffc\uda18\ude31\ud912\uddd5\uda58\ude07\ud941\udd26\udab6\udcf5\uda7e\udf16\ud882\udefd\ud85e\udff9\ud879\udf9c\udb32\udff8",
        26, 36237, -2031015130, 8686972642660694947L, -580L, false, true, (char) 19961, (char) 6476,
        Double.longBitsToDouble(0x3f88cd0e7d895380L), Double.longBitsToDouble(0x3fd1c4e2d53b1d36L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 18, 8, "\ud97d\ude37\udb26\ude33", "\u2992\ub787\u8e96\uc003\uc145\ua36d", "\uda74\udf5f\u3df6\udaec\ude84\udb47\udd09\ud8e8\udf9c\ud98f\ude42\udbcd\udca6\ud879\uddce\uda7e\udf16\ud882\udefd\ud878\ude4e\udbee\ude83\udb5d\uddc3\ud96f\udc00\udbb1\udd11\uda85\udc03",
        57, 46643, -1539481230, 5338122433597049478L, 2164L, true, true, (char) 31164, (char) 22564,
        Double.longBitsToDouble(0x3fc9c97b11eb6c3cL), Double.longBitsToDouble(0x3fe2cfb350fec1ebL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 10, 6207\012",
        Z.run(T, 1, 3, 10, 16, "\ud97d\ude0d\udb2f\udd0f", "\u7a57\u5e58\u597d\ua7c1", "\ud81f\udc76",
        33, 45305, 388928655, 5834290094470253762L, 55261L, false, true, (char) 12036, (char) 14014,
        Double.longBitsToDouble(0x3fe04c3563524762L), Double.longBitsToDouble(0x3fb375851799ee18L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 9, 1, 17, "\udbb7\udc0b\udb22\udc8e", "\u4c44\u5e58\u597d", "\udac5\ude85\uda7b\udd26\udad1\udd0b\ud950\udeca\uda8e\udef0\ud8ab\ude71",
        4, 3591, -1105524909, 3235897717259112527L, -21824L, false, false, (char) 20570, (char) 35688,
        Double.longBitsToDouble(0x3fc1fdc4c2bc00a4L), Double.longBitsToDouble(0x3fce603eaa6a1bc4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 8, 4, 12, "\ud918\uddbc", "\ua732\u66c9\u8e71\u39e7\uc406\u31d5\uba58\ubabc", "\udabf\udd30\ud86c\udcd9\ud99b\udc58\ud7a3\uda76\udfb9\udb33\udcae",
        42, 85198, 841928025, -1962205144476971311L, -74968L, false, true, (char) 484, (char) 21687,
        Double.longBitsToDouble(0x3fdaaa980d1d3862L), Double.longBitsToDouble(0x3fc3dd92a5348bf0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 28, 7599\012",
        Z.run(T, 2, 2, 3, 1, "\ud9bd\udd4e", "\uac2c\u7a73\u5e58\u0b76\u54a2\u00fd\u6975\u8cfd\u4023", "\ud82e\udfec\ud971\udda0\ud99e\udd6a\udb8d\ude84\uda57\udce2\ud907\udc6a\uda74\udc27\ud8e0\udd68\udabd\udd08\udbdf\udf01\uda75\udc58",
        7, 59408, -1628361881, -6264755153753280636L, 68002L, false, false, (char) 16934, (char) 52787,
        Double.longBitsToDouble(0x3fb8196afbde6908L), Double.longBitsToDouble(0x3feeeee0e1803eecL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 19, 16, "\udabf\ude0e\udb26\ude33", "\u7a57\u5e58\u597d\ua7c1\u112b\uba58\ubabc", "\udae1\uddec\uda98\udf27\udbc2\ude05\uda7c\udd7e\ud9cd\udc56\uda99\udfe3\udab6\udce7\uda7e\udf16\ud882\ude58\udb14\udff0\uda5c\ude80\udb32\udff8\ud9da\udff6\udbb1\udd11",
        42, 15423, -1089802364, 3304971166639090369L, 34056L, false, false, (char) 23168, (char) 1468,
        Double.longBitsToDouble(0x3fd265f809f5f174L), Double.longBitsToDouble(0x3fe161962e52f43fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 6, 1, 16, "\ud98b\udcca\udb26\ude33", "\u58dc\u25fb\u171c\ua7c1\uc00e\ub9fe", "\udb9e\udf7a\udae1\uddec\udaeb\udd70\ud922\udf1a",
        21, 4949, 464088532, 5687092813898263902L, -84814L, true, true, (char) 21590, (char) 8409,
        Double.longBitsToDouble(0x3fdc0f21c64de8ecL), Double.longBitsToDouble(0x3fe204378f84a90fL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 18, 20, "\ud8ed\udf97\uda6d\udd79\udb5f\udc66\ud97e\udf34\ud955\udcfa\ud9b7\ude45", "\u00b1\uba58\ubabc\u0bd4\u76ea\u22f5", "\uda7c\udd7e\ud890\udc91\ud9ce\udd6d\udab6\udcf5\uda7e\udf16\udae1\udc0c\udb84\udd4e\uda5c\ude04\udb32\udff8\ud9da\udff6\udb18\udc10\uda85\udc03\udbc0\udfbb\uda5f\udd5d\ud83f\udc46\ud8c6\udfba\ud8e1\udfbb\ud9ca\uddec\uda19\udfdd\ud88e\udefa\uda62\udf8b\uda84\udcad\ud9d7\udfd5\uda9f\udeec\ud9d7\uddae\ud91a\udec5\ud9c8\udc69\udb7f\ude3f\udafe\udde1\udb1e\ude7a\u71ea\ud869\uddb2\uda8b\udd13\uda26\udfc8",
        -1, -279, 1288349196, -7630831874045965267L, -2894L, true, true, (char) 30268, (char) 10082,
        Double.longBitsToDouble(0x3fe42347453a9356L), Double.longBitsToDouble(0x3fe7cc0cb7778455L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 18, 12, 9, "\000", "", "\udac2\udc43",
        47, 34420, 1342177280, -2556377293297444962L, 92073L, true, false, (char) 44059, (char) 38516,
        Double.longBitsToDouble(0x3f2010e7d6700000L), Double.longBitsToDouble(0x3feea31a10000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:1790467200000 |this=org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 27, -20354\012",
        Z.run(T, 2, 11, 1, 16, "\ud97d\ude0d\ud8bf\ude21", "\u7a57\u5e58\u597d\ua7c1\u00b1\u3c05", "\uda83\udf7a\udae1\uddec\udb03\udffc",
        49, 48351, 328556157, 3235897713886787237L, -90078L, false, true, (char) 10019, (char) 58801,
        Double.longBitsToDouble(0x3fc905823703c870L), Double.longBitsToDouble(0x3fe937a3b1bddf75L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 51, -3603\012",
        Z.run(T, 1, 19, 0, 16, "\ud8c4\udc49\udb26\ude33\udb5f\udc66\ud97e\udf34\udb8b\udfb7\udbf0\ude9c\ud80e\udfa5\udaf4\ude20\udb23\ude39\udb0c\ude4d\ud95b\udd57\ud8cd\uddf8\udb81\udf7a\ud98a\udf69\ud6f1\udae3\udc76\uda7c\udd7e\ud9cd\udc56\udaed\ude2b\udab6\udcb8\uda7e\udf16\ud890\udc2b\ud85e\udff9\uda5c\ude80\ud811\udfc7", "\u63ab\ud734\u7057\u762e\u059a\ua4bb\ud369\ua3f9", "\ud9ca\udd04\ud948\udd57\ud990\udeee\udac7\udead\uc4a9\ud85a\udf47\uda9d\udfd9\uda7a\ude4e\ud8cf\udf6e\udbce\udc2c\ud85e\udfbe\ud9e9\udc13\udafe\udfc2\udbd5\udf53\udb25\udf0b\ud966\udf1b\udbb4\udcdd\udbbb\udea6\ud857\uddf2\ud9b3\udfa4\udbb6\udd20\udac2\ude6e\ud807\ude7a\ud9f0\udc50\ud9d3\udc92\uda68\udf4c\udafd\ude9c\udb4a\udcb9\udb11\udc8b\udac5\udf8e\ud881\udd6e\ud888\ude31\ud920\udfd3\uda43\udc83\ub05e\ud812\udefd\udafe\udc9d",
        32, 68258, 1362520464, 8464624614664181426L, 7057L, true, false, (char) 27289, (char) 27540,
        Double.longBitsToDouble(0x3fe3aaecb961ab7bL), Double.longBitsToDouble(0x3fe7bbf5e75ccb9eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 9, 14, "\ud97d\ude0d\udb26\ude33", "\u1a62\u5e58\u597d\u6a49\u00b1\uba58\ubabc\u0bd4\u3b7a\ua383\u8058\u1518", "\ud9da\ude9c\udab6\udcf5\uda7e\udf16\ud8d5\udd1e\uda3b\udce8\uda97\udd9d\udb32\udfef\ud9da\udff6\udbb1\udd11\uda85\udc03\udbb7\udd16\ud8d4\uddd0\udbd5\ude21\ud9bf\udc65\ud8e3\udf9c\udba4\udc95\uda94\ude5b\ud9a1\uddfc",
        -3, 71389, -1509253459, -5511632289088469630L, 39186L, false, false, (char) 26477, (char) 47969,
        Double.longBitsToDouble(0x3fca9c191654a374L), Double.longBitsToDouble(0x3fdaaab0500499d6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 31, 15463\012",
        Z.run(T, 1, 5, 20, 14, "\ud97d\udd7d\udb26\uddd9", "\u7513", "\udb22\udff7\udb23\ude39\ud8b9\udd73",
        31, 80999, -798560695, 1670435855246798318L, 85497L, true, false, (char) 412, (char) 9175,
        Double.longBitsToDouble(0x3fe2e2700a594528L), Double.longBitsToDouble(0x3fe25addd3e282baL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 11, -13879\0121=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 0, 7, 1, "\udb21\udea9\ud815\udec7\ud88e\ude0b\udb90\udc21\ud8a3\udcfd\udac2\udc8a\ud913\udea6\ud9ad\ude1c\ud818\udf0c", "\ud3d4\u4091\ub01a\u1775\u556e\u2802", "\udbf1\udfb3\udb94\udeae\ud838\udf22\ud85f\udc7d\udbab\uddb5\ud953\udffe\ue654\udbce\udfb7",
        44, 61681, -1406091311, 4491448694550651278L, -97495L, false, false, (char) 22546, (char) 33638,
        Double.longBitsToDouble(0x3fdc961fded2d76eL), Double.longBitsToDouble(0x3fd9a2cb26a70196L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 6, 12, 12, "\ud942\udcd9\ud8ec\udefb", "\u7a57\u5e58\u597d\u3ad5\u00d4", "\ud8cd\uddf8\udb9e\udf7a",
        45, 68278, -761240942, 7449282981694430780L, 41448L, false, true, (char) 61295, (char) 17730,
        Double.longBitsToDouble(0x3fe79e3eeb43d97aL), Double.longBitsToDouble(0x3fc905823703c870L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 25, -23511\0121=new org.jfree.data.time.Week:Week 25, -23511\012",
        Z.run(T, 2, 1, 1, 4, "\ud8b1\udc82\udb26\ude33\udb6b\udc5d\ud88e\ude49\udb8b\udfcb\udac2\udc43", "\u666f\u04f4\u4aa2\uc39d\u25c8\uca1b\u826c\uc059\u01f8\u8211\u6321\ub0dc\ua208\ucaab\u7073\u1d57\u460e\u6951\u2013\u63ab\ub8c6", "\ud905\udf4b\ud8db\udd96",
        28, 44705, 1519287886, 3661830067387929507L, 91023L, false, true, (char) 4705, (char) 44410,
        Double.longBitsToDouble(0x3fcf25b34e787e80L), Double.longBitsToDouble(0x3fed0328ca2cbfb1L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 8, 10, 8, "\udaea\udc04\ud908\udfba\udb5f\udc66\ud97e\udf34\ud985\ude33\u319d\udaf6\uddf8\udaea\udcfb\udb23\ude39\udb0c\ude4d\udacc\udd51\udabb\udf1b\uda2a\udef2\ud9e7\udf50\udb16\udffc\udae3\udc76\uda7c\udd7e\ud9cd\udc56\udb52\udeb5\udab6\udd92\uda7e\udf16\ud882\udefd\ud85e\udff9\uda5c\ude80\udb32\udff8\uda5d\udc36\ud9ba\ude8c\udbc4\udde6\udadb\udf89\uda44\udf48\ud9db\udf88\ud80f\udfaf\u0cfd\udafb\uded3\udb10\udf6f", "\u9dd8\ua8fe\ud4f4", "\uda0d\udc73\uda42\udd39\ud927\udfae\ud954\udd89\udb2a\udca7\ud884\udf6b\udb2c\udc98\uda2f\ude23\uda66\udda7\ud91b\ude90\ud8f7\udff3\ud8a2\udc23\udb5c\udf41\udba8\udfc0\udbb9\udf94\ud833\udcf5\udaae\udd7f\udad0\udd1a\u7e3e\ud8e4\ude24\udad2\udfa9\uda5e\udf95\ud93c\udf32\ud841\udc1c\uec0a\ud847\udcc8\ud8ea\udfbe\ud986\udf18\udb69\ude9a\ud8ea\udde0",
        16, 26289, 2113850057, -5805514961745577865L, -20439L, true, false, (char) 24489, (char) 27056,
        Double.longBitsToDouble(0x3fd719f7dd04db3eL), Double.longBitsToDouble(0x3fe3b328e730208cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=new org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 18, 2, 7, "\ud991\udf0d", "\ubbb1\uba2a\ucb64\u0e3a\uaa37\uabd6\u715c\ub7f3", "\u81b6\ud804\udc71\ud90a\udf32\udb8f\udd83\udb61\udc3b\u5cc5\udab6\udcf5\udb74\udf12\uda52\udf7f\ud8f9\udd8a\udb43\udd18\ud99c\udfb2\ud85e\udc7e\udb94\udf5b\uda85\udcca\udae7\udf10\udb02\udc92\ud8cc\udfa2",
        35, 40754, 538837152, -58088335161272836L, -10095L, false, false, (char) 31288, (char) 47017,
        Double.longBitsToDouble(0x3fee816955bb7f49L), Double.longBitsToDouble(0x3fd97ebbfcd41cecL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Long:1791052199999 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 15, 13, 17, "\ud888\ude53\udb63\udce3\uda59\udc7f\ud855\udc8c\ud82a\ude98\ud85e\udf36\ud875\ude92\ud8bd\udd9a\ud922\udcbe\udb0c\ude4d\ud95b\udd57\ud8cd\uddf8\udb9e\udf7a\uda34\udd01\ud934\udf0d\udb63\udc9e\uda7c\uddb5\ud8a2\udd36\ud95b\udc3c\udab6\udcf5\uda7e\udf16\ud882\udefd\ud925\udd91\udabf\udc12\udb32\udff8\uaaaf\udb2b\udfaf\ud9fa\ude5c", "\u71d9\u05d6\u38de\uc8b0f\u8de6\u1a86\u8ad3\u374c\u26ad\u8083", "\ud818\ude34\ud929\uddc9\uda34\ude38\uda01\udcc1\ud91c\udd87\uda67\ude8c\ud9cc\udec7",
        -2, 68347, -1026876425, -192688633683647495L, 97864L, false, false, (char) 12696, (char) 54686,
        Double.longBitsToDouble(0x3fd1f9ad39055cb6L), Double.longBitsToDouble(0x3fd2cfbe422eb6bcL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 11, 8, "\ud97d\ude0d", "\u8a86\u7a57\u5e58\u0d9e", "\udb0c\ude4d\ud95b\udd57\ud804\udd14",
        -5, 39624, 1234845934, 14513416064085784L, -100000L, false, false, (char) 11614, (char) 24943,
        Double.longBitsToDouble(0x3f31f32dd190a000L), Double.longBitsToDouble(0x3fe445e9881d2662L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 1970\012",
        Z.run(T, 1, 17, 20, 11, "\ud97d\ude0d\ud91c\ude8e\udb5f\udc66\ud97e\udf34", "\u0d9e\uc897\u00b1\u6ede\ubabc\ua974\000\u0379\u826c\u6292\000\u7421\000", "\ud879\udcfd",
        1, 92437, 739311968, 0L, -42208L, false, true, (char) 51065, (char) 6438,
        Double.longBitsToDouble(0x3fe0ba338d026157L), Double.longBitsToDouble(0x3fe9648e003a3b58L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 57, -10856\012",
        Z.run(T, 1, 5, 9, 1, "\ud97d\ude0d\ud9cc\udc32", "\u7a57\u5e58\u9d05\u66f6\ubb33\u7d37\ua1c6\u42de\u4f5f\ud6a9\u6e61\ua8a6", "\udaa9\udfe1\uda8f\udca6\uda7e\udf16\ud882\udefd\000\uda5c\udde3\uda45\udd5b",
        57, 54680, -2041316410, -7844888483856819766L, -26902L, false, true, (char) 21705, (char) 47679,
        Double.longBitsToDouble(0x3fea60f2e8972e4aL), Double.longBitsToDouble(0x3fec341d5dbb2e9cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 4, 1970\0121=new org.jfree.data.time.Week:Week 4, 1970\012",
        Z.run(T, 2, 17, 1, 1, "\ud97d\ude0d\ud9cc\udc32", "\u7a57\u5e58\u58df\u9fde\u5e78\u28bd", "I",
        -5, -1000, 539058834, 1665293949L, -45984L, false, true, (char) 34775, (char) 18380,
        Double.longBitsToDouble(0x3fd0000002c0a5ecL), Double.longBitsToDouble(0x3fc9058220000070L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 1970\012",
        Z.run(T, 1, 17, 1, 1, "\u0096\000", "\u5556", "\udae6\ude72\udbd9\ude34\000",
        -5, 94103, 73, 0L, -100000L, false, false, (char) 14292, (char) 232,
        Double.longBitsToDouble(0x3fb793bb36100000L), Double.longBitsToDouble(0x3f31f30000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week -2, -13497\012",
        Z.run(T, 1, 5, 1, 1, "\ud97d\ude0d\ud9cc\udc32", "\uc564\u5e58\ud3df\ua7c1\ub04f\000", "\ud977\udc9a\ud838\udf65\ud98f\udf85\ud8f7\uddad\udb4f\udc76\ud9cd\udc56\udaa9\udfe1\uda8f\udca6\uda7e\udf16\ud882\udefd\000\uda5c\udde3\udb32\udff8\udac1\udcc9",
        -2, 52039, -2042596710, -3919756488693843252L, -66406L, false, false, (char) 5296, (char) 50775,
        Double.longBitsToDouble(0x3fd96001e568dd02L), Double.longBitsToDouble(0x3fd30367e1f63246L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 1, 1, "\ud97d\ude0d", "\uac2c\u7a57\u9216\u4bdf\ua7c1\ub04f\000", "",
        -5, -1000, 0, 2315240062649892864L, -100000L, false, false, (char) 31582, (char) 9943,
        Double.longBitsToDouble(0x3f31f32800000000L), Double.longBitsToDouble(0x3fd6052f69905822L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 10, 17, "\ud97d\ude0d\ud9cc\udc32\udb5f\udc66\udbbb\udff6\ud883\udfb3\udac2\udc43\ud913\ude08\udae7\udef6\ud80b\udf6d\udaeb\udf2c\ud8de\udc56\udb0a\udd11\uda76\udc2c\000\udb5a\udc0c\udae9\udcfa\ud821\udf74\ud9cd\udc56\udaa9\udfe1\ud979\udc8f\ud888\udd56\ud882\udefd\000\ub9af\ud887\udf68\udb40\udd24\ud9d0\uddaa\ud950\udd64\u7b2b\udbbe\udd8b\ud82f\ude4b\uda2e\udc4f\uda77\ude34\uda86\udf54\u6f58\ud83d\udeaa\ud978\udda9\uda4d\ude85\ud86a\udf1e\ud898\udcfe\uda8b\udc98\udadf\ude87\udba8\ude67\uda33\udcb2\ud9ab\udf90\ud8c1\udc2f\udac2\udec8\udac2\udef8\udbfd\udec0\ud8b3\udfae\ud8bb\udf94\ud903\udd93\uda5f\ude49\ud93c\udeb7\udacf\udfa7\ud919\uded5\uda5d\udda9\u3cc1", "\u4a5c\u19d2\u5529\u5909\u53ec\u7d36\ubd78\ub992\uabd6\u2262\u270e\u42b5\u43d3\u9506\ubcf5\u930a", "\udada\udf17\ud8d9\uddb0\ud860\udfbb\uda1b\udf1e\u7566\udbbf\ude12\uda3d\ude87\udad9\ude0e\udab9\udc48\uda71\udece",
        31, 34823, 1711102169, 469602311714300328L, -36469L, false, false, (char) 32871, (char) 57087,
        Double.longBitsToDouble(0x3fd178639304f384L), Double.longBitsToDouble(0x3fb34f418161a0b0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 12, 1, "\000", "\uac2c\u7a57\u5e58\u58df\ua7c1\ub04f\000", "",
        3, -1000, 0, 2315240062649892864L, -100000L, false, false, (char) 11614, (char) 34775,
        Double.longBitsToDouble(0x3f31f32800000000L), Double.longBitsToDouble(0x3fd6052f60000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 8, -21112\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 20, 1, "\ud97d\udd97\ud9cc\udc32\udb5f\udc66\ud97e\udf34\udb1b\udf7f", "\u7c98\ub04f\ub800", "\ud91e\uded3",
        -1, 16518, -270351696, 4830391531536014973L, -90078L, true, true, (char) 37500, (char) 21466,
        Double.longBitsToDouble(0x3fc9058220000070L), Double.longBitsToDouble(0x3fdbd4187e281d66L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 16, "\ud9a3\udd76\udb26\ude33\udb5f\udc66\ud97e\udf34\ud9e5\udc8a\u0b8a\ud940\udfa6\ud83b\udf23\udb23\ude39\ud846\ude8a\uda9e\udd4a\ud896\udff2\udb9e\udf7a\udae1\uddec\udb03\udffc\udb9b\udf5c\uda84\ude23\udbd3\uddda\ud9da\ude79\ud8a9\udf67\udbbf\udf62\ud882\udefd\ud85e\udff9\uda5c\ude80\udb32\udff8\ud9da\udff6\udbb1\udd11\uda85\udc03\ud964\udc20\ud848\udcaa\ud8ed\udd45\udb81\udf6b\udad2\udfbe\ud9de\udc2f\udb55\udde0\ud92d\udedd\uda19\udec0\udbd1\udeb5\ud96d\uddb3\ud8b1\udd24\udb68\udea4\ud9fa\udc66\ud849\uddad\ud88e\udcc0\ud959\ude3e\uda26\udc40\ud8df\uded0\udb83\udd2d\udadf\udcf7\udb99\udc7e\ud82d\uddb4\uda2b\udcfe\ud85a\udeeb\udb5e\udfb3\udbb6\udd60\udbba\udc9c\udb75\udc19\ud81e\udc40\ud900\udf98\uda69\udd57\uda86\udef9\udb19\udff3\ud8a8\ude81\ud8a5\ude25\udbae\udf2b\ud9d3\ude28", "\uba6d\u4ebc\u425d", "\udbbe\udc16\uda37\udc44\ud843\udfb8\ud92f\udfe0",
        5, 82235, 914062553, 5590183822471462087L, 35352L, true, false, (char) 18669, (char) 3708,
        Double.longBitsToDouble(0x3fd67580b6436574L), Double.longBitsToDouble(0x3fd3f0b3160bc22aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 16, "\000", "", "",
        13, -1000, 0, 5787688470529305701L, 23151L, true, false, (char) 25845, (char) 44059,
        Double.longBitsToDouble(0x3fe0019800002021L), Double.longBitsToDouble(0x3fe3e80000000000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 39, 18957\0121=new org.jfree.data.time.Week:Week 39, 18957\012",
        Z.run(T, 2, 0, 0, 16, "\000\000", "", "\ud928\udfa6",
        10, 51622, -595202971, 6999041999770083599L, -9230L, true, true, (char) 50654, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fefdf61485db7fcL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Long:1790431200000 |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 20, 17, "\ud977\udd71\ud8ad\udc53", "\u55e6\u8566\uc336\u3695", "\ud9db\uddd7",
        20, 41735, -1953393521, 3184391897433072287L, 55261L, false, true, (char) 51510, (char) 49431,
        Double.longBitsToDouble(0x3fe7ebbc805247ccL), Double.longBitsToDouble(0x3fe3fc4e99605201L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Long:107418 |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 1, 17, "\ud84b\uddbd", "\u67ed\u5c44\u5e88\u597d\u8218\uc92c\ua643\u9bd2", "\uda8e\udef0\ud8ab\ude71\udaf3\udcf3\ud9f8\udd1d\udb88\udf70\ud9da\ude79\udacd\udcf2\udb6a\ude78",
        -3, 76662, 360705233, -1286210510350882673L, 38789L, true, false, (char) 46093, (char) 9525,
        Double.longBitsToDouble(0x3fe491047466542aL), Double.longBitsToDouble(0x3fe576aa2bad1476L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null\0121=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 8, 6, 6, "\ud8f1\udfad\ud94f\udd9e\udbfc\udcab\udbc4\ude81\udbe0\udd21", "\uab21\u5a33\u2bbf\u4156\u8514\ub7a6\ua74c\u8366\u6454\u47a3\u9d7e\u931e\u0d36\u1151\u18d3\u3650\ucb22\u5790\ub951\u6146", "\ud8cc\udfc8\ud80f\udd69\uda3d\uddeb\ud87f\udcec\udaef\udefe\uda0d\ude76\ud925\udcf3\ud897\udf18\ud97f\uddc9\ud90e\udfac\udb6e\udf5e\udb95\udd8c\udb33\udf56\ud802\udd36\udb03\udc54\ud929\udd8e\udb89\udda3\uda29\udf0a\udb42\udec0\u9a22",
        -4, 7313, -1514864583, 1284897611425633611L, 48177L, true, false, (char) 32303, (char) 1426,
        Double.longBitsToDouble(0x3fb80fcb8f1be5f8L), Double.longBitsToDouble(0x3fe97f22b3025f4bL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 3, 1, "\ud9bd\udd4e\ud94e\udd47\udb5f\udc66\ud97e\udf34", "\u0b76\u54a2\u00fd\u6975\u2930\u4023\u8e93\u0631\ua0f7\u3ac6\u4668\u3961\u0a86", "\ud8e0\udd68\udabd\udd08\udbdf\udf01\uda75\udc58\ud91c\udff7\ud911\udfe2",
        44, 14025, 935128964, -1021544088345984107L, 68002L, false, false, (char) 16934, (char) 52787,
        Double.longBitsToDouble(0x3fb8196afbde6908L), Double.longBitsToDouble(0x3feeeee0e1803eecL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 14, "\ud9c9\udf8b\udb7c\udd59", "\u1a62\u8474\u597d\u6a49\u00b1\uba58\ubabc\u0bd4\u6f16\ua383\u8058\u1518", "\ud9da\ude9c\udab5\uddf5\uda7e\udf16\ud8d5\udd1e\uda21\udf1a\uda5d\udea6\udb32\udfef\ud9da\udff6\udbbc\ude07\uda85\udc03\udbb7\udd16\ud8d4\uddd0\udbd5\ude21\ud9bf\udc65\ud8cf\udf52\ud9c7\uddc1\uda09\udce4\ud9b8\udc39",
        44, 71389, -1509253459, 3826948941065329588L, 39186L, false, false, (char) 51711, (char) 1221,
        Double.longBitsToDouble(0x3fca9c1e3654a374L), Double.longBitsToDouble(0x3fdaaab0500499d6L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 28492\0121=new org.jfree.data.time.Week:Week 1, 28492\012",
        Z.run(T, 2, 0, 1, 15, "\ud9dd\ude0c\uda3f\udcce", "\u512a\u5b28\u4328\uaac2\u00b1\u0872", "\udb9e\udf7a\udae1\uddec\udb86\udf5a\uda98\ude14\ud9db\udd6f",
        47, 8363, 1308714496, -6923089024475569892L, -31362L, true, true, (char) 63420, (char) 30086,
        Double.longBitsToDouble(0x3fb6df2197b24f30L), Double.longBitsToDouble(0x3fe7553c024ec7e4L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:1790442000000 |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Long:1790442000000 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 11, 11, 9, "\ud97d\udd7d\udb26\uddd9", "\u7513", "\udb22\udff7\udb23\ude39\ud8b9\udd73",
        31, 80999, -798560695, 1670435855246798318L, 85497L, true, false, (char) 412, (char) 9175,
        Double.longBitsToDouble(0x3fe2e2700a594528L), Double.longBitsToDouble(0x3fe25addd3e282baL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 0, 17, "\ud888\ude53\udb63\udce3\uda59\udc7f\udb6b\udf98\ud82a\ude98\u2bcd\ud875\ude92\ud8bd\udd9a\ud922\udcbe\udb0c\ude4d\ud95b\udd57\ud93e\udf51\udb9e\udf9a\uda34\udd01\uda58\udddf\udb63\udc9e\uda7c\uddb5\ud8a2\udd36\ud95b\udc3c\udbae\udee5\udbbc\udf6b\ud882\udefd\ud925\udd91\udabf\udc12\ud998\udffd\udb79\udfb9\ud828\udf4d\ud8eb\udff8", "\u71d9\u05d6\u38de\u5b3bU\u8de6\u1a86\u8ad3\u374c\u26ad\u8083\u6ca3\u18cd\u09bb\u3b9d", "\ud91c\udcda\uda67\ude8c\ud9cc\udec7\ud83d\udf1e\ud9c4\udd28\uda50\udc5b",
        21, 32929, 494227041, -1613625880686268451L, 79090L, true, true, (char) 27357, (char) 57616,
        Double.longBitsToDouble(0x3fd175b9bc59deccL), Double.longBitsToDouble(0x3fefa955b66aeb0dL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=null\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 8, 9, 13, "\ud921\udff4\udba7\ude3b", "\u79f4\u5e58\u3f3b\u9d71\ubb33\u4d8a", "\udafa\udef7\uda8e\udf0e\ud922\udfe1\udae4\udf30\u1183\ud9b6\udff5\udaa9\udfe1\udb3a\udddd\uda9d\udd3d\udb36\ude66\ud9ec\udcab\udbf5\udd5e\ud8bb\uddb5\ud811\udcd1\udad3\ude28\ud925\uddd4\udb53\ude38\ud9d8\udf01\ud8c5\ude1a\ud884\udc88\ud83b\udc4a\uf863\ud8fb\udf0a\ud971\uddfb\ud8dc\udd43",
        58, 29651, -434696238, -1258988034480682918L, 773L, false, true, (char) 14165, (char) 37092,
        Double.longBitsToDouble(0x3fb8c747371d2c80L), Double.longBitsToDouble(0x3fea781b36cb3c44L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 1, 1970\0121=new org.jfree.data.time.Week:Week 1, 1970\012",
        Z.run(T, 2, 17, 1, 1, "\u0096\000", "\u5556", "\udae6\ude72\udbd9\ude34\000",
        -5, 94103, 73, 0L, -100000L, false, false, (char) 14292, (char) 232,
        Double.longBitsToDouble(0x3fb793bb36100000L), Double.longBitsToDouble(0x3f31f30000000000L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 7, 6, 19, "\ud84a\udc39\udb4c\udf21\ud8fc\udf8b\uda59\ude85\udb1b\udfe7", "\u7c98\ub04f\ub800", "\ud91e\uded3",
        -1, 16518, -270351696, -2807713436479724231L, -90078L, true, true, (char) 37500, (char) 21466,
        Double.longBitsToDouble(0x3fc9058235ec0070L), Double.longBitsToDouble(0x3fddf8e4ee291d86L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 20, 1, "\ud97d\udd97\ud9cc\udc32\udb5f\udc66\ud97e\udf34\udb1b\udf7f", "\u7c98\ub04f", "\ud8cd\uddf8",
        2, 82153, -1730767518, -2079044253732410193L, -85708L, false, true, (char) 5514, (char) 34775,
        Double.longBitsToDouble(0x3fefb99326dbbba1L), Double.longBitsToDouble(0x3fcc6a4f5320b304L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 9, 9, 1, "\ud97d\udd97\ud9cc\udc32\udb99\udc44\udbef\udcd0\u2fca", "\u7c98\ub04f\ub800", "\ud91e\uded3",
        56, 16717, -270351696, 4830391531536014973L, -90230L, true, true, (char) 37500, (char) 21466,
        Double.longBitsToDouble(0x3fc9058220000070L), Double.longBitsToDouble(0x3fdbd4187e281d66L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 0, 12238\0121=new org.jfree.data.time.Week:Week 0, 12238\012",
        Z.run(T, 2, 5, 5, 1, "\ud8fb\udca6\ud9cc\udc32\udb5f\udc66\ud97e\udf34", "\u438b\u7c98\u171e", "\ud8c3\udf47",
        0, 77774, 438413878, -1161151597124190335L, -85708L, false, true, (char) 5514, (char) 14890,
        Double.longBitsToDouble(0x3fe920c48edbbba1L), Double.longBitsToDouble(0x3fd60527a9905822L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 21, -32607\0121=new org.jfree.data.time.Week:Week 21, -32607\012",
        Z.run(T, 2, 5, 5, 17, "\ud888\ude53\udb63\udce3\uda59\udc7f\udb6b\udf98\ud82a\ude98\u2bcd\ud875\ude92\ud8bd\udd9a\ud922\udcbe\udb0c\ude4d\ud95b\udd57\ud93e\udf51\udb9e\udf9a\uda34\udd01\uda58\udddf\udb63\udc9e\uda7c\uddb5\ud8a2\udd36\ud95b\udc3c\udbae\udee5\udbbc\udf6b\ud882\udefd\ud925\udd91\udabf\udc12\ud998\udffd\udb79\udfb9\ud828\udf4d\ud8eb\udff8", "\u71d9\u05d6\u38de\u5b3bU\u8de6\u1a86\u8ad3\u374c\u26ad\u8083\u6ca3\u18cd\u09bb\u3b9d", "\ud91c\udcda\uda67\ude8c\ud9cc\udec7\ud83d\udf1e\ud9c4\udd28\uda50\udc5b",
        21, 32929, 494227041, -1613625880686268451L, 79090L, true, true, (char) 27357, (char) 57616,
        Double.longBitsToDouble(0x3fd175b9bc59deccL), Double.longBitsToDouble(0x3fefa955b66aeb0dL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 7, 6, 19, "\ud84a\udc39\uda31\udf52\u4957\udb05\udfad\udae5\udf29", "\u7c8d\ub04f", "\ud83c\udec2",
        46, 77774, 617093603, -1161151809355972735L, -91047L, false, true, (char) 24970, (char) 34890,
        Double.longBitsToDouble(0x3fefb99326dbbba1L), Double.longBitsToDouble(0x3fe30293d4c82cd4L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Integer:1 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 6, 6, 19, "\ud84a\udc56\uda31\udf52\ud8e9\udd73\udb0c\udec6\udae5\udf29", "\u7c8d\ub04f\u2d7e", "\ud99b\udf2a",
        42, 83873, -270351723, -2807713436719944972L, -92732L, true, true, (char) 20529, (char) 46282,
        Double.longBitsToDouble(0x3fe6de578c60527aL), Double.longBitsToDouble(0x3fdfb5a407bf374cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:40 |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 1, 15, 20, 10, "\ud97d\ude0d\udb26\ude33", "\u7a57\u099a\ua171\ua7c1\u00b1\uba58", "\ud8e3\ude37\ud8fd\uddc9\ud974\udf90\udab5\uddd7",
        21, 4949, 463550420, 5687092483185782110L, -84814L, true, false, (char) 13416, (char) 49527,
        Double.longBitsToDouble(0x3fdc0f21c74f60ecL), Double.longBitsToDouble(0x3fe204378941f50fL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\0121=java.lang.Boolean:false |this=org.jfree.data.time.Week:Week 40, 2026\012",
        Z.run(T, 2, 7, 7, 8, "\ud97d\ude0d", "\u8a86\u7a57\u5e58\u1e8e", "\udb0c\ude4d\ud957\udefd\udb6f\udcde",
        -5, 39624, 89042926, 9095647758256844568L, -100000L, false, false, (char) 11614, (char) 24943,
        Double.longBitsToDouble(0x3f31f32dd190a000L), Double.longBitsToDouble(0x3fe445e9881d2662L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 22, -1637\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 20, 7, "\ud97d\udd97\ud9cc\udc32\ud841\udd18\udb06\ude50\ud87f\uded0\ud9f1\udf15\udb1a\udf4a\udb17\uddcd\udb13\udf23\ub889\000\ud8cd\uddf8\ud91e\uded3\u9eed\udab7\ude1b\udb8a\uddbc\ud928\udf74\ud9cd\udc56\udab3\ude86\ud9de\udf4e\udadc\udf25\ud8bc\uddba\uda1f\udfef\ud930\udfb7\ud8dd\uddd2\udab6\udd0e\uda3a\udfdc\udafd\ude9a\ud8c2\ude51\udaae\udd79\udba5\udc30\udb04\udf7c\uda31\ude10\u7ff5\udbe9\ude93\uda80\udc22\ud87c\uddf2\ud86b\uddfa\ud865\udc9e\ud983\udf07\udbab\udfe2\ud8ea\ude52\uda78\ude60\u3588\uda36\udc5d\udb9e\udd31\uda6c\udf4d\uda0e\udcdc\ud825\uddf7\ud9ef\udf2d\ud964\udfd2\ud919\udde1\ud962\uded9\ud9b3\udc47", "\u590e\u210a\ua08b\u2420\ud21d\u9cd4\ua631\u0898\u5935\u2d71\ua970\ua5f6\u85a6\u2fee\u1732\ud589\u9722\u5d8e\u572d\u091e\u1365\u76f5\u1e9e\u5653\u6660\u3879\u523e\u00e7\ud563\u9445\u964c\u2eec\u6602\u78fa\u5c9e\u80e3\u5157\uc7fd\u5285\ub352\u4af9\u92c9\u123e\u34a5\uaab3\u9969\ucc44\ub3a6\u6c88\uc27d\u787d\ub5e8\u4213\u224b\u7c61\uc92f\u1541\u8511\u6925\u34cc\u61f5\uc497\u7fc5\u1816\uada3\u84e9\u68d4\u15cb\ud42a\u9f45\u7265\u0ec1\u8f86\u7006\ub078\u491c\uca95\ubdd9\u17fb\uc454\u604e\u7eb1\u7722\u5778\uce03\u0cf2\u6622\u08fa\u2d42\u3ade\u6522\u04d6\uc270", "\uda66\udf92\ud969\udc46",
        18, 49145, -953232634, 4194026258853831194L, 29423L, true, true, (char) 4284, (char) 53288,
        Double.longBitsToDouble(0x3fe2aa3c62a2ffc7L), Double.longBitsToDouble(0x3fba5713ed23e7e8L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 52, -6289\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 20, 1, "\ud97d\udd97\ud9cc\udc32\udb5f\udc66\ud97e\udf34\udb1b\udf7f", "\u7c98\ub04f\ub800", "\ud91e\uded3",
        -1, 16518, -270351696, 3341815515256971315L, -90078L, true, true, (char) 37500, (char) 21466,
        Double.longBitsToDouble(0x3fc9058220000070L), Double.longBitsToDouble(0x3fdbd4187628621cL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 8, 8, 0, "\ud84b\uddbd\udb22\udc8e\uda9f\ude27", "\u5e88\u597d\u8218\uc92c", "\udace\udf8f\ud973\udcde\uda8e\udef0\uda7a\udfc8\udaf3\udcf3\ud9f8\udd1d\udb88\udf70\ud8ca\udde3\udacd\udd83\udb6a\ude78\ud914\udee4\ud8ea\udc5e\ud945\ude15",
        9, 86743, -1389350737, -6640027843508966891L, -3954L, false, false, (char) 64891, (char) 42581,
        Double.longBitsToDouble(0x3fe52cc0a984dbe4L), Double.longBitsToDouble(0x3fdce33add2510ceL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=new org.jfree.data.time.Week:Week 52, -6289\0121=new org.jfree.data.time.Week:Week 52, -6289\012",
        Z.run(T, 2, 16, 0, 14, "\ud97d\udd97\ud9cc\udc32\udb5f\udc66\ud97e\udf34\udb1b\udf7f", "\u7c98\ub04f\ub800", "\ud91e\uded3",
        -1, 16518, -270351696, 3341815515256971315L, -90078L, true, true, (char) 37500, (char) 61657,
        Double.longBitsToDouble(0x3fc9058220000070L), Double.longBitsToDouble(0x3fdbd4187628621cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone,java.util.Locale",
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone",
    "C|org.jfree.data.time.Week|<init>|",
    "C|org.jfree.data.time.Week|<init>|java.util.Date",
    "C|org.jfree.data.time.Week|<init>|int,org.jfree.data.time.Year",
    "C|org.jfree.data.time.Week|<init>|int,int",
    "M|org.jfree.data.time.Week|compareTo|java.lang.Object|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|equals|java.lang.Object|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|evaluateAsYear|java.lang.String|static",
    "M|org.jfree.data.time.Week|findSeparator|java.lang.String|static",
    "M|org.jfree.data.time.Week|getFirstMillisecond||new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getFirstMillisecond|java.util.Calendar|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getLastMillisecond||new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getLastMillisecond|java.util.Calendar|new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getSerialIndex||new:org.jfree.data.time.Week:",
    "M|org.jfree.data.time.Week|getWeek||new:org.jfree.data.time.Week:",
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone,java.util.Locale",
    "C|org.jfree.data.time.Week|<init>|java.util.Date,java.util.TimeZone",
    "C|org.jfree.data.time.Week|<init>|",
    "C|org.jfree.data.time.Week|<init>|java.util.Date",
    "C|org.jfree.data.time.Week|<init>|int,org.jfree.data.time.Year",
    "C|org.jfree.data.time.Week|<init>|int,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
