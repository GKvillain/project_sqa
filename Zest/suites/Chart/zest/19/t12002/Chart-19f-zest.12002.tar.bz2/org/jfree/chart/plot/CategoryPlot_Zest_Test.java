package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class CategoryPlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716192973, 4072110252550731686L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud953\uddb2\udb8c\uddf5", "\uc0e4\u6a08\u1343\u08f4\u8730\ube74\uc44f\u5155\u6237\ua89a\u5dad\u1f5e\u7704\u6ad5\u7226\u5eaf\u5dd0\u27fc\u5a27\u4e32\uaa26\u3a45\u77d0\u0af3\ua36d\u588d\u2e02\u2ce0\u0d3b\u9f21\u750e\u88a2\ucd00\u777d\u0dae\u1bc1\u4866\ub6e9\uadbb\uc572\uca7d\ud105\u2fb9\u3a05\u9727\u6758", "\ud9a8\udce3\ud9f0\udcb1\udbaf\udd0b\ud8bd\udec7\udb76\udd8d\ud9b8\ude92\udb38\udeda\ud8c5\udd2e\udba6\udd79\ud9b2\udde5\udb04\udd16\uda31\udec1\udaad\udffa\udad6\udf5e\ud94a\uddac",
        29, 70496, 210302156, 8280349754696269061L, 66125L, true, true, (char) 50199, (char) 55375,
        Double.longBitsToDouble(0x3fed2af3449624f7L), Double.longBitsToDouble(0x3fc61248466a2bb8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udb3d\ude9e\uda33\ude52\udb18\ude45\u1194\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716192973, 4072110252550731686L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5ec6fdc26L), Double.longBitsToDouble(0x3fd705ad6c7c1bfeL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\u707b\u6a08\u1343\u08f4\u8730\u993d\ud111\u5155\u6237", "\uda42\udd9f\uda6b\udd4e\ud93c\udd52\udba5\ude7d\ud944\ude4f\ud896\udea5\uda5f\udc2b\ud977\udd0a\uda63\uded7\udb6a\udf38\udac7\udd27\ufe95\udb39\uded1\udb73\udf7d",
        36, 69616, -1391203142, -1763796744540976693L, 58703L, true, true, (char) 10744, (char) 3763,
        Double.longBitsToDouble(0x3fe77b08eaccdb4dL), Double.longBitsToDouble(0x3fc38a6b7d1c01bcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 12, "\ud816\udfe4\udabb\udc82\udbf2\udfc1\udaf2\udc63\ud936\udde6\udb18\uddd1\ud82d\udf8d\udaac\udf65", "\uc0e4", "\ud9b3\ude19\ud845\udf97\ud8de\udf03\ud848\udde9\ud8f7\ude30\ua748\udbe8\udcae\udbe3\ude02\uda42\udd9f\udb21\udce8\ud93c\udcb1",
        44, 73850, -1621170089, -1291427836234350025L, 62564L, true, false, (char) 42862, (char) 34891,
        Double.longBitsToDouble(0x3fe69666fc5c9324L), Double.longBitsToDouble(0x3fd6a190454f74ecL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud866\udd22\udbb8\udcc0\ud9f2\udc4e\ud8e7\udf26\uda2b\uddc2\udb18\ude45\ud88c\udd97\udbe6\udf60\udb68\udcb7\ud8a6\udd15\ud91c\udff9", "\u08f4\u8730\ube74\uc44f\u5155\u6237\ua89a\u29fd\u3653\u33e6\u7892", "\ud919\ude13\uda99\udf99\ud94d\udccf\uda63\uded7\udba2\udd94\ud8aa\udcbf\uda44\udcb6\udb7e\uddea\ud8f3\udedf\ud973\ude2d\ud970\ude41\udb33\udd87\ud97c\uddd8",
        50, 40337, -1192229212, -5451571053544516689L, -81411L, true, true, (char) 30266, (char) 59915,
        Double.longBitsToDouble(0x3fe49ff32bebc797L), Double.longBitsToDouble(0x3fe07deb93d52e57L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\udbe1\ude3f\ud9ab\udef4\udbdf\udf99\udaf2\udc63", "\u6798\u3d85\u3ea7\u98d2\u4da1\u5301\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716192973, 4072110252550731686L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 12, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\ua7f2\u4b08", "\ud86e\ude16\uda82\udd24",
        1, 48429, 1699658250, 4072110252092450470L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419ff10da1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 2, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\uda1c\ude77\ud984\udef8\ud8ff\udf9f\udbf9\udd1f\udbe6\udf60", "\u1c13\u9768\u4d5e", "\ud90a\udfa5\uda0f\udf3f\uda09\udf04\uda92\udf1c\udb1c\udfd4\u7646\u0ef0\udaef\udd4b\ud8da\udf22\udb05\uded7\ud852\udc17\ud85d\ude5a\uda5f\udc2e\ud977\udd0a\uef23\ud87e\udcbf",
        10, 96932, -1768052853, 8334370274894606744L, -8950L, true, true, (char) 7608, (char) 26743,
        Double.longBitsToDouble(0x3f9413aa5fcdd080L), Double.longBitsToDouble(0x3fd65a3dc6c353feL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 0, "\udb3a\udd3c\udbb8\udcc0\u83dd\000\000\ud89e\udc0e\u8f23\udbe6\udf60", "\000\uba07\u1343", "]\ud9df\ude06",
        51, 39053, -716193024, 4072110251988498342L, 31277L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud92b\udf4a\udbd0\udc6b\udb1c\uded4\udaf2\udc63\ud860\udd60\udb18\uddde\ud88c\udd97\udbe6\udf60\udb68\udcb7\ud94f\udd03", "\u1343\u90b1\u0bc3\u8d4a\u9d10\u0c6a\u6d79\u308c\u5dad", "\ud816\udfaf\uda52\udfdd\udbb1\udf44\ud93d\udf63\ud9bf\udd27",
        53, 92263, 852743742, -7754068975686429823L, -30484L, false, true, (char) 45193, (char) 10546,
        Double.longBitsToDouble(0x3fe7d55ad8ef3be8L), Double.longBitsToDouble(0x3fefc20f266cfea2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 3, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u2864", "\ud8b3\udcc1",
        15, 85431, 16503053, -3076025395711898957L, 14833L, true, true, (char) 63851, (char) 50905,
        Double.longBitsToDouble(0x3fb5e81c69d4faf0L), Double.longBitsToDouble(0x3fe1bf709e0aa833L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 11, 13, 7, "\ud866\udd22\udbb8\udcc0\uda53\ude5e", "\uc0bf\u6798\u3d85\u3ea7\u7978\uc0e4", "\uda5a\udc6c\uda7c\ude7f\udab2\udc8e\ud9df\uddf7\ud80f\udf07\uda55\udcdd\ud9af\ude6c\uda9f\udfd3\uda76\udcf9\uda6b\udd4e",
        10, 93782, -1603198991, -6962872512852792006L, 88918L, false, false, (char) 38269, (char) 60234,
        Double.longBitsToDouble(0x3fe77e916fbac737L), Double.longBitsToDouble(0x3fbcbad96c6f1b98L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716192973, 4072110252550733208L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 12, 1, 0, "", "\u6195\000\u6ded\u3983", "\000\000\000\000\udae6\udc36\ud9b3\ude19\ud90b\udcd2",
        50, 38785, 39, 70880017084579840L, -99834L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fef8d3740570071L), Double.longBitsToDouble(0x3fd3a9f5e46fdc26L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 12, 10, 1, "\ud866\udd22\udbb8\udcc0\udaf4\udf65\udaf2\udc63\uda33\ude24\udb18\ude45\ucc8a\uda60\udcfd", "\uc097\u6a08\u7b8f", "\udb99\ude94\u147e\uda09\udf51\udb52\udd1b\udbe8\udcae",
        11, 15686, -927874927, 6750539379122936766L, -28407L, false, false, (char) 42865, (char) 40784,
        Double.longBitsToDouble(0x3fd5bdc56c20c4c4L), Double.longBitsToDouble(0x3fe45e8049e5eaeaL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 15, 12, 0, "\ud866\udd22\udbb5\udf46\ud875\udf07\udaff\udd1d\ud88e\udf6e\udb15\udd34\ud88c\udd97\udbd6\udd49", "\ua603\u27ec\ube5b\u26ed\ua04b\ubee1\u3cb2\u605b\u10b3\u7d5d\u5dad\u1c0f\ua575\u5c8f\ud3d0", "\ud852\udee2\ud907\ude66\uda63\uded7\udb7f\udd22\udb59\ude90",
        24, 31084, 2032169452, -2164801688715735542L, 91161L, true, true, (char) 32952, (char) 6949,
        Double.longBitsToDouble(0x3fd216c99ac38754L), Double.longBitsToDouble(0x3fb6f783de9afe20L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 7, "\ud866\udd22\udbb8\udcc0\udaf5\udc10\ud9ac\udeae\uda06\udd51\ud908\udc65\uda85\udc24\udbe6\udf60", "\uc11a\u6a08\u1343\u89f3\u8730\u2fdd\uc44f\u8b2e\u8ee4\u7d58\u3609\u913f\u6a64\u7010\ud4eb\u5eaf\u9c08\ub2e1\u6b87\u4700\ub189\u4176\u2d61\u2c5c", "\udbb3\ude09\udacb\udca0\ud81d\udccc\uda88\ude5d\udbfa\udd32\udb53\udeb7\ud9fa\ude8a\ud876\udf6e\ud847\udfd0\uda27\ude5f\udb6d\udcfe\udbd4\uddf6\uda8f\udf6d\ud8d8\udc81\udacc\ude01\uda03\udd0f\udab7\udc1b\udbf9\udc10\ud8e5\udceb\ud8f3\udeae\ud8f3\udc3d\ud874\udea9\udabe\udee2\ud816\ude30\uda17\udee6\udb6d\uddf4\u75ba\ud832\udf08\ud849\ude26\udbd7\udd4c\ud889\udc0c\ud9ec\udeff\udbf7\udfb2\ud849\uddfa\ud92b\udf39\udbcd\udcc8\udb92\udcb0\ud983\udc21\udbd1\uddf1\ud9d8\udd6a\udb5b\udde9\ud88a\udc64\ud80f\udcd5\udb7e\udf99\ud889\udfbb\ud95b\udf6b\ud9eb\udf4b\udbdd\ude55\ud819\ude38\udbac\ude71\uda35\udd57\udab2\ude66\udaf5\ude02\uda45\udee5\ud8e5\udeeb\ud844\uddd3\ud953\udc68\ud9ea\udf4e\udbab\uddf8\uda06\udc5d\ud9d9\udeaa\ud922\udfe4\udbb7\uded9\ud8eb\udd99\udbd7\udd33\ud96d\udfb3\udaa2\udf5e\ud816\udca0\ud88b\udfbf\udbf5\udd28",
        58, 92409, -391698770, 7345821494502275214L, -46532L, true, true, (char) 51491, (char) 24763,
        Double.longBitsToDouble(0x3fbd274e642e98c0L), Double.longBitsToDouble(0x3fe618d36e2361ebL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06\uda09\udf04\udb52\udd1b\udbe8\udcae\uda2d\ude07\uda42\udd9f\uda6b\udd4e\ud93c\udd52\udba5\ude7d\ud817\udcd8",
        34, 93026, -1473035721, 982099222018315838L, -91044L, false, true, (char) 44677, (char) 27897,
        Double.longBitsToDouble(0x3fd2a8fa55778612L), Double.longBitsToDouble(0x3fe8135ae6fd3e7eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 5, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\uda28\ude04\udbe6\ude9d", "\uc0e4\u6a08\u1343", "\ud8b6\udee2\ud9df\ude3e",
        51, 39053, -716192973, -611633359176127620L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 0, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716192973, 4072110252550731686L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud915\udc7a\udb70\uddae\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud879\udc97\uda0e\uddd5", "\u76f3\u6a08\u1343\u08f4\u8730", "\uda09\udf04\udb52\udd1b\ud9c9\udc4d\uda2d\uddab\uda42\udd9f\ud81c\ude84\ud93c\udd52\udba5\ude7d\ud944\ude4f\ud896\udea5\uda5f\udc2b\ud977\udd0a\uda63\uded7\ud941\udca3\udb73\udcc5\udbbf\uddf6\udbe5\ude52\udae8\udff0\ud9f2\udf58\udaaf\udd10\ud8b3\udddc\ud829\uddbd\udbf7\udd10\udb16\udd34\ud8cb\udeee\udb5c\ude5d\udaba\udd76\udbe9\udff9\udbaf\udc3a\uda51\uddcd\ud9b5\ude6c\udb04\udfc3",
        -4, 30495, -1004424250, -8978178752635473931L, 72128L, false, true, (char) 56722, (char) 36308,
        Double.longBitsToDouble(0x3fe617d7314684fcL), Double.longBitsToDouble(0x3fef6fa2b4b8eabeL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 15, 15, 3, "\ud866\udd22\udbb8\udcc0\ud946\ude0e\udaf2\udc63\uda33\ude24\udafa\udc45\ud88c\udd97\udbe6\udf60\udb68\udcb7\ud8a6\udd15\ud91c\udff9\ud9dc\udd92\ud881\ude3c\ud9b3\ude19\udad7\udd3b\ud8b3\udcc1\ud9df\ude06\uda09\udf04\udbfa\udc4e\ud8be\udfb5\uda2d\ude07\uda42\udd9f\uda6b\udd4e\ud93c\udd52\uf408\ud977\udd0b\ud896\udea5\uda5f\udc2b\ud977\udd0a\uda63\uded7\udb63\ude94\ud83d\udf98\ud986\udc2b\ud83d\udd7e\udb88\udee6\u4c84\uda9f\udd8d\udb84\udd8c\uf1d3", "\u4df8\u2dd2\u7ac0\u35db\u5df3\u649f", "\ud9d5\ude8f\ud86d\udd74\udb98\udcd1",
        38, 63786, 74852663, 7070467400483082137L, 20972L, true, false, (char) 60697, (char) 18915,
        Double.longBitsToDouble(0x3fd40bf643cc9e0eL), Double.longBitsToDouble(0x3feb05fb881d3608L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716216781, 4072110252550731686L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 15, 10, 14, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\ub59b\u553b\u1389\u5c72\u24bf\ube74\uc44f\ucdf4\u1249\ua89a\u6e47\u41ca\u8e10\u6ad5\u7226\u5eaf\u5dd0\u27fc\u5a27\u4631\u08d6\u342f\u5f77\u9b0a\u20e0\u8a66\u69b4\u5da1\ubebd\uac99\uc3cd\ub8b6", "\uda2e\udfbe\ud92c\udd10\uda5d\udc13\uda4b\uddf8\udab3\udc74\ud85e\udfdc\udac9\uddb9\u0aac\ud96e\udc0c\uda66\udfc0",
        29, 88069, 344330157, -6610253060362713580L, 34352L, false, false, (char) 61646, (char) 18423,
        Double.longBitsToDouble(0x3fe2e1b93b204cb9L), Double.longBitsToDouble(0x3fa3eb8349b5eac0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 7, "\ud866\udd22", "\u0ce0\u1f03\u3983\u6798\u9200\u6e29\ub3d0\uc0e4\u6a08\u1343\ucdf3\u8730\u4920\uc42c\u5155\u8958", "\uda42\udd9f\uda6b\udd4d\ud915\udd59\udba5\ude7d",
        4, 80911, -300683974, -6326640247306117622L, 82209L, false, false, (char) 51159, (char) 4944,
        Double.longBitsToDouble(0x3fe6f6d23eaa8444L), Double.longBitsToDouble(0x3fddce3da83fd0d4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbc9\udf71\ud82d\ude93\ud8a6\udd15\ud91c\udff9\ud9dc\udd92\ud881\ude3c\ud9b3\ude19\udad3\udc3e\uda5c\ude54\ud90a\udc8f\uda5d\udf11\udb1e\udca9\udbe8\udcae", "\u3be6\u8a13", "\ud896\udebb\uda5f\udc2b\ud977\udd0a\udb2d\udc3c\udb85\udce7\ud9ca\udf3b\uda87\udd6a\ud970\udc24\ud9f3\ude16\udbac\udf1d\ud931\udfbf\udba8\udd6d\ud9d9\udc95",
        39, 61438, -41618519, -4429450924466420397L, -80801L, false, false, (char) 54773, (char) 25814,
        Double.longBitsToDouble(0x3fe7bcd43c18fe13L), Double.longBitsToDouble(0x3fe6077bcfc8779cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 13, 10, 9, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716192973, 4072110252550731686L, 98707L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 1, 5, "\u58c3\ud86a\udfce\udb9f\udcbe\udb2c\uded0\u0f42\ud8a6\udd8d\udbe6\udf20\uda70\ude46\udb68\udcb7\ud8a6\udd15\ud8f0\udec6\ud92a\udd04\ud99e\udc7b", "\u4634\u2826\ub48d\u6225\uccc0\u5dad\u73ed\u7704\u39d7\uc1a8\u5eaf", "\ud9e8\ude1f\ud9bb\udd80\ud9bd\udeff",
        52, 19967, -1131080401, -7162641271404146605L, -16538L, false, false, (char) 62354, (char) 7302,
        Double.longBitsToDouble(0x3fed35c0ff80e552L), Double.longBitsToDouble(0x3fe46ec9053d99a7L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 12, 15, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1",
        15, 85431, 16503053, -3076025395711898957L, 14833L, true, true, (char) 63851, (char) 50905,
        Double.longBitsToDouble(0x3fb5e81c69d4faf0L), Double.longBitsToDouble(0x3fe1bf709e0aa833L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 12, 12, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\uda2e\ude60\uda33\udf0d\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, 609207091, 4094601806573942694L, 48531L, true, false, (char) 50757, (char) 35056,
        Double.longBitsToDouble(0x3fd2c9ffd47a175eL), Double.longBitsToDouble(0x3fb7732e3490b538L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 3, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 39053, -716192973, 4072110252550731686L, -17005L, false, true, (char) 50905, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 14, "\ud866\udd22", "\ub4fd\u1f03", "\ud8f7\udd6a\udb58\uddb0\ud8ae\udf4d\udbec\ude61\ud905\udf6a\ud89c\udcce\ud9b3\ude19\udad7\udd3b\udbc0\udea6",
        15, 19501, 16503053, -3076025398077486413L, 14833L, true, true, (char) 22015, (char) 50905,
        Double.longBitsToDouble(0x3fd57a0713b7df18L), Double.longBitsToDouble(0x3fe35f709e0a48daL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud866\udd22", "\u30d7\u1f03\u3983\u6798\u3d85\u3ea7\ub926\uc0e4\u6a08\u1343\u08f4\u8730\ube74\uba4f\u5155\u6237", "\000\000\000\000",
        -5, -1000, -300744704, 14428028031533056L, 12353L, false, false, (char) 3804, (char) 53945,
        Double.longBitsToDouble(0x3fefc9052e359703L), Double.longBitsToDouble(0x3fe40e2f7c6a768eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 15, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\ud8ce\ude41", "\u81af\u3d85\u3ea7\ub926", "\ud90e\udff0\ud9b3\ude19\ud989\udf1d\udab5\udc7f\uda04\udc5d\ud9ac\ude93\udbfe\udd39\udb0b\udeea\uda44\udc67\uda42\udd9f\uda6b\udd4e\ud9b7\uddd0\udb80\udfe0",
        4, 80911, -300683974, -6326640247312015862L, -84938L, true, false, (char) 30273, (char) 28226,
        Double.longBitsToDouble(0x3fe12c1e766d0dc4L), Double.longBitsToDouble(0x3fbc80da48663e48L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 8, "\udb60\udc3c", "\uc9ce\u1f03\u3983\u6798\u3d85\u3ea7\ub926p\ub951\u1343\u08f4\u8730\ube74\uc44f\u3827\u622a", "\uda42\udcf9",
        53, 70429, -1494705218, -6885687236946368425L, -51415L, false, false, (char) 58334, (char) 17031,
        Double.longBitsToDouble(0x3fe03e933dee9864L), Double.longBitsToDouble(0x3feea55dcdc7cd9dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 4, "\000", "", "\udb18\ude45\u8f23\000",
        -5, 47571, 0, 0L, 58109L, false, false, (char) 39257, (char) 30351,
        Double.longBitsToDouble(0x3f8a017e0cc03ec0L), Double.longBitsToDouble(0x3fe59ea807a63883L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud866\udd22", "\u1aaa\u1f03\u3983\u6798\u3d85\u3ea7\ub926\uc0e4\u6a08\u1343\u08f4\u8730\ube74\uc44f\u8909\000", "",
        19, 11073, 1571732224, -6419710030073749519L, -100000L, false, false, (char) 0, (char) 54845,
        Double.longBitsToDouble(0x3feb584aa6b66608L), Double.longBitsToDouble(0x3fb02804f4946bb0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 13, 9, 1, "\ud866\udd22\uda77\udfbe\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\uc0e4\u6a08\u1343", "\ud986\udc4a\ud9df\ude5d",
        51, 35506, -1840266345, -1980727861383579727L, -17005L, false, true, (char) 62169, (char) 40240,
        Double.longBitsToDouble(0x3fecf4978a370adcL), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 11, 9, 1, "\uda2d\udd09\udbb8\udcf1\udb1c\udf59\udaf2\udc63\udabb\udee8\udb23\uddb9\ud88c\udd97\ud93f\udca2", "\uc0e4\u6a08\u1343", "\ud8b3\udcc1\ud9df\ude06",
        51, 95077, -705503693, -971921330104223753L, -17005L, false, true, (char) 29084, (char) 35016,
        Double.longBitsToDouble(0x3fd3a9f5e46fdc26L), Double.longBitsToDouble(0x3fe055419e3e0da1L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 1, "\ud840\udd3f", "\u162d", "\ud97f\udf30",
        9, 78549, 954383803, 7992232855841114294L, 1746L, false, false, (char) 38858, (char) 39477,
        Double.longBitsToDouble(0x3fa39f3410decbf0L), Double.longBitsToDouble(0x3fe99807dab3d54fL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 10, 9, 7, "\uda2c\udc26\udb15\ude70\udb14\udfb7\ud839\udcbc\uda30\udf09\udb18\ude45\u1194\udbe6\udf60\udb68\udcb7\ud8a6\udd15\ud91c\udff9\ud9f3\udcfd\ud88e\ude0e\ud9b3\ude19\udad7\udd3b", "\u5155\u11d5\u4402\u2005\u27f3\u1a8b\u31c8\u149e\u65c7\u5dd0\ub764\uab83\u364d\u91f5\u17a2\ub357", "\udb67\udd90\ud801\udf89\ud8c2\udd53\ud890\udd21\udb92\ude2e",
        17, 78153, 1821841054, 5630121079583949764L, -62701L, true, false, (char) 25361, (char) 780,
        Double.longBitsToDouble(0x3fb013c57fd11680L), Double.longBitsToDouble(0x3fe49a9f6ccfe6b7L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 11, 11, 1, "\ua225\ud9f4\udd8f", "\u3503", "\ud8ca\udf05\udbf7\udf16\ud8a6\udd07\ud91c\udff9\ud95a\udd52\ud996\udc92\ud958\uddce\udadc\udecb\ud938\udc8f\udaf9\udf8d\uda09\udf04\udb52\udd1b\udbe8\udcae\uda2d\ude07\uda42\udd9f\uda6b\udd4e\ud93c\udd52\udbd7\udf56\ud96c\udd4f\ud896\udea5",
        46, 99023, -1737511424, -7782748012426328237L, 52625L, false, false, (char) 60467, (char) 29580,
        Double.longBitsToDouble(0x3fef0ca472a7101aL), Double.longBitsToDouble(0x3fe5ce1485c83541L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 14, 14, 14, "\ud866\udd22\udbb8\udcc0\uda4c\udf32\udb3d\ude9e\uda33\ude52", "\u3d85\u3ea7\ub926\uc0e4\u6a08\u1343\u25c4", "\ud9df\ude06\uda09\udf04\udb52\udd1b\udbe8\udcae\uda2d\ude07\uda42\udd9f\u4461\ud93c\udd52\udba5\ude7d",
        13, 23394, 370491033, 6485596940149951856L, 61053L, true, true, (char) 41266, (char) 52912,
        Double.longBitsToDouble(0x3fdbcef0dd51663eL), Double.longBitsToDouble(0x3fe007f9c9cf6cbdL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 10, 10, 1, "\ud866\udd22\udbb8\udcc0\udb1c\udf59\udaf2\udc63\uda33\ude24\udb18\ude45\ud88c\udd97\udbe6\udf60", "\u707b\u6a08\u1343\u08f4\u8730\u993d\ud111\u5155\u6237", "\uda42\udd9f\uda6b\udd4e\ud93c\udd52\udba5\ude7d\ud944\ude4f\ud896\udea5\uda5f\udc2b\ud977\udd0a\uda63\uded7\udb6a\udf38\udac7\udd27\ufe95\udb39\uded1\udb73\udf7d",
        36, 69616, -1391203142, -1763796744540976693L, 58703L, true, true, (char) 10744, (char) 3763,
        Double.longBitsToDouble(0x3fe77b08eaccdb4dL), Double.longBitsToDouble(0x3fc38a6b7d1c01bcL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 9, 9, 12, "\ud87c\udc5d\udabb\udc82\udbf2\udfc1\udaf2\udc63\ud940\udc4a\ud8ea\udcd7\ud833\udf3f\udaac\udf65", "\u114a", "\ud999\udfb7\ud845\udf97\ud8de\udf03\ud848\udde9\ud8f7\ude30\ua748\udbe8\udcae\udbe3\ude02\udb99\udfcb\udb21\udce8\ud93c\udcb1",
        44, 73850, -1621170089, -1291427836234350025L, -46280L, true, true, (char) 6875, (char) 2442,
        Double.longBitsToDouble(0x3fb4cd261b06a0f8L), Double.longBitsToDouble(0x3fe69666fc5c9324L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 0, "", "\000", "\000",
        -5, -1000, -1056636928, 54426955151310848L, -74912L, false, false, (char) 3895, (char) 0,
        Double.longBitsToDouble(0x3fe2c8000027cb00L), Double.longBitsToDouble(0x3fd0decbfb740072L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 0, "", "\u83dd", "",
        16, 35643, 985262059, -1667587413272117829L, -34282L, false, false, (char) 28651, (char) 102,
        Double.longBitsToDouble(0x3fb77b1b52c80000L), Double.longBitsToDouble(0x3fa39f3400000000L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 13, 13, 7, "\ud866\udd22\udbb8\udcc0\ud879\udff2", "\uc0bf\u76f2\u7584\u3edb\u7978\uc0e4", "\ud9db\udd69\uda7c\ude7f\udab2\udc8e\ud803\udc5a\ud839\udd1c\ud8ec\udd3b\ud9af\ude2f\uda9f\udfd3",
        44, 11073, 1571701965, -6419710029540614159L, -29658L, false, false, (char) 50749, (char) 58334,
        Double.longBitsToDouble(0x3fdc3efba0832612L), Double.longBitsToDouble(0x3fe77e916fbac737L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 15, "\ud866\udd22\udbb8\udcc0\udaf5\udc10\ud9ac\udeae\uda06\udd51\ud908\udc65\uda85\udc24\udbe6\udf60", "\uc11a\u6a08\u1343\u89f3\u8730\u2fdd\uc44f\u8b2e\u8ee4\u7d58\u3609\u913f\u6a64\u7010\ud4eb\u5eaf\u9c08\ub2e1\u6b87\u4700\ub189\u4176\u2d61\u2c5c", "\udbb3\ude09\udacb\udca0\uffd3\udb7d\udfff\udbfa\udd32\udb53\udeb7\ud9fa\ude8a\ud876\udf6e\ud847\udfd0\uda39\udd74\udb6d\udcfe\udbd4\uddf6\uda8f\udf6d\ud8d8\udc81\udacc\ude01\uda03\udd0f\udab7\udc1b\udbf9\udc10\u8029\ud951\udcc0\ud8f3\udc3d\ud874\udea9\ud80f\ude8a\ud97e\udf1c\ud955\udf88\udb72\udcb6\u75ba\ud832\udf08\ud849\ude26\udbd7\udd4c\ud889\udc0c\ud9ec\udeff\udbf7\udfb2\ud849\uddfa\ud92b\udf39\udbcd\udcc8\udb92\udcb0\ud983\udc21\udbd1\uddf1\ud9d8\udd6a\udb5b\udde9\ud88a\udc64\ud80f\udcd5\udb7e\udf99\ud889\udfbb\ud95b\udf6b\ud9eb\udf4b\udbdd\ude55\ud819\ude38\udbe3\udfec\udb74\udc90\u36ef\udaf5\ude02\uda45\udee5\ud9db\udd5a\ud99a\udd5a\udb0f\uddf7\ud9ea\udf4e\udbab\uddf8\uda06\udc5d\ud9d9\udeaa\ud922\udfe4\udbb7\uded9\ud8eb\udd99\udbd7\udd33\ud96d\udfb3\udaa2\udf5e\ud816\udca0\ud88b\udfbf\udbf5\udd28\udb6d\udfaf\uda20\udd7b\ud9b8\ude0c\udbeb\udfbc\uda53\udc80\udafb\udd3e\udab3\udd17\uda8a\udc8b\uc166\udb31\udef7\uda53\uddf5\ud971\udc55\ud8df\udfe2\ud9ea\udc05\ud967\udf4c\udb95\udcae\ud9e4\udcc8\udb0a\udfa1\ud942\udd24\udae0\udd3f\udb11\udd7a\udb16\udf60\ud8a1\ude2f\udbd6\uddd5\ud860\udc17\uda90\udf51\ud950\udd2a\ud812\udc8b\uda7f\ude81\ud960\udc9d\uda41\ude56\ud919\udead\udad7\udcfc\udb89\udd11",
        -4, 882, 1588818604, -4197696069751851525L, -34886L, false, false, (char) 19678, (char) 42367,
        Double.longBitsToDouble(0x3fb56a2af3fd1550L), Double.longBitsToDouble(0x3fdc074c816892d8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 15, 15, 4, "\uda31\ude7c\udbbc\udd85\udb1c\udf59\ud8e3\uddd9\udb6f\udd26\udb19\ude05\ud88c\udd97\udbe6\udf60", "\u7ea4\u691f\u862d\u84e7\u0b8c\u364f\ua23e\u9c2b\u7447", "\ud83f\udd4d\ud90b\udef7\ud836\udd66\u61ce",
        9, 80893, -1009429190, 239989475283186963L, 65871L, false, false, (char) 16500, (char) 21027,
        Double.longBitsToDouble(0x3fe8424618ed44dfL), Double.longBitsToDouble(0x3fce83b47a4f010cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 12, 11, 10, "\ud877\ude2b", "\u1320\u0e8f\u0f14\ua26e\u247d\uab78\u0098\uc0d0\u170c\u1343\u08b9\u0be5\ubec9\uc44f\u5155\u6237\ua89a\u5dad", "\ud926\udf35\udb85\udfcb\ud944\ude4f\udb0a\ude9f\uda5f\udc2b\ud977\udd0a\uda07\udc80\uda46\udf10\ud941\udf8a\u137d",
        28, 5490, 932537744, -2249806939223000061L, -32969L, false, false, (char) 8166, (char) 5885,
        Double.longBitsToDouble(0x3fc9fb3564865218L), Double.longBitsToDouble(0x3fe30dcd57cdd390L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 7, "\ud866\udd22\udbb8\udcc0\udaf5\udc10\ud9ac\udeae\uda06\udd51\ud908\udc65\uda85\udc24\udbe6\udf60", "\uc11a\u6a08\u1343\u89f3\u8730\u2fdd\uc44f\u8b2e\u8ee4\u7d58\u3609\u913f\u6a64\u7010\ud4eb\u5eaf\u9c08\ub2e1\u6b87\u4700\ub1d4\u4176\u2d61\u2c5c", "\udbb3\ude09\udacb\udca0\ud81d\udccc\uda88\ude5d\udbfa\udd32\udb53\udeb7\ud9fa\ude8a\ud876\udf6e\ud847\udfd0\uda27\ude5f\udb6d\udcfe\udbd4\uddf6\ud8f3\udca0\ud8d8\udc9b\udacc\ude01\uda03\udd0f\udab7\udc1b\udbf9\udc10\ud8e5\udceb\ud8f3\udeae\ud9d9\ude10\ud8b7\ude0d\ud92d\udd57\ud810\udc49\uda17\udee6\udb6d\uddf4\u75ba\ud832\udf08\ud849\ude26\udbd7\udd4c\ud943\udc09\ud9ec\udeff\udbf7\udfb2\ud849\uddfa\ud92b\udf39\udbcd\udcc8\udb92\udcb0\ud983\udc21\udbd1\uddf1\ud9d8\udd6a\udb5b\udde9\ud88a\udc64\ud80f\udcd5\udb7e\udf99\ud889\udfbb\ud95b\udf6b\ud9eb\udf4b\udbdd\ude55\ud819\ude38\udbac\ude71\uda35\udd57\udab2\ude66\udaf5\ude02\uda45\udee5\ud8e5\udeeb\ud844\uddd3\ud953\udc68\ud9ea\udf4e\udbab\uddf8\uda06\udc5d\udaed\ude53\udb68\udc47\udbb7\ude1d\ud8eb\udd99\udbd7\udd33\ud96d\udfb3\udaa2\udf5e\ud816\udca0\ud88b\udfbf\udbf5\udd28",
        58, 24889, -1281262546, 4632660890595802178L, -5782L, false, true, (char) 31032, (char) 61093,
        Double.longBitsToDouble(0x3fee82e6c8a658abL), Double.longBitsToDouble(0x3fd73031d65222c8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.plot.CategoryPlot|getDomainAxisIndex|org.jfree.chart.axis.CategoryAxis|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|getRangeAxisIndex|org.jfree.chart.axis.ValueAxis|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addAnnotation|org.jfree.chart.annotations.CategoryAnnotation|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addDomainMarker|int,org.jfree.chart.plot.CategoryMarker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addDomainMarker|org.jfree.chart.plot.CategoryMarker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addDomainMarker|org.jfree.chart.plot.CategoryMarker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addRangeMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addRangeMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|calculateAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|calculateDomainAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.AxisSpace|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|calculateRangeAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.AxisSpace|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearAnnotations||new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearDomainAxes||new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearDomainMarkers||new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearDomainMarkers|int|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|getDomainAxisIndex|org.jfree.chart.axis.CategoryAxis|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|getRangeAxisIndex|org.jfree.chart.axis.ValueAxis|new:org.jfree.chart.plot.CategoryPlot:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
