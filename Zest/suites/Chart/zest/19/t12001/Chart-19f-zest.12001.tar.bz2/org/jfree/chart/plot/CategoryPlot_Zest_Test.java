package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class CategoryPlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u361e\u9b38", "\udbc5\ude84\uda27\udf3a",
        16, 14243, -412088265, 6001473248952397768L, 33267L, false, true, (char) 46481, (char) 7801,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u361e\u9b38", "\udbc5\ude84\uda27\udf3a",
        16, 14243, -412088265, 6001473248952397768L, 33267L, false, true, (char) 46481, (char) 28974,
        Double.longBitsToDouble(0x3fcd3c4cc2c1cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\ud803\udec0\ud9c0\udf8e\ud83b\uddbc\udbaa\udc4d\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\udab1\udc45\udafb\udd44\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\udb38\udfb2\ud903\ude67\ud8a8\ude5b", "\u048f\uc75e\uc13c\u42f8\u3eb5", "\uda48\udecf\udbc5\ude84\uda27\udf3a\udb06\ude57\udadc\uddf4\ud99d\udec4\ud9f4\udd07\udaa1\ude31\ud80a\udfb6\ud90b\udd13\ud84c\udd9b\udaaf\udd2b\udb36\udcc8\ud984\udc70\ud981\ude2d\uda4d\udf8e\udb19\ude97\udaa1\ude54\udb5f\udf32\udb11\udf52\ud9fd\udf53",
        51, -37, 1596579288, -1886386603676484594L, -33603L, false, true, (char) 44407, (char) 23323,
        Double.longBitsToDouble(0x3fcb924e83b287e4L), Double.longBitsToDouble(0x3fa3910152a39020L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\udaeb\udef2\ud9c0\udf8e\udb4d\udee5\udab6\udc93\uda17\udeac\ud892\ude57\ud852\udd9a\udbec\udd6f\ud9b8\udff2\udb60\udd84\udbe6\udfb8\udace\udc58\uda97\ude05\uda93\udc91\uadab\udade\ude72\udb48\uded6", "\ub861\u99ae", "\ud857\udec0\ud8f2\uddd6\udad6\udd46\uda48\udecf\udbc5\ude84\uda27\udf3a\udb06\ude57\udadc\uddf4\uda97\udcd0\uda6e\udc9e\udbc0\udfdd\ud80a\udfb6\ud8b7\udc08\ud847\udefd\udaaf\udd2b\udba6\udc5a\ud960\udfba\ud981\ude2d\ud99d\udeb6\ud9d4\udf17\ud934\udf3d\ud8d2\udc6c\uda73\ude38\ud8a8\udd86\udb79\udccd\ud995\uddf6\udb2b\udcbb",
        1, 47655, -649159927, -3770230018156876850L, -88482L, true, true, (char) 46400, (char) 34664,
        Double.longBitsToDouble(0x3fd508df3e2cf708L), Double.longBitsToDouble(0x3fd6e3e4aa3685c4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 14, 12, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\udada\udd71\ud96a\udc33\uda97\ude22\udac4\udd91", "\u201a\u16d9\u66f0\u07a2\u99ae", "\ud857\udec0\ud8f2\uddd6\udad6\udd46\uda48\udecf\udbc5\ude84\uda27\udf3a\uda46\ude57\udadc\uddf4\ud99d\udec4\uda8c\udcf4\udb54\udcf3\ud80b\udc16\ud90b\udd13\ud84c\udd9b\uda83\udcfd\uda2c\udd52\ud960\udfba\ud981\ude2d\ud99d\udeb6\udb59\udd3a\udb24\udefd\ud8b6\udece\ud9e5\udc09\uda62\udcd9\ud822\udd2a\udb06\ude27\udb77\udfb2",
        21, 60877, -1733560388, -3165693838066322044L, -10293L, false, true, (char) 27679, (char) 27204,
        Double.longBitsToDouble(0x3fdfdea1c41429ccL), Double.longBitsToDouble(0x3fd416273dd7b324L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 12, 16, 6, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8ba\udfbd\ud889\udfb0\uda6c\udf6f\ud96a\udc33", "\u4f82\u8e6c\u5919\u16d9\u66f0\u07a2\ub40d\uba16\u0ac6\u361e\u9b38\u57c9\uab6e\u372f\ud42e\u1e97\u01f2\u631a\u56d5\u70c0\u8528(\u7ffe", "\udbf9\udca7\ud981\ude2d\ud99d\udeb6\uda74\udea8\u084b\uda41\udec8\uda75\uded5\uda51\udd11\ud90b\udf3e\udb66\udcbc\ud989\udf81",
        19, 82863, -1815091202, -3623695406584557415L, -84976L, false, false, (char) 20783, (char) 49157,
        Double.longBitsToDouble(0x3fe15b99be510d96L), Double.longBitsToDouble(0x3fb4467100e0b460L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 14, 16, 5, "\ud89c\udd72\ud9c0\udf8e\udb4d\udee5\udbff\udc49\udb6a\udf5e\uda03\udc27\ud85d\ude3e\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud981\udc9b\uda23\udffc", "\u74ad\ube9c\u21be\u1f49\u361e\u9b38\u57c9\u46fd\u9caf\ua0b1\u2300\uaa78", "\udad4\ude31\ud88b\udd56\udb57\udd19\ud84c\udd9b\udaaf\udd2b",
        7, 56825, -601167798, 1304332009469995562L, 4344L, true, true, (char) 58711, (char) 41656,
        Double.longBitsToDouble(0x3fe59125d46f916cL), Double.longBitsToDouble(0x3fee425fb93b0b43L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 5, "\ud889\udead\ud9c0\udf8e\udb4d\udee5\udad7\udc64\ud86f\udeb3\udb87\udc01\ud982\udd81\udbec\udd6f\udbc4\udefd\udbae\udce8\uda57\udde9\ud96a\udc33\ud836\udd30\uda1c\udf48\udac1\uded6\ud91c\ude6a\ud888\udc4b", "\u0738\uc5df\uc162\u6428\u4c0b\u5fdb", "\udb65\udd2e\uda27\udf9e",
        16, 14243, -412088265, 6001473455110827976L, 33267L, true, true, (char) 803, (char) 63265,
        Double.longBitsToDouble(0x3fea545f86a549b0L), Double.longBitsToDouble(0x3fec1890cbedc563L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 11, 2, "\000\ud9c0\udf8e\udb4d\udee5\u3f41\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\u3de7\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u361e\u9b38", "\uda98\udd0d\000",
        16, 14243, -412088265, 6001473248952397768L, -100000L, false, false, (char) 46291, (char) 7801,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud92d\udcfe", "\u1a4c\u9a44", "\ud857\udec0\ud8f2\uddd6\udad6\udd46\uda48\udecf\udbc5\ude84\uda27\udf3a\udb06\ude57\udadc\uddf4\uda29\udda9\ud9f4\udd19\udaa1\ude31\ud80a\udfb6\ud90b\udd13\ud84c\udd9b\udaaf\udd2b\uda2a\uddfd\ud960\udfba\ud981\ude2d\ud99d\udeb6\ud80f\ude35\udaef\ude5a\ud9b7\udf1b\udbc2\udd3f\u0d03\uda67\udd17\ud8ba\udc26\ud8be\udd57",
        37, 25016, -1544193006, 193756771142332588L, -25080L, false, true, (char) 60104, (char) 54539,
        Double.longBitsToDouble(0x3fe2d91570f63b85L), Double.longBitsToDouble(0x3fd693b2bac4411cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 9, 16, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba7\udfe2\ud86b\udcd9\uda46\udf91\ud838\udf52\udbec\udddc\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\uaebe\u9974\uc13c\u42f8\u361e\u9b38", "\udbc5\ude84\uda27\udf3a",
        16, 14243, -9435081, -4969840646470371313L, 33267L, false, true, (char) 46481, (char) 7801,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 6, "\ud828\udf70\ud9c1\udc38\udb4d\udee5\udba9\udfed", "\u6776", "\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d",
        -3, 83984, -1112197781, -3482020498512606104L, -26867L, false, false, (char) 65529, (char) 33054,
        Double.longBitsToDouble(0x3fe18bcfd9e5f078L), Double.longBitsToDouble(0x3fcff0f9844357e0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 11, 16, 5, "\ud879\udef9\ud9c0\udf8e\udb67\udce5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\ud9cf\udee1\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u5d3a\u9b38", "\udbc5\ude84\uda7c\ude25",
        48, 14243, -412088265, 6001473247850445553L, -80304L, false, true, (char) 46481, (char) 7801,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 13, "\ud879\uded6", "\u14ff", "\udbd1\uddda\udbec\udd6f\uda6c\udea9\ud8c9\udd51",
        23, 50397, -1885315902, 3370661539459518848L, -39644L, true, false, (char) 38251, (char) 19543,
        Double.longBitsToDouble(0x3fe431fe0a99e560L), Double.longBitsToDouble(0x3fe53233c23179fbL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 14, 6, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud963\udf0e\ud888\udc4b", "\u07a2\u99ae\ucb4e\ubf7b\u6d0c\ua094", "\udbe5\udf75\uda27\udf3a",
        16, 92755, -412088226, 6001473247640656521L, 33267L, false, true, (char) 46481, (char) 7765,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\ud879\udef9", "\u94d6", "\ud85d\ude20",
        41, 60565, -414209630, 657259305524932069L, 63400L, false, true, (char) 7750, (char) 7514,
        Double.longBitsToDouble(0x3fd6bb9af19d7b6aL), Double.longBitsToDouble(0x3fc47835a980761cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 11, 16, 5, "\ud879\udef9\ud9a1\ude8e\udb91\udd68\uda5a\uded8\ud84e\udcea\uda46\udf91\ud85d\ude20\udbfd\udf6f\udb91\udf8a\ud9fd\udfc3\uda57\ude64\udb17\udcd3\ud922\udfe3\ud862\udc0f\udadc\uddc1\udb3c\udec6\ud888\udc4b", "\u487a\u99f5\u268c\u31ad\ua66e\ub9ec\u1810", "\uda27\udf3a\udb06\ude57\udaa3\uddf4\ud99d\udec4\ud9f4\udd07\udaa1\ude31\ud80a\udfb6\ud90b\udd13\ud84c\udd9b\udaaf\udd2b\uda2a\uddfd\ud960\udfba\ud981\ude2d\ud99d\udeb6\uda9f\udc5c",
        56, 44719, -1410627939, -1009445701261442473L, 80114L, false, true, (char) 18784, (char) 27102,
        Double.longBitsToDouble(0x3fef6fa1f7e4d25eL), Double.longBitsToDouble(0x3fb1afae19d7f318L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 10, 10, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udbee\udf3f\ud86b\udc64\uda4f\udd91\udbbc\udd8e\ud8da\udc44\uda15\ude4c\ud876\udc2a\udb6a\udef5\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud898\udf32\udaf4\udc56\udbfc\udf92\ud969\ude76\ud8ae\udd09\u1cc5\uda8e\uddd0\ud8e1\udf51\ud887\udd01\ud9c7\udc3b\uda48\udecf\udbc5\ude84\uda55\udc49\ud909\udcfd", "\u0cf7\u70c0\u8528(\u7ffe\u9991\u45fd\u4e53\u64e8\u8670\ua517\u2639\u3d88\u0a9a\u570c\u2d61\u3059\ubfe5\u995c\u34db\ua3b8\u6dca\u76d8\u4810\u9c81V\u0549\u8a7d", "\ud9ee\ude05\ud8c6\udd8a\ud82b\udf1c\uda11\udd74\ud857\udc9c\udaad\udcb3\udb95\ude15\udb69\ude48\ud9fb\udd27\ud989\udecb\udae0\udee7\ud8d7\uddc9\udab4\udf8f\ud9a8\udcfc\udaa7\udc1b\ud91c\ude1a\udb7a\udfd5\udab6\udd2b\ud91d\ude73\udaac\udeed\udad6\udea7\udad1\ude2f\ud8c4\udfd2\ud9a2\uddcf\ud823\udfad\ud84f\udfa4\ud903\udc1c\ud808\ude52\udb9b\udc74\uda0a\udfc6\udb9c\udd27\u07e5\ud8ba\udc43\uda93\udc1e\ud8af\ude9b\uda22\udfb8",
        26, 62337, 1938650925, -220754808098437671L, -24613L, true, false, (char) 22238, (char) 61562,
        Double.longBitsToDouble(0x3fe039386e2c2f99L), Double.longBitsToDouble(0x3fe9167421aa659eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 9, 16, 6, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5", "\u5495\u6776\ub41a\u0d86\u42d5\u3f20\u1a1c\u8c57\u2d83\u95a0\u8e64\u5919\u16d9\u66f0\u3790\u42db\u6a01\u42f8\u0e44\u9af1", "\udbc5\ude84\uda27\udf3a",
        34, 14243, -412088265, 6001473257542332360L, 33267L, false, true, (char) 46481, (char) 7801,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fea4ee1551a4a5bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 9, 5, "\ud879\udef9\udaad\udce5\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\ud883\udf6d\udb75\udc7d\udb24\udd72\uda97\ude01\udac4\udd91\u3d5d\ud91c\ude6a\udbaf\ude3e", "\u07a2\u99ae\uc13c\u42f8\u361e\ub893\u01a0\u6c0d\ubde0\ud42e\u1e97\u01f2\u631a", "\ud80a\udfb6\udb2d\udf24\udba0\ude05\udaaf\udd25\udb4e\udccf\uda5a\udfb7\ud981\ude2d\ud99d\udeb6\ud9a0\udd1e\udada\ude28\udbed\udd48\udafa\uddeb\uda25\uddfa\ud997\udf35\uda7c\uddf0\ud0c3\ud886\udf52",
        5, 17852, 1122453797, 6971547576985478049L, 1309L, false, true, (char) 7010, (char) 17010,
        Double.longBitsToDouble(0x3fbe0c5e51bf1570L), Double.longBitsToDouble(0x3fe30abc1adb1db5L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 10, 10, 13, "\udaa0\ude8d\ud98f\udf34\udb4d\udee5\udba9\udfed\ud86b\udcd9\ud83c\udfec\ud86e\udc20\udbec\udd6f\uda91\udfff\ud944\udc6f\udbee\udf50\u7a42\uf2a9\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u1f76\u9b38", "\udbc5\ude84\uda27\udf3a",
        16, 14243, 80278107, 6001559650809491400L, 28896L, false, true, (char) 46481, (char) 7801,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 3, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u361e\u9b38", "\udbc5\ude84\udb6f\ude3d",
        28, 92587, -412088265, 6001473248952397768L, 33267L, false, true, (char) 46481, (char) 7801,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2aa36b832L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 13, 9, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\ud9bd\udc37\ud86b\udcd9\udb8a\udd1b\udbbc\udd8e\udaf4\udc8c\ud8f5\udc1e\uda2c\udc51\udbb8\ude41\ud970\udd67\uda97\udd75\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u361e\u980a", "\udbc5\ude84\ud97b\udf39\udb06\ude57\udadc\uddf4\ud99d\udec4\udbfe\ude6c\udaa1\uddc9\ud80a\udfb6\ud90b\udd13\ud84c\udd9b\udb8c\udf20\ud8a8\udefc\udabe\udce7\ud810\ude95\udbd8\udf7b\ud9c0\udeec\ud92f\udcd2\udb0c\udd01\ud83b\udf6e\ud8f4\udc78",
        36, 15747, -1644392630, 8700588559828260034L, -92898L, false, true, (char) 30181, (char) 1984,
        Double.longBitsToDouble(0x3fe77ec3320cbe63L), Double.longBitsToDouble(0x3fd092e3e83bcdf4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 15, 16, 5, "\ud879\udef9\ud9c0\udf8e\u2c45\udbcc\udca5\ud86b\udcd9\uda46\udf91\000\000\ud99e\udccf\udab4\udda6\000\ud95e\ude4e\uda97\ude22\udac4\udd91", "\u5919\u356b\u699b\u07a2\u99ae", "\ud857\udec0\ud8f2\uddd6\udad6\udd46\uda48\udecf\u00ff\uda27\udf2a\udb06\ude57\udadc\uddf4\ud99d\udec4\ud9f4\udd07\ud925\udfd4\000\000\ud84c\udd9b\udaaf\udd2b\ud874\udfc2\ud960\uded1\ud981\ude2d\ud99d\udeb6\ub886\ud823\ude19\ud815\udea6\udaff\udd7a\uda1e\udcfa\ud9c5\ude6c\uda43\udd91\ud890\udc5b",
        26, 97509, 195000419, 6390258798071582920L, 74551L, true, true, (char) 56991, (char) 34863,
        Double.longBitsToDouble(0x3fe0f9056d81c9efL), Double.longBitsToDouble(0x3fefe24fa896986dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\ud879\udef9", "\u1fcd", "",
        -5, 96656, -2030341435, -1779016814385230373L, -99806L, false, false, (char) 32838, (char) 7750,
        Double.longBitsToDouble(0x3fbc363a6b5dcd78L), Double.longBitsToDouble(0x3fc9d7b6b28f06b4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 15, 0, 5, "\ud913\udea8\ud8e0\udf3f\udbb4\udec3\ud9d3\udd05\uda83\udcb0\ud82a\ude31\ud85d\ude20\udbcd\udd40\ud8d8\udfa3\uda01\udfa9\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\ud91c\ude6a\ud968\udc9a", "\u07a2\u99ae\uc13c\u42f8\u361e\u930d", "\udbc5\ude84\uda27\udf3a",
        16, 26779, -379492715, 6001473236067495880L, 33267L, false, true, (char) 46481, (char) 2050,
        Double.longBitsToDouble(0x3fcd34c26129cec0L), Double.longBitsToDouble(0x3fd49dc2ad6ab832L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 3, 5, "\ud879\uded4\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\ud98d\udd5d\udac4\udd66\u3d5d\ud91c\ude6a\ud888\udc4b\udb7c\udd82\udaff\udd21\ud9bf\ude60\u1420", "\u361e\u9b38\u57c9\ua84c\uad87\u4beb\u1e97\ud51c\u2674\u7492\u70c0\u8528(\u0c40\u4b59\u084a\ud019\u90e0\u8670\u94df\uaba2\ua6fe\u5306\u2a2e\uad51\uc62a\u77e9", "\udb95\udd49\ud8d5\udcf0\u9828\ud97a\ude9f\udac2\udcb0",
        54, 93175, 597234769, 4237511825231012071L, 32122L, true, true, (char) 58866, (char) 35444,
        Double.longBitsToDouble(0x3fd88b15a1c3fe7aL), Double.longBitsToDouble(0x3fb302f2c86424b0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 16, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed", "\u6776", "\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d",
        -3, 8638, -1112197781, -4490826815043597149L, -26867L, false, false, (char) 65529, (char) 33054,
        Double.longBitsToDouble(0x3fe18bcfd9e5f078L), Double.longBitsToDouble(0x3fcff0f9844357e0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 0, "\udaeb\udef2\ud9c0\udf8e\udb4d\udee5\udab6\udc93\uda17\udeac\ud892\ude57\ud852\udd9a\udbec\udd6f\ud9b8\udff2\udb60\udd84\udbe6\udfb8\udace\udc58\uda97\ude05\uda93\udc91\uadab\udaa1\udfe9\udb72\udc79", "\ub861\u99ae\uc13c\u42f8\u361e", "\uda48\udecf\udbc5\ude84\uda27\udf3a\udb06\ude57\udadc\uddf4\uda97\udcd0\uda6e\udc9e",
        30, 68393, 279378701, -4197756808586530861L, -39351L, false, false, (char) 56691, (char) 49460,
        Double.longBitsToDouble(0x3fd81659472ec2a6L), Double.longBitsToDouble(0x3fd8d52024189e80L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\udac4\uddfd\ud9c0\udf6b\udb4d\udee5\udab6\udc93\uda17\udeac\ud892\ude57\ud852\udd9a\udbec\udd6f\ud9b8\udff2\udb60\udd84\udbe6\udfb8\udace\udc58\uda97\ude05\uda93\udc91\uadab\udaec\ude79\udb48\udea7\ud948\udca1\uda06\udd81\udb92\udd74\ud99f\udf50\ud8c8\udf2d\ud942\udd0d\ud857\udec0\ud92a\uddd2\udad6\udd46\uda48\udecf\udbc5\ude84\uda27\udf3a\udaf0\udf57\ud988\udde9\uda97\udcd0\uda6e\udc9e\udbc0\udfdd\ud80a\udfb6\ud8b7\udc08\ud9a8\udce5\udbdc\udeac\udba6\udc5a\ud960\udfba\ud981\ude2d\ud99d\udeb6\ud9d4\udf17\ud9c9\udee8\uda99\udc9a\uda73\uddc4\ud9df\ude0d\ud9b4\ude94\ud94a\ude46\udb2b\udcbb\ud97f\ude0d\ud9af\udff0\ud84b\udc5b\uda7e\udec0\udbed\ude0e\ud9d8\udfc0\ud9c4\udd14\u9b7f\udaa1\udcb0\udbc0\udc0d\udb8d\uddde\ud948\udef0\udb84\udeee\ud959\udf7a\ud9c7\udc97\udb14\udec1\ucd5f\uda02\udf28\udaa6\udfce\uda0b\udf38\udac1\udd18\ud94a\udfce\udb2a\udcb5\ud802\udc94\udba8\udc64\ud9ad\udf4d", "\u58eb\ub00b\u38a5\uc654\u271b\u9793\u9cd4\u5b71", "\udad9\ude9e\ud849\ude96",
        -3, 98874, 1608090210, 4333016146578109815L, -40288L, true, false, (char) 4810, (char) 42539,
        Double.longBitsToDouble(0x3fe903e91a67ca6cL), Double.longBitsToDouble(0x3fea6425477db4ffL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 12, 14, 12, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\udada\udd71\ud96a\udc33\uda97\ude22\udac4\udd91", "\u201a\u16d9\u66f0\u07a2\u99ae", "\ud857\udec0\ud8f2\uddd6\udad6\udd46\uda48\udecf\udbc5\ude84\uda27\udf3a\uda46\ude57\udadc\uddf4\ud99d\udec4\uda8c\udcf4\udb54\udcf3\ud80b\udc16\ud90b\udd13\ud84c\udd9b\uda83\udcfd\uda2c\udd52\ud960\udfba\ud981\ude2d\ud99d\udeb6\udb59\udd3a\udb24\udefd\ud8b6\udece\ud9e5\udc09\uda62\udcd9\ud822\udd2a\udb06\ude27\udb77\udfb2",
        21, 71813, -1183994, 4758447151479649668L, -10293L, false, true, (char) 27679, (char) 27204,
        Double.longBitsToDouble(0x3fdfdea1c41429ccL), Double.longBitsToDouble(0x3fd416273dd7b324L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 6, "\ud879\udef9\u5399\udb7a\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8ba\udfbd\ud889\udfb0\uda6c\udf6f\ud96a\udc33", "\ubac4\u5adf\ucf22\u4305\u66a2\u07a2\u7959\u0cb1\u0ab5\u361e\ua2e5\u57c9\uab6e\u372f\ud42e\u1e97\u01f2\u631a\u56d5\u70c0\u8528(\u7ffe", "\udb9e\ude4f\uda30\udc88\udb69\udd3f\ud877\udea3\u084b\uda41\udec8\uda8c\udfe0\uda51\udd11\ud90b\udf3e\udb66\udcbc\ud989\udf81",
        2, 82863, -1815091202, -3623695407794033569L, -84976L, false, false, (char) 20783, (char) 49157,
        Double.longBitsToDouble(0x3fe15b99bcc80d96L), Double.longBitsToDouble(0x3fdf9b55cc2632c8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 11, 16, 5, "", "", "\u6516",
        -5, 34952, 1708064768, -8720250063452919390L, 42821L, false, false, (char) 36464, (char) 32838,
        Double.longBitsToDouble(0x3fbdd063a0e81348L), Double.longBitsToDouble(0x3feb5dcfca32aed5L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 14, 14, 5, "\ud89c\udd72\ud9c0\udf8e\udb4d\udee5\udbff\udc49\udb6a\udf5e\udaae\udc08\ud858\udf7e\udbec\udd6f\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud902\udee4\ud97d\ude66\uda07\udcfe\u4a24\ud981\udc9b\uda23\udffc", "\ube1b\u0bc5\u84e8\u93be\ucba3\u9b38\u57c9\u46fd\u9caf\ua0b1\u2300\uaa78", "\ud893\udd11\ud8a0\udeed\udb57\udd19\udba7\udee8\udb6b\udc86",
        30, 56825, -601167798, 1304332009469995562L, -75016L, false, true, (char) 29424, (char) 41656,
        Double.longBitsToDouble(0x3fe68a85d46f916cL), Double.longBitsToDouble(0x3fee425fb9540d65L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 6, "\uda09\udcb5\u2c47\ud8d2\ude34\u2f44\ud8ad\udcda\uda46\udf91", "\u0fe3\u145f\u70aa\u594f\u5791\uc01c\u6f28\u00b8\u3340\u8b18\u5124\u3610\u148a\u0a65", "\ud8f2\uddd6\udad6\udd46\uda32\udc63\ud9d3\udde9\uda7c\udecb",
        48, 14243, -412088265, 6001474103873119035L, -80304L, true, false, (char) 23000, (char) 58440,
        Double.longBitsToDouble(0x3fdbe82531e8e760L), Double.longBitsToDouble(0x3fe986e1534c7abeL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 16, 5, "\uda76\uddd8\ud9f3\udda5\ud897\udca8\udbaa\udc85\ud86b\udcd9\uda46\udf91\ud85d\ude20\ud9cf\udee1\ud8d8\udfa3\uda02\udc2d\udb2d\udecf\udb4c\udc04\uda97\udd9c\udac4\udd91\u3d5d\udb86\udc9f\uff87\udb7c\udd82\udaff\udd21\ud9bf\ude60\u3520\udb4c\udd6e\ud944\udd66\udb48\udc19\ud8f2\udd53\udad6\udd46\uda48\udecf\ud8e6\udc34\ud9ff\udcfe", "\u710b\u56d5\uc610\ub2ba\u3f0c\u7ffe\u4b59\u084a\u2607\ud5d1\u8670\u9807\ubeb6\u3790\u415c\ub1e9\u94e9\uaf86\u80cb\u0af3\u5362\u4315\u43eb", "\ud849\udf61\ud8cc\udd9c\uda83\ude13\ud8d6\udeae\uda6c\uddaa\udb75\ude8e\udba8\udd78\ud8bb\udd2f\uda34\udfa8\udb6d\udebd\ud83f\udd5e\uda8c\udefc\ud8bf\uddd3\ud93b\udeca\uda81\udd02\ud871\udd05\ud96c\ude05\ud86d\uddca\uda7d\udff0\ud94c\uddd2\ud910\udc67\ud94a\udf34\udb39\udf13\uda17\udf70\ud873\udf47\ud9be\udc0b\udad8\ude60\ud9c6\ude1b\uda33\udd5e\ud90e\udcbc\udbba\udc62\uda9f\udc8a\udbe1\udf72\ud9ca\udf4d\udb5d\udfe9\uda3e\udf92\ud9aa\udcd4\uda31\udf13\ud93d\udf08\udb8e\udec6\uda98\ude71\ud9cc\udc38\ud878\udd2b\ud811\udf0e\udbec\udfcc\udbbe\udd74\udaa4\udf3f\u8895\uda27\udeea\ud859\uddc4\ud8c1\udfc2\ud8dc\ude8f\uda19\ude74\ud861\udf89\ud874\udd59\udbd0\udc5d\u0f09\udb23\udd4f\uda4a\udd7c\ud9b3\udf42\ud874\ude43\udb00\ude7c\udbae\udd61\udbed\udd65\ud97c\udd0e\uda62\udf73\ud99d\udf3f\ud9b1\ude60\ud80b\udc69\udb6a\uddcc\ud966\udce9\udb10\uddcc\ud9cd\udc8a\ud9a3\uddba\udbe2\udf62\udb10\udf73\udb7c\udeb6\uda47\ude24\ud9ef\udc6e\udbdf\udcf9\udb3f\udd94",
        43, 65123, -724010797, -8419017465223726350L, 1515L, true, false, (char) 9217, (char) 39418,
        Double.longBitsToDouble(0x3fad64c5033c4cd0L), Double.longBitsToDouble(0x3fd3943c678b0296L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 5, 13, "\udb2a\udfb3\ud9fd\udf79\udb67\udce5\udba9\udfed", "\u6776", "\uda02\udc2d\uda57\ude64\u9a11\uda97\ude22\udaf1\ude28\udbc1\uddcd\ud91c\ude6a\ud888\udc4b\ud95d\udfba",
        15, 84859, -1345511072, 4593985723313243782L, -49478L, true, false, (char) 49757, (char) 28875,
        Double.longBitsToDouble(0x3fd10d5f81bd154eL), Double.longBitsToDouble(0x3fcc6a9780df3910L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 4, 5, "\ud879\udef9\ud91c\udf5d\udb91\udd68\uda5a\uded8\uda62\ude93\ud808\ude7f\ud8aa\udeeb\udbe0\udcaf\udb91\udf8a\ud9fd\udfc3\uda57\ude64\udb17\udcd3\ud922\udfe3\uda6b\udd34\uda3f\udc05\udb3c\udec6\ud888\udc4b", "\u487a\u99f5\u268c\u31ad\ua66e\ub9ec\u1810", "\uda27\udf3a\udb06\ude57\udaa3\uddf4\ud99d\udec4\ud9f4\udd07\udaa1\ude31\ud80a\udfb6\ud90b\udd13\ud84c\udd9b\udaaf\udd2b\uda2a\uddfd\ud960\udfba\ud981\ude2d\ud99d\udeb6\uda9f\udc5c",
        56, 44719, -1410627939, -1009445701261442473L, 14578L, false, true, (char) 18784, (char) 27102,
        Double.longBitsToDouble(0x3fef6fa1f7e4d25eL), Double.longBitsToDouble(0x3fb1afae19d7f318L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 13, "\udaa6\ude8d\ud98f\udf72\udb4d\udee5\udba9\udfed\ud86b\udcd9\ud83c\udfec\ud86e\udc20\udbec\udde2\udbe3\ude68\ud8d9\udcbc\udbee\udf50\u7a42\uf2a9\udac4\udd91\u3d03\ud91c\ude6a\ud888\udc4b", "\ud007\u8fe7\uc13c\u42f8\uc827\u9b38\u57c9\uab6e\u372f\u235f\u1edc\u01f2\u5c78\ua56a\u70c0\u0788;\u7ffe\u4b02\u084a\u3bc8\ud5b0\u8701\ud736", "\udbed\udd7e\ud947\udc76\udbdb\udf71\ud985\udedf\ud9d7\uddea\ud985\ude5c\ud89a\uddc7\udb84\udfa4\ud846\udddd\ud928\udf3f\uda86\udfd5\ud91e\udd8e",
        38, 23709, -1079204392, 3053110718943156515L, 52313L, true, false, (char) 59833, (char) 48796,
        Double.longBitsToDouble(0x3fe870aaef616ba6L), Double.longBitsToDouble(0x3fcd52ee38b461c0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 10, 10, 13, "\ud82d\udc73\ud90f\udfca\udb4d\udee5\udba9\udfed\ud86b\udcd9\ud83c\udfec\ud86e\udc20\udbec\udd6f\uda91\udfff\ud803\udd8e\udbda\udd32\uda23\udd0c\uda58\uddc6\udac4\udd91\u3d5d\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\ua376\u9b38", "\udbc5\ude84\uda27\udf3a",
        16, 14243, 81536859, 6029536724178251720L, 28896L, false, true, (char) 46481, (char) 26438,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fee704ec6176db0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\u0243\uda47\udcd0\udb99\udc45\udbe9\udf1b\ud8d8\udfa3\uda02\udc2d\uda57\ude64\ud96a\udc33\uda97\ude22\udac4\udd91\u3d5d\u1a5f\udad8\udf8a", "\u07a2\u99ae\uc13c\u42f8\u361e\u9b38\u57c9\uab6e\u372f\u1939\ucc8c\u0941\u631a\u56d5\u70c0\u8528\uc199", "\uda2a\uddfd\ud960\udfba\ud981\ude2d\udb7e\udcc7\ud888\uddec",
        15, 78340, 675561194, -8757303394064154031L, -69537L, true, true, (char) 6257, (char) 10564,
        Double.longBitsToDouble(0x3fe6b270a066090bL), Double.longBitsToDouble(0x3fecc32d17545016L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 13, 13, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udbaa\udc2f\uda77\ude3e\ud9e6\udd60\ud8ad\udcf6", "\u145f\u70aa\u3d75\u5a7c\u2170\u6f32", "\udb7c\udd82\udaff\udd21\ud9bf\ude60",
        16, 14500, -443001263, 5077837826339060390L, 12368L, false, false, (char) 48539, (char) 63611,
        Double.longBitsToDouble(0x3fdcd2e70f9056e4L), Double.longBitsToDouble(0x3fbe55c3d8bf98a0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 9, 9, 5, "\u12f3\ud9c0\udf8e\udb4d\udee5\ud9bd\udc37\ud86b\udcd9\udb8a\udd1b\udbbc\udd8e\udaf4\udc8c\ud8aa\udd59\uda2c\udc51\udbb8\ude41\ud970\udd67\uda97\udd75\ud852\udd13\u3d1e\ud91c\ude6a\ud888\udc4b", "\u07a2\u99ae\uc13c\u42f8\u361e\u4056", "\udb13\udd0b\ud959\udc53\udb06\ude57\udadc\uddf4\ud9a6\uddf1\udbfe\ude6c\ud898\udea6\ud86f\udc9d\ud90b\udd13\ud84c\udd9b\udb8c\udf20\ud8a8\udefc\udabe\udce7",
        36, 18526, 188792036, 7965061893494162149L, 62319L, false, false, (char) 33432, (char) 11799,
        Double.longBitsToDouble(0x3fe99cefe4c278beL), Double.longBitsToDouble(0x3fbf23591df130b8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 15, 15, 14, "\ud896\udf02\ud9c0\udf8e\udb20\udc0f\udba9\udfed", "\u6776", "\udae2\udc7c\ud856\udf35\uda68\udc4c\ud96f\udfab\ud8e4\ude52\udb4c\udcea",
        47, 90312, -1112197781, -4490826815043597149L, -26867L, false, false, (char) 44025, (char) 1793,
        Double.longBitsToDouble(0x3fe29863125226faL), Double.longBitsToDouble(0x3fc285ee51e461c4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 12, 12, 6, "\ud879\udef9\u5399\udb7a\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\ud85d\ude20\udbec\udd6f\ud8ba\udfbd\ud889\udfb0\uda6c\udf6f\ud96a\udc33", "\u37ce\u5b01\ucf22\u4305\u66a2\u07a2\u795a\u0cb1\u0ab5\u361e\ua2e5\u57c9\uab6e\u0f0e\ud42e\u1e97\u01f2\u631a\u56d5\u70c0\u8528(\u7ffe", "\udb9e\ude4f\uda30\udc88\udb69\udd3f\ud877\udea3\u084b\uda41\udec8\uda8c\udfe0\uda51\udd11\ud90b\udf3e\udb66\udcbc\ud989\udf81",
        2, 82863, -1815091202, 4883952835254853904L, -84976L, false, false, (char) 20783, (char) 49157,
        Double.longBitsToDouble(0x3fe15b99bcc80d96L), Double.longBitsToDouble(0x3fdf9b55cc2632c8L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.CategoryPlot:@?\0121=void |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 15, 15, 3, "\ud896\udf02\ud9c0\udf8e\udb20\udc0f\udba9\udfed", "\u6e75", "\udae0\ude2a\ud909\udcae\uda22\udfa7\udb40\uddc1\udab9\udc88\ud986\udce7",
        47, 90312, 2092250475, 7116972830175793336L, 89011L, false, false, (char) 44025, (char) 1793,
        Double.longBitsToDouble(0x3fe29863125226faL), Double.longBitsToDouble(0x3fc285ee51e461c4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 16, 5, "\ud879\udef9\ud9c0\udf8e\udb4d\udee5\udba9\udfed\ud86b\udcd9\uda46\udf91\udac8\uddb4\ud954\udfab\ud8e8\ude09\uda02\udc2d\uda57\ude64\ud96a\udc33\udbd2\udc5f\udac4\udd91\ud800\udd15\ud91c\ude6a\ud888\udc4b", "\u0765\u99ae\uc13c\u42f8\u361e\u9b38", "\udbc5\ude84\uda27\udf3a",
        16, 14243, -412088265, 6001473248952397768L, 78875L, false, true, (char) 31693, (char) 26666,
        Double.longBitsToDouble(0x3fcd3c426129cec0L), Double.longBitsToDouble(0x3fd49dc2a1b67fe6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.plot.CategoryPlot|getDomainAxisIndex|org.jfree.chart.axis.CategoryAxis|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|getRangeAxisIndex|org.jfree.chart.axis.ValueAxis|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addAnnotation|org.jfree.chart.annotations.CategoryAnnotation|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addDomainMarker|int,org.jfree.chart.plot.CategoryMarker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addDomainMarker|org.jfree.chart.plot.CategoryMarker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addDomainMarker|org.jfree.chart.plot.CategoryMarker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addRangeMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|addRangeMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|calculateAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|calculateDomainAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.AxisSpace|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|calculateRangeAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.AxisSpace|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearAnnotations||new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearDomainAxes||new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearDomainMarkers||new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|clearDomainMarkers|int|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|getDomainAxisIndex|org.jfree.chart.axis.CategoryAxis|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|getRangeAxisIndex|org.jfree.chart.axis.ValueAxis|new:org.jfree.chart.plot.CategoryPlot:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
