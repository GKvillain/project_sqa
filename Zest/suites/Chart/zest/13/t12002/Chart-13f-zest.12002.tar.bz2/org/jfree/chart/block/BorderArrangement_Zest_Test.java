package org.jfree.chart.block;
import org.junit.Test;
import static org.junit.Assert.*;
public class BorderArrangement_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ubb8c\u5da3\u2601\u929d\u0585\u3d3e\ucda2\u2cde", "\uda7f\uded2\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, 637365245871489335L, 15485L, true, false, (char) 45061, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u996d\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ubb8c\u5da3\u2601\u929d\u0585\u3d3e\ucda2\u2cde", "\uda7f\uded2\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, 637365245871489335L, 15485L, true, false, (char) 45061, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\u8194\u5a1d\u2d0c\ub9ee\u43a3\u3e5b\ud37f\u6c20\u6416\u3141\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ubb8c\u5da3\u2601\u929d\u0585\u3d3e\ucda2\u2cde", "\ud98f\udf5a\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, -8513949199088955265L, -52451L, true, true, (char) 60068, (char) 1583,
        Double.longBitsToDouble(0x3fd6ebcaab287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\ud84b\udcff\uda90\uddd4\ud9d0\udc39\u8b73\udb04\udca1\ud85c\udf7e\uda6f\ude4d\ud9b8\udc37\ud87e\udf24\udbdf\udee5\u818c\uda7e\udf99\uda32\udc79\udb61\udc70\ud894\udca7\udb0c\udd0e\udb4f\udfe0", "\ub2d2\u9204", "\uda69\udffe\ud844\udf11\ud9ad\ude33\udaa4\udf0c",
        15, 22370, 1394698722, -895576369816065619L, -64427L, true, false, (char) 18300, (char) 60072,
        Double.longBitsToDouble(0x3fc70b79b2b941f4L), Double.longBitsToDouble(0x3fe83b490ae5cfcdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73\udb04\udd54", "\u1575\u5286\u0164\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8", "\ud801\udf2e\ud88b\ude53",
        9, 95877, 1290478459, -3872480388781925114L, 21338L, true, true, (char) 11155, (char) 39309,
        Double.longBitsToDouble(0x3fddb4a88210bfc2L), Double.longBitsToDouble(0x3fd0bda8691287feL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\u3606\u0102\ud2d4\u8236\u6c20\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ubb8c\u8a60\u5897\u9250\u0585\u3d3e\ucda2\u2cde", "\ud8c1\udc25\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, -2879946064634590403L, 31504L, true, true, (char) 33580, (char) 6175,
        Double.longBitsToDouble(0x3fa9a8403d4b7b80L), Double.longBitsToDouble(0x3fd78e4b48aa90c2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\udabc\ude8c\udacc\udfed\udba6\udea3\udb70\udce5", "\u1f5a\u5a1d", "\ud862\udc37",
        7, 61204, 1468386405, -8405143700994469981L, 30424L, true, true, (char) 55982, (char) 53288,
        Double.longBitsToDouble(0x3fce994e913684c0L), Double.longBitsToDouble(0x3febd908eb43e911L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\ud84d\udf88\udad4\udda8\ud9d0\udc39\u8b73\udb04\udd54\ud85c\udf7e\uda6f\ude4d\ud9b8\udc37", "\u2963", "\ud986\udd8d\udac3\udcb8\udb0c\udd0e",
        43, 91592, 1234104249, 7398729332861200763L, 48403L, true, true, (char) 16992, (char) 60864,
        Double.longBitsToDouble(0x3fe51c57e2fa05ceL), Double.longBitsToDouble(0x3febee9549e2c1b0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 8, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73\udb04\udd54\ud85c\udf7e\uda6f\ude4d\ud9b8\udc37\u4b10\ud8ff\uded5\ud862\udc37\udbff\ude2e\uda32\udd19\ud986\udd8d\ud8bb\udf76\udbdf\udc97\ud9e5\udc12\ud9dc\udf3a", "\u9204\u2895\ubb8c\u5da3\u2601", "\u704e\udbba\udfd0\udbf3\udecd\ud99c\ude6d\ud9d4\udf81\uda7f\uded2\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb85\udc77\uda4f\udfd2",
        -2, 45861, 1622093509, -1298451854193565616L, 77371L, true, true, (char) 48426, (char) 45061,
        Double.longBitsToDouble(0x3fd8fefd1adceb7cL), Double.longBitsToDouble(0x3fd943a8b866a100L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 9, 0, 0, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\000\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ubb8c\u5da3\u2601\u5678\u2ee1\u3d3e\ucda2", "\ud9d4\udf81\uda7f\uded2\udb62\udd0c\uc289\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65\ud980\udf07\uda73\udc77\ud85f\udfdb\ud9a4\udcd5\udbdf\udfd5\uda8e\udfca\udb26\udff8\udb52\uddbb\udb97\udd5b\ud95c\udc7f",
        -5, 61332, 0, 2472128561416828256L, -12252L, false, false, (char) 58504, (char) 49294,
        Double.longBitsToDouble(0x3fed2e86dd1e24f3L), Double.longBitsToDouble(0x3fb34e5436bb2d40L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\ud9ee\udf77\udaf9\udf53\000\000", "\ua559\u00a1\000\u3213\u24ff\000\u73d3\u6c20\u6416\u0c37\000\000\u5f2d\u1905\u9204\u2895\ubb8c\u5da3\u1f30\u3c25\u0585\u3d3e\ucda2", "\ud9d4\udf81\uda7f\uded2\udb62\udd01\uda0e\ude97\uda3d\udc9e\udbdc\udd6d\ud904\udd76\udbf7\udcaf\udb74\udc2f\uda4f\udfd2\udaf2\udc65\ud980\udf07\uda73\udc77\ud85f\udfdb\ud9a4\udcd5\udbdf\udfd5\uda8e\udfca\udb26\udff8\udb52\uddbb\ud959\ude5c\ud923\udf7f",
        -5, 88428, 12119091, -2101558337475759735L, -65865L, true, true, (char) 45821, (char) 56780,
        Double.longBitsToDouble(0x3feba7dd75d9f358L), Double.longBitsToDouble(0x3fe51278ec4f681aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 8, "\uda12\udec2", "\u5fd0\u0119\u8ccf\ua559\u5a1d\u2d0c", "\u295f\uda56\ude2d\ud986\udd8d",
        -3, 35347, 312309448, -6589331986701160519L, -72997L, false, false, (char) 23933, (char) 58519,
        Double.longBitsToDouble(0x3fe27a608d4d50bdL), Double.longBitsToDouble(0x3fe51c57e2fa05ceL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 8, "\uda12\udec2\udabc\udd54\ud9d0\udc39\ud980\udc72", "\ua559\u5135\ud52c\u3606\u2963\u21a4\ud37f\u6c20\u6416\u0c37\u532b\u4116\u7747\u7b6c\u5fcc\u17b2\u6f11\u7eda\u2601\u929d\u0585\u74a5\ucda2\u2cde\u0e5f", "\uda04\udfc4\ud843\udcf7\uda61\udd24\udbdc\udd6d\ud904\udd76\ud889\udc98\udb74\udc2f\uda4f\udfd2\udaf2\udc65\uda8a\ude6d\uda73\udc77\ud85f\udfdb\ud968\udcd7\udbdf\udfd5\uda8e\udfca\udb26\udff8\udb52\uddbb\udb97\udd5b\ud95c\udc7f\ud8ac\udce1\ud9f6\ude52\uda35\udff0\udbbe\udeb9\ub076\uda49\udd38\ud924\uded6\ud93b\ude48\ud8fc\udd0a\udbf5\udd2b\udac4\ude47\udaa0\udcdf\ud9a7\udc27\udaed\uddf9\udae0\udf4a",
        7, 58437, -640604796, -5879509142492461562L, -53369L, true, true, (char) 28098, (char) 23445,
        Double.longBitsToDouble(0x3fa944420ea420a0L), Double.longBitsToDouble(0x3fe49bb8afe07985L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 4, 6, "\ud92c\udfc1\udabc\udd54\u8cc3\000", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\000\000\000\000\u27a1\ubb8c\u5da3\u2601\u929d\u0585\u3d3e\ucda2\u2cde", "\uda7f\uded2\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, 637365245871489335L, -99971L, false, false, (char) 45493, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 9, 9, 6, "\ud9f9\udcc2\udabc\udd54\ud9d0\udc39\u8b73", "\u6c2a\u18e7\u9225\u3606\u2963\ud2d4\u99ac\u6c20\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\u2713\u835c\u2601\u929d\u0585\u3d3e\ucda2\u2cde", "\uda7f\uded2",
        45, 89673, -962359162, 6614983032920937656L, -68502L, true, false, (char) 20828, (char) 20154,
        Double.longBitsToDouble(0x3fe62b230ceb60afL), Double.longBitsToDouble(0x3fe2c2ed793708d8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 1, 4, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u54f5\u70ae\u9204\u2895\u99d9\u8235\u2601\u929d\u6a99\u3d3e\ucda2\u2cde", "\uda7f\uded2\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb29\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, 637365245871489335L, 15485L, true, false, (char) 45061, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\0121=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 9, 5, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\004\u8d1f\u3065\u929d\u0585\u3d3e\ucda2\u2cde", "\uda7f\uded2\udb62\udd0c\u06d2\ud8a9\udeaf\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, 637365245871489335L, 19905L, false, false, (char) 3072, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 6, "\uda12\udec2I\000\u8ad9", "\u02cf\u5a1d", "\000",
        -5, -1000, 0, 404488192L, 30424L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e493d3044000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 7, 9, 1, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73\udb04\udd54\ud85c\udf7e\ud831\udf4e\ud9b8\udc70\u4b10", "\ud2d4\ud37f\u6c20", "\udb4f\udfe0\ud978\udc14\udae9\udc0e\ud801\udf2e\ud88b\ude53\uda6e\udf5d\uda57\ude40\uda69\udff6\ud844\udf11\uda9b\ude67\uda5b\udefa\u704e\udbba\udfd0\udbf3\udecd\ud99c\ude6d\ud9d4\udf81\uda7f\uded2\udb62\udd0c",
        33, 68838, 1540170757, 5799814675598265518L, -88453L, true, true, (char) 20154, (char) 37670,
        Double.longBitsToDouble(0x3fcd6c15e143b7e8L), Double.longBitsToDouble(0x3fda5ff4f9b6e0b2L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 0, 0, "\uda12\udec2", "\u15df\u0119\u8ccf\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u6c20", "\udb32\udd18\ud978\udc14\udae9\udc0e\ud801\udf2e\ud88b\ude53\uda6e\udf5d\uda57\ude40\uda69\udff6\ud844\udf11\udb85\udd5b\uda5b\ude57\u704e\udbba\udfd0\udbf3\udecd\ud99c\ude6d\ud8ba\udf74\uda7f\uded2\udb62\udd0c",
        33, 12366, 1540170752, 5764630303509433518L, 96608L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e043b4000000000L), Double.longBitsToDouble(0x3fab846c40000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 9, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a0d\u2d0c\u3606\u2963\u9cfc\uc8e7\u6c20\u6416\u0c37\u0cd8\u4116\u15df\ub2d2\u9204\u50aa\u3cec\u0a8a\u2601\u929d\u0585\u3d3e\ucda2\u2cde", "\uda18\udc1e\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d",
        34, 70654, -808613113, -3756051684663655043L, -28656L, false, true, (char) 47167, (char) 9362,
        Double.longBitsToDouble(0x3fe2cc3688b201b5L), Double.longBitsToDouble(0x3fd23a4efadcea38L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\udbf9\uddf4\uda8b\ude1c\ud865\udc3c\uda4a\ude2b", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ubb8c\u29d7\u2666\u7d3c\u8f3e\u7d71\u1816\u2cde\u0e5f\ud77d\uc49d", "\udb00\udd53\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65\ud980\udf07\uda73\udc77\ud85f\udfdb\ud9a4\udcd5\udbdf\udfd5\uda8e\udfca\udb26\udff8\udb52\uddbb\udb97\udd5b\ud95c\udc7f\ud8ac\udce1\ud9f6\ude52\ud9e7\udf04\udac7\ude96\udb9d\udf8e\udbc8\udfa0\ud99f\ude5a\ud832\udf6b\uda46\uddfc\udb4c\udd01\uda10\ude6e\ud9a3\udddc\ud8a3\udfc5\udb65\udcb2\ud8e3\udc33\udb22\udc3c\udb90\ude4b\ud97b\uddab\udaae\ude3b\udaef\udf16\uda09\udfe2\ud93d\udc0d\udbc6\udcfc\uda5a\uded8\udb71\udfbf\udb88\udcb5\udaf4\udcbf\udabe\udd71\ud8ab\udc37\uda27\ude39\ud8e5\udc99\ud976\udfbe\uda08\udc58\ud81a\udd59\udac9\ude2c\udb4b\udfb6\ud8a2\ude93\ud887\udcce\ud9c7\udc58\udbf8\ude59\ud872\udea9\udaaf\uddda\ud90e\udfc5\udbbb\udd46\udb8c\udf96\uda22\udf10\udb8c\ude31\ud985\ude77\ud8ce\udc7a\ud987\uddc6\ud8cb\udd10\udbfc\udfc6\uda86\udeb0\udbe3\udf33\uda8c\ude0a",
        14, 19766, 1515376098, -542739037326320872L, -3585L, false, true, (char) 9172, (char) 62661,
        Double.longBitsToDouble(0x3fed8564359db2abL), Double.longBitsToDouble(0x3fe26febb06d1ad6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 8, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\udb66\udf6f", "\u8446\u5a1d\u2d0c\u3606\ub66b\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ubb8c\u5da3\u2601\u929d\u0585\u3d3e\ucda2\u2cde", "\ud8b2\ude22\ud9a8\udc2b\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\uda75\udd9f\ud87f\udc8a\uda4f\udfd2\udaf2\udc65",
        41, 10109, -314539029, 5278391732093754164L, 31504L, true, true, (char) 42707, (char) 6185,
        Double.longBitsToDouble(0x3fa9a8403d4b7b80L), Double.longBitsToDouble(0x3fdf62299e252df4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 8, 7, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u75f7\u73d2\uc473\u0426\u0ab6\u21c6\u6c20\u346c\u0c81\u0cd8\u4116\u76e7\ub2d2\u9204\u2895\ua756\u8310\u44b5\ua261\u0585\u77f7\u0fb4\u6355\u0e5f\ud77d\u95f1", "\uda61\udd24\udbdc\udd6d\ud904\udd76\udaee\udc2b\uda00\udd03\udb54\udc06",
        55, 45861, 787455933, -1298451854193565616L, 77371L, true, true, (char) 50151, (char) 45061,
        Double.longBitsToDouble(0x3fd04ccd139a5b0cL), Double.longBitsToDouble(0x3fedb2cd5cf5b170L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 6, "\ud90d\udc15", "\u15df\u0119\u8ccf\u8194\uab3c", "\ud8df\udfaf",
        38, 61228, 746966117, -8405143703488154409L, 30424L, true, true, (char) 55982, (char) 53288,
        Double.longBitsToDouble(0x3fce994e913684c0L), Double.longBitsToDouble(0x3febd908ee4f4c11L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\ud88e\udd8b\udb04\udd54\udab9\udd06\uda2f\udcb4\ud9b8\udc37\u4b10\ud818\udc44\ud996\udfd2\ud90a\ude35\uda32\udd19\ud986\udd8d\ud8bb\udf76\u391f\ud9f9\udf4c\ud927\udeae\udae9\udc0e\ud801\udf2e\ud88b\ude53\uda6e\udf5d\uda57\ude40\uda69\udff6\ud844\udf11\udaa2\udccb\uda5b\udefa\udac4\ude21\udbad\udf1c\udbf3\udecd\ud9c6\udf22\ud9d4\udf08\udb61\udf22", "\uc489\u98d2\u7c3a\u321b\u51e7\u0f31\u2ccf\u25eb\u395c\u838f\u4446\ua638\uc233\u121b\u8a84\u0513\u0aae\u11ed\ua4fd\u0689\ub68c\u8d22\ube8c\u5c66\u3425\u0bcc\ud591\uceaa\uac21\u2496\ua415\u4499\u9f3e\uadd4\u811d\u336c\u0453\u8350\u5b06\u4fda\u25e0\ud2fd\u1d74\u8b37\u9c44\u29d5\u3872\u44fc\u9c33\u4464\ud182\u9c31\uc135\u41f3\u570e\u7f33\u79b1\u86d3\ua5a0\u1efe\ub1b1\u8687\u6068\uafea\u5019\u9b65\u48e2\u582d\u6266\u1961\u346f\uc23c", "\udb57\udccf\ud982\udfdf\udb1e\udfd0\ud864\udf67\ud8ff\udeb7\ud8ea\udd56\ud8d4\udde4\ud903\udc39\udb9c\udc5c\ud998\udd6e\ud871\udcfb\uda74\udfd5\uda8b\ude80\ud912\udd4d\ud86d\ude7b\uda1e\udf21\udb5f\udd68\ud8df\udfb3\udacf\udffd\ud8da\udd16\ud9e2\udcbf\ud9e5\udff2\uda48\udf66\uda30\ude4a\ud80d\udd30\udbdd\udd75\uda2c\ude02\uda68\udf06\ud911\ude3b\ud964\udce2\ud886\udd6f\ud8af\udfb9\udb65\udebe\udaea\udda1\udac5\udf3f\ud88c\uddd1\udb06\udf3a\udb43\udf98\ud8e6\udfb7\ud813\udca2\udb21\udf83\udbfb\udc86",
        3, 80603, -677245296, -6205384169920944632L, 19642L, false, false, (char) 58502, (char) 45431,
        Double.longBitsToDouble(0x3f92cf55a8a22c80L), Double.longBitsToDouble(0x3fe7aecfce90221cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\0121=new org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 9, 9, 6, "\ud84b\udcff\uda90\uddd4\ud9d0\udc39\u8b73\udb04\udca1\ud85c\udf7e\uda6f\ude4d\ud9b8\udc37\ud87e\udf24\udbdf\udee5\u818c\uda7e\udf99\uda32\udc79\udb61\udc70\ud894\udca7\udb0c\udd0e\udb4f\udfe0", "\ub2d2\u1f05", "\uda69\udffe\ud844\udf11\ud9ad\ude33\udaa4\udf0c",
        15, 22370, 1394698722, -895576369816065619L, -64427L, true, false, (char) 18300, (char) 60072,
        Double.longBitsToDouble(0x3fc70b79b2b941f4L), Double.longBitsToDouble(0x3fe83b490de5cfcdL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 6, "\ud84b\udcff\uda90\uddd4\ud9d0\udc39\u8b73\udb04\udca1\ud85c\udf7e\uda6f\ude4d\ud9b8\udc37\udb75\udc20\udbdf\ude9a\u818c\uda7e\udf99\uda32\udc79\udb61\udc70\ud894\udca7\ud9ab\udc3d\udb3e\udc2a", "\ub2d2\u4547", "\uda69\udffe\ud844\udf11\ud9ad\ude33\udaa4\udf0c",
        15, 25186, 1394698722, -895576369816065619L, -64427L, true, false, (char) 18300, (char) 60072,
        Double.longBitsToDouble(0x3fc70b79b2b941f4L), Double.longBitsToDouble(0x3f7da48573c30280L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 4, "\ud84b\udcff", "\000J\u8090\ua200\000\000\000\000\000\000\u4357", "\000",
        -5, 23880, 0, 0L, -34464L, true, false, (char) 0, (char) 24529,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcc400000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\0121=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 8, 5, 8, "\udbc0\udf05\uda90\uddd4\ud9d0\udc39\u8b73\udb04\udca1\ud85c\udf7e\uda4d\ude82\ud9b7\udfc5\ud87e\udf24\udbdf\udee5\u818c\uda7e\udf99\udb9b\udf96\udb61\udc70\ud894\udca7", "\u4116", "\udafd\udc20\uda6e\udf5d\uda9e\udda6\uda69\udffe\ud844\udf11",
        57, 84514, 1996516295, -4490077479790089758L, 85939L, true, true, (char) 53899, (char) 1672,
        Double.longBitsToDouble(0x3fc0d6ded0171a8cL), Double.longBitsToDouble(0x3fc70b79b2b879f4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\000", "", "",
        17, 52674, -687865695, 1815814489211338928L, -57318L, false, true, (char) 59591, (char) 81,
        Double.longBitsToDouble(0x3fed1c5806c8181cL), Double.longBitsToDouble(0x3fd78129df73491aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 1, 8, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua5c7\u5a1d\u2d0c\u3606\u0102\ud2ae\u8236\u6c20\u6609\u0c37\u3060\u40d5\u76e7\ub2d2\u9204\u2895\ubb8c\u8a60\u5897\u8ddf\u0cab\u3d3e\ucda2\u2cde", "\uda0c\udcc5\udb62\udd0c\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\ud853\udcf3\udab0\udef7",
        41, 32509, -302319381, -2879946064634590403L, 31504L, true, true, (char) 33580, (char) 6175,
        Double.longBitsToDouble(0x3fa9a8402d4b7b80L), Double.longBitsToDouble(0x3fda9dfd48aa90c2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 1, 6, "\ud92c\udf76", "", "\ud85c\udf7e",
        31, -1000, 0, 0L, -100000L, true, false, (char) 17883, (char) 23293,
        Double.longBitsToDouble(0x3f181c0000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 1, "\ud92c\udfc1\udabc\udd54\u8cc3\udbb5\udd3a", "\ua599", "\udb9e\udd48\ud862\udc37\udbff\ude2e\uda32\udd19\ud986\udd8d\ud8bb\udf76\udb0c\udd0e\udb4f\udfe0\000\000\000\000\uda6e\ude69\ud905\ude20",
        12, 5094, -1963156147, 418463829734314746L, -99970L, false, true, (char) 11042, (char) 59722,
        Double.longBitsToDouble(0x3fd0bda8651287feL), Double.longBitsToDouble(0x3fcb16ded0171a8cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 9, 1, 6, "\ud9f9\udcc2\udabc\udd54\ud9d0\udc39\u8b73", "\u6c2a\u18e7\u9225\u3606\u2963\ud2d4\u99ac\u6c20\u6416\u0c37\u0cd8\u2016\u76e7\ub2d2\u9204\u2895\u2713\u835c\u2601\u929d\u0585\u3d3e\u6801\u2cde", "\uda7f\uded2",
        45, 89673, -962359162, 6614983032920937656L, -68502L, true, false, (char) 20828, (char) 20154,
        Double.longBitsToDouble(0x3fe62b230ceb60afL), Double.longBitsToDouble(0x3fe2c2ed793708d8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 7, 7, 6, "\uda56\udcb7\udabc\uddac\ud84a\uddf6\ud807\ude64", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u54f5\u1405\ua216\u4618\u4b28\u180c\ud1e6\u929d\u6a99\u3d3e\ucda2\u2cde", "\uda7f\uded2\udb62\udd0c\uda4b\udf88\uba3b\uda11\udc4d\ud885\udea9\ud9e3\udfa6\udb8d\udeb3\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, 637365244740670519L, 46659L, true, true, (char) 38519, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fe19a8403e32117L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73\ud9b0\ude6b", "\u01fb\u4e4b\u3606\u2963\ud2d4\ud37f\u6c20", "\ud89e\udcd4",
        2, -71, 1722633981, -3858343005338439436L, 37203L, true, false, (char) 21992, (char) 14736,
        Double.longBitsToDouble(0x3fd3abdca99d04beL), Double.longBitsToDouble(0x3fde2698ec12a708L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 1, 5, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\u682a\u598c\u2d0c\u3606\u074e\u5b3f\u386b\u8a3b\u6416\u0c37\u0cd8\u4116\u76e7\ub2d2\u9204\ucd62\004\u8d1f\u3065\u929d\u0585\u3d3e\ucda2\u2cde", "\uda7f\uded2\uda98\udd6e\udae7\udc79\ud8a9\udeaf\udbdc\udd6d\ud904\udd76\udb5a\udf8f\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, -7793373256566079105L, 19905L, false, false, (char) 3072, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fa9a8403d4aab80L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 9, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\u3638\u29b0\ud2d4\ud37f\u6c20\u6416\u0c37\u0cd8\u4116\u8f48\u6a44\u6c72\ubbb5\004\u8d1f\u3065\u929d\u0585\u3d3e\ucda2\u2cde", "\uda7f\uded2\udb62\udd0c\u06d2\ud8a9\udeaf\udbdc\udd6d\ud904\udd76\udb3b\udc91\udb74\udc2f\uda4f\udfd2\udaf2\udc65",
        41, 32509, -302319381, 637365245871489335L, 19905L, false, false, (char) 3072, (char) 53600,
        Double.longBitsToDouble(0x3fd6e75beb287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 4, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\uce05\u2963\u9b20\ud3cc\u6c20\u6416\uc010\u6b01\u11ff\u76e7\ub2d2\u8e9f\u2895\004\u8d1f\ub7e2\u041a\u0585\u3d3e\ucda2\u2cde", "\uda7f\udf07\udb62\udd0c\u06d2\ud8a9\udeaf\udbdc\udd6d\udbfc\udd35\udb21\ude2c\udb74\udc2f\uda4f\udfd2\ud9be\udd99",
        41, 32509, -302319381, 637365245871489335L, 52929L, false, true, (char) 57447, (char) 54113,
        Double.longBitsToDouble(0x3fd6e759ab287516L), Double.longBitsToDouble(0x3fa9a8403d4b7b80L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\0121=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 5, 5, 2, "\uda12\udec2\udabc\udd54\udb14\udd1b\ud8db\uded2", "\ua559\u5a1d\u2d0c", "\udbff\ude2e\uda32\udd19\ud95f\udff8",
        -3, 79595, -1338907090, -6589331986701160519L, -72997L, false, false, (char) 23933, (char) 29804,
        Double.longBitsToDouble(0x3fc7ce82b53542d0L), Double.longBitsToDouble(0x3fe51c57e2fa05ceL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 8, 1, 6, "\ud939\udeb5\udabc\uddd1\ud9d0\udc39\ud94d\udc86", "\ua559\u75f7\u73d2", "\ud971\udf97\uda6f\udf0f\udbd0\udc21",
        4, 35421, 1151170248, 419911008074526649L, 60084L, true, true, (char) 33681, (char) 41371,
        Double.longBitsToDouble(0x3fdd7e8e1aef1566L), Double.longBitsToDouble(0x3fe44ccd6086b6f6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 8, 8, 6, "\ud84b\udcff\uda90\uddd4\ud9d0\udc39\u8b73\udb04\udca1\ud85c\udf7e\uda6f\ude4d\udbd2\udfed\udb75\udc20\udbdf\ude9a\u818c\uda7e\udf99\uda32\udc79\udb61\udc70\ud894\udca7\ud9ab\udc3d\udb3e\udc2a", "\ub2d2\u4547", "\uda69\udffe\ud844\udf11\ud9ad\ude33\udaa4\udf0c",
        15, 25186, 1394698722, -895576369816065619L, -64427L, true, false, (char) 18300, (char) 60072,
        Double.longBitsToDouble(0x3fc70b79b2b941f4L), Double.longBitsToDouble(0x3f7da48573c30280L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 1, 1, 6, "\ud9f9\udcc2\udabc\udd54\ud9d0\udc39\u8b73", "\u6c2a\u18e7\u9225\u3606\u2963\ud2d4\u99ac\u6c20\u6416\u0c37\u0cd8\u2016\u7b0d\uae78\u17c2\u2995\u2713\u835c\u2601\u929d\u0585\u3d3e\u6801\u2cde", "\udae0\udc0f\udb53\udc2e\ud855\ude3b\uda61\udd24\udbdc\udd6d\ud904\udd76\ud9bc\ude6a\udbb4\udc34\uda4f\udfd2\udaf2\udc65",
        41, 32509, 1571804395, 637349886127145271L, 3339L, true, true, (char) 18856, (char) 24918,
        Double.longBitsToDouble(0x3fc33d00b8815ba8L), Double.longBitsToDouble(0x3feb51a732aaabc3L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 6, "\uda12\udec2\udabc\udd54\ud9d0\udc39\u8b73", "\ua559\u5a1d\u2d0c\u3606\u2963\ud2e9\ud37f\u6c20\u6416\u0c37\u0cd8\u6cab\u76e7\ub2d2\u9204\u2895\ubb8c\u5da3\u2601\u929d\u0585\u3d3e\ucda2\u6eec", "\uda7f\udf6b\udb62\udd0c\ud855\ude3b\ud98f\udc1b\udbdc\udda5\ub4cc",
        42, 28404, -874524121, -6224672337545812707L, -32651L, false, false, (char) 35342, (char) 9524,
        Double.longBitsToDouble(0x3fe8ebad965986eaL), Double.longBitsToDouble(0x3fe2858da98fefd1L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 9, 1, 2, "\udbf3\udd33\udb7f\udd88\ud84a\udd22\ud84e\udf12\u0ec9\ud939\udc84\udb76\udd96\ud9b8\udc37\u4b10\ud8ef\uded5\ud862\udc37\ud8e5\udd01\uda32\udd66\ud986\udd8d\udaa5\udf4b\udbdc\udcd3", "\u76e7\ub2d2\u8e9f\u2895\u689b\u8d95\ub7e2\u041a\u68ee\u4fac\ub8c1\u7728\u4ff5\u1c05", "\ud9b4\udc34\uda4e\udde0\ud8d2\udff3\udbfc\udd35\udb21\ude2c\udb74\udc2f\uda4f\udfd2\ud9de\udc99\ud980\udf07\uda73\udc77",
        34, 97096, 1884914041, 7525432354322928993L, 11327L, false, false, (char) 55755, (char) 5079,
        Double.longBitsToDouble(0x3fc715757796d7f4L), Double.longBitsToDouble(0x3fd20684ff5b2338L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.block.BorderArrangement|arrangeFF|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|add|org.jfree.chart.block.Block,java.lang.Object|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrange|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeFN|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,double|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeFR|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeNN|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeRR|org.jfree.chart.block.BlockContainer,org.jfree.data.Range,org.jfree.data.Range,java.awt.Graphics2D|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|clear||new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|equals|java.lang.Object|new:org.jfree.chart.block.BorderArrangement:",
    "C|org.jfree.chart.block.BorderArrangement|<init>|",
    "M|org.jfree.chart.block.BorderArrangement|arrangeFF|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
