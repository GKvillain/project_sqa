package org.jfree.chart.block;
import org.junit.Test;
import static org.junit.Assert.*;
public class BorderArrangement_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u1ab7\u534b\u2305\uca7d", "\uda4b\udc25\udaf6\udce0\ud872\udfed\ud92b\uddb7\udb47\udf70\udbb9\udfca",
        1, 40143, -1561247517, 7466008351793313305L, -63053L, true, true, (char) 65015, (char) 53639,
        Double.longBitsToDouble(0x3fb160fa035ebfd8L), Double.longBitsToDouble(0x3fe53fcca4fe71daL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u1ab7\u534b\u2305\uca7d", "\uda4b\udc25\udb8c\udccb\ud98e\udc34\u5a12\udb49\udcce\udbb9\udfca",
        1, 40143, -1561247517, 7466008351793313305L, -63053L, true, true, (char) 65015, (char) 53639,
        Double.longBitsToDouble(0x3fb160fa035ebfd8L), Double.longBitsToDouble(0x3fe53fcca4fe71daL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 4, "\u2743\udbb2\udd31\uda33\udeaf\udb37\udee6\ud89d\udc3a\uda39\udf98\udb88\udced", "\u469c\u1b73\u091a\u1ab7", "\udaef\udedf\ud8ff\udf22\uda08\udf15",
        3, 54795, 1595991634, -4198345344827644366L, 55689L, true, true, (char) 51593, (char) 14843,
        Double.longBitsToDouble(0x3fe0cb3ce0fa12bdL), Double.longBitsToDouble(0x3fb4c4dc457fca20L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\u4ae7\u4c88\u7653\uc26e\u469c\u1b73\u091a\u1ab7\u534b", "\ud8ff\udf22",
        34, 47073, 1367565331, 6854731871741356327L, -94831L, true, false, (char) 11233, (char) 51603,
        Double.longBitsToDouble(0x3fe855178e19679cL), Double.longBitsToDouble(0x3fe69895e85313f7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 8, 4, 2, "\u27a7\udbb2\udd31\ud85e\udc34", "\ua936\ud221\u761f\u2179\u77c7\u1398\ube68\u1eff\ub5f4", "\ud969\udcb2\udb1c\udf46\udb1c\ude1a\udae1\udf58\ud872\udfed\ud92b\uddb7\ud8dd\udf10\ud863\udfba\uda37\udef8\uda41\udec0\ud934\udd00\ud85f\udd25\ud8e9\udfa8\ud83c\ude33\udaa0\udfd0\udb9f\udc18\uda38\udf72\udb29\udd18",
        2, 95128, 713945436, -2915451357133853863L, 90736L, true, true, (char) 9372, (char) 33744,
        Double.longBitsToDouble(0x3fdb5e561dc5d4a2L), Double.longBitsToDouble(0x3feb003664a85aadL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 6, 6, "\ud8f5\ude99\udba4\udcfe\uda33\udeaf\ub6e3\ud839\udc4e\ud98c\udf5f\udbc1\udc39", "\u068f\u1b73\u091a\u1ab7\u534b\u6070", "\uda08\udf15",
        3, 24331, 1595991634, -4120598876788742606L, 55689L, true, true, (char) 51603, (char) 33019,
        Double.longBitsToDouble(0x3fe6a0d2a2e5b702L), Double.longBitsToDouble(0x3fe85120df09e454L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\ud7de\uaf1e\u761f\uc26e\u469c\u1b73\u091a\u1ab7\u534b\u2305\uca7d\uc44f\uc183\u50e4\u24af\u6ef9\u840b\u1f3e\u649e\u903e\u0477\u1a98\u19d7\ud44e\u4805\u1e88", "\udb81\udc90\ud8d0\udde9\ud84c\udc0a\udaaa\udd5c",
        22, 62380, 1853305772, -8844251307707089034L, 84259L, true, true, (char) 51768, (char) 53871,
        Double.longBitsToDouble(0x3fe15ef610b1fe30L), Double.longBitsToDouble(0x3fa309a1bd8cf180L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\ua936\ud221\u761f\uc26e\u469c\u0c0b\u0a05\u1ab7\u5447\u2305\uca7d\uc44f\uc183\u50e4\u24af\u2f11\u840b\u1f3e\u649e", "\ud8e3\udf6f\ud85f\udd8c\udad3\udf33\ud92a\ude1f\uda4c\ude8e\uda8f\udff2\ud8b7\udc91\udb82\ude3d\ud8d0\udde9\ud842\udd37\udaaa\udd5c\ud991\udefe\udaeb\udc6b\ud8bc\udde5\uc1b3\ud91c\uded8\ud8f7\ude3e\udaa5\udec3\ud95e\udca9\udb1c\udcdd\ud95c\udc97\ud89a\udd65\ud8a3\udc78\ud906\udf5d\udbed\udf32\ud915\udf24\udaf7\ude1d\ud9a4\udff9\ud8d5\udca9\ud8a0\udf4c",
        39, 88006, -2033989964, -8075064271621059092L, -55046L, false, true, (char) 24138, (char) 50955,
        Double.longBitsToDouble(0x3fcc36b228c25920L), Double.longBitsToDouble(0x3fc2405dfeb38c30L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 3, 2, "\ud822\udefd\udb90\uddd0\uda33\udeaf", "\ua936\u549f\u761f\uc26e\u469c\u1b73\u091a\u3ab7\u534b\u2305\uca7d", "\uda4b\udc25\udaf6\udce0\ud872\udfed\ud92b\uddb7\udb47\udf70\udbb9\udfca",
        1, 40143, -1772683293, 7466009313865987609L, 74284L, false, true, (char) 41005, (char) 42086,
        Double.longBitsToDouble(0x3fe53fcca4fe71daL), Double.longBitsToDouble(0x3fe642eb86e3bc02L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\ud8e6\udf4b\uda0e\udc88\uda19\udeb9", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u1ab7\u534b\u2305\uca7d", "\uda4b\udc25\udaf6\udd21\ud872\udfed\ud92b\uddb7\udb60\udc1d\udbb9\udfca",
        1, 96223, 1348867114, -8001037216115755495L, -63053L, true, true, (char) 65015, (char) 53639,
        Double.longBitsToDouble(0x3fb160fa035ebfd8L), Double.longBitsToDouble(0x3fe53fcca4fe71daL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 4, 0, "\udb66\udd6a\ud90d\ude86\ud9d3\udedc\ud891\ude05\ud89d\udc3a\uda39\udf98\udb88\udced\uada9\udb7c\udcc4\ud99a\udc62\ud984\udcc4\ud868\udf48\ud941\uddfc\ud966\udeb7\udadf\uddc5\ud9f8\udf87\ud8a4\udf6c\ud8e3\udf45\uda93\udc06\udb0d\udc71\ud872\udfed\ud8e8\ude96\udb47\udf91", "\u0477\u9b31\u19d7\ud44e", "\u240e\ud8b7\udc91\udb82\ude3d\ud8d0\udde9\ud84c\udc0a\udaaa\udd5c\ud848\udfd9\ud857\udc9b\ud957\ude1b\udaa7\udf84\udb68\udcd4\ud974\udea0\udaae\ude4a\udb70\uddcc\ud8f1\udf3a\uda43\ude48\ud966\uded2\ud86b\udcf7\udbc0\udccc",
        22, 74901, 1946641181, 8458184659784762477L, -59165L, true, false, (char) 14106, (char) 64925,
        Double.longBitsToDouble(0x3fe8cf4b3344ad47L), Double.longBitsToDouble(0x3fdbc57bcd5cbe80L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 2, "\u2743\ud850\udf60\uda33\udf18", "\ua936\ud221\u761f\uc26e\u469c\u9feb\u091a\u1ab7\u534b\u5fe9\u057d", "\ud804\udd24\udbe9\uded1\ud872\udfed\ud92b\uddb7\udb47\udf70\ud9b6\udfc9",
        3, 71114, -1570276383, 7466008351793313305L, -63053L, true, true, (char) 56914, (char) 53639,
        Double.longBitsToDouble(0x3fb160fa035ebfd8L), Double.longBitsToDouble(0x3fe53fcca4fe71daL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 2, "\u2743\udbb2\udd31\u4da0", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u1ab7\u534b\u2305\uca7d", "\ud839\udf7c\udb16\udd55\ud940\uded5\ud92b\uddb7\udb47\udf70\udbb9\udfca",
        1, 40143, -1561247517, 7466008351793313305L, -63053L, true, true, (char) 65015, (char) 41534,
        Double.longBitsToDouble(0x3fdefede890fa62eL), Double.longBitsToDouble(0x3fe53fcca4eb42daL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743\000\ud9e8\udf94", "\ubc41", "\udb7c\udcc4",
        17, 31487, -509154030, 302591909756203267L, -6986L, true, true, (char) 18628, (char) 1303,
        Double.longBitsToDouble(0x3f93d998ca4a3060L), Double.longBitsToDouble(0x3fd275f200018b62L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\ua936\ud221\u761f\u1937\u231a\u1b73\u3e4f\u1a6d\u534b\u2305\uca7d", "\udaff\udd38",
        52, 84814, -978245337, 1522821621220119601L, -3494L, true, false, (char) 12869, (char) 65015,
        Double.longBitsToDouble(0x3fd8e3f5d88b07d0L), Double.longBitsToDouble(0x3fbaf5fed53fcca0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf\udb37\udee6\ud89d\udc3a\uda39\udf98\ud858\udcf5\ud8d9\udee4\ud973\uddca\ud944\uddb2", "\u1ab7\u534b\u085b\uca7d\uc44f\uc183\u50e4\u24af\u2f11\u840b\u1f3e\u649e\u903e\u0477\u1a98\u19d7\ud44e\u4805\u1e88\u53fc\u14a0\u067b\u94d6\ua0ce\u2198", "\ud864\udd06\uda2c\udf48\u0388\uda51\ude72\udad7\udfa2\ud8b2\uddf5\ud859\uddd1\uda2f\ude18\ud90f\uddc3\ud818\udd7e\ud90e\udec1\udb8e\udeec\ud84c\udda7\ud9e3\ude99\udb4c\ude22\udbc6\ude05\ud8d3\ude42\udbc9\udc24\udac5\udd6c\ud8fe\udf20\uda1d\udc69\uda12\uddbf\uda9d\udd99\ud838\udc9d\ud9b5\udd52\udb99\udfac\uda92\udd44\ud8de\udf13\ube5b\uda7e\ude41\udaaa\udde3\udae6\udc3e\udbce\udd7e\ud99c\ude5f\udb30\udcfd",
        37, 5370, 782777557, 6094216746401222803L, 19849L, true, false, (char) 40292, (char) 16506,
        Double.longBitsToDouble(0x3febb89c1bd324f9L), Double.longBitsToDouble(0x3fb361ffd5807368L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 5, 4, 6, "\u2743\udbb2\udd31\uda33\udeaf", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u8d01\u19f9\u21bc\ucae8\uc44f\uc183", "\ud872\udfed\ud92b\uddb7\udb47\udf70\udbb9\udfca\uda37\udef8",
        35, 9483, 1738315530, 1350365314101180666L, -36759L, false, false, (char) 53639, (char) 41005,
        Double.longBitsToDouble(0x3fbaf5fed53fcca0L), Double.longBitsToDouble(0x3fcfce3b51ece4b0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 7, 4, 2, "\u2743\udbb2\udd31\udaa5\udc08", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u1ab7", "\udaef\udedf\ud8ff\udf22\uda08\udf15",
        3, 24331, 1595991634, -4201531729524939214L, 86284L, true, true, (char) 51603, (char) 14843,
        Double.longBitsToDouble(0x3fe0cb3ce0fa12bdL), Double.longBitsToDouble(0x3fb4c4dc7849d9e0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 4, 8, "\u2804\ud973\ude3c\ud8bf\udea0", "\u7a9c\u0b53\u93a0\u0f65\u2889\u1b73\u091a\uc134\u7771\u3b24\u0fc2\uc44f\uc183\u1ee4\ua763\u47c7\u4afe\ucc00\u5c42\u7a55\u9bfd\u991c\uc6ea\uc611\uaff6\u7343\uca3a\u7d60\u9cb1\ud2a7\u7ede\u38c3\u5734\ucd22\u830e\u3df5\ub54b", "\ud901\udd7d\uda7f\udedd\udad3\udd58\ud844\udfca\ud9dd\udd15\ud908\ude31\udbf7\udf4c\udabd\ude73\ud89c\udfd8\ud9e5\udcac\udafb\udd55\uda51\udc83\udbe3\uddbb\uda28\udfb5\ud9ff\uddcd\ud94d\udc01\ud86e\udcca\u5237\ud8c2\udc5b\u5ec9\ud9c3\udf71\udbf6\udd1a\udab5\udd88\ud909\udd25\ud87c\udeb8\ud931\udcda\ud9cf\ude71\ud951\udf2f",
        34, 85110, -611334991, -877739605587953942L, -12742L, true, false, (char) 39370, (char) 30365,
        Double.longBitsToDouble(0x3fdd1f742a174f76L), Double.longBitsToDouble(0x3fc74f2059022dccL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 9, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u1ab7\u534b\u2305\uca7d", "\uda4b\udc25\udaf6\udce0\ud872\udfed\ud92b\uddb7\udb47\udf70\udbb9\udfca",
        1, 40143, -1561247517, 7466008351793313305L, -63053L, true, true, (char) 46636, (char) 48856,
        Double.longBitsToDouble(0x3fb160fa035ebfd8L), Double.longBitsToDouble(0x3fe53fcca4fe71daL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 5, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf", "\ua936\ud221\u761f\uc26e\u469c\u1b73\u091a\u1ab7\u534b\u2305\uca7d", "\uda4b\udc25\udaf6\udce0\ud872\udfed\ud92b\uddb7\udb47\udf70\udbb9\udfca",
        1, 40143, -1561247517, 7466008351793313305L, -7427L, true, true, (char) 41005, (char) 2151,
        Double.longBitsToDouble(0x3fe53fcca4fe71daL), Double.longBitsToDouble(0x3fd5ea2cbe972ec6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 9, 4, 4, "\udac7\udf41\udbbc\udd36\uda33\udeaf", "\u3983\ud210\u761f\u0483\u1471\u37fa\u091a\u393c\uaf62\u9aba\u263c", "\uda66\udc3e\udaf6\udce0\ud872\udfed\udb1c\uddd3\udb47\udf70\ud89c\udc7c\udb9a\udcc8\ud84f\uded3\ud818\udf67\ud85f\udd25\udad3\udf33\ud92a\ude1f\udaa0\udfd0\u240e\ud8b7\udc91\udb82\ude3d\ud8d0\udde9\udb97\udc27\ud80b\udc9a\ud8c9\ude1b\ud8cb\uddbb\ud959\ude19\ud9ad\udd11\ud8ab\udedd\udafb\ude64",
        -2, 202, -1545709396, -5488230349996165849L, -54839L, true, false, (char) 20610, (char) 47297,
        Double.longBitsToDouble(0x3fe0eab038911702L), Double.longBitsToDouble(0x3fe8e6af63587217L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743\udbb2\udd31\uda33\udeaf\udad0\udf73\udb82\uddba\uda14\udf1b\udb88\udce7\uada9\udb7c\udcc4\ud99a\udc62\ud984\udcc4\ud868\udf48\ud8b9\udd38\udb8a\ude7a\ud93e\udeeb\udaef\udedf\ud827\udf16\uda08\udf15\ud809\udf44\udaf6\udd0c\ud872\udfed\ud92b\uddb7\udb47\udf70\udbb9\udfca\udb6e\udf14\udb9c\udc4c\ud818\udf4c\ud85f\udd25\ud91b\udcf2\ud92a\ude1f\udaa0\udfd0\u240e\ud8b7\udc91\udb82\ude3d\ud8f2\udde9\ud84c\udc0a", "\ubc49\u3411\u6d81\u3d36\u8852\u814d", "\ud822\udf0c\ud988\udc7d\ud8c0\uddbe\udb9f\udce1\udbf1\udfcf\ud9a2\ude99\udadb\udf53\uda79\udc95\ud9a8\udc77\ud99f\udca2\ud91b\uddc4\ud8af\udc53\udbfe\udeac\ud936\udd97\ud9a4\ude5c\ud8e4\uddcc\ud8ae\udd53\ud8a6\ude83\ud904\udd7c\ud919\ude42\uda2e\udd40\ud95f\ude40\u7481\ud9f2\udf00\ud802\udccf\ud854\udff1\ud8f7\ude50\udbce\udee0\uda56\ude36\ud98a\udcd1\ud9f2\udcb7\udb1b\udf49\ud8cb\udcaa\ud8b1\udd8c\udbc9\ude7f\udb5b\uddf4\ud92b\uddeb\ud92e\ude15\ud927\udfdf\ud84b\udd7c\udaaf\uddef\ud845\udd91",
        54, 15803, -131532002, -1199577368261943912L, -42476L, true, true, (char) 31661, (char) 15137,
        Double.longBitsToDouble(0x3fbff7d666783bd0L), Double.longBitsToDouble(0x3fc9f3f2ce1bdcd4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 8, 4, 2, "\ud80b\udd2f\udbb2\udd31\uda33\udeaf\udb37\udee6\ud89d\udc3a\uda39\udf98\udb88\udced\uada9\udb7c\udcc4\ud99a\udc62\ud984\udcc4\ud868\udf48\ud941\uddfc\ud966\udeb7", "\uc44f", "\ud9b2\udf3d\ud872\udfd3\ud99e\udfde\udb47\udf70\udbb9\udfca\uda37\udef8",
        -2, 9483, 1738315530, 1350365313353480442L, -36759L, false, false, (char) 53639, (char) 41005,
        Double.longBitsToDouble(0x3fbaf5fed53fcca0L), Double.longBitsToDouble(0x3fcfce3b5bd99f98L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\u2743", "\u0a9a\ua7ff\ua936\ud221", "\000",
        22, 86970, 70452669, 2084305722754394858L, 4919L, true, false, (char) 1303, (char) 55704,
        Double.longBitsToDouble(0x3fe2928c19275f20L), Double.longBitsToDouble(0x3fe1962d8c311522L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 0, "\037\000\020", "\ua936\ud221\u5e6b\u325e\u469c_\000\000\000\000\000", "\uda4b\udc25",
        36, 89634, 10535, 1522821621218284593L, -100000L, false, false, (char) 14602, (char) 56757,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 7, "\ud8f5\udf77\udbb2\udd31\uda33\udeaf\udb37\udee6\ud89d\udc3a\uda39\udf98\udb88\udced\uada9\udb7c\udcc4\ud99a\udc62", "\u1ab7\u534b\u2305\uca7d\uc44f\uc183\u50e4\u830b\u6b88\uabc0\u99c9\u1b3d\u99de\u0477\u1a98\u19d7\ud44e\u4805\u1e88\u53fc\u14a0\u067b\u94d6\ua0ce\u2198", "\udaec\uddce\udbc3\udfea\ud942\udd76\uda9d\udc9c\udbe3\uddab\uda58\ude5b\ud82f\udeb0\udab3\udec0\u1dc1\udaa5\udc08\ud9b3\udc2f\udba2\udef6",
        39, 32819, -2104060755, -4208992196473374271L, -65887L, false, true, (char) 53419, (char) 16431,
        Double.longBitsToDouble(0x3fcf2791ad521e84L), Double.longBitsToDouble(0x3fefc1fb396ee3e1L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 2, "\u2743\udbb2\udd31\uda7e\udd74", "\ua936\u97a5\u435b\u26fb\u88cf\u81fb\u09bf\u1ab7\u9b41\u7509\u2386", "\ud896\udf4b\ud8b8\udf0a\ud98e\udc34\ud81f\udeb6",
        22, 21177, 1607601961, -2428284324513680355L, 25099L, true, false, (char) 41923, (char) 41866,
        Double.longBitsToDouble(0x3fc997798c506be8L), Double.longBitsToDouble(0x3fb160fa1fbd3bc0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 0, "\u2743\ud8f6\udd33\ud8e7\udc30\udb97\udffe\ud89d\udc26\ud857\udd8f\u1a1a", "\u3103\u1b88\u091a\u1ab7", "\udaef\udedf\ud8ff\udf22\uda08\udf15",
        3, 54795, 1595991634, -4198345345230297550L, 55689L, true, true, (char) 39049, (char) 14732,
        Double.longBitsToDouble(0x3fe0cb3ce0fa12bdL), Double.longBitsToDouble(0x3fb4c4dc457fca20L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\0121=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 8, 5, 1, "\ud882\ude84\udbc4\udd52\ud803\udc76", "\ua936\ud221\u761f\u91d4\u469c\u1b73\u091a\u1ab7", "\ud8b1\udfe0\udbb6\udfbf\udb44\udcc3",
        49, 54795, 1595991634, -4198401419920660942L, 44907L, true, true, (char) 25510, (char) 46419,
        Double.longBitsToDouble(0x3fd68ecfd1f4257aL), Double.longBitsToDouble(0x3fb4c4dc5d7fca20L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 7, 7, 8, "\u2743\udbb2\udd31", "\u2b81\uaa80\u202b\u6e04\ucb42\uca39", "\ud941\udd8e\ud966\udeb7\udbce\udef3\udaef\udedf\u3eee\udb2f\udf84\uda4b\udc25\udaac\udd2c\u2e42\udbff\udfb7",
        2, 99353, -338528983, -8597140931366272807L, -63053L, true, false, (char) 51399, (char) 30784,
        Double.longBitsToDouble(0x3fe4f7ba5139a9e1L), Double.longBitsToDouble(0x3f8d312b9423e280L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 1, "\ud9e7\udcd7", "\u0a9a", "\udb7c\uddf9\uae8e\udb70\udc2a\ud99a\udc62",
        22, 86970, 70452669, -4464168926693953122L, 63856L, true, false, (char) 1303, (char) 19115,
        Double.longBitsToDouble(0x3fe6e32583275f20L), Double.longBitsToDouble(0x3fe1962de4311522L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 7, 0, 2, "\ud816\udee4\udb5c\udf4f\ud955\udc4a", "\u779a\ud20b\u761f\u2179\u77c7\u1398\ube68\u1eff\u4c13\u56f4\u8d42\u7acc\ubd56", "\ud86f\udc97\ud92b\uddb7\ud8dd\udf10\ud863\udfba\uda37\udef8\uda41\udec0\ud934\udd00\ud85f\udd25\ud8e9\udfa8\ud83c\ude33\ud89e\udd6c\udb69\udc0f\uda38\udf72",
        50, 19667, 59383128, -5664025109067623883L, 13787L, false, false, (char) 33744, (char) 27657,
        Double.longBitsToDouble(0x3fe71756076006ccL), Double.longBitsToDouble(0x3fc50b55a9595a78L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 2, "\uda60\ude73\uda09\udfbc\udba5\uddb9", "\ua936\ud221\u761f\ua5ea\u198a\u1398\ubdeb\u9a61\u1349\u3c5a\u0269\u7a81\uaccf\u8bcd", "\udae9\udd4e\udaf4\udf7b\ud863\udfba\uda2f\udff8\uda41\udec0",
        33, 52274, -2038404410, 3206401921652658202L, -56788L, true, false, (char) 41326, (char) 42017,
        Double.longBitsToDouble(0x3fd5c038a1304ebaL), Double.longBitsToDouble(0x3feac8f6f7d3fa1bL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 1, 2, 9, "\u27a7\udbb2\udd31\ud85e\udc34", "\ua936\ud221\u761f\u2179\u77c7\u1398\ube68\u1eff\ub5f4\u3c5a\ub9b4\u7a81\u5f0d\u67ce", "\ud92b\uddb7\ud8dd\udf10\ud8be\udda8\udadc\udc2a\uda41\udec0",
        33, 3530, -1735627327, -8742945858942889858L, 82751L, true, false, (char) 51817, (char) 51286,
        Double.longBitsToDouble(0x3fd5c038a819d908L), Double.longBitsToDouble(0x3feacebc53d3fa1bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 8, 4, 2, "\u27a7\udbb2\udd31\000", "", "",
        -5, -1000, 13784064, 171013639221850975L, -33131L, true, false, (char) 30776, (char) 1487,
        Double.longBitsToDouble(0x3fca6ed9ce1ca670L), Double.longBitsToDouble(0x3fe45b7cde525183L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 8, 9, 4, "\ud822\udefd\udb90\uddd0\uda33\udeaf\udb37\udee6\udb6f\udc43\uda39\udf98\udbbd\udeb5\uada9\udb7c\udcc4\ud99a\udc62\ud984\udcc4\ud868\udf48\udaaf\udf93\ud966\udeb7\ud93e\udeeb\udaef\udedf\ud8ff\ude7c\uda08\udf15\uda4b\udc25\udaf6\udce0\ud872\udfed\ud92b\uddb7\udb91\udff5\udbb9\udfbb\uda37\udef8\uda22\udd55\ud853\ude26\ud85f\uddb0\udad3\udf33\udb3d\udfa4\udaac\udc08\u240e\ud8b7\udc91\udb82\ude33", "\u2198\u5bbc\u8232\u4c14\ubf2a\u3d3f\ubfa4\u8e2b\u2a00\u7b80\u46c5\u988b\uc8c1\u8a5d\u1d6f\ud028\u3b1d\uc70a\ubcb6\u74c7\u199b\u1074\u2f63\u722f\u7ce3\u6fdb\u8797\u5502\u3662\u2fb4\ud3e1\ubbd4\u476d\u5086\u9955\u2c6d\u7439\u407b\u5945\uac4f\u9752\u8cd6\u0e63\u4ce2\u2f51\ub311\u93bb\u381d\u7639\ua573\u9022", "\udbe8\udd95\ud8c3\udd8c\ud8d8\udeee\ud835\ude24\udae0\udfa0\ud945\udf4f\udb6e\uddbd\udbe2\udf96\ud81c\udf1f\uda94\ude04\uda2e\ude0a\ud83e\uddcd\uda16\udd9c\udbd8\ude5a\ud853\udcd7\udb4f\udcc5\ud8ed\udc12\udb6a\udd84\udada\udf4d\udbed\udd93\ud9fd\udddf\uda7c\udf1d\ud874\uddbc\uda52\udfef\ud911\udfc5\uda83\ude9f\udb14\udf08\ud80f\ude32\udb7a\udfea\uda40\uddd3\ud885\uddc6\uda79\udd55\uda33\ude3b\udb2c\udd50\udb20\udedc\uda93\uddf2\udb18\udf1a\uda34\udc54\udaf8\udc7a\ud8e4\udee3\ud8fd\udee9\ud8b6\udc2b\udbcc\udf87\ud91c\udc99",
        21, 4208, 1996910749, -2504661154263873910L, 22716L, false, false, (char) 18554, (char) 2782,
        Double.longBitsToDouble(0x3fe994a976c1df9cL), Double.longBitsToDouble(0x3fced7dfa0fd0aa8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 5, 1, 2, "\ud822\udefd\udaa2\uddd9\uda33\udeaf", "\ua936\u549f\u761f\ua107\ub9e1\ub892\u66a1\u3ab7", "\ud9df\uddca\ud8ff\ude99\uda08\udf15",
        3, 24331, 1595991634, -5138280452634250537L, 6455L, true, true, (char) 34963, (char) 11840,
        Double.longBitsToDouble(0x3fe0cb3ce65312bdL), Double.longBitsToDouble(0x3fea585527093b3cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\uda06\udc21", "", "",
        -5, 77064, -117440498, 1056561954816L, -100000L, false, false, (char) 0, (char) 20736,
        Double.longBitsToDouble(0x3fe3496c79ba78b8L), Double.longBitsToDouble(0x3fe77aceae00005dL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 0, "", "", "\000",
        -5, 77064, -112273906, -7570974328536112494L, 31072L, true, false, (char) 1024, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcde00000000000L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 1, 9, "\u2743\ud880\udfd8", "\ua810\ua936", "\udb7c\udcc4\uda4c\udc5b\ud984\udcc4\ud868\udf38\ud941\uddfc\ud966\udeb7\udada\udeeb\udad9\udfd8\ud8ff\udf22\uda08\udf15\udbdf\udee9\udaf6\udd0d\ud872\udfed\ud92b\uddb7\udb47\udf70\ud87f\ude4d",
        15, 3696, -1561247517, 7466008351793313305L, -63053L, true, true, (char) 44056, (char) 54053,
        Double.longBitsToDouble(0x3fe0147e99f52223L), Double.longBitsToDouble(0x3fc4574b33ef93dcL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\0121=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 5, 5, 2, "\u2743\udbb2\udd31\uda7e\udd74", "\ua936\u97a5\u435b\u26fb\u88cf\u81fb\u09bf\u1ab7\u9b41", "\ud89f\udd4e\ud854\udebc",
        52, 34605, -69588877, 4795791312346729470L, 34953L, true, true, (char) 9269, (char) 22402,
        Double.longBitsToDouble(0x3feaac8ce0451da6L), Double.longBitsToDouble(0x3fb4c4dc54a587b0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.jfree.chart.block.BorderArrangement:@?\0121=new org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 9, 9, 2, "\u2743\udbb2\udd31\uda7e\udd74", "\ua936\u97a5\u435b\u26fb\u88cf\u81fb\u09bf\u1ab7\u9b41\u74d1\u2386", "\ud896\udf4b\ud8b8\udf0a",
        53, 51178, 357878782, 7903501641453353L, 1347L, false, false, (char) 43157, (char) 38379,
        Double.longBitsToDouble(0x3fb4c4dc54a587b0L), Double.longBitsToDouble(0x3fc997798c506be8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.block.BorderArrangement:@?\0121=void |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 1, 1, 2, "\u2743\ud830\udd30\uda7e\udd74", "\ua936\u9a08\u435b\u26fb\u88cf\u81fb\u09bf\u1ab7\u9b41\u7509\u2386", "\ud896\udf4b\ud8b8\udf0a\ud98e\udc34\ud81f\udeb6",
        22, 21177, 1607601961, -2428284324513680355L, 25099L, true, false, (char) 45696, (char) 41866,
        Double.longBitsToDouble(0x3fc997798e906be8L), Double.longBitsToDouble(0x3fb160fa1fbd3bc0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 2, 8, 8, 6, "\u2743\ud8f6\udd33\udb84\udc01\ud90c\udfb8\ud89d\udc26\ud857\udd8f\u1a1a", "\u3103\u1b88\u091a\u1ab7", "\udaef\udedf\ud8ff\udea3\uda08\udf15",
        36, 54795, 1595991634, -4198345345230297550L, 55689L, true, true, (char) 39049, (char) 14732,
        Double.longBitsToDouble(0x3fe0cb3ce0fa12bdL), Double.longBitsToDouble(0x3fb4c4dc457fca20L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 2, "\000\000\000", "\ua936", "\u7ef6\000\ud94c\udd65\ud868\udf48\ud941\uddfc\ud966\udeb7\ud93e\udeeb\udaef\udedf\ud8ff\udf22\uda08\udf15\uda4b\udc25\udaf6\udce0\ud872\udfed'\udb47\udf70\udbb9\udfca",
        1, 40143, -1561247517, 7466008351793313305L, -63053L, true, true, (char) 65015, (char) 53639,
        Double.longBitsToDouble(0x3fb160fa035ebfd8L), Double.longBitsToDouble(0x3fe53fcca4fe71daL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.chart.util.Size2D:Size2D[width=0.0, height=0.0] |this=org.jfree.chart.block.BorderArrangement:@?\012",
        Z.run(T, 1, 5, 4, 0, "\u2743\udbb2\udd31\uda33\udeaf\udb37\udee6\ud89d\udc3a", "\u761f\uc26e\u469c\u1b73", "\ud966\udeb7\ud93e\udeeb\udaef\udedf\ud8ff\udf22\uda08\udf15\uda4b\udc25",
        36, 89634, -978245337, 1522821621220119601L, -54765L, true, false, (char) 53577, (char) 48431,
        Double.longBitsToDouble(0x3fca611da6cfebf4L), Double.longBitsToDouble(0x3fd676535daf3dd6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.block.BorderArrangement|arrangeFF|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|add|org.jfree.chart.block.Block,java.lang.Object|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrange|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeFN|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,double|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeFR|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeNN|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|arrangeRR|org.jfree.chart.block.BlockContainer,org.jfree.data.Range,org.jfree.data.Range,java.awt.Graphics2D|new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|clear||new:org.jfree.chart.block.BorderArrangement:",
    "M|org.jfree.chart.block.BorderArrangement|equals|java.lang.Object|new:org.jfree.chart.block.BorderArrangement:",
    "C|org.jfree.chart.block.BorderArrangement|<init>|",
    "M|org.jfree.chart.block.BorderArrangement|arrangeFF|org.jfree.chart.block.BlockContainer,java.awt.Graphics2D,org.jfree.chart.block.RectangleConstraint|new:org.jfree.chart.block.BorderArrangement:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
