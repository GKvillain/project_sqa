package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiplePiePlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u987e\u5c97\u77e5\u2b4f\uc9d3\ud73c\u0383\uad2d\u3aa5", "\uda94\udfc7",
        14, 66006, 876602888, 1040938231025770133L, -99208L, true, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da18d07db4L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\uda59\udcf2\udbc7\udc9a\ud997\udda4\uda48\udeee\ud84b\udf83\udacc\udcb9\uf06a", "\uaaaf\u71a2\u9ce0\u987e\u5c97\u77e5\u2b4f\uc9d3\ud73c\u0383\uad2d\u3aa5", "\uda94\udfc7",
        14, 66006, 876602888, 1040938231025770133L, -99208L, true, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da18d07db4L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 12, 11, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a\ud819\udecd\ud9c3\udc3a\udb07\udf82\udb8b\udf48\ub6bf\ud867\udfe1\ud8b7\udeaa\uda77\ude1b\ud855\udff9\ud9f0\udde9\ud999\udee3", "\u3aa5\uac01\u252e\u8a5b\uc61a", "\udbbe\udca7\uda5a\udf9d\uda84\udd9b\udb90\udd5f\ud87d\udf4f\ud974\udf5f\ud8de\ude91\ud99c\ude52\udad2\udea8\ueed6\ud812\udc39",
        45, 68758, -1645183940, 7446407647821340035L, -13132L, false, true, (char) 36326, (char) 11299,
        Double.longBitsToDouble(0x3fe2aa71b103a564L), Double.longBitsToDouble(0x3fcd1417b28f062cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaa2\u8909\u03df\u9888\u5c97\u77e5\u2b4f\uc9d3\ud73c\u0383\uad2d\u13a7", "\uda94\udfc7\udbd3\ude6c\udacb\udea9\ud8e4\udd1c",
        -2, 29005, 734684935, -2102051725288263113L, 560L, false, false, (char) 17444, (char) 704,
        Double.longBitsToDouble(0x3fe1b46169dd79c3L), Double.longBitsToDouble(0x3fcef7bb900125d8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\uda59\udd37\udbc7\udc9a", "\u23d9\u6362\u5b3b\u0efe\u29dc\uaaaf\u8909\u9ce0\ud734\u5c97\u5f01\u2ba9\u0959\ud686\u0383", "\ud894\ude28\ud841\udc96",
        59, 28789, -22556994, -4161354609973224182L, 41806L, false, true, (char) 36875, (char) 43013,
        Double.longBitsToDouble(0x3fd8113b25d491aaL), Double.longBitsToDouble(0x3fca0fb68a4a5e54L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\udb09\udc68\ud96f\udc2c\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0", "\uda77\uddb0",
        39, 14782, -1663163205, 392337698188970537L, 12436L, true, false, (char) 12774, (char) 58543,
        Double.longBitsToDouble(0x3fee71a1fc5c0e72L), Double.longBitsToDouble(0x3fe83aab53182bcaL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 7, 0, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u8025\u5c97\u9e59\u6a9c\uc9d3\ud73c\u0383\uad2d\u3a92", "\ud85c\ude29",
        14, 66006, 876603083, 1041086665095519893L, -84872L, false, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da18d0b6b4L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:Multiple Pie Plot |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 11, 9, 8, "\ud8f0\udca4\udb4a\udd45\ud9aa\udfb0\ud909\udc5f\ud855\ude8a\udaeb\udc03\uf06a", "\uaaaf\u8909\u9ce0\u5c81\u5c97\u1f98\uc0aa\u2dcc\ud73c\u2d83\u999f\ub67e", "\ud8d1\udc9f\udb9f\ude2e\udb39\udf07\ud8b1\udd7d\udbbe\udca7\uda5a\udf9d\ud8ec\udea6\ud8df\udcec\uda96\udcfa\udb83\udd73\ud8de\udeb0\uda79\udf2f\udab4\udfba",
        41, 93506, -1230848337, 2025172789674573368L, -80519L, true, false, (char) 50922, (char) 12947,
        Double.longBitsToDouble(0x3fef4c0ef35786ceL), Double.longBitsToDouble(0x3fc10f2e35343180L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a\ud819\udecd\ud9c3\udc3a\udb07\udf82\udb8b\udf48\ub6bf\ud867\udfe1\ud8b7\udeaa\udb87\udfa3\udb0b\udf34\ud9f0\ude33\ud999\udee3\ud85d\udd61\udb01\udf20\udbac\udcd5\ud894\ude28\ud841\udc96\uda94\udfc7\udbd3\ude6c", "\u10ed\ub7aa\u21ac\ub15b\u0a04\u61f6\ub91c\u9290\u1a37\u6f78\u3fe0", "\ud969\uddc4\ud82f\udcd9\uda17\udf33\ud9f1\udfc9\udb08\udf41\udb32\udcf0\udb81\udceb\udbb6\udd77\ud8d4\ude45\udb7e\udd7c\uda40\udc5a\udb6c\ude50\uda53\udc2a\ud827\udf86\uda1d\udc9c\udbff\ude79\udb1b\udf30\uda19\udcbc\uda5d\ude00\ud8a9\udf1f\udb4d\udd88\udb98\udd68\udad5\udf3b\ud81c\udd0e\uda81\udff8\udafa\udf9c\ud821\udca1\udbed\udc2e",
        35, 72480, -850420134, 2683632010829864075L, -21761L, false, false, (char) 30352, (char) 23745,
        Double.longBitsToDouble(0x3fe8684610deed60L), Double.longBitsToDouble(0x3feb9df09df01ea4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 6, "\ud8b5\udc8b", "\u0e90\ubfc5\u1c66\uba80\u374a\u7f2f\u3fec\u63d7\u9ce0\u2750\u6a06\u467d\u434e\u3b4f\u453e\u0416\uad2d\u3aa5", "\udaa6\udc15\udbaf\udf66\udacb\udea9\ud8e4\udd1c\udbbe\udca7\uda5a\udf9d\uda84\udd9b\udb90\udd5f",
        48, 22073, 239335553, -8334087738710637007L, 70969L, false, false, (char) 43836, (char) 59233,
        Double.longBitsToDouble(0x3fea8ef31196514fL), Double.longBitsToDouble(0x3fec0ce6ea0b5c0dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.chart.util.TableOrder:TableOrder.BY_COLUMN |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 6, 16, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2", "\u53a1\u4471\u45f9\u29dc\uaaaf\u8909\u8bfd\u8b33\u5c97\u81e4\u2b4f\uc9d3\ud73c", "\ud19a\ud894\ude28\ud841\udc96\uda94\udfc7\udbd3\ude6c",
        16, 22888, 242362318, 6154765466788849415L, -100000L, false, false, (char) 0, (char) 48685,
        Double.longBitsToDouble(0x3fca0fb68a4a5e54L), Double.longBitsToDouble(0x3f4814576db6c800L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 12, 16, "\ud897\udcf1\udaa3\udce7\ud853\udcc2\udab2\udc46\u8284\udae4\udcc5\uf06a", "\uaaaf\u00cb\u9ce0\u987e", "\ud856\udc44\ud9f0\udde9\ud999\udee3\ud85d\udd61",
        49, 36157, 1815102408, 549830730028005172L, 41262L, true, false, (char) 48241, (char) 12002,
        Double.longBitsToDouble(0x3fe1bf16a019ceb2L), Double.longBitsToDouble(0x3fec09bc92f59db5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 5, "\uda59\udcf2", "\000\ubfb7\u1da1\uba80\u0efe\uc672\000\u8909\uc101\u02f6\u5c97\u77e5\010\000\000\000\uad2d\u3aa5", "\uda94\udfc7",
        14, 66006, 876602888, 1040938231025770133L, -99208L, true, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da18d07db4L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 7, 12, 6, "\ud8c4\uddea\udaa8\udd3e\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a\ud819\udecd\ud9c3\udc3a\udb07\udf82\udb8b\udf48\ub6bf\ud867\udfe1\ud8b7\udeaa\uda77\ude1b\ud855\udff9\ud9f0\udde9", "\u8f4d\u10cb\u8963", "\udbd3\ude6c\udacb\udea9\ud8e4\udd1c\udbbe\udca7\uda5a\udf9d\uda84\udd9b\udb90\udd5f\ud87d\udf4f\ud974\udf5f\ud8de\ude91\ud99c\ude52\udad2\udea8\ueed6\udb9a\ude7d\ud872\udd00\uda73\ude84\ud897\udf48\uda6f\uddc0\udbc0\udd5a\udbde\udc5a\udb7d\ude06\ud912\udfd0\udae4\udc8b",
        44, 76211, -1500647949, -1029521681322449583L, 89307L, true, true, (char) 7667, (char) 52071,
        Double.longBitsToDouble(0x3fec4570718e6f45L), Double.longBitsToDouble(0x3fd5bb8c2f013ecaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 16, 8, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u987e\u5c97\u77e5\u2b4f\uc9d3\ud73c\u0383\uad2d\u3aa5", "\uda94\udfc7",
        28, 65850, 876602888, 1040938231025770133L, -99208L, true, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da18d07db4L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jfree.chart.JFreeChart:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 10, 7, 16, "\uda59\udcf2\udbc7\udc9a\ud845\udd39\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u987e\u5c97\u77e5\u2b4f\uc9d3\ud576\u0406\uad2d\u3aa5", "\uda94\udfc7",
        14, 66006, 876602888, 1040938231025770133L, -80323L, true, true, (char) 48073, (char) 28605,
        Double.longBitsToDouble(0x3fc415d9c341f6d0L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 8, "\uda59\udcad\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaa30\u8909\u9129\u987e\u64e6\u1220\u168e\u88bc\ud73c\u0383\uad2d\u3aa5", "\uda94\udfc7",
        14, 66006, 876602888, -8269081919167521131L, -99208L, true, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da19d07db4L), Double.longBitsToDouble(0x3fdfb2953eab001aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\udbe6\udc34\uda08\udc4a\ud8ec\udfcf\udacf\udec8\u8284\udacc\udcb9\uf06a\ud819\udecd\uda16\udf94\udb76\ude71\udb8b\udf48\udb51\udc70\udbe8\udfc3\ud8b7\udeaa\uda69\uddd7\ud855\udff9\ud8d9\udf31\udb03\udd05\ud8e4\udc51\ud83e\udc72\udbac\udcd5\ud894\ude28\ud841\udc96\uda94\udfc7\udbd3\ude6c\udacb\udea9\ud8e4\udd1c\uda72\ude33\udaa5\udd97\uda84\udd9b\udb90\udd5f\ud87d\udf4f", "\u17e6\ubd0e\u6f78\u02fb\u8d2b\ub4e8\u95a4\uc421\u730e\u2925\u4df5\ub5d3\u73b9\uba82\ubc22\u909e\u7077\u4ef9\u0f1a\u6e00\u4c63", "\udaba\udf65\ud815\udf39\udba1\udf0e\ud8ed\udfc7\ud94e\udd43\uda56\udece\u07d4\ud9b5\udc43\ubadd\udbfe\udd9c\ud9d9\ude29\u4d46\uda2e\ude71\ud9be\udf48\udb77\udce4\u2ed6\udbf6\udde2\udb75\udfb9\ud86b\ude52\udbf1\ude6d\udb22\udc50\udaf4\udf3c\uda28\udd58\ud812\udf96\ud855\udd0d\udb57\uddc4\ud94d\uddff\u4ca9\ud9b7\udd69\ud863\udf03\udaaf\udd8d\udbd0\udc47\ud9d9\udfe9\u63c3\udabd\udc2e\udaed\ude8a\udadb\udfec\uda64\udc2c\u5ef7",
        19, 41171, -1690895105, 6314898645485146440L, -63377L, true, true, (char) 58465, (char) 19772,
        Double.longBitsToDouble(0x3fc53fdc5eab60e4L), Double.longBitsToDouble(0x3fc9c020f46ac254L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 1, 16, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u987e\u5c97\u77e5\u2b4f\uc9d3\ud73c\u0383\uad2d\u3aa5", "\uda94\udfc7",
        14, 66006, 876602888, 1040938231025770133L, -99208L, true, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da18d07db4L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=java.lang.String:Multiple Pie Plot |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 8, 11, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8584\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u9d64\uc0a1\ud6f9\u2b4f", "\udbe2\uddd2",
        40, 17556, 1815102408, -8052103931520399895L, 20354L, true, true, (char) 48500, (char) 52198,
        Double.longBitsToDouble(0x3fefc03e10182bcaL), Double.longBitsToDouble(0x3fefb703ef24ea75L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 3, 16, 0, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\uce0e\udacc\udcb9\ud923\udd5d", "\000", "\ud867\udfe1",
        38, 45946, 0, -1663163392L, -81015L, false, true, (char) 14127, (char) 53331,
        Double.longBitsToDouble(0x3fe9a03d0895c5e9L), Double.longBitsToDouble(0x3fe5f3194608fea7L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 3, 16, 3, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\uce0e\udabe\ude3eT", "\u00f3", "\ud867\udfe1",
        38, 1138, 1122223112, 2017612897686791355L, -100000L, false, true, (char) 62310, (char) 25600,
        Double.longBitsToDouble(0x3fe8003d0895c5e9L), Double.longBitsToDouble(0x3fc7c0000003f800L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "", "\ua722\u0e90\ubfc5\000\uba2c\u45f9\u29dc\uaaaf\u8909\u9ce0\u987e\u5c97\u77e5\u2b4f", "\ud85d\udd61",
        36, -1000, 0, 549720628541372212L, -100000L, false, false, (char) 48135, (char) 12002,
        Double.longBitsToDouble(0x3fe1bf16a019ceb2L), Double.longBitsToDouble(0x3fc026f24baa6d0cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 9, 6, "\uda59\udcf2\udbc7\udc9a\udbee\uddb8\ud9c6\uddc1\uda70\udd11\udacc\udcb9\uf06a", "\u60e1\u8909\u531d\u987e\u40bd\u7734\u2b4f\u88cd\ua019\ua38b\uad44\u3aa5", "\uda6a\ude2a",
        14, 23254, 876602888, -5091148068992950635L, -98386L, false, false, (char) 43722, (char) 12307,
        Double.longBitsToDouble(0x3fe754da18d04ab4L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 14, 16, 12, "\udb35\uddbf\ud81a\udc17\ud98d\udd15\ud931\udd5e\ud83f\udf65\ud81c\udc76\ud97b\udf1c", "\uaaaf\u8909\u9ce0\u8be5\u5c97\u77e5\u2b60\uc9d3\ud73c\u3b37\u710a\ud129\ucf5d\u23bc\u8a5b", "\ud8e4\udd1c\udbbe\udca7\uda5a\udf9d\uda84\udd9b\udb90\udd5f\ud87d\udf4f\ud974\udf5f\ud8de\ude91\ud932\udfff\udaf0\udc9f\ueed6\udbe8\udf25\ud811\ude7b\u1dfc\uda16\udeec",
        49, 4365, -1763572158, -2801208871794387507L, -10672L, false, false, (char) 30397, (char) 33957,
        Double.longBitsToDouble(0x3fed924739b37d16L), Double.longBitsToDouble(0x3fe6414a40b59845L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 14, 16, 8, "\udaee\ude6d\ud9f6\udf08\udb48\udc1b", "\u7626\u0c80\u5879\ua495\u81a3\u0567\uc937\u0a44\u3459\u6803\u5a69\u58d3\u7d1e", "\ud8cb\udce6\ud88d\ude03",
        3, 59780, -668432297, 4095887604142679536L, -92171L, true, true, (char) 12002, (char) 5388,
        Double.longBitsToDouble(0x3f99ceb27046f240L), Double.longBitsToDouble(0x3fd2e440112d29deL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:Other |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 11, "\uda59\udcf2\udbc7\udc9a\ud853\udd79\udab2\udc46\u8284\udacc\udcb9\uf06a\ud819\udecd\ud9c3\udc3a\udb07\udf82\udb8b\udf48\uda85\udeca\ud867\udfe1\udb5b\udfe1\ud9f1\uddd6\ud9b6\udfea\ud915\udf6a\ud999\udee3", "\u3aa5\uac01\u252e\u8a5b\uc61a", "\udbbe\udca7\ud8c8\uddd5\ud8dc\udd28\udb90\uddde\ud87d\udf4f\ud974\udf5f\ud8de\ude91\ud99c\ude52\udad2\udea8\udbfc\udcd6\ud820\udf2a",
        45, 38366, 1062639971, 7446407651109674371L, -13132L, false, false, (char) 30626, (char) 11532,
        Double.longBitsToDouble(0x3fe2aa71b103a564L), Double.longBitsToDouble(0x3fcd1417b28f062cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.chart.util.TableOrder:TableOrder.BY_COLUMN |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 6, 11, 12, "\uda59\udcf2\ud8cd\udfdf\ud82d\uddc5\ud8df\uddd1\ud9ca\uddeb\ud962\udcb8\u1382\ud8e8\udef2\uda79\udc78\ud987\udf64\udb8b\ude71\ud9e7\udf7c\udb73\ude9a\udba4\udc8d\udb20\udee2\ud966\udd69\udbea\ude7b\udbd1\uddba", "\ua754\uc8b0\uc473\u8a5b\u3845\u47d0\u348c\u0415\u9506", "\ud916\udf73\uda0a\udd5b\ud8de\ude91\uda33\udf5e\udad2\ude36\ueed6\ud812\udc39\ud815\udc30\ud9e5\udc19\udbfa\udd57\uda57\ude52\ud89d\udebe\udb0b\ude3d\udbe4\ude68\ud834\ude15\udb7e\ude22\uda28\udcb7\udafc\udd79\udb59\uded8\udb14\udcf4\ud8f1\udeb2\ud932\udcb6\uda9f\udd55\ud882\ude97\ud8e9\udce6\ud915\udf7b\u11a5\udb19\udcc2\ud8c4\ude30\udbc8\ude25\uda9e\udc9a\ud917\udee6\udb28\ude3f\uda3d\udd31\ud9c9\ude68\ud86d\udc40\ub4a4\udbc2\udf96\ud923\uddf6\ud943\udd67\uda43\ude79\ud943\udf26\ud94c\udd9b\ud96c\udd7a\udb99\udf79\ud995\udc4a\u2f03\uda10\udd66\udb1c\udc0f\udac1\udc7e",
        6, 7321, -1246761287, -8409443086347523020L, -5345L, false, true, (char) 22786, (char) 34461,
        Double.longBitsToDouble(0x3fde6e994f1cb11aL), Double.longBitsToDouble(0x3fe81529466e3aa0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:Multiple Pie Plot |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=java.lang.String:Multiple Pie Plot |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 11, 11, 8, "\ud9a7\udff9", "\u9991", "\ud937\udeaf\ucd65\ud9c3\udc92\uda79\udce4\uda23\udda7\u5eb9\uda45\udcdd\ud8b9\udc18\udace\udf2a\udab3\udcaf\uda80\udff1\udb6f\udf2c\ud8bc\udd83\udbda\ude4f\uda90\udd01\ud8a1\udf8a\ud958\ude26\udbc8\udf2f",
        4, 58185, 876602888, -6198061610445431147L, 3032L, true, false, (char) 32252, (char) 35698,
        Double.longBitsToDouble(0x3fe6b23a1b1dad01L), Double.longBitsToDouble(0x3fede2976b7cf371L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 8, 0, 6, "\uda59\udcf2", "", "\000",
        -5, 55248, -631126414, -5426938760072122134L, -100000L, false, false, (char) 0, (char) 8,
        Double.longBitsToDouble(0x3faf00000001c560L), Double.longBitsToDouble(0x3f438008a4000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=192,g=192,b=192] |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 11, "\udbc8\udda8\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a\ud819\udecd\ud9c3\udc6b\udb07\udf82\ubbbb\ud8b3\udc83\ud843\udce1\ud8b7\udeaa\uda77\ude1b\ud855\udff9\ud9f0\udde9\ud999\udee3", "\u3aa5\uac01\u252e\u8a5b\ua1b0", "\udbbe\udca7\uda5a\udf9d\uda84\udd9b\udb90\udd5f\udaf9\udc4d\ud974\udf5f\ud9a7\udf75\ud9a0\udd28\udad2\udea8\ueeb3\ud812\udc39\ud815\udc30\ud989\uddd8\ud993\udf35\ud8f4\ude9c\ud89d\ude9b\udb0b\ude3d\ud8a3\udea7\ud8f3\udd0b\ud9b0\udc65\udba2\udcbb\ud86e\udc25\udb30\udcc1\udb14\udd39\u2c1e\ud9e7\udd26\ud91e\udc5d\ud941\uddb8\udbb9\ude4d\udb61\uddba\uda5d\udc23\u92b3\udb59\udef0\u0248\uebc2\uda51\udfb5\uda07\udd67\udabb\udfe5\ud972\udf15\udb2c\udc31\udb45\ude79\ud835\udc9f\udb02\udc51\ud936\udd97\ud89a\ude99\u541c\udbc7\ude4a\ud935\udcf4\udba7\ude91\ud9ec\ude80\udb84\udd2d\udba2\ude45\udbd5\ude9f",
        58, 64312, 412868828, 1069482794860137198L, -38160L, true, false, (char) 20905, (char) 44891,
        Double.longBitsToDouble(0x3fe302c51660f275L), Double.longBitsToDouble(0x3fe8c4f2914cf0c7L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 16, 16, 8, "\ud8dc\udf26\uae36\uda86\udc96", "\ud384", "\ud8d6\udee3\ud8c0\uddd1\udb78\udc86",
        28, 9708, -30886202, -909218212931714040L, 32649L, false, true, (char) 61905, (char) 36312,
        Double.longBitsToDouble(0x3fe1e87c5c0ef656L), Double.longBitsToDouble(0x3fe9a03d0895c5e9L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "", "\ua722\u47bf\000\u1d26\uba80\u0efe\ub7c9\uaaa2\u8909\u03df\u9888\u5c97\u77e5\010\uc995\ud73c\u0383\uad2d\u13a7\uce66\000\u8a12\u8895\u25a1", "\u1e00",
        45, 56424, -827182592, 4004430250134445697L, 560L, false, false, (char) 49314, (char) 61887,
        Double.longBitsToDouble(0x3e2dd00000000000L), Double.longBitsToDouble(0x3e400125d8000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u82ad\udacc\udd17\udac4\udf0e", "\uaaa2\u88bd\u03df\u9888\u065e\u4132\u2b4f\u61bc\u09f7\u9ca3\uc2ed\u13a7", "\udb45\uded6\ud908\udf65\ud9b0\udf46\ud80f\udfbd\ud824\udc0d",
        55, 9935, -489422056, -3552721945088976871L, -20786L, false, true, (char) 11907, (char) 12119,
        Double.longBitsToDouble(0x3f8b448eb6984400L), Double.longBitsToDouble(0x3f325d933e530800L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\000",
        -5, -1000, -354680832, 27521264405947379L, 77118L, false, false, (char) 64048, (char) 52738,
        Double.longBitsToDouble(0x3fe197bfd83edb3aL), Double.longBitsToDouble(0x3fc7638ac0000378L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 3, 14, 8, "\uda59\udcf2\udbc7\udc9a\udb87\udeb9", "\u53a1\u4471\u45f9\u29dc\uaaaf\u8909\u8bfd\u8b33\u5c97\u81e4\u2b4f\uc9d3\ud73c", "\ud19a\ud894\ude28\ud841\udc96\uda94\udfc7\udbd3\ude6c",
        16, 68536, 242388828, 6154765466783344391L, -100000L, false, false, (char) 0, (char) 48685,
        Double.longBitsToDouble(0x3fca0fb68a4a5e54L), Double.longBitsToDouble(0x3f4814576db6c800L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.chart.JFreeChart:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 10, 8, 6, "\ud8c4\uddea\udaa8\udd3e\ud872\udec2\udab2\udc46\u8284\udacc\udcb9\uf06a\ud819\udecd\ud9c3\udc3a\udb07\udf82\udb8b\udf48\ub6bf\ud867\udfe1\ud8b7\udeaa\uda77\ude1b\ud855\udff9\ud9f0\udde9", "\u8f4d\u10cb\ud034", "\udbd3\ude6c\udac0\udea9\ud8e4\udd1c\udbbe\udca7\ud94a\ude15\ud905\ude23\udba8\udc6b\udbad\udccd\ud974\udfff\ud8de\ude91\ud99c\ude52\udad2\udea8\ueed6\udb9a\ude7d\udb40\udf59\uda73\ude84\ud897\udf48\uda6f\uddc0\udbc0\udd5a\udbde\udc5a\udb7d\ude06\ud912\udfd0\udae4\udc8b",
        44, 76211, -1500647949, -3191249502460264529L, 89307L, true, true, (char) 10959, (char) 52071,
        Double.longBitsToDouble(0x3fec4570718e6f45L), Double.longBitsToDouble(0x3fd5bb8c2f013ecaL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=null |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 7, 7, 16, "\uda59\udcf2\udbc7\udc9a\ud845\udd39\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uc7af\u8909\u9ce0\u987e\ua1be\u2cf9\u2bd6\uc9d3\ud576\u39d1\u5a83\ua34b", "\uda94\udfc7",
        14, 83846, 876602888, 1040938231025770133L, -80323L, true, true, (char) 48073, (char) 28605,
        Double.longBitsToDouble(0x3fc415d9c3419784L), Double.longBitsToDouble(0x3fe494bcab82c0a2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:Multiple Pie Plot |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 14, 8, "\ud9d7\udca1\uda21\ude6d\ud835\uddc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\u0e27\u88f0\u9129\u15c1\ud024\ua216\u874d\ucf37\ud73c\ua6f1\uaf59\u3aa5", "\ud9b0\udfa1",
        14, 66006, 876602888, -8269081919710954930L, -7865L, true, false, (char) 48685, (char) 28548,
        Double.longBitsToDouble(0x3fdfb2953eab001aL), Double.longBitsToDouble(0x3fead0d2ce6989dcL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=192,g=192,b=192] |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 15, 8, "\udb56\udceb\udbc7\udc26\ud853\udcc2\udab2\udc46\uda1d\udc61\udac8\udeb9\uf06a", "\uaa30\u8909\u9129\u987e\u64e6\u1220\u168e\u88bc\ud73c\u0383\uad2d\u3aa5", "\uda94\udfc7",
        25, 36744, 876602888, -5082612559490049317L, 12920L, false, false, (char) 9256, (char) 27667,
        Double.longBitsToDouble(0x3fe1ccda19d07db4L), Double.longBitsToDouble(0x3fd15303ceaa1a92L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 14, 14, 8, "\ucb1a\udbc6\udff7\ud853\udcc2\udab2\udc46\u8284\ud991\ude7c\uf016", "\u2444\000\u9129\u987e\u64e6\u1220\u168e&\000\ud672\uad2d\u3aa5", "\uda94\udfc7",
        14, 66006, 8, -8269171864372633963L, -99208L, true, false, (char) 26315, (char) 12307,
        Double.longBitsToDouble(0x3fe754da19d07db4L), Double.longBitsToDouble(0x3fd000053e01001aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 1, 1, 8, "\uda59\udcad\ud8d4\udcd8\udb6a\udd00\udab1\udfd5\u8284\udacc\udcb9\ud9fc\udd6a", "\u85bf\u48e8\u9129\u987e\u64e6\u1220\u168e\u623a\ud73c\u0383\uad2d", "\ud9e9\ude0b\uda94\udfc7\udbd3\ude6c\udacb\udea9\ud8e4\udd1c\udacc\udf0a\uda5a\udf9d\uda5a\udce6\u7262\udb3b\udd9b\ud974\udf5f\ud8de\ude91\ud99c\ude52\ud9dd\udc3f\udac3\ude70\udba0\ude8c\ud8c9\udf6b\ud88b\udf23\udb2e\udd14",
        6, 41309, 946945427, 5675267469360310256L, 29338L, false, false, (char) 14781, (char) 37077,
        Double.longBitsToDouble(0x3fe64e4e569626a9L), Double.longBitsToDouble(0x3fe138df3c88d290L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 8, 8, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8584\udacc\udcb9\uf06a\udb38\udefc\ud9ba\udc97\udb07\udf82\udb8b\udf48\ub6bf\udb1b\udc94\uda16\udf32\uda59\udd30\ud855\udff9\ud9f0\udde9\udbef\udff3\udbe2\uddd2\ud9de\udc7f\uda7e\udcde\ud894\ude28\ud85f\udf8d\udb3a\udfbd\ud823\udec7\ud896\udd31\ud819\udcd4\ud882\udef1\ub52c\uda6c\ude8c\uda63\ude36\uaeb1\ud810\udfd9\ud8af\ude39\ud90a\udee1", "\ucd5b\u2dfb\u1846\u342f\u2221\u057d\u1596", "\ud91b\udd96\udae6\udc31\udb5f\udfd0\ud8e9\udce1\ud9cc\udfdf\uda2a\udc2a\ud8cd\udcec\uda27\udfbe\udac8\udf35\uda5d\udfeb\ud8ed\udcea\udbf8\udcd4\udaee\udf89\uf7e3\udb9e\ude21\uda58\udc39\uda88\udfc5\ud9e8\ude60\udafd\ude80\ud9e0\ude90\ud972\ude05",
        52, 95729, -1822654990, 1097239212696996330L, 51681L, true, true, (char) 42762, (char) 33560,
        Double.longBitsToDouble(0x3fe441acd789c4f1L), Double.longBitsToDouble(0x3fd31d905a523ec6L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jfree.chart.util.TableOrder:TableOrder.BY_COLUMN |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=org.jfree.chart.util.TableOrder:TableOrder.BY_COLUMN |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 6, 6, 13, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8584\udacc\udcb9\ud829\udd6a", "\uaaaf\u8909\u9ce0\u9d64\ua5ee\ud673\u2b4f", "\udbe2\uddd2",
        51, 39808, -137863371, -8051921786252343831L, 11906L, true, true, (char) 48500, (char) 52198,
        Double.longBitsToDouble(0x3fefc03970182bcaL), Double.longBitsToDouble(0x3fefb703ebd0ea75L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 8, "\uda59\udcf2\udbc7\udc9a\ud866\udd81\udab2\udc46\u8584\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u067b\uc0a1\ud6f9\u2b4f", "\udbe2\uddd2",
        40, 17556, 1815102408, -8052103931520399895L, 20354L, true, true, (char) 48500, (char) 52198,
        Double.longBitsToDouble(0x3fefc03e10182bcaL), Double.longBitsToDouble(0x3fefb703ef24ea75L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 3, 16, 3, "\uda5b\udef2\udbc7\udc9a\ud853\udcc2\udab2\udc46\uce0e\udabe\ude3eT", "\u00f3\u012e\u7323\u4e15\ubc8a\u77e5\u2b4f\u79c1\ub282\uce0c\u3a6a\u4d6c\000\u250b\u8a27\u8895\u265f\u2f84\uca25\u3ba2\u8704\u4db7\u5b21\ucdca\u6df3\u48a7\u343f\u051b\u466a\u69a7\uce05\u59ea\u1abd\u136b\ua801\u41e3\u4bbb\ua906\u8d49\u533f\u6b1b\ua592", "\uda40\uddc9\ud91f\udf69\ud8f9\ude33\udaeb\udddc\udae2\ude2c\ud814\udf4c\udae3\uddd3\ud92d\ude0b\ud8c1\ude51\ud8c1\uddd7\ud9b1\udc17\ud9fb\udc30\udbb6\udcdc\udafe\udcab\udbd9\udc00\ud9ac\udfff\ud8fe\udec4",
        7, 83970, -1278697, -8821151761494841002L, 87365L, true, false, (char) 59314, (char) 2924,
        Double.longBitsToDouble(0x3fd549397a2e4ec2L), Double.longBitsToDouble(0x3fd0c72780613006L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 3, 3, 8, "\uda59\udcf2\udae8\udf23\ud853\udc86\udab2\udc46\u82ad\udacc\udd17\udac4\udf0e", "\uaaa2\u88bd\u8134\u9d68\u05d7\u4132\u2b4f\u61bc\u09f7\u9ca3\uc2ed\u13a7", "\udb45\uded6\ud908\udf65\ud9b0\udf46\uda85\udccc\ud824\udc07",
        55, 9935, -489422056, -3552721945088976871L, -20786L, false, true, (char) 11907, (char) 12119,
        Double.longBitsToDouble(0x3f8b448eb6984400L), Double.longBitsToDouble(0x3f325d933e541000L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\uda59\udcf2\udbc7\udc9a\ud853\udcc2\udab2\udc46\u8284\udacc\udcb9\uf06a", "\uaaaf\u8909\u9ce0\u987e\u5c97\u77e5\u2b4f\uc9d3\ud73c\u0383\uad2d\u3aa5", "\uda94\udfc7",
        14, 65832, 876602888, 1040938231345192597L, -90018L, true, false, (char) 26315, (char) 12819,
        Double.longBitsToDouble(0x3fd79002aafee614L), Double.longBitsToDouble(0x3fe674c5b3cdb216L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 16, 8, "\uda59\udcf2\ud9d4\udca1\ud853\udcc2\udab2\udc46\u8284\ud894\ude3e\ud9c4\udfb4\ud819\udeda\ud9c3\udc3a\udb07\udfda\udb71\uddbc\ub6bf\ud867\udfe1\ud8b7\udeaa\uda77\ude1b\ud855\udff9\ud9f0\udde9\uda24\uded4\ud85d\uddc7\udb01\udf20\udbac\udcd5\ud894\ude28\ud841\udc96\uda94\udfc7\udbd3\ude6c\udacb\udea9\ud8e4\udd1c\udbbe\udca7\uda5a\udf9d\uda84\udd9b\udb90\udd5f\ud87d\udf4f\ud974\udf5f\ud8de\ude91\ud99c\ude52\udad2\udea8\ueed6\udbb9\udc8d\uda0a\udcac\ud9f5\udda8\ud8dd\udde7\ud83f\udc97\udaf3\udf34\ud8fe\udd7b\udba9\ude11\udaaa\udcd7\ud9c4\ude1c\uda3f\udf4e\uda0c\udfec\udb91\uddb6\ud893\udc3b\ud987\udd60\ud951\udffd\udb52\ude2d\uda12\udd1b\u9b1f\ud893\udf03\ud8eb\udfd6\udbf3\udea6\uc307\u6370\ud8ed\udc93\ua527\ud8da\udf5c\ud95e\ude8d\udad4\udd94\ud938\uddd5\udbef\ude8f\ud8c7\uddb9\udb39\udc2c\udaa2\udd52\ud884\udcf1\ud939\udc29\ud98f\ude7b\ud8e3\udec1\u7690\ud895\udcc8\uda9c\udc46\udbd1\ude99\ud8ba\udc1b\ud907\udf61\ud84d\udf27\udab9\uddd8", "\ua94d\u4ff2\ub493\u714f\u9d98\uca6c\u5d11\ubab9\ub3de\u2f2e\u8f23\u6aa1\u71e9\u64f5\u4a89\u9952\u02a2\u85fc\u78f7\u9cff\u648c\ud2e8", "\udb32\uddcc\udb94\udd6b\ud8c8\udd00\uda75\udc7b\uda22\udc15\udbc6\udc20\udbe0\udf53\ud980\udf98\uda75\uded3\uda7b\ude5d\ud83f\udc6d\ud843\udc51\udb3f\udf1a\uda9e\udc6b\ud88d\udd40\uda85\udd88\ud994\udea2\udb3d\udede\udbf6\ude69\ud979\udfa4\udb26\uded5\uda2e\udd68\uda9b\udfc2\ud938\udec4\uda27\udd6d\uda29\udf9b\udb4a\udf21\udbdb\udc26\ud8e0\udfe9\udb33\udd26",
        22, 6921, 155230857, -8217745254536219884L, 61961L, false, true, (char) 54323, (char) 61471,
        Double.longBitsToDouble(0x3fefeb9bb2e26f2fL), Double.longBitsToDouble(0x3fe392074d4aa3ceL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|",
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|org.jfree.data.category.CategoryDataset",
    "M|org.jfree.chart.plot.MultiplePiePlot|draw|java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Point2D,org.jfree.chart.plot.PlotState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|equals|java.lang.Object|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getAggregatedItemsKey||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getAggregatedItemsPaint||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getDataExtractOrder||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getDataset||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getLegendItems||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getLimit||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getPieChart||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getPlotType||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|prefetchSectionPaints||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|readObject|java.io.ObjectInputStream|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|setAggregatedItemsKey|java.lang.Comparable|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|setAggregatedItemsPaint|java.awt.Paint|new:org.jfree.chart.plot.MultiplePiePlot:",
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|",
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|org.jfree.data.category.CategoryDataset",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
