package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiplePiePlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477\u3edc\u9ee7\u9066\ud348", "\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc0d\ud90a\udf5d\udb7c\uddf0\uda25\udeaf",
        49, 50908, 652153725, 551844805652751837L, -17043L, false, false, (char) 3837, (char) 20566,
        Double.longBitsToDouble(0x3fdc2e7c41aeff6eL), Double.longBitsToDouble(0x3fd2a9701d57b5f4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8db3\ud477\u3edc\u9ee7\u9066\ud348\u62dc\u645a\u9b70\u458c\u164c\u5bee\u6634\u9e88", "\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc0d\ud90a\udf5d\udb7c\uddf0\uda25\udeaf",
        33, 54658, 652153725, 551844805652751837L, -17043L, false, false, (char) 3837, (char) 20566,
        Double.longBitsToDouble(0x3fdc2e7c41aeff6eL), Double.longBitsToDouble(0x3fd2a9701d57b5f4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 15, "\uda1a\udebd\udb3c\udd86\udad2\udc60\udb7f\ude29\ud898\udf71\ud9a3\udf44\uda19\udc9d\ud89c\udc6e\uda02\udcde\ud98f\udc0b\ud99f\ude94\ud96d\ude9a\ud8a4\ude35\ud8d5\udfbd\ud889\uded1\ud9f9\udcd1\udaaf\udf15", "\u16be\uc00c\u3c73\u6ad2\u92e5\uc85a\u03ac\ub74d\u46b6", "\uf76b\udb73\udd0c\udb7b\udf3f\ud99b\uddc7\uda0b\udc60\udae2\ude58\udabd\ude7a\ud9ff\udee4\ud9bf\udf9b\uda57\udea2\ud98d\udef0\udb49\udd48\udbde\udea6\ud9ac\udefb\uda20\udc4e\ud833\udea7\udba8\udf7d\ud82b\uddcf\ud9ff\udc80",
        11, 92007, 761432926, 4815244118584839317L, 72473L, false, true, (char) 49253, (char) 25734,
        Double.longBitsToDouble(0x3fd800c5832c364aL), Double.longBitsToDouble(0x3fdbe7512d162fa4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:Other |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 4, 13, 14, "\udbbc\udca9\ud9e0\udc4f\u70cd", "\u8e15\000\ud12e\u9ee7\000\000", "\u4e74\000\000\000\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\u5b2b\000\ud9fd\udf9e\ud9f4\udc92\ud932\udf0e\uda61\udd2f",
        12, 59473, 1530064017, -1640348171597088562L, -39453L, true, true, (char) 44420, (char) 29653,
        Double.longBitsToDouble(0x3f8ae41c002a1e40L), Double.longBitsToDouble(0x3e07abc000000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\udaca\ude5b\u7104", "\u8e15\ud477\u3edc\ua43d\ubc15\uadb4", "\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73",
        54, 39547, 1423176579, -5758596308068664077L, 62328L, true, false, (char) 58020, (char) 43258,
        Double.longBitsToDouble(0x3f7d6cc867749e00L), Double.longBitsToDouble(0x3fe8231ff37dc018L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 16, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477\u3edc\u9ee7\u9066\ud348", "\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc0d\ud90a\udf5d\udb7c\uddf0\uda25\udeaf",
        49, 50908, 652153725, 551844805652751837L, -17043L, false, false, (char) 3837, (char) 20566,
        Double.longBitsToDouble(0x3fdc2e7c41aeff6eL), Double.longBitsToDouble(0x3fd2a9701d57b5f4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=org.jfree.chart.JFreeChart:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 1, 10, 14, "\udb27\udf1f\ud80d\udc7c\udb94\ude0e\udb7f\ude29\ud88e\udf8f\ud9f9\udd7c\u1545\udb0d\udc25\uda02\udd00", "\u0b09\u06ba\ud7d9\u458c\ub38b\u2ca6\u6634\ucc75\u16be\uc00c\u9227", "\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc57\ud90a\udf5d\udb7c\uddf0\ud9c1\udc1c\uda68\udef2",
        15, 37771, 1419288770, 4823022008959908096L, -70736L, false, true, (char) 20566, (char) 52614,
        Double.longBitsToDouble(0x3fcaeff6f4aa5c04L), Double.longBitsToDouble(0x3fea4ed7d0134531L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 14, 7, 14, "\udac6\udcad\ud9e0\udc4f\ud814\udd04", "\u8e15\ud477\u3edc\u6062\u78ca\u3a83", "\u3d00\udbee\udc56\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc0d\ud90a\udf5d\udb7c\uddf0\uda25\udeaf",
        49, 50908, 652153725, 551844805652751837L, -17043L, false, false, (char) 3837, (char) 20566,
        Double.longBitsToDouble(0x3fdc2e7c41aeff6eL), Double.longBitsToDouble(0x3fd2a9701d57b5f4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477\u3edc\u9ee7\u2dd1\ud348", "\u4e74\udbd1\udeb1\ud9f9\udcd1",
        57, 1310, -159098426, 179330120280175491L, 97389L, true, false, (char) 30931, (char) 20790,
        Double.longBitsToDouble(0x3fde8a20566eb1daL), Double.longBitsToDouble(0x3feac953ac91bc69L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\uda8e\udf32\udb6a\udebe\u7104", "\u8e15\ud477\u3edc\u9ee7\u9066\ud348", "\udbee\udd3a\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud846\ude02\ud8cc\ude37\ud91e\ude71\udac6\udf22\ua675\ud9bf\uddb2\uda34\ude2b\udbe0\udfe7\ud89d\ude74\uda5e\udf25\ud8d4\udc0d\ud981\udc5d\udb7c\uddf0\uda25\udeaf",
        49, 50908, 652153725, 551844805652751837L, -93282L, true, false, (char) 48171, (char) 14615,
        Double.longBitsToDouble(0x3fbacb9125156248L), Double.longBitsToDouble(0x3fe64967e4cf5e27L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477\u3edc\u9ee7\u9066\u2ab1", "\u4e74",
        49, 93023, 1383062074, 5934280416357013958L, 97389L, true, false, (char) 30931, (char) 20790,
        Double.longBitsToDouble(0x3fde8a20546eb1daL), Double.longBitsToDouble(0x3feaceda5c91bc69L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477", "\ud98f\udc0b\ud8d6\uddb0",
        20, 1482, 974187272, 950274823412322327L, 89554L, true, true, (char) 45054, (char) 44296,
        Double.longBitsToDouble(0x3fec68658205c300L), Double.longBitsToDouble(0x3fec592285e8a205L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477\u3edc\u9ee7\u9066\ud348", "\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25",
        12, 881, 0, 1660944384L, -39453L, true, true, (char) 44420, (char) 29653,
        Double.longBitsToDouble(0x3f8ae41c15aa1e40L), Double.longBitsToDouble(0x3fead79d105eaff8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 3, 15, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477\u3edc\u9ee7\u9066\ud348", "\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda24\udc92\udb39\udd9d\udb40\udf8d\uda6a\ude75\ud8d4\udc0d\ud90a\udf5d\udb7c\uddf0\uda25\udeaf",
        49, 50908, 729709172, 551830056735057373L, -17043L, false, false, (char) 3837, (char) 20566,
        Double.longBitsToDouble(0x3fdc2e7c41aeff6eL), Double.longBitsToDouble(0x3fd2a9701d57b5f4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104\udb7f\ude29\ud898\udf71", "\u3edc\u9ee7\u0ea0\ud2ab\u8340\u0ad7\u80ef\u9332\u16f6", "\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25",
        12, 23705, 1530017681, -1640348174667319090L, -47515L, true, true, (char) 46619, (char) 30927,
        Double.longBitsToDouble(0x3fead79d105eaff8L), Double.longBitsToDouble(0x3fdc2e7c41aeff6eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 0, 14, "\ud9dd\udd54\ud9e0\udcac\u7104", "\ub23b\ud477\u3edc\u9ee7\u9066\ud348", "\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25\udb6f\udc4e\udb6f\udcac\udb7c\uddf0\uda25\udeaf",
        49, 50908, 652153725, 551844805652751837L, -17043L, false, false, (char) 64678, (char) 31666,
        Double.longBitsToDouble(0x3fe9273da0dc01e4L), Double.longBitsToDouble(0x3fd2a9701d57b5f4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104\udb7f\ude29\ud898\udf71\ud9a3\udf44\uda19\udc9d\ud89c\udc6e\uda02\udcde\ud98f\udc0b\ud99f\ude94", "\ud7d9\u458c\u164c\u5bee\u6634\uc4e6\u369e\ubbdf\ucf03\u9bfd\u92e5\uc85a\u03ac\ub74d\u46b6\u573d\uc8a7\u73c6", "\ud99b\uddc7\uda0b\udc60\udae2\ude58\udabd\ude7a\ud9ff\udee4\ud9bf\udf9b\uda57\udea2\ud98d\udef0\udb49\udd48\udbde\udea6\ud9ac\udefb\ud9d6\udfea\udaff\ude06\udac6\udd86\uca92\uda30\udd12\udb48\udc77\udba8\udc95\uda91\ude84\udaae\udc10\ud989\udfb5\ud994\uddae\ud8c4\udd6a\ud8e7\udc40\ud832\ude43\ud8e9\udd3e\udb59\ude55\ud85f\udd18\ud8c6\udf2a\udb18\udf5b\udbcb\udfc3\uda53\udd4a\uda9c\ude0d\udb8f\udc80\ud9c5\udf48\ud811\ude58\uda78\uddd5\u6f51\udaf9\udca1\ud868\ude30\ud941\udf55\uda07\uddb2\uda2c\udeb7\udbd3\udd41\ud827\udd44\ud8cd\udd78\ud833\udd28\uda83\ude8f\udbe9\udda1\ud987\ude1f\ud8a3\udf37\ud88f\udf65\ud859\udcbb\uda4c\udf88\udb96\udd1c\ud8c4\ude87\ud8c5\ude8a\uda55\udffd\udbb0\udd65\ud8d9\udc42\ud80c\udf41\ud828\udebf",
        1, 99937, 1483461402, 439672591682044149L, -66621L, false, false, (char) 98, (char) 42113,
        Double.longBitsToDouble(0x3fd93d7dbc3790baL), Double.longBitsToDouble(0x3fe18b5241055afcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:Other |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 4, 10, 14, "\udbbc\udcab\ud972\udd4f\u7104", "\u1452\ud477\u3edc", "\ud9ae\udc1f\ud96d\ude9a\udbf8\udcdf\u4e74\udbd1\udeb1\uf4b3\udad3\udf44\ud9aa\udd02\udabd\uded0\uda12\udff0\udafe\udc82\ud92b\ude75\uda6a\udea8\uda34\uddd4\ud9f4\udc92",
        -5, 89320, -615802313, -4870353441655441263L, 146L, false, false, (char) 30659, (char) 45771,
        Double.longBitsToDouble(0x3fddd07a8f849826L), Double.longBitsToDouble(0x3f8ae41c15aa1e40L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=192,g=192,b=192] |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 5, 9, 12, "\ud826\udf7e\ud9a6\uddc7\u7104\uda09\uddce\udad9\udd22\udb93\udf3c\uda19\udc9d\ud817\uddcb\udacd\udfeb\ud992\ude2c\ud99f\udec2\ud987\ude61\udbf8\udcdf\u4e74\udbd1\udeb1\ud8f9\ude30\udae6\udf7c\ud93a\udf85", "\ub7f6\ub476\u9b3e\u92e5\u80cc\ub094\u70f3\u46b6\u5d4e\u0587", "\udbcd\udfc0\ud99b\udd60\uda0b\udc60",
        51, 84306, -1468447731, -890920709822866598L, -93282L, true, false, (char) 12877, (char) 14758,
        Double.longBitsToDouble(0x3fe89c3c5272728eL), Double.longBitsToDouble(0x3fe9d064ae243a9cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=192,g=192,b=192] |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 5, 5, 0, "\udbbc\udca9", "\u0710\u922b\u8e15\ud477\u3edc\u6192\u1ed0\ud348\u62dc\u06ba\000\uce23\u164c\u5bee\000\000", "\ud92b\ude75",
        43, 31405, -1909948600, -6771791998292752920L, 94727L, true, false, (char) 23346, (char) 59854,
        Double.longBitsToDouble(0x3fe82318037dc018L), Double.longBitsToDouble(0x3fe80006fddd07a8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 16, 8, "\udbbc\udca9\ud91d\udfad\uda12\ude23\udb7f\ude29\ud898\udf71\ud9a3\udf44\udbad\udcc6\ud89c\udc6e", "\ud348\u97e5\u06ba\ud7d9\u458c\u823f\u5c62\u6634\u9e88\u16be\uc00c\u3c73\u9bfd\u92e5\u5c08", "\ud8d4\udc0d\ud90a\udf5d\udb7c\uddf0\uda25\udeaf\ud986\udf7a\ud8a7\ude42\ud99b\uddc7",
        31, 18061, 1913530306, -7531914079382613930L, -34249L, false, true, (char) 14758, (char) 31832,
        Double.longBitsToDouble(0x3fd078c9b18f9732L), Double.longBitsToDouble(0x3fcd7dd493ac20fcL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.chart.util.TableOrder:TableOrder.BY_COLUMN |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 6, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\ucee3\u340f\u23ab", "\ud99f\ude94\ud96d\ude9a\udbf8\udcdf\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\udbbb\udc2f\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25",
        37, 59473, 1530064017, -1640348171597088562L, -39453L, true, true, (char) 44420, (char) 29653,
        Double.longBitsToDouble(0x3f8ae41c15aa1e40L), Double.longBitsToDouble(0x3fead79d105eaff8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 0, 13, 7, "\000\000\000", "\u00fb", "\uda02\udcde",
        16, 41318, -413249522, 5492681126207089416L, -30345L, false, false, (char) 0, (char) 198,
        Double.longBitsToDouble(0x3d33e80000000000L), Double.longBitsToDouble(0x3fe9580004f3b015L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 6, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\u6785\u6464\u2b3a\u9066\ud348\u62dc\u06ba", "\ud815\ude07\uda95\udd24\ud948\ude88\udbb8\udd36\uda12\udff0\udb70\udd05\ud952\udc1c",
        43, 31405, -90472632, -6771845754103429656L, -32602L, true, false, (char) 43833, (char) 25099,
        Double.longBitsToDouble(0x3fe8231ff37dc018L), Double.longBitsToDouble(0x3fef6936fddd0799L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 8, 8, 14, "\udbbc\udca9\ud9e0\udc4f\u7104", "\u8e15\ud477\u3edc\u9ee7\u9066\ud348", "\u4e74\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc0d\ud90a\udf5d\ud89f\udec2\uda25\udeaf",
        49, 50908, 652153725, 551844805652751837L, -17043L, false, false, (char) 3837, (char) 20566,
        Double.longBitsToDouble(0x3fdc2e7c41aeff6eL), Double.longBitsToDouble(0x3fd2a9701d57b5f4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 0, 14, "\udba9\udfe0\ud819\udeba\uda01\ude4b", "\u1dbf\ud477\u3edc\u9ee7\u9066\ud348", "\udbdb\ude77\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud8e4\ude4e\ud89d\udd95\uda5e\udf25\ud8d4\udc0d\ud90a\udf5d\uda16\udf1d\ud973\ude76\uda29\ude92\udb7b\udf3f\ud976\udec2\uda0b\udc60\udae2\ude58\ud8e8\udd3e\ud9ff\ude94\ud9bf\udff4\uda9e\ude04",
        8, 42178, -1761541929, -2667778964803658069L, -73228L, false, true, (char) 43136, (char) 57587,
        Double.longBitsToDouble(0x3fb46649900cdf00L), Double.longBitsToDouble(0x3fa1d1a6a7ec2ab0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 7, 3, 11, "\udbb2\ude3f\ud9e0\udc4f\u7104", "\u8e15\ud477\ucb99\u55b0\u5e39\ud3dd", "\u4e74",
        47, 93106, 1383062074, -6286237172517842957L, 37347L, false, true, (char) 34702, (char) 59196,
        Double.longBitsToDouble(0x3fea47cc530e8e28L), Double.longBitsToDouble(0x3fe745102f60935fL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.chart.JFreeChart:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=org.jfree.chart.JFreeChart:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 10, 10, 6, "\udbc2\udfa2\ud9e0\udc4f", "\u922b\u8e15\ud477\u3edc\u6fe8\u07cf\ud39d\u62dc\u06ba\u22e5\u1791\u164c\u5bee", "\udbcb\udf4d\udafe\udc82\ud92b\ude75\ud9bf\uddb2\ud9e3\udee2\ud861\udc88\ud955\udcb7\uda3e\ude56\ud8d4\udc0d",
        18, 49953, -372968739, 7205329281515393796L, -60369L, true, true, (char) 47829, (char) 46614,
        Double.longBitsToDouble(0x3fb5aa1e5ad79d10L), Double.longBitsToDouble(0x3fb7abfe2e173e20L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\u7104\udb7f\ude29\ud898\udf71\ud9a3\udf44\uda19\udc9d\ud89c\udc6e\uda02\udcde\udbf0\udf3b\ud814\udd91\ud95d\udc7d\ud88f\udecc\u4f3e\udbd1\udeb1\ud9f9\udcd1\udaaf\udf15\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud92b\ude75\ud9bf\uddb2\uda34\ude2b\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc0d\ud90a\udf5d\udb7c\uddf0\uda25\udeaf", "\u118f\u8d00\u9007\ub6ef\u5450\u81ae\u847f\u9ba5\u5521\u4e79\ua745\u720c\u8877\u4516\u86a8\ud1cc\u5840\u13aa\ua494\ub031\u1ff3\u7f10\u67d2\u6a3e\u0b00\u191e\ud73d\u64b9\u364f\u52bd\u2608\u3611\u1484\u670c\ua9c8\u9f5c\u9d01\u1313\u9181\u2e1f\u3dc4\u6933\u9c69\ud11e\u7951\uc3da\u1681\u4d7f\u8670\ua8f3\ubc36\u38a0\u826f\u4fce\u3977\uc6f9\u0d1a\u5bc8\ubc9f\u93c7\ub1b6\u1b36", "\uda20\udcf4\udb46\udd00\ud813\udebe\ud873\udd28\ud80d\uddb7\ud925\udef2\uda0f\udc5e\ud9bb\udd8c\udbaa\udf2e\ud8de\uddd5\ud805\udcc4\udb50\udefb\ud9a6\udefb\uda20\udc81\ud840\ude4f\ud969\udeed\uda66\udec4\udbeb\udf85\uda1f\udc6f\ud9e9\ude3f\udaed\udd4a\ud990\ude0a\udadf\udf31\udb9f\udf8b\uda08\ude6d\uda22\udc2f\udb15\udc98\udad7\udf2a\ud96d\udc51\uda89\udcbc\ud9c7\udfae\ud90e\udd4a\ud822\udf2c\udad8\udf9c\ud992\udf1b\uda5d\udee0\ud8e1\udcca\ud829\ude83\uda4d\udffc",
        35, 89219, -183830058, -2745735653385606564L, 54373L, false, false, (char) 59223, (char) 64554,
        Double.longBitsToDouble(0x3fdfa30d0b9e59c2L), Double.longBitsToDouble(0x3f9cc5288569ad60L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 0, 0, "\udbbc\udca9", "\u0710\035\u8d1a\ud477\u308e\u9ee7\u98d7\000\u12ce\u06ba\ud7d9\u458c\u164c\ubb6a\u6634\u00c6", "",
        -5, -1000, 0, -1576730624L, -99945L, false, false, (char) 43153, (char) 43833,
        Double.longBitsToDouble(0x3fc9dd278c118ff8L), Double.longBitsToDouble(0x3febee00c3ed26dfL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 7, 0, 14, "\ud821\udf08", "\u7952\u9690\u8e15\ud477\u3edc\u9ee7\u9066\ud348\u62dc\u06ba\ud7d9\u458c\ub51c\u6549\u6634\ua875", "\ud9f3\udf02",
        43, 31447, 438861650, 5524718890373716318L, 41250L, true, false, (char) 30927, (char) 49092,
        Double.longBitsToDouble(0x3fb7abfe2e173e20L), Double.longBitsToDouble(0x3fcaeff6f4aa5c04L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 1, 0, 0, "", "\ud1a7\u0710\u922b\u8e15\u5777\u3edc\u9ee7", "\000\000",
        19, 62099, 0, 1381629952L, 89493L, true, true, (char) 45054, (char) 45077,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe8000005e8a205L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 14, "\udbbc\udca9\ud9e0\udc4f\u70cd\ud855\uddd3\ud851\udf0c\udbe7\udff5\udaa4\udc06", "\000", "\udbf8\udcdf\u4e74",
        -5, 27674, 52056, 5934280416357013958L, -7433L, false, true, (char) 18617, (char) 20790,
        Double.longBitsToDouble(0x3e751bac00000000L), Double.longBitsToDouble(0x3fe80d89b491bc69L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:Other |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 4, 13, 14, "2", "\u0710\u922b\u8e15\000\000\u3d55\000\000\u925e\u8ca6\ud7d9\000\000\000\u6634\000", "",
        -1, -1000, -108396544, 309237972992L, -29489L, true, false, (char) 25099, (char) 30466,
        Double.longBitsToDouble(0x3febee00c3ed26dfL), Double.longBitsToDouble(0x3fddd07a8f849826L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\035",
        -5, -1000, -1342177280, -637486516683145216L, -100000L, false, false, (char) 60216, (char) 14864,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc3200007194968L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jfree.chart.JFreeChart:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 10, 0, 14, "\ud87d\udd4a\ud9e0\udc6f\u70cd", "\uc217\000", "\uda82\udd13\uda4c\ude63",
        1, 32194, 1388725702, 9848982779985920L, -21305L, true, true, (char) 57562, (char) 62975,
        Double.longBitsToDouble(0x3fe95aa698000000L), Double.longBitsToDouble(0x3e4ecbe628000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 1, 0, 13, 16, "\udbbc\udc77\ud9e0\udc4f\u70cd", "", "",
        -5, 29960, 0, -419430400L, -39832L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc3200007194968L), Double.longBitsToDouble(0x3fee5fb42383027dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 3, 14, 10, "\udbb0\udf58\ud9e0\udc4f\u70cd", "\u8dfe\u4000\ud12e\u9ee7\000\000", "\u4e74\000\000\000\ud9aa\udd73\udbad\udcb6\uda12\udff0\udafe\udc82\ud877\udf5a\000\ud9fd\udf9e\ud9f4\udc92\uda0c\uddc9\uda61\udd2f",
        12, 48313, 1530064017, -4666766842550673478L, -39453L, true, true, (char) 44331, (char) 29653,
        Double.longBitsToDouble(0x3f8ae41c002a1e40L), Double.longBitsToDouble(0x3fbb000002f57800L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:Multiple Pie Plot |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 15, "\udbbc\udca9\udb8a\ude5b\u7104\udaa0\udd18\udb41\udf46\ud9a3\udf44\uda19\udc9d", "\ubc15\uc293", "\udb30\udd0f\ud86a\ude62\ud9f9\udcd1\udaaf\udf15",
        9, 76574, 425270731, 6107958278062755371L, 14572L, false, true, (char) 12027, (char) 10221,
        Double.longBitsToDouble(0x3fe1bac76f59db4bL), Double.longBitsToDouble(0x3fc2378d201d6d50L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 1, 0, 13, "\udb42\udd36\ud80d\udc7c\udb94\ude0e\udb7f\ude29\ud88e\udf8f\ud9f9\udd7c\u1545\udb0d\udc25\uda02\udd00", "\u0b09\u06ba\ud7d9\u458c\u3b28\u2ca6\u6634\ucc75\u09bf\uc00c\u9227", "\ud9f4\udc92\ud89d\udd84\uda5e\udf25\udbb4\udda6\ud92f\udd6a\udb7c\uddf0\ud9c1\udc1c\uda68\udef2",
        15, 37771, 1419288770, 4823022008959908096L, -70736L, false, true, (char) 20566, (char) 29703,
        Double.longBitsToDouble(0x3fcaed3894aa5c04L), Double.longBitsToDouble(0x3fea4ed7d627e7d1L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:Other |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 15, 14, "\uda63\udc62\ud80d\udc8d\udb94\ude0e\udb7f\ude29\ud88e\udf8f\ud9f9\udd7c\u1545\udb0d\udc25\uda02\udd00", "\u0b09\u06ba\ud7d9\u578c\ub38b\u2ca6\u6634\u12d0\u5839\u4aca\u8b0b", "\ud9f4\udc92\ud89d\udd84\uda5e\udf25\ud8d4\udc57\ud90a\udf5d\udac0\uddd2\ud9ce\udc52\uda5f\udf29",
        -1, 37771, 1419288770, 4823022008959908096L, 49840L, false, true, (char) 20566, (char) 52614,
        Double.longBitsToDouble(0x3fcaeff6f4aa5c04L), Double.longBitsToDouble(0x3fe956d7d0134531L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 14, 15, "\000\ud80d\udc28\udb94\ude0e\udb7f\ude29\ud88e\udf8f\udbb2\uddd8\u1460\udb0d\udc25\ud8be\udcfe", "\ub0aa\000\000\u458c\ub38b\u2ca6\u6634\ucc75\ud3bd\uc00c\u0204", "\ud9f4\udc92\000\000\000\ud909\udc04\udb7c\uddf0\ud9c1\udc1c\uda68\udef2",
        -5, -1000, 0, -1275985920L, -70736L, false, false, (char) 45048, (char) 0,
        Double.longBitsToDouble(0x3fcaeff6f4aa5c04L), Double.longBitsToDouble(0x3fea4ed7d0134531L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 14, "\udb27\udf1f\ud80d\udc7c\udb94\ude0e\udb7f\ude29\ud88e\udf8f\ud9f9\udd7c\u1545\udb0d\udc25\ud8f6\ude04", "\u0b09\u06ba\ud7d9\u458c\ub38b\u2ca6\u6634\ucc75\u16be\uc00c\u9227", "\uaf48\ud9e6\udc68\uda65\udf86\ud8d4\udc57\ud90a\udf5d\udaf8\uddcd\ud9c1\udd4f\ud937\udf5a\uda4c\udf3f\uda35\ude0a\ud8e3\uddbe\udb19\udce8\uda57\udc84\ud8a2\udfda\uda75\udc7b\uda57\udea2",
        25, 42338, 262226647, -1480950987887672503L, 26830L, true, false, (char) 52621, (char) 56598,
        Double.longBitsToDouble(0x3fc7cb6775f0b10cL), Double.longBitsToDouble(0x3fd4add28486b3c2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=new org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 1, 1, 14, "\ud93a\udf69\udb95\udf02\udb94\ude0e\udb68\udd7d\ud8bf\udf0f\udad1\udddb\u1545\udb0d\udc25\uda02\udd00\ud973\udf6b", "\uc5fe\u9266\u458c\u28a2\ucda5\u2515\u6c50", "\ud9e8\udd6b\udb19\udfef\uda0a\udeeb",
        20, 29310, 1491961320, -2644850478442543271L, -79513L, false, true, (char) 36691, (char) 8479,
        Double.longBitsToDouble(0x3fc85c15e3dd5260L), Double.longBitsToDouble(0x3fd0042eeebb0be4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.MultiplePiePlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 7, "\udb27\udf1f\ud80d\udc7c\udb94\ude0e\udb7f\ude29\ud88e\udf8f\ud9f9\udd7c\u1545\uda43\udc20\udb05\uddc2\ud969\udc53\ud99f\ude94", "\ua897\u44e2\ub38b\u2ca6\u6634\ucc75\u16be\uc00c\u9227\uc4c1", "\ud889\udfc1\uda5e\udf25\ud8d4\udc57\ud90a\udf5d\udb7c\uddf0",
        57, 85690, -1992150465, -2256417885656670014L, 45664L, true, true, (char) 39805, (char) 16430,
        Double.longBitsToDouble(0x3fb7abfe28a18620L), Double.longBitsToDouble(0x3fe0afadbd2a9701L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=null |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 7, 7, 12, "\ud826\udf7e\ud9a6\uddc7\u7104\uda09\uddce\udad9\udd22\udb93\udf3c\uda19\udc9d\ud817\uddcb\udacd\udfeb\ud992\ude2c\ud99f\udec2\ud987\ude61\udbf8\udcdf\u4e74\udbd1\udeb1\ud8f9\ude30\udae6\udf7c\ud93a\udf85", "\ub7f6\ub476\u9b3e\u92e5\u80cc\ub094\u70f3\u46b6\u5d4e\u0587", "\udbcd\udfc0\ud99b\udd60\uda0b\udc60",
        51, 84306, -1468447731, -890920709822866598L, -93282L, true, false, (char) 12877, (char) 14758,
        Double.longBitsToDouble(0x3fe89c3c5272728eL), Double.longBitsToDouble(0x3fe9d064ae243a9cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 8, 8, 12, "\ud826\udf7e\ud9a6\uddc7\u7104\uda09\uddce\udad9\udd22\udb93\udf3c\uda19\udc9d\u6b64\ud948\udff7\udbde\udfce\ud866\udc64\ud987\udd9d\udac1\udf14\ud9c3\udd31\ud9c0\udf53\ud8f9\ude30\udae6\udf7c\ud93a\udf85", "\u3cf9\u4380\u7c6a", "\ub15b\ud980\uddc6\udb95\uded2\ud94c\uddcf\uda8a\ude13\uda58\udf1c\udb5e\udcec\udbcd\udfc0\ud99b\udd60\ud8f7\udcb7\udae1\udf6a\udb63\udc1f\ud9ff\udee4\udb72\uddde\uda57\udea2\ud843\udeeb\udb49\udd48\ud83e\udd95\ud9b3\udc84\udaa3\udf91\udb0c\ude2d",
        38, 61362, 1121241274, 295057304298871128L, 86093L, false, true, (char) 49681, (char) 40520,
        Double.longBitsToDouble(0x3fb5199ca835f650L), Double.longBitsToDouble(0x3fdcbffad3d19fc2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 3, 3, 0, "\ud826\udf7e\ud9a6\uddc7\u7104\ud8c0\udc29\udad9\udcc2\ud911\udd62\uda31\ude69\ud958\udc3d\uda92\udcea\uda03\udf85\ud99e\udceb\udb40\udc3d\udbf6\udd8f\u4e74\udbd1\udeb1\ud8f9\ude30\udae6\udf7c\ud93a\udf85\udbbc\udc3a\ud90a\udc9e", "\u3a24\u2fd7\u2992\u0dd3\u8799\u7d93\u7f65\u05fc\u7207\u2d7c\ua24f\u1a90\u8d00\u8ff8\ub6ef\u1d50\u81ae\u847f\u9ba5\u5521\u67c6\ua9d1\u0438\uc0d8\ua480\uacb1\u1cd2\u0bc3\uba65\u8cb8\ubf5e", "\ud819\ude55\ud80a\udcc5",
        12, 14664, 1993497648, -849743404869389632L, 6261L, true, false, (char) 55396, (char) 33100,
        Double.longBitsToDouble(0x3fafe60037be9400L), Double.longBitsToDouble(0x3fdd49ef45c25934L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=void |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 14, 14, 3, "\udbbc\udca9\ud9e0\udc4f\u70cd\ud855\udd66\ud851\udf0c\udbe7\udff5\ud825\udce7", "\000\uca0c", "\u4701\000\udbcd\udce5\ucb58\ud9aa\udd73\udbb8\udd36\uda12\udff0\udafe\udc82\ud8bb\udef7\ud9fe\uddb5\u1948\ud9de\udd53\ud932\udf0e\uda61\udd2f\ud95d\udd92\udbea\udf54\ua5c3\udb05\udd11",
        -3, 92029, -1643750867, -9153939952796287964L, 34644L, false, true, (char) 27630, (char) 54623,
        Double.longBitsToDouble(0x3fc2317b6137b134L), Double.longBitsToDouble(0x3feeb709779f29d5L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jfree.chart.util.TableOrder:TableOrder.BY_COLUMN |this=org.jfree.chart.plot.MultiplePiePlot:@?\0121=org.jfree.chart.util.TableOrder:TableOrder.BY_COLUMN |this=org.jfree.chart.plot.MultiplePiePlot:@?\012",
        Z.run(T, 2, 6, 6, 13, "\udbd3\udde6", "\u6a45\u4050\u3bef\ubcca\u71ed\u1e151\ua767\u30d4\u06ba\ucd9c\ud7b8\uc771\u7fcb\u65a2\u9e88", "\udbfa\udee9\uda07\ude3d\udbd6\udf10\ud9de\udd53\ud932\udf0e\udaaf\udc76\ud953\udec5\uda1c\udefd\ud223\ub98a",
        55, 8811, -1704828048, -1150221680283732336L, -39513L, false, true, (char) 16392, (char) 40479,
        Double.longBitsToDouble(0x3fee0b080f35408fL), Double.longBitsToDouble(0x3fdec4740f9ef016L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 14, "\udbbc\udca9\ud9e0\udc4f\ud99f\udd65", "\u8e15\ud477\u3f9c\u9ee7\u9066\ud348\u62dc\u06ba\ud7d9\u9122\u164c\u5bee\u6634\ucd4f\u16be\uc00c\u3c73", "\ud9f4\udc92\udba9\udc3d",
        45, 94687, -1133967527, 6571574913419464711L, -99119L, false, true, (char) 36379, (char) 60798,
        Double.longBitsToDouble(0x3fee12609c0d720eL), Double.longBitsToDouble(0x3fe7be03cb5a60d9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|",
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|org.jfree.data.category.CategoryDataset",
    "M|org.jfree.chart.plot.MultiplePiePlot|draw|java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Point2D,org.jfree.chart.plot.PlotState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|equals|java.lang.Object|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getAggregatedItemsKey||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getAggregatedItemsPaint||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getDataExtractOrder||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getDataset||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getLegendItems||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getLimit||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getPieChart||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|getPlotType||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|prefetchSectionPaints||new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|readObject|java.io.ObjectInputStream|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|setAggregatedItemsKey|java.lang.Comparable|new:org.jfree.chart.plot.MultiplePiePlot:",
    "M|org.jfree.chart.plot.MultiplePiePlot|setAggregatedItemsPaint|java.awt.Paint|new:org.jfree.chart.plot.MultiplePiePlot:",
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|",
    "C|org.jfree.chart.plot.MultiplePiePlot|<init>|org.jfree.data.category.CategoryDataset",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
