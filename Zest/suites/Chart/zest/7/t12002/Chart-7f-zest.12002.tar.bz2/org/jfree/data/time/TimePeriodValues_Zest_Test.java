package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimePeriodValues_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\udbaa\udc76", "\u4782\ud628", "\ud9be\udc34",
        33, 2181, 1831393719, 6486680610993211897L, -25253L, true, true, (char) 6475, (char) 14757,
        Double.longBitsToDouble(0x3fe98ef1feaca128L), Double.longBitsToDouble(0x3fcdcaeee56a4cc4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 0, 0, "\ud84d\udf02\ud904\ude4e\ud938\ude87\udb6e\udd0a", "\024\u4495", "\ud9ce\udf1b\udbdd\udc5c\udb6f\udee1\udb56\udc25\ud85a\udd88\ud9ad\udfaa\ud86b\udd85\ud954\udc40\ud802\udfe5\ud98a\udd63\udaca\udf98\ud85b\udf85\ud8f6\udf85\ud9d3\ude84\udb25\udf3b\ud86b\udf35\ud9d3\udf49\udb2b\udeb0\udae1\udca1\ud8c3\udd51\ud8f5\udfa9\ud8ed\ude38\udbae\udd02\udafe\udc56\udbe3\udde9\ud971\udc85\udb4a\ude56\ud802\udf68\ue5f7\ud995\udde5\ud9a6\udd46\udbe3\ude60",
        8, 64028, 221708974, 118464956997581641L, 49167L, true, false, (char) 15792, (char) 35892,
        Double.longBitsToDouble(0x3fe352a5b6d88788L), Double.longBitsToDouble(0x3fd887737b9cc736L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 12, 0, "\udb88\ude3f\ud904\udefc\uda39\ude49\udbaa\udc76", "\u879c\u9490", "\ud9be\udc34\ud9c6\udc04",
        46, 60719, 1510298022, -3050614830594523471L, 98301L, true, true, (char) 14757, (char) 1393,
        Double.longBitsToDouble(0x3fe5650944ee5777L), Double.longBitsToDouble(0x3fd5a93314aa9d32L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 12, 0, "\ud84d\udf02\ua285\uda39\ude1b\udbaa\udc76", "\u4782\ud628\u18fb\u1040\u8eac", "\udb56\udc25\ud833\udef4\ud905\udf7a\ud86b\udd85\ud954\udc40\ud9b9\uddbf\uda38\udeec\udb3d\udc74\ud85c\udd9a\uda4a\udfd3\ud9d3\ude84\ud978\udc63\udb23\udff9\udaac\udff5\ud9cd\udd73\udbdf\uddc3",
        27, 72348, -1007858705, 8834519641683405723L, -91158L, true, true, (char) 16575, (char) 28122,
        Double.longBitsToDouble(0x3fddd90dcdf9dc56L), Double.longBitsToDouble(0x3fe235272da1938dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 1, 5, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\uf11e", "\u4782\ud628", "\ud9be\udc34",
        33, 2181, 1831393719, 6486680610993211897L, -25253L, true, true, (char) 6475, (char) 51034,
        Double.longBitsToDouble(0x3fe7865e05c7c82bL), Double.longBitsToDouble(0x3fece1f063682779L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 12, 0, "\ud84d\udf02\udab7\udca7\uda2f\udee2\udbaa\udc76", "\u4ce6\ud63b", "\udb87\ude41\ud9df\udfab\ud888\ude5b\udb56\udc25\ud833\udef4\ud905\udf7a\ud86b\udd85\ud954\udc40",
        17, 65003, -566239559, 8658213375860564735L, 9835L, false, false, (char) 16474, (char) 21536,
        Double.longBitsToDouble(0x3fdb0bde3c1e98faL), Double.longBitsToDouble(0x3fe492bc907b96e3L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 12, 0, "\u94ef\000\000\000", "\u4782\ud628", "\ud9be\udc34",
        33, 2965, 0, 6486680610993211897L, -25253L, true, false, (char) 18944, (char) 0,
        Double.longBitsToDouble(0x3fe98ef1feaca100L), Double.longBitsToDouble(0x3fcdcaeee56a4cc4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\udbaa\udc76\ud8b0\udd48", "\ud628\ua00b\u1040\u4e4c\u7a2e\u905c\u5b17\u6457\u14d8\ud006\u00fc\u9918", "\ud85c\udd9a\uda4a\udfd3\ud9d3\ude84\ud918\uddb4\ud920\udd8a\uda93\uddab\udb48\udf6d\udb18\udc02\uda4a\udec4\ud853\udc13\ud93b\udda8\udb08\udedd\udb87\uddce",
        14, 18402, -655556232, -291575033148448164L, 64445L, false, false, (char) 55252, (char) 16711,
        Double.longBitsToDouble(0x3fe09833e1818383L), Double.longBitsToDouble(0x3fe187dd1503907fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 12, 0, "", "\u1d6c", "\uda48\udf93\udb64\uddf1",
        9, 69120, 465975125, -8313258978859868506L, -44265L, false, false, (char) 2304, (char) 54363,
        Double.longBitsToDouble(0x3fcf6e6000000000L), Double.longBitsToDouble(0x3fb2c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\udbaa\udda3", "\u4782\ud628", "\ud9be\udc34",
        33, 2003, 1831393719, 6486680610993211897L, -25253L, true, true, (char) 6475, (char) 14757,
        Double.longBitsToDouble(0x3fe98ef1feaca128L), Double.longBitsToDouble(0x3fcdcaeee56a4cc4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 1, 15, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\udbaa\udc76\ud888\ude5c\uda48\udf93\ud890\udda5", "\u1040\u4e44\u7a2e\u905c\u5b17\u6457\ua7cb\u2935\uaa60\u9918\ub30e\u8eb8\u4ec8\u8c43\uaec2\u17ae\ud1a0\u168b\u0847\u4991\u953e\u6684", "\udb80\udd4d\ud8c4\udc5c\udbf6\udd08\uda93\udd60\ud88d\udedf\ud9a6\ude70\ud825\uddf4\udbef\udece\udac8\ude8b\ud856\ude17\ud967\uddc3\ud86d\ude04",
        17, 16069, -986753927, -6005374102815210608L, 7752L, false, false, (char) 15856, (char) 46432,
        Double.longBitsToDouble(0x3fd09e0da2f348b0L), Double.longBitsToDouble(0x3fc4e03261187f80L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 12, 14, "\ud84d\udf02\ud904\ude4e\ud809\udf10\uda82\udc63\ud8b0\udd48", "\ud628\u18fb\u6e10\u4e44\u7a2e\u0548\u742a\u6427\ua7cb\u1852\u70f2\u9918", "\ud85c\udd9a\ud906\udef1\ud97c\udd32\udb76\udcb9\udb66\udc38\udafd\udc5f\ud9c1\udeb2\ud87b\uded0\uda91\udd59\uda8b\udc8e\ud956\udf11\ud963\udf2a\u9b1a",
        -3, 53040, -164143275, -3699805705263981416L, -87956L, true, true, (char) 57414, (char) 44414,
        Double.longBitsToDouble(0x3fe81b1ffb21af64L), Double.longBitsToDouble(0x3fe998b7f20c545cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 10, 12, 0, "\ud84d\udf02\uda12\ude55\uda81\udd40\udbd4\udd63", "\u316d\ud628\u18fb\u0679\u4e60\u7a2e\u905c\u5b17\ub78a\ua7cb\ud006\u8472\u9918\ub30e\u8eb8\u4ec8", "\udbf8\udc64\udaae\ude11",
        30, 27454, 350855404, -5124203401602301860L, -8471L, true, true, (char) 25050, (char) 55085,
        Double.longBitsToDouble(0x3fc699c22e6abf8cL), Double.longBitsToDouble(0x3fe26598b63f20eaL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 1, 7, 12, 0, "\ud84d\udf02", "\u5f48\u3bf6\u70bf\u4782", "\ud97e\ude6d\ud9be\udcf9\ud9c6\udc04\udaa5\udf4a\udaf1\uddc3\ud833\udef4\ud905\udf7a\ud836\udc85\ud954\udc40\uda0d\udf29\udbb2\uddad\ud875\ude1a\udaa8\uddac\ud810\udce9\udb8a\ude9f\ud879\udf0f\ud852\udc9b\ud941\uddac\udb5b\udf41\ud96c\udfa6\uda02\ude9e",
        44, 10070, 863577389, -8302559668332395377L, 89454L, true, false, (char) 61220, (char) 63857,
        Double.longBitsToDouble(0x3fe1aa3099f2b2b7L), Double.longBitsToDouble(0x3fe5ad6de3d3d60fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 12, 0, "\ud863\udd70\ud904\ude4e\ud915\udf77\udb86\udc44", "\u4782\ub1bb\u1914", "\ud98a\udebb\ud888\ude5b\udb56\udc25\ud833\udef4\udb61\ude51\udaa9\udca5\udb7c\udfb7\ud9c1\udcec\udaed\udca6\udb3d\udcbb\ud85c\udd9a\uda4a\udfd3\ud84b\udf8f\udb09\udd36\uda6f\udc39\udbe7\ude70\udb12\udeda\ud999\udcd2\ud9e9\udd4e\uda05\udfe7\udbf2\udd1e\udb53\uddd9\uda8b\udc56\ub520\udb44\udf4d\ud904\uddb2\udaf4\uddcd\udb6d\udeb8",
        24, 80810, -893859231, 6218073595579361457L, 61427L, true, true, (char) 36602, (char) 7505,
        Double.longBitsToDouble(0x3f977691b82a6820L), Double.longBitsToDouble(0x3fea5a62554300ceL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 14, 0, "\ud84d\udf02\ud904\ude4e\ud887\ude2f\udbb0\ude1b", "\u4782\u7087", "\ud9be\udc34\ud9c6\udc04\ud9c5\udfe4\ud8ea\ude50\ud833\udef4\ud905\udf7a\udaaf\udd08\udab7\ude2a\ud885\udc2b\ud8ad\ude93\ud92b\udcfd\ud85c\udd9a\uda4a\udfd3\ud9d3\ude84\ud96b\ude3e\udbfb\uded2\udb9d\udfe5\uda38\udc2e\udbfa\ude49\ud977\udea6\udb17\ude3f\udb13\udc56\udbf4\udf11",
        8, 91689, -415972500, 1252851474548767206L, 39084L, false, true, (char) 307, (char) 25356,
        Double.longBitsToDouble(0x3fd415e84a314d74L), Double.longBitsToDouble(0x3fd0f0b079d61abcL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 1, 4, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\ud95e\udf22", "\u17d4\ud628", "\ud9be\udc34",
        33, 2181, 1831393719, 6486680610993211897L, -25432L, true, true, (char) 53578, (char) 17625,
        Double.longBitsToDouble(0x3fe989b996aca128L), Double.longBitsToDouble(0x3fcdcaeee56a4cc4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 0, 0, "", "\u0897\u5148\u3bf6\u70bf\u5faa\ud628\u18a3\u1040\u4e44\u7a2e\u905c\u5b17\u6457\ua7cb\ud006\u00fc", "\udb3d\udcbb",
        30, 79836, -1825465106, -6810980465775041283L, -17742L, true, true, (char) 44271, (char) 20293,
        Double.longBitsToDouble(0x3fdfe231a8f3841cL), Double.longBitsToDouble(0x3fe20e52ced3cb20L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 10, 2, "\ud8e4\ude6a\ud904\ude4e\uda39\udea3\ud927\ude58", "\u4782\ud628\u18fb\u759e\u4e44\u7a2e\u8f7e\u5b17\ucd39", "\ud954\udc40\ud957\udf8f\udaed\udc62\udb3d\udcbb\ud860\udf9a\uda16\udfd9",
        24, 14418, -1298785295, -1479736834661125588L, 57905L, false, true, (char) 50389, (char) 47052,
        Double.longBitsToDouble(0x3f9f9cb02b93bb20L), Double.longBitsToDouble(0x3fc1dd5b94a216dcL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 8, 6, "\ud84d\udf02\ud904\ude4e\ud8dd\udda0\udbe4\udf48\ud896\udd48\udb8a\uddeb\udaa8\udd11\udbed\ude38\uda51\udfc6\ud81d\udd86\ud9be\udc34\ud99a\udc8f\ud888\uddfb\udbe7\udf26\uda1f\ude59\uda37\udef8\udb69\udc3a\udbb0\udf19\ud80a\udfbf\udb2b\udfd1\udb33\udfe5\ud85c\udd9a", "\u27e2\u643a", "\ud873\udfe6\ud9f3\udcc5\udb12\udf33\uda66\udea8\uda20\udf5d\ud9a5\udc42\ud854\ude32\ud94c\ude1b\uda34\udca6\uda8a\udc09\udafe\ude42\ud985\udde7\ud9e1\udc00\udac3\udfbf\udad9\udec0\ud944\udfb8\uda3e\ude4b\ud8a6\udc45\udae4\udd86\ud9f4\udc71\udb56\udec1\ud964\udd10\ud8bd\ude6b\ud93c\ude64",
        4, 44795, 863169274, -1332742076704583157L, 69639L, true, true, (char) 58213, (char) 17649,
        Double.longBitsToDouble(0x3fdd231171c9a50cL), Double.longBitsToDouble(0x3fd1125c23fc8fa6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 11, 9, "\ud97f\ude46\ud904\ude81\uda39\ude49\udbaa\udc76\udac5\ude5e", "\uc05f\u195b\u1040\u4e44\u7a2e\u905c\u5b17\u6457\ua7cb\ud006\u00fc\u9918\ub30e\u8eb8\ua65e\u0657\uabf8\u74f5\u9fa7\u8ee2\u2c24\u3ef9\uba5f\u592b\u8251\u3c67\u8a5e\u730c\u6ba9\u7b94\u6309\u9aa3\u55b9\ud76b\u4463\u3fe4\u5612\ubbdb\u866a\u2ffe\u4759", "\uda32\udf2c\uda92\uddf4\ud91d\udddb\udb78\ude11\udb88\udd2a\udb08\udc2f\ud918\udc2d\udb23\uddc9\ud996\udc07\ud8a0\udee4\ud8f6\udf0f\udbb6\ude61\udade\udcd3\ud8fd\ude9f\udaf9\udc74\udbe4\udf85\ud252\ud83e\ude35\udb92\udcdf\udb5c\udd1b",
        19, 46834, -1160689114, 585863269612246210L, 53035L, true, false, (char) 63805, (char) 54014,
        Double.longBitsToDouble(0x3fe1bfa260265ca8L), Double.longBitsToDouble(0x3fe1340195069761L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\ud84d\udf02\ud904\ude4e\ud938\ude87\udb51\udd1b", "\024\u4495", "\ud9ce\udf1b\udbdd\udc5c\udb3c\udc7e\udb56\udc25\ud85a\udd88\ud9ad\udfaa\ud86b\udd85\ud8c2\udcd7\udb1c\udc8c\ud98a\udd63\udaca\udf98\ud85b\udf85\ud8f6\udfd2\ud9d3\ude84\udb25\udf3b\ud86b\udf35\ud9d3\udf49\udb2b\udeb0\udae1\udca1\ud8c3\udd51\ud8f5\udfa9\ud8ed\ude38\udbae\udd02\udafe\udc56\udbe3\udde9\ud970\udfd2\udb58\ude9e\ud802\udf68\ue5f7\ud995\udde5\ud9a6\udd46\udbe3\ude60",
        32, 8656, 1664549575, -8477461337390394927L, 12977L, true, false, (char) 15792, (char) 35892,
        Double.longBitsToDouble(0x3fe352a5b6d88788L), Double.longBitsToDouble(0x3fd887737b9cc736L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 12, 5, "\ud84d\udf02\ua285\uda39\ude1b\udbaa\udc76\uda58\udebd\uda72\udddb\ud890\udda5\ud9d0\udf81\udafc\udd3c\u50f8\uda88\udc39\ud9c6\udc04\ud888\ude5b\udb56\udc25\ud833\udef4\ud905\udf7a\ud86b\udd85\ud954\udc40\ud9b9\uddbf\ud87c\udc6f\udb3d\udc0e\ud85c\udd9a\uda4a\udfd3\ud9d3\ude84\ud978\udc63\udb23\udff9\udaac\udff5\ud9cd\udd73", "\u454d", "\ud897\udcc1\udba5\udeb5\ud930\udd9d\ud849\udf42\ud998\uddee\ud919\udc12\udbf3\udccf\uda14\udd9d\udb86\udfda\ud974\udd31\uda49\udc73\ud8a1\udfbd\ud8ef\udcac\ud900\udee0\ud9d7\udd58\udbaf\udf7b\ud833\udca3\udb94\udd61\udb70\udcd1\ud8fc\udfba\ud879\udf09\ud940\udf41\udae9\udeac\ud9b9\udced\ud8db\udf4a\ud928\udce4\ud891\udd67\udbc3\udfa1\uda2a\uddd7\udbb8\udfd1\ud864\udc0b\udb99\udc20\udb10\ude7f\ud8d8\ude2b\ud85a\udcc3\ud8db\ude6f\ud88f\udd08\udbe2\udffa",
        40, 17407, 1334048485, -567841134918824458L, 37444L, false, false, (char) 36847, (char) 34606,
        Double.longBitsToDouble(0x3fe7af51523d3c8eL), Double.longBitsToDouble(0x3fb1768afe93a578L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\ud6c8", "",
        -5, 23656, -599667880, 2001347920688930561L, 7245L, true, true, (char) 28110, (char) 5,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd000000e969400L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 12, 0, "", "\000", "",
        27, 8416, 107, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 0, 0, "\ud84d\udf02\udab7\udca7\uda2f\udee2\udbaa\udc76", "\000\uc71c", "\udb87\ude41\ud9df\udfab\ud888\ude5b\udb56\udc25\ud833\udef4\u00f9\udbcf\udec6\ud954\udc40",
        17, 65003, -566239559, 8658213375860564735L, -100000L, true, false, (char) 65406, (char) 1792,
        Double.longBitsToDouble(0x3fd93d55c928921eL), Double.longBitsToDouble(0x3fe78726b9a2fe04L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\udbaa\udda3\ud95c\udf26\ud9f5\udc47\udb8b\udcc9\ud9d1\udf7d\udafc\udd3c\u50f8\ud9be\udc34\ud84f\udf63\ud949\ude76\udb56\udc25\u4a11\udb0a\udca3\udabb\udef6\ud966\udf5e\ud9af\ude80\udb2d\udf07\udb21\udf73\ud85c\udd9a\uda4b\udc23\ud9d3\ude84\u1aac\udb2c\ude9f\ud96d\udc04\ud88d\udf5b\uda99\udc24\ud9d0\udfaa\udb99\udf1e\ud8c2\udd33\uda62\uddad\uda02\ude20\udbba\udd25\udaad\ude89\udb39\ude7d\ud929\udde5\ud9ed\udeca\udaf0\udf69\ud879\udd1c\ud91f\udf9c\u4e41\ud992\udf74\ud963\uded0\ud8a4\udfe6\ud9e7\uddb1\udbdc\udf86\ud9fc\udcd0\ud95e\udce1\ud9ba\udc80\udb11\udc69\ud9d5\uddb1\ud939\ude20\ud869\ude99\ud928\ude5c\ud985\udf05\udb07\udfa2\uda37\ude59\udb88\udfb3\ud90f\udd3e\udab5\udf33\uda9c\udc80\ud866\ude9f\ud9d6\udc07\udac4\ude47\uda50\uddc7\udaa2\udc1e\udbe4\uddd8\uda64\udf7f\udbf1\udf4c\udad1\ude17\uda22\udf70\ud90d\udf84\udacc\udd10\ud804\udf28\ud88b\udc52\udaa7\udf36\ud949\udce9\ud904\udc96", "\u68bf\u423c\ua165\ud490\u2484\u1830\uaca7\u943e\uc525\uccc5\u648c\u9fd5\u6931\u178b\ud650\u28c3\u700b\u0706\ubdc7\ucc29\u84d1\u13f0\u8a50\u09b6\u4613", "\ud8af\ude13\ud87d\udebe\ud900\uddc5\ud98b\udcd4\udbd4\uddb8\ud905\udf4b\ud8a2\udf28\ud99f\udfa8\ud979\uddd3\ud8b3\udd2c\ud836\ude37\ua442\ud955\udea7\ud975\uddf5\uda8e\udc10\uda88\udd07\udb44\udd66\udbca\ude11\udbe7\ude7d\uda84\udde0\uda7d\udcfc\udad5\udc91\ud815\udf73\ud8c2\udc78\udadb\udca7\ud879\uddac\ud8c9\udef1\udafa\ude61\ud96e\udd67\udaf1\uddce\ud815\uddac\udb73\udcf3\ud9fb\udc7f\ud823\udf7c\ud804\udd2d\uda6f\udfca\udbe9\udfdb",
        12, 60807, 2004794296, 6654037240130784018L, 57465L, true, true, (char) 17201, (char) 28447,
        Double.longBitsToDouble(0x3fe8df3ca30a6911L), Double.longBitsToDouble(0x3fea73d4c3697afbL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 0, "\ud8ee\udd00\ud946\udd7a\uda81\udd40", "\ua7da\u316d\u9093\uc88c\u0679\u4f3a\u7a2e\u905c\u881f\ub78a\ua7cb\uabe5\u8472\u8e2d\u2ea8\u84c1\ubf21\uce8d\ud057\u0e27", "\uda96\uddca\ud937\uddeb",
        21, 50293, 563994807, -1481009687347059646L, 74409L, false, false, (char) 56189, (char) 36194,
        Double.longBitsToDouble(0x3fe7e90753c62fa7L), Double.longBitsToDouble(0x3fdbac6c37dde982L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 3, 7, "\ud84d\udf02\uda12\ude55\uda4a\udd04\udbd4\uddfb", "\u316d\ud628\ucf3a\u0679", "\ud964\udc94\udb56\udc5c\uda8e\uddf6\ud858\ude74\ud8ec\ude07\uda9f\udedd\ud8fa\udc73\udaed\udd19\udb3d\udc59\uda69\udf60\uda7f\ude05",
        -2, 33474, 1488706775, -102202979656574797L, 39021L, true, true, (char) 65533, (char) 25050,
        Double.longBitsToDouble(0x3fd492de51699c22L), Double.longBitsToDouble(0x3fe046071acccdc5L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 0, "\ud84d\uded0\uda12\ude55\uda81\udd40\udbd4\udd63", "\ua50b\u6f57\u8421\u06c5\u4e60\u7a2e\u905c\u5b17\ub78a\u3560\u9187\uab71\u4c85\uca61\u8e06\u0b83", "\udbf8\udc64\udaae\ude11",
        31, 27454, 350855404, -5124203401484861348L, -8471L, true, true, (char) 25050, (char) 33070,
        Double.longBitsToDouble(0x3fc699d3ee6abf8cL), Double.longBitsToDouble(0x3fe26598b63f20eaL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 6, 0, "\ud949\udda1\uda12\udf18\udb07\udc17\udbd4\udd63\ud9bc\udf8e", "\ud628\u18fb\u0679\u4e60\u7a2e\u905c\u5b17\u3de3\u4445\u4384\ua6ff\u8ce7\uc52c\u8eb8", "\ud9d3\ude84\udbf8\udc64\udaae\ude11\udb72\udec9",
        29, 81404, -1698964952, 1513790412636938423L, 72957L, false, false, (char) 46893, (char) 46274,
        Double.longBitsToDouble(0x3fecd57f1a4cb316L), Double.longBitsToDouble(0x3fe1f907524e44e8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 1, 8, "\ud84d\udf02\uda12\ude55\uda81\udd40\udbd4\udd63", "\u316d\u62e5\u1996\u0679\u4e60\u7a2e\u3c06\ub0cb\ub78a\ua7cb\ud006\ua5ed\u9918\ub30e\u8eb8\u4ec8", "\udbf8\udc73\udaae\ude11",
        30, 27454, 350855404, -5124203402592157604L, -9409L, true, true, (char) 25050, (char) 17261,
        Double.longBitsToDouble(0x3fc699daae6abf8cL), Double.longBitsToDouble(0x3fe26598b37020eaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 6, 0, "\udaf6\ude0c\uda12\ude55\uda81\udd40\ud976\udfdd", "\u0113\u8455\uc492\u8750\ud075\u7a83\u2e26\u5ae5\ub78a\u5c3e\u299b\uc5da\u9109\ub30e\u8eb8", "\ud9d3\ude84\udbb4\udd14\udb2e\ude11\ud94e\udd98",
        52, 81404, 1943696197, -3844644101913976649L, 72957L, false, false, (char) 55088, (char) 40645,
        Double.longBitsToDouble(0x3fecd57f1addd3cdL), Double.longBitsToDouble(0x3fafbce850f18510L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 1, 6, 0, 0, "\ud84d\udf02\ud904\ude4e\ud887\ude2f\udbb0\ude1b", "\u4782\u7087", "\ud9be\udc33\000",
        -5, -1000, 1510298022, 47861711092318208L, -71072L, false, false, (char) 53302, (char) 31200,
        Double.longBitsToDouble(0x3fe5650944ee5777L), Double.longBitsToDouble(0x3fd5a933139d9686L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 7, 7, 13, "\ud8e4\ude6a\ud8c6\udf79\uda39\udea3\ud927\ude58\ud8b5\ude98\uda93\udf51", "\u711f\uc086\u8c55\u209a\u5945\u5b17\ucd39\ua7cb\u8c4f\ua3c3\u4ca6\ub2ca\u8eb8\u60c8\u9e5f\u90bd\u08c1\u1244\u73b5\u5b9c\u380c\u88a8\uc487", "\u1600\ud97b\udeae\ud887\udd80",
        24, 87508, 1604409066, 7499889267739879076L, 28778L, true, false, (char) 43804, (char) 2962,
        Double.longBitsToDouble(0x3fec60c5fdae944eL), Double.longBitsToDouble(0x3fe637ba8fdc660eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 4, 5, 6, "\ud8f1\udd0b\ud83d\udfe5\ud8dd\udda0\udb1e\udf45\ud896\udd48\uda9f\ude64\udb2b\udcb2\u6e83\uda51\udfc6\ud81d\udd86\ud9be\udc34\ud80e\udc34\udb6e\udc5a\udbe7\udf26\uda1f\ude59\uda37\udef8\ud82d\udd3b\udb90\udca0\ud80a\udfbf\uda25\udcee\udb33\udfcf\ud85c\udd9a", "\u27e2", "\ud864\udde0\ud873\udfe6",
        36, 31470, 343208308, -7601159638560989516L, 11713L, true, false, (char) 4491, (char) 57298,
        Double.longBitsToDouble(0x3fee5611237f23e3L), Double.longBitsToDouble(0x3fb4c2257723efe0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 4, 4, 15, "\ud84d\udf02\ud904\ude4e\ud9b9\udfce\ud8e3\udc6e\ud896\udd48\udb8a\uddeb\udaa8\udd11\udbed\ude38\udb4f\udfc5\ud81d\udd86\ud9be\udc34\ud82f\udd19\udbc5\udcc1\udbe7\udf26\uda1f\ude59\uda37\udef8\ud824\ude58\ud887\uddb1\ud975\udf98\udb2b\udfd1\udb33\udfe5\ud9c4\udead", "\u27e2\u643a\ub470\u0c14\ua37e\u0bfd", "\uda20\udf5d\ud9a5\udc42\ud854\ude32\ud94c\ude1b\uda34\udca6\uda8a\udc09\udafe\ude42\ud985\udde7",
        39, 80115, -39223580, -1564916207708241699L, 94282L, false, true, (char) 40085, (char) 5963,
        Double.longBitsToDouble(0x3fe6b0e19174b50cL), Double.longBitsToDouble(0x3fe9487f7578585fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 5, 5, 8, "\ud84d\udf02\ud904\ude4e\ud938\ude87\udb51\udd1b", "\u53b9\u44d6", "\ud9ce\udf1b\udbdd\udc5c\udb3c\udc7e\udb56\udc25\ud85a\udd88\ud9ad\udfaa\ud86b\udd85\ud8c2\udcd7\udb1c\udc8c\ud8a6\udcb9\udaca\udf98\ud85b\udf85\ud8f6\udfd2\ud9d3\ude84\udb25\udf3b\ud86b\udf35\ud8db\ude47\udb2b\udeb0\udae1\udca1\ud8c3\udd51\ud8f5\udfa9\ud8ed\ude38\udbae\udd02\udafe\udc56\udbe3\udde9\ud970\udfd2\ud9ff\ude66\ud993\udf75\udbc6\uddfc\ud995\udde5\ud9a6\udd46\udbe3\ude60",
        31, 67034, 1664549597, -8477461337390394927L, 12977L, true, false, (char) 15792, (char) 35892,
        Double.longBitsToDouble(0x3fe352a5b6d88788L), Double.longBitsToDouble(0x3fd887737b9cc736L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 12, 0, "\ud84d\udf02\000\000\udbaa\udc13", "\u4782\ud628", "\ud9be\udc34",
        33, 2181, 1831393719, 6486680610993211897L, -25253L, true, true, (char) 0, (char) 57016,
        Double.longBitsToDouble(0x3fe98ef1feaca128L), Double.longBitsToDouble(0x3fcdcaeee16a4cc4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 12, 0, "\ud84d\udf02\ud904\ude4e\uda39\ude49\udbaa\udda3\ud95c\udf26\ud9f5\udc47\udb8b\udcc9\ud9d1\udf7d\udafc\udd3c\u50f8\ud9be\udc34\ud84f\udf63\ud949\ude76\udb56\udc25\u4a11\udb0a\udca3\udabb\udef6\ud966\udf5e\ud9af\udeff\udb2d\udf07\udb21\udf73\ud85c\udd9a\uda4b\udc23\ud9d3\ude84\u1aac\udb2c\ude9f\ud96d\udc04\ufa5e\ud889\udf1e\udafe\ude4f\ud8c0\udded\ud8b3\udf72\uda62\uddad\uda02\ude20\udbba\udd25\udaad\ude89\udb39\ude7d\ud929\udde5\ud9ed\udeca\udaf0\udf69\ud879\udd1c\ud91f\udf9c\u4e41\ud992\udf74\ud963\uded0\ud8a4\udfe6\ud9e7\uddb1\udbdc\udf86\ud9fc\udcd0\ud95e\udce1\ud8ab\udc97\udb11\udc69\ud9d5\uddb1\ud939\ude20\ud869\ude99\ud928\ude5c\uda79\udfeb\udb07\udf50\uda37\ude59\udb88\udfb3\ud90f\udd3e\udab5\udf33\uda9c\udc80\ud866\ude9f\ud9d6\udc07\udac4\ude47\uda50\uddc7\udaa2\udc1e\udb4c\uddeb\uda64\udf7f\udbf1\udf4c\udad1\ude17\uda22\udf70\ud90d\udf84\udacc\udd10\ud804\udf28\ud88b\udc52\udaa7\udf36\ud949\udce9\ud904\udc96", "\u68bf\u423c\ua165\ud490", "\ud84f\ude5b\ud904\udfb8\ud9de\udc98\ud800\uddaa\ud916\uded1\uda7d\udc78\uc808\udb92\udee0\udbad\ude00\udbe3\udf96\ud8f8\udf14\ud8b8\udee5\ud972\udc2e\udaa7\udd4c\udaf6\udd2a\udadd\udf2c\udb89\udf0e\ud97f\udc91\ud8f3\udc28\ud81a\udfeb\uda64\udccd\ud8af\ude13\udbab\udd35\ud900\udd93\ud98b\udcd4\udbd4\uddb8\ud905\udf4b\ud8a2\udf28\ud99f\udfa8\ud979\uddd3\ud967\udddc\ud966\ude09\udb65\udc50\ud955\udea7\ud975\uddf5\uda8e\udc10\udb81\udf24\udb44\udd66\udbca\ude11\udbe7\ude7d\uda84\udde0\uda7d\udcfc\udad4\ude91\ud815\udf73\ud8c2\udc78\udadb\ude92\udb54\uded9\uda42\udc9a\uda51\uddd6\ud96e\udd67\udaf1\uddce\ud815\uddac\uda41\udd97\ud9fb\udc7f\ud823\udfb3\ud9d0\udf37\uda6f\udfca\udbe9\udfdb\ud8fb\udf95",
        22, 44296, 1549263774, -8919577995042925817L, -21L, true, false, (char) 28447, (char) 45743,
        Double.longBitsToDouble(0x3fe853488f4e7a98L), Double.longBitsToDouble(0x3feb4bd7db5c9da5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimePeriodValues|updateBounds|org.jfree.data.time.TimePeriod,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|add|org.jfree.data.time.TimePeriod,double|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|add|org.jfree.data.time.TimePeriod,java.lang.Number|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|add|org.jfree.data.time.TimePeriodValue|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|clone||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|createCopy|int,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|delete|int,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|equals|java.lang.Object|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getDataItem|int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getDomainDescription||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getItemCount||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMaxEndIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMaxMiddleIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMaxStartIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMinEndIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMinMiddleIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|updateBounds|org.jfree.data.time.TimePeriod,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
