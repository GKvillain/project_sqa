package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimePeriodValues_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\uda16\udf70", "\u5baf", "\ud8db\uddc6\ud96a\udecd",
        11, 72417, -1783600707, -9053915764490638434L, 88698L, false, true, (char) 43114, (char) 29009,
        Double.longBitsToDouble(0x3fc29d7e2534a2acL), Double.longBitsToDouble(0x3fc79ec19bffd4e0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 0, "\ud92a\udef5\ud8a9\udcf5\ud824\udc2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\ud8e5\udfd8", "\u5baf", "\ud8db\uddc6\000",
        11, 72417, -1783600707, -9053915764490638434L, 88698L, false, true, (char) 43114, (char) 28930,
        Double.longBitsToDouble(0x3fc29d7e2534a2acL), Double.longBitsToDouble(0x3fc79ec19bffd4e0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\udbdc\uddb4", "\u5baf\u7914\u7e12\u4fd7\u03dc\u3ac1\u1632\uc3bc", "\udbab\udec3\uda54\udecc\udb57\udfd4\ud855\udea2\ud99d\udcd3\uda40\udef9\udb68\udcb6\ud96b\udc19\u62a9",
        31, -193, -1305493935, -401251156673442083L, -42647L, false, true, (char) 56754, (char) 15541,
        Double.longBitsToDouble(0x3fe951d6c09bfe6dL), Double.longBitsToDouble(0x3fd92fd50a46326cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 1, "\ud931\udfeb", "\ua3e2\000\000\ub644\u8e66\u740b\u2168\uce72\u6062\u7d53\000\uaf79\u2c61\u9d7e\u5baf\u7914\u7e12\u4fd7\u03dc\u3ac1\u1632\uc3bc\u92a9\uc937\ua5f5\u2475\u3a91\u3734\u063d\u895f\u6581\u97f5\u742f\u2aba", "\ud927\udd0f\udbb6\udc11\udb8d\udddb\ud80e\udf28\ud92a\udecf\udb0e\udd19",
        5, 20207, -1655463590, 7792063523355229071L, 79569L, false, true, (char) 4192, (char) 33913,
        Double.longBitsToDouble(0x3fea74ea770ebaacL), Double.longBitsToDouble(0x3fdd8040a6e91af2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:Time |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 8, 3, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\udb3f\udf41\uda4c\udf09\ud829\udee7\udaf9\ude96\ud9ba\ude61\ud87b\udf31\ud9e4\udfc2\ud888\udf72\udaa2\udf07", "\u5baf", "\ud8db\uddc6\ud96a\udecd",
        57, 50769, -1783575343, -9053915766069924962L, -33540L, false, false, (char) 48261, (char) 27789,
        Double.longBitsToDouble(0x3fb85a6ff7ffa9c0L), Double.longBitsToDouble(0x3fddf7415ee502d0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 14, 4, 1, "\ud931\udfeb\udbcb\uddc2\ud811\udef5\udbeb\udca7\udb17\udde2\u92a5\ud828\udf15\ud947\udd8f\ud97e\udc34\ud927\udf48\ud953\udec8\ud9e0\udc72\ud9a8\uddf0\ud8be\udc29\ud997\udd87\udb05\udfbd\ud836\udd6a", "\u7e12\u4fd7\u3ca6\u50d1\uc64d\uafed\u3072\u3e87\ua5ce\u2475\u9245\u3723\u06f2\u20c8\u6581\u97f5\u767e\u761b", "\uda39\udf4e\ud946\udef3\ud9a9\udc71\ud890\udf1a\uda2f\uddba\uda86\udf8b\udaff\udc20\ud8a2\uddda\ud976\udfca",
        59, 5742, -1389178530, -8880423922789813730L, 48938L, false, false, (char) 59268, (char) 35728,
        Double.longBitsToDouble(0x3fc0fd22c26017a0L), Double.longBitsToDouble(0x3fd36eb33df92250L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 7, 1, "\ud931\udfeb\ud8a9\udcf5\ud852\ude2d\ud8ea\udc7c\ud8dc\ude3e\ud8be\udd45\ud828\udf15\ucfe7\ud9c8\udce8\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\uda16\udf70", "\u243a", "\ud8db\uddc6\ud96a\udecd",
        11, 72417, -1783600707, -9053915764490638434L, -55948L, false, false, (char) 55690, (char) 29009,
        Double.longBitsToDouble(0x3f9dbcae29a51560L), Double.longBitsToDouble(0x3fc79ec19bfed4e0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 6, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\udaa1\udfdd\ud97e\udc17\ud907\udd38\ud8d7\udf6b\uda20\udff3\ud893\udc25\ud888\udf19\ud9fd\udc70\udb50\udf1d", "\u7914\ua3b3\u3509\u8b5f\ua0dc\u6c89\uc364\u2f5b\uaf60\ua5f5\u1abb\u351b\u8bc2\ubb91\u3f2b\ud438\u4046\u0e90\u740f\ubd8b\u1e2b", "\ud84e\udcba\uda3e\uddf0\udbf6\uddb5",
        52, 14962, 1079925786, 674143344436454254L, -87381L, false, true, (char) 45463, (char) 63560,
        Double.longBitsToDouble(0x3fe1c627cf2cac4cL), Double.longBitsToDouble(0x3fed7e95fa71ab49L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 1, "\ud931\udfeb\udb2b\udfb6\ud831\udfba\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\udb54\udf6f", "\ucc72", "\ud8db\uddc6\ud96a\udecd\uda99\ude55\ud885\uddf2\ud84a\udd11\ud85f\ude7f\uda39\ude2c\udbab\udec0\uda54\udecc\udb57\udfd4\uda30\udea0",
        52, 92692, -166964915, -776663422170886401L, 45992L, true, false, (char) 60463, (char) 16780,
        Double.longBitsToDouble(0x3fd5a4e2eadae5eaL), Double.longBitsToDouble(0x3febfc4d1404c834L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.String:Time |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 14, 9, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c", "\u2be4\u8e66\u861e\u32cf\uce72\u6062\u7d53\u0cdf\ub04f\uab31\u7d78\u13bf\u466b\u7a40\u4fd7\u03dc\u3aad\u0ad7\uad74\u3dc1\u11b8\u4653\u866a\u65d3\u3734\uc217\u203b", "\ud825\udd26\ud8e6\udfd2\uda22\udc51\ud978\udc71\ud9f1\udd31\udb0a\ude23\udbac\udcf9",
        16, 47215, 1456734231, 7161339710393130908L, -95335L, false, false, (char) 30581, (char) 62708,
        Double.longBitsToDouble(0x3fe079e95197db83L), Double.longBitsToDouble(0x3fb6b60e41cdeef8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 6, 1, "\ud979\ude42", "\uc68b\ua6ba\u7470\u9b73", "\ud89e\udca2\udbf0\uddab\uda50\udcfe\ud84f\ude61\u7135",
        26, 91911, 1133311311, 8313920820810231120L, -95640L, true, false, (char) 43429, (char) 15638,
        Double.longBitsToDouble(0x3f749803cab73000L), Double.longBitsToDouble(0x3fef7e32d4ba8bf8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 12, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud912\udfb8\uda05\udd0d", "\u7a91", "\ud827\udcc3\udb0a\udf67\ud889\uddc8\uda3a\udd0b\ud940\udfaf\uda4b\udd3b\udb67\ude6a\uda22\udcba\uda54\udecc\udbb7\udc88\udab7\udc26\ud99d\udcd3\udb00\udef9\udb68\udcb6\ud8f4\udeed\ud8a4\ude8e\uda86\udfff\ud848\udda2\ud9e8\udd09\ud9a1\udcbf\udba1\ude3f\udb56\udf28\ud855\ude21",
        38, 7699, -648318382, 4826574365848396601L, 46732L, true, true, (char) 8888, (char) 49668,
        Double.longBitsToDouble(0x3fe3de93828032feL), Double.longBitsToDouble(0x3f961439b91b3960L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 14, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\udb72\ude7b\udac6\ude7e\udb66\ude7e\uda03\udf7f\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud860\udd92", "\ub04f\u2c61\u9d7e\u5baf\u7914\u7e12\u4fd7\ubb87\u3ac1\u19f2\uc3bc\u0a24\uc937\ua5f5\u2475\u5957\u8300\u063d\u20c8\u6581\u97f5\u0a3c\ubef2\u4345\uad29\u4689\u0653\u9d67\u36df\u98ba\u6ef4\u6862", "\ud81e\udd26\ud95a\ude02\ud95f\udf5b\ud814\uddb2\udbd5\udcad\uda32\ude45\udbe1\udf8f\udb1d\udede\udbd4\uddd8\udbd5\udd7a\udbdd\ude21\udaee\udc5e\ud919\udfac\udb46\udfee\udaf1\udc36\uda76\uddf9\u1413\udac8\uddbc\udb73\udf00\udb2e\udee9\ud9ce\udce1\ud9d9\udfcd\uda88\udf04\ud836\udf95\uc709\ud956\ude0c\udb5c\udd46\udb4d\udced",
        47, 72381, -187623415, -6278237491974376025L, -78519L, true, false, (char) 62300, (char) 7489,
        Double.longBitsToDouble(0x3fd6793b074a2614L), Double.longBitsToDouble(0x3fd9ddd8161e282aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 9, 1, "\ud931\udfeb\udacb\udf7b\ud8dc\udfa6\udb97\udc17\ud8dc\ude3e\udad2\udc40\ud828\udf15", "\u5d42\u75bd\u6062\u7d53\u3646\u574b", "\udaee\udc8d\ud8fb\ude62\uda34\udc8c\ud8db\uddc6\ud96a\udecd\uc9ba\udba5\udce9\ud852\udf79\ud972\udc2d",
        51, 88240, -1049551130, -2384100359412921983L, -87860L, true, true, (char) 45768, (char) 1080,
        Double.longBitsToDouble(0x3feffaa5dc3b7fb7L), Double.longBitsToDouble(0x3feabecf63736c72L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 1, "\uda32\uddc7\uda43\udd66\ud827\udd2d\ud8ea\udc7c", "\u364d", "\ud927\udf48\ud953\udec8\ud9cb\udd08\udb94\udd79\ud911\udc86\udaf9\udc55\udb18\udc8e\ud836\udd6a\uda9a\uddbc\udb2f\udebc\ud8b3\ude50\ud8db\uddc6\ud96a\udecd\ud9e4\ude5c\uda5d\udfb2\ud852\udf79\ud972\udc2d\uda72\udf19\udbab\udec0\uda54\udecc\udb57\udfd4",
        12, 62522, 682348692, 7836870384941579452L, 319L, true, false, (char) 46733, (char) 25674,
        Double.longBitsToDouble(0x3fe8157f9bc32835L), Double.longBitsToDouble(0x3feafb6e7e9c3ef3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 7, 9, "\ud931\udf8a\ud8a9\udcf5", "\ub1cc\u6716\u2bc5\u8e66\u0e6a\u2168\uce72\u6062\u7d53", "\udb06\udc58\ud836\udd6a\uda9a\uddbc\uda7a\udee0\ud9cd\udd88",
        36, 46760, -1305002254, 8605007421459425725L, 36290L, false, false, (char) 56900, (char) 33304,
        Double.longBitsToDouble(0x3fe4c483c6028b4fL), Double.longBitsToDouble(0x3fc29d7e2534a2acL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 1, "\u00f6", "\u817a", "\ud828\udf15",
        19, 21796, -802543078, -533176039272217821L, 94030L, false, true, (char) 35621, (char) 40995,
        Double.longBitsToDouble(0x3fe7821805507360L), Double.longBitsToDouble(0x3ebb800000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 14, 5, 13, "\ud8fc\uded6", "\u8139\ub1cc", "\udae8\ude92\ud97e\udcb9\ud927\udf48\ud953\udec8\uf0ff",
        40, 87590, 1025933270, -5200109462793806128L, 55743L, true, false, (char) 39669, (char) 19803,
        Double.longBitsToDouble(0x3fdbd776bf2b2b60L), Double.longBitsToDouble(0x3fecf412d683f739L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 14, 13, 15, "\ud931\udfeb\udbcf\ude08\ud8e5\udd1e\ud8ea\udc7c\ud8dc\ude3e\ud862\udc08\ud828\udf5b\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9fd\udfc1\ud9e4\udf94\ud888\udf72\uda16\udf70\udb06\udc58\ud836\udd6a\uda9a\uddbc\udb2f\udebc\ud8b3\ude50\udab7\ude95\ud96a\udecd\ud9e4\ude5c", "\u92a9\uc937\ua5f5\u2475\u0551\u9ced\u0e0a\u20c8\u6581\u404c\u696e\u5042\ucf89\u3c08\ua90a\uba21\u6594\u887e\u1207", "\udb3a\udc7b\ud92c\udd7c\udb86\udda9\uda5f\udeee\ud9c5\udc7a\udad4\uddc8\uda82\udfa9\udbf8\udca0\ud923\udd75\ud95a\uddef\ud917\ude00\ud9ea\uddcd\udab5\ude7b\udb0d\udfcb\ud2ec\udbf3\udf14\uda30\udcc1\ud941\udd5b\ud888\udfac\uda82\uddad\ud954\udd69\udbbc\udc49\udb91\uddd0\udb1c\ude48\udadf\udc24\ud9ba\udcdc\uda25\udebb\uda5b\udcbf\udb73\uddb7\udb5e\uded6\ud849\udf4a\ud9fe\uddf7\udbdd\udc5f\udbe1\uddc0\ud8ac\udfae\ud9b9\uded2\uda8c\ude76\udbec\udec3\udb14\udf23\udb3f\udf2e\uda03\udc51\ud9b3\udc6e\ud98e\udeea\ud83e\udd88\uda78\udd05\ud9c2\udc77\ud995\udf69\ud8a3\udee6\ud90b\udebd\uf0e4\udac9\uded9\ud96b\udc18\ud9bd\udff8\udade\udf76",
        59, 2400, 1267690724, -1395817028144863580L, 58334L, false, true, (char) 2394, (char) 28629,
        Double.longBitsToDouble(0x3fc6c3a08344765cL), Double.longBitsToDouble(0x3fd6b472418caf0aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 15, "\ud931\udfeb\ud8a9\udcf5\udb5a\udd3e\ud856\udde1\ud813\udfe2\ud9c7\udc8f\ud929\udec2\ud828\udf6f\ud97e\udc1e\ud92b\udf48\uda3d\uddbc\ud870\udc84\udbe0\uddbc\ud870\udda7\udb06\udee8", "\u871b\u6d71\uc5e3\ub702\ube86\u3ac1\u71b4\uc3bc\u92a9\u4d37\ua5f5\u2875\ud232\u9fab\u3db0\uc9ba", "\ud80b\ude78\ud83f\udc42\uda26\uddde\ud2ce\ud916\udebe\uda45\udc05\udaa9\udf81\u96c3",
        23, 61859, 307858179, 4815705535970293978L, 20868L, true, false, (char) 18590, (char) 15087,
        Double.longBitsToDouble(0x3fcbd01c35c6b0ecL), Double.longBitsToDouble(0x3feee9f9304598d9L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 14, 7, 6, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\udbe1\udef3\ud805\ude0a\uc77c\ud927\udf48\ud953\udec8\ud81a\ude49\ud9e4\udfc2\ud888\udf72\uda16\udf70\ud8b1\udf4e\ud838\udfbe\uda9a\uddbc\udb2f\udebc\ud8b3\ude50\ud8db\uddc6\ud96a\udecd\ud9e4\ude5c\uda5d\udfb2\ud852\udf79\udb04\uddf5\ud8d6\udf59\udb87\ude74\ud8ec\udf80\udb57\udfd4\uda30\udea0\ud99d\uddbf\uda40\udef9\udb68\udcb6\ud8c2\udd45\udaef\udf44\udb71\uddc0\udbc1\udf80\udacb\udc52\ud965\udd0a\ud8c8\udd2c\ud9aa\ude6a\uda15\ude1f\u52c3\udad6\udead\udbce\ude75\uda74\udc88\ud804\udda9\ud973\udc2c\ud836\udcdd\ud88d\udf5b\udb29\ude98\ud9d1\udc14\udb29\udfa6\ud966\udf52\udb0b\udc5e\uda92\udc49\udbc0\udf73\ud97b\uddf1\u94e2\ud8e6\udf78\ud9bc\udca1\udadc\udf35\ud9d9\udcbc\udb73\uddf5\ud8dd\udc4e\ud910\udee1\ud845\ude2a\ufb4d\uda7f\udf25\udafb\udfec\udbd5\udf84\udb58\udd14\udb87\udf16\uda60\udcad\uda44\udc4f\udb46\uddac\uda5d\udd37\uda41\uddbd\ud8e3\udca1\ud8f1\udd4e\udba5\ude95\ud8ef\udee8\ud8d9\udd73\uda03\udd29\udb62\udeac", "\u1777\u94ff\uad65\u124f\ud4ee\u8ae2\u6e23\ube8b\u8c10\u45bb\u4156\u630f", "\ud9cf\udee6\ud80c\ude18\uda0d\udfd1\udbfc\uded9",
        44, 76477, 1633211065, -4477019411296642517L, 43367L, true, true, (char) 42985, (char) 5578,
        Double.longBitsToDouble(0x3fc5a1df109763b4L), Double.longBitsToDouble(0x3fbab793a3aac950L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 1, 14, 0, 0, "\ud931\udfeb", "\u817a\ub1cc\uc89f\000\u8dd6\u0e6a\u214e\uce72\u0323\000\u5639\ub04f\u2c61\u8fd7\u5baf\uadd2\u7d83\u4fd7\u0f5a\000\u1d0a\u00bd\000\u3d55\ua5f5\u2475\u3a91\uc981\000\u6f68\u815b\u97f5\u65aa\u4586", "\ud838\uded9\udb2e\udfb6",
        30, 93990, -289936068, -5060219478066939062L, 43156L, false, false, (char) 41829, (char) 16334,
        Double.longBitsToDouble(0x3fd2d131ba77d810L), Double.longBitsToDouble(0x3fe4c54a869b51e0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 3, 4, "\udaa7\ude2c\ud8a9\udd16\udab7\udd35\udb5a\udc20\uda5b\udd00\udb02\udccd\udba4\udfe5\ucfe7\ud97e\udc17\uda0f\uded9\uda1b\udd9d\ud9fb\udfa9\ud9e4\udfc2\udb52\udc4d\ud881\ude4f", "\u9642\u28e4\u12dc\u82fd\u3968", "\ud9b3\udc4d\ud8b5\udc0c",
        56, 59169, 1141465239, 473596458405547876L, 99222L, true, true, (char) 28692, (char) 24632,
        Double.longBitsToDouble(0x3fef37ef78aeae3aL), Double.longBitsToDouble(0x3fe5097cb7cf227cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 1, "\ud931\udfeb\udb28\udc14\ud831\udd7e\ud8ea\udc7c\ud8dc\ude3e\uda5d\udd11\uda84\udfab\ud97d\udcfa\ud8d9\uddf9\ud927\udf48\udbae\uddb0\ud962\ude13\ud9e4\udfc2\ud888\udf72\uda16\udf70\udb01\ude07\ud847\udc40\udbc3\uddbd\uda6b\uddb9\ud84d\udfa6\ud89a\ude47\ud96a\udf57\ud9e4\ude5c\uda5d\udfb2\ud852\udf79\ud972\udc2d\uda72\udf19\udbab\udec0\udad8\udcd4\ud98e\udfbf\uda30\udea0\ud93b\udea3\ud97e\udd4e\ud891\udea9\udb1a\udda7\uda72\udc76\udbaf\udf2d\uda75\udcd7\ud879\udc15\uda41\udf61\ud882\udd43\ud99e\ude28\ud827\udfe7", "\uc724\u27d4\u2baa\u76ee\uaa22\u0c26\u70ce", "\udbf6\udc4a\ud966\udfd4\uda0d\ude11\ud970\udd2e\ud83c\udf74\udb6f\udcc3\udb1a\uddce\ud8d8\udf02\ud951\udf27\ud95e\udc42\udbb5\ude0e\ud806\udc8b\udb27\udcd4\uf734\udbce\udd76\ud8ee\uddfb",
        5, 87884, 807448631, 1640110713612019428L, 94561L, true, false, (char) 59197, (char) 57977,
        Double.longBitsToDouble(0x3fd082d22533dbc2L), Double.longBitsToDouble(0x3fe01ed13d06282fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 0, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\udbfd\udd01\ud9e4\udfc2\ud888\udf72", "\u9d7e\u5baf\u7914\u7e12", "\ud9e4\ude5c\uda5d\udfb2\ud852\udf79\ud972\udc2d\uda72\udf19\udbab\udec0\uda54\udecc\udb57\udfd4\uda30\udea0\ud99d\udcd3\uda40\udef9\udb68\udcb6\ud96b\udc19\ud975\udfd7\udbe9\udfb4\udad0\ude95\udacb\ude2e\ud85c\uddbd\ucb4d\ud863\udd82",
        55, 30591, -603854940, 7970112703768770354L, -32879L, true, true, (char) 63935, (char) 8496,
        Double.longBitsToDouble(0x3fe28cee86108270L), Double.longBitsToDouble(0x3fd11a09349ae1deL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 0, "", "\uadba", "\000",
        -5, -1000, 0, 46179364175872L, 99441L, false, true, (char) 32880, (char) 15654,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 7, 7, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\ud93e\udc90\ud8fe\udcbf\ud9e7\ude4d\u162f\ud927\udf48\udb71\udf4e\uda19\udc34\ud9d8\udf06\udbbf\udde3\udac0\udff7", "\u5baf\ub84e\u7d52\uc755\u6548\u7ee3\u1632\uc288\u6585\ua4ab", "\ud809\udf4d\uda33\ude77\udb82\udf06\ud9c0\ude8e\udb73\ude05\udbef\udcae\ud85d\udd09\uda43\udf5e\udab6\udd60\udb39\udca3\udbb1\udd94\udbc7\udc9d\uda02\udcd2\ud88b\udf4d\ud983\udf5c\ud8ad\ude65\ud88e\udff2\ud95e\udd32",
        58, 46658, -1850884690, -9070172596004375093L, -93968L, true, false, (char) 50608, (char) 41883,
        Double.longBitsToDouble(0x3fe5df996b2eaae1L), Double.longBitsToDouble(0x3fedbd6875dffea4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 1, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud896\udeb3\udae0\ude41\udad2\udc40\ud828\udf15\udb61\udc5d\ud8c4\ude3a\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\udbdc\uddb4", "\u5baf\u7914\u7e12\u4fd7\u03dc\u3ac1\u1632\uc3bc", "\udbba\udcc1\uda54\udecc\udb57\udfd4\ud855\udea2\ud99d\udcd3\uda40\udef9\udb68\udcb6\ud96b\udc19\u62a9",
        31, -193, -1305493935, -401251156673442083L, -42647L, false, true, (char) 56754, (char) 15541,
        Double.longBitsToDouble(0x3fe951d6c09bfe6dL), Double.longBitsToDouble(0x3fd92fd50a46326cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 2, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\udbdc\uddb4", "\u5baf\u7914\u7e12\u4fd7\u03dc\u3ac1\u1632\uc3bc", "\udbab\udec3\uda54\udecc\udb57\udfd4\ud855\udea2\ud99d\udcd3\uda40\udef9\udb68\udcb6\ud96b\udc19\u62a9",
        31, -193, -1305493935, -401251156673442083L, -42647L, false, true, (char) 56754, (char) 15541,
        Double.longBitsToDouble(0x3fe951d6c09bfe6dL), Double.longBitsToDouble(0x3fd92fd50a46326cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 4, 5, 1, "\ud931\udfeb\ud923\udcf2\ud849\udd8f\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud946\udfc8\ud9cb\udd08\ud9e4\udf72\ud888\udf72\udbdc\uddb4", "\u9cb0\u21a3\u7e12\u4fd7\u03dc\u3ac1\ud6ca\uc3bc", "\udbab\udec3\uda54\udecc\udb57\udfd4\ud855\udea2\udb58\udcb0\udbf9\uded6\udb68\udcb6\ud947\udf19\u62a9",
        15, -193, 1831845457, -8482335624176395043L, -42647L, false, true, (char) 56754, (char) 25018,
        Double.longBitsToDouble(0x3fede9d20c845b1bL), Double.longBitsToDouble(0x3fcc6265948c66a8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 1, "\ud931\udfeb", "\ua3e2\000\000", "\u1b1c",
        34, 89280, -1737620701, -1435253073889984512L, -35760L, false, true, (char) 19197, (char) 11950,
        Double.longBitsToDouble(0x3fead39bdef2b2ceL), Double.longBitsToDouble(0x3eab800000000000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 0, 1, "\ud931\udfeb", "", "",
        -5, -1000, 96802704, 56887752368586752L, 30269L, true, false, (char) 60436, (char) 32512,
        Double.longBitsToDouble(0x3fdff3d26adf4046L), Double.longBitsToDouble(0x3fe7821c65507360L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud931\udfeb\udbcb\uddc2\ud811\udef5\udbeb\udca7\udb17\udde2\u92a5\ud828\udf15\ud947\udd8f\ud97e\udc34\ud927\udf48\ud953\udec8\ud9e0\udc72\ud9a8\uddf0\ud8be\udc29\ud997\udd87\ud81c\udf87\ud819\uddd4", "\u7e12\u4fd7\u3ca6\u50d1\uc64d\uafed\uac97\u3e87\ua5ce\u2475\u9245\u3723\u06f2\u20c8\u6581\u97f5\u767e\u761b", "\uda39\udf4e\ud946\udef3\ud9a9\udc71\ud890\udf1a\uda2f\uddba\uda86\udf8b\udaff\udc20\uda24\udcbb\ud977\udc40",
        59, 5742, -1389178530, -8880423922789813730L, 48938L, false, false, (char) 59268, (char) 35728,
        Double.longBitsToDouble(0x3fc0fd22c26017a0L), Double.longBitsToDouble(0x3fd36eb33df92250L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 6, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\udaa1\udfdd\ud97e\udc17\ud840\udf78\ud8d3\uddd9", "\uaf46\u494f\u8415\ua0e5\u5baf\u7914\ua3b3", "\uda5d\udc12\udaca\udc6e\ud852\udf21\udbce\ude5a\udbf8\udcc8\udbab\udec0\ud8ba\udd66\udba6\udd42\udaed\udf3e\uda7f\udf85\udb1f\udf8e\ud895\udee2\ud973\udc1d\uda7a\udf59\udac6\udfa1\udbd8\udf18\uda43\udd03\uda52\udf4b\udaa3\udeff\ud84e\udcba\uda3e\uddf0\udbf6\uddb5\ud83c\udfd3\ud8a7\udd26\ud82f\udfe5\ud85e\ude5a",
        55, 50012, -167260491, -4762981774849084495L, 48561L, true, false, (char) 54561, (char) 7345,
        Double.longBitsToDouble(0x3fb653033aef5d40L), Double.longBitsToDouble(0x3fec85f13fc0fae2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\0121=org.jfree.data.time.TimePeriodValues:@? |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 5, 5, 0, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\udaa1\udfdd\ud97e\udc17\ud907\udd38\ud8d7\udf6b\uda20\udff3\ud893\udc25\ud888\udf19\ud9fd\udc70\udb50\udf1d", "\u7914\ua3b3\u3509\u8b5f\ua0dc\u6c89\uc364\u4b35\u5116\ua5f5\u1abb\u351b\u8bc2\ubb91\u3f2b\ud438\u4046\u0e90\u740f\ubd8b\u1e2b", "\ud84e\udcba\uda3e\uddf0\udbf6\uddb5",
        52, 14962, 1079925786, 1000776363211498258L, -87381L, false, true, (char) 45463, (char) 63560,
        Double.longBitsToDouble(0x3fe1c627cf2cac4cL), Double.longBitsToDouble(0x3fed7e95fa71ab49L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 14, 7, 6, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\udbe1\udef3\ud805\ude0a\uc77c\ud940\udd48\udb36\udfd9\ud81a\ude5c\ud9e4\udfc2\ud888\udf72\ud92b\ude9b\ud8b1\udf4e\ud838\udfbe\uda9a\uddbc\udb2f\udebc\ud8b3\ude50\ud8db\uddc6\ud96a\udecd\ud9e4\ude5c\uda5d\udfb2\ud852\udf79\udb04\uddf5\ud8d6\udf59\udb87\ude74\ud8ec\udf80\udb57\udfd4\uda30\udea0\ud99d\uddbf\uda40\udef9\udb68\udcb6\ud8c2\udd45\udaef\udf44\udb71\uddc0\udbc1\udf80\udacb\udc52\ud965\udd0a\ud8c8\udd2c\ud9aa\ude6a\uda15\ude1f\u52c3\udad6\udead\udbce\ude75\uda74\udc88\ud804\udda9\ud973\udc2c\ud836\udcdd\ud88d\udf5b\udb29\ude98\ud9d1\udc14\udb29\udfa6\ud966\udf52\udb0b\udc5e\uda92\udc49\udbc0\udf73\ud97b\uddf1\u94e2\ud8e6\udf78\ud9bc\udca1\udadc\udf35\ud9d9\udcbc\udb73\uddf5\ud8dd\udc4e\ud910\udee1\ud9fe\ude86\uda9b\udcee\ud8e8\ude59\udafb\udfec\udbd5\udf84\udb58\udd14\udb87\udf16\uda60\udcad\uda44\udc4f\udb46\uddac\uda5d\udd37\uda41\uddbd\ud8e3\udca1\ud8f1\udd4e\udba5\ude95\ud8ef\udee8\ud8d9\udd73\uda03\udd29\udb62\udeac", "\u1777\u94ff\uad65\u124f\ud4ee\u8ae2\u6e23\ube8b\u8c10\u45bb\u4156\u630f", "\ud9cf\udee6\ud80c\ude18\uda0d\udfd1\udbfc\uded9\uda00\ude78\ud8bd\udf9b\uda70\udc75\uda88\udee7\udbdf\udf67\ud951\udff3\uda73\ude6f\ud917\ude47\udae7\udd74\udba7\udd45\udbb4\udd02\udb45\ude6f\ud9e8\ude5f\udab0\ude28\ud892\uddab\ud901\udd8b\uda84\udeaf\udb0b\udc77\udbf2\udcce\udbae\udf71\udb08\udf23\uda9b\udc21\udbe4\udcde\ud820\udd6e\udb4c\uddd9\ud92f\udeeb\udb58\udff4\uca68\ud973\ude49\udb26\udfb8\ud850\ude5c",
        0, 53816, -1121971636, 8730489572080815466L, -92497L, false, false, (char) 40929, (char) 33063,
        Double.longBitsToDouble(0x3fe42631633184f0L), Double.longBitsToDouble(0x3fdd839d503eaf4cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimePeriodValues:@?\0121=void |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 6, 6, 14, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\ud828\udf15\ucfe7\ud97e\udc17\ud927\udf48\ud953\udec8\ud9cb\udd08\ud9e4\udfc2\ud888\udf72\udbdc\uddb4", "\u81df\u0583\u7e33\u4fd7\u03dc\u2b0e\u162f\uc3bc", "\udbab\udec3\uda54\udecc\udb57\udfd4\ud855\udea2\ud99d\udcd3\uda40\udef9\udb68\udcb6\ud96b\udc19\u62a9",
        31, -193, -1305493935, -401251156673442083L, -42647L, false, true, (char) 56754, (char) 55624,
        Double.longBitsToDouble(0x3fe951d5489bfe6dL), Double.longBitsToDouble(0x3fd92fd50a46326cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 1, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\uda98\ude4f\udb8c\udca3\udbc8\udd1b\ud89e\uddff\ucfe7", "\u5a36\u30e9\u7d53\u0cdf\ub04f\ud1fd\u9d2a\u79b9\u7914\u7e12\u4fd7\u6c73\ucda6", "\udb3a\udf6e\uda41\uddbf\udbab\udec0\uda54\udecc\ud9a1\udf9d\ud988\ude7f\ud923\udd2c\udb57\udcbc\udb46\udc43\ud96b\udc19\udaf5\udfd7\ud848\udc68\udb26\udd8d\udabe\udee0\ud9fe\ude78\udaa0\ude42\ud89c\ude7e\ud84c\ude66\udaef\udc08",
        7, 47262, -1195127415, -2554469854859621567L, -65819L, false, true, (char) 36304, (char) 44155,
        Double.longBitsToDouble(0x3fe4d5f14d48b9d0L), Double.longBitsToDouble(0x3fed77e54f624571L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.time.TimePeriodValues:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimePeriodValues:@?\012",
        Z.run(T, 2, 14, 7, 6, "\ud931\udfeb\ud8a9\udcf5\ud827\udd2d\ud8ea\udc7c\ud8dc\ude3e\udad2\udc40\udbe1\udef3\ud805\ude0a\uc77c\ud927\udf48\ud953\udec8\ud81a\ude49\ud9e4\udfc2\ud888\udf72\uda16\udf70\ud8b1\udf4e\ud838\udfbe\udbd3\udd1a\ud8ce\ude02\ud903\udd7e\ud9ba\udf77\ud973\udfb8\ud9e4\ude5c\uda5d\udfb2\ud852\udf79\udaa0\ude03\ud8d6\udeba\ud8cc\udf78\ud8ec\udf80\udb57\udfd4\uda30\udea0\ud99d\uddbf\uda40\udef5\udb68\udcb6\ud8c2\udd45\udaef\udf44\udb71\uddc0\udbc1\udf80\udacb\udc52\ud965\udd0a\ud8c8\udd2c\ud9aa\ude6a\uda15\ude1f\ud8d4\udec2\uda75\udc7d\uda0f\udf22\uda74\udc1e\ud804\udda9\ud973\udc2c\ud836\udcdd\ud88d\udf5b\udb29\ude98\ud9d1\udc14\udb46\udf95\udaf7\udcf2\udb0b\udc8d\uda92\udc49\udbc0\udf73\ud97b\uddf1\u94e2\ud8e6\udf78\ud93e\udfa3\udab4\ude01\ud9d9\udcbc\udb73\uddf5\ud8dd\udc4e\ud910\udee1\ud808\udd14\udb9e\udcfb\uda7f\udf3b\udb07\udf12\udbd5\udf84\udb58\udd14\udbed\udfca\ud8fe\udc14\ud98e\udf34\udb46\uddac\uda5d\udd37\uda41\uddbd\ud8e3\udca1\udbf8\uddd2\udbbf\udee0\ud8ef\udee8\ud8d9\udd73\uda03\udd29\udb62\udeac", "\u177b\u9315\ubdee\u124f\ud4ee\u8ae2\u6e23\uba25\u4227\u45bb\u4156\u630f\u4bab\u2af7\u27cd\u9951\uc6cb\uc4ef\u5a22", "\uda88\udee7\udbdf\udf67\ud951\udff3\uda73\ude6f\ud917\ude47\udae7\udd74\udba7\udd45\udbb4\udd02\udb45\ude6f\ud9e8\ude5f\udab0\ude28\ud892\uddab\ud80e\udcd7\ud92b\udc61\ud9c4\udcb1\udbbe\udec9\udaab\ude1e\udabd\uddb8\u9681\ua386\uda7b\udccd\ud965\udcf6\ud90a\ude92\ud93c\udca1\ud8e6\ude95\udbba\udc93\ud8ac\udcd1\uda26\ude30\ud980\udd1e\ud815\udd49\udb83\udff5\ud90b\udde7\u3f56\ud8dc\ude4c\ud841\udd2e\ud8ac\ude7f\udb0f\udfa5\ud96b\uddd9\ud936\udeb0\ud9a7\udc22\uda9f\udee5\ud813\uded1\uf61d\uda8a\udf5d\uda54\udc01\uda00\udce6\udaf9\uddc8\udb45\udd30\uda47\ude5f\uda2a\ude28\ud81d\udebf\ud9ff\udd0a\ud9f0\ude8b\udb8b\udef4\ud82f\udee8\udada\ude96\udbe3\udeb1\ud8dd\udcd6\ud8e7\udf11\ud853\udd84\udb0e\udf53\uda76\udcaa\ud80e\udd0f\uda2f\udf78",
        41, 18413, -321438892, -1254094379040840937L, -20242L, true, true, (char) 52386, (char) 59288,
        Double.longBitsToDouble(0x3fdf584f800a70feL), Double.longBitsToDouble(0x3fd7f44c5f17ae3cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimePeriodValues|updateBounds|org.jfree.data.time.TimePeriod,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|add|org.jfree.data.time.TimePeriod,double|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|add|org.jfree.data.time.TimePeriod,java.lang.Number|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|add|org.jfree.data.time.TimePeriodValue|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|clone||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|createCopy|int,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|delete|int,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|equals|java.lang.Object|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getDataItem|int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getDomainDescription||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getItemCount||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMaxEndIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMaxMiddleIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMaxStartIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMinEndIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|getMinMiddleIndex||new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
    "M|org.jfree.data.time.TimePeriodValues|updateBounds|org.jfree.data.time.TimePeriod,int|new:org.jfree.data.time.TimePeriodValues:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
