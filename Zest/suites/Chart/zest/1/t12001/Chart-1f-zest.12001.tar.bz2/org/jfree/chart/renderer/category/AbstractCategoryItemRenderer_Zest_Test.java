package org.jfree.chart.renderer.category;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractCategoryItemRenderer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u987a\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 13, 1, "\ud973\udc79\udad5\udff5\uda1c\udfa9", "\u1eb2\u7881", "\udb41\ude97\ud987\ude7a\ud95d\ude04\ud9c0\udc0c\u6e64\udbed\udd82\ud996\uddb7\ud965\udd95\ucb2f\udbfe\udfc3\udbaa\udc29\udad6\udd5e\ud8c0\uddf3\uda46\ude71\udb60\ude04\udbd4\udfa5\uda97\udf9a\udb2f\udd38\udb58\udc9d\u9181\ud82f\udd06\u1778\udbe5\udd8c\ud826\udf4a\uda69\udd7d\udbf4\udec7\udaad\udec6\uda5c\ude81\ud958\udf40\ud983\ude99\udbbf\udeee\ud8bb\udc6f",
        31, 22326, -403613268, -7697525093267296970L, -287L, false, true, (char) 41822, (char) 45110,
        Double.longBitsToDouble(0x3fe43d50ac6d7be0L), Double.longBitsToDouble(0x3feeabdc87f90441L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 14, "\ub22b\ud8b5\udc9b\ud964\ude96\udb88\udfbd\uda52\udef2\ud917\udf9c", "\u6a3b\u3cd1\uae15\u68ed\u9337\u21c6\u4c3f\u1400\u9ff8\u00b2", "\ud886\udcb7",
        5, 5822, 92137906, -2980584614244879715L, 83211L, true, false, (char) 43480, (char) 41467,
        Double.longBitsToDouble(0x3fe97fcdad6d9f66L), Double.longBitsToDouble(0x3fed8698fb00f088L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\ud913\udf43\u64c0\uda10\uddc4", "\u2242\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\u8b91\u09f7\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u9821\u01ff", "\udbf4\udec7\udaad\udec6\ud815\udcdd\ud958\udf14\ud983\ude99\ud88d\udd96",
        17, 85784, 391297326, -1733505788083903050L, -33607L, true, true, (char) 60432, (char) 41822,
        Double.longBitsToDouble(0x3fb672f7543d50a8L), Double.longBitsToDouble(0x3fbb5ef8242bdc80L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 1, "\uda19\ude16\u0c05\ud8a4\udc0f\udb88\udf14\uda6b\udf9f\uda33\ude9d\ud8cc\udc37\udba0\udff6\ud803\udd15\udb41\ude97\ud923\udde7", "\u21c6", "\ud965\udd95",
        53, 50258, 1149045706, -4183205755681969839L, 36782L, false, false, (char) 18752, (char) 6620,
        Double.longBitsToDouble(0x3feab0294683599bL), Double.longBitsToDouble(0x3fb56ac1a40c1fe8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 1, "\ucc7a", "\u725e\u5e92\uc1c4\u7881\u4ed5\u2258\u0091\u52b2\u68ed\u9337\u21c6\000\u70e3\u00eb", "\ud8d5\udc09",
        31, 76905, -458621938, 395729292287279126L, 73699L, true, false, (char) 23552, (char) 30680,
        Double.longBitsToDouble(0x3fe80000000000b5L), Double.longBitsToDouble(0x3e4ec00000000000L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 1, "\ucc7a\udad5\udff5\uda0f\udee3\udb88\udff6\uda6b\udf9f\uda33\ude9d\uda77\udfcd", "\u0091\ud4fd\u5913\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u17a5\u6cb0\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u6794\ud6b7\u01cc\u3c34\u10b1\u483d\u75cb\u9470\u4111\u0f72\ud54b\ub383", "\ud802\udc41\ud961\udf6a\u6aee\udb8d\udcbe\ud857\udcba\uda40\ude07\ud9c8\udfd9\udb57\udf48\udb94\uddd3\ud88d\udf06\uda15\ude5b\ud85a\udcb1\uda49\ude9d",
        27, 67433, -2068492642, -7083603623357272943L, -51676L, true, true, (char) 40931, (char) 12051,
        Double.longBitsToDouble(0x3fe5f49fd0c29ce5L), Double.longBitsToDouble(0x3fedf52726586c3aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 5, 5, 9, "\ucc7a\udbb5\udecf\ud98a\udee2\udb83\udfc3\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u74d3\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u5951\u22e1\u6a1f\u02a9\u8be8\ua55b\u987a\u85b6\u61f5", "\udb9a\udf29",
        51, 82732, -1792219722, -2789226571364760743L, 91360L, false, true, (char) 63568, (char) 4824,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfc9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u987a\ucb5b\u61f5", "\ud975\udf37",
        39, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 0, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\ud417\ub307\u7d89\ua9cc\u695a\u0cdf\u01ff\u3c34\u10b1\u483d\ua55b\u987a\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 7, 5, 1, "\udb0e\udd75\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\ud71b\u7463\u69a8\u9337\u21c6\u4c3f\u1400\uceab\u5ba7\u2fad\u9cd2\ua7b8\u70f8\uc3a7\u4034\u2cc4\uc905\ub307\u7d89\ua9cc\u695a\u3280\u8a0b\ua795\uaa5b\u483d\ua55b\u987a\u31b7\u61f5", "\uda58\udde9",
        -2, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u987a\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 10, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udadf\ude24\uda45\ude0f\uda33\ude9d", "\ucfcb\u0091\u579e\u68ed\ua5af\ubc1d\u1c17\u40f6\ud72a\u5e81\uc9bf\u34c4\uc63c\u40ed\uc3e8\u89fb\u61dd\u5e50\ub988\ua3df\ua9cc\u695a\u9821\u792d\ua002\u5d95\u4889\ud052\ub448\u31af\u61f5", "\uda1d\udfe3",
        38, 82732, -1792219722, -8108086582940439482L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fe43e2f04857b90L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u447c\u9c35\u9dda\u4975\u1400\u5c11\u5ba7\u5edb\u3cf6\ua7b8\u70f1\uc3a7\u4034\uaca3\u6e18\u9afa\u1060\ud673\uce62\u97d1\ucae1\u125b\u2d63\uc61f\ua55b\ubefb\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 51989, (char) 43328,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626d17aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 6, 1, "\ucc7a\udad5\udff5\uda15\udda9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u5410\u68ed\u9337\u21c6\ua706\u1400\uc4f8\u5ba7\u5edc\u3cf6\ua7b8\u70f8\uc1b1\u3c31\u8d0f\u6e18\ub307\u7d89\ua9cc\ub9f1\u46a3\u01ff\u68a6\u10b0\u483d\ua55b\u987a\u31b7\u9314", "\ud99e\udd32\u8c76\uda53\uded7\ud961\udf55\u6aee\udb8d\udcbe\ud880\udd0d\ud84f\udd6e\udbda\udcc6\udb25\udd1a\udb94\uddd3\ud88c\udfb5\uda15\ude5b\ud85a\udcb1\udb91\udd81\ud980\udf58\uda31\udd36\uda1f\ude2c\u8b86\udbba\udcd7\udb94\udde0\ud802\udcfe\udad0\uded0\ud81e\udf9f\udb26\udcef\udb68\udcdf\u41de\ud822\udd43",
        40, 58676, 1294850501, 2414668076959368156L, -25996L, false, true, (char) 34763, (char) 15581,
        Double.longBitsToDouble(0x3fb9b658aa861cb8L), Double.longBitsToDouble(0x3fee07ed5e8a9d04L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 15, 10, 1, "\udaa4\udd55\udb1e\uddb5\uda1c\udfd8\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u34b9\u339d\u2b8d\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua466\ud36f\u7b2f\u2e8a\u8d0f\u26fc\ub21c\u1664\u7b1f\ubfc1\uc2df\ud127\ua777\u204d\u483d\ua55b\u63bc\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, 3609147148766099872L, -29216L, false, false, (char) 4847, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 10, 12, "\ucbfc", "\u71f3\u5e92\u2451\u7881\u6559\u15b6\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8", "\ud8d7\udfd3\ud87a\udd1b\ud8d7\udede",
        52, 80490, -693971434, -3679314876839736085L, 73699L, true, false, (char) 57470, (char) 43480,
        Double.longBitsToDouble(0x3fed48b29b2f7089L), Double.longBitsToDouble(0x3fd6d9f66f61a63eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda64\ude86\ud832\uddc9\ud8cc\udc37\udba0\udff6\ud803\udd15\udb41\ude97\ud987\ude7a\ud95d\ude04\ud9da\udd98\uda28\udddf\udbc7\ude3f\ud996\uddb7\ud965\udd95\ucb2f\udbfe\udfc3\ud8d7\udfd3\ud87a\udd1b\ud8d7\udede\uda46\ude71\udb60\ude04\udbd4\udfa5\uda97\udf9a\udb2f\udd38\udb58\udc9d\udbfa\udd8b\ud82f\udd06\u1778", "\u10b1\u483d\ua55b\u987a\u31b7\u3379\u4ecc\ub383\u219d", "\ud8d6\udfaa\u6aee\udae2\udfe9\uda47\udec6\ub259\ud9c8\udfd9\udb57\udf48\udb94\uddd3\ud880\udeb5\uda15\ude5b\ud85a\udcb1\udb45\udffc\ud825\uddc8\udbd2\ude83\udac9\udd71\udb4f\udf7f\ud8b0\udf8f",
        -4, 32800, -1230015457, -3603605647256437799L, 58502L, true, true, (char) 8646, (char) 56488,
        Double.longBitsToDouble(0x3fd5caa0af720632L), Double.longBitsToDouble(0x3feae4af9c6371dbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 7, "\udad8\udc2c\udad5\udff5\udaed\udf52\ud94a\udd6a\ud823\udf8b\ud89f\udc83\ud8cc\udc37\udba0\udfae\ud82e\udd8c\udb34\udd0d\ud987\ude7a", "\u21c6\u8223\ubdca\u6245\u9721\u6367\u5055\u8613\u6ee4\ud645\ud300\u2cc4\u7dcf\ub307\u353d\ua9cc", "\ud944\udd50\ud91e\ude38\ud9c4\ude40\udad7\udc18\udb92\udf35\ud879\ude54\ud95b\ude87\ud983\ude99\ud99d\udf1e\udae5\udd82\ud975\udefb\udb6e\ude8d\ud802\udc41\ud8d9\udea6\u2add\udbbf\ude7b\udbdb\udefe\uda22\udd4f\uda12\udd20\ud8e3\udf4e\udb94\uddd3\ud88c\udfb5\uda15\ude5b\uda13\udf6c\udbe1\udd2b\u36e4\ud955\udd2b\udac4\udc57\u8046\uda62\udf23\udb31\udcb9\ud844\udc84\ud975\uddfe\udb3a\udf04\ud8c9\ude47\ud93f\udef3\ud87b\ude84\uda28\udfa1\udbd8\udcac\uabab\udace\udf1a\ud83d\ude51\ud961\udf3e\udbd1\udf5b\uda5f\udfee\uda88\udee4\uda3d\udc30\uda9a\udeb1\ud868\udf77\ud901\udfa4\ud957\udd83\udb7e\uddac\ud95b\udf37\udb8b\udde6\udba1\ude3f\udb7c\udcc2\udab6\udd34",
        25, 22997, 1183558712, 6418054676757819031L, 63259L, true, false, (char) 33553, (char) 24350,
        Double.longBitsToDouble(0x3fea1b273ce999a9L), Double.longBitsToDouble(0x3fd073453a3a459cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\uc298\u71df\u21c6\u4c3f\u1400\u06f9\u5ba7\u5edb\u3cf6\u1d5f\u2889\ud32c\u4034\u52db\u6e18\ub307\u7d89\u3d17\u8dc4\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u987a\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226573767900327L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 0, "", "\u215b", "\uda33\ude9d\ud8cc\udc37",
        21, 44292, -1162300755, -6383883589984077299L, -76872L, false, true, (char) 1631, (char) 12760,
        Double.longBitsToDouble(0x3fd05711b3c539f2L), Double.longBitsToDouble(0x3fee54c19487447dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 10, 5, 1, "\ucbdf\udad5\udff5\uda1c\udfa9\udaad\udd8e\ud9c0\udfd1\udb7a\udfce", "\u69ae", "\ud95d\ude04\ud875\udea6\udbb3\uddc9\ud874\udc1c\ud8f0\udf4f\ud874\uddd8\ud99a\udf98\udbfe\udf21\ud8d7\udfd3\ud887\udd1b\ud8a5\udc3d",
        52, 24906, -693971434, -3679314876832201749L, 73699L, true, false, (char) 57470, (char) 45140,
        Double.longBitsToDouble(0x3fe817fe1d4bf9d6L), Double.longBitsToDouble(0x3fd6d9f66f61a63eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 6, 10, 1, "\ud82d\udc87\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\ub808\u55aa\u9337\u21c6\u4c3f\u00f5\ud4ed\ua199\u3109\u0a73\u9d33\ua937\u1968\u4011\u8d0f\u6e18\u0d66\u45c2\ua95e\u695a\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u39aa\u31b7\u61f5", "\udb01\udcbd",
        29, 3940, -1792219882, -2789226571364760743L, -23328L, false, false, (char) 45110, (char) 52479,
        Double.longBitsToDouble(0x3fc1a2caff752900L), Double.longBitsToDouble(0x3fe0a24c22dd16ffL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 1, "\udae0\udf3b\udad6\udc39\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d\ud8cc\udc37\udba0\udff6\ud803\udd15\udb41\ude97\ud987\ude7a", "\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u9821\u7ffe\u3c34\u10b1", "\ud815\udcdd\ud958\udf14\ud983\ude99\ud88d\udd96\u68d4\ud975\udf37\udb6e\ude8d\ud802\udc41\ud961\udf6a\u6aee\udb8d\udcbe\uda33\udd89\ub259\ud9c8\udfd9\udb57\udf48",
        8, 67229, -1754225531, 1619826223086593574L, -27048L, false, false, (char) 62724, (char) 35520,
        Double.longBitsToDouble(0x3fba28d33a8d0bb0L), Double.longBitsToDouble(0x3fe42504a10fc07aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda75\udd9f\uda33\ude9d", "\u2258\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u987a\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 0, 0, 1, "", "", "\uda6b\udf9f",
        21, 28152, 0, 8502796095313195693L, 48979L, false, false, (char) 43498, (char) 32708,
        Double.longBitsToDouble(0x3fe0200006ebfaecL), Double.longBitsToDouble(0x3fd05001b3c40000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 1, "\ud98c\uded2\udb26\ude60\udb31\udef8\ud8fa\udc24\ud900\udd24\uda33\ude9d", "\u224b\uc5ec\ua68f\u167d\u704e\u4fa6\ud651\u14cb\uc4f8\u7787\u63f9\u3c2c\u8c45\u70f8\ud136\uc5cb\u8d0f\u6e18\ub307\u571e\u8062\uc2ec\u16e9\u853b\u2a86\uab22\u81ef\ucbdc\u987a\u31b7\u95b9", "\ud846\udc10\ud9e5\udc24\ud8a2\udf0b\ud961\udf6a\uda68\udcf4\udb8d\udc72\ud897\udf3b\ud83e\udd88\udb33\udc66\udaa1\ude2f\ud9cc\udf92\ud91f\udde2\ud835\udc85\u0086\ud83b\ude64\udad2\udd9f\uda54\udeb9\uda0b\udd6f\uda6d\ude3b\uda82\ude36\ud9c5\udc64\udbee\ude79\ud8ad\uddaa\ud82e\uddca\ud949\udea7\udac7\udd4d\udbe2\udd74",
        -3, 75122, -69539766, -7971778276162708580L, 90648L, false, true, (char) 37494, (char) 64025,
        Double.longBitsToDouble(0x3fbb3f0bee619c38L), Double.longBitsToDouble(0x3fd21acb1bee9db6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 0, 10, 1, "\ucc7a\udad5\udff5\004", "", "\udba0\udff6",
        2, 6245, 6808499, -4932081506403033880L, -48523L, true, true, (char) 40185, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f378d0800000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 9, 6, "\udb74\udcaa\udad6\udc02", "\u5e92\u1ece\u7881\u4ed5\u2258\u0091\u955d", "\uda4f\udca1\ud9b0\udf00\ud996\uddb7\ud965\udd95\ucb2f\udb64\udcfa",
        11, 64511, 1580525905, -1981306698891138638L, 83211L, true, false, (char) 43480, (char) 41467,
        Double.longBitsToDouble(0x3fe97fcdad6d9f66L), Double.longBitsToDouble(0x3fec3698fb00f088L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 0, 14, "\ub22b\ud8b5\udc9b\ud964\ude96\udb88\udfbd\uda52\udef2\ud917\udf9c", "\u5539\u3cd1\u0dca\u68ed\u9337\u21c6\u4c3f\u1400\u9ff8\u00b2", "\ud886\udcb7",
        5, 5822, 92137906, -2980584614244879715L, 83211L, true, false, (char) 43480, (char) 41467,
        Double.longBitsToDouble(0x3fe97fcdad6d9f66L), Double.longBitsToDouble(0x3fed8698fb00f088L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 14, "\udb08\udf58\udb63\udd89\ud90d\udc4d\udbaa\udfa8\uda1c\udef7", "\u6fc6\u374e\u1e0f\ub40a\u699e", "\udbc7\ude3f\ud996\uddb7\udac7\udc0b\ud949\udef8\ud8a8\udee5\ud8dd\udcfc\ud886\udcb7\udbdf\udd37\ud8c3\udc93\udbdc\ude80\uda70\udc0f\ud9ae\ude90\udb59\udd78\ud8d3\ude28\ud901\udc43\ud9cd\udcfe\u1778\udb40\udcd9\ud826\udf4a\uda69\udd7d\uda29\udc57\ud9a7\udc88",
        57, 74209, -1618887603, -6896329089858001179L, 84919L, false, false, (char) 59650, (char) 53987,
        Double.longBitsToDouble(0x3fe6a701e26b382bL), Double.longBitsToDouble(0x3fda088a50da66d4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 10, 10, 14, "\ub22b\ud8b5\udc9b\ud964\ude96\udb88\udfbd\uda52\udef2\ud917\udf9c", "\ub2b0\u3cd1\uae15\u68ed\u9337\u21c6\u4c3f\u1400\u9ff8\u00b2", "\ud886\udcb7",
        5, 5822, 92137906, -2980584614244879715L, 79883L, true, false, (char) 43480, (char) 41467,
        Double.longBitsToDouble(0x3fe97fcdad6d9f66L), Double.longBitsToDouble(0x3fed8698fb00f088L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 15, 14, "\u5f2b\ud8b5\udc9b\udbd6\udcef\udb88\udfbd\uda52\udef2\ud917\udf9c", "\u6a3b\ua0ae\uae15\u68ed\u9337\ua2c7\u926b\uc3dc\uc168\ua994", "\ud886\udcb7",
        58, 9886, 92137906, -2980584614244879715L, 83211L, true, true, (char) 41917, (char) 41467,
        Double.longBitsToDouble(0x3fe97fcdad6d9f66L), Double.longBitsToDouble(0x3fed8698fb00f088L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 10, 14, "\ub23f\ud8b5\udc9b\ud964\ude96\udb88\udfbd\ud9fe\udd88\uda41\uddce", "\u6a3b\u3cd1\uae15\u68ed\u9337\u21c6\uc674\u1400\u9ff8\uaf1d", "\ud886\udcb7",
        5, 5822, 92137906, -2980584614244879715L, -6721L, true, false, (char) 59454, (char) 57470,
        Double.longBitsToDouble(0x3fec49927ba91653L), Double.longBitsToDouble(0x3fe97fcdad6d9f66L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 10, 14, "\ub22b\ud8b5\udc9b\ud964\ude96\udb88\udfbd\uda52\udef2\ud917\udf9c", "\u6a3b\u3cd1\u0ffd\u68ed\u9337\u21c6\u4c3f\u1400\u9ff8\u00b2", "\ud886\udcb7",
        5, 5822, 92137906, -2980584614244879715L, 83211L, true, false, (char) 43480, (char) 41467,
        Double.longBitsToDouble(0x3fe97fcdad6d9f66L), Double.longBitsToDouble(0x3fed8698fb00f088L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 5, 9, "\ucc7a\udbb5\udecf\ud98a\udee2\udb83\udfc3\udba9\udd3d\udb03\uddbe", "\u83fd\u2323\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\u9000\u538e\u74d3\u3cf6\u058b\u9f9b\uc3a7\u4034\u8d0f\u4e18\uc3f7\u7d89\ua9cc\u695a\u68f1\u26d5\u2c4d\u65b0\u8be8\ua55b\u987a\u85b6\u0a41", "\ud8f0\udd3a",
        19, 96051, -1868131146, -2789226571364760743L, 91360L, false, true, (char) 63568, (char) 31192,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda5a\udff4\uda33\ude9d", "\u2258\u0091\u52b2", "\uda28\udddf\ud9e9\uddc7\ud968\ude1e\ud965\udd95\ucb2f\udbfe\udfc3\ud8d7\udfd3\ud87a\udd1b\ud8d7\udede\udafe\udd80\udb60\ude04\udbd4\udfa5\uda7b\udd9a\udb2f\udd38\ud97b\udcaf\u91d6\ud82f\udd06\udaa1\udc85\udb40\udcd9\ud826\udf4a\uda69\udd7d",
        -2, 10896, 738681600, 1960061421752901669L, 78478L, false, true, (char) 52647, (char) 16994,
        Double.longBitsToDouble(0x3feaceca558117b9L), Double.longBitsToDouble(0x3fec00048eecec72L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 7, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u12c7\u0091\u52b2\u68ed\u9337\u21c6", "\ud972\ude54\ucb2f\udbfe\udfc3\ud8d7\udfd3\uda50\udd66\ud8d7\udede",
        52, 24906, -693971434, -3679440221165302549L, 73699L, true, false, (char) 57470, (char) 30680,
        Double.longBitsToDouble(0x3fed48b29b2fa9b5L), Double.longBitsToDouble(0x3fd6d9f66f61a63eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 2, 1, "\udae7\udddc\udac2\udcb5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u2258\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u695a\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u987a\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226571364760743L, 38151L, true, false, (char) 24653, (char) 8213,
        Double.longBitsToDouble(0x3fec6500ce26167aL), Double.longBitsToDouble(0x3feaa35f4b774428L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 10, 1, "\ucc7a", "", "",
        -5, -1000, 0, 8502796095313195693L, 48979L, false, false, (char) 20370, (char) 39300,
        Double.longBitsToDouble(0x3fe02262deebfaecL), Double.longBitsToDouble(0x3fd05711b3c539f2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 1, 11, "\ucc7a\udad5\udff5\uda1c\udfa9\udadf\ude24\uda45\ude0f\uda33\ude9d", "\ucfcb\u0091\u579e\u68ed\ua5af\ubc1d\u1c17\u40f6\ud72a\u5e81\uc9bf\u34c4\uc63c\u40ed\uc3e8\u89fb\u61dd\u5e50\ub988\ua3df\ua9cc\u695a\u9821\u792d\ua002\u5d95\u4889\ud052\ub448\u5843\u1349", "\uda1d\udfe3",
        38, 82732, -1792219722, -8108086582940439482L, 91360L, true, false, (char) 56938, (char) 35996,
        Double.longBitsToDouble(0x3fec3e2f04857bb1L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 3, 1, "\ucc7a\udad5\udff5\uda1c\udfa9", "\u4e3c\u7881", "\udb41\ude97\ud849\uddad\ud95d\ude04\ud9ba\udf9e\ud9d6\udf6a\ud805\udff9\ud9a2\udd5d\uda34\ude3d\ud91d\udf42\ud97f\udf4a\ud877\udf9f\ud847\uddb4\ud9c7\udccb\uda46\udeb2\udb0c\udc9a\ud9ef\udef5\udb6d\udd66\udb25\udc22\udb61\udef3\u9181\ud82f\udd06\uda10\udeff\udbb1\udf0d\udb01\ude23\u4a36\udbf4\udf13\udb45\ude11\u481c\ud958\udf0c\ud983\ude99\ud88d\udd96\udb61\uded6",
        37, 44165, -403613268, -7697525095124022730L, 49780L, true, false, (char) 30108, (char) 5224,
        Double.longBitsToDouble(0x3fc0af721d7a5dc0L), Double.longBitsToDouble(0x3fe130b3d1e0159dL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 1, "\ucc7a\udad5\udff5\udb50\udfa3\udadf\ude24\uda45\ude0f\uda33\ude9d\ud8cc\udc37\udba0\udff6\udb3a\ude1a", "\u68ed\ua5af\ubc1d\ua262\u3dd5\ud72a\uc990\uc9bf\u34c4\uc63c\u40ed", "\ud9ef\udf84\udb6d\udd66",
        1, 62116, -1425627517, -8791813355924154812L, -52421L, false, false, (char) 11726, (char) 37388,
        Double.longBitsToDouble(0x3fe99af676109ef1L), Double.longBitsToDouble(0x3fa28d999d26d870L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 13, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udadf\ude24\uda45\ude0f\uda33\ude9d", "\ucfcb\u0091\u579e\u1315\ua5af\ubc1d\u1c17\uc51a\u8f6c\u6321\uc9bf\u34c4\uc63c\u40ed\uc3e8\u89fb\uc1d9\u5e50\ub988\ua3df\ua9cc\u695a\u9821\u1ca1\ud4ff\u5d95\u45de\u4049\ub448\u43e8\uc805", "\uda1d\udfe3\udb53\uddd4",
        5, 24300, -1887810829, 1709516581476861313L, 49780L, true, false, (char) 31170, (char) 5224,
        Double.longBitsToDouble(0x3fc0af721d7a5dc0L), Double.longBitsToDouble(0x3fe130b3d0be9406L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 3, "\ucc7a\udad5\udff5\uda1c\udfa9\udadf\ude24\uda45\ude0f\uda33\ude9d", "\ucfcb\u0091\u579e\u68ed\ua5af\ubc1d\u1c17\u40f6\ud72a\u5e81\uc9bf\u34c4\uc63c\u40ed\uc3e8\u89fb\u61dd\u5e50\ub988\ua3df\ua9cc\u695a\u9821\u792d\ua002\u5d95\u4889\ud052\ub448\u31af\u61f5", "\uda1d\udfe3",
        38, 82732, -1792219722, -8108086582940439482L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fe43e2f04857b90L), Double.longBitsToDouble(0x3fbde5dc3130b448L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 13, "\ucc7a\udad5\udff5\uda1c\udfa9\udadf\ude24\uda45\ude0f\uda33\ude9d", "\ucfcb\u0091\u579e\u68ed\ua5af\ubc1d\u1c17\u40f6\ud72a\u5e81\uc9bf\u34c4\uc63c\u40ed\uc3e8\u89fb\u61dd\u5e50\ub988\ua3df\ua9cc\u695a\u9821\u792d\ua002\u5d95\u4889\ud052\ub448\u31af\u61f5", "\uda1d\udfe3",
        38, 82732, -1792219722, -8108086582940439482L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fe43e2f04857b90L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 10, 15, "\ucc7a\udad5\udff5\uda1c\udfa9\ud833\udc72\uda6b\udf9f", "\u4ed5\u7e7d\u0fa6\ubcbe\u447c", "\ud94d\udd29\ud842\udd26\udb37\udfc1\ud867\udea0\ud845\udf86\uda9f\udf2a\udb98\udd15\ud8d7\uded7\uda46\ude71\udb60\ude04\uda4a\udfa0\uda97\udf9a\uda11\udf73\uda93\udf79\ube28\ud856\udf98\u1728\udbce\ude21\uda74\ude25\udb8a\udd4d\udbde\udcaa\udaad\udec6",
        -2, 20538, 1098593203, -5176586701466606797L, -38739L, false, true, (char) 52647, (char) 16994,
        Double.longBitsToDouble(0x3feaceca558117b9L), Double.longBitsToDouble(0x3feab464d6ecec72L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 0, 0, 1, "", "", "\uda6b\udf9f",
        34, -1000, 14369423, 8525936417031369389L, -34464L, false, true, (char) 20370, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd0000003c539f2L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 1, "\ud965\udef3\ud97a\ude6f\ud96d\udf1d\udb88\udfbd\uda6b\udf9f\uda33\ude9d\ud8cc\udc37", "\u0091\u52b2\u0fbe\uaf9c\u9dda\u4975\u1465\ub56c\u7b5c\u134b\u3cee\uba28\u70f1\uc3a7\u50c6\u23f8\u6dd9\u9afa\u1060\ud673\uce62\u8099\ucae1\u125b\u2d8c\u4e1f\ua55b\ubefb\u31b7\u61f5\uccac\ub383", "\ud802\udc41\ud957\udf6a\u6aee\udb8d\udcbe\udabf\udd8f\ub259\u07f6\udb27\ude11\udb94\ude08\ud880\udfaf\uda15\ude5b\ua07a\uda1e\udf33",
        13, 85431, -2034148945, -5402445760713766775L, -85369L, true, false, (char) 56302, (char) 54737,
        Double.longBitsToDouble(0x3feb93c704d9114eL), Double.longBitsToDouble(0x3fe89f2c2d795d52L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 15, 3, "\ud883\udce3\udad5\udff5\ud914\udff0\uda31\udeff\uda6b\udf9f\uda33\ude9d\ud8bc\udf71\udba1\udc5a\ud803\udd09\udb41\ude97\ud987\ude7a\udbf3\udc8e\udb32\udf9a\udb35\udf13\uda53\udc94\ud996\uddb7\ud981\udcad\ucb2f\udbfe\udfc3\ud8d7\udfd3\ud87a\udd1b\ud8d7\uded7\uda46\ude71\udb60\ude04\uda4a\udfa0\ud9f9\udd3d\uda11\udf73\ud957\udf7b\ube28", "\ucae1\u125b\u2d63\ud6b7\ua520\u150c\u3f87\ubab2*\u5056\u219d\u74d2\u9d28\u071a\u5755\ua776", "\u07f6\udb27\ude11\udb94\ude08",
        59, 42469, -780482722, -7279675007993911273L, -20027L, false, true, (char) 54902, (char) 43295,
        Double.longBitsToDouble(0x3fe8b10937180aaaL), Double.longBitsToDouble(0x3fcc96518aaf5a64L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 7, 7, 1, "\ucc7a\udad5\udff5\uda1c\udfa9", "\u1ece\u7881", "\udb41\ude97\ud987\ude7a\ud95d\ude04\ud9da\udd98\uda28\udddf\udbc7\ude3f\ud996\uddb7\ud965\udd95\ucb2f\udbfe\udfc3\ud8d7\udfd3\ud87a\udd1b\ud8d7\udede\uda46\ude71\udb60\ude04\udbd4\udfa5\uda97\udf9a\udb2f\udd38\udb58\udc9d\u9181\ud82f\udd06\ud887\udec6\udbf6\udf55\ud826\udf4a\uda69\udd7d\udb33\udf49\udaad\ude96\ud815\udcdd\ud958\udf14\ud983\ude99\ud88d\udd96\u68d4",
        39, 22326, -1191618132, 2963660063928616171L, 2067L, true, true, (char) 58166, (char) 45090,
        Double.longBitsToDouble(0x3fe43d50ac6d7be0L), Double.longBitsToDouble(0x3fc0af721d7a5dc0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 15, 6, "\u4170\ud8b5\udc9b\udb1c\udd33\udb88\udfbd\uda17\udced\ud913\ude29", "\u5539\u3cd1\u0dca\u68ed\u9337\u9562\ua0bb\u7b49\u9ff8\u00b2\u5aa9\u3cf6\ud754\u70f8\u11eb\u4034\u8d0f\uce63\u3247\u7d89", "\u1778\udb35\udd73\ud82b\udd37\ud961\udc68\ud805\udf41\udb30\udd27\udb40\udd8d\udb8e\udcb9\ub4a7\udba7\udf9b\ud927\uddfe\u1d2e\u3efc\uda72\udf90",
        -2, 42420, 1099944664, 2748387293388632242L, -21650L, true, true, (char) 21465, (char) 49665,
        Double.longBitsToDouble(0x3fb987b8d9a9c950L), Double.longBitsToDouble(0x3fe33d24082a539dL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 6, 6, 1, "\udae7\udddc\udac2\udcb5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\udb4f\udeca", "\u2258\u5fcf\ua8c5\u9383\uc3e7\u5986\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8", "\udbd4\udfa5\uda97\udf9a",
        51, 52302, -1425627517, 3854817171448348199L, 1289L, true, true, (char) 40147, (char) 53967,
        Double.longBitsToDouble(0x3fe80784417a1f9fL), Double.longBitsToDouble(0x3fe19eb1991b6d87L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 10, 1, "\ucc7a\udad5\udff5\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d", "\u7cbc\u0091\u52b2\u68ed\u9337\u21c6\u4c3f\u1400\uc4f8\u5ba7\u5edb\u3cf6\ua7b8\u70f8\uc3a7\u4034\u8d0f\u6e18\ub307\u7d89\ua9cc\u2e65\u9821\u01ff\u3c34\u10b1\u483d\ua55b\u987a\u31b7\u61f5", "\ud975\udf37",
        51, 82732, -1792219722, -2789226571364760743L, 91360L, false, false, (char) 45110, (char) 35996,
        Double.longBitsToDouble(0x3fbb5ef8242bdc80L), Double.longBitsToDouble(0x3feaf4bb8626167aL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 1, "\udae0\udf3b\udad6\udc39\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d\ud8cc\udc37\udba0\udff6\ud803\udd15\udb41\ude97\udb20\ude9d\ud95d\ude04\ud9da\udd98\uda28\udddf\udbc7\ude3f\ud996\uddb7\ud965\udd95\ucb2f\udbfe\udfc3\ud8d7\udfd3\ud87a\udd1b\ud8d7\udede\uda46\ude71\udb60\ude04\udbd4\udfa5\uda97\udf9a\udb2f\udd38\udb58\udc9d\u9181\ud82f\udd06\u1778\udb29\udf1a\udad3\udee1\uda8a\ude28\udbf4\udf55\udaad\udec6\ud815\udcdd\ud958\udf14\ud983\ude99\ud88d\udd96\u68d4\ud975\udf37\udb6e\ude8d", "\u5755\ua776\u662d\ucc53\uc121\u5e85\u4559\u6ee0\u2098\u8202\u1d30\u0dd9\u512a\u5c5b\u0bb6\u9992\u36a8\u7a7d\u511a\ubdf0\u333b\u3b94\uc149\u931d\u8677\u4d04\u42f8\u35b3\uc019\ub9d7\u71e8\u9c6e\u42e0\u4b37\uc588\u1632\uc949\ua582\u151f\u48e6\u5934", "\udb59\udd6c\udb38\udfa7\udaba\udffc\ud9f9\udca8\u4f14\ud8e1\ude21\ud886\ude84\udae2\ude32\udbcb\ude52\udb13\udf3e\uda26\uded3\ud904\uded6\ud89c\udff0\ud980\udd9d\u8099\ud811\udde7\ud828\udf6c\ud849\ude2b\ud9e9\udfc6\udb52\udcf9\ud900\ude80\ud99d\udcb5\ud89e\udebf\ud8e5\udf44\udb8b\udc32\u414d\ud912\udd0a\ud9e4\udfca\ud814\udde5\u40ad\ud93a\ude61\ud89a\udd08\udb18\udc73\ud8ae\udd96\u7f75\uda93\udc2b\ud834\udd88\ud8a6\udf3d\ud935\udda1\uda7e\ude0d\uda3f\udf09\ud876\ude02\ud8e1\udf35\ud9bb\udc6f\udb4c\udf74\ud9e2\udd2b\udaee\udf5a\udaeb\udf69\ud8af\ude24\ud9f9\udf92\ud971\udfae\udb96\uddef\ud99a\udfb8\ud881\udd31\ud996\uddf4\udbda\ude9f\ud98e\udebf",
        50, 57913, 2130186605, 5939175278503015340L, 77186L, true, true, (char) 13946, (char) 55545,
        Double.longBitsToDouble(0x3fb2eccdbcfd69c8L), Double.longBitsToDouble(0x3fd3704ed92917e8L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 10, 9, 1, "\udacb\uddd7\udad6\udc39\uda1c\udfa9\udb88\udfbd\uda6b\udf9f\uda33\ude9d\ud8cc\udc37\ud82e\udf7c\uda01\udcdf\udb41\ude97\ud987\ude7a\ud95b\ude04\ud9da\udd98\ud85f\udddd\ud90b\udca1\ud996\uddc0\ud901\udcc3\ucbb4\udbfe\udfc3\ud8d7\udfd3\ud87a\udd1b\ud8cf\uddde\uda46\ude71\ud964\ude06\udbd4\udfa5\u9278\udb2f\udc90\ud834\udf4c\u91e5\ud82f\udd06\u1778\udb29\uded9\ud826\udf4a\uda69\udd7d\udbf4\udec7\udaad\udec6\ud815\udcdd\ud958\udf14\ud983\ude99\ud88d\udd96\u68d4\ud975\udf37\udb6e\ude8d\ud802\udc41\ud92a\udd50\ud9f0\udef8\udb8d\udcbe\uda33\udd89\ub259\ud9c8\udfd9\udb57\udf48\udb94\uddd3\ud88c\udfb5\uda15\ude5b\udaff\udde3\uda19\udf25\ud925\udd66\ud970\ude0f\ud86a\udf2e\udb6d\udea8\ud985\udfdc\ud8e6\udf08\ud9c2\udee5\udaf5\uded5\ud9bc\uddb1\udabc\udec5\ud851\udea1\ufb61\udbb1\udc21\udb05\udfa4\ud80c\ude8b\udb5c\udd24\uda43\udcda\udb17\udf5a\ud928\udda9\uda2b\udfaf\ud909\udd00\ud93c\udddd\uda3d\udd49\ud844\ude0a\ud8f1\udfd0\u5796\ud3b8\u5407\ud910\udf39\ud94c\udea9\uda4d\udead\udaa3\uddf5\ud8fe\udfac\ud8bb\udfbc\ud8b7\udc74\ud8dd\udde8\udb6e\ude53\udaac\udf75\ud87d\udf50\ueeea\udaff\udce8\udb65\udeba\ud89a\udca2\udaeb\udfeb\udb98\udf8c\udb61\ude88\udbdb\udc86\ud9de\udefb\ud9fa\udec7\udbcb\udf7a", "\u5e71\ua38b\u1327\u3ba3\u9f12\u614f\u74be\u455a\u9330\u1901\ua274\u4ec3\ud1bd\u6919", "\ud8bb\uddfd\ud837\udf49\ud902\udd04\ud901\udfdf\udbc5\udd5e\ud80b\udc8e\udbf7\udfe5\ud991\udc2a\uda40\udc50\udbc9\udc6f\ud8a0\udfc1\udb2d\udd14\ud9ee\udf73\udb92\udea2\ud83b\udc88\ud91b\uded6\udbc0\udf82\ud95b\udd0f\udaad\udc4b\udab5\uddc8\ud959\udcb1\udb96\udf07\ud9c3\udeb0\uda8a\uddfd\ud8c2\udce4\udb30\udc8a\uda1e\udc77\ud8d9\ude61\ud969\udf8b\ud88e\udd07\udbb4\udcfb\ud8dd\ude5d\udb56\udd32\udaf9\ude2c",
        7, 30929, -4711835, -1218907118042882971L, 56819L, true, true, (char) 61337, (char) 45531,
        Double.longBitsToDouble(0x3fd822266dc5b742L), Double.longBitsToDouble(0x3fdbef73de34fab0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|getLegendItems||new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addAnnotation|org.jfree.chart.annotations.CategoryAnnotation|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addAnnotation|org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addEntity|org.jfree.chart.entity.EntityCollection,java.awt.Shape,org.jfree.data.category.CategoryDataset,int,int,boolean|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addEntity|org.jfree.chart.entity.EntityCollection,java.awt.Shape,org.jfree.data.category.CategoryDataset,int,int,boolean,double,double|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|calculateDomainMarkerTextAnchorPoint|java.awt.Graphics2D,org.jfree.chart.plot.PlotOrientation,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleInsets,org.jfree.chart.util.LengthAdjustmentType,org.jfree.chart.util.RectangleAnchor|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|calculateRangeMarkerTextAnchorPoint|java.awt.Graphics2D,org.jfree.chart.plot.PlotOrientation,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleInsets,org.jfree.chart.util.LengthAdjustmentType,org.jfree.chart.util.RectangleAnchor|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|clone||new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|createHotSpotBounds|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,boolean,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|createHotSpotShape|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,boolean,org.jfree.chart.renderer.category.CategoryItemRendererState|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|createState|org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawAnnotations|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawBackground|java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawDomainLine|java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawDomainMarker|java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawItemLabel|java.awt.Graphics2D,org.jfree.chart.plot.PlotOrientation,org.jfree.data.category.CategoryDataset,int,int,boolean,double,double,boolean|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|getLegendItems||new:org.jfree.chart.renderer.category.AreaRenderer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
