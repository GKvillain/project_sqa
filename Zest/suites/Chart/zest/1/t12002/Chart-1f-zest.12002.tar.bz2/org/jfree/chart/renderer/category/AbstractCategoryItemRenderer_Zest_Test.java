package org.jfree.chart.renderer.category;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractCategoryItemRenderer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u1256\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u8260\ud2fe\ua66f\u94a9", "\ud900\udd99",
        6, 40089, -489580114, -3218469358648688768L, -70765L, false, true, (char) 21865, (char) 9820,
        Double.longBitsToDouble(0x3fcdc1238428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u1256\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u8260\ud2fe\u69c9\u9453", "\ud900\udd99",
        6, 40089, -489580114, -3218469358648688768L, -70765L, false, true, (char) 21865, (char) 9820,
        Double.longBitsToDouble(0x3fcdc1238428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 10, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\udafd\udd61\ud860\udd7a\uda67\ude08\ud951\udc95\udbd4\udce1", "\ub78d\u0439\u6f94\u310e\u4630\u884b\u8418\u26eb\u8d60\u6fbb\u7465\u16d5\u8c1c\ubb6c\u4172\ud091\u91a5\u8260\ud2fe\ua66f\u94a9", "\ud900\udd99",
        13, 40089, -489580114, -3218469358648688768L, -55917L, true, true, (char) 39759, (char) 50780,
        Double.longBitsToDouble(0x3fcdc12a0428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1\ud97c\udf74\uda8b\ude70\udaf5\udef1\ud8d9\udc9f", "\u12e6\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\u1681\uc02a\u6840\u4172\ud091\uc61b\ucded\u2856\ua66f\u94a9\ud6ec\ub4a7\ucab1\u80fe\u5a4a\u0718\ud63b\u03f6\u466d\ub205", "\ud9b5\udf3e\ud801\udd6c\ud908\udf5b\ud862\udf48\uda67\udf95",
        21, 38890, 1939042211, 3377248793569974897L, -21800L, true, false, (char) 19227, (char) 24784,
        Double.longBitsToDouble(0x3f83e00026ee0f40L), Double.longBitsToDouble(0x3fbbc6dc14d04428L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 0, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\udb56\ude94\udaf2\udfd7\ud9c2\ude09\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u1256\u83b4\000\000\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u8260>\000\u94a9", "\ud900\udd99",
        6, 40089, -489580114, -3218469358648688768L, 99680L, true, false, (char) 5642, (char) 39268,
        Double.longBitsToDouble(0x3fe9c13a9e9d44f1L), Double.longBitsToDouble(0x3fb35056cfe7f0d0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\uda74\udf44\000\udb8e\udea6", "\u1750", "\ud927\udcd4\ubcfa\000\udb0a\udd27\000\ud956\udeb0\ud931\udefe",
        58, 80483, 1995491805, -450127399881431952L, -74435L, true, true, (char) 14437, (char) 16485,
        Double.longBitsToDouble(0x3fefce6958b3f7f4L), Double.longBitsToDouble(0x3fd7f0000d223868L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\ub2ef\u8586\u4c9e\u26eb\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u8260\u07c4\u3902\u94ef", "\ud900\udd99",
        6, 40089, -489611346, -3218469358648688768L, 8123L, false, true, (char) 21865, (char) 9820,
        Double.longBitsToDouble(0x3fcdc1238428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 15, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2", "\u0b19\u00e1\u1750\u45bb\u03ca\u6f94\u2837\u78cb\uca3c\u4c9e\uae52\uc9a4\u38c4\u66a3", "\ud9d6\udf06\ud8b7\udf5b\ud97b\udf77\udae7\uddb6\uda06\udcc2\ud847\udc3f\uda5d\udf7f",
        21, 58759, -1960188614, -8281832349760735281L, 4878L, false, true, (char) 53973, (char) 61595,
        Double.longBitsToDouble(0x3fea1df8d51f06f5L), Double.longBitsToDouble(0x3f325a75acfd3800L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 5, 5, "\udbef\udc71\ud9ee\udf73\ud998\udc48\uda3f\udf4a\ud9b2\udea2\udacb\uddd7\ud951\udcb0\udbd4\udce1\ud970\udc74\udaf7\uddb5\ud87d\udca8\ud927\udd86", "\u1256\u095b\ub576\u272f\u76fb\u6fc5\u4207\u16d5\u4cc2\u7bb4\uc180\ud091\uc61b\u8260\u622b\ua66f\u94a9\u75a8\ub4a7\ucab1\u2e3e\u8676\u0718\ud63b\u03f6\u466d\ub205", "\ud9b5\udf3e\ud801\udd6c\ud908\udf5b\ud862\udf48\udb68\udf15\ud870\udc73\ud9a6\udfea\udb26\udf1d\ud984\udca1\ud813\udf4d\ud9af\udcb7",
        18, 94213, -1629327813, 5968529664880839924L, -39597L, true, false, (char) 51837, (char) 25000,
        Double.longBitsToDouble(0x3fe8720249f5daedL), Double.longBitsToDouble(0x3fd4b40100cc16beL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1\ud970\udc74\uda8b\ude70", "\u6f94\u070e\u1256\u095b\u4c9e\u26eb\ub481", "\ud97a\udcdf\udaf8\udf25\uda66\udcce\uda7a\udf2b\ud97b\udfad\udae7\uddb6\uda4a\udf03\ud847\udc3f\uda5d\udf7f\uda44\udca1\ud9ff\udf28\ud9fb\udfb5\ud900\udd99\ud99d\uddf5\uafda\ud835\udeaf\ud86a\udd5b\ud84e\ude27\udbab\udf84\ud95d\udfca\uda06\udd96\ud9a7\ude52\ud9b5\udf3e\ud801\udd6c\ud908\udf5b\ud862\udf48\ud930\ude58\uda5a\udd67\ud9dd\uddd8\ud9b8\udc32\ud9ed\ude15\udb80\udd3c\uda26\ude1d\ud9b2\udf6f\udbc7\udf4d\ud924\ude6e\ud837\udc2b\ud9d4\udcc5\uda82\udd43\udba4\udf19\uda7a\ude0c\ua4af\ud84d\ude00\ud8fd\udfbe\udb3c\udddb\ud961\ude15\ud978\udc5c\ud948\udf1b\uda44\uddca\ud864\udc5e\uda8e\udd26\ud8d6\udda7\udb36\udfd7\ud96a\udf3d\ud9c2\udc9d\udafa\udced\ub9db\ud8c9\udefa\ud831\udf24\ud825\udd66\udbd8\udc41\uda40\udd93\udb9f\ude4a\udb84\udc3b\ud937\udeea\uda0c\ude21\udb74\ude90\udbcb\udffa\udbf6\ude01\udb8d\udf7c\ud832\udc4f\udb62\udde8\udbe1\udcf6",
        9, 3074, -1760549735, 3607115509442840246L, -19680L, false, true, (char) 56028, (char) 4451,
        Double.longBitsToDouble(0x3fd57ed112715e90L), Double.longBitsToDouble(0x3f9d30076328cac0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 10, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\ud9ba\udca4\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u893a\u4aef\u6070\u4c9e\u26eb\ud44a\ub9a7\u58fd\u5be5\u8c1c\ubb6c\u4172\ub5c9\u5949\u8348\ud2fe\ua66f\u94a9", "\udb76\udfa6",
        52, 40089, -489580114, -3218469358648688768L, -41259L, true, false, (char) 40562, (char) 45183,
        Double.longBitsToDouble(0x3fcdc1238428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda5d\udc2a\udaa5\udc6e\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u0c26\u7d92\000\000\u5f2e\ud0d7\u4f0e\u842e\000\000\u9097\ubb6c\u2468\ud091\uc61b\u8260\ud2fe\ua66f\000", "\000",
        6, 88249, -489580114, 187456290688L, -70765L, false, true, (char) 21865, (char) 34651,
        Double.longBitsToDouble(0x3e9c21410b600000L), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 6, 0, "\uda5d\udc2a\ud80e\udf66\ud847\udd87\udaab\udd5c\udacf\udf1d\udaf7\udfea\uda42\ude69\ud85d\udef6", "\ub7d9\u0439\u6f94\u070e\u1256\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u74ff\ud2fe\ua66f\u94a9", "\ud900\udd99",
        6, 40089, -489580114, -3218469356658914030L, -70765L, false, true, (char) 21865, (char) 49244,
        Double.longBitsToDouble(0x3fcdc1238428216cL), Double.longBitsToDouble(0x3fd38275336b67faL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\ud81b\udf0a\ud889\udfa6\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udaf9\ude01", "\ub78d\u0439\u17e0\u5990\u124e\u095b", "\ud931\udefe\udb8c\udec3\udbbb\ude71\ud97a\udcdf\udaf8\udf25\uda66\udcce\uda7a\udf2b\ud978\udd8c\ud8ce\udc99\ud81a\ude6d\ud948\udef3\uda5d\udf2a\uda44\udca1\ud9ff\udf28\ud9ee\udd8d\ud935\udd89\ud99d\uddf5\ud9b3\udd23\udaf5\udff5\ud86a\udc8a\ud84e\ude27\udbb7\udc84\udadc\udec8\uda06\udd89\ud9a7\ude52\ud9b5\udf3e\ud801\udd6c\ud908\udf5b\ud85b\udee3\ud909\udf25",
        6, 40236, 1365334333, 1356672700561695262L, -77007L, true, false, (char) 43346, (char) 6098,
        Double.longBitsToDouble(0x3fec7355c11e49c5L), Double.longBitsToDouble(0x3fc31a6471764f64L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 0, "\ud839\udf91\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u5455\ua182\u4c9e\u26eb\u693f\u6fbb\u4207\u14d5\u8c1c\u96d2\u4172\ud091\uc61b", "\uda5d\udf7f\uda44\udca1\ud9ff\udf28\ud9dd\udfb5",
        24, 87516, 1540010633, 7048583893730308960L, 11784L, true, true, (char) 51653, (char) 30319,
        Double.longBitsToDouble(0x3fe1ca3d8cee091cL), Double.longBitsToDouble(0x3fd0a085be704ea6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 0, 0, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\udb56\ude94\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u1256\u095b\u4c9e\u26eb\u6573\000\000\000\000\000\uc92f\ud091\u7c2e\u8260\ud2fe\u676f\u94a9", "\000",
        -5, 95384, -489580114, -3218469358648688768L, -70765L, false, false, (char) 21865, (char) 40871,
        Double.longBitsToDouble(0x3fcdc0000428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\000\000", "\ub78d\u0439\u6f94\u070e\u1256\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u8260\ud2fe\ua66f\u94a9", "\ud900\udd99",
        6, 40089, -489580114, -3218469358648688768L, -70765L, false, true, (char) 21865, (char) 9820,
        Double.longBitsToDouble(0x3fcdc1238428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 5, 8, "\uda5d\udca1\ud978\ude7c", "\ub8ff\uc8ab\u584d\ub280\u7dab\u1750\ub78d\u0439\u6f94\u6e77\ucd4b\u095b\u576d\u14e2\u8c60\u6fbb\u39bb\u16d5\ud31b\u8c18\u4172\ud091\uc61b\u8260\ub283\ua66f\u94a9\ud6ec\ub4a7\ucab1\u8085\u8c48\u0718\uc81d\ua77c\u1790\u9b4e\u653f\uc9ce", "\ud900\udf79\ud862\udf48\udb75\udffb\ud878\udfa5",
        19, 40609, -1309699862, 5086515288803881350L, -81009L, false, true, (char) 969, (char) 20295,
        Double.longBitsToDouble(0x3fb67d555f2c2f88L), Double.longBitsToDouble(0x3fd27dd7bbd6b83aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 0, "\uda5d\udc2a\ud9ce\udef7\udbbf\ude64\udb76\udd52\ud9c9\udd86\uda36\udfb9\ud95c\udc4e\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u689f\u167f\u4c9e\u26eb\u8212\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u8260\ud2fe\ud4b5\ucc90", "\ud900\udd5c",
        6, 40089, -489580114, -3201017910092628096L, -37763L, true, false, (char) 5642, (char) 39268,
        Double.longBitsToDouble(0x3fd382753d3a889aL), Double.longBitsToDouble(0x3fe191581a86a07fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 0, "\udb1c\ude69\ud972\udc3b\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1\ud970\udc74\ud8dc\udd2f\udac4\udefa\ud927\udd86\ud927\udcd4\uda5f\udf11\ud9d9\udc16\udb0a\udd27", "\ub481\ud3ad\ucd71\u85ef\u8c1c\ubb6c\u4172\u9899\uc61b\u8260\ud2fe\ua66f\u94a9\ud6ec\ub4a7\u4a93\u8085\u5a4a\u0718\ud63b\u03f6\u466d\ub205\u1c38\uc9ce\u7181\u2ed5\u1fa6\uc0ee\u3997", "\ud883\udecc",
        29, 48318, -1688547695, -677708628199582833L, -98442L, false, false, (char) 46131, (char) 16917,
        Double.longBitsToDouble(0x3fb083c67510cc50L), Double.longBitsToDouble(0x3fe08a3d72aa242fL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 0, "\uda5d\udc2a\ud978\udeb2\ud847\udd28", "\u1a28\u584d\u8c81\uc0bb\u1750\ub78d\u0439", "\ud9bf\udc16\udb0a\udd27\uda63\udfc7\ud956\udf87\ud931\udefe\udb8c\udec3\ud97f\udc72\ud97a\udcdf\udaf8\udf25\uda66\udcce\uda7a\udf2b\ud97b\udee5\udae7\uddb6\uda4a\udf03\ud847\udc3f\uda5d\udf7f\ud950\udca7\udbbe\udec7\ud9fb\udf38\ud900\udd99\ud99d\uddf5\ud8a4\udce3\udaf5\udff5\ud86a\udc8a\ud84e\ude27\udbab\udf84\udadc\udec8",
        34, 61632, 152864437, 602089191766200586L, 88061L, true, false, (char) 55362, (char) 64139,
        Double.longBitsToDouble(0x3fb78a55d6efee88L), Double.longBitsToDouble(0x3fd7bc0ba1fabdd8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 0, "\000", "\u4752", "\ud951\udcb0\udbd4\udce1\u00c8\uda5e\ude8e\udaf5\udef1\ud927\udd86\ud927\udcd4",
        16, 43744, 0, 765460480L, -99779L, false, true, (char) 40496, (char) 28298,
        Double.longBitsToDouble(0x3fcba00707b502e0L), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 11, 15, "\uda3e\udc2a\ud978\ude7c\ud95e\udf94\ud8db\ude9b\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udb69\udd8c", "\u88f0\u43af\u6fe2\u680d\u1274\u095b\u4c9e\u26eb\ub481\uc053\u4207\u16d5\u2846\u0a4a\u4172\u22ac\u7ddc\u0a5c\uadb6\ud751\u35cb", "\ud934\udff3",
        21, 29253, -499213906, -3218387449327386752L, -70765L, false, true, (char) 26027, (char) 48988,
        Double.longBitsToDouble(0x3fedcea4990a085bL), Double.longBitsToDouble(0x3fe9593a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 3, 0, "\udbcb\uddc1\ud975\udc7a\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1\ud970\udc74", "\u7b08\u159e\u070e\u1256\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u47bc\u4765\u93fd\u8d0d\ud2fe", "\ud9ff\udf28\ud9fb\udfb5\ud900\udd99\ud99d\uddf5\ud8a4\udce3\udaf5\udff5\udbdd\udf37\udbfb\udccb\udbab\udf84\udadc\udec8\uda06\udd89\ud9a7\ude52\ud9b5\udf3e\ud801\udd6c\ud908\udf5b\ud862\udf48\udabe\udc60\uda6e\udc27\ud911\ude8a\udae0\ude3c\ud966\udf58\udb6d\udef3\udb48\udf1c\udb08\uddff\udbe1\udd48\udb74\ude85\ud921\uddcd\ud848\udefb\uda9a\udfe9\ud9f8\udc9a\udbe4\udd8f\udb15\uddcf\uda2b\udd1d\uda8e\udc8c\ud8e4\ude06\udb17\udf12\udb74\udd8b\ud805\udf91\udb0f\udfab\udaf4\udf99\uda7d\udee6\ud9c7\udcb5\ud964\udc78",
        54, 54071, 480028655, 8378546869801871358L, 15935L, false, true, (char) 10867, (char) 21339,
        Double.longBitsToDouble(0x3fee1076674b781fL), Double.longBitsToDouble(0x3fdcd771f98af86eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 7, 12, "\uda5d\udc2a\udad9\udf4d\ud80b\udf28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u1bec\u070e\u1256\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\ub2bb\ua11b\ubb6c\u4172\ud091\uc61b\u8260\ud2fe\ua66f\u94a9", "\ud900\udd99",
        6, 40089, -1843426130, -3218469358648688768L, -70765L, false, true, (char) 21865, (char) 27855,
        Double.longBitsToDouble(0x3fcdc123977c216cL), Double.longBitsToDouble(0x3fea493a9f9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda5d\udc2a", "\u4752\u556f\uc8ab\ub2f7\000\u7d18\ub3e2\000\000\u6f94\u4676\u1256\u095b\u4c9e\u26eb\ub481\u6fbb\u4207\u00dd\000\000\u1d0a\000\u6a41\u6241\ud2fe\u676f\u94a9\ud6ec\u1f53\000\000\000\000\u5aaa\000", "",
        34, 61632, 152864437, 1022862004480L, 87904L, true, true, (char) 58153, (char) 48932,
        Double.longBitsToDouble(0x3fe45423db70a888L), Double.longBitsToDouble(0x3fab63806cbb8060L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u1256\u095b\u4c9e\u26eb\ub481\u6fbb", "\udaf8\udf25\uda66\udcce\uda7a\udf2b\ud97b\udfad",
        35, 37006, -852816066, -579768115072033101L, 4878L, false, true, (char) 53973, (char) 61595,
        Double.longBitsToDouble(0x3fdcdbf1aa6ca91eL), Double.longBitsToDouble(0x3f325a75acfd3800L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 2, 0, "\uda5d\udc2a\ud958\udc6c\ud82d\udc22\ub9dd\ud9c1\udda2\udaf2\udfd7\ud92a\uddb0\udad4\ude01", "\u164a\ucc00\u6f94\u070e\u1256\u1564", "\ud931\udefe",
        58, 80483, 1995491805, -450127400337070992L, 6167L, true, true, (char) 50786, (char) 18257,
        Double.longBitsToDouble(0x3febf3e94eb3f7f4L), Double.longBitsToDouble(0x3fd299908d223868L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 0, "\uda5d\udc2a", "\u8d52\u0109\ucf21\u584d\u4022\u0b0d\u80aa\ub78d\u0439\u7bfe\u613c\u1256\u095b\ub665\u26eb\ub481\u6fbb\uce1b\u5f75\u0d4c\ubb6c\u4172\ub0dc\uc61b\u8260\ud2fe\ua66f\u94a9\ud6ec\ub4a7\u520b\u1b98\ud4f4\u9d3a\u335a\u173f", "\uda06\udda6",
        42, 50437, -1942745874, 2319032708907532088L, 47011L, true, false, (char) 56881, (char) 41282,
        Double.longBitsToDouble(0x3fb60b33991a5c98L), Double.longBitsToDouble(0x3fe53ac31d7169d5L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94\u070e\u1256\u095b\ua322\u1050\ub481\u6fbb\u4207\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u8260\ud2fe\ua66f\u94a9", "\ud900\udd99\ud99d\uddf5\ud8cb\uddf8\udaf5\udf88",
        53, 664, -1088795816, 1633647488653686070L, -92356L, false, false, (char) 30879, (char) 11952,
        Double.longBitsToDouble(0x3febbb19a55a1892L), Double.longBitsToDouble(0x3fe5ef2744b066edL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 13, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u0439\u6f94", "\udb0a\udd27\uda63\udfc7\ud956\udf87\ud931\udefe\udb8c\udec3\ud97f\udc72\uda36\udcbb\udaf8\udf25\uda66\udcce\uda7a\udf2b\ud97b\udfad\udae7\uddb6\uda4a\udf03\ud847\udc3f\uda5d\udf7f\uda44\udca1\ud9ff\udf28\ud9fb\udfb5\ud900\udd99\ud99d\uddf5",
        29, 66886, -749358292, -6538101309879727272L, -4458L, false, false, (char) 9820, (char) 5642,
        Double.longBitsToDouble(0x3fd0a085be704ea6L), Double.longBitsToDouble(0x3fe4ea278b1e534eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 0, "\uda5d\udc88\ud978\ude7c\uda4e\ude6c\uaadf\ud9b2\udea2\uccb8\ud950\udff6\udbd4\udce1", "\u343e\u0439\u1bc7\uce6b\u1256\ud7de\u01e0\u26eb\ub481\u6fbb\u6a53\u169a\u8c1c\ubb6c\uc14e\u00fb\ub0c1\u8260\ud2fe\ua66f", "\ud97a\udf33\ud99b\udd59\ud99d\uddf5",
        29, 66886, -749358292, -6538101309879727272L, 66602L, false, false, (char) 9820, (char) 5642,
        Double.longBitsToDouble(0x3fe1d3ca573827e5L), Double.longBitsToDouble(0x3fe4ea278d8a876dL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 10, 0, "\udaf7\udc77\uda24\udf71\ud82b\udf4b\udaee\udfe0\ud860\udd7a\uda67\ude08\ud951\udc95\udbd4\udcd6", "\ub78d\u4f39\u6f94\u310e\u509a\u4af4\u78da\u2aa6\u8d26\u6fbb\uce74\u59e0\u8c1c\ubb6c\u427f\u9ee3\u81cf\u8260\ud2fe\ua66f\u94a9", "\ud900\udd99",
        13, 40089, -1764648480, -7376649370363789209L, -55917L, true, true, (char) 42569, (char) 7859,
        Double.longBitsToDouble(0x3fcdc12a0428216cL), Double.longBitsToDouble(0x3fe816357e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.CategoryItemRendererState:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 10, 10, 0, "\udb22\uddc7\udb2f\udef4\udbae\udf7d\udafd\udd35\ud860\udd7a\udb85\udec7\ud951\udf69\ud93a\udd26", "\ub78d\u0439\u6f94\u310e\u982e\u6975\u2ff1\u48bb\u8d60\u6fbb\u7465\u16d5\u8c1c\ubb6c\u4172\u471f\u91a5\u8260\u0277\u88ee\u57c5", "\udb82\udfac",
        1, 81762, -489580114, -3218469355887526016L, -55917L, true, true, (char) 39759, (char) 50780,
        Double.longBitsToDouble(0x3fcdc12a0428216cL), Double.longBitsToDouble(0x3fe9c13a9e9d44f1L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 6, 15, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\udafd\udd61\ud860\udd7a\udb41\ude7e\udba5\uddb3\udbd4\udce1", "\ub78d\u5697\u6f94\u310e\u4630\u884b\u57a6\ub949\u9474\u5fa1\u7465\u16f1\u8c1c\ubb6c\u4172\ud091\u91a5\u8260\ud435\ua66f\u94a9", "\ud900\udd99\ud937\udca4\ud8a4\udce3\udaf5\udff5\ud86a\udc8a\ud84e\ude27\ud9f5\udcac\ud8c7\udd65\ucd27\ud9a7\uded7\udb63\udd41\udbb1\udf28\ud908\udf5b\ud862\udf48\ud8e3\udd91\ud9f3\ude80",
        -2, 71781, 682132942, 4185134629663243129L, 44155L, false, false, (char) 26618, (char) 53315,
        Double.longBitsToDouble(0x3fe9ac1c432d0aa0L), Double.longBitsToDouble(0x3fe503bc0a7a5a0aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 11, "\uda2b\udc05\uda35\udeae\udaa8\udd21\ud909\udcfe\ud860\udd7a\uda67\ude08\ud951\udc95\udbd4\udce1", "\ub78d\u0439\u6f94\u1628\u86dd\u884b\u8d30\ub1df\u1f8b\u6fbb\u7465\u16d5\u8c1c\u3580\u0821\u38ec\u6d76\u0f00\ud382\ua66f\u87e2", "\uda0c\udfb9\uda08\udf57\ud809\udf19\udaf6\udc00\ud86a\udc8a\ud893\udc68\uda90\udd1f\ud8c7\udd65\ucd27\ud9a7\uded7\ud9e3\udf41\ud801\udd6c\ud908\udf5b",
        30, 2333, 1179473246, 2677957416239636089L, -41552L, false, true, (char) 43958, (char) 42878,
        Double.longBitsToDouble(0x3f9039add13ec780L), Double.longBitsToDouble(0x3fee3b8f0a409b2cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 7, 7, 2, "\uda5d\udc2a\udb95\udd29\ud847\udd5d\ud86b\udddb\uda96\udfcc\udaf2\udfd7\ud9c2\ude09\udbd4\udce1", "\u87ba\u690c\ub84a\u070e\u1256\u83b4\000\000\ub481\u6fbb\u4207\u16d5\u8bd0\ubb6c\u4172\ud091\uc61b\u8260>\000\u94a9", "\ud900\udd99",
        6, 40089, -489580114, -3218469358648688768L, 99680L, true, false, (char) 5642, (char) 39268,
        Double.longBitsToDouble(0x3fe9c13a9e9d44f1L), Double.longBitsToDouble(0x3fc4682b67f3f868L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.LegendItemCollection:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u0b24\u4752", "\u00fd\udbbd\udd76\000",
        -5, -1000, 1275068416, 1711477183093980410L, -66284L, false, false, (char) 0, (char) 25971,
        Double.longBitsToDouble(0x3fa70d1a27be7ff0L), Double.longBitsToDouble(0x3fddd215e708ede0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 3, 14, "\ud8a2\ude55\ud978\ude7c\ud847\udd28\ub9dd\udb56\ude94\udaf2\udfd7\ud9c2\ude09\udbd4\udce1", "\ub78d\u0439\u87f7\ubbf2\u1306\u83b4\000\000\ub481\u6fbb\u4207\u40c2\u8c1c\u3405\u089c\ud020\uc61b\u8260>\000\u94a9", "\ud900\udd99",
        6, 45177, 997154067, -3218469359140733056L, 99680L, true, false, (char) 5642, (char) 39268,
        Double.longBitsToDouble(0x3fe9c13a9e9d44f1L), Double.longBitsToDouble(0x3fda79871f8702d2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 15, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\udb56\ude94\udaf2\udfd7\udb6f\udff3\udbd4\udce1", "\u03b4", "\uda5f\udf11\ud9bf\udcd9",
        51, 65618, 0, 1888245687318048558L, -37757L, false, false, (char) 59453, (char) 29302,
        Double.longBitsToDouble(0x3feeebbd59ed40b8L), Double.longBitsToDouble(0x3f7da24c5a4acd80L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 6, 0, "", "", "\udacf\udf1d",
        45, 41821, 977662855, -4067493973890989627L, 49757L, false, true, (char) 54457, (char) 41640,
        Double.longBitsToDouble(0x3fe80005756f5c84L), Double.longBitsToDouble(0x3fcae4f9e1ccb680L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 0, "\udbff\udd0a", "\u273d", "",
        -5, -1000, 30408, 0L, -100000L, false, false, (char) 128, (char) 25321,
        Double.longBitsToDouble(0x3f46380000000000L), Double.longBitsToDouble(0x3fd732da085c7200L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 3, "\uda5d\udc2a\ud978\udeb2\ud847\udd28", "\u1a28\u584d\u8c81\uc0bb\u1750\ub78d\u0439", "\ud9bf\udc16\udb0a\udd27\uda63\udfc7\ud956\udf87\ud931\udefe\udb8c\udec3\ud97f\udc72\ud97a\udcdf\udaf8\udf25\uda66\udcce\uda7a\udf2b\ud97b\udee5\udae7\uddb6\uda4a\udf03\ud847\udc3f\uda5d\udeb2\ud950\udca7\u9459\ud9fb\udf38\ud900\udd99\ud99d\uddf5\ud8a4\udce3\udaf5\udff5\ud86a\udc8a\ud84e\ude27\udbab\udf84\udadc\udec8",
        34, 61632, 152864437, 602089191766200586L, 88061L, true, false, (char) 55362, (char) 64139,
        Double.longBitsToDouble(0x3fb78a55d6efee88L), Double.longBitsToDouble(0x3fd7bc0ba1fabdd8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 15, 0, "\uda5d\udc2a\ud9b9\uded2\ud847\udd28", "\u1a28\u584d\u8c81\uc0bb\u1750\ub78d\u0439", "\ud9bf\udc16\udb0a\udd27\uda63\udfc7\ud956\udf87\ud931\udefe\udb8c\udec3\ud97f\udc72\ud97a\udcdf\udaf8\udf25\uda66\udcce\uda7a\udf2b\uda5f\udfc7\udae7\uddb6\uda4a\udf03\ud847\udc3f\uda5d\udf7f\ud950\udca7\udbbe\udec7\ud9fb\udf38\ud995\udc64\ud9e5\ude5e\ud8a4\udcb7\udaf5\udff5\ud86a\udc8a\ud8f1\udc77\uda46\ude24\udadc\udec8",
        37, 61632, 152864437, 602089191766200586L, 88061L, true, false, (char) 55362, (char) 64139,
        Double.longBitsToDouble(0x3fb78a55d6eca760L), Double.longBitsToDouble(0x3fd7bc0ba1fabdd8L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 0, "", "", "7",
        16, -1000, 2061543936, -4070132912741895198L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e45bd7000000000L), Double.longBitsToDouble(0x3fcae4f9f5ccb680L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 6, 6, 0, "\ud82a\udd10\uda14\udf63\uda4e\uded0\uaadf\ud9b2\udea2\udb79\udcda\ud951\udca5\uda9f\udf28", "\u7dfd\u6466", "\ud9bf\udc16\ud96e\udcba\uda51\udd09\ud963\udd0e\ud9bb\udde9\u462d\udab0\udc57\ud97a\udca4\udaf8\udf25\uda66\udcce\ud850\udfe3\ud88d\udeac\ud8f2\udd53\uda45\udc1e\ud847\udc3f",
        52, 13995, 1062382975, 484572153016968528L, -23522L, false, true, (char) 38397, (char) 20950,
        Double.longBitsToDouble(0x3fee2dd5285c7e06L), Double.longBitsToDouble(0x3fe3dacbf2d63d06L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 10, 0, "\udaf7\udc77\uda24\udf71", "\u03bc\u85a3\u68ca\u8f86\uae84\u1750\ub78d\u4f39\u6f94\u310e\u509a\u4af4\u78da\u2aa6\u8d26\u6fbb\uce74\u59e0\u8c1c\ubb6c\u427f\u9ecc\u81cf\u8260\u51a9\u5235\u2d10\ud6ec\ub4a7\ub182\u06be\u6bd0\u8d36\u1f26\u337e\u37c6\u43df\u7da5\u38fe", "\ud84b\ude06\ud856\udf12\ud861\ude51\ud843\udc65\uda72\uddf5\udb23\uddd9\ud948\udd8a\u5784\udb82\udd9c\udb60\udff4\ud834\ude6c\udb2e\ude4e\udbbf\udf51\udaf5\uddba\ud99d\ude47\ud8c2\udd54\udb36\udff8\udb87\ude1c\ud8b6\uddaa\udb19\uded7\udb4d\udd94\ud96e\uddfc\udb91\udd4a\udac0\udf37\ud8e9\udd49\ud9f0\udf4d\udbf9\udcdc\ud92d\ude91\udb1c\udc7f\udbb0\udfb7\ud9c7\udf55\udb93\uddc9\ud9cb\udc2b\ud906\udf81\ud861\udd2c\ud817\udddf\udbae\udda7\udacd\udcf1\udaa6\udc44\ud8c8\udc21\udb34\udc99\udba1\udc4f\udba5\ude76\uda29\udec6\u7801\udb1c\udcf5\udb10\udf05\ud816\udd2e\ud825\udd27\udacd\udf13\ud97c\udc22\uda5b\udd8a\ud97d\udceb\ud97f\ude94\ud899\udc1a\u98b9\ud89e\udc0c\ud989\udee3\ud905\udfa3\uda39\udc68\udbfe\udf1a\ud90e\udceb\ub29a\ua0c8\ud9c9\uddfc\ud972\udc9f\udae7\uddf3\ud9a5\udc27\udbb3\ude6c\ud8ed\udd75\ud881\uddab\ud8da\ude09\ud9eb\udfac\ud901\uddb4\u710a\ud86c\udf7b\udbcd\ude17\ud9bf\ude82\udb49\udf70\udbc7\udf96\ud8ad\udfc2\ud9f3\udd28\ud97e\udde7\uda36\ude59\ud80d\udefe\udbe4\udd71\ud87f\udef8\uda93\ude4a\udbee\udf14\udaac\udc4f\udbfe\udfc9\udbc5\udcd1",
        1, 34812, -1647318726, 8641370684919885308L, -46828L, true, true, (char) 28286, (char) 2429,
        Double.longBitsToDouble(0x3fe18b8cc4ede2aaL), Double.longBitsToDouble(0x3fda6c4e2e1c8084L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 15, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\udafd\udd61\ud860\udd7a\udb41\ude7e\udba5\uddb3\udbd4\udce1", "\ub78d\u5697\u4f11\u30cf\u4630\022\u57d9\ub949\ubcf5\u5fa1\u7465\u16f1\uaf42\ubb6c\u1971\ucffd\u91a5\u2ed2\ud435\ua66f\u94a9", "\ud900\udd99\ud937\udca4\udbf7\udd79\udafc\udc5d\ud86a\udc8a\ud84e\ude27\ud9f5\udcac\ud8c7\udd65\ucd27\ud9e8\ude37\udbd6\ude5e\udbb1\udf28\ue0e2\ud830\uddee\ud8d4\udfb4\ud9f3\ude80",
        -2, 71781, 682132942, 4185134631639931257L, 17868L, false, false, (char) 26618, (char) 15939,
        Double.longBitsToDouble(0x3fe1bb350bcbcc39L), Double.longBitsToDouble(0x3fe501514a7a5a0aL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 15, 15, 0, "\udb2b\udef8\ud977\udd17\ud851\udc1c\ud997\udce4", "\u60bc\u4938\u2b0c\u5a13\u292a\uad11", "\ub585\udb07\uddaa\uda10\udcf3\ud886\uddb3\udac4\udc3c\udb88\udebe\ud8bf\ude33\ud9e7\ude74\ud85d\udd98\ud90a\udd1f\uda7a\udf2b\ud97b\udfad\udada\udd40\uda16\udc03\ud97e\udd4c\udbb1\ude72\udaa9\udd04\ud071\ud97f\udfc4\udb0f\udc7a\ud944\ude6a\ud8a4\udce3\udaf5\udff5\ud847\udd12\ud84e\ude63\ud9f5\udcac\uca9a\udb79\udf90\uea16\ud849\udf8c\ud934\udd86\ud908\udf5b\ud920\udd4d\ud8c2\udc2f\ud9f3\ude80\udbd4\udfae\ud921\udf0a\ud96e\udc0f\uda52\udd3b\ud861\udd7a\udb43\udeb3\ud833\udfae\uda61\ude9c\uda12\ude4d",
        6, 21413, 2004957997, 6488141838805865082L, -55013L, true, false, (char) 22475, (char) 10432,
        Double.longBitsToDouble(0x3fe997a518a38691L), Double.longBitsToDouble(0x3fee7c066029febaL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 0, "\uda5d\udc2a\ud978\ude7c\ud847\udd28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\ud924\ude8a", "\ub78d\u0439\u849d\u9216\ubb8f\u42b5\u628e\u4e7d\ub481\u8960\u3c67\u16d5\u8c1c\ubb6c\u4172\ud091\uc61b\u03dc", "\uda44\udca1\ud9ff\udf28\ud9fb\udfb5\ud900\udd99\ud99d\uddf5\ud8a4\udce3\udaf5\udff5\ud86a\udc8a\ud84e\ude27\udbab\udf84\udadc\udec8\ucc41",
        22, 50437, 140184814, 2833768063201050424L, -68896L, false, true, (char) 41500, (char) 5424,
        Double.longBitsToDouble(0x3fe59752da1a0b23L), Double.longBitsToDouble(0x3fe2976cbbb079f0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.awt.geom.Point2D$Double:Point2D.Double[0.0, 0.0] |this=org.jfree.chart.renderer.category.AreaRenderer:@?\0121=org.jfree.chart.renderer.category.AreaRenderer:@? |this=org.jfree.chart.renderer.category.AreaRenderer:@?\012",
        Z.run(T, 2, 5, 7, 12, "\uda5d\udc2a\udad9\udf4d\ud80b\udf28\ub9dd\ud9b2\udea2\udaf2\udfd7\ud951\udcb0\udbd4\udce1", "\ub78d\u63fa", "\ud9bf\udc16\udb0a\udd27",
        4, 46223, 439641459, -1770613747462576517L, -68194L, true, false, (char) 19675, (char) 51653,
        Double.longBitsToDouble(0x3f325a5ae3cb9800L), Double.longBitsToDouble(0x3fcdc123977c216cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|getLegendItems||new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addAnnotation|org.jfree.chart.annotations.CategoryAnnotation|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addAnnotation|org.jfree.chart.annotations.CategoryAnnotation,org.jfree.chart.util.Layer|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addEntity|org.jfree.chart.entity.EntityCollection,java.awt.Shape,org.jfree.data.category.CategoryDataset,int,int,boolean|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|addEntity|org.jfree.chart.entity.EntityCollection,java.awt.Shape,org.jfree.data.category.CategoryDataset,int,int,boolean,double,double|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|calculateDomainMarkerTextAnchorPoint|java.awt.Graphics2D,org.jfree.chart.plot.PlotOrientation,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleInsets,org.jfree.chart.util.LengthAdjustmentType,org.jfree.chart.util.RectangleAnchor|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|calculateRangeMarkerTextAnchorPoint|java.awt.Graphics2D,org.jfree.chart.plot.PlotOrientation,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleInsets,org.jfree.chart.util.LengthAdjustmentType,org.jfree.chart.util.RectangleAnchor|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|clone||new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|createHotSpotBounds|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,boolean,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|createHotSpotShape|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,boolean,org.jfree.chart.renderer.category.CategoryItemRendererState|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|createState|org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawAnnotations|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.chart.util.Layer,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawBackground|java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawDomainLine|java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,java.awt.geom.Rectangle2D,double,java.awt.Paint,java.awt.Stroke|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawDomainMarker|java.awt.Graphics2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.plot.CategoryMarker,java.awt.geom.Rectangle2D|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|drawItemLabel|java.awt.Graphics2D,org.jfree.chart.plot.PlotOrientation,org.jfree.data.category.CategoryDataset,int,int,boolean,double,double,boolean|new:org.jfree.chart.renderer.category.AreaRenderer:",
    "M|org.jfree.chart.renderer.category.AbstractCategoryItemRenderer|getLegendItems||new:org.jfree.chart.renderer.category.AreaRenderer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
