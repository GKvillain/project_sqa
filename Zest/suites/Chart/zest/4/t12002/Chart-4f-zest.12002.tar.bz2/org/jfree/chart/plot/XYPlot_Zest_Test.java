package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class XYPlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\u6428\udb82\ude54", "\u1c6d\u3987\ua068\ua9f6\u7eaf\u8b30\ud20d\u3962\u55f6", "\ud8d8\udd12\ud836\udd1b",
        47, 51624, -1788187864, 3947378022694873429L, 64256L, false, false, (char) 12414, (char) 42727,
        Double.longBitsToDouble(0x3fb47b65b697a8d8L), Double.longBitsToDouble(0x3fde35d9f7aab414L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 6, "\u6428\udb82\ude54", "\u1c6d\u3987\ua068\ua9f6\u7eaf\u8b30\ud20d\u3962\u55f6\u09cd\u0d36\u03de\u5db0", "\u24e0",
        6, 78893, -110567659, -5781075597489016226L, -33219L, true, false, (char) 29678, (char) 15234,
        Double.longBitsToDouble(0x3feeaad0557060fcL), Double.longBitsToDouble(0x3fe7a0eb8a41bb55L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 6, "\uda36\uddb6\ud8bc\ude91", "\u46ff\u3987\u9405\ua953\u7e6f\u8b30\ud20d\ua763\u8a94", "\ud8d8\udd12\ud836\udd1b",
        47, 51624, -1788187864, 3947378022694873429L, 64256L, false, false, (char) 12414, (char) 42727,
        Double.longBitsToDouble(0x3fa6f6cb6d2f51b0L), Double.longBitsToDouble(0x3fde35d9f7aab414L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 1, "\udb3b\uddf5\udb82\ude54\ud9a3\udd03\ud8bc\ude1d\udb36\udd6f\udae7\udd39", "\uc807\u9507", "\ub82e\ud820\udd37\ud81c\udc5a\udafe\udd43\udad8\udf99\ud85f\udf36\uda82\udc5d\udae9\udd25\u73b5\ud9e9\udec0",
        12, 40096, -1620397912, 2991792671000174634L, 72511L, true, false, (char) 20017, (char) 46057,
        Double.longBitsToDouble(0x3fb01bc3bd66cda8L), Double.longBitsToDouble(0x3fc915ddb7aa9438L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\ud93e\uddca\udb56\udfe6\udba2\udfe9\ud8bc\ude1d\uda2d\ude27\ud967\uddef\ud9e1\udded\udbc1\udd0c\ud87f\udec6\udbf7\udf14\ud913\ude9d\ud99e\udc61\uda68\udcf5\udbe3\udc62\uda30\udc99\ud8d8\udd12\ud836\udd1b\uda7a\udd6e\udbaf\udf02\uda96\udcf8\ud9b0\udea0\uda23\uddd9\uda31\udeb1\uda6a\udda5\ud9eb\udcb5\ud801\udd30\ud8cd\ude28", "\u089b\uc837\ubde2\ua619\u503e", "\udadb\udff6\ud964\udcdf\udb10\ude92\udbb8\udd6b\ud890\uded4",
        24, 41046, -1304504405, 7305171956517021964L, 37237L, false, true, (char) 46417, (char) 34225,
        Double.longBitsToDouble(0x3fd5aa989cd83cc6L), Double.longBitsToDouble(0x3fe0a81271aa6259L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\udbf2\udd93\ud86a\udc7d\udbcb\udf4c\udabe\udcb0\udb25\udc6f\udaee\udd34", "\u7eaf\u8b30\ud20d\uc5a5\u441b\u1d0b\u24f9\u03de\u5db0\u36f8\uab1d\uccd4\u47ba\u6a22\u5745", "\ud801\udd30\ud8a7\ude28",
        19, 81778, 1510661603, -30562211265408070L, -41067L, true, true, (char) 28362, (char) 54708,
        Double.longBitsToDouble(0x3fe061473b5ced76L), Double.longBitsToDouble(0x3fe56b057a029daeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\ud831\udfed\udb82\ude77\udbc6\udca7\ud8bc\ude1d\udb36\udd6f\udae7\udd39\ud9e1\ude79\udbc1\udd0c\ud87f\udec6\udbf7\udf14\ud913\ude9d\ud99e\udc61\uda68\udcf5\udbe3\udc62\uda30\udc99\ud8d8\udd12\ud836\udd1b\uda7a\udd6e\ud8cd\ude30\u24e0\ud9b0\udea0\uda23\uddd9\uda31\udeb1", "\u5e23\ud16b\u2368\u5dc8\u089b\u1080\u9d5c\u5d28\u4981\u4845\u9c50\u60f9\u80d8\ub75f\u3651\u70f5\u5b31\u2e17\u9f1b\u93de\u3fbe\u5f23\u4009\u314c\u7931\ud373\u44c7\u8a44", "\ud9ae\udc87\u7fb8\ud903\udeb2\ud9a4\udfaf\udabc\udd35\u2e24\ud8ad\udcfc\udafb\udd48",
        5, 14713, 631879646, -4843800471776788623L, 33033L, true, true, (char) 62958, (char) 41209,
        Double.longBitsToDouble(0x3fd0a38e5bc944aaL), Double.longBitsToDouble(0x3fccc69e568eb078L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\udb64\udc68", "\u86e0\u1c6d\u3987\ua068\ua9f6\u7eaf\u8b30\ud20d\u3962\u55f6\u09cd\u0d36\u03de\u5db0\uaaf7\u2827\uccd4\u3053\ubb4c\u5745\u8749", "\ud8cd\ude28\uda9d\udfac\ud9ab\udc56\ud996\udf31\uda24\udff9\uda70\udf87\ud83a\udd82\ud861\ude1f\udbf6\udc70\udb5c\udfc1\ud9db\udc6e\udb01\udca4\udbc4\uded3\udb36\udd47\udbbf\udced\uda6f\udf23\ud809\udee7\uda59\udf1b\uda0f\udc75\ud836\ude07\udbed\udcec\uda1c\udd71\ud825\udc9e\ud975\udf42\udb83\udc6c\uda32\ude06\uda59\udc7f\ud87d\udf55\udadb\udd6f\ud966\udd30\udb09\udde4\udb2c\udc57\udb00\udd34\ud917\uddc9\ud995\ude1c\ud89f\uddad\ud8e8\udee1\ud8d8\ude95\udb78\udfbd\ud945\ude50\udaca\udfab\udb86\udf9e\ud83a\udfee\udbda\udf2b\udb7d\udcc7\ud811\udf04\udabd\uddfb\ud844\udd91\udbd5\udd7b\uda3f\udd63\ud896\udcf4\u8db9\udb07\udde7\ud87c\udf61\udbfa\udebd\ud807\udfdd",
        30, 72492, -894514936, 4797554325572631270L, -29036L, true, false, (char) 6864, (char) 12940,
        Double.longBitsToDouble(0x3f85dc325e62d100L), Double.longBitsToDouble(0x3fdf9e5d11f6efc8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\u6428\udb82\ude54\udbcb\udf4c\ud8bc\ude1d\udb36\udd6f\udae7\udd39\ud9e1\ude79\udbc1\udd0c\ud87f\udec6\udbf7\udf14\ud921\udf24\ud9cb\udc73\uda68\udcf5\udbe3\udc62\uda30\udc99", "\uaaf7\u2827\uccd4\u3053\ubb4c\u5745\u8749", "\ud8cd\ude28\uda9d\udfac\ud9ab\udc56\ud996\udf31\udba8\udd9a\ud844\ude9d\ud82e\uddc2\ud9c0\udc47\uda79\udf47\ud8f9\ude62\ud924\udf7e\ud87a\ude12\udbbc\udc65\udad9\udfcc\ud8db\uddff\ud813\udec7\uda4f\udc32\udba4\ude6b\udb0e\udeab\ud94c\udda4\ud8a2\udf3c\udb58\udcb7\udb7d\udc70\ud8f5\udde6\ud928\udf52\ud84f\udfef\u5e4d\udb47\udd8d\ud95c\udf9f\udacc\ude02\ud814\uddd0\udb4d\udff7\udb27\uddb8\udb72\udf80\uc818\ud9bb\ude7d\ud8a4\udeb0\ud82b\ude06\udbb3\udc8a\uda4e\udce0\udaaa\uddf9\ud962\udd2b\ud8f5\udccf\ud9b9\udfcd\ud90b\udcec\ud88e\udfe5\ud809\ude72\ud81a\udcc4\uda86\uddf9\udb63\udf35\uda29\udce1\ud856\udc7f\ud9c9\udc6c\uda5b\udf1a\ud818\ude75\ud8b9\ude0f",
        40, 37144, -462376196, 2740523828462817737L, -92259L, true, true, (char) 31742, (char) 4160,
        Double.longBitsToDouble(0x3fc9b881c03dfe80L), Double.longBitsToDouble(0x3fd218c4b77719c4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 7, 6, "\ud926\udd4c\uda93\udddb", "\u2cc6\u39cf\ua068", "\udbf7\udf14\ud913\ude9d\ud99e\udc61\uda68\udcf5\udbe3\udc62\uda30\udc99\ud8d8\udd12",
        9, 73312, 1459300624, 6803368007558489958L, -26078L, true, false, (char) 29678, (char) 15234,
        Double.longBitsToDouble(0x3feeaad0511363a9L), Double.longBitsToDouble(0x3fc214cef9b3738cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.XYPlot:@?\0121=null |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000\udb82\udd90", "", "\udb9e\ude76",
        25, 39156, 776211547, -5410033671809529856L, -100000L, false, false, (char) 0, (char) 55606,
        Double.longBitsToDouble(0x3eaf000000000000L), Double.longBitsToDouble(0x3e4d9a55a8000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 0, "\ud891\udc23", "\u86e0", "\ud9e1\ude79\udbc1\udd0c\ud87f\udec6",
        2, 3544, 14944340, 34063432869216256L, -100000L, false, true, (char) 49699, (char) 31952,
        Double.longBitsToDouble(0x3fd5536c7e2b89d2L), Double.longBitsToDouble(0x3fe307cb425eafc5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 6, "\udbf6\udf54\udb77\ude40", "\u09ba\u7107\ua068\ua993\ub4e8", "\ud9d2\ude83\uda68\udcf5\udbe3\udc62\ud953\udd3c\ud9c6\ude44\udbc1\udecf\ud938\ude50\ud8cd\ude30",
        1, 693, -995792555, -206249598098923462L, 59614L, false, true, (char) 34279, (char) 14332,
        Double.longBitsToDouble(0x3fde35d9843ab414L), Double.longBitsToDouble(0x3fe9ddf5586aae0bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 13, 12, 4, "\u6428\udb82\ude54", "\u1c6d\u3987\ua068\u6d69\u34a7\u4eae\ud20d\u3962\u55f6", "\ud8d8\udd12\ud836\udd1b",
        47, 51624, -1788187864, 3947378022694873429L, 46592L, false, false, (char) 12414, (char) 42727,
        Double.longBitsToDouble(0x3fb749a5b697a8d8L), Double.longBitsToDouble(0x3fde35d9f7aab414L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 1, 0, "\uda19\ude35\udb82\ude54\udbcb\udf4c\ud8bc\ude1d\udb36\udd6f\udae7\udd39\ud9e1\ude79\udbc1\udd0c\ud87f\udec6\udbf7\udf14\ud913\ude9d\ud99e\udc61\uda68\udcf5\udbe3\udc62\uda30\udc99\ud8d8\udd12", "\u2827\uccd4\u3053\ubb4c\u5745\u8749\ua092\u5dbc\ud16b\u2368\u5dc8\u089b\u6f6b\u7cc2\u0a09\u30b4", "\udbdd\udf88\ud872\udf43\udb7f\udcdc\udb8b\udcc2\uda32\udff7\ud8db\udee7",
        52, 79081, 2095369347, -6023329265812939024L, -44524L, true, true, (char) 56393, (char) 49905,
        Double.longBitsToDouble(0x3f70f374428c7000L), Double.longBitsToDouble(0x3fcdd0d7b0927d0cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 1, 0, 7, 6, "\u64c4\uda34\udf23\ud8ad\ude3d\ud925\ude07", "\u3a6e\u3af6\u75b1\u254a\ud20d\u3962\u8bbd\u15c5\u99b5\u03de\u5fa9", "\u24e0",
        57, 57901, -110567659, -5781075597489016226L, 62754L, true, false, (char) 62350, (char) 44629,
        Double.longBitsToDouble(0x3fe9fb738e177a54L), Double.longBitsToDouble(0x3fd12087fb1fa63eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 6, "\u6428\udb4a\ude58\udbc2\udd06\ud883\ude37\ud853\udcdb\udae7\udd39\ud9e1\ude79\uda2e\udf44\uda08\ude87\ud83a\ude51\udaff\ude96\ud99e\udc61", "\u0d36\u03de\u9124\u5634\u2827\uccd4\u3053\ubb4c\u5745\u8749\ua092\u5dbc\u0208\u263e\u8929\u583e\u7985\u6c3d\u7583\uc43d", "\udae9\udf88\ud9da\ude4e\uda8e\udc37\udafc\udf41",
        8, 9882, 361127749, 1102037853085737114L, 5164L, true, true, (char) 21802, (char) 45535,
        Double.longBitsToDouble(0x3fc61e4da33e8a00L), Double.longBitsToDouble(0x3fb2c6f22a2dbe18L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 6, "\udbb3\udd57\udb82\ude57", "\u5435\u9f02\uc808\uab44\u24b1\u93ac\u1013\u399e\u55f6", "\ud906\uddf3\udbb2\udeb6",
        18, 4243, -1788187864, 3947378022694873429L, 64256L, false, false, (char) 12203, (char) 57547,
        Double.longBitsToDouble(0x3fe1e74366d2f51bL), Double.longBitsToDouble(0x3fde35d9f7aab414L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 7, 6, "\u6428\ud8df\udce2\ud85f\udeb3\ud8bc\ude1d\udb31\udc6f\udae7\udd39", "\u7eaf\u2213\u2d11\u9e10\ube32\u09cd\u0d36\u18e7\u0bc9\u13dc\u06eb\uccd4\u3053\ubb4c\u5745", "\ud801\udd30\ud8cd\ude28\uda9d\udfac\ud9ab\udc56\ud81e\udf70\ud852\udffe\udb69\uddee\uda78\udf25\udbac\udc2a\udb76\udeab\ud8be\udd66\udac4\udd76\ua0ad\uda80\udcfb\udad0\ude1e\ud916\udcb2\udb31\udea6\ud9c2\udfe1\ud9ad\udfd8\ud85f\udc73\ud996\ude51\ud9bd\udead\uda7d\udf68\ud993\ude33\ud9f0\udf91\ud80c\udef7\uda77\ude13\ud9e8\udcdb",
        33, 29864, 849936355, 7562788349413005829L, 17665L, false, true, (char) 60972, (char) 39740,
        Double.longBitsToDouble(0x3fe7da4890734b47L), Double.longBitsToDouble(0x3fca7bebea5fef1cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 14, "\ud853\udf87\udb82\ude54\udbcb\udf4c\ud8bc\ude1d\udb36\udd6f", "\ua9f6\u7eaf\u8b30\ud20d\u7470\u4772\u8085\u4353\u3bf1\u3d6f\u5ba1\u165f\uccd4\ud42c\ubb4c\u5745\ua474\ud0d3\u03d3\ud16b\u2410\ud3f3\u5874\u27f0\u3efb\u0ce6\u864d\u3bb7\u5aa4\u4ede\u2c97\u3a3b\u0162\u5d9a\u7833\u5d4f\ub9c2\uaf0b\u43da\ubd2c\u141e\u4d4e\u570c\u57c6\u0c06\ub805", "\ud9f1\udede",
        8, 30822, 255557759, -1223535726342396954L, 62371L, true, false, (char) 45630, (char) 60232,
        Double.longBitsToDouble(0x3fe022e6bd227654L), Double.longBitsToDouble(0x3fe0b13884788eedL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 7, 6, "\u6428\ud9e0\udd63", "\u7ad6\u3987\ua068\u887b\u3701\u62e2\ud20d\uc362\u544b", "\ud8d8\udd12\ud836\udd1b\udb71\udd28",
        42, 83603, 919070566, -8249634278730097548L, -38350L, true, false, (char) 29678, (char) 15234,
        Double.longBitsToDouble(0x3fd0c5a0a35a4c54L), Double.longBitsToDouble(0x3fb6ce47ed6a9878L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 6, 6, "\ud8a2\uded2\udb82\ude6a", "\u9990\u397a\u7efa\ua9f6\u7eaf\u8b30\u6a1b\u7794\u55f6", "\udbf5\udfa2\ud934\udd93\uda89\udc96\ud8cd\ude30\u24e0\ud9b0\udea0\uda23\uddd9\uda31\udeb1\ud8cf\udcf6\ud9bf\ude6f\ud801\udd30\ud8cf\ude29\uda9d\udfac\ud9ab\udc56\ud996\udf31",
        -2, 55660, 1090903436, 1725533899597119797L, 24772L, false, true, (char) 49236, (char) 10663,
        Double.longBitsToDouble(0x3fd200a25ee6b45aL), Double.longBitsToDouble(0x3fe5c16924ef0fd2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 6, "\u6428\udb82\ude54", "\u0d54\u389d\ua068\ub82e\u832f\u6e8b\ud257\u7add\u6dd4\u77c1\u1364", "\uda7a\udd55\ud8cd\ude30\u24e0\udbd7\udd08\uda23\ude6e\uda31\udeb1\udb5b\udfad",
        21, 69266, -308879554, -784866234815512878L, 17423L, false, false, (char) 25512, (char) 10344,
        Double.longBitsToDouble(0x3fcc3b31a2b2477cL), Double.longBitsToDouble(0x3fe92c47539658dbL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 6, "\ua0c1\udb82\ude54", "\u1c6d\u3987\uc43c\u8bd2\u7ec0\u0f56\u3480\u3962\u55f6", "\ud8c7\ude12\ud836\udd1b",
        47, 51624, -1788187864, 3947378023141763413L, 64256L, false, false, (char) 12414, (char) 42727,
        Double.longBitsToDouble(0x3fef9f6cb1c501cbL), Double.longBitsToDouble(0x3fde35d9f7aab414L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 2, "\udb16\udcb2", "\u86e0\u3e07\u3987\u6be1\ua9f2\u7eaf\uc0fd\ua4fd\u3962\u55f6\ub9eb\u0d36\u03de\u5db0\uaaf7\u2827\ucd12\u3053\ubb4c\u5745\u8f68", "\ud8cd\ude28\uda9d\udfac\uda43\udc43",
        29, 23429, -209936050, -7435269584328906007L, -52903L, true, true, (char) 29389, (char) 7460,
        Double.longBitsToDouble(0x3feb7c9569a9632eL), Double.longBitsToDouble(0x3fe68bee0f391563L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jfree.chart.plot.XYPlot:@?\0121=java.lang.Boolean:true |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 15, 15, 6, "\udb81\udd09", "\ua2c4\u22e0\ud4f6\u2615\u5341\u979d\u4253\ud350\u0660\uac8b\u09cd\u0d03\u03de\u5db0\uab62\u2827\uccd4\ub8bb\u97ef\u39fe\u93bc", "\ud8cd\ude28\uda9d\udfac\ud9ab\udc56\ud996\udf31\ud86b\udfbd\uda4b\udce6\udb3f\ude64\ud8bc\ude4f\ud8bc\udeb6\ud8cd\udf71",
        20, 37744, 817675052, 4048023349618413454L, 80537L, false, true, (char) 49652, (char) 64541,
        Double.longBitsToDouble(0x3fe7d43c15ac7576L), Double.longBitsToDouble(0x3fe9b69714c46bccL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 6, "\u6428\udb82\ude54", "\u1c6d\u3987\ua068\ua9f6\u7eaf\u8b30\ud20d\u3962\u55f6", "\ud8d8\udd12\ud836\udd1b",
        47, 28705, -234014554, 3947377846601214293L, 59739L, false, true, (char) 34279, (char) 29678,
        Double.longBitsToDouble(0x3fd4b5d9f7aab414L), Double.longBitsToDouble(0x3fea2104bfc4a72dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 0, "\000", "", "",
        -5, 51512, 905969664, -2052963632702029824L, -100000L, false, false, (char) 19321, (char) 0,
        Double.longBitsToDouble(0x3fe6a93ce43725ffL), Double.longBitsToDouble(0x3f4967c400000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\u6428", "\u86e0\u1c6d\u3987\ua068\ua9f6\u7eaf\u8b30\ud231\u3962\u55f6\u09cd\u0737\u03de\u5db0\uaaf7\u2827\uccd4\u3053\ubb4c\u5745\ua558", "\ud8cd\ude28",
        19, 81778, 1510661603, -9177936001071407694L, -50277L, true, true, (char) 2648, (char) 30043,
        Double.longBitsToDouble(0x3fc1524e930e513cL), Double.longBitsToDouble(0x3fed49d53895e45bL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 0, "", "\u87f3\u0940\u06d1\u3987\ua068\ua9f6\u7eaf\u8b30\ud20d", "\ud820\udc61\uda30\udc99\ud89e\ude2e",
        9, -1000, 0, -7680208394970994842L, -100000L, true, false, (char) 29678, (char) 159,
        Double.longBitsToDouble(0x3feea800049f7083L), Double.longBitsToDouble(0x3faf01828d469a80L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 13, 13, 12, "\uda36\uddb6\ud8bc\ude91\udb9e\udda4\ud8bc\ude1d\uda58\udebe\ud892\udd8e\ud916\udf7e\ud9d4\udd6e\ud87f\ude86\ud95c\ude66\ud913\ude9d\uda25\udcb3\udb38\udd78\udbe3\udc62\uda30\udc99\ud8d8\udd12\ud836\udd1b\uda68\udf6e\ud8cd\ude30\u24e0\ud9b0\udea0\uda23\uddd9", "\ua092\u5dbc\ud16b\u2344\u5dc8", "\udaa3\udd79\ud93a\udd98\ud993\udf09\udb9a\udead\ud83a\ude27\ud833\udfe7\ud8c0\udeee",
        16, 30829, -382463652, -4053788737594091699L, 65724L, true, false, (char) 743, (char) 57661,
        Double.longBitsToDouble(0x3fc9bbfafbf3e760L), Double.longBitsToDouble(0x3fd5803bebced586L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 6, "\uda36\uddb6\ud8bc\ude91", "\u46ff\u3987\uac0c\u0ce2\u7ebd\u8b30\u3728\u37fb\uc69b", "\ud8d8\udce2\uda1f\udeb0",
        29, 87976, -1788187864, 3947378022694873429L, 64256L, false, false, (char) 12414, (char) 42727,
        Double.longBitsToDouble(0x3fa6f6cb3ca751b0L), Double.longBitsToDouble(0x3fdd01b3c55afe14L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 1, "\udb3b\uddf5\udb82\ude54\ud9a3\udd03\ud8bc\ude1d\udb36\udd6f\udae7\udd39", "\uc807\u9682", "\ub82e\ud820\udd37\udb57\udd2b\udafe\udd43\udad8\udf99\ud85f\udf36\uda82\udc5d\udae9\udd25\u73b5\ud9e9\udec0",
        12, 40096, -1620397912, 2991792671000174634L, 72511L, true, false, (char) 20017, (char) 46057,
        Double.longBitsToDouble(0x3fb01bc38566cda8L), Double.longBitsToDouble(0x3e47aa9400000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 5, 1, "\udb3b\uddf5\udb82\ude54\ud9a3\udd03\ud8bc\ude1d\udb36\udd6f\udae7\udd39", "\uc804\u9507", "\ub82e\ud820\udd37\ud8ff\udf4c\udafe\udd43\udad8\udf99\ud85f\udf36\uda82\udc5d\udae9\udd25\ud858\udc88\uda06\udf60",
        40, 56188, -1620397922, 2991792671000174634L, -75817L, true, true, (char) 55016, (char) 936,
        Double.longBitsToDouble(0x3fe35d3e31cb521eL), Double.longBitsToDouble(0x3fb01bc3bd66cda8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 1, "\udaeb\udfb8\udb3b\udddc\ud9a3\udd03", "\u9c4f\u4d1d\u5fad\u659c\u9ca6", "\ud8ee\udc2d\ud865\udddb\ud910\udcd4\ud82d\udd21\udab6\ude3b\u2343\ud996\udc55\udae9\udd25\udbf0\udd7d\ud825\udcb8\uda80\udee9\ud988\ude6d\uda6a\udeab\udba1\uddf9\udaa4\udd8d\ud858\ude0f\ud9ab\udc56\udae5\udd34\ud9ce\udf79\uda73\udc17\udb8d\udf55",
        15, 42680, -1360165077, 3343599857165479402L, 35374L, true, true, (char) 21781, (char) 41615,
        Double.longBitsToDouble(0x3fef4d6c143b5806L), Double.longBitsToDouble(0x3fe70bf2154c120eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\udb64\udc68", "\u86e0\u1c6d\u3987\ua068\ua9f6\u7eaf\u8b30\ud20d\u3962\u55f6\u09cd\u0d36\u03de\u5db0\u096d\u3fd6\u9bf1\u30e0\uc773\u5745\u8749", "\ud8cd\ude28\uda9d\udfac\ud9ab\udc56\ud996\udf31\uda24\udff9\uda70\udf87\ud83a\udd82\ud861\ude1f\udbf6\udc70\udb5c\udfc1\ud9db\udc6e\udb01\udca4\udbc4\uded3\udb36\udd47\udbbf\udced\uda6f\udf23\ud809\udee7\uda59\udf1b\uda0f\udc75\ud836\ude07\udbed\udcec\uda1c\udd71\ud825\udc9e\ud975\udf42\u2d31\ud866\ude34\ud8a3\udc72\ud93c\udeae\udadb\udd6f\ud966\udd30\udb09\udde4\udb2c\udc57\udb00\udd34\ud917\uddc9\ud995\ude1c\ud89f\uddad\ud8e8\udee1\ud8d8\ude95\udb78\udfbd\ud945\ude50\udaca\udfab\udb86\udf9e\ud83a\udfee\udbda\udf2b\udb7d\udcc7\ud811\udf04\udabd\uddfb\ud844\udd91\udbd5\udd7b\uda3f\udd63\ud896\udcf4\u8db9\udb07\udde7\ud87c\udf61\udbfa\udebd\ud807\udfdd",
        30, 71396, -894514936, 4797554325572631270L, -39253L, false, true, (char) 22927, (char) 42000,
        Double.longBitsToDouble(0x3fe728679f2110feL), Double.longBitsToDouble(0x3fc9b8babc55a840L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 12, 12, 4, "\ud804\udcc3", "\u86e0\u1c6d\u18b3\ua068\u6d69\u34a7\u8d24\ud20d\u3962\u55f6\u09cd\u0d36\ud3b0\u5db0\uaaf7\u2827\ua260\u3008\ubb4c\u5745\ucc49", "\uda5c\udd86\ud9c5\udc7b\udab9\udd4c\ud989\udd44\udb6f\udd05\ud884\udda3\udac2\udc42\uda08\udc09\ud90e\udc8e\ud938\udf86\ud9ee\uddc2\ud9ec\udc8b\uda08\udcb8\ucd68\uda5a\udd16\ud8d0\udd0f\ud8e5\ude00\uda44\udfe1\ud9a1\ude2d\uda28\uddd0\u04eb\ud999\udc2a\udab8\udf72\uda70\udecd\ud815\udf43\udb53\udddc\ud8a4\udd8e\udb58\udfcc\ud99d\udd3a\ud924\udd38\ud8c3\udfca\udb60\udf86\udac7\udd5d\ud84b\udc04\uda23\ude61\uda50\udc44\ud95b\udde9\udba4\udc27\ud934\udd2f\udbff\udc8e\ud919\udfee\udb28\udd3c\ud997\udfab\ud8aa\udf04\udb99\ude1d\ud8a3\udeeb\udbfa\udf64\ud861\udea3\ud851\udfb2\udaa2\uddf1\udbd7\udd82\uda79\udc4b\ud938\udcf6\ud926\udc8f\ud806\udc0c\ud9fb\udcd2",
        28, 20233, -837409412, -407156926419326592L, 85871L, true, false, (char) 28837, (char) 40812,
        Double.longBitsToDouble(0x3fd49c7e883943baL), Double.longBitsToDouble(0x3fe44046db97f232L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 6, "\u6428\udb82\ude54", "\u1c6d\u3987\ua068\ua9f6\u7eaf\u8b30\ud20d\u3962\u55f6", "\ud8d8\udd12\ud836\udd1b",
        47, 67752, -1791857880, 3947378022694873429L, 64256L, false, false, (char) 12414, (char) 49152,
        Double.longBitsToDouble(0x3fea8f6cb6d2f530L), Double.longBitsToDouble(0x3fde35d9f7aab414L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 1, 0, "\uda3b\udc29\udb82\ude54\udbcb\udf4c\udbb6\udd3a\udb3d\ude77\ucba9\ud8e5\udedd\udbb7\udc91\ud87f\udec6\udbf7\udf14\ud981\udf44\udae2\udf3a\uda68\udcf5\udbe3\udc62\ud81b\udf94\ud8d8\udd12", "\u2827\uccd4\u5ef0\ubb4c\u5745\u8749\ua092\u5dbc\ud16b\u2368\u6a41\u0852\u6f6b\u7cc2\u0a09\u30b4\u4481\uac39\u8537\u1155\u550b\uc71e\u6278\u2e40\uc046\u1ea8\u5089\u7adf\u4dc2\u0fad\ua493\ubddf\u4bac\u9c1c\u7998\u34e6\u9ad6\u3a55\uae60\u1f8d\ubdb9\uacb7\u4028\ua207\u6134\uc92f\uaefd\ud50d\u12ed\ub4f0\uc4e5\u8427\u2d7f\u2a26\ub0fd\u339e\u4e06\u71a8\u7dcb\u896f\u2944\u7386\uc1d6\u3b2f\ub3d3\u3fd5\u3ea8\ubb38\u71d2\u1798\u6b54\u60c6\u0da5\u36aa\ud087\u1b53\u173a\u7dd5\u87e1\u93f0\ubf35\u71d6\ua1d1\ucb11\u7fd5\ub6e6\u544a\u01d4\u2ba2\u1cc7\u4655\u309c\u5219\u6b1a\u9e83\ubb05\u0380\u7d91\u1b39\u3010\ub1f0\u9e1f\u1bd7\ua8bf\u9386\ua088\u8cfe\ubaab\u37f9\u869a\u6676\u9c7a\u3d5d\u90b3\u9f7e\u2755\ua41c\u4601\u0186\ub4e1\uc6b0", "\udb28\udf09\ud9d4\udf61\udbc3\ude33\uda17\udc5f\uda56\udd22\udab5\udfe3\udb2e\ude52\ud868\udc1f\uda89\udfd0\udb53\ude0f",
        6, 84788, -726615987, -7632602887777954131L, 12337L, false, true, (char) 29075, (char) 56269,
        Double.longBitsToDouble(0x3fe5ba5cb96479a4L), Double.longBitsToDouble(0x3fcf51c124966fa8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 9, "\udbf6\udf54\udb1b\ude52\ud977\udc21\ud8bc\uddb3\ud9fb\udcf1\udb8e\udeb1\ud88b\udd81\udbc1\udca6\udb86\ude9b\ud8b5\udfbf\ud835\udf5e\ud9c3\ude99\uda68\udcf5\udbe3\udc62\uda01\udd33\ud9c6\ude44\udbc1\udecf\ud938\ude50\ud867\udd9e\uda15\udca0\ud963\udd7e\ud81a\ude04\ud833\ude42\ud845\udfd5\ud9dd\udde9\ud832\udc6c\ud8bc\udd3b\ud9d8\ude9a\ud832\uded0\ud996\udf31\ud9f3\udd28\udb62\udf7a\uda95\uddc3\ud82a\udf3b\ud8fc\udf09\udb94\ude8b\ud967\udcac\ud959\uddf4\uda7e\udee9\uda06\udce3\uda5e\udf0c\ud9d7\ude88\u31e1\udbc1\udc37\uda06\udd91\udb28\udd62\ud8f5\udd22\uda42\udc8f\udaab\ude20\udaac\udd46\ud92c\udfa1\udac7\udcd5\uda72\udf40\udad7\udf3b\udbf4\udd42\ud975\udd9f\ud923\udf13\uda1e\udd22\ud8de\udd12\uda42\udfca\ud9d6\ude72\ud9ae\ude45\ud95a\ude13\udbb0\udfac\ud982\ude72\ud97d\ude43\udaa0\udda0\ud9c5\udf2f\ud9ca\ude3a\uda3a\udf0b\ud84a\ude2d\udab0\ude7f\ufb61\ufdab\ud9f7\udea2\ud9e5\ude06\udbe8\udc4f\udaad\udc97\uda3b\uddfa\ud854\udfcc\u8c46\udbcb\udc8c\uda57\udd92\ud952\udccc\uda65\udfa7\udb65\udf4c\uda19\udca9\udaff\udfbd\udb5a\udee6\uda2b\ude7b\udaa3\udf63\ud8f0\udf85\ud95c\ude4e\ud863\udc3e\ud8f7\ude60\ud97f\udf48\ud86f\udd3b\udaf9\udff6\ud8b8\udd41\udb50\udcf9\udb93\uddde\udaae\udf6b\udb64\udf1d\udab1\udfa7\uda65\udf6a\udbd5\udcc9\udbde\udf96\uda77\udca3\udb84\uddbc\udae9\udd32\udbcb\udc20\ud9f7\udfec\ud8bb\udf20\udb61\udc54\udac3\udead\ud931\ude84\udb46\udd5e\uda79\udccd\ud826\udf11\ud8b9\ude27\ud82c\udd5c", "I\u67fb\u35c9\u8a36\u130e\ud226\u8e09", "\ud852\udc5d\ud85e\udc89\ud9e0\udf64\ud8a5\udfda\u6b40\ud8a7\udf32\udb41\udc1d\udbad\udf45",
        25, 87240, -113201230, -3973671528608501771L, -14561L, false, true, (char) 32929, (char) 23848,
        Double.longBitsToDouble(0x3fb6a681c7e5ce60L), Double.longBitsToDouble(0x3fd566564d350934L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 9, "\udbf6\udf54\udb1b\ude52\ud977\udc21\ud8bc\uddb3\ud9fb\udcf1\udb8e\udeb1\ud88b\udd81\udbc1\udca6\udb86\ude9b\ud8b5\udfbf\ud835\udf5e\ud9c3\ude99\uda68\udcf5\udbe3\udc62\uda01\udd33\ud9c6\ude44\udbc1\udecf\ud938\ude50\ud867\udd9e\uda15\udca0\ud963\udd7e\ud81a\ude04\ud833\ude42\ud845\udfd5\ud9dd\udde9\ud832\udc6c\ud8bc\udd3b\ud9d8\ude9a\ud832\uded0\ud996\udf31\ud9f3\udd28\udb62\udf7a\uda95\uddc3\ud82a\udf3b\ud8fc\udf09\udb94\ude8b\ud967\udcac\ud959\uddf4\uda7e\udee9\uda06\udce3\uda5e\udf0c\ud9d7\ude88\u31e1\udbc1\udc37\uda06\udd91\udb28\udd62\ud8f5\udd22\uda42\udc8f\udaab\ude20\udaac\udd46\ud92c\udfa1\udac7\udcd5\uda72\udf40\udad7\udf3b\udbf4\udd42\ud975\udd9f\ud923\udf13\uda1e\udd22\ud8de\udd12\uda42\udfca\ud9d6\ude72\ud9ae\ude45\ud95a\ude13\udbb0\udfac\ud982\ude72\ud97d\ude43\udaa0\udda0\ud9c5\udf2f\ud9ca\ude3a\uda3a\udf0b\ud84a\ude2d\udab0\ude7f\ufb61\ufdab\ud9f7\udea2\ud9e5\ude06\udbe8\udc4f\udaad\udc97\uda3b\uddfa\ud854\udfcc\udba4\ude26\udb88\udd4c\ud936\udee1\udada\udc45\uda65\udfb8\udb65\udf4c\uda19\udca9\udaff\udfbd\udb5a\udee6\uda2b\ude7b\udaa3\udf63\ud8f0\udf85\ud95c\ude4e\ud863\udc3e\ud8f7\ude60\ud97f\udf48\ud86f\udd3b\udaf9\udff6\ud8b8\udd41\udb50\udcf9\udb93\uddde\udaae\udf6b\udb64\udf1d\udab1\udfa7\uda65\udf6a\udbd5\udcc9\udbde\udf96\uda77\udca3\udb84\uddbc\udae9\udd32\udbcb\udc20\ud9f7\udfec\ud8bb\udf20\udb61\udc54\udac3\udead\ud931\ude84\udb46\udd5e\uda79\udccd\ud826\udf11\ud8b9\ude27\ud82c\udd5c", "I\u67fb\u35c9\u8a36\u130e\ud226\u8e09", "\ud852\udc5d\ud85e\udc89\ud9e0\udf64\ud8a5\udfda\u6b40\ud8a7\udf32\udb41\udc1d\udbad\udf45",
        25, 87240, -113201230, -3973671528608501771L, -14561L, false, true, (char) 32929, (char) 23848,
        Double.longBitsToDouble(0x3fb6a681c7e5ce60L), Double.longBitsToDouble(0x3fd566564d350934L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.AxisSpace:@? |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 9, "\udbf6\udf54\udb1b\ude52\ud977\udc21\ud8bc\uddb3\ud9fb\udcf1\udb8e\udeb1\ud88b\udd81\udbc1\udca6\udb86\ude9b\ud8b5\udfbf\ud835\udf5e\ud9c3\ude99\uda68\udcf5\udbe3\udc62\uda01\udd33\ud9c6\ude44\udbc1\udecf\ud938\ude50\ud867\udd9e\uda15\udca0\ud963\udd7e\ud81a\ude04\ud833\ude42\ud845\udfd5\ud9dd\udde9\ud832\udc6c\ud8bc\udd3b\ud9d8\ude9a\uda6d\udce3\ud996\udf31\ud9f3\udd28\udb62\udf7a\uda95\uddc3\ud82a\udf3b\ud8fc\udf09\udb94\ude8b\ud967\udcac\ud959\uddf4\uda7e\udee9\uda06\udce3\uda5e\udf0c\ud9d7\ude88\u31e1\udbc1\udc37\uda06\udd91\udb28\udd62\ud8f5\udd22\uda42\udc8f\udaab\ude20\udaac\udd46\ud92c\udfa1\udac7\udcd5\uda72\udf40\udad7\udf3b\udbf4\udd42\ud975\udd9f\ud923\udf13\uda1e\udd22\ud8de\udd12\uda42\udfca\ud83a\ude05\uda75\udd15\ud93c\udd79\udbb0\udfac\ud982\ude72\ud97d\ude43\udaa0\udda0\ud9c5\udf2f\ud9ca\ude3a\uda3a\udf0b\ud84a\ude2d\udab0\ude7f\ufb61\ufdab\ud9f7\udea2\ud9e5\ude06\udbe8\udc4f\udaad\udc97\uda3b\uddfa\ud86f\udd58\udbd5\udf33\ud9dd\udd18\uda57\udd92\ud952\udccc\uda65\udfa7\udb60\udeeb\uda19\udca9\udaff\udfbd\udb5a\udee6\uda2b\ude7b\udaa3\udf63\ud8f0\udf85\ud95c\ude4e\ud863\udc3e\ud8f7\ude60\ud97f\udf48\ud86f\udd3b\udaf9\udff6\ud8b8\udd41\udb50\udcf9\udb93\uddde\udaae\udf6b\udb64\udf1d\udab1\udfa7\uda65\udf6a\udbd5\udcc9\udbde\udf96\uda77\udca3\udb84\uddbc\udae9\udd32\udbcb\udc20\ud9f7\udfec\ud8bb\udf20\udb61\udc54\udac3\udead\ud931\ude84\udb46\udd5e\uda79\udccd\ud826\udf11\ud8b9\ude27\ud82c\udd5c", "\u7dce\u6805\u86ac\u0344\u58d2\ud232\u8e09", "\ud852\udc5d\ud85e\udc89\ud9e0\udf64\ud8c8\udc34\ud94a\udf88\ud88c\udccf\udb41\udc1d\udbad\udf45",
        25, 87240, -113201230, -3973671528608501771L, -14561L, false, true, (char) 32929, (char) 23848,
        Double.longBitsToDouble(0x3fb6a681c7e5ce60L), Double.longBitsToDouble(0x3fd566564b28bf34L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.plot.XYPlot|getDataRange|org.jfree.chart.axis.ValueAxis|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addAnnotation|org.jfree.chart.annotations.XYAnnotation|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addAnnotation|org.jfree.chart.annotations.XYAnnotation,boolean|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addDomainMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addDomainMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addRangeMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|addRangeMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|calculateAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|calculateDomainAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.AxisSpace|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|calculateRangeAxisSpace|java.awt.Graphics2D,java.awt.geom.Rectangle2D,org.jfree.chart.axis.AxisSpace|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|canSelectByPoint||new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|canSelectByRegion||new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|getDataRange|org.jfree.chart.axis.ValueAxis|new:org.jfree.chart.plot.XYPlot:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
