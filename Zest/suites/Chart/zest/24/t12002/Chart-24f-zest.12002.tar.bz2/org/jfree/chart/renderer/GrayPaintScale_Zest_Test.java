package org.jfree.chart.renderer;
import org.junit.Test;
import static org.junit.Assert.*;
public class GrayPaintScale_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u0f26\u3aa2\u0b60\u1a56\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u5d8f\u18f6\u84c1\uafe3\u7b60\u5d8a\u0a9d\u8677\u462e\u6527\u18c5\u0347\u049b\u4c5c\u4bf5\u8480\u8df1\u04de\u30aa\ub370\u5b01\uce6e\u1858\ud6fe\u0e67\u06c7\ua8e8\u1954", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c7\udc27\ud8e5\udc3d\uda8e\ude7e\uda40\udf8b\ud8ad\udc78\ud842\ude85\ud97c\udcd2\udb6f\udf11\uda0d\udf3c\u280e\ud8fe\udf18\udbe1\uddb7\udaab\ude4b\ud9c1\udf38\udaa8\udcc6\udb26\uddce\ud9dd\udda2",
        -3, 67959, -1536680919, -1554166128502010935L, 12458L, false, false, (char) 30374, (char) 31046,
        Double.longBitsToDouble(0x3fb024180403d8c0L), Double.longBitsToDouble(0x3fea23da5cfcbb3aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\u3bfb\udad1\ude11\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e\ud968\udf46\ud837\udff8\udb1d\ude85", "\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535", "\uc45c",
        37, 60718, 16368386, 770010120273337581L, 67640L, false, false, (char) 32089, (char) 31166,
        Double.longBitsToDouble(0x3fd672943605c0b2L), Double.longBitsToDouble(0x3fe0432c7b866b95L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 3, "\ud8f1\udffa\udb14\udf17\ud94b\udd64\uda04\ude76\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda5e\udca2\udb43\udffe\ud8e4\udcc5\ua6ea\uda66\udcc3\ud951\udc52\uda6d\udc9b\ud8e1\uddbc\udb91\udd4f", "\ua1e7\uc1d7\u4eab\uc456\u5027\u39b8\u4256\u17d9\u50d6\u94fa\u0f26\u2ba2\u0b60\u1a56\u4c3e\u6e9a\u7b39\u4da2", "\ud99e\udc5f\ud8e2\uddd1\ud9d8\udf39\ud9e2\udf89\udab2\ude79\u824d\ud981\udddd\ud8e5\udedb\uda46\udc96\uda03\udded\udae9\uddab",
        24, 5459, -1088296642, -3056312642371730490L, -68125L, true, true, (char) 48315, (char) 64283,
        Double.longBitsToDouble(0x3fef8ed79bd35b86L), Double.longBitsToDouble(0x3feea57013e11a4cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 3, "\udb4d\udf52\ud82b\udce8\udbd0\udfdf\udb35\ude75\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb", "\u1d63\u4aa0\u24c9\u42da\u987f\u5538\u9ccc\u9d76", "\ud986\udf6c\ud88f\uddf3",
        3, 10421, -1551671308, -3318662067408026396L, 32715L, false, false, (char) 8302, (char) 48078,
        Double.longBitsToDouble(0x3fed097ccb02188eL), Double.longBitsToDouble(0x3fa0007cced0aaf0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\udbc8\udd64\ud94a\udd4f\ud88f\udfa3\u976b\udb7c\udd01\uda6a\udf01\udbc2\udf48\uda23\udf8a\udabf\udf06\udb64\udeb4", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u0f26\u3aa2\u0b60\u1a56\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u90a7\u18f6\u84c1\uafe3\u7b60\u5d8a\u0a9d\u8677\u462e\u6527\u18c5\u0347\u049b\u4c5c", "\ud928\udd1c\ud87f\udf20\ud929\udf98\ud8f8\ude2d",
        27, 15232, -1375567593, 1894933334511922145L, 63036L, false, true, (char) 56551, (char) 62038,
        Double.longBitsToDouble(0x3fee7ecd368ead61L), Double.longBitsToDouble(0x3fd6e57f34ea5c6eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 4, 6, 3, "\udb27\uded6\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud9cc\udfb2", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u3a2a\u4256\u17d9\u50d6\u15a2\u0f26\u3aa2\u0b60\u1a56\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\ubd4b\u18f6\u14b6\uafe3\u7b60\u5d8a\u0a9d\u8677\u7688\u0e65\u0cd5\u606a\u049b\ub465\u4bf5\u8480\u8df1\u04de\u30aa\ub370\u02d2\uce6e\u1858\ud6fe\u0e67\u06c7\ua8e8\u1954", "\udb70\udc2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c7\udc27\ud8e5\udc3d\uda54\ude81\uda40\udf8b\ud8ad\udc78\udb22\udc16\uda3a\udefa\udb6f\udf11\ud837\udef1\u280e\udbf8\ude35\uda0f\udc95\udaab\ude4b\ud9c1\udf38\udaa8\udcc6\udb26\uddce\ud9dd\udda2",
        -3, 67959, -1536680919, -1554051777967322167L, 12458L, false, false, (char) 30374, (char) 31046,
        Double.longBitsToDouble(0x3fb02418314da7b0L), Double.longBitsToDouble(0x3fea275efcfcbb3aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30", "\ud832\udc63\udab0\ude80",
        35, 8204, 38412927, -2873852455191699742L, 93840L, false, true, (char) 56131, (char) 41240,
        Double.longBitsToDouble(0x3fcda155e54fb164L), Double.longBitsToDouble(0x3fd289aa695c9e3aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc5\udd48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8", "\udaec\udd81\uda0e\udea1\ud90f\udc11\ud8cc\udc43\uda4e\udf98\uda81\ude4d\udbe8\udd41\udace\udf10\ud8ac\udcc1\ud9f6\udfc4",
        29, 87576, -440511314, 4459856223671630810L, -55714L, false, false, (char) 44827, (char) 54617,
        Double.longBitsToDouble(0x3fd2214f6cdfed84L), Double.longBitsToDouble(0x3fe0ebf9592fb49eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 2, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\u00f9\uda9b\udd0d\ud913\udda8", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u0f26\u3aa2\u0b60\u1a56\u1cc0\u042a\u3cca\u4da2\u9933\000\000\u185b\u84c1\uafe3\u7b60\u5d8a\u0a9d\u8677\u462e\u6527\u18c5\u0347\u049b\u4c5c\u4bf5\u8480\u8df1\u04de\u30aa\u54a0\000\000\u1858\ud6fe\u0e67\u06c7\ua8e8k", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c7\udc27\ud8e5\udc3d\uda8e\ude7e\uda40\udf8b\ud8ad\udc78\ud842\ude85\ud83b\ude11\udb61\ude30\uda0d\udf3c\u09cb\ud8fe\udf18\udbe1\uddb7\udaab\ude4b\ud9c1\udf38\udaa8\udcc6\udb26\uddce\ud9dd\udda2",
        -3, 67959, -1536680919, -1554166128502010935L, 12458L, false, false, (char) 30374, (char) 31046,
        Double.longBitsToDouble(0x3fb024180403d8c0L), Double.longBitsToDouble(0x3fe8000004fcbb3aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\ud86d\ude83\ud9a7\ude71\udad1\ude14\ud89f\udcf0\ud8e6\udfd4\ud8da\ude8c\uda28\udf0c\ua2db\uda66\udcc3\ud9a9\udc3c\ud885\ude62\udad9\udfba\ud828\udc5e", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u0f26\u3aa2\u0b60\u1a56\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u5d8f\u18f6\u84c1\uafe3\u7b60\u5d8a\u1684\u8677\u462e\u6527\u18c5\u0347\u049b\u8d04\u7860\u1e4f\u8df1\u04de\u30aa\ub370\u5b01\uce6e\u1858\ud6fe\u0e67\u06c7\ua8e8\u1954", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c7\udc27",
        58, 58865, -1547337477, -576895122484073005L, 35868L, true, true, (char) 25618, (char) 59429,
        Double.longBitsToDouble(0x3fd8d05f123602b0L), Double.longBitsToDouble(0x3fefaf7c513797a7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=211,g=211,b=211] |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 0, 2, 0, "\udb0d\udd89\ud866\udf42\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u9eb0\u3aa2\u0b60\u50da\u3186\u042a\u3cca\u8aac\u9933\u6eec\u5d8f\u18f6\u84c1\uafe3\u7b60\u5d8a\u0a9d\u8677\u462e\u6527\u18c5\u0347\u049b\u4c5c\u4bf5\u8480\u8df1\u04de\u30aa\ub370\u05ce\u2919\u7830\u3788\u1fe1\u06c7\ua8e8\u1954", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c7\udc27\ud8e5\udc3d\uda8e\ude7e\uda40\udf8b\ud8ad\udc78\ud842\ude85\ud97c\udcd2\udb6f\udf11\uda0d\udf3c\u280e\ud8fe\udf18\udbe1\uddb7\udaab\ude4b\ud9c1\udf38\udaa8\udcc6\udb26\uddce\ud9dd\udda2",
        -3, 67959, -1536680919, -1554166128502010935L, 12458L, false, false, (char) 30374, (char) 2578,
        Double.longBitsToDouble(0x3fea8755e8801bddL), Double.longBitsToDouble(0x3fea23da5cfcbb3aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=155,g=155,b=155] |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 0, 3, 4, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87", "\uc267", "\uda28\udf0c\ua2db",
        54, 45872, 380502009, -3550073575586790740L, -24462L, false, true, (char) 33803, (char) 50324,
        Double.longBitsToDouble(0x3fe37d1c1ce4d1f1L), Double.longBitsToDouble(0x3fe3fe34a66b024aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 5, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u53b9\u3aa2\u0b60\u1a56\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u5d8f\u9c52\u3777\u4d79\u7b60\u5d8a\u0a9d\u8677\u462e\u6527\u5a1a\u0388\u049b\u4c5c\u4bf5\u8480\u8df1\u04de\u30aa\ub370\u5b01\uce6e\u1858\ud6fe\uab67\u06c7\ua8e8\u1954", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\ud8c5\uddd4\udbea\udfb0\ud860\udf76\ud92e\udf59\ud8a2\udd4f\ud8ad\udc78\ud842\ude85\ud97c\udcd2\udb6f\udf11\uda0d\udf3c\udb4d\udfef\ud910\udd3f\udbe1\uddb7\udaab\ude4b\ud9c1\udf38\udaa8\udcc6\udb26\uddce\ud9dd\udda2",
        57, 67959, -1536680919, -1554166128502010935L, -53078L, false, false, (char) 30374, (char) 31046,
        Double.longBitsToDouble(0x3fb024180403d8c0L), Double.longBitsToDouble(0x3fea23da5cfcbb3aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 2, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud9a3\udcf2\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ubcdb\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud9b3\udde4", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\ub6b0\u5d3f\u3aa2\u0b60\uaa20\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u5d8f\u18f6\u2050\u9765\u9fd1", "\udaae\udd6b\ud8b9\udc61\uda03\udded\udae9\uddab\ud86a\udc18",
        34, 78358, -111621160, -8654368341630200029L, -46634L, true, true, (char) 64416, (char) 12092,
        Double.longBitsToDouble(0x3fd859c91fa95c04L), Double.longBitsToDouble(0x3fef08d26077f4a1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=162,g=162,b=162] |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 0, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\udae8\udd32\ud9a1\ude3b\udbba\ude6b\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u0f26\u3a59\u0b60\u1a56\u4c3e\u042a\u3cca\u4da2\ub392\u2e1f\u5d8f\u18f6\u84c1\uafe3\u7b60\u5d8a\u0a9d\u8677\u462e\u6527\u18c5\u0347\u049b\u4c5c\u4bf5\u8480\u8df1\ud2dd\u30aa\ub370\u5b01\u05a1\u1858\u2b71\u9d31\u06c7\ua8e8\u1954", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c4\udc27\ud8e5\udc3d",
        -5, 82523, -134318863, 5741647326466448904L, -47377L, true, true, (char) 39456, (char) 48914,
        Double.longBitsToDouble(0x3fe454d3e39c26ebL), Double.longBitsToDouble(0x3fdbf6358febdf86L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=198,g=198,b=198] |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 0, 3, 3, "\000", "\u34f4", "\ud89f\udcf0",
        37, 95764, -1695266559, 3674972252462547329L, 96615L, false, false, (char) 53607, (char) 16725,
        Double.longBitsToDouble(0x3fe8d95fc2355287L), Double.longBitsToDouble(0x3fe78249d2f71a13L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 1, "\udb0d\udd89", "\u34f4\u2d10\u7009\u6ab3\u2a54\u02ed\u7222\u1fcb\000", "\udad7\udffc",
        51, 25735, 1375791899, 5276529913855445744L, -100000L, false, false, (char) 19061, (char) 50324,
        Double.longBitsToDouble(0x3fe37d1c180000f1L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 6, 2, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\udb42\udc29\udb65\udd5e\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u9535\u0f26\u3aa2\u0b60\u1a56\u4c3e\u042a\u3cca\u4d6e\u9933\u66a1\u99cb\u18f6\u84c1\uafe3\u7b60\u5d8a\u0a9d\u8677\u462e\u6527\u18c5\u0347\u049b\u4c5c\u4bf5\u8480\u8df1\u04de\u30aa\ub370\u5b01\uce6e\u1858\ud6fe\u0e67\u06c7\ua8e8\u1954", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c7\udc27\ud8e5\udc3d\uda8e\ude7e\uda40\udf8b\udbf1\udd84\ud8f5\udecc\udb78\ude55\udb6f\udea6\uda0d\udf3c\u280e\ud8fe\udf18\udbe1\uddb7\udaab\ude4b\ud9c1\udf38\udaa8\udcc6\udb26\uddce\ud9dd\udda2",
        -3, 67959, -1536680919, -1554166128502010935L, 12458L, false, false, (char) 30161, (char) 31046,
        Double.longBitsToDouble(0x3fb024180403d8c0L), Double.longBitsToDouble(0x3fea23da5cfcbb3aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e\ud968\udf46\ud973\udcd7\udb01\ude19\ud977\udc79\ud986\udf6c\ud88f\uddf3\udb0d\ude64\ud832\udc63\udab0\ude80\ud882\udfb8\udaec\udd81\uda0e\udea1\ud90f\udc11\ud8cc\udc43\uc45c\ud8e7\udc61\udbe8\udceb\udace\udf10\ud8ac\udcc1\ud9f6\udfc4\udbd0\udf59\uda31\uddd1\udb7c\udf21\udaf2\udf40\ud9ed\ude48", "\u5d8a", "\uda46\udc96\uda03\udded\udae9\uddab\ud86a\udc18\udb1b\udcf9\ud955\udd6b\uda6a\udf73\ud816\udfc5\ud928\udd1c\ud87f\udf20\ud929\udf98\ud8f8\ude2d\u9cbc\udb9b\ude6b\ud4b0\udae4\udd60\ud9b4\udf35\udb69\udd32\uda95\udcfe\udb9f\uded3\udbd5\ude77\ud82f\udcea\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc",
        24, 74773, -598668135, -6645763859724471055L, 71528L, true, false, (char) 44764, (char) 40579,
        Double.longBitsToDouble(0x3feefb520d1eaef4L), Double.longBitsToDouble(0x3fdf20a34b1a0be2L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 6, 3, "\ud8f1\udffa\udb14\udf17\ud94b\udd64\udb7f\uddde\ud93b\udd1e\ud95d\udf4e\ud89f\udcf0\uda5e\udca2\udb43\udffe\ud8e4\udcc5\ua6ea\uda66\udcc3\ud951\udc52\udb16\udd3b\ud81d\udc33\udb86\udf46", "\ua1e7\uc1d7\u4eab\uc456\u5027\u39b8\u4256\u17d9\u50d6\u94fa\u0f26\u2ba2\u0b60\u1a56\u6aa7\u0aab\u7b39\u4da2", "\ud99e\udc5f\ud8e2\uddd1\ud9d8\udf39\ud9e2\udf89\udab2\ude79\u824d\ud981\udddd\ud8e5\udedb\uda46\udc96\uda03\udded\udae9\uddab",
        24, 5459, -1088296642, -3056312642371730490L, -68125L, true, true, (char) 48315, (char) 64283,
        Double.longBitsToDouble(0x3fef8ed79bd35b86L), Double.longBitsToDouble(0x3feea57013e11a4cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 6, 6, 1, "", "\u4d17\u0f83\u938e\u7009$\uca12\u0092", "\uda66\udcc3",
        38, 25818, 15896510, -950188800L, 78973L, false, false, (char) 36618, (char) 0,
        Double.longBitsToDouble(0x3e33a80000000000L), Double.longBitsToDouble(0x3f39280000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud016\udb14\udf17\ud94b\udd64\ud890\udcf3\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda5e\udca2\udb43\udffe\ud8e4\udcc5\ua6ea\uda66\udcc3\ud951\udc52\udbc0\udcc4\ud90a\udd76\ud858\udd70", "\ua1e7\uc1d7\u4eab\uc456\u5027\u39b8\u4256\u17d9\u50d6\u94fa\u0f26\u2ba2\u686a\u0be4", "\ud9d6\udd96\ud9f6\udfc4\udbd0\udf59",
        35, 8214, 1391486190, 4062185183331841383L, 85336L, false, false, (char) 54617, (char) 34328,
        Double.longBitsToDouble(0x3fe37fb6108b652bL), Double.longBitsToDouble(0x3fd2fb49ebb7db08L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 6, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e", "\ud0ff\uc1d7\u5c30", "\ud832\udc63\udab0\ude80",
        35, 8204, 38412927, -2873852455191699742L, 93840L, false, true, (char) 56131, (char) 41240,
        Double.longBitsToDouble(0x3fcda155e54fb164L), Double.longBitsToDouble(0x3fd289aa695c9e3aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 6, 6, 3, "\ud957\udc8d\u16ae\udaa8\udcd2\udbd6\udf8c\ud8f1\udef5\udaef\udf4f\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda59\udc04\ud8e2\uded7\uda66\udcc3\udbc2\udf48\ud86e\udd4f\udad7\udffc\ud828\udc5e\ud886\uded6\ud837\udff8\ua6ad\ud97f\udf20\ud986\udf6c\udada\ude60\ud9bd\uddbd\ud832\udc79\udab0\ude80\ud882\udfb8\udaec\udd81\udb55\udc3f\ud90e\udfea\ud8cc\udc43\uda09\uddef\ud8e7\udc61\udbe8\udceb\udace\udf10\ud8ac\udcc1\ud8c9\ude4d\udbd0\udf59\uda31\uddd1\udb65\udff6\ud8e9\udc08\udad6\ude73\uda28\ude9d\ud8a5\udc0a\ue729\udbf5\udd0a\uda60\udd0e\udbce\udde3\uda7a\ude03\ud8a6\ude43\ud8f0\udf2c\udbed\udee8\udb1c\ude7d\ud961\ude19\ud8e0\udd5f\ud9d6\udced\ud995\udcdb\udaf7\udd29\ud8f9\uddad\udae2\udc87\udbf4\ude43\udb7c\udc6d", "\u81f7\ua717\ud7e5\u4e09\u8bb5\ucde3", "\ud987\ude6a\ue940\udb6d\udf94\ud924\udee7\ud86e\udceb\ud99a\ude8e\ud812\ude49\udab3\udf87\ud964\udf58\udbd4\udc09\udb13\udf99\uda71\uddbc",
        47, 41797, 2034949785, -4735522324282191881L, 22414L, false, true, (char) 37958, (char) 34605,
        Double.longBitsToDouble(0x3fc20cd1c38b23ecL), Double.longBitsToDouble(0x3fd231f6dde845a4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 6, 3, "\u4b00", "\u34f4", "",
        57, 27007, 1914147764, -7281114428035555381L, -100000L, false, false, (char) 0, (char) 39963,
        Double.longBitsToDouble(0x3fe1aa900200493aL), Double.longBitsToDouble(0x3e93e240f9000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 5, 3, 0, "\udad2\udd9b\udbf8\udeb0\ud9f0\ude79\udb62\udcfc\ud9bf\udf38\udad1\udea3\ud89f\udcf0\ud99c\udfe2\ud8da\uddc9\uda28\udf0c\ua2db\ud817\udfc3\udbc2\udf48\ud9aa\udfae\udad7\udffc\ud828\udc5e", "\uc10d", "\ud88f\uddf3\udb0d\ude64\ud832\udc63\udab0\ude80\ud882\udfb8\ud89b\udd47\uda0e\udea1\udac8\udc0b\ud8cb\udfcc\ud9d8\udecb\ud81d\udc4f\ud811\udfa0\ud8f1\udc58",
        22, 48093, -567298619, 5700837731534066862L, -24443L, true, true, (char) 52040, (char) 22092,
        Double.longBitsToDouble(0x3fe5861979d240f4L), Double.longBitsToDouble(0x3fc2efe9012eb26cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 2, 6, 3, "\000", "", "",
        -5, 21152, 7837927, 8221039643092863233L, 64225L, false, true, (char) 64307, (char) 0,
        Double.longBitsToDouble(0x3f49c002bd800000L), Double.longBitsToDouble(0x3fe8d95fc2355287L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 5, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud9a3\udcf2\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ud81a\udd30\udb89\ude3d\udbc2\udf48\ud86e\udd02\udad7\udffc\ud9b3\udde4", "\ud0ff\uc1d7\u5c30\u116e\u4f40\ua165\u4232\u17d9\u50d6\ub6b0\u5d3f\u3aa2\u0b60\uaa20\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u5d8f\u18f6\u2050\u9765\u9fd1", "\udaae\udd6b\ud8b9\udc61\uda03\udded\udae9\uddab\ud86a\udc18\udb1b\udcf9\ud955\udd6b\uda6a\udf73\ue2c5\ud928\udd1c\ud87f\udf20\ud929\udf98\ud8f8\udd7d\u9cbc\udb9b\ude6b\ud4b0\udae4\udd60\ud9b4\udf35\uda25\udfaf\ud8e3\udc9e\ud9cd\udd95\ud8f0\ude91\uda78\udf36\udb0c\uddd4",
        42, 93532, -325762243, -3473787855144284792L, 11273L, true, false, (char) 29534, (char) 60785,
        Double.longBitsToDouble(0x3fe6aa897ac03a3bL), Double.longBitsToDouble(0x3fda1e3737d6f19aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.GrayPaintScale:@? |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=org.jfree.chart.renderer.GrayPaintScale:@? |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 1, 1, 5, "\udab1\udcda\udb35\udd8a\u79e9\ud88e\uddbb\ud950\udc52\ud95d\udf4e\ud89f\udcf0\uda5e\udca2\udb83\udd8e\ud8e4\udcc5\ua6ea\uda66\udcc3\ud951\udc52\udb16\udd3b\ud81d\udc33\udb86\udf46", "\ua1e7\uc1d7\u4eab\u827e\u7d3c\u3022\uc48b\u17d9", "\ud8c7\udfcd\ud858\udeeb\ue295\ud8e7\udc61\udb28\udfde\udb71\ude4f\ud8a7\udf76\udbd2\uddb6\udbd0\udf59\ud921\udc49",
        -1, 8190, 945801191, -2280662650341881854L, 60034L, true, false, (char) 45384, (char) 3534,
        Double.longBitsToDouble(0x3fddbed8427d38aaL), Double.longBitsToDouble(0x3feec5f90bc6d595L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 2, 2, 1, "", "\u4d17\u64ef\u217f\000\000\000\000", "\uda66\udcc3",
        38, -798, -972719104, 8836768586339279184L, 78973L, false, false, (char) 36618, (char) 36732,
        Double.longBitsToDouble(0x3fef3c086a753996L), Double.longBitsToDouble(0x3e49be8c00000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 4, 2, 3, "\udb0d\udd89\uda57\udd19\ud962\uded0\udbbf\udda1\ud9a7\ude71\udad1\ude14\ud89f\udcf0\uda8e\udddb\ud8da\ude6d\uda28\udf0c\ua2db\uda66\udcc3\udbc2\udf48\uda35\uddb3\udaf0\uddb0\ud863\ude7f", "\ud0ff\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\u3357\ud463\u3bad\u0b60\u1a56\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u9c8f\u18f6\u84c1\u52c1\uafe2\u8a47\uc9d9\u8677\u462e\u6527\u2ac4\u0347\u049b\u4c5c\u4bf5\u8480\u8df1\u04de\u30aa\ub370\u5b01\uce6e\u1858\ud6fe\u3648\u06c7\ua8e8\u1954", "\udb5e\udd2c\ud9aa\udd8b\uda42\udef0\udb6c\udfbc\ud8c7\udc27\ud8e5\udc3d\uda8e\ude7e\uda40\udf8b\ud8ad\udc78\ud842\ude85\ud97c\udcd2\udb6f\udf11\uda0d\udf3c\u280e\uda0a\udd35\udbe1\uddb7\udaab\ude4b\udae2\udfa7\udaa8\udcc6\udb26\uddce\ud9dd\udda2",
        -3, 67959, -1536680919, -7858080072810984095L, 12458L, false, false, (char) 30374, (char) 31046,
        Double.longBitsToDouble(0x3fd329060871ea9aL), Double.longBitsToDouble(0x3fea21f8a4fcbb3aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 2, 6, 3, "\udb0d\udd89\uda57\udd19\ud870\ude57\udb35\ude87\ud9a7\ude71\udad1\ude14\ud9a3\udcf2\udbfc\udf72\ud9b4\udd35\uda28\udf0c\ubcdb\uda28\ude45\udbc2\udf48\ud86e\udd4f\ud860\udfee\ud9df\ude13", "\ua71a\uc1d7\u5c30\u116e\u4f40\u39b8\u4256\u17d9\u50d6\ub6b0\u5d3f\u3aa2\u0b60\uaa20\u4c3e\u042a\u3cca\u4da2\u9933\u6eec\u5d8f\u18f6\u2050\u9765\u9fd1\u42b6\uc6ac\u283d\u7825\u6527\u18c5\u0347\u049b\u4c5c\u4bf5\u0b80\u8df1\u04de\u30aa\ub2c0\u5b01\uce6e\u1858\ud6fe\u0e67\u984a\u9d15\u6371\u5b3a\u1978\u942b\uae77\ucd5e\ub20e\ua8bc\u8fd3\uacbb\ubd7d\u806e\u2c2b\uaa15\u32f1\u4d87\u8628\ua8d4\u4758\ucee3\ubd01\u04f1\u6de9\u7d38\ud617\u6843\u5f05\ua29c\u8024\ucc79\u9abd\u4e71\u946b\ua68e\u5890\u9c4c\uc54d\u02dc\uc96a\u8795\u095c\u7936\u6f44\ubfe3\u31d3\u7757\u7fac\u0641\ub15d\u1939\u4210\u29d3\uae0d\u0bd3\ud4c2\ucfc2\u2131\u6bee\u9854\u918e\u2159\u7102\u89cb\uc597\u615e\ube28\u2ffa\u5f52\u8883\u918f\ub8aa\ubc48\u838b\u75f0\u83d4\ub79b\u520d\u1b36\u1598\ua041\ud47d\u9a8f\u0890\u324c\ud43e\u774a\ubd1e", "\ud8be\udf4c\ud8c3\udec0\udadd\uddff\ud991\ude71\ud988\udfbc\ud83b\uddaa",
        25, 57186, -1541840034, 1343196760129855978L, -31028L, false, false, (char) 34795, (char) 26496,
        Double.longBitsToDouble(0x3fd7dc657b88466cL), Double.longBitsToDouble(0x3fd6c16d2037ac42L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 2, 5, 5, "\udbe7\udfba\uda57\udd19\ud870\ude57\ud979\udc0a\ud9a7\ude71\udad1\ude14\ud9a3\udcf2\uda8e\udddb\ud8da\ude5c\uda28\udf0c\ubcdb\uda69\udf9d\udbc2\udf48\uda7d\udfd7\udad7\udf44\ud9b3\udde4", "\ud0ff\ucf44\u5eff\u116e\u4f40\u39b8\u4256\u16c5\u50b8\u8a2e\u5d3f\u5427\ud5d5\u5ac5\uc192\uccb7\ud37a\u7c84\uc0b4\u6eec\u5d8f\u18f6\u2050\u9765\ud311", "\udaae\udd6b\ud8b9\udc61\uda03\udded\udae9\uddab\ud86a\udc18\udb1b\udcf9",
        43, 83840, -2015002151, -2351486887034059463L, 44433L, false, true, (char) 38479, (char) 18941,
        Double.longBitsToDouble(0x3fdb70328d134672L), Double.longBitsToDouble(0x3fe2ebc9e3848f2bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.GrayPaintScale|getPaint|double|new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|clone||new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|equals|java.lang.Object|new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|getLowerBound||new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|getUpperBound||new:org.jfree.chart.renderer.GrayPaintScale:",
    "C|org.jfree.chart.renderer.GrayPaintScale|<init>|",
    "C|org.jfree.chart.renderer.GrayPaintScale|<init>|double,double",
    "M|org.jfree.chart.renderer.GrayPaintScale|getPaint|double|new:org.jfree.chart.renderer.GrayPaintScale:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
