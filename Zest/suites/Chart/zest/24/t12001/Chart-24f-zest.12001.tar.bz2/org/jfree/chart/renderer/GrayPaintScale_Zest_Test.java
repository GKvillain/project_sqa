package org.jfree.chart.renderer;
import org.junit.Test;
import static org.junit.Assert.*;
public class GrayPaintScale_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udae9\ude45\ud84d\udc45", "\u76ac\u3632\u1793\ubd0c\uc375\u7c9e", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\ud805\udd41\uda9c\udc2b\udb88\udc98\ud873\ude5b\udaed\ude9e\ud94f\udebc",
        50, 62275, 170101278, 2348173769612800884L, 96105L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fdee67f9d0190c6L), Double.longBitsToDouble(0x3fcb16388a64e944L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\u7d51\udbee\udc49\ud85c\udcca\udbe2\udd4b\udae9\ude45\ud84d\udc45", "\u76ac\u3632\u1793\ubd0c\uc375\u7c9e", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\ud805\udd41\uda9c\udc2b\udb88\udc98\ud873\ude5b\udaed\ude9e\ud94f\udebc",
        50, 62275, 170101278, 2348173769612800884L, 96105L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fdee67f9d0190c6L), Double.longBitsToDouble(0x3fcb16388a64e944L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\ud829\ude61\ud8b4\udcee\ud8f7\ude5b\ud98b\uddee\ud9bc\udf76\udb39\udfa2\ud84d\udc45", "\ub564\u3632\u1793\ubd0c\uc375\u7c9e", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\ud805\udd41\ud852\ude5c\udb88\udc98\ud873\ude5b\udaed\ude9e\u7d25",
        53, 18755, 170101414, 2348173770216780660L, 96099L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fdee67f9d0190c6L), Double.longBitsToDouble(0x3fcb16388a64e944L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f", "\u21f4\ub5e9\u46c3", "\uda46\udfd8\uda7e\udfed\ud970\udfa8\ud97c\udc52\uda18\ude9d\udbf2\udd1e",
        54, 6116, 1085239679, -6662503975284399534L, -17485L, false, false, (char) 48224, (char) 40894,
        Double.longBitsToDouble(0x3fe63269f0d3725dL), Double.longBitsToDouble(0x3fe0f6711b9a0a23L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=123,g=123,b=123] |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 0, 3, 0, "\ud9d4\udf05\ud8f5\udeb7\u6ccd\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udae9\ude45\ud84d\udc45", "\u76ac\u1344\u1793\ubd0c\u072e\u7c9c", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\ud805\udd41\000\000\ud864\udc31\udaed\ude9e\ud94f\udebc",
        50, 62275, 30, 2348173769612800884L, -100000L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fdee67f9d0190c6L), Double.longBitsToDouble(0x3fcb16388a64e944L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb75\ude43\ud85b\ude0f\ud8f7\ude0b\ud918\udca9\u931f\udaea\udc82\ud84d\udc45", "\uc2fc\ua758\u768b\u4105\uca8c\ub639", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\u9441\uda9c\udc2b",
        42, 30938, -712001249, 5566108493791488936L, -69822L, false, true, (char) 21514, (char) 20035,
        Double.longBitsToDouble(0x3fe8dff274fb63acL), Double.longBitsToDouble(0x3fd376e0edf4ef18L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.awt.Color:java.awt.Color[r=89,g=89,b=89] |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 2, 0, 4, "\ud946\uddbd\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\ud9ec\ude32\ud89b\udd89\ud861\udc53", "\u76ac\u3632\u17b3\ubd0c\uc375\u7c9e", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\u23e2\ued70\uda23\udf4e\udb7f\udd84\ud873\ude5b\udaed\ude9e\ud94f\udebc",
        50, 62275, 1039556382, 2348173808474201716L, 96105L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fd694df9d0190c6L), Double.longBitsToDouble(0x3fcb16388a64e944L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 6, 5, "\udb52\udc6f\u3195\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u3973\u1894\ud8f7\udc07\ud84d\udc45\udafd\uddb7\uda50\udd4f\ud9f1\udfae\ud8c0\ude9f\ud984\udf17\ud80f\udf72\ud801\ude6f\udbd7\udf84\ud93c\udcd6\ud91c\udd6f\udb65\udda6\ud8d3\udce8\ud853\udc30\udba2\ude8e\ud805\udd41\uda9c\udc2b\udb88\udc98\uda29\udf8b\ud80f\udca1\ud94f\udebc\ud945\udd83\udb0d\udde2\udbe9\udfb6\uda71\udd85\udb90\udc34\ud995\udd80\udad8\udcfa\ud8ff\udf57\ud852\udcc7\ud97a\ude08\uda2a\uddba\uda7e\udf58\udbff\udea6\udaf8\udde3\udb39\udc47\ud842\ude2a\udbe1\uddcf\udaab\udf5a\ud9b8\udeb3\udae5\udd33\ud9eb\udfee\ud85a\udcf0\ud9c8\udf45\udb67\ude8d\ud9ba\udc54\ud89b\ude0e\uda39\ude44\udaec\udcc3\udbc4\udcdc\ud9f9\udf38\udb02\udcda\udb78\udc35\udb74\uddec\udb7a\udf41\ud898\ude2e\ud8ce\udd7b\ud815\udc6a\udb7a\udf8d\udaeb\udda3\ud8b4\udf98\ud920\udeff\ud8c8\udd42\ud96e\udfc0\ud982\udf2b\ud838\udecc\ud8b2\ude6c\uda39\udcae\udbf5\udd78\udb2f\udf52\udb35\udc56\ud922\uddd5\udac5\udf07\uda4f\udef6\udbc9\udd0e\uda2a\udfda\udb10\udcd2\ubb01\ud9d4\udeb3\uda3f\udf6e\ud994\uddd8", "\u51d8\u99de\u3d0d", "\ud9f2\uddf1\udac2\udfbc\ud8ea\udf38\uda5d\udc01\ud80f\udfd1\ud990\ude7f\ud81e\udc0b\uda4a\udd19\ud92d\udd24\ud965\ude29\udac3\ude0d\ud898\udc8c\udbc3\udf0b\udb5b\udc00\ud909\ude79",
        4, 98063, 2073424416, 7842465247438407344L, -62572L, true, false, (char) 14406, (char) 1369,
        Double.longBitsToDouble(0x3fda5a1436bb416aL), Double.longBitsToDouble(0x3fdd2848b7560efaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udae9\ude45\ud84d\udc45\udafd\uddb7\uda50\udd4f\uda46\udfd8\uda7e\udfed\ud970\udfa8\ud97c\udc52\uda18\ude9d\udbf2\udd1e\ud93c\udca3\udb3b\uddfe\udb7d\udd4e\ud81c\ude7c\udb7a\udd99\ud8b1\udcdc\ud9a8\udc6e", "\ua206\u071e\uad59\ubed5\ub092\u58da\u6239\ud7ae\ua397\u213d\u2c74\u8cf9\ucab2\u0620\uad9e", "\udb39\udc47",
        31, 54897, 1994395705, -1613894290141789692L, 39794L, true, false, (char) 5118, (char) 28990,
        Double.longBitsToDouble(0x3feb0d3fbd0bdb90L), Double.longBitsToDouble(0x3fecd89d9121b593L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=org.jfree.chart.renderer.GrayPaintScale:@? |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 5, 1, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udb33\udc89\ud84d\udc45", "\u76ac\u94ec\u49c8\ubd0c\uc375\u1bc2\u9e1a\uabb4\u4e29\u2a59\u7d0a\u683d", "\udb88\udc98\ud873\ude5b\udaed\ude9e\ud94f\udebc\ud945\udd83\ud96b\ude1b\udbd4\udeb6\ud9c8\udeb1\ud922\udd18\ud995\udd4a\udad8\udcfa",
        40, 90169, 367431870, -1048069230769345224L, 83961L, false, true, (char) 25632, (char) 31743,
        Double.longBitsToDouble(0x3fc68abd353cd95cL), Double.longBitsToDouble(0x3fcf6f50b2f86a64L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udb41\uddd0\ud854\ude32", "\u76ac\u3632\u1793\ubd0c\u44f7\u7c9e", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\uda4c\ude83\ud805\udd41\uda9c\udc2b\udb64\udd7a\ud873\ude5b\udaed\ude9e\ud94f\udebc",
        50, 62275, 170101278, 2348173769612800884L, 96105L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fdee40f969b595eL), Double.longBitsToDouble(0x3fc2422fa15fd7c0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud9d4\udf05", "S\u6cbdu", "",
        -5, 93264, -1381447022, 979252543488L, 31072L, true, true, (char) 36387, (char) 56833,
        Double.longBitsToDouble(0x3fd6c34d39b86d26L), Double.longBitsToDouble(0x3e4fbd0000000000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 6, 4, "\ud9aa\udef2", "\u0249\u8522\uc626", "\udae9\ude45\ud84d\udc45\udafd\uddb7\uda50\udd4f\ud861\udc18\ud941\udff8\udb19\udd1d\ud97c\udc52\udb13\udc23\ud81f\udcc2\ud93c\udca3\udb3b\uddfe",
        39, 9306, 378241418, 2922669217417641615L, -81636L, false, false, (char) 56379, (char) 40894,
        Double.longBitsToDouble(0x3fe84e736db55c6aL), Double.longBitsToDouble(0x3fe35266639a0a23L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\ud963\udefc\ud847\udeb0\ud8f7\ude0b\u39e5\uda2a\udfae\udbd8\udc49\udb39\ude16", "\u15a3\u5db9\u17b4\ubd0c\uc375\u50d1\u7463\u185b\u3f73\u2a59\u7d0a\u683d\u93e1\u65a7\ua662\ua206\u7ed2\u2dbc\u5e51\u95ba\u3622\u6239\u4d20\ua397\u213d\u2c74\u8cf9\ucab2\uc158", "\udaf8\udde3\udb4d\udc51\uc662\ud9ae\ude25\uda63\ude35\uda11\ude56\ud8f6\udd8c\uda8e\udc98\ud805\udec6\ud9fd\ude70\ud97d\udc59\u8be2\ud88e\udf15\udba7\udce4\ud9ed\udd62\udaf0\udf3d\udbda\udf1a\udb98\udefe\udb38\ude68\udbf0\uddd6\udbcc\udf43\ud9a9\udcda\ud9de\udf1d\ud92c\ude0b\udb19\udead\udb23\ude80\udae7\udcc0\udbeb\ude86\ud9b4\udfb9\uda06\udf9b\ud96b\udf36\ud97e\udfae\ud914\ude89\ud808\ude8f\udb40\udf33\ud82f\udf77\ud8fa\udc96\ud9c0\ude27\ud81c\ude54\udb13\udca1\ud900\ude89\udb34\udfb1\uebc8\uda35\ude95\udbad\ude80\udb0d\uddf6\ud9a3\udfb3\uda1c\udddf\ud995\uddb9",
        21, 88855, -459550557, -5338197690059560952L, 80120L, true, false, (char) 36440, (char) 38702,
        Double.longBitsToDouble(0x3fd9e917496b0fdaL), Double.longBitsToDouble(0x3feb9883d2b1833bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 2, "\ud9d4\udf05\u31c4\udb49\udc06\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udae9\ude45\ud84d\udc45", "\u76ac\u3632\u1793\ubd0c\uc375\u7c9e", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\ud805\udd41\uda9c\udc2b\ud8f1\ude10\ud873\ude5b\udad6\udf9e\ud94f\udebc",
        50, 62275, -1409566158, 2348173769612800884L, 96105L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fdee67f9d0190c6L), Double.longBitsToDouble(0x3fcb16388a64e944L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.GrayPaintScale:@? |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 1, 2, 0, "\ud9cc\ude83\u31c4\ud817\udc0d\udb7f\udda1\ud85b\ude0f\udbca\ude94\udbf1\udd21\udb5f\uddf3\udae9\ude45\ud84d\udc45", "\u76ac\u3632\u1793\ubd0c\ubfef\u7d5d", "\udb7d\udd4e\udbaa\udf25\ud86e\udf0f\udba2\udee3\ud805\udd41\uda19\udf49\udad2\udcbb\uda69\udc23\ud947\udfe5\ud932\uddbc",
        50, 62275, 442774822, 2348174035475177998L, -38928L, false, true, (char) 5232, (char) 41857,
        Double.longBitsToDouble(0x3fdee67a3d0190c6L), Double.longBitsToDouble(0x3fdd8b1c453274a2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 3, 0, "\ud9ec\udc05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\udb4e\udde0\udb60\udeac\udae9\ude45\ud84d\udc45", "\u76ac\u3632\u1793\ubd0c\uc375\u7c9e", "\udb7d\udd4e\ud906\udef0\ud852\udfa6\udba2\ude8e",
        28, 51347, -973763216, 6811303089382220700L, -26586L, true, false, (char) 22593, (char) 28093,
        Double.longBitsToDouble(0x3feba104b59a30a9L), Double.longBitsToDouble(0x3fe8dff274fb63acL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac", "\ua8fa\ubc60\u76ac\u3632\u1793\ubd0c\uc375\u7c9e\u9e1a\uabb4\u4e29\u2a59\u7d0a\u683d\u93e1\ube98\u206e\ua206\u7ed2\u2dbc\u5e51\u95ba\u3622\u6239\u4d20\ua397\u213d", "\ud97a\ude08",
        36, 60440, -933021202, -5637162579524493096L, -35478L, false, false, (char) 12685, (char) 46625,
        Double.longBitsToDouble(0x3fec55b0fea1f8f8L), Double.longBitsToDouble(0x3fe12b2ecfe176a6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u00ab\u34c6\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb29\udfac\udae9\ude45", "\u6e3b\u76ac\u533c", "",
        24, 24162, 915615084, 1389031577533510015L, -76018L, true, false, (char) 41502, (char) 15570,
        Double.longBitsToDouble(0x3fdad9b28c000124L), Double.longBitsToDouble(0x3fd1f034245fab1eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.GrayPaintScale:@? |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 1, 3, 4, "\ud9d4\udf05", "\u9c5f\u432e\u9f76\u1c58\u543c\uc613\u46a3\u05af\u0265\ud193\u3632", "\ud90f\udd3f\ud838\uddc7",
        12, 76388, 1085239679, 3452256432953847378L, 35827L, true, false, (char) 55153, (char) 43244,
        Double.longBitsToDouble(0x3fe63371f0d3f25dL), Double.longBitsToDouble(0x3fefdcf2d2c20345L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 6, 0, "\ud9d4\udf05\u31c4\ud802\udca5\udb6d\udea1\ud85b\ude0f", "\ua754\ud3d2\u4750\ua8fa\u6e3b\u76ac\u3632\uc791", "\udbf2\udd1e\ud93c\udca3",
        51, 94679, -1551235089, 2481956909984028047L, -34947L, true, true, (char) 28604, (char) 48224,
        Double.longBitsToDouble(0x3fe17eac7ec64d3eL), Double.longBitsToDouble(0x3fca6e4bae07f078L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 2, 3, 0, "\ud9be\udfd9\u347f\ud817\udc59\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\udb64\udd04", "\u46c3\ua8fa\u6e3b\u76ac\u3632\u1793\u5720\u50d5\u7b58\uc365\u25b0\u8c10\u37a7\u37d4\u68e4\u93e1\ube98\u206e\ud349\u6cac\u2096\ubb56\u04ac\u3622\u4239\u1540\ua397\u213d\u8bc3\u8cf9\ucab2\uc158\ua073\u6804\u1d74\ub66a\ucaaf\ud237\uafab\u9f5a\u208d\uab45\u5327\ube7b\u3746\ua96b\u1d0b\ua090\u2ca5\u4ee0\u2af1\u5e81\u6e9d\u9b87\u3415\u5fbb\ud55c\u16c0\u05cd\u6e24\u8f35\u73aa\ucb9e\u2888\u11f0\ub7b9\uc52f\u2239\u7009\u365d\u65ae\u1d79\u6549\ud7ec\u1fe0\uaf64", "\udac9\uded2\uda18\udc76\uda1f\udecc\udb29\udff9\ud913\udc19\udaad\uddfc\u647e\udaaf\uddd6\ud91a\udf98\ud91f\udfa8\ud669\ud870\udfbf\ud929\udcf2",
        57, 92898, 1569792512, 7422365825227703026L, 45324L, false, false, (char) 58008, (char) 15163,
        Double.longBitsToDouble(0x3fe087585ab93984L), Double.longBitsToDouble(0x3fd71132541d7c54L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 1, 5, 3, 0, "\ud9f5\udd44\ud8c7\udfe1\ud817\udc0d\udb6d\udea1\udaa2\udfb3\ud90d\uddf9\u39e5\udb60\udeac\ud965\ude43", "\u6557\u76ac\u3632\u1793\ubd0c\u2676\u028d\u9e1a\uabb4\u4e29\u298a\u7d0a\u683d", "\ud97f\udd83\ud98a\udf4d\ud80e\udd62\ud93b\udf9e\ud945\udd83\udb0d\udde2\udbd4\udeb6\uda71\udd85\ud84b\ude52\ud995\udd80\uda0f\udd97",
        -5, 44857, 367427052, -1048069230769345224L, -29984L, true, false, (char) 59398, (char) 61315,
        Double.longBitsToDouble(0x3fc8209880b72564L), Double.longBitsToDouble(0x3febea13c87089c8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 6, 6, 5, "\ud9d4\udf2c\udbe9\udd2c\ud817\udc0d\uda8e\ude10\ud9cc\ude06\ud945\ude0f", "\u5e5e", "\ud90c\udc6d\ud887\uddb5\uda57\ude55\ud8cb\udef0\ud97c\udc43\uda42\ude93\udb62\uded6\ud93c\udca3\uda04\udf22\udafc\udf89\ud847\udfd6\ud852\udfa6\uda89\uddb1",
        52, 55425, 1086617780, -8360999497001551585L, -26730L, true, false, (char) 63025, (char) 54673,
        Double.longBitsToDouble(0x3fc8bacc9984c2a4L), Double.longBitsToDouble(0x3feb69d2f8fb638eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 5, "\u7e08", "\u4553\000\u2fa2", "",
        -5, -1000, 0, -720575941290510580L, 39475L, false, false, (char) 25151, (char) 54271,
        Double.longBitsToDouble(0x3fd7f1346fde815eL), Double.longBitsToDouble(0x3fb4a8e28158b458L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=123,g=123,b=123] |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 0, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udae9\ude45\ud84d\udc45", "\u76ac\u3632\u1793\u2779\u95f9\u7ca5", "\ud95a\udc96\ud8ec\udfc2\ud830\udfe1\udba2\ude8e\ud805\udd41\uda9c\udc2b\udb88\udc98\uda02\ude02\udb59\udd26\ud94f\udebc",
        31, 50295, 170068766, 2348173769612800884L, 89702L, false, false, (char) 2158, (char) 57004,
        Double.longBitsToDouble(0x3fdee67f983d0a2aL), Double.longBitsToDouble(0x3f5ef3753274a200L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "", "\u77ce", "\ud8f7\ude5b",
        50, 22702, -1082240144, 24388304896L, -73958L, true, false, (char) 66, (char) 32207,
        Double.longBitsToDouble(0x3fe96d77b602b29dL), Double.longBitsToDouble(0x3fd6c34d39b86d26L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.GrayPaintScale:@? |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=org.jfree.chart.renderer.GrayPaintScale:@? |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 1, 1, 3, "\ud93e\udc91\u31c4\udb6d\udcb3\ud9e3\udfa4\ud8b4\udcee\ud8a3\udcf1\udaa3\udcc2\ud9bc\udf91\udb39\udfa2\ud84d\udc45", "\ub564\u5ade\u1bba\u0613\uc375\u6b57", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\ud805\udd41\ud852\ude5c\udb88\udc98\ud95c\udff7\uda68\udefc\u7d25",
        53, 44883, 170105083, 2348173767761539956L, -40875L, true, false, (char) 28689, (char) 40279,
        Double.longBitsToDouble(0x3fe4b0af3638f174L), Double.longBitsToDouble(0x3fdee67f9d0190c6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 6, 6, 0, "\ud9d4\udf05\ud8f5\udeb7\ud9ac\udcd6\ud9b8\ude88", "\u02a4", "\ud817\udf9e\ud872\ude65",
        18, 77292, -654235904, -3191109925567978187L, 85564L, true, true, (char) 18590, (char) 17884,
        Double.longBitsToDouble(0x3f96938bf1f69b00L), Double.longBitsToDouble(0x3fe8425a00000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 6, 5, "\udb52\udc6f\u3195\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u3973\u1894\ud8f7\udc07\ud84d\udc45\udafd\uddb7\uda50\udd4f\ud9f1\udfae\ud8c0\ude9f\ud984\udf17\ud80f\udf72\ud801\ude6f\udbd7\udf84\ud93c\udcd6\ud91c\udd6f\udb65\udda6\ud8d3\udce8\ud853\udc30\udba2\ude8e\uda35\udf7a\uda9c\udc2b\udb88\udc98\uda3a\udc8b\ud80f\udca1\ud94f\udebc\ud945\udd83\udb0d\udde2\udbe9\udfb6\uda71\udd85\udb90\udc34\ud995\udd80\udad8\udcfa\ud8ff\udf57\ud852\udcc7\ud97a\ude08\uda2a\uddba\uda7e\udf58\udbff\udea6\udaf8\udde3\ud9ed\udf88\ud842\uddd6\udbe1\uddcf\udaab\udf5a\ud9b8\udeb3\udae5\udd33\ud9eb\udfee\ud85a\udcf0\ud9c8\udf45\udb67\ude8d\ud9ba\udc54\ud89b\ude0e\uda39\ude44\udaec\udcc3\udbc4\udcdc\ud9f9\udf38\udb02\udcda\udb78\udc35\udb74\ude0b\udb7a\udf41\ud898\ude2e\ud8ce\udd7b\ud815\udc6a\udb7a\udf8d\udaeb\udda3\ud8b4\udf98\ud920\udeff\udb19\udcba\udb0f\uddd3\ud982\udf2b\ud838\udecc\ud8b2\ude6c\uda39\udcae\udbf5\udd78\udb2f\udf52\udb35\udc56\ud922\uddd5\udac5\udf07\uda4f\udef6\udbc9\udd0e\uda2a\udfda\udb10\udcd2\ubb01\ud9d4\udeb3\uda3f\udf6e\ud994\uddd8", "\u51d8\u99de\u85b2", "\ud9f2\uddf1\udac2\udfbc\ud8ea\udf38\uda5d\udc01\ud80f\udfd1\ud990\ude7f\ud81e\udc0b\uda4a\udd19\ud92d\udd24\ud965\ude29\udac3\ude0d\ud898\udc8c\udbc3\udf0b\udb5b\udc00\ud909\ude79\ub632\ud9ed\ude98\ud9d0\udd68\udbd7\udf00\ud989\udca2\udb58\udfed\ud8e6\udf7e\ud937\udf42\ud80a\udd65\ud82a\udf8a\ud9ec\udee1\udadf\udcd8\ud945\udc07\ud9cf\udc16\u2243\uda71\uddd4\udac8\udf7e\ud96b\udf79\ud88b\udfa1\ud865\uddb7\ud92a\ude44\udbd5\ude94",
        14, 81372, 199438778, 1192494385795880425L, -1774L, true, true, (char) 61643, (char) 592,
        Double.longBitsToDouble(0x3fe5034025159e6aL), Double.longBitsToDouble(0x3fef2de779ce71fdL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 6, 5, "\udb52\udc6f\u3195\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u3973\u1894\ud8f7\udc07\ud84d\udc45\udafd\uddb7\udbaf\udf7f\ud9e2\udeaa\ud8c0\ude9f\ud984\udf17\ud80f\udf72\ud801\ude6f\ud8df\udf88\ud93c\udcd6\ud91c\udd6f\udb65\udda6\u2192\ud853\udc30\udba2\ude8e\ud805\udd41\uda9c\udc2b\udb88\udc98\uda29\udf8b\ud867\udc2c\ud94c\udd81\ud945\udcff\ud8f9\udf98\udbea\udc1d\uda71\udd85\udb90\udc34\ud995\udd80\udad8\udcfa\ud8ff\udf57\ud87d\udcc7\ud97a\ude08\uda2a\uddba\uda7e\udf58\udbff\udea6\udaf8\udde3\udb39\udc47\ud842\ude2a\udbe1\uddcf\udaab\udf5a\ud9b8\udeb3\udae5\udd33\ud9eb\udfee\ud85a\udcf0\ud9c8\udf45\udb67\ude8d\ud9ba\udc54\ud89b\ude0e\uda39\ude44\udaec\udcc3\udbc4\udcdc\ud9f9\udf38\ud830\ude66\uda10\udebd\udb74\ude5b\udb7a\udf41\ud898\ude2e\ud8ce\udd7b\ud815\udc6a\udb7a\udf8d\udaeb\udda3\ud8b4\udf98\ud920\udeff\ud8c8\udd42\ud96e\udfc0\ud982\udf2b\ud838\udecc\ud8b2\ude6c\uda39\udcae\udbf5\udd78\udb2f\udf52\udb35\udc56\ud922\uddd5\udab7\udd99\uda4f\udef6\udbc9\udd0e\uda2a\udfda\udb10\udcd2\ubb01\ud9d4\udeb3\uda3f\udf6e\ud994\uddd8", "\u51d8\u99de\u3d0d", "\ud9f2\uddf1\udac2\udfbc\ud8ea\udf38\uda5d\udc01\ud80f\udfd1\ud990\ude7f\ud81e\udc0b\uda4a\udd19\ud92d\udd24\ud965\ude29\udac3\ude0d\ud898\udc8c\udbc3\udf0b\udb5b\udc00\ud909\ude79\ub632\ud9ed\ude98\ud9d0\udd68\udbd7\udf00\ud989\udca2\udb58\udfed\ud8e6\udf7e\ud937\udf42\ud80a\udd65\ud82a\udf8a\ud9ec\udee1\udadf\udcd8\ud945\udc07\ud9cf\udc16\u2243\u0f7d\uda4f\udfbc\udb89\ude47\udb95\udfb5\uda0f\udced\ud81c\ude55\ud8ef\udc12\uda94\udf36\uda91\udd42",
        52, 41985, 1075782040, -4189146948128238721L, -83100L, true, true, (char) 22222, (char) 8221,
        Double.longBitsToDouble(0x3fdedc4a3cfe3cbcL), Double.longBitsToDouble(0x3fead59ccd51c993L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\udb7f\udfcf\uda85\udec8\udb60\udeac\udb41\uddd0", "\u6e3b\u76ac\u3632\u1793\ubd0c\u44f7\u7c9e\u9e1a\uabb4\u4e29\u2a59\u7d0a\u67b9", "\udb64\udd7a\ud873\ude5b\udaed\ude9e\ud94f\udebc\ud945\udd83\udb0d\udde2\udbd4\udeb6\uda71\udd85\ud84b\ude52",
        33, 82899, 672011515, 908317589844168894L, 35880L, false, true, (char) 38908, (char) 7695,
        Double.longBitsToDouble(0x3fb5fd7c346f3fd0L), Double.longBitsToDouble(0x3fbbcce1ea6c7540L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 5, 6, 4, "\udbf5\udeb7", "", "",
        52, -440, 805878, -4629434270698427130L, -100000L, false, false, (char) 27373, (char) 28774,
        Double.longBitsToDouble(0x3fd19e9b605b5decL), Double.longBitsToDouble(0x3fe80000050000d3L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=java.lang.Double:0.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud9d4\udf05\u31c4\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u39e5\udb60\udeac\udae9\ude45\ud84d\udc45", "\u76ac\u3632\u1793\u8738\uc375\u7c9e", "\udb7d\udd4e\ud81c\ude7c\ud852\udfa6\udba2\ude8e\ud805\udd41\uda9c\udc2b\udb88\udc98\ud873\ude5b\udaed\ude9e\ud94f\udebc",
        50, 62275, 170101278, 2348173769612800884L, 96105L, false, false, (char) 39035, (char) 57004,
        Double.longBitsToDouble(0x3fdee67f9d0190c6L), Double.longBitsToDouble(0x3fcb16388a64e944L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=new org.jfree.chart.renderer.GrayPaintScale:@?\012",
        Z.run(T, 2, 4, 6, 5, "\udb52\udc6f\u3195\ud817\udc0d\udb6d\udea1\ud8a1\udf32\ud8f7\ude02\u3973\u1894\ud8f7\udc07\ud84d\udc45\udafd\uddb7\uda50\udd4f\ud9f1\udfae\ud8fe\udc9e\ud984\udef2\ud80f\udf72\ud801\ude6f\udbd7\udf84\ud93c\udcd6\ud91c\udd6f\udb65\udda6\ud8d3\udce8\ud853\udc30\udba2\ude8e\ud805\udd41\uda9c\udc2b\udb88\udc98\uda29\udf8b\ud80f\udca1\udab1\udd49\ud945\udd14\udb0d\udde2\udbe9\udfb6\uda71\udd85\udb90\udc34\ud995\udd80\udad8\udcfa\ud8ff\udf57\ud852\udcc7\ud97a\ude08\uda2a\uddba\uda7e\udf58\udbff\udea6\udaf8\udde3\udb39\udc47\ud842\ude2a\udbe1\uddcf\udaab\udf5a\ud9b8\udeb3\udae5\udd33\ud9eb\udfee\ud85a\udcf0\ud9c8\udf45\udb67\ude8d\udafa\udee0\ud89b\ude21\uda39\ude44\udaec\udcc3\udad0\udf43\uda1c\udf83\ud4a6\udb78\udc47\udb74\uddec\udb7a\udf41\ud898\ude2e\ud8ce\udd7b\ud815\udc6a\udb7a\udf8d\udaeb\udda3\ud8b4\udf98\ud920\udeff\ud8c8\udd42\ud96e\udfc0\ud982\udf2b\ud838\udecc\ud8b2\ude6c\uda39\udcae\udbf5\udd78\udb2f\ude7a\udb35\udc56\ud922\uddd5\udad3\ude37\uda4f\udef6\udbc9\udd0e\uda2a\udfda\udb10\udcd2\ubb01\ud9d4\udeb3\uda3f\udf6e\ud994\uddd8", "\u51d8\u99de\u3d0d\u1243\uadb1\uae24\ub2df\u17ef\u1b20\uacbf\u2bb3\u71fa\ua5a2\u5d3b\u8c8b\ua5f6\u0dd8", "\ud909\ude79\ub632\udbed\udf98\ud9d0\uddea\udbd7\udf00\ud989\udca2\udb58\udfed\ud8e6\udf7e\ud937\udf42\ud80a\udd65\ud82a\udf8a\ud9ec\udee1\udadf\udcd8\ud945\udc07\ud9cf\udc16\u2243\ud8e6\udc6d\uda74\udf49\udbdb\udfc3\udb48\udf9c\udae2\udf6c\ud89d\udf09\ud902\uddb6\uda23\udc90\udb12\ude0b\udaf3\uddff\uda65\ude8e\ud94b\udf8d\ud509\ud8aa\udf7f\udbad\udc19\uda7f\udc33\ud9e5\udf36\ud87f\udf92\udb08\udd2a\ud862\udef2\ud818\udc9c\ue551\udb0c\udd8f\u729d\udb3a\udc26\ud84b\udf4f\ud851\udf33\uda84\ude02",
        19, 54600, 200979022, -1758938392099143721L, -31673L, false, false, (char) 44590, (char) 65310,
        Double.longBitsToDouble(0x3fda4484b38c82c8L), Double.longBitsToDouble(0x3feb7f4b979986baL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.jfree.chart.renderer.GrayPaintScale:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 6, 5, "\udb52\udc6f\u3195\ud817\udc0d\udb6d\udea1\ud85b\ude0f\ud8f7\ude0b\u3973\u1894\ud8f7\udc07\ud84d\udc45\udafd\uddb7\uda50\udd4f\ud9f1\udfae\ud8c0\ude9f\ud984\udf17\ud80f\udf72\ud801\ude6f\udbd7\udf84\ud93c\udcd6\ud91c\udd6f\udb65\udda6\ud8d3\udce8\ud853\udc30\udba2\ude8e\udbf2\udd03\ud88f\udeeb\udb88\udc98\uda29\udf8b\ud80f\udca1\ud94f\udebc\ud945\udd83\udb0d\udde2\udbe9\udfb6\uda71\udd85\udb90\udc34\ud995\udd80\udad8\udcfa\ud8ff\udf57\ud852\udcc7\ud97a\ude08\uda2a\uddba\uda7e\udf58\udbff\udea6\udaf8\udde3\udb39\udc47\ud842\ude2a\udbe1\uddcf\udaab\udf5a\ud9b8\udeb3\udae5\udd33\ud9eb\udfee\ud85a\udcf0\ud9c8\udf45\udb67\ude8d\ud9ba\udc54\udad9\udf91\uda70\udc77\udaec\udcc3\udbc4\udcdc\ud9f9\udf38\udb02\udcda\udb78\udc35\udb74\uddec\udb7a\udf41\ud898\ude2e\ud8ce\udd7b\ud815\udc6a\udb7a\udf8d\udaeb\udda3\ud8b4\udf98\ud920\udeff\ud8c8\udd42\ud96e\udfc0\ud997\udf2b\ud838\udecc\ud8b2\ude6c\uda39\udcae\udbf5\udd78\udb2f\udf52\udb35\udc56\ud922\uddd5\udac5\udf07\uda4f\udef6\udbc9\udd0e\uda2a\udfda\udb10\udcd2\ubb01\ud9d4\udeb3\uda3f\udf6e\ud994\uddd8", "\u9a8f\uc5e7\u6883", "\ud9f2\uddf1\udac2\udfbc\ud8ea\udf38\uda5d\udc01\ud80f\udfd1\ud990\ude7f\ud81e\udc0b\uda4a\udd19\uda69\udcc3\ud965\ude29\udbc3\uded5\ud898\udc8c\udbc3\udf0b\udb5b\udc00\ud909\ude79\ub632\ud9ed\ude98\ud9d0\udd68\udbd7\udf00\ud9a1\udea2\udb58\udfed\ud9c0\udc83\ud937\udf42\ud80a\udd65\ud82a\udf8a\ud9ec\udee1\udadf\udcd8\ud945\udc07\ud9cf\udc16\u2243\ud897\udfe7\ud993\udfbc\udbd2\udce9\ud879\udcd9\uda3c\udeb1\udb4b\udcc8\udbd7\ude5d\udb9f\udc0b\u9c44\udbb6\udfca\udb86\udcac\ud950\udea1\uda7c\udf7b\uda4c\udf72\ud9e2\udd27\ud95f\udcdc\uda5e\ude77\ud9bc\ude0c\ud939\udd48",
        51, 38846, 844084021, 7104459607464963741L, 41028L, true, true, (char) 14879, (char) 28361,
        Double.longBitsToDouble(0x3feb1f911859ac8eL), Double.longBitsToDouble(0x3fc49459a10037a0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.GrayPaintScale|getPaint|double|new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|clone||new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|equals|java.lang.Object|new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|getLowerBound||new:org.jfree.chart.renderer.GrayPaintScale:",
    "M|org.jfree.chart.renderer.GrayPaintScale|getUpperBound||new:org.jfree.chart.renderer.GrayPaintScale:",
    "C|org.jfree.chart.renderer.GrayPaintScale|<init>|",
    "C|org.jfree.chart.renderer.GrayPaintScale|<init>|double,double",
    "M|org.jfree.chart.renderer.GrayPaintScale|getPaint|double|new:org.jfree.chart.renderer.GrayPaintScale:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
