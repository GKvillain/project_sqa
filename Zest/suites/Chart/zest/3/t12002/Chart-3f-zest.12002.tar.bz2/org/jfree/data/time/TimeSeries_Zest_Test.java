package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimeSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e",
        -4, 18632, 1832428000, 7974011048015518068L, -48940L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud86d\ude39\ud8e9\udd69\uda8c\udc62\ud85f\udf7e",
        40, 18632, 1832428000, 7974011048015518068L, -48940L, true, true, (char) 19096, (char) 954,
        Double.longBitsToDouble(0x3fe638a336857ec3L), Double.longBitsToDouble(0x3feb8aad36bb16b8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 10, "\udbe8\ude20\uda3e\udc01\ud8d6\udf8f\uda60\uddf9\ud8e8\udff6\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\udb7e\uddbb\ud9f4\udfa9",
        30, 62087, 1832428000, 7974011050834090356L, -19289L, true, false, (char) 51402, (char) 10907,
        Double.longBitsToDouble(0x3fe388fb5684de74L), Double.longBitsToDouble(0x3fe452ca8bc3023dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 15, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b\ua8b2\u7c37\u2bb1\ud752\uc8c1\u65d0\ub673", "\ud996\udcc1\ud858\udf2c\ud8be\udc5b",
        23, 63597, 1448224960, 7870050791752032461L, 59365L, true, false, (char) 27896, (char) 36708,
        Double.longBitsToDouble(0x3fa198741c753630L), Double.longBitsToDouble(0x3fd1a80b0b5faa5aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e",
        -4, 18632, 1832428000, 7974011048015518068L, -48940L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b\ucff3\u58ad\u2bb1", "\udac5\udc4b",
        40, 13781, 631183099, -561541242087718743L, 10247L, false, true, (char) 64248, (char) 19894,
        Double.longBitsToDouble(0x3fdcdcc582e8dc58L), Double.longBitsToDouble(0x3feb5e80088c962cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 9, "\udbb8\udc8f\ud83d\udf0c\udae0\uddac\u3cd4", "\u7ec7\ub7dd\u5bb7\u3d0b\ua8b2\u2544\ua78b\u155d\uc8c1\u65d0\ua154\u9ffe\ubd64\u6ffa\u632f\u95a2\ud40a\u5aa9\u6e57\ubab7\ua652\u709d\u51fe\u61f8\u37f9\uab92\u6986\u09af\ucbc0\u22af\u572c\u907c\u5e1e\u7fe3", "\ud997\udc6e\u2c77\ud818\ude5d\u5e66\uda5a\udc52\ud0a4\ue223\ub112\udb26\udf74\ud9fd\udcef\ud8f9\udf3d",
        36, 35878, -942991280, -1053589213526773902L, -37006L, false, true, (char) 61093, (char) 3847,
        Double.longBitsToDouble(0x3feb83778a64715aL), Double.longBitsToDouble(0x3fbe262151201ee8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 7, 14, "\ud8a7\ude5f\ud80b\udf97\uda0a\udca0\u3cd4\ud8e7\ude84\udb19\udc24\ud9e6\udf37", "\u0cd1\u3d60\u41be\ud7d2\u6086\uc8c1", "\ud982\udd5c\udadd\udcd9\ud996\udcc1\ud858\udf2c\ud8be\udc5b",
        57, 14736, -1166483133, 7870249120456859853L, 89969L, true, true, (char) 7862, (char) 51402,
        Double.longBitsToDouble(0x3fe3d1e60a711f6aL), Double.longBitsToDouble(0x3fe426f3a45699d5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\udd09", "\000\u7ec7\ub7dd\u5bb7\u3d0b\ua8b2\u58ad\u2bb1\ud752\uc8c1\u65d0\u6c4b", "\ud996\udcc1\ud858\udf2c\ud8be\udc5b",
        52, 26106, -1166530368, 7870218334131282125L, -99889L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3388f800000000L), Double.longBitsToDouble(0x3fc09bce967da958L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 0, 2, "\udbd4\udd55\ud9cd\udd15\udae0\udd67\u3cd4\ud9d4\ude3d\udb15\udde7\ud933\udcfb", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb2a\udc12\ud898\ude68\udac6\udc15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\uda31\udcc7",
        -4, 18632, 708354528, -2843904521313101452L, -48940L, true, true, (char) 54423, (char) 26613,
        Double.longBitsToDouble(0x3fd8326bdd0b782aL), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 4, 0, "\ud8f3\udc4d\udaae\udf52\uda1b\udf4c\u3cd4\uda90\uddf7\udbf5\udd78\udb71\udc00\udaad\udfb9\ud8bb\udc92\ud9ba\udd43\udb81\udd39\ud898\udd7e\ud979\udc1a\ud8dd\udea0\ud97d\udd15\ud939\udd4f\udb3b\udd3d\ud8e1\udf65\udb24\udd8d\ud996\udcc1\ud858\udf2c\udab2\udc55\ud85f\udf7e\ud91f\udd07\u5ca7\ud9af\udc22\ud8da\udca4\ud822\udcb2\ud9bc\udd2e\ud958\udef0\ud983\udd88\u41e9\udb9c\udc33\uda91\udf8f", "\uc309\u7f0f\u7aae\u383f\u401e", "\u5e24\uda03\udfe6\ud893\udd29",
        39, 52004, -1297404352, 4433397138522756283L, 84159L, false, true, (char) 60829, (char) 50421,
        Double.longBitsToDouble(0x3fb178496b150e10L), Double.longBitsToDouble(0x3fef188904065985L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 15, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\ud82f\udce3\ud8f2\udd77\udb55\ude1d\udb4e\udc8c", "\u49cc", "\udb75\ude37\ud8dd\udea0\ud89c\udc74\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud99a\uddfa\ud858\udf2c\ud8be\udc5b\udab8\udc09",
        57, 81244, 1832428000, 7974011048015518068L, -48940L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 12, 10, "\ud829\ude01\udade\udc19\udb48\udcc5\u5c9f\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud939\udc76\uda19\udf31\ud898\udedb\udae0\udf15\udb9d\udc65\ud858\udefb\ud8be\udc5b\ud85f\udf7e",
        -4, 18632, 1832428000, 7974011048015518068L, -48940L, true, true, (char) 24525, (char) 64258,
        Double.longBitsToDouble(0x3fb5323bb42de0a8L), Double.longBitsToDouble(0x3fe7e87b5684de74L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 10, "\udac6\uddd2", "\u71b0\u0750\u4d1b", "\ud8bb\udc92\ud8e7\uddba",
        23, 48020, -1555326658, -6609115981472593565L, -60357L, true, false, (char) 35255, (char) 9927,
        Double.longBitsToDouble(0x3fd20da192ac5500L), Double.longBitsToDouble(0x3fd59ef60175c10cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\udbd4\udcdb\ud884\udffa\udb4e\udcc3\ud9ce\ude4a\ud8bb\udc92\ud8e7\uddba\udb01\udfcc\ud95e\udcfa\ud979\udc1a", "\u65d0", "\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e",
        -4, 18632, 1832428000, -5428701441682697352L, -48940L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b\u3e4c\u5842", "\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud972\udc34\udb95\udf79\ud91f\udd07\u5ca7\udb0a\udc4f\ud8ce\ude07\udbad\ude9f\ud9bc\udd2e\udab3\udf3d\ud831\ude7e",
        13, 67415, -630076176, 2295831762006481521L, -21166L, true, false, (char) 39876, (char) 13263,
        Double.longBitsToDouble(0x3fdddf873a91d022L), Double.longBitsToDouble(0x3fe19996f0f491ffL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 12, 4, "\uda87\ude2d\ud8eb\ude49\ud9e9\udd5f\udade\udedd\uda55\ude7b\uda5d\udd27\ud98d\udcab", "\uc099\u7982\u5c3e", "\ud99e\udf59\uda41\udc90\ud808\ude4d\udb26\udd63\ud866\udf7e",
        30, 20444, 1415629142, -2267991974589755394L, -50270L, true, true, (char) 35578, (char) 20870,
        Double.longBitsToDouble(0x3fc192deba44a25cL), Double.longBitsToDouble(0x3fb41b82737b39b8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\uda55\udcfc\uda9b\udc81\ud93a\ude3b", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\udaab\ude8f\udb3c\udcfc\ud850\udd84\udba5\uddc4\ud85c\udf25\u7211\ud8be\udc40\ud85f\udf7e",
        27, 12663, 1832403882, 7974011048015518068L, -48940L, true, true, (char) 23786, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e3fce3c4L), Double.longBitsToDouble(0x3fd84c342d089c2eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\udda0\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u414f", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e",
        -4, 18632, 1832428000, 7974011048015518068L, -48940L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 11, 11, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\ud5d2", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\udf05\udb3c\udcfc\ud9bb\uddf0\u36cd\u5832\udb6b\udc0f\ud89e\ude49\udb6b\udda3",
        -4, 18632, 1832428000, 7695166104142018128L, -19289L, true, false, (char) 51402, (char) 10907,
        Double.longBitsToDouble(0x3fe388fb56845274L), Double.longBitsToDouble(0x3fdaeb081917f2fcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4", "\u7ec7\uaf91\u755e\u3d8c\ua8b2\u58ad\u85b0\ud752\uc8c1\u0d75\u6c4b\ua346\ubd64\u6ffa\u632f\u8a1f\ud3b1\u6177\u6e57\u1b53\u54d8\u35d5\u4512\ua0a7\uc4c2\u0c29\u6986\u09af\ucbc0\u22af\u7018\ud5de\u3c58\ub8c4", "\uda15\udcb0\ud92f\ude53\ud9ec\uddf0\ud89d\udef3\ud979\udf3d\ud96c\udd81\ud82f\udcbe\ud888\udcda\u68f0\udb99\udc9c\udac3\udf01\ud908\udc0b",
        26, 97718, 1428508398, -3737244207771234895L, -76333L, false, false, (char) 5555, (char) 9200,
        Double.longBitsToDouble(0x3fee99e198b98ed7L), Double.longBitsToDouble(0x3fe147672a3465bcL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud8d9\udc2d\udbdb\ude0b\udaa6\udf76\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e",
        -4, 77332, 1832420151, 7974011048015518068L, 2501L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 12, 12, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\ud90e\udc53\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud8b3\udfbe\ud8be\udc6c\ud85f\udf7e",
        -4, 18632, 1832428000, 7974159482085267828L, -19289L, true, false, (char) 51402, (char) 10907,
        Double.longBitsToDouble(0x3fe5931353bc0f16L), Double.longBitsToDouble(0x3fef9e39d53fb18eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 6, 14, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\udb80\ude22\ud9db\udc27\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e",
        -4, 18632, 1832428000, 7974011048015518068L, -48940L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 11, 13, "\udbe8\ude20\udba7\ude16\ud8e8\uddb0\u6524\ud8e7\ude84\ud997\udc23\udae7\udd86\ud88f\udde8\ud9a6\udd1c\ud860\udc27\ud897\udd25\ud990\udf2a\ud979\udc1a\uda5f\udcaa\uda8a\ude26\ud9af\udcd2\ud810\udfc8\uda23\uddcf\udac3\udc94\ud927\udd56", "\u443a\u3c1c\u117e\u20ab\u3853\ua891\u51fe\u900d\u402a\uc38e\u9a26\ud0cf\uc3b3\u0a46\u2488\u54c2", "\ud8cc\udd23\uda63\udce4\uda8f\udd58\uda03\udf61\ud9d8\udc4f\ud9ed\udec3\ud876\udfcf",
        28, 23201, -1915639693, 3332784095610696542L, -86726L, true, true, (char) 4958, (char) 43362,
        Double.longBitsToDouble(0x3fecb68746cfca9eL), Double.longBitsToDouble(0x3febe999db861c2aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 7, 3, "\udb0b\udf3e\udba7\ude42\udae0\uddac\u3cd4\ud8e7\ude84\udb88\udedc\udb4e\udd07\uda98\udfb9\ud8bb\udc92\ud8e7\uddba\udaf2\udca3\u9a1b\udab2\udc7a\ud909\ude0d\ud85b\udcb4\ud9b7\ude98", "\u4195", "\ud8be\udc5b",
        0, 67539, -1166530401, 7870218334131282125L, 21967L, true, false, (char) 7949, (char) 51402,
        Double.longBitsToDouble(0x3fecbde0a9e28203L), Double.longBitsToDouble(0x3fe53b00c2a618e7L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 14, 10, "\udbe8\ude20\udba7\ude16\udaa7\uddaf\u3cd4\ud8e7\ude84\ud997\udc23\u017e", "\u23dc", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\udb72\ude94\udb3c\udcfc\ud898\ude68\uda69\udda5\ud996\udcbd\ud858\udf2c\ud8ef\udc54\ud85f\udf7e",
        2, 94163, -2107672599, 6076082042343366807L, -48940L, false, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3feaad8ce625a1bdL), Double.longBitsToDouble(0x3fe519322684de74L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 9, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\uda3c\udea9\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b", "\udbb1\ude46\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e",
        -4, 18632, 1832428000, -8932478863389140619L, -44362L, false, false, (char) 36455, (char) 21381,
        Double.longBitsToDouble(0x3fe388fb5684de74L), Double.longBitsToDouble(0x3fe2bf72f2f662ffL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 11, 5, "\udbe8\ude20", "\u2fe7", "\uda1f\udf78\ud968\udf83\udb94\udc89\ud9e3\udf73\udaf2\udca3\ud8a4\udffa\ud979\udc1a\ud8f1\udf1a\udbd7\udca7\ud9b7\udf30\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud9d7\udc98\ud8be\udc5b\ud85f\udf7e\ud91f\udd07\u5ca7\udb0a\udc4f\ud9e5\udf52\udbad\ude9f\ud9bc\udd2e\ud958\udef0\ud983\udd88\u41e9\u9839\ud94b\ude2d\udbd0\udc5e\udbb2\udc76\udb85\udc73\udb1e\udc3f\ud9de\udf99\ud9b1\udd6a",
        7, 91675, -1596283828, 8002761014946287427L, -89006L, false, false, (char) 26647, (char) 61066,
        Double.longBitsToDouble(0x3fe60529d43a5fe7L), Double.longBitsToDouble(0x3fe29b6d87a19259L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 16, 14, 8, "\udbed\udd47\udba7\ude16\udba6\uddab\ud867\udde8\ud9b3\ude4b", "\ub7dd\uc682\u2933\u513d\u58ad", "\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud9e1\ude5f\ud922\udee5\u5ca7\udb0a\udc4f\ud9e5\udf52\ud894\uddf9\udace\udd62\ud958\udef0\ud983\udd88",
        52, 45748, 1770506978, -6802096764125099914L, 46078L, true, true, (char) 63767, (char) 13453,
        Double.longBitsToDouble(0x3fef6d52d37020d4L), Double.longBitsToDouble(0x3fda64adf4a47f66L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 7, 5, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3d43\ud8e7\ude84\ud997\udc23\ud99a\udc16", "\u3d0b\ua8b2\u58ad\ucfe9\ud752\uc8c1\u9ecb\u6c4b", "\ud9cb\udfdb\udb48\udf16\udbf5\udde2",
        34, 36762, -1164858117, 3184198729745938631L, -44853L, false, false, (char) 27654, (char) 24728,
        Double.longBitsToDouble(0x3fe37e82362e969cL), Double.longBitsToDouble(0x3fe42de63f498115L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 12, 5, "\ud960\uddbc\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\udaeb\udc2e\ud9a5\udd42", "\u537c", "\udaab\udd56\ua8f3\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68",
        4, 4511, 1500679353, 4422545966105032952L, -60985L, false, true, (char) 57011, (char) 22164,
        Double.longBitsToDouble(0x3fa198d9b79e45f0L), Double.longBitsToDouble(0x3fe183dba47780bcL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 5, 0, "\000\000\000", "\ub9cb\000\ub743\u1d75\u9894\u49e7\u83ac", "\uda8a\ude26",
        29, 88914, -1059576287, 2706884236022186295L, -48458L, false, false, (char) 0, (char) 10240,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd7400000000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 12, 10, "\udbe8\ude20", "\000", "\udb4e\udc8c",
        5, 13884, -1916896138, 3074733828718046687L, -34153L, true, false, (char) 10999, (char) 20825,
        Double.longBitsToDouble(0x3fedd70430c0d238L), Double.longBitsToDouble(0x3fde0ba7819ada70L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 0, "\uda29\udd40", "", "",
        -5, 72352, -534157926, 269878565011456L, 10047L, true, true, (char) 22355, (char) 2474,
        Double.longBitsToDouble(0x3f09f00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 13, 0, 10, "\ud86a\udc60\udbd3\udfc2\udae0\udd83\uda66\udc86\udbeb\uddd6\udab1\uddb4\udadd\udee9", "\u3d0b\ua8b2\u588b\u2bb1\ud752\uc8c1\u57d6\ud2bc", "\ud996\udcc1\ud82f\udc8e\ud8be\udc5b\ud85f\udf7e\u08ba\ud934\udcf4\ud8f3\udd2c\ud8b2\udc3c\udbad\ude9f\ud9bc\udd2e\uda06\udcc2",
        55, 58513, -1768141201, -4893950245451698555L, -5412L, true, true, (char) 38690, (char) 36520,
        Double.longBitsToDouble(0x3fe92f81c5310470L), Double.longBitsToDouble(0x3f9a54abaec6d160L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 16, 10, "\udbe8\ude20\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud997\udc23\udb4e\udc8c", "\u3d0b\ua8b2\u58ad\u2bb1\ud752\uc8c1\u65d0\u6c4b\ua346\u1991\u6fe0\u632f\u95a2\ud40a\u6177\u6e57\u1b53\u23f5\ua891\u51fe\u3fe7\u9f68\u0c29\u6986\u09af\ucbc0\u22af\u09d0\u53a0\u3d38\uc591\u7582\u04e9\u08b7\u1ed9\u964e\u3f97\u28c1\u1de4\u6b57\u7e65\ub482\u45b0\u4e3c\u1c85\u2ed4\u24cf\uafd1\ub73b\u253f\u4d7a\u9900\u72fe\ud031\uc26c\u4f35\u67aa\ubc31\u0e4a", "\ud9d7\udd9c\uda45\ude39\udb57\ude22\uda29\udf3a\udabb\udff6",
        30, 93665, -1559999268, 7064071816902595546L, 78924L, false, false, (char) 6273, (char) 1796,
        Double.longBitsToDouble(0x3fef633845af7566L), Double.longBitsToDouble(0x3fd14590ea7a4128L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 3, 10, "\udbe8\ude20\udba7\ude16\ud9a5\udf6f\ud82a\udd1f\ud8e7\ude57\ud997\udc23", "\u54f9\u3d0b\ua8b2\u58ad\u2bb1\ud752\uc8c1\u65d0\uc556\u558b", "\ud858\udf2c\ud8be\udc5b\ud85f\udf7e\udb65\udd0a\u5ca7\u805b",
        30, 54068, -1775446165, 2924868655267136367L, 2779L, false, true, (char) 31190, (char) 43946,
        Double.longBitsToDouble(0x3fe7516d8aba55b2L), Double.longBitsToDouble(0x3fe9c2aa91309508L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 2, 4, "\udbe8\ude61\udba7\ude16\udae0\uddac\u3cd4\ud8e7\ude84\ud821\udd67\udb4e\udc83\uda98\udfb9\udb9c\udfe3\ud8bb\ude54\ud94a\udff5\ud880\udffa\ud979\udc1a\ud8dd\udea0\udb32\udfda\ud98a\udcc7\udb9c\ude87", "\u2271\u349b\ud66c\ud255\uc51d\u1b8c\u17bd\u999a\u7b20\u8c5d\ua111\uc4c2", "\ud8db\udffd\ud947\ude51\ud84f\udf37\ud91e\udc56\ud9e7\udcfb\uda4b\uddfc\udb85\udd68\udb27\uddbc\udb60\udf0f\ud85a\udfef\udbf7\udd72\ud9d7\udeb5\udbe2\ude2b\ud83d\udf03\ud813\udc73\uda08\udec4\udb97\udc32\ud830\udc11\u0994\ud9a2\uddb5\ud875\udd88\ud84a\ude79\udae3\udc9c\udadd\uddec\ud976\udf8d\udb0e\uddb0",
        5, 60504, -850984937, -8950596477215671974L, 7233L, true, false, (char) 65111, (char) 11334,
        Double.longBitsToDouble(0x3f5fa5c7f496f200L), Double.longBitsToDouble(0x3fc4e5b106ce4e50L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 10, 16, "\udbe8\ude20\uda3e\udc01\ud8d6\udf8f\uda60\uddf9\ud8e8\udff6\udb32\udd7f\udad8\udfc8", "\u58a5", "\ud8cd\udee3\ud87b\ude85\ud8f4\uddfe\uda38\udd4d\ud84c\udc67\udafc\udd3a\udae0\udf15\ud996\udcc1",
        56, 96606, -1623288138, -3300365936426954113L, -9683L, false, true, (char) 33571, (char) 29459,
        Double.longBitsToDouble(0x3fbbca25e5b03ef8L), Double.longBitsToDouble(0x3fb1c9fe91734978L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 12, 10, "\udafc\udcf1\uda32\udde0\ud8b9\udfc9\uda60\uddf9\ud8e8\udff6\ud997\udc23\udb4e\udc8c\uda98\udfb9\ud892\udfbd\ud8f1\uded6\udaf2\udca3\ud8a4\udffa\uda1e\udf6c\ud9e9\udde9\udafc\udd93\ud9b7\udeaa\ud97b\udf72\ud898\udef0\uda82\udfc6\udbfe\udfe2\udaac\ude91\udb72\uddbb\ubf55\udb74\udd6c\udbba\udd89\ua401\uda65\udde4\ud9be\udc23\u71b5\ud958\udef0\ud980\ude88\u41e9\ud89a\uddb2\ud94b\udef4", "\u0111\u6131\u6048\uba79\ub538\u5161\u7c70\u573e\u11c0\u4d7d\ua8de\u05e0\u096b\u9c32\ub069\uaa4d", "\ud9da\udfc4\udb4c\ude30\ud9b2\udf7e\ud9ee\udc05\udbe9\ude02\udaf1\ude98\ud929\udc8b\udbf4\udd0c\ud804\ude91\uda55\udcba\ud956\udf86\udb9c\udedd\ud93b\udea2\uda71\ude86\ud891\udf53\ud91f\udfe1\ud8d6\udf25\ud90b\udf55\ud8ac\udffa\udb27\udd79\udb47\udecd\uda2a\udef0\udbdc\udda6\ud838\udd8a\ud8d1\udcdf\ud847\ude78\ud9f6\udfd9\ud896\udc56\uda35\udd0a\uda99\udc4e\udbdd\udf57\udb75\ude93",
        -1, 11694, 290524482, -6326224339605071267L, 78970L, false, true, (char) 49960, (char) 57458,
        Double.longBitsToDouble(0x3fb1bb4c9288f648L), Double.longBitsToDouble(0x3fe9ded90bddae5eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 10, "\udbe8\ude20\uda3e\udc01\ud8d6\udf8f\uda60\uddf9\ud8e8\udff6\ud997\udc23\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\udb3d\udf7b\ud983\ude50",
        18, 17550, 194100430, 7974011050834090356L, -19289L, true, false, (char) 51402, (char) 57498,
        Double.longBitsToDouble(0x3f9adaa5d09bce80L), Double.longBitsToDouble(0x3fe452ca8bc3023dL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 9, 11, "\udbe8\ude20\uda3e\udc01\ud8cf\uddd9\uda60\uddf9\ud8e8\udff6\ud997\udc23\udb4e\udc8c\uda98\udfb9\ud8bb\udc92\udbb6\udef2\uda44\udc90\ud8a4\udffa\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\udbfb\udd29\udb73\udd89\ud836\udfaa\ubee8\ud86d\ude91\ud8ac\ude5e\udb37\udc89\ud81b\ude09\u71e7\ud958\udef0\ud980\ude88\u41e9\u9839\ud961\udc2d", "\u5860\u6131\ub6b9\ua83e\u3e79\u0830\u8a12\u3aef\u87e0\uc058\ubbe8\u8982\u964b\u7edc\u0c7a\ua110\u3ed1\uaa63\uc37c", "\udb8b\udf4d\ud81c\udd95\uda9a\udd3a\ud9bd\udf54\ud94d\udc83\uda57\ude0a\udbba\udfb7\uda62\udef8\udaa5\ude21\uda44\uded6\udbb7\udcca\udb49\udc6b\ud82e\udc5b\udbbd\udd2a\udb90\udc7c\udaa5\udc3a\ud927\uddba\ud98e\uddae\ud8d7\udd58\ud859\udc0e\udbc8\udc33\udbe8\ude87\ud866\uddb0\udb41\udca6\uda50\udff0\ud955\udfd3\udb20\udc65\ud83e\udcd9\ud85a\udd9d\u06f9\ud89e\udcb3\ud856\udd71\udb03\udc4a\ud9fe\udc48\ud9b0\udec0\ud961\uddc4\udbef\udca4\ud9b8\ude53\ud89a\udd25\ud850\udd7d\ud8cd\ude2d",
        40, 24222, -1126240464, -5792349507949628675L, -36938L, true, true, (char) 51458, (char) 43858,
        Double.longBitsToDouble(0x3fe1aacbf30f0582L), Double.longBitsToDouble(0x3fe54600023a065cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 7, "\uda19\ude1a\ud9fd\udea9\ud8d6\udf48\uda60\uddf9\ud8cc\udf80\ud997\udc23\udb4e\udc8c\uda2a\udfc2\ud8bb\udc92", "\ucf1d\u2bb1\u6a4a\u786c\u7fa7\u6c52\ua346\ubd64\u7494\u62f9\ud156\u1f01\u2062\u4017\u800f\u23f5\u1faf\ucba0\ua0a7\ub99d\u0be2\u6986\u09af\u0df4\u9250\u6d2b\ua1d8", "\ud863\udf2e\udba3\udeeb\ud826\udd66\uda0d\udf8e\ud967\udc92\ud908\uddf5",
        12, 92990, -1257549156, 2846762732175541900L, -16083L, false, true, (char) 48470, (char) 36515,
        Double.longBitsToDouble(0x3fe63e94480cf781L), Double.longBitsToDouble(0x3fbde3efd753bd50L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 13, 13, 8, "\ud9e5\udd08\udba7\udd66\udae0\uddac\u3cd4\ud8f7\uddad\ud9fb\udd3b\ud8b2\udf49\udb89\udd69\ud8d0\udc65", "\u7c37\u2bb1\u4408\uc8c1\u65d0\ub673\uafac\ubd00\u6ffa\u632f\u95a2\u2097", "\udae3\udfee\ud9e5\udf52\udbad\ude9f\ud9bc\udd2e\ud958\udef0\ud983\udd88\uda00\udde0\ud999\udf93",
        7, 92605, -562783631, -3864494731829918458L, -66639L, true, true, (char) 18435, (char) 606,
        Double.longBitsToDouble(0x3fe3fa94896397e3L), Double.longBitsToDouble(0x3fe6c1763eda1e8aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 10, "\udbe8\ude20\uda45\udca5\udb0b\uddaf\udb96\uddbc\udb2e\udeed", "\ub7dd\uafba\u7def\uba34\u57e5", "\uda8a\ude26\ud9b7\ude95\udb3c\udcfc\ud898\ude68\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\ud85f\udf7e\ud91f\udd07\udb29\udfc6\udb20\udeb5\uda20\udfc4\udb55\udff3\uda42\udfa4\ud958\udef0\ud998\ude51",
        19, 28194, -1139411605, 2263743279654148721L, 31876L, true, true, (char) 50454, (char) 61523,
        Double.longBitsToDouble(0x3fedcfed84b38c1dL), Double.longBitsToDouble(0x3fd6c98f8acc0948L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 16, 16, 16, "\udadf\udedf\udba7\ude16", "\u95fe\ucef1\u20ec\u019b\u53d5\u3d0b\ua8b2\u92d1\u2b2b\ud752\uc8c1", "\ud8cd\udee4\udae0\udf15\ud996\udcc1\ud858\udf2c\ud8be\udc5b",
        52, 57031, -2016851342, 7870128938681983181L, 2779L, true, false, (char) 27896, (char) 54582,
        Double.longBitsToDouble(0x3feed8ba8d0676f3L), Double.longBitsToDouble(0x3fdd572a9c22b394L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 0, 6, 0, "\u2d32", "\u9703", "",
        13, 20426, -956292801, 1103980288L, -99960L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f924d73c4200000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 0, 2, "\udbd4\udd55\ud9cd\udd15\udae0\udd67\u3cd4\ud9d4\ude3d\udb15\udde7\ud933\udcfb", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud9b7\ude95\udb2a\udc12\ud898\ude68\udac6\udc15\ud996\udcc1\ud858\udf2c\ud8be\udc5b\uda31\udcc7",
        -4, 18632, 711277536, -2843904521313101452L, -48940L, true, true, (char) 54423, (char) 26613,
        Double.longBitsToDouble(0x3fd8326bdd0b782aL), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 12, 10, "\ud829\ude01\udade\udc19\udb48\udcc5\u00df\000\udb64\uddf1\udb4e\udc8c", "\u3d0b", "\ud979\udc1a\ud8dd\udea0\uda8a\ude26\ud939\udc76\uda19\udf31\ud898\udedb\udae0\udf15\udb9d\udc65\ud858\udefb\ud8be\udc5b\ud85f\udf7e",
        -4, -1000, 1828716544, 7974011048015518068L, -48940L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fb5323bb42de0a8L), Double.longBitsToDouble(0x3f0ed40000000000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 12, 4, "\uda87\uddfb\ud8eb\ude49\udbbc\uddbb\ud9c9\uddd5\ud806\udf9b\ufd54\ud979\ude33", "\uc08f\u7982\ucb54", "\ud99e\udeaa\uda41\udc90\ud808\ude4d\udb26\udd63\ud866\udf7e",
        30, -991, -1553977598, -2267991974589755394L, -50270L, true, true, (char) 35578, (char) 56946,
        Double.longBitsToDouble(0x3fc192deba44a25cL), Double.longBitsToDouble(0x3fd506e09691a39aL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 6, 15, "\uda08\udf30\ud838\ude99\ud969\udd38\uda30\udf89\ud8ed\udf37\ud997\udc23\udb4e\udc8c\uda98\udfb9\ud8bb\udc92\ud917\ude05\udacd\udf78\ud8a4\udffa\ud979\udc1a\uda9d\udf57\udb80\ude22\ud9db\udc27\udb3c\udcfc\ud898\ude68\ud980\ude86\ud996\udd79\ud858\udf2c\ud8be\udc5b\ud85f\udf7e\ud91f\udd07\u5ca7\udb0a\udc4f\ud9e5\udf52\udbad\ude9f\ud9bc\udd2e\ud971\udff0\ud983\udd88\uda4b\udd56\u35bc\udb62\udc7e\udbbb\udde3\udbb2\udc76\udbbb\udd2e\uda36\ude99\uda93\udcad\udb57\udcab\ud882\udc7c\u3170\ud962\ude78\uda11\udeb1\udaa6\ude37\uda73\uddaa\ud920\ude51\uda30\udc90\udb86\uddfc\udbe3\udd9f\uc913\ud9b1\udca0\udb9c\udfcb\ud878\udc84\udaa4\ude82\ud863\udeb0\uda12\udcfd\udb18\udfaf\ud8c4\udcac\ud9ac\udc7d\udb59\ude12\ud958\udd04\uda62\uddee\ud9ec\udd9c\udb47\ude04\ud96e\ude8f\uda42\udd7b\ud8f0\ude14\udac4\udc5a\ud93d\udc95\ud863\udec7\udb8f\udc0f\udbb8\ude4f\u6bb9\ud9c2\udd15\ud935\udc33\ud901\udf25\ud82a\uddad\udb57\ude1d\uda7b\udfd9\ud87c\uded3\udbf5\udee5\udaa1\udcfb\udac4\udc86\ud829\udeef\ud972\udc0b\ud9e4\udc73\ud84e\udd12\ud82e\udef9\ufc98\u61b4\ud88a\ude33\ud850\udeab\udbea\udf23\ud9af\udf75\ud8fb\udca4\udb9e\udd83\uda86\ude57\udae5\udf6a\ud9aa\udce6\udbb6\uddf5\ud9c3\udd8b\uda4e\udf73\u811c\uda5f\udd12\udb43\udc49\ud94d\udf37", "\u21b3\u5da2\ua041\u9b7b\ud6d3\u35b3\ua19e\u8ffc", "\udbab\udc4d\uda24\uddb2\uda38\udefd\ud813\ude51\ud934\udcc8\ud984\udf3b\udbac\udd19\udae0\udfe2\udb32\udc34\uda98\uded9\ud701\ud832\udd43\ud95c\udd68\ud915\udcdb\udbe3\ude3a",
        -5, 7227, -172997994, -7545408895483590779L, 23441L, false, true, (char) 55631, (char) 586,
        Double.longBitsToDouble(0x3fed254cddd40623L), Double.longBitsToDouble(0x3fdc80fd35d1eee2L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 15, 5, "\udbe8\ude20\udaeb\ude5d\udaf5\udddd\ud8a0\udeab\ud8e7\ude84\ud97c\udc23\ud99a\udc16", "\u3d0b\ua8b2\u58ad\u9f28\uab45\u93d0\uaae0\u6cd7", "\ud9cb\udfdb\udb48\udf16\udbf5\udde2\uda1f\udf7e\udaf5\udd91\udab3\udd5b\ud973\udfb4\ud8b3\udcf4\udaa7\udcde\ud9a2\udc47\uda29\udd59\ud983\udd88\u41e9\u9839\udb80\ude37\ud8fd\udf0a\udafc\udc7b\ud846\uddae\uda6b\udf7f\udb40\udcfd\ud8cc\udcf9\udafa\udc8a",
        28, -513, 1960666572, -9017732881958176706L, 30464L, false, true, (char) 36092, (char) 28650,
        Double.longBitsToDouble(0x3fd5c8ea0cb73400L), Double.longBitsToDouble(0x3fd5735523166c70L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 0, 2, "\udbd4\udd55\ud9cd\udd15\udae0\udd67\u3cd4\ud9d4\ude3d\udb15\udde7\ud933\udcfb", "\u3d0b", "\uda60\ude5f\ud8dd\udea0\uda8a\ude26",
        29, -286, -1864882655, 2706766197435990327L, -48458L, true, false, (char) 23074, (char) 64248,
        Double.longBitsToDouble(0x3fef0756c3e82a65L), Double.longBitsToDouble(0x3fd74d888ed7a002L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 6, 15, "\uda08\udf30\ud838\ude99\ud969\udd38\uda30\udf89\ud8ed\udf37\ud997\udc23\udb4e\udc8c\uda98\udfb9\ud8bb\udc92\ud917\ude05\udacd\udf78\ud8a4\udffa\ud979\udc1a\uda9d\udf57\udb80\ude22\ud9db\udc27\udb3c\udcfc\ud898\ude68\ud980\ude86\ud996\udd79\udb96\udf6c\ud9af\ude06\udb74\udc27\udb23\udef8\u5ca7\udb0a\udc4f\ud9e5\udf52\udbad\ude9f\ud9bc\udd2e\ud84a\udd47\ud983\uddda\uda4b\udd56\u35bc\udb62\udc7e\udbbb\udde3\udbb2\udc76\udbbb\udd2e\uda36\ude99\uda93\udcad\udb57\udcab\ud882\udc7c\u3170\ud962\ude78\uda11\udeb1\udaa6\ude37\uda35\udeff\ud93c\udc3d\uda30\udc90\udb86\uddfc\udbe3\udd9f\uc913\ud9b1\udca0\udb9c\udfcb\ud878\udc84\udaa4\ude82\ud863\udeb0\udb64\udd06\udb18\udfaf\ud8c4\udcac\ud9ac\udc7d\udb59\ude12\ud958\udd04\uda62\uddee\udadc\udc74\ud9a7\udd79\udbf5\ude15\uda42\udd7b\uda00\udf9c\udac4\udc8d\ud93d\udc95\ud863\udec7\udb8f\udc0f\udbb8\ude4f\u6bb9\ud9c2\udd15\ud935\udc33\ud901\udf25\ud825\udda9\udb57\ude1d\uda7b\udfd9\udab6\udfb1\udbf5\udee5\udaa1\udcfb\udac4\udc86\ud829\udeef\ud854\udd3c\ud9e4\udc73\udb35\udf38\ud8d2\udc9f\ufc84\u61b4\ud88a\ude33\ud8e6\udc35\ud994\udd7c\udba7\udcba\ud8fb\udca4\udb9e\udd83\ud870\udcab\udae8\udf28\ud9aa\udce6\udbb6\uddf5\ud9c3\udd8b\uda4e\udf73\u811c\uda5f\udd12\udb43\udc49\ud94d\udf37", "\u6704\u5da2\ua041\u9b7b\ud6d3\u35b3\ua19e\u25f4", "\ud9d2\udf4e\uda24\uddb2\uda38\udefd\ud813\ude51\ud934\udcc8\ud984\udf3b\udbac\udd19\udae0\udfe2\udb32\udc34\uda98\uded9\ud701\ud832\udd43\ud95c\udcfd\ud915\udcdb\udbe3\ude3a\ud83f\uddcb\ud927\udf35\ud99a\uddfa\ud90e\udc32\uda3a\udf08\ud83f\udfa1\ud8e5\udf7e\uda5e\ude64",
        31, 4853, 102987684, 1140499032016634205L, 33563L, true, true, (char) 22096, (char) 54880,
        Double.longBitsToDouble(0x3fd99ac2f767cf48L), Double.longBitsToDouble(0x3fc773239571ea34L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 6, 15, "\uda08\udf30\ud838\ude99\ud969\udd38\uda30\udf89\ud8ed\udf37\ud997\udc23\udb4e\udc8c\uda98\udfb9\ud8bb\udc92\ud917\ude05\000\000\ud952\ude89\uda9d\udf57\udb80\ude22\ud9db\udc27\udb3c\udcfc\ud898\ude68\ud980\ude86\ud996\udd79\ud858\udf2c\ud8be\udc5b\ud85f\udf7e\ud91f\udd07\u5ca7\udb0a\udc4f\ud9e5\udf52\udbad\ude9f\ud9bc\udd2e\ud971\udff0\ud983\udd88\uda4b\udd56\u35bc\udb62\udc7e\udbbb\udde3\udbb2\udc76\udbbb\udd2e\uda36\ude99\uda93\udcad\udb57\udcab\ud882\udc7c\u3170\ud962\ude04\uda11\udeb1\udaa6\ude37\uda73\uddaa\uce3c\uda30\udc90\udb86\uddfc\udbe3\udd9f\uc913\ud9b1\udca0\udb9c\udfcb\ud878\udc84\uda09\udc74\udb59\udeab\uda12\udcfd\udb18\udfaf\ud8c4\udcac\ud9ac\udc7d\udb59\ude12\ud958\udd04$\ud9ec\udd82\udb47\ude04\ud96e\ude8f\uda42\udd7b\ud8f0\ude14\ud972\udeb2\ud913\udd09\ud863\udec7\udb8f\udc0f\udbb8\ude4f\u6bb9\udbf0\udd0c\ud935\udc33\ud8fd\udf7e\ud82a\uddad\udb57\ude1d\uda7b\udfd9\ud87c\uded3\ud861\udcd8\udaa1\udcfb\udac4\udc86\ud829\udeef\ud972\udc0b\ud9e4\udc73\ud84e\udd12\ud82e\udef9\u0a98\u61b4\ud88a\ude33\ud850\udeab\udbea\udf23\ud9af\udf75\ud8fb\udca4\u9be9\udaef\ude77\udae5\udf6a\ud9aa\udce6\udbb6\uddf5\ud9c3\udd8b\uda4e\udf73\u811c\uda5f\udd12\udb43\udc49", "\u1603", "\uda88\udf76\ud8cd\udffc\ud816\udf1d\ud98b\ude26\ud944\ude82\uda13\udd60\udae0\udeb6\ud86e\udd0d\udbab\udc4d\uda24\uddb2\uda38\udefd\ud813\ude51\ud934\udcc8\ud984\udf3b\udbac\udd19\udae0\udfe2\udb32\udc34\uda98\uded9\ud701\u009f\ud95c\udcbc\ud915\udcdb\udbe3\ude3a\ud8b3\udeca\ud927\udfb6\ud99a\uddfa\ud8bd\udc6a\uda3a\udf08\ud83f\udfa1\ud8e5\udf7e\udb4f\uddad\ud852\ude1d",
        53, 67684, 265543124, -616648142948447512L, -20951L, true, false, (char) 29377, (char) 24883,
        Double.longBitsToDouble(0x3fed107c2e2aa161L), Double.longBitsToDouble(0x3fd513a28202a686L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 6, 15, "\uda08\udf30\ud838\ude99\ud9f1\udcdc\uda03\udd89\ud8ed\udf37\ud997\udc23\udb4e\udc8c\uda98\udfb9\ud8bb\udc92\uda42\udedc\udae9\uddcd\ud8a4\udffa\ud979\udc1a\uda9d\udf57\udb80\ude22\ud9db\udc27\udb3c\udcfc\udbe5\uddfa\ud867\udef9\ud996\udd79\ud858\udf2c\ud8be\udc5b\ud85f\udf7e\ud91f\udd07\u5ca7\udb0a\udc4f\ud9e5\udf52\udbad\ude9f\ud9bc\udd2e\ud971\udff0\ud983\udd88\udb55\udd5b\u35bc\udb62\udc7e\udbbb\udde3\udbb2\udc76\udbbb\udd2e\uda36\ude99\uda93\udcad\udb57\udcab\ud882\udc7c\u3170\ud962\ude78\uda11\udeb1\udaa6\ude37\uda61\udcaa\udada\ude4e\uda30\udc90\udb86\udde5\udbe3\udd9f\uc913\ud9b1\udca0\udb9c\udfcb\ud878\udc84\udaa4\ude82\ud863\udeb0\uda12\udcfd\udb18\udfaf\ud942\udecb\ud9ac\udc7d\udb59\ude12\ud958\udd04\uda62\uddee\ud9ec\udd9c\udb47\ude04\ud96e\ude8f\uda48\udf7e\ud8f0\ude14\udac4\udc5a\ud916\udf76\ud863\udec7\udb8f\udc0f\udbb8\ude4f\u6bb9\ud9c2\udd15\ud935\udc33\ud901\udf25\ud82a\uddad\udb57\ude1d\uda7b\udfd9\ud87c\uded3\udbf5\udee5\udaa0\udc6a\udac4\udc86\ud829\udeef\ud972\udc0b\ud9e4\udc73\ud8d6\uddd6\ud93a\udfaf\ufc98\u621c\ud950\udcf6\ud86b\udd4a\udbea\udf23\ud9af\udf75\ud8fb\udca4\udb9e\udd83\uda13\udc9e\udb10\udc1f\udbcf\udffa\udbb6\uddd3\ud9c3\udd8b\uda4e\udf73\u811c\uda5f\udd12\udb43\udc49\uff20", "\u21b3", "\ud8cd\udffc\ud816\udf1d\ud98b\ude26\ud944\ude82\uda13\udd60\udae0\udeb6\ud86e\udd0d\ud914\udc4d\ud852\udc26\ud946\ude34\ud8e8\udd07\ud934\udcc8\ud996\udee4\udb5d\udc86\udae0\udfe2\udb32\udc34\uda98\uded9\ud701\ud832\udd43\ud95c\udd68\ud808\udd74\udbe3\ude3a\ud8b3\udf2a\ud927\udfb6\ud99a\uddfa\ud8bd\udc6a\udafc\udf09\ud83f\udfa1\ud8e5\udf7e\udb6f\udead\ud852\ude1d\uda5e\udfcd\udbb2\uddee",
        37, 46416, -213693720, -8905473632668639500L, 35386L, true, true, (char) 2112, (char) 15352,
        Double.longBitsToDouble(0x3fe94c29d88b0272L), Double.longBitsToDouble(0x3fda5bd687caff90L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 12, 10, "\udbe6\udc62\udba7\ude16\u15e0\udabb\ude92\ud79d\ud997\udc23\udb4e\udc8c\uda98\udfb9\ud8bb\udc92\ud8e7\uddba\udaf2\udca3\ud8a4\udffa\ud979\udc1a", "\u65d0", "\udae0\ude41\ud996\udcc1\udb86\udda3\ud8be\udc5b\ud8d3\udcd1",
        50, 18632, 1832428000, 7974011048015560564L, -48940L, true, true, (char) 24728, (char) 7862,
        Double.longBitsToDouble(0x3fe174b4e685bc15L), Double.longBitsToDouble(0x3fe388fb5684de74L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 10, "\udb49\ude31\ud996\udf63\udbc0\udfdb\u3cd4", "\u7ec7\uaf91\u755e\u3d8c\ua8b2\u58ad\u85b0\u33bb\u574a\u0d75\u6c4b\ua346\ubd64\u6ffa\u632f\u8a1f\ud3b1\u6177\u6e57\u1b53\u54d8\u35d5\u4512\ua0a7\uc4c2\u0c29\u6986\u09af\ucbc0\u22af\ua92c\ud61a\u3c58\ub8c4", "\uda15\udcb0\ud92f\ude53\ud9ec\uddf0\ud89d\udef3\ud979\udf3d\ud96c\udd81\ud82f\udcbe\ud888\udcda\u68f0\udb99\udc9c\udac3\udf01\ud908\udc0b",
        28, 97718, 1428508398, -3737244207771234895L, -16759L, true, false, (char) 22648, (char) 39627,
        Double.longBitsToDouble(0x3fe263cf56ee14afL), Double.longBitsToDouble(0x3fe61b45d31a02cfL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addAndOrUpdate|org.jfree.data.time.TimeSeries|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clear||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
