package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimeSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 0, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b", "\ud83f\udc63\udbe1\uded7\ud947\udd70\uda98\udcf6",
        56, 92972, -546996271, 8453481999496670220L, -69669L, false, false, (char) 8335, (char) 5815,
        Double.longBitsToDouble(0x3febe71b01b5bf4dL), Double.longBitsToDouble(0x3fe4239df5996f91L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 0, "\udacd\udf35\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590\ud9d0\udd2a\u7131", "\u7c3a\u64a5\u450f\u95ed\ubd77\u7d92\u9854\u7861\u912c\u1022\u1603\u07c8\ucd2e\ub0a0\uc746\ub4f2\u0ace\u1ae3", "\ud9f8\udf93\u44d7\u91f0\udb39\udeae\u2db3\udbd8\ude2d\uda96\udf1e\uda8b\ude94\ud990\udf9d\ud8d8\ude45\udbbd\uddb0\uda3d\udf94\ud92b\uddd5\udb63\udea1\udb34\udc7f\udb53\udf24\udb12\ude7b\ud87e\udf13\ud965\udd6d\u94b0\ud96d\udcde\ud885\udea4",
        14, 46233, -710063411, 6353912023628383436L, -56318L, false, true, (char) 11908, (char) 50774,
        Double.longBitsToDouble(0x3fedc36227425926L), Double.longBitsToDouble(0x3fe6512c3e1201c0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 0, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\ud9eb\udf77", "\u4db4\ucb20", "\ud83f\udc63\ud8fd\udee5",
        13, 53531, 969747411, -9093605527608000559L, -72340L, true, true, (char) 1833, (char) 51811,
        Double.longBitsToDouble(0x3fdbb5ed4e5def10L), Double.longBitsToDouble(0x3febe71b00e7acbfL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 0, "\udacd\udee1\ud83b\udf3c\udb1b\ude75\ud965\udfdb\u6590\ud9d0\udd2a\ud8ab\udf18\udb3f\udf78\ud98c\udf04\uda87\udf73\u1d8a\ud83f\udc63", "\u7d9b\u9854\u7861", "\udaa5\udcf0\ud9a9\udd8b\ud988\udfd4\uda97\uddd2\ud8f2\udd3b\ud869\udd7e\udbc0\udfab\ud880\udc87\ud895\udd17\udb2c\udc1d\ud9b4\udf6b\udba4\udded\ud93a\udff6",
        2, 26285, -1863295831, 7879554816836850143L, 96233L, true, false, (char) 4945, (char) 57316,
        Double.longBitsToDouble(0x3fc68fdfc926ea80L), Double.longBitsToDouble(0x3fa91db46b2e61a0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 11, 0, "\ud81e\udc48\udbc7\udc25\udb1b\ude75\ud965\udfdb", "\u7a2a\u0645\u9276\u551d\u55a6", "\ud947\udd70\ud90f\udea6",
        45, 80861, -546996242, 8453482579317255180L, -69669L, false, false, (char) 8335, (char) 42440,
        Double.longBitsToDouble(0x3fd52e360ea21e68L), Double.longBitsToDouble(0x3fe59cd9fa693c91L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 0, "\udacd\udee1\ud935\udfd5\udb1b\ude75\ud965\udfdb\u6590", "\u09f0", "\u1d8a\ud83f\udc63\udbe1\uded7\ud908\udf70\uda98\udcf6\u6f3b\ud821\ude84\ud849\udde5",
        10, 89340, -1213999733, 3051058478481449020L, 6059L, false, false, (char) 62761, (char) 21653,
        Double.longBitsToDouble(0x3fe7c64d7a190b22L), Double.longBitsToDouble(0x3fe407d1e3f23ab2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 6, 1, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb", "\u5079\u4db4\u9b6b\uca43\u64a5\u450f\u95ed\ubd77\u7d92\u9854\u7861\u912c\u1022\u1603\u75f6\ub2fa\u29c0\u86f4\u2038\u0b45\u1ae3\u6abf\u19ba\u218e\u8673\u0a07\uc6ba\u4ae7\uc003\u2d8d\ud374\ube47\u030a\u3559\u9844\u7381\u0c58\ube54", "\uda56\udd5e\udb07\udd0b\ud89a\udf1b\ud97b\udd08\udb60\udd7a\uda1d\udd7a\udb11\udcf0\u0a16\udbcf\udfb5",
        51, 96401, -948563908, -7570574558594718639L, -35575L, true, false, (char) 48849, (char) 11659,
        Double.longBitsToDouble(0x3fdb17aa886af9f6L), Double.longBitsToDouble(0x3fc48dbe4535a208L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 0, "\udab6\udfe1\ud842\ude3c\udb1b\ude75\ud965\udfdb\udba8\udf1c", "\u4db4\u9b6b\uca43\ua48d\u450f\u95ed\ubd77\u7dad\u9854\u7861\u912c\ub460\u78a8\u08e8\ua854\u8a9b\u4fb2\ucd40\ua15d\ud0f8\u739a\u3ab6\u31f8\u2808\uba03\ud734\u0c7e\u2144\u1457\u542e\u3c18", "\ud9c5\uddbc\udb1a\udcab\ud856\ude00\ud892\udcf3\ud83b\udc04\udb49\udd38\ud8e6\ude6e\udb04\udd09\ud8f6\udc42\udbe5\udc25\udae2\udd31\udb97\udde8\ud95f\udef3\uda7b\udef3\udaf5\udc5c\ud947\udcb4\ud802\udfd8\ud8ac\udeed\udb0a\udc54\ud95d\udf36\uda69\udf09\ud9ce\udc29\udb13\ude0f\udb3e\uddfb\udb34\udea2\u4ba5\ud97a\udf8d\uda45\uddb1\ud81d\udd4c\udbe8\uded2\ud9a9\udceb\udaf1\udf40\ud899\udfd9\uda87\udeb4\udbc5\udcf2\udb85\udd03\uda11\udd0b",
        7, 35220, 1561189109, 281532079492907250L, 88635L, true, true, (char) 43037, (char) 13507,
        Double.longBitsToDouble(0x3fed1873212b1ab8L), Double.longBitsToDouble(0x3fd3babd862ddbecL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 15, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b", "\udba3\udf14\udaf2\udfdc\u5bbc\ud96b\udd89",
        56, 93340, -849529646, 8453472773906918412L, -69669L, false, false, (char) 8335, (char) 27575,
        Double.longBitsToDouble(0x3feef1fb07b5bf4dL), Double.longBitsToDouble(0x3fc08e77d66571acL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 15, 0, "\udacd\udee1\ud842\ude3c\uda8d\udd2d\ud965\udfdb\u6590", "\u4db4\u9b6b", "\ud83f\udc63\udbe1\uded7\ud947\udd70\uda98\udcf6",
        56, 92972, -546996271, 8453481999496670220L, -52234L, true, true, (char) 4196, (char) 5815,
        Double.longBitsToDouble(0x3febe71b01b5bf4dL), Double.longBitsToDouble(0x3fe0339df5996f91L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 10, 0, "\udacd\udee1\udb0c\ude66\udb1b\ude75\ud965\udfdb\u6590", "\uc17b\u2a88", "\ud800\udfe3\udbb0\udf58\u00ed\udabf\udd3e",
        56, 2404, -547028992, 8453481999245011980L, -50405L, false, true, (char) 58208, (char) 8374,
        Double.longBitsToDouble(0x3fe4239df5996f91L), Double.longBitsToDouble(0x3fd507dff1f4b90cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 7, 16, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b", "\ud83f\udc44\udbe1\uded7\ud947\udd70\uda98\udcf6",
        56, 92972, -1822064687, -7884399549527593972L, -69669L, false, false, (char) 8335, (char) 53815,
        Double.longBitsToDouble(0x3fc5abb3c6d6fcf0L), Double.longBitsToDouble(0x3feda2e5f5996f91L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 4, 7, "\ud856\udd26\udb73\udc54\ud9ac\udfc4\ud912\udf07\udb5c\uddc3", "\u83a7\u9ce9\ub5ea\u1116\ud532\ucca5\u6094\u8d33\u210e\u9336\ucc4d\u802d\u1603\u918f\u3391\uc0ba\u4fb2\u76bc", "\uda16\udf55\ud913\udee6\udbba\ude4b\ud8e7\udeab\uda0b\udc8d\ud99c\udc8d\udb55\udda5\ud892\udfaf\udba3\udc6b\udab8\udece\ud804\ude21\ud94f\udcd8\ud90a\udc33\udb22\udff2\ua066\uda5d\ude9f\u1c92",
        42, 97109, 714110557, -661712492068592122L, -9274L, true, true, (char) 9787, (char) 62360,
        Double.longBitsToDouble(0x3fed3cb72d885cf0L), Double.longBitsToDouble(0x3fe3614a3ffb97aeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 3, 0, "m", "\ub4b9\u2668\u59fd", "\udbc2\ude4f",
        54, 54856, -2135032861, -5688675803355350291L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f88ea0162c3ca00L), Double.longBitsToDouble(0x3fd85b7a307854aeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 0, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b", "\ud83f\udc63\udbe1\uded7\ud947\udd70\uda98\udcf6",
        38, 92948, -546996271, 8453481999496670220L, -69669L, false, false, (char) 8335, (char) 5815,
        Double.longBitsToDouble(0x3febe71b01b5bf4dL), Double.longBitsToDouble(0x3fe4239df5996f91L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 4, "\ud839\udd0c\ud842\ude3c\udb1b\ude75\ud965\udfdb\udb86\udec5", "\uce4a\u181f\ua413", "\udb25\udeb9",
        57, 23563, -364181798, 9095345130940817425L, -72340L, true, false, (char) 52465, (char) 20459,
        Double.longBitsToDouble(0x3fdbb5ed41d35064L), Double.longBitsToDouble(0x3fe99a6641228d55L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 0, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b\uca43\u64a5\u450f\u95ed\ubd77", "\ud821\ude84\ud8e4\udff3\udb89\udc00\udaa5\udcf0",
        -3, 45909, 1590992956, -610024741085896914L, -89306L, true, false, (char) 17516, (char) 50763,
        Double.longBitsToDouble(0x3feceb25843ebb91L), Double.longBitsToDouble(0x3fe66209c7a43f9dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 3, 0, "\udaaa\ude74\ud842\ude3c\udb1b\ude75\ud965\udfdb\u00de", "\u4db4", "\u1d8a\udbe7\udc57\udbb0\udf58\ud947\udd70\uda98\udcf6\u6f3b\ud821\ude84\ud849\udde5",
        10, 89340, -1213999733, 571244585020L, -74987L, false, false, (char) 62761, (char) 6633,
        Double.longBitsToDouble(0x3fe0887c0da04839L), Double.longBitsToDouble(0x3fc0579163bdf9ccL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 2, 13, "\udadb\udee1\ud842\ude3c\ud832\udce9\ud804\udd1d\u6590\ud9d0\udd2a\udb48\ude66\udab1\udef4\udb93\udc53\udae8\udc5b\udbf4\udc19", "\ubd77\u4463", "\udb57\udcaf\ud9b6\udca0\ud8e0\udce2\ud92e\udd47\udbab\ude02\ud9ce\udf69\ud8f2\udd3b\ud93f\udc28\udb36\udd6e\ud782\ud936\udf88\uda7c\udf80\ud9c1\udd59\udbc7\udcd1\ud999\ude25\ud9a9\udff0\ud883\udea6\ud9cc\ude1f\udb8f\udc5c\uda78\udde9\ud8a3\udd0f\udb94\udfdf\udbab\udc53",
        47, 26520, -955971876, -6139780504039006104L, -84993L, false, true, (char) 45820, (char) 37171,
        Double.longBitsToDouble(0x3fe6aef74f8d237dL), Double.longBitsToDouble(0x3fc6d6c51bd0b36cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 16, 14, 8, "\ud9a5\udffb\ud8aa\ude6e\ud8e5\udd67\u2e6a\ud94b\udfa2\ud9b6\udf67\uda91\udcaa\ud87e\udf34\ud9a5\ude5b\ud828\ude45\ud99f\udecc", "\u965b\u1227\u11bc\u2ff2", "\udaa5\udcf0\uda89\udd94\uf0eb\ud869\udec0\ud95a\udd0c\ud8fe\udd40\ud871\udc50\ud928\udda0\udbb5\udec8\ud94a\udc92\u96ef\u422d\ud843\udcb0\ud865\udf20\ud905\udf76\ud992\udfb9\ud9a7\udf42\ud869\udd70",
        0, 53608, 1620443432, 2817708586037984180L, -81786L, true, false, (char) 2100, (char) 10767,
        Double.longBitsToDouble(0x3fc7fba5cb10438cL), Double.longBitsToDouble(0x3fc3c89ec9fbcab4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 15, "\000\ud842\ude3c\udb1b\ude75\000\u6590", "\u43c4\000", "",
        -5, -1000, 715454976, 6436835408374213587L, 63887L, true, true, (char) 57692, (char) 58546,
        Double.longBitsToDouble(0x3fd85b7a307854aeL), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 2, 12, "\uda10\udc8a\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b", "\udaad\udf60\ud9f3\udee0\ud947\udd70\uda98\udcf6\ud936\udfe2\ud8dc\udd64\ud82d\udffa\udb89\udca5\udb25\udcf0\udb90\udfdd\udb7f\ude95\ud843\udc4f\ud8c1\udfbb\udb2c\udfb5\udbc0\udfab\ud880\udc87\ud895\udd17\ud967\udddb\ud8c2\uddce\uda03\udcdb\ud9ad\udcaf\udb0a\udecc\udb1c\uddb2\udaad\udd01\uda3b\ude2a\ud9bd\udce9\ud9f1\udeaa\ud95f\udcb6\u303b\udbd8\udc30\udbb0\udc2b\ud8c5\ude69\ud912\udf56\ud881\udfd6\udafb\udea2\udb48\udc27\udad1\udd65\ud97f\udf84\ud994\udc30\uda44\udd87\udad6\udd76\udbc8\udd00\udb19\udfd1\udb01\udedc\udb86\udd06\udb61\udf5f\ud83e\udc3e\uda9a\ude7d\ud915\udeb0\udaac\udd91\ud892\udef4\ud82d\udfe3\ud841\udeeb\ud811\udcde\ud8cc\udcbf\uda75\udc17\ud8db\udfe9\uda0c\udc29\ud8dd\udf88\uda9c\udde9\ud8e7\udf06\udb54\udf3a\ud846\udd3c\ud917\ude46\ud962\udf21\ud95e\udd05\ud9af\udef2\udb71\udcba\ud8cf\uddeb\ud83e\udd10",
        10, 59638, 525200990, 3310502097340086954L, 4016L, true, true, (char) 23372, (char) 2918,
        Double.longBitsToDouble(0x3fd898bc5ee391eeL), Double.longBitsToDouble(0x3fdfa915f50cc894L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u8614\ud722\u2668\u59fd\u5079\u4db4", "\000\udba8\udc74\udbe1\uded7\ud947\udd70\uda98\udcf6\ud824\udfdf\u0500\ud849\udd14",
        52, 89340, 54667, 0L, -100000L, false, true, (char) 8451, (char) 8770,
        Double.longBitsToDouble(0x3fd996f913f4a0eaL), Double.longBitsToDouble(0x3fc55422821a5310L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 9, 16, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\ud91e\udf35", "\u4db4", "\udad0\udf6f\udb22\udddd\udbd9\udfb7\ud947\udd70\uda98\udcf6\u6f3b\udb7c\udcb0\ud849\udde5",
        10, 89340, -1213999733, 3051058478481449020L, -92018L, false, true, (char) 11011, (char) 39290,
        Double.longBitsToDouble(0x3fd997ec1ea2e15eL), Double.longBitsToDouble(0x3feaa262f39aa485L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 0, "\udab2\udd84\u0140\udb1b\ude75\ud965\udfdb\udbe4\ude8f", "\u4db4\u9b6b", "\udaee\ude63\udabe\udd39\ud947\udd70\ud919\udc78",
        48, 46548, 821480466, 1303541094489287878L, -69669L, false, false, (char) 8335, (char) 5815,
        Double.longBitsToDouble(0x3fb82adc8dadff08L), Double.longBitsToDouble(0x3fe4239df213b679L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 0, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b", "\ud83f\udc63\udbe1\uded7\ud947\udd70\uda98\udcf6",
        56, 92972, -546996271, 8453481999496670220L, -69669L, false, false, (char) 8335, (char) 5815,
        Double.longBitsToDouble(0x3febe71b01b5bf4dL), Double.longBitsToDouble(0x3fe4239df5996f91L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 0, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb\u6590", "\u4db4\u9b6b", "\ud83f\udc63",
        56, 71213, 1498692531, 4165033413508400628L, 6059L, false, false, (char) 62761, (char) 33468,
        Double.longBitsToDouble(0x3fb63088790dbc08L), Double.longBitsToDouble(0x3fdd83f0e0d6c17cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 12, 0, 0, "\udacd\udee1\ud825\udd3c\udb1b\ude75\ud965\udfdb\u6590", "\u1930\u15bc\u99e6\ud7af\u451a\u95ed", "\u6f3b\ud851\ude18\ud849\udde5\udb89\udc00\udaa5\udcf0\ud92e\udd47\udb21\udc03\uda97\uddd2\ud8f2\udd3b\ud869\udd7e\ud910\udd71",
        18, 85372, 368477593, 6894796441368607033L, 2726L, false, false, (char) 18941, (char) 4264,
        Double.longBitsToDouble(0x3fdadfa8370a32a4L), Double.longBitsToDouble(0x3fed9be4f1a50c9bL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 15, "\udad1\udd89\udb43\udd9b\udb46\udfea\ud945\ude69\u6590\ud9d0\udd2a\ud888\udfce\udb4a\ude9f\u4af8\ud9a8\udc15\u1d8a\ud83f\udc63\udbe1\uded7\udaf4\udf52\uda99\udca9\u6f3b\ud821\ude84\ud86e\udff9\udbc0\udc43\udaa5\udd42\ud92e\udd47\uda6e\ude8a\uda97\ude80\ud829\udc57\udb89\udf9d\udaad\uddd2\ud880\udc87\ud8bc\udda8\uda96\udeb1\uda6f\udc18\udb03\udfa3\uda59\udc88\ud9c3\uddb3\udb08\udd54\uda51\udd48\ud8d2\ude22\ud8fa\udd34", "\u4537\ubedf\u4eb6\u744b\u52a5\u493d\u5cef\ub2eb\u1796\u0a55\u482e", "\uda4f\ude1c\ud9ce\uddee\ud812\udcda\ud942\uddb5",
        38, 41186, 7481112, 1881980403248017888L, 68991L, true, false, (char) 33616, (char) 47379,
        Double.longBitsToDouble(0x3fec34f5b89a2903L), Double.longBitsToDouble(0x3fc9e147201c3e98L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 12, 13, 8, "\udacd\ude77\ud842\ude3c\udb67\udf3b\ud943\udddb\u6590\ud9d0\udd2a\udbd0\udc3e\udaca\udc60\ud98e\uddf5\udb1b\udfc0\u1dc8\ud83f\udc63\udbe1\uded7\uda57\udef8\uda98\udc66", "\u9dbb\u3171\u83c6\u07c8\u847d\ub0a0", "\udbc0\udfab\ud880\udc87",
        42, 89889, 137697319, -807972105047696056L, -36564L, false, true, (char) 16837, (char) 62132,
        Double.longBitsToDouble(0x3fb6be6fc13f9ad8L), Double.longBitsToDouble(0x3fdc21617dae1cc2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 11, 0, "\ud81e\udc48\udb47\udc25\udb1b\ude75h", "", "",
        48, 99079, -1389762604, -9169896314097515649L, -58861L, false, true, (char) 25212, (char) 32444,
        Double.longBitsToDouble(0x3fd9edf65818eaa0L), Double.longBitsToDouble(0x3fd8b0f2830b6f46L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 0, "\ud81e\udc48\udbc7\udc25\ud895\ude72\ud965\udfdb", "\u7a2a\u0645\u1a54\u551d\u55a6\u23fc", "\ud911\udd89",
        -2, 80861, -546996242, 8453482579317255180L, -69669L, false, false, (char) 32443, (char) 36679,
        Double.longBitsToDouble(0x3fd52e360ea21e68L), Double.longBitsToDouble(0x3fe59cd9fa693c91L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 11, 9, "\ue248", "", "\udac8\udd35\000",
        30, 4669, -1854461921, 11795369629187043L, 97907L, true, false, (char) 56724, (char) 25212,
        Double.longBitsToDouble(0x3fcddfd9b67b7c00L), Double.longBitsToDouble(0x3f88ea0162c3ca00L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 11, 0, "\ud81e\udc48", "\ud722", "",
        -5, 66856, 899410669, -7964853303762098220L, -100000L, false, false, (char) 0, (char) 20224,
        Double.longBitsToDouble(0x3fd855cf7001fd9aL), Double.longBitsToDouble(0x3fc3dbeca0000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udacd\udee1\ud935\udfd5\udb1b\ude75\ud965\udfdb\udbd2\udceb", "\u09f0", "\u1d8a\ud83f\udc63\udbb0\udf58\ud908\udf70\u3bb3\udbb8\udf5b\ud821\ude84\ud849\udde5",
        23, -1000, -1214054400, 3026570155507621948L, -100000L, false, true, (char) 77, (char) 8770,
        Double.longBitsToDouble(0x3fd996f910c1686aL), Double.longBitsToDouble(0x3fe7c64d7a190b22L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 6, 1, "\udacd\udee1\ud842\ude3c\udb1b\ude75\ud965\udfdb", "\u5079\u4db4\u9b6b\uca43\u64a5\u450f\u95ed\ubd77\u7d92\u9854\u780e\u9100\u1022\uc7a6\u760a\ub2fa\u29c0\u86f4\u2038\u0b45\u1ae3\u6abf\u19ba\u218e\u8673\u0a07\uc6ba\u4ae7\uc003\u2d8d\u9469\u5e9c\u030a\u3559\u9844\u7381\u0c58\ube54", "\uda56\udd5e\udb07\udd0b\ud89a\udf1b\ud97b\udd08\udb60\udd7a\uda1d\udd7a\udb11\udcf0\u0a16\udbcf\udfb5",
        51, 96401, -948563908, -7570574558594718639L, -35575L, true, false, (char) 48849, (char) 11659,
        Double.longBitsToDouble(0x3fdb17aa886af9f6L), Double.longBitsToDouble(0x3fc48dbe4535a208L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 0, "", "\u8614", "",
        32, 2557, 1952596932, -418286877085412149L, 30019L, true, true, (char) 44026, (char) 26226,
        Double.longBitsToDouble(0x3fee9acaa5f439cdL), Double.longBitsToDouble(0x3fee8c0e6d17df65L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 13, 13, 16, "\ud935\udccd\ud8d7\udf9b\udb1b\ude75\ud965\udfdb\u6590\ud918\udd2e\ud8d8\udc4e", "\uca43", "\udaef\uddbb\uda3f\udf2a\ufe90\ue86b\uda65\ude85\ud816\udda8",
        7, 89340, -1213999733, 3051058478481449020L, 71399L, false, true, (char) 145, (char) 56950,
        Double.longBitsToDouble(0x3fe88abcbde24745L), Double.longBitsToDouble(0x3fea24192ea83eebL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 0, "", "", "\000",
        -5, -1000, 196, -418286877085412149L, 30019L, true, true, (char) 44026, (char) 10916,
        Double.longBitsToDouble(0x3fee9ac805f439cdL), Double.longBitsToDouble(0x3fee8c0e6d17df65L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 12, 12, 0, "\udbfa\udc19\udace\udf32\ud970\udfdc\ud945\ude5c\u6590", "\u3005\ua6a1", "\ud83f\udc63\udbe1\uded7\ud947\udd70\uda98\udcf6\u6f3b\ud821\ude84\ud849\udde5",
        10, 41492, 1586988409, 1321877597148166417L, -54478L, true, true, (char) 27420, (char) 8644,
        Double.longBitsToDouble(0x3fd996f917d2f72eL), Double.longBitsToDouble(0x3fe9960a8bb895adL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 16, 13, "\udaaa\ude74\ud842\ude3c\udb1b\ude75\ud973\udca1\uda3a\udf30\000\ud8c6\udc02\ud8b2\udc38\ud98e\uddf5\uda87\udf73\ud903\udfc7\udb99\ude51\udbb0\udf58\ud82d\udd43\ud9d5\udce6\ud928\udf12\ud8af\udee4\ud849\udd35\udb89\udc00\udaa5\udcf0\ud92e\udd47\u0085\uda02\udc48\000\ud9a0\udd6c\u876e\udbe8\udc7b\ud895\udd17\ud928\udd7c\udbac\udc98\uda59\ude52\ud92c\udda6", "\u9780\u035e\uc130\u92b3\u5d24\u071c\ub81a\u8e05\u45f2\u9ac3", "\ud81c\udf9c\udb08\udca4\udbaa\udc41\ud8f5\ude70\udb69\ude33\uda2b\udf82\udb70\uddef",
        -1, 77614, 740881406, -4126013755314117366L, 73969L, true, false, (char) 46530, (char) 28755,
        Double.longBitsToDouble(0x3fe506f9aa3478f9L), Double.longBitsToDouble(0x3fe3fcd85ab1e85cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 16, 7, "\udadb\udee1\ud842\ude3c\ud832\udce9\ud804\udd1d\u6590\ud9d0\udd2a\udb48\ude66\udab1\udef4\uda96\udc15\udafb\udeb3", "\u8006\ub874\u1623\u58cc\u8030\uc7e0", "\udaf4\udd4a\udbab\ude02\ud9ce\udf69\ud8f2\udd3b",
        33, -114, 1652724420, -3585798097061602590L, 93342L, false, false, (char) 38947, (char) 61293,
        Double.longBitsToDouble(0x3fd8e239b31a9b08L), Double.longBitsToDouble(0x3fe5497db9a0f350L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 14, 15, "\000\ud842\ude3c\udb1b\ude75\udb95\udc56\udbcb\ude10", "\u78cd\u1648", "",
        -5, -1000, 715454976, -3493601773076098604L, 63887L, true, true, (char) 57692, (char) 58546,
        Double.longBitsToDouble(0x3fe21dbd1fdd830dL), Double.longBitsToDouble(0x3ec2fc0000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 12, 16, 13, "\udaaa\ude74\ud842\ude3c\udb1b\ude75\ud973\udca1\uda3a\udf30\000\ud8c6\udc02\ud8b2\udc38\ud98e\uddf5\uda87\udf73\ud903\udfc7\udb99\ude51\udbb0\udf58\ud82d\udd43\ud9d5\udce6\ud928\udf12\ud8af\udee4\ud849\udd35\udb89\udc00\udaa5\udcf0\ud92e\udd47\u0085\uda02\udc48m\ud9a0\udd6c\u876e\udbe8\udc7b\ud895\udd17\ud928\udd7c\udbac\udc98\udafb\udce4\udba7\udffd", "\u9780\u035e\uc130\u92b3\u5d24\u071c\ub81a\u8e05\u45f2\u9ac3\u5f18\ub2e1\u699e\u6328\u89be\u08b1\u09eb\ucd0f\u5a9e\ucfd9\u2066\u97f1\u807c\ua368\u0c68\uc055\u447c\u4243\u5569\uaa01\uc28c\uca7a\u8a12\u7a00\u27ff\uc0ce\u0dd9\ubb2f\ua765\u0b79\u673b\u800a\u49ab\uc74b\u7424\ucd94\u2d8a\u414c\u8a00\u380e\u3344\u9249\u6746\u4fce\ua72e\u41c6\u2dd2\u9224\uc831\u2596\uc4e1\u5bbc\u7683\u4dc4\u01a6\u6428\ub3b2\u9b11\ua621\u7237\u556f\ua4c4\ubdc2\ud10b\ubede\u4e82\ub649\u02f8\u12cc\u17df\u6dd4\ucfa3\ubec1\u833a\ud620\u5f23", "\uda84\udcce\udbef\udd4a\ud910\udcac\ud84d\uded4\ud862\udefb\udac9\udcbd\ud849\udc51\ud939\udc57\udac8\udff8\ud8d6\udc70\ud8ee\udf99\ud9d1\udd50\ud97f\udec3\uda36\udfa0\uda9c\uddc1\ud986\udc31\uda3c\udfdc\ud836\udeae\udaa9\udd3a\udabe\udf63\ud9b6\udd9e\ud978\udeb8\udb46\udc8e\udb1c\udc4b\ud982\udce8\udb1e\udcb1\uda1e\udd3a\uac20\udb6c\udca2",
        6, 99281, 2096475657, -1525704206708562692L, -52871L, true, true, (char) 7269, (char) 11055,
        Double.longBitsToDouble(0x3fdd4af1aadbcba2L), Double.longBitsToDouble(0x3fc0a615a8ae5aecL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addAndOrUpdate|org.jfree.data.time.TimeSeries|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clear||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
