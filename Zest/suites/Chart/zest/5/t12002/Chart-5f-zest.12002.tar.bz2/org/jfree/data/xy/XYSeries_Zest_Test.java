package org.jfree.data.xy;
import org.junit.Test;
import static org.junit.Assert.*;
public class XYSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\udb79\udf3a\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322249664092618L, 87669L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\udb79\udf3a\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 60057, -918333369, 7516322249664092618L, 87669L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 2, 1, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6525\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud87f\ude70\udb79\udf3a\uda20\udf44\uda91\udd28\ud9ba\udebf\ud913\udf65\uda18\udeaa\ud898\udc36\ud85e\udd82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        49, 48734, -920448690, 7516322249664092618L, 87669L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10adf3460L), Double.longBitsToDouble(0x3fed5213bc41f2e1L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 14, 16, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udb4d\udd50\udb24\udec3", "\u6543\u4294\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9fe\udc0e\ud848\udf35\udb79\udf3a\uda20\udf44\uda91\udd28\udab1\ude5a\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\ud945\udc20\udab5\udc5c\u25bc\udaf1\udef6\ud828\ude7c",
        34, 74393, 454482820, -5381987083125007993L, 22133L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6fe61cL), Double.longBitsToDouble(0x3fe582ebbcefb3e1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\ud995\ude5c\000\000\000\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\u00b7\ud9a9\ude61\ud86a\udf70\udb72\udd78\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322249664092618L, -34464L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub771\udb02\udf6f\ud977\udf9a\udb2b\udf85", "\u339a\u1db2\ub923\uce53\u3851\u1b36\u917b", "\uda8d\udc42\ud8ee\ude1e\uda46\udf90\ud93a\udc2c\ud90f\udd10\ud8d2\udee8\ud9e0\udfd0\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\ud89c\udf6b\ud814\udc20\uda91\uddd0",
        -2, 65197, 1908913142, -7387954798480935858L, -24449L, false, false, (char) 52922, (char) 16628,
        Double.longBitsToDouble(0x3fe8add2be9171b5L), Double.longBitsToDouble(0x3fb1da593a1e4a18L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ud89a\ude9f\udb02\udf6f\udaff\udd75\udb30\udf38\udb01\ude8c\udaf2\uddd7\ud98b\udc81\udbe2\udca0\u9ec9\ud921\udf15\ud9a2\udde4\uda3a\udcf1\u3b41\udb4d\udd50\udb16\ude23", "\u6543\ud53b\u421e\u2b0e\ubc8a\u2db5\ud53f\u08eb\u1823\u7e8a\u735d\u220f\u86e2\u1c73\ubec0\u4ad0\u5225\u4fe4\u102a\u0f7b\u2ce8\u8dd7\ub754\ua320\u1103\u038e\ud2b3\u4c91\u3b97\u52b9\ua06c\ub062\ud58f\u388b\u736e\ud3cb\uc509\u9b23\ucf3f\u76c7", "\ud8c3\udea9\ud89a\udced\ud848\udcf3\ud9d0\udc0e\ud801\ude44\uda40\udf96\ud82b\ude72\udaaf\udf79\udbe8\udd21\uda37\ude7c\udbee\uddf4\ud802\udc9c\udbdf\uddee\ud977\uded9\udb7d\udd89\ud85a\udee4\uda10\udede",
        -3, 95875, 26349227, 2199283942369709102L, 79172L, true, false, (char) 46456, (char) 52629,
        Double.longBitsToDouble(0x3fe6f0a8488ad8a9L), Double.longBitsToDouble(0x3feae8b60dca759dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 1, 1, 5, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\ud8fa\udf0a\ud977\udf8c\ud899\udf1c\uda73\udf6f\ud951\udc64\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb47\ude0e", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\udaf1\udf18\uda11\udd87\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\udbf6\ude79\udbcf\udc8c\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322246869572042L, -14483L, true, true, (char) 21833, (char) 31136,
        Double.longBitsToDouble(0x3fbcc7bcd6af76e8L), Double.longBitsToDouble(0x3fd6adf10a6e7a10L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 2, 12, "\ud827\udfc6\uda66\udefe\udae2\uddc4\udaac\uddac\ud8ba\udcf3\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85", "\u6ba6\u7a34\u5562\u05ad\u38ef\ub236\u917b\u1653\u11ff\u742a\u2347\u46ca\u677a\u7dd3", "\ud976\udd75\udb78\udf19",
        8, 9579, -1741317746, 1800065193439127857L, -56232L, true, true, (char) 11152, (char) 50440,
        Double.longBitsToDouble(0x3fc805edd83bef98L), Double.longBitsToDouble(0x3feab152390ec8e5L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\ud815\uddd5\ud873\udcb6\u2ab3\udacc\ude78\ud892\udc3e\udb6d\ude52\udb11\udf61\u3b41\udb4d\udd50\udb24\udec3", "\u6543\u10cb\u17b7", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\udac6\udda7\udb95\udeab\uda20\udf44\uda91\udd28\udb3e\udc01\ud83b\uddbb\uda18\udeaa\ud898\udc36\ud873\udc82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322249664092618L, -30364L, true, false, (char) 31866, (char) 35391,
        Double.longBitsToDouble(0x3fe582ebbcd2f2e1L), Double.longBitsToDouble(0x3fe7496d3c3ce21dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 7, 3, 3, "\ud827\udfc6\uda66\udefe", "\uc29b\u0742\ua560\u808d\ua2b6\u8b20\u58b2\u1781\ud515\u3c05\ub923\uce53\u83b8\ubcee\u2ab4\u1653\u11ff\u4d65\u4347\u6543\ud53b\u291c\u24a1\ubc8a\u2db5\ubd77\u131c\uc818", "\ud88a\ude78\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud8cf\uddb1\ud872\udfd1\udb5c\udc8b\ud881\udd3f\u25bc\udb18\udd89\ud9fb\ude63\ud9bc\ude67\u04c7\ud8a3\udd0d\udaa3\udd68\ud9ff\ude4d\udb7a\ude3f\udab5\udd04\uda31\udc43\udab5\udf81\udbbb\ude98\ud9bf\udf70\ud84a\udce4\udb1a\udd02\udb5d\ude12\ud822\uddea\ud948\udf44\u49a8\ud93d\udcc4\ud937\ude5c\udb0b\udfe4\uda7d\uddfa\ud905\udeb3\ud9b8\udf16\ud918\udf6f\uda1f\udfd7\ud8c6\ude9d\ud82b\udef5\uda83\udcd8\udb80\udef0\udbeb\ude28\ud9ca\udfb6\ud844\ude48\udb57\udfcd\ud8fe\udc32\udb89\udf7a\ud927\ude39\ud816\udc73\ud9b0\uddd1\udbd0\ude32\uda1a\udd5e\uda36\udec2\ud8c9\udf95\ud9f4\udd4a\uda23\udf73\udb08\udfbd\ud971\udc4f",
        33, 63271, -1189700864, -951764813970601986L, 87235L, false, false, (char) 32547, (char) 10249,
        Double.longBitsToDouble(0x3fd33028a546dab4L), Double.longBitsToDouble(0x3fe0a5fd33624a84L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 7, "\ud827\udfc6", "\u3ca5", "\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud849\udf41",
        20, 54375, 1649404190, 1140428583144054938L, -79822L, true, true, (char) 30999, (char) 22130,
        Double.longBitsToDouble(0x3fe663ce43ade3b4L), Double.longBitsToDouble(0x3fed362482045be3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\uda01\udf44\u2aed\udacc\ude78\ud83b\udf64\ud914\udec3\udb11\udf8e\u3b41\udb4d\udd50\udbcf\ude39", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\udb79\udf3a\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -1969268665, 7516442775036352970L, 87669L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf1046e7a10L), Double.longBitsToDouble(0x3fe90866bcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 1, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udab5\udc51\uf99c\ud9e8\udf42\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\udb79\udf3a\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udaf0\udf93\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 57076, -918333218, 7516322249664092618L, 87669L, false, false, (char) 45926, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 10, 3, "\ueafd", "\u3c6d\uc29b\u14a3\u69d7", "\udb1d\udf85\035\000\000\000\000\000\ud941\ude02\u00c9",
        -5, -1000, 0, 0L, -23708L, true, true, (char) 40239, (char) 6420,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e470a60d4000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 5, 12, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f", "\u3fb2\u1781\u97c0\u1db2\ub923\u9953\u4351\ucf3c\u3a9d\u1653\u0a12\u4d86\u0219\u6543\ud53b\u109b\u26d3\u4d65\u1c78\uc0ec\u08eb", "\udb79\udf3a\udb23\udfd6\uda91\udd28\ud9ba\udebf\ud83b\ude24\ud885\ude2d\ud898\udc57\ud873\udc82",
        33, 3293, 1536880726, -3865194451536742761L, -79887L, true, false, (char) 8327, (char) 16921,
        Double.longBitsToDouble(0x3fecfa64bbd6a4d9L), Double.longBitsToDouble(0x3fbde314175fe4b8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 7, "\udb95\ude81\uda7c\udea6\udace\uddb7\ud9e3\udf07\ud8ba\udd16\udb69\uddf4\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud8b5\udc99\udaaf\udfa2\ud98b\udc81\ud98f\uddaf\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3\uda8d\udc42\udad3\ude19\ud850\udd21\uda1c\ude2d\udb7f\udf69\ud8d2\udee8\ud9e0\udfd0\uc8b5\uda05\udeec\ud951\udc4d\ud9a9\udf43\ud836\udf16\udbaf\udc17\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud888\ude37\ud9f3\udc7e\udb5c\udd1f\ud9c0\udf54\u25bc\udaf1\udef6\ud828\ude7c\ud9bc\uddc8\u04c7\ud8a3\udd0d\udaa3\udd68\ud9ff\ude4d", "\u60da\u1945\u8c1f", "\ud836\udc84\ud96b\udd87\ud8d1\udc4b\udacd\udc27\ud908\udda1\ud8ee\udc8b\ud8c4\udceb\udac7\udee6\udbd2\udfb3\udb35\udd98\udb89\ude2b\udbfb\udcb8\ud943\udd10\ud9cf\udf82\udbe1\udc8f\udac7\udf38\ud87a\udfa4\ud8a2\udf66\uda4d\udd6f\ud3d9\ud8f5\udc9a\ud80d\udc4b\ud803\udd44\ud974\udee5\ud8fd\udc00\uda5c\udde6\ud819\udcd6",
        50, 54437, -176562147, -3603028335404062274L, -34308L, true, true, (char) 28603, (char) 33816,
        Double.longBitsToDouble(0x3fe094c3ec487b81L), Double.longBitsToDouble(0x3fd25db0b0b3122eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 5, 3, 3, "\ud827\udfc6\uda2c\udf20\udb67\udfbe\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud92f\udc99\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\udad2\udf24",
        32, 17809, 526742351, -270028602644089971L, -53343L, false, false, (char) 31221, (char) 20876,
        Double.longBitsToDouble(0x3fb5995b5102dcd0L), Double.longBitsToDouble(0x3fe4be52e315ba57L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 10, 5, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ud8cf\udff0\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\uda99\udca4\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\uda72\udf23\udbca\udf9b", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\ud8eb\udd23\uda28\udc89\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322249664092618L, -30253L, true, false, (char) 31866, (char) 35391,
        Double.longBitsToDouble(0x3fe582ebbcd2f2e1L), Double.longBitsToDouble(0x3fec4bc1a88b80daL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 14, 3, 9, "\ud837\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u5fa2\u8a37\u3e58", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\uda27\udf31\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322249664092618L, 87669L, false, false, (char) 12134, (char) 42076,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 11, 12, 10, "\ud827\udfca\uda66\udefe\udae2\uddd4", "\u0742\ua560", "\udb2b\udf85\ud983\udf4d",
        17, 11055, 1253402198, -4691653148170865123L, -6754L, true, true, (char) 60438, (char) 33760,
        Double.longBitsToDouble(0x3fe663ce43ade3b4L), Double.longBitsToDouble(0x3fed362482045be3L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 12, 9, 11, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\uda10\udf42\ud88d\udd72\uf26d\ud83c\udfac\ud978\udc2f\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda11\udccd\udbcf\ude64\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u4a89", "\udaa7\ude65\ud9cb\uded5\uda57\ude9b\uda8e\udd81\uda74\udf15\udba3\udc3a\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udb65\udf30\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c\ud9bc\uddc8\udbfb\udfbd\ud8a3\udd0d\udaa3\udd68\ud9ff\ude4d\udaf6\ude7c\udbe9\udebd\u8bc8\udbf0\uddf6\ud8d6\udc8f\ud9bf\udf25\udaf6\ude3a\uda51\udd23\udb16\ude05\ud822\uddea\uda5a\udfec\uda6a\udd1b\ud84d\udebe\ud943\uddc2\ud912\udcd0\uda2d\udd4c\u85a8\uf8ff\udbed\udc77\ud921\uddd8\ud8ab\udc9d\uda74\udf21\ud964\udef4\udbc7\udea7\ud977\udd0c\ud8e4\udd98\udbb8\udd11\ud8fb\udddb\udab9\udcd7\uda0a\udc44\ud9c7\udff9\udac3\udcc8\u3fc9\uda6a\ude49\ub043\udadd\udffb\uda6d\udc74\ud967\udf2d\udabd\udd66\ud967\udc86\ud897\udda9\udab4\udcb5\udbab\udef5\udbd1\udf16\ud99b\udf44\uda77\ude4c\ud898\udf62\uc936\uda66\udfff\udb44\udd65\ud9dc\udef5\ud903\ude15\ud909\udeba\udb8f\ude5d\ud8a0\udc18\ud8ac\ude55\udac1\udc20\ud80c\udf0b\ud894\udf72\u99ab\udb6f\ude4d\udb8e\udf02\ud911\udc44\uda24\udf74\udb00\udd7b\udb9f\udf0d\uda47\ude06\uda96\udc4a\udb11\ude4d\udaa6\udef7\u7707\ud8f4\udd1e\udacb\udd36\ud8d5\ude02\ud990\udde6\udb3c\udf9c\uda2a\udd0a\udb08\uddc8\u1334\udad8\uddae\ud9d9\udcd5\ud93b\ude0c\ud904\udd84\uda68\udc6a\u0c59\ud942\udce4\udade\udda5\uda07\udd4a\udbaf\udc8a\ud906\ude8d\ud848\uddd7\uda90\uddce\ud873\udcdd\udb9c\ude63\udb05\ude65\udb4d\udc1f\ud916\udfa5\udafc\udcf0\ud913\udfc5\uda3e\udf80",
        20, 28356, 415929859, 309248191191182152L, 56402L, false, true, (char) 61181, (char) 37671,
        Double.longBitsToDouble(0x3fca1da3001c3910L), Double.longBitsToDouble(0x3fe9d2af93d2b8acL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 4, 3, 3, "\ud827\udfc6\uda25\ude5a\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\ud8ff\udd9c\ud977\udf9a\ud99e\udda3\ud964\udc4b\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb37\uddf6", "\u3f43\ud53b\uc197", "\ud968\udc3e\ud99e\uded8\uda23\ude05\ud9a9\ude98\udae9\udd6d\udb79\udf3a\ud849\ude17\uda91\udd28\ud9f8\udcbe\udbf4\udcde\udaf3\udd19\ud8f7\udd20\ud873\udc82\ud819\udd2a\uda43\udc77\ud971\uddfb\udaf1\udef6\ud828\ude7c",
        -5, 68610, -918333369, 7516322249630538186L, -59371L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fdb05d7797d739cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 4, 3, 16, "\ud9de\ude30\udbe4\uddde\uda52\ude09\ud81a\udd2e\ud8ba\udd16\udb6b\uddf5\udbb1\udf60\udb02\udf45\uda98\udf0b\uf61a\ud983\udf4d\udb84\udcec\ud98b\udc81\u2b32\udacc\ude78\uda32\uddbf", "\u917b\u1653\u4648\u4d6b\u7b46\ucb9e\ubf31\u5ad8\u3c83\ubc8a\u2db5\ud53f\u4fe0\u7f49\u7e28", "\udb5d\udc6f\ud998\udefd\ud83b\ude24\uda18\udeaa\uda54\udc34\udac4\udccb\ud84d\udc09",
        19, 1797, -899935500, -5019412866861282539L, 53671L, true, false, (char) 61266, (char) 13366,
        Double.longBitsToDouble(0x3feeb526cc778c50L), Double.longBitsToDouble(0x3fbebf25e63630e8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 0, 0, 12, "\ud827\udfc6\uda66\udefe", "\u70e3", "\udad2\udfa9",
        -1, 97591, 2046656541, 4598073926665606607L, -78240L, true, false, (char) 239, (char) 61131,
        Double.longBitsToDouble(0x3fed6f1da7a6c490L), Double.longBitsToDouble(0x3fe022df18000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 9, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\udb1d\ude48\ud941\udf5c\ub760\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\ud8a0\uddb6\uda5b\udee8\udbd9\ude5c\ud876\ude51\udb4d\udcee\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud820\udc9f\ud83f\udffc\udb67\udcdd\udb16\uded5\udbab\udef9\ud88d\udd48\ud85b\udf4b\uda18\udeaa\ud898\udc36\ud873\udc82\uda4e\ude8d\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322249664092618L, 87669L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 2, 15, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5", "\ua2b6\u8b20\u58b2\u1781\u339a\u1db2\ub923\uce53\u8df9\u4ae4", "\udb24\udec3\uda8d\udc42\ud8ee\ude1e\ud8d4\udc85\ud92a\udd4c\udbee\udea1\ud84c\udf52\ud9e0\udfce\ud976\udd75\udb78\udf19\udb2b\udea5\ud8d7\ude9b\ud86a\udf70\udb79\udf3a\uda20\udf44\uda91\udd28",
        -2, 65197, 1908913142, -7387954796406789696L, -24411L, false, false, (char) 28090, (char) 16628,
        Double.longBitsToDouble(0x3fe8add2be9171b5L), Double.longBitsToDouble(0x3fb1da5926aaea18L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 3, "\ud827\udfc6\uda66\udefe\ud8fe\udd32\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud969\uddf4\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\ud870\udd08\ud935\udd14\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u849c\u6596\u5381", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud86a\udf70\ud8f0\udd36\uda20\udf55\uda91\udd28\ud9ba\udebf\ud83b\ude24",
        27, 88729, -68766528, 3046542272497526597L, -96689L, true, false, (char) 8067, (char) 6884,
        Double.longBitsToDouble(0x3fbcc7bcd6af76e8L), Double.longBitsToDouble(0x3feb56f88537183eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 13, 12, 1, "\ud827\udfc6\ud9a5\udcff\ud8ea\udf99\ud9e3\udf07\ud8ba\udd16\udbb5\udee9\ud82b\udf9f\udb02\udf6f\udad7\udc4a\udb2b\udfc3\ud983\udf4d\udaaf\udfa2\ud98b\udc81\uda95\udf06\udbac\udec7\uda32\ude28\ud941\ude5d\udb11\udf8e\udb69\udc7f\ud9b4\ude03\ud957\udc7e", "\u83aa\uc541\u8c8e", "\udbc0\ude4c\udb81\udeeb\udb2b\udea5\udb7f\udf9f\ud87f\ude89\udb79\udf3a\uda20\udf44\uda91\udd28\ud9bd\udfbe\ud913\udf65\ud8e8\udf8a\ud898\udc36\ud85e\udd82\udb5c\udc8b\ud881\udd3f\u25bc\udaf1\udef6\ud828\uddf0",
        49, 70494, -920448582, 7516322249664092618L, -19314L, true, false, (char) 31866, (char) 59295,
        Double.longBitsToDouble(0x3fee9a13bdf7f2e1L), Double.longBitsToDouble(0x3fee68ed3dc47735L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 0, 2, 1, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\udaba\ude16\udb6b\udd5f\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud983\udf4d\ud9cf\udf53\ud98b\udc32\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\ub610\ud53b\u6a44\u2bbb", "\udb78\udf19\udb2b\udea5\ud9a9\udea4\ud9f1\ude70",
        18, 18985, 526740176, -5530232361066016218L, -53351L, false, true, (char) 31221, (char) 14954,
        Double.longBitsToDouble(0x3fb594515ee4fcd0L), Double.longBitsToDouble(0x3fe4be527315ba57L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 14, 14, 3, "\ud827\udfc6\uda7e\udffe\udae2\uddc4\ud9e3\udf07\udb35\udf74", "\u3e53\u5e88\u323e\u164b\u3550\u8941\u4792\u790d\u0e40\u2bf7", "\u80da",
        57, 57567, 2043167473, -2038742170460820563L, -43192L, true, false, (char) 62140, (char) 34536,
        Double.longBitsToDouble(0x3fc6ebc7f50ee944L), Double.longBitsToDouble(0x3fd53a7adb85306aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 13, 3, "\ud9a8\udda5\ud914\udd56\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udb4d\udd50\udb24\udec3", "\u6543\u4294\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9fe\udc0e\uda71\udea9\uda74\udc40\uda20\udf44\uda91\udd28\udab1\ude5a\ud83b\ude24\udb0b\udc85\ud94d\udd18\udbcf\udebe\uda00\udfcd\udab5\udc5c\u25bc\udaf1\udef6\ud828\ude7c",
        34, 39761, 454445188, -5381987083125007993L, 424L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fe356f882d7cf8eL), Double.longBitsToDouble(0x3fe5839684efb3e1L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 15, 11, 3, "\ud98c\udeb8\uda7c\udfbf\udae2\uddc4\udac9\udfbb\ud8ba\udcaf\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc61\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\udbba\uddd6\udb4d\udd50\udb5e\udea1", "\u6543\u4294\u172c", "\ud976\udd75\ud842\ude82\udb2b\udea5\ud9fe\udc0e\ud848\udf35",
        18, 55233, 526742351, 4139558988095435661L, -53343L, false, false, (char) 31221, (char) 1839,
        Double.longBitsToDouble(0x3fec7e1f6a205b72L), Double.longBitsToDouble(0x3fe4be52e315ba57L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 0, 16, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud852\ude62\udb3c\udfb5\ue1aa\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udb4d\udd50\udb24\udec3", "\u1804\u4294\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\udbe1\udfa0\ud848\udf35\udb79\udf3a\uda20\udf44\uda91\udd28\udab1\ude5a\ud83b\ude24\uda18\udeaa\ud898\udc36\ud92b\udc7e\ud945\udc20\udab5\udc5c\u25bc\udaf1\udef6\ud828\ude7c",
        34, 74393, 454482820, -5381987083125007993L, 22133L, true, true, (char) 34682, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6fe61cL), Double.longBitsToDouble(0x3fe582ebbcefb3e1L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 8, 3, "\uda55\udf9c\udb23\udcee\udb56\udf2b\ud9e3\udf07\ud8ba\udd16\ud916\udc10\udadc\ude39\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udb4d\udd50\udb24\udec3", "\u6543\u4294\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9fe\udc0e\ud848\udf35\udb79\ude9e\uda20\udf44\uda91\udd28\udab1\ude5a\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\ud945\udc20\udab5\udc5c\u25bc\udaf1\udef6\ud828\ude7c",
        34, 74393, 454482820, -1216598331970037400L, -91720L, false, false, (char) 8067, (char) 37832,
        Double.longBitsToDouble(0x3fc36e1e6b57bb74L), Double.longBitsToDouble(0x3fd6adf10a6fe61cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 4, 11, 7, "\ud827\udfc6\uda66\udefe\ub07d\ud91a\uddc9\ud8ba\udd16\udb78\udff5\ub7a1\udb3e\udd1c\ud977\udfa6\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81", "\u6f15\u3508\u3bd8\u91da\u2f23\u1bae", "\ud867\udd21",
        51, 66172, -618177900, -7118974508209995781L, -84969L, true, true, (char) 47360, (char) 46583,
        Double.longBitsToDouble(0x3fd3118fb69f36f6L), Double.longBitsToDouble(0x3fe7c0fb2b8d3972L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 7, 0, 7, "\ud827\udfc6\uda66\udefe", "\uc29b", "\udb02\udf95\ud980\udcd5\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d",
        0, 22619, 253367405, 6604622712548593775L, -38868L, true, false, (char) 22194, (char) 20823,
        Double.longBitsToDouble(0x3fda38761ff73a68L), Double.longBitsToDouble(0x3fd8c191456ebc7eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 7, 5, 12, "\ud921\udde3\uda8f\udf8c\udae2\udd37\udbec\udfa5\ud9b9\udd6b\udb9d\udcaa\ub7a1\udbfa\udf6b\ud977\udf9a\udb2b\udf85", "\ua86b\u18b2\ub923\uce53\u809d\ud2fb\u91f8", "\ud8a4\udd6e\udbb6\udf22\ud9e2\udeb4\ud81e\udfd6\uedcc\ud8d2\udc78\udbb9\udef2\ud976\udd75\udb78\udf19\udb2b\udea5\udbad\udea5\ud8d8\udf91\ud8c1\udfc8\uda20\udf44\uda91\udd28",
        23, 59309, 1908913142, -7387954798257157184L, -61533L, false, false, (char) 28090, (char) 16628,
        Double.longBitsToDouble(0x3fe0add2b8849227L), Double.longBitsToDouble(0x3fec234ac6a4e892L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 1, 16, 3, "\ud833\udf7b\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\uda17\ude1b\ud824\udf4e\uda17\ude9f\u1cbf\ud98b\udc81\ud8cf\udec4\udac0\uddfc\uda32\uddbf\uda7c\udceb\ud9e8\udfa3\u3b41\udb4e\udd2f\udb24\udec3", "\u4e18\u4294\ucdd7\u289e\ubc8a\u2db5\ud53f\u08eb\u0495\uce4e\u735d\uc100\u0885", "\udb7d\udef9\ud898\udcd4\ud873\udc82\ud945\udc20\udab5\udc5c",
        51, 17224, -1168673129, -4535783688160270419L, 24831L, true, true, (char) 43253, (char) 57082,
        Double.longBitsToDouble(0x3fc8c7e045cc7bccL), Double.longBitsToDouble(0x3fe0c773216adf10L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 6, 6, 14, "\ud827\udfc6\udbc1\udf4b\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\uda61\uddf0\ub7a1\ud968\ude01\ud91a\ude5b\udb2b\udf55\ud982\udc4d\ud9d4\udf64\ud98b\udca5\udbf2\ude7d\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udbf6\udc24\udb24\udec3", "\u6543\u6a93\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9fe\udc0e\ud848\udf35\udb79\udf3a\uda20\udf44\uda91\udd28\udab1\ude5a\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\ud945\udc20\udab5\udc5c\u25bc\udaf1\udef6\ud828\ude7c",
        34, 74393, 454482820, -5381987083125007993L, 22133L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6fe61cL), Double.longBitsToDouble(0x3fe582ebbcefb3e1L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 4, 10, 6, "\udaf7\ude3b\uda19\udd59\ud8a0\udf92\ud9e3\udf07\ud8ba\udd16", "\u808d\ub7bf\u8b20\u51b2\u1781\u339a\ud3c3\ub923\uce53\u37de", "\ud8dd\udef9",
        56, 54903, 1004781297, 8658060051713924323L, -24332L, true, true, (char) 40239, (char) 34464,
        Double.longBitsToDouble(0x3fdd0aac6a8775f8L), Double.longBitsToDouble(0x3fd53a7adb85306aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 12, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udb4d\udd50\udb24\udec3", "\u6543\u4294\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud85a\udfa6\ud884\udcd2\udb21\udee8\ud85b\udcf9\uda8c\udcbd\udaa0\udcaa\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\ud945\udc20\ud80c\udc88\ud9fe\udd6a\ud8ed\udca0\udbb0\uddd8",
        43, 74393, 454482820, -5381987083125007993L, 39836L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6fe61cL), Double.longBitsToDouble(0x3fe582ebbcefb3e1L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 10, "", "", "\000",
        -5, -1000, -1234649146, 8900124770560129175L, 70410L, true, false, (char) 227, (char) 0,
        Double.longBitsToDouble(0x3e40ec0000000000L), Double.longBitsToDouble(0x3fbb5dcbaae878d0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 1, 1, 5, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\u8d2f\ud8fa\udf0a\ud989\udc8c\ud899\udf1c\uda73\udf6f\ud951\udc64\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udaa5\ude8e\ud85c\ude77", "\u6543\ud53b\u8c8e", "\udaa3\udeec\udb78\udf19\uda3c\ude9c\ud9be\ude2e\ud86a\udf70\udaf1\udf18\uda11\udd87\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\udbf6\ude79\udbcf\udc8c\ud881\udd3f\u25bc\udaf1\udef6\ud828\ude7c",
        -5, 74393, -918333369, 7516322247803675850L, 40590L, true, true, (char) 21833, (char) 31136,
        Double.longBitsToDouble(0x3fbcc7bcd6af76e8L), Double.longBitsToDouble(0x3fd6adf10a6e7a10L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 2, 2, 5, "\ud827\udfc6\ud808\udc03\udb28\udd0d\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\ud9b3\udd07\ud8d3\uded4\ud953\udcfe\udb90\udf4a\ud951\udc64\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\ud902\udd8b\udb47\ude61", "\uc55f\ud53b\u8c8e", "\udbf1\udc41\udb88\udc83\udb2b\udea5\ud9af\udea4\ud86a\udf70\ud927\udf13\ud92b\udcb4\udaa1\uddcc\ud9ba\uddd5",
        6, 12142, -1720142271, -334380451871702514L, 92598L, false, false, (char) 16628, (char) 1389,
        Double.longBitsToDouble(0x3fd9171b508ed2c8L), Double.longBitsToDouble(0x3fea1e4a19ca684fL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 3, 3, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udba9\udf2b\uf99c\ud9e8\udf42\ud977\udf9a\udb2b\udf85\ud983\udf4d\udaaf\udfa2\ud98b\udc81\udb6b\udf04\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\udb78\udf70\udb2b\udea5\ud9a9\udea4\ud86a\udf70\udb79\udf3a\udaa2\udea4\uda7c\ude32\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\udaf0\udf93\ud881\udd3f\u25bc\ud9fb\udd7b\ud828\uddff",
        -5, 57076, -918333218, 7516322249664092618L, 87669L, false, false, (char) 40061, (char) 39289,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 16, 5, 0, "\uda0b\udcd7", "\ua80c", "",
        -5, 41008, 2072221779, 2046656541L, -95995L, true, true, (char) 36, (char) 0,
        Double.longBitsToDouble(0x3fb743c000000000L), Double.longBitsToDouble(0x3fe78a077ecc79c8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud827\udfca\uda66\udefe\udae2\uddd4", "\u0798\ua560", "\ud9d5\udc96\ud983\udf50",
        17, 11055, -1784303847, -1307287247557604615L, -38868L, true, true, (char) 42038, (char) 34279,
        Double.longBitsToDouble(0x3fc71e3cd703c64cL), Double.longBitsToDouble(0x3fe748b62bfb0fe9L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud827\udfc6\uda25\ude5a\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\ud8ff\udd9c\ud977\udf9a\ud99e\udda3\ud974\udc4b\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\udbd3\ude04\ud886\udc7b\udb28\udfb0", "\u3f43\ud53b\uc197", "\ud968\udc3e\ud99e\uded8\uda23\ude05\udbab\udedc\udae9\udd6d\udb79\udf3a\ud849\ude17\uda91\udd28\ud9f8\udcbe\udbf4\udcde\udaf3\udd19\uda4a\udf49\ud863\ude82\ud819\udd2a\uda43\udc77\ud971\uddfb\udab3\udef7\ud828\ude7c",
        -5, 68610, -918333369, 7516322249630504650L, -59371L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fd6adf10a6e7a10L), Double.longBitsToDouble(0x3fdb05d7797d739cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 13, 14, 3, "\ud827\udfc6\ud9a5\udcff\ud8ea\udf99\ud9e3\udf07\ud8ba\udd16\udbb5\udee9\ud82b\udf9f\udb02\udf6f\udad7\udc4a\uda95\udcf8\ud991\udd20\ud8f2\udcd2\ud98b\udc81", "\uce54\u5109\ua7ee\u4317\u8402\u9c1c", "\ud9bc\ude53\ud8c6\udf1b\ud90f\udd10",
        27, -661, -874905179, -4936670947358333093L, 55625L, false, true, (char) 24581, (char) 3874,
        Double.longBitsToDouble(0x3fefb8fb2a26fc40L), Double.longBitsToDouble(0x3fcb7a295905c5b8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 13, 3, "\ud9a8\udda5\ud914\udd56\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ub7a1\ud88b\udc92\ud977\udf9a\udb2b\udf85\ud982\udc4d\ud800\udf4a\ud986\udd90\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udb4d\udd50\udb24\udec3", "\u6543\u4294\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9fe\udc0e\uda71\udea9\uda74\udc40\uda20\udf44\uda91\udd28\udab1\ude5a\ud83b\ude24\udb0b\udc85\ud94d\udd18\udbcf\udebe\uda00\udfcd\udab5\udc5c\uda22\udcb6\udb5c\ude2b\ud846\udfc6",
        0, 57030, 454445188, -5381987083125007993L, 424L, false, false, (char) 12134, (char) 39383,
        Double.longBitsToDouble(0x3fe356f882d7cf8eL), Double.longBitsToDouble(0x3fe5839684efb3e1L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 13, 3, "\ud9a8\udda5\ud914\udd56\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\u69d7\udb02\udea9\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41m\udb24\ude66", "\u6543\u00ad\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9fe\udc0e\uda71\udea9\uda74\udc40\uda20\udf44\udbe8\udf54\000\000\udb0b\udc85\ud94d\udd18\udbcf\udebe\uda00\udfcd\udab5\udc5c\u25bc\udaf1\udef6\ud828\ude7c",
        24, 39761, 454445188, -5381987083125007993L, -100000L, false, false, (char) 12134, (char) 39346,
        Double.longBitsToDouble(0x3fe356f882d7cf8eL), Double.longBitsToDouble(0x3fe5839684efb3e1L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 5, 3, "\uda55\udf9c\udb23\udcee\udb56\udf2b\ud9e3\udf07\ud8ba\udd16\ud916\udc10\udadc\ude39\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb5b\udd33\u3b41\udb4d\udd50\udb24\udec3", "\u6543\u4294\u172c", "\ud976\udd75\udb78\udf19\udb2b\udea5\ud9fe\udc0e\ud848\udf35\udb79\ude9e\uda20\udf44\uda91\udd28\udab1\ude5a\ud83b\ude24\uda18\udeaa\ud898\udc36\ud873\udc82\ud945\udc20\udab5\udc5c\u25bc\udaf1\udef6\ud828\ude7c",
        34, 74393, 454482820, -1216598331970037400L, -91720L, false, false, (char) 8067, (char) 37832,
        Double.longBitsToDouble(0x3fc36e1e6b57bb74L), Double.longBitsToDouble(0x3fd6adf10a6fe61cL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 10, 10, 7, "\ud8fb\udd2f\uda5b\udfd9\ub07d\ud91a\uddc9\ud8ba\udd16\udb7f\udff5\ub7a1\udb3e\udd1c\udba4\udfbe\udb2b\udf85\ud982\udcc6\udaaf\udfa2\ud98b\udc81", "\u6f72\u3508\u3bd8\u5355\ub263\u1bae", "\ud867\udd21",
        51, 19671, -618177900, 6710735522035006273L, -84969L, true, true, (char) 35328, (char) 2022,
        Double.longBitsToDouble(0x3fd3118fb69e5e00L), Double.longBitsToDouble(0x3fe7c0fb2b8d3972L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 12, 6, "\udae4\udf44", "\u8f4a\uc29b\u3d42\ua560", "\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\ud9fb\uddc3\ud922\udeb5",
        0, 6538, 1453938797, -5337562186144079180L, -38868L, true, false, (char) 6846, (char) 33879,
        Double.longBitsToDouble(0x3fe33ed93ffb9d34L), Double.longBitsToDouble(0x3fd8c191456ebc7eL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 6, 12, 3, "\ud827\udfc6\udbd5\udc95\udb60\udfe3\ud9e3\udefb\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\u95cf\udaaf\ude60\000\000\000\udb5b\udc6a\u3b41\udb4d\udd50\u555d", "\u4e76\000\000", "\ud976\udd75",
        21, -1000, 679627008, -6389800778164304632L, -53343L, false, false, (char) 230, (char) 0,
        Double.longBitsToDouble(0x3faf4176a608c2b0L), Double.longBitsToDouble(0x3fe3b13193a03976L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 12, 12, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\uda18\udd0d\ud8ba\udd16\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\ud910\udd6e\u69cd\udb4d\udd50\udb24\udec3", "\u6543\u9c76\u172c", "\uda51\udc15\ud921\uddb9\udb2b\udea5\ud85a\udfa6\ud884\udcd2",
        42, 60476, -1756328215, 4139482365878875021L, -53343L, false, false, (char) 31221, (char) 1839,
        Double.longBitsToDouble(0x3faf4176a608c2b0L), Double.longBitsToDouble(0x3fe3b13193a03976L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 14, 3, "\ud827\udfc6\uda66\udefe\udae2\uddc4\ud9e3\udf07\ud8ba\udd16\udb6b\uddf5\ud9d4\udf14\udb02\udf78\ud977\udf9a\udb2b\udf85\ud983\udf4d\uda1f\udf9a\ud98b\udc81\u2aae\udacc\ude78\uda32\uddbf\ud941\ude5d\udb11\udf8e\u3b41\udb4d\udd50\udb24\udec3", "\u6543\ud53b\u8c8e", "\ud976\udd75\ud85e\ude42\ud9ba\udf9c\ud9a9\udea4\udbfa\udc17\udb79\udf67\uda20\udf44\uda91\udd28\ud9ba\udebf\ud83b\ude24\uda18\udeaa\ud896\udd36\ud873\udc82\udb5c\udc8b\ud881\udd3f\udaaf\uddef\ud8c9\ude38\ud815\udf76",
        -5, 81705, -918333369, 7516322249664092618L, 87669L, false, false, (char) 39695, (char) 59808,
        Double.longBitsToDouble(0x3fc9a5a497e0aab0L), Double.longBitsToDouble(0x3fe582ebbcd2f2e1L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 13, 13, 5, "\ud827\udfc6\u3492\000\ud9e3\udefb\ud893\udfa9\udb6b\uddf5\ub7a1\udb02\udf6f\ud977\udf9a\udb2b\udf85\ud982\udc4d\udaaf\udfa2\u95cf\udaaf\ude60\000\000\000\udb5b\udc6a\u3b41\udb4d\udd50\u555d", "\000\000\000", "\ud976\udd75",
        5, -1000, 679608320, -6389800778164304632L, -53343L, false, false, (char) 230, (char) 0,
        Double.longBitsToDouble(0x3faf4176a608c2b0L), Double.longBitsToDouble(0x3fe3b13193a03976L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|double,double|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|java.lang.Number,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,double|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,double,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,java.lang.Number,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|java.lang.Number,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|java.lang.Number,java.lang.Number,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|org.jfree.data.xy.XYDataItem|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|org.jfree.data.xy.XYDataItem,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|clear||new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|clone||new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|createCopy|int,int|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|delete|int,int|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|equals|java.lang.Object|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|getAllowDuplicateXValues||new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|double,double|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|java.lang.Number,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
