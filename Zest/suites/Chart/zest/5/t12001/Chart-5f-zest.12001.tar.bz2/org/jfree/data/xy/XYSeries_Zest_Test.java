package org.jfree.data.xy;
import org.junit.Test;
import static org.junit.Assert.*;
public class XYSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 0, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20812, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 0, "\uda6f\udcd4\udb0c\udfe4\udb25\udebf\ua713\udafd\udc0b", "\u9e7d\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\ud9b5\uddc2\ud9e5\ude23\udb07\udfbb\ud80c\ude65",
        5, 20812, 1832162051, -4629256577084701706L, 19987L, true, true, (char) 64462, (char) 9942,
        Double.longBitsToDouble(0x3feff3a3314d2203L), Double.longBitsToDouble(0x3fdef99ca1276f4cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 15, 12, 5, "\uda40\udc7a\udb11\udcf7\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20812, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 2, 1, 0, "\ud9cb\udd00\ud8ae\ude92\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u8b7a\ube63\u41fa", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda7f\ude63\uda33\udc42\udb17\udebb\udaa5\ude51",
        39, 20812, 1832162051, 8773455914021667736L, -40960L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 12, 10, 0, "\ud9cb\udd00\ud862\udc8d\udb25\udefc\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\ud93b\udee0\uda56\udc31\udac2\udcaa\ud975\ude40\ud9cc\udf39\udb17\ude59\udaa5\ude51",
        39, 20812, 1832162051, 8773455915783275416L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53312fdcc0L), Double.longBitsToDouble(0x3fe112276a8a7749L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 8, 2, "\ud9cb\udd00\udb0c\udfa1\ud84d\udf34\ud974\udfe4\uda4c\udc46", "\uc480\u7d14\u94b2\uacdb\u8897\u5091\u2fe0\u0ac5\u1b97", "\udaa5\ude51\udbf8\ude7a\ud8ed\uddbd\uda06\udd72\udb80\uded8\ud883\udf00\udb4e\ude1f\udbc5\udc8c\uda32\udc61\ud8a8\udf79\ud840\uddb3\ud89c\udebe\udb91\udcf7\ud9bf\uddde\ud8d6\udd77\uf39e",
        41, 12381, -1320594898, -2054076908255694039L, -19173L, true, true, (char) 28078, (char) 41007,
        Double.longBitsToDouble(0x3fac971f2f06ba60L), Double.longBitsToDouble(0x3fe76ba343538555L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 10, 5, 0, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\u997a\ub11c", "\ud9eb\udc4b\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20812, 1832162051, 8773455917000999832L, 11532L, false, false, (char) 64462, (char) 46226,
        Double.longBitsToDouble(0x3f8fd4cdd46d89c0L), Double.longBitsToDouble(0x3fe11223d893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 0, "\ud9cb\udd00\udb0c\udfa1\udbff\udf78\ud9d4\udeb0\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23",
        -3, 92747, -420367371, -3547454813556665597L, 11475L, false, false, (char) 36814, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276821b7a6L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 7, 1, 0, "\ud997\udfe2\udb64\ude2d", "\u738d", "\ud96d\udccf\udb6f\udf00\udb8c\udd67",
        53, 13701, -1464290838, 9173349745953433559L, -72260L, true, false, (char) 36007, (char) 21567,
        Double.longBitsToDouble(0x3fc4856e6c0f3b14L), Double.longBitsToDouble(0x3fed61a3929879c1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 14, 11, 3, "\udacf\uddf9\ud800\ude38\ud828\ude0e\uda1e\ude65\udb2f\udfdd", "\u554b\u045d\u8c27", "\ub8c1\udaa7\udde2\ud913\udd23\ud9ac\udcff\ud936\udecb\ud99d\udca8",
        0, 80467, -825956188, 7869076088117367724L, 44025L, false, false, (char) 1588, (char) 58068,
        Double.longBitsToDouble(0x3fecfc48a5311d35L), Double.longBitsToDouble(0x3fe561454a2244abL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 15, 0, 1, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20812, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 5, 10, "\uda65\udc4d\ud9de\udc8d\ud91a\udfef\uce6b\udbc6\ude0e", "\u9f80\ucccf\u64b5\ud506\u1a2a\u29e6\u2fe0\ucc90\u0771\u4de1\u8ee1\u9f71\u9e2c", "\udb80\uded8\ud883\udf00\udb2c\udec9\udbc5\udc8c\uda32\udc61\ud8a8\udf79\ud840\uddb3\ud922\udde1\ud822\udc85\ud826\udda1\u32d6\ud99f\udcff",
        16, 30206, 1233344270, 875141477112514823L, 33310L, false, false, (char) 32783, (char) 56739,
        Double.longBitsToDouble(0x3fd9ba7b1633bd56L), Double.longBitsToDouble(0x3fdc0f9f200eb748L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 0, "\ud9cb\udd00\udb0c\udfa1\ud8c7\uddb0\ud8cd\udeb4\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\ud909\udeb1\uda77\udcc1\ud912\udcd3\uda00\udc43\ud9e5\ude23\udafd\udfbb\ud903\udd60",
        23, 20812, 1832162051, 8773455917008012184L, 11532L, false, true, (char) 29380, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 3, 4, 0, "\uda91\udca3\udb0c\udf21\ud95f\udebc\udbab\udcf3", "\u7edc", "\uda9b\udcd2\udaee\udc4d\udbe3\udca2\udaa7\udc49\uda41\udfd5\ud822\udd31",
        -5, 26932, -149522308, 5190286501542482835L, -59665L, true, false, (char) 50995, (char) 64244,
        Double.longBitsToDouble(0x3feff12ab093b7a6L), Double.longBitsToDouble(0x3feb23957b4bea43L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 0, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20812, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fbb953b41f6ab40L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 2, 1, 0, "\ud9cb\udd00\uda7e\ude2b\udb25\udf06\ud8c3\udcff\ud807\udc13", "\ua1eb\u1d21\u64b5\u89b0\u885c\u8805\u5a44\u0ac5\u304c", "\udae9\udc98\udb62\udf2e\ud817\udc7b\udadc\udc59\u2ead\ud884\ude0a\udb92\udce1\uc8c2\uda32\udc61\ud8a8\udf79\udb10\udc49\udbe9\udfa2\ud8b8\uddc7\uda51\uddfe\ud9ad\udd41\udade\udd53\uda9f\ude85\udbb6\ude1a\ud812\udd94",
        10, 69610, -1195500163, 6300388426091791495L, -64871L, true, false, (char) 46998, (char) 63515,
        Double.longBitsToDouble(0x3feba0a6d2c85a22L), Double.longBitsToDouble(0x3fef17aa8806bcceL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 0, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\ud9f9\udcd9\ud906\ude3b\udbdb\udcff\udb21\ude23\udbbc\udc48", "\uc97a", "\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51\udbf8\ude7a\ud8ed\uddbd\ud801\udfd1\uda13\udd48\ud883\udf00\udb23\udd64\udbc5\udc8c\uda32\udc61\ud8a8\udf79\ud840\uddb3\ud87d\uddce\udb85\udd5c\ud9bf\uddde\ud974\udd5e\ud837\udf87\ud982\uded9\u71d3\ud827\udfd5",
        24, 21338, -409418337, 4433660049594877534L, 85211L, false, true, (char) 19033, (char) 64708,
        Double.longBitsToDouble(0x3fee78516af8a753L), Double.longBitsToDouble(0x3feb50b96b35c4a5L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 1, "\ud9de\udcd7\udacc\udd44", "\u88cc\ub9cf\u7f0f\u9f80\ucccf\u64b5\u7524\u37a3\u5211\u9598\u0ac5\u1281\u0710\u8ee1\ua33c", "\uda06\udd72\udb80\uded8\ud883\udf00\udad1\udd5b\ud812\udef7\uda31\udd93\ud8b4\ude79",
        -4, 29269, 1156419917, -5213449891638331245L, -77814L, true, true, (char) 37132, (char) 12473,
        Double.longBitsToDouble(0x3fa0ad2157b5dcf0L), Double.longBitsToDouble(0x3fdd32e4336b8aa2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 3, 0, "\ud800\udf6c\udb0c\udfa1\ud9e0\udd1c\uda29\ude12\uda36\udc41\ud8ed\udef7\udbef\ude2a\udab0\ude17\ud9f3\udda8\ud9e1\udf8d\uda04\udf45\u1d98\udaa7\udc49\uda56\udc7e\ud912\udc6c\uda16\udfae\udae0\udc3f\ud82f\udd2e\ud817\udcbb\udbdf\udf1b\udb9c\ude15\uda3c\udd61\ud993\udf86\ud8a6\udcc5\udb23\udd64\ud9ec\udc4c\uda32\udc07\ud8a8\udf79\uf550\ud978\ude71\ud8dc\udf1d\ud9bf\ude03\udbe1\udfdc\ud8ff\udec4\udb9a\ude7a\ud910\udfeb\udbe7\udef5\udaba\udfaa\udb20\ude3c\ud931\udfd0\ud87a\uddfa\udaad\udfd5\udbf3\udca8", "\u9509\ub44e\u0d11\uc0a5\u8273", "\ud96d\ude33\uda9c\udde8\uda3b\udf50\uda9d\ude02\ud9fc\udfde\ud9f9\udef4\ua153\udaef\udf99\u7b8a\udb41\uddfe\ud8b4\udf7b\uda69\uddf8\ud9e1\udcff\ud878\ude5a\udb9a\ude21\ud9b8\udd86\udb82\ude8a\ud8ad\udc01\ud91f\ude74",
        10, 54993, 1325848935, 7945466346090410749L, 57225L, true, true, (char) 39100, (char) 61288,
        Double.longBitsToDouble(0x3fd5124ec5a88d10L), Double.longBitsToDouble(0x3fef2d220ad09c10L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 8, 0, "\udbde\udc89\ud8d9\uddf4\udb25\udebf\udbab\udcf3\udbf5\ude8a", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        47, 94054, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 8636,
        Double.longBitsToDouble(0x3fbe215adb918bc8L), Double.longBitsToDouble(0x3fe2d505b84a7911L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 11, 10, "\ud9dc\udeaf\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9fb5\ucccf\u3b5e", "\udaaf\udfdf\uda36\udeb7\uda42\udffe\ud9f3\udc94\ud9e5\ude23\udb17\udebb\uda89\ude18",
        39, 20812, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 0, 5, "\udab2\udffc\uda45\udf7e\udaa0\ude10\udbab\udcf3\ud845\udfd3\udb53\udc51\ud8fd\udfd0\udbbc\udc48\ud86b\ude4e\udb07\udd92\ud8b0\uddcc\udbe3\udca2\ud854\udf88\uda56\udc7e\uda8e\udcd1\uda33\udf3c\ud8ab\ude49\ud8d1\udf8d\ud9b9\udc01\udb55\udc88\ud93d\udd2b\uda36\udc3e\udaad\udf4f", "\u38cd\uc4c8\u5e4e\u015f\u8c1d\u94c5\u52d2\ub668\u4128\u4577\u942b\u1d47\uc101\u76cd\u437d\ucb07\u736f", "\udbb2\udd8f\ud90c\udd9b\uda4f\udd22\ud894\udd65\ud9ae\udf1f\ud920\udea7\udb4a\udd85\uda79\ude2d\ud953\udedc\ud83d\udd7a\ud9cd\udfd0\ud042",
        36, 83806, -1140399443, 4715219560875725333L, 75040L, false, false, (char) 33420, (char) 19720,
        Double.longBitsToDouble(0x3fe55b30697f07f4L), Double.longBitsToDouble(0x3fdf619db44151aaL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 13, 5, "\ud9cb\udd00\udb0c\udfa1\u9ec1\udbab\udcf3\udb59\udda9\udbdb\udcfa", "\u3cd3\u2deb\uc97a\u9ebf\u3992\u2fe0\u0ac5\u1281\u4de1", "\udbf8\ude7a\ud8ed\uddbd\uda06\udd72\udb80\uded8\ud883\udf00\ud878\udef0\ud95d\udf28\uda65\udd21\ud8a8\udf79\udbac\ude75\u3fc2\udb85\udd5c\ud9bf\uddde\ud822\ude7c\ud885\ude47\ud95d\ude51\udb78\udcb9\ud88f\udeed\ud9d9\udf98\ud8c5\udd11\ud8c7\udd1f\udb3d\udeed\ud882\udf6c\ud856\udec4",
        30, 99910, -1665996930, 5119651314552235751L, -21154L, true, true, (char) 62756, (char) 22353,
        Double.longBitsToDouble(0x3fce3950e643153cL), Double.longBitsToDouble(0x3fc3c6a32ccd5314L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udbe8\udece\udb0a\udfa9\ud9a3\udc3f\udbab\uddb3\uda4c\ude2a", "\u9f80\ucccf\u64b5\uc97a\u9ebf\u3992\u2fe0\u0ac5\u1281\u4de1\uc695\u443b", "\uda06\udd72\udb80\uded8\ud883\udf00\udbb1\uddac\udbc5\udc9b\uda32\udc61\ud8a8\udf79\ud840\uddb3\ud825\ude43\udb85\udd5c\udbda\udc6a\ud819\udd7a\ud8f6\udf1a",
        33, 54088, -412300225, 3421724514644968119L, -89785L, false, true, (char) 12434, (char) 32810,
        Double.longBitsToDouble(0x3feca297c0279ab5L), Double.longBitsToDouble(0x3fea981e141bda73L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 0, "\udbf6\udd5a", "\u8b8d", "\udb21\ude23",
        17, 56421, 1106644616, -7069387243094581923L, 12386L, true, true, (char) 41568, (char) 32850,
        Double.longBitsToDouble(0x3fc4454c684c8e94L), Double.longBitsToDouble(0x3fefaa4038a4e6f1L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 1, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\ud9c7\udffe\udb2f\udfc7", "\u6e00\u18cf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20812, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 0, 16, 0, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf!\000", "\u9f80", "\udb8d\udff9\udbe3\udca2\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb",
        30, 94629, -826015580, 7869076092060013484L, 44025L, false, false, (char) 966, (char) 64369,
        Double.longBitsToDouble(0x3fe7cc4e1bcdea66L), Double.longBitsToDouble(0x3fd4d220340089daL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 7, 4, "\udac1\udd7c\ud962\uddd5\ud9cd\udd5d\uda06\udd0f\udb7e\udc44\uda76\udff7\udb21\udeeb\udbbc\udc40\ud9f0\udfef\uda86\udf3f\udab7\udcac\ud897\udeba\uda94\udccf\udbe0\udc83\ud9ce\udfd9\uda00\udcb8\ub3de\udad0\udd86\udb37\udd86\udbf8\ude7a\uda98\ude54", "\ua84c\u7810\u878f\u9c07", "\udbd1\uded9\uda86\udec9\ud8be\udfab\uda64\udc3d\ud9d5\udd95\ud9aa\udcc0",
        38, 74798, 1081776759, 8495174886308222724L, -41959L, false, false, (char) 50917, (char) 25468,
        Double.longBitsToDouble(0x3fe3675f5d0f5586L), Double.longBitsToDouble(0x3fe02dda52e4f770L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 1, 0, "", "", "\udaf2\udc78",
        9, 74076, 0, 251742024761344L, -58365L, false, true, (char) 61529, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 7, 1, 0, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udab7\ude9b",
        39, 20812, 1832162051, 8773455917008012184L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 2, "", "\u7e1d\u2eeb\u88cc\ud534\u7edc\u9f80\ucccf\u64b5\u986c\u5d5d\u3992\u2fe0\u0ac5\u1967\000\000\u9d55\000\u50e9\000\u00ac\000\000\000\000\000\u015f\u0bce\000\u9c61\u8eb9\u0723\u3384\u0ee2\u8484\u46f1\u1038\u1034\uc560\ua132\u6bd3\u10f8\u2f97\u4f8d", "\u1eb8",
        1, 54466, -96013492, -5862121271154347795L, 73239L, true, false, (char) 10457, (char) 30453,
        Double.longBitsToDouble(0x3fccdc15c3f9eb38L), Double.longBitsToDouble(0x3fd8af1c0b2c2f18L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 3, 10, 13, "\udaa3\udc35\ud850\udc17\uda4d\uddb3\uda33\ude9b\udb2f\udfc7", "\u75ee\ub139\u5138\u44a7\u923e\u9a74\u56fc\u0ac5", "\udb21\ude20\ud9a2\udd75\ud829\udf37\udbb0\udff4\uda01\udcff\udb80\uded8\ud883\udf00\udb23\udd64\udbc5\udc8c\uda32\udc61\ud8a8\udf79\ud840\uddb3\ud87d\uddce\udb85\udd5c\ud9bf\uddde\uda59\udf57\udbcf\udd72\u430b",
        16, 1472, -1314986707, -2496447352839132936L, -15786L, false, false, (char) 50810, (char) 51703,
        Double.longBitsToDouble(0x3feb96e70c355efbL), Double.longBitsToDouble(0x3fec4653f0a4bcfdL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 15, 11, 0, "\udbf6\udd5a\udb0c\udfa1\udbca\udf72\udbab\udcd2\udb2f\udfc7", "\u020c\000\000", "",
        -5, -1000, -2013265920, -1392147303927409756L, 3340L, false, true, (char) 27752, (char) 62470,
        Double.longBitsToDouble(0x3fe3701e3271995dL), Double.longBitsToDouble(0x3fcf313860000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jfree.data.xy.XYSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 15, 14, 1, "\ud9cb\udd00\000\000\000\udaf2\udc78", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 76612, 1832124416, 8773455178273637272L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 11, 11, 12, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\uda8c\udddb\udb01\uddb5\ud9ea\udc2e\ud816\udf9b\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20252, 1832141263, 8773455917008012184L, 11477L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53354d2203L), Double.longBitsToDouble(0x3fe11222e093b7a6L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 2, 2, 0, "\uda6c\udcaa\ud911\udf82\uda94\udd7c\udb57\udc3d\udb07\udd8e\udbdb\udcff\udb21\ude23\ud81d\udc4d\udbfa\udef5\ud84c\ude6b\udb8d\udff9\udbe3\udca2\udaa7\udc49\uda56\udc7e\ud912\udcd3\ud9b5\uddc2\ud9e5\ude23\udb07\udfbb\ud80c\ude65\udbf8\ude58\ud8ed\uddbd\uda06\udd72\udb11\udfe2", "\u7ea4\u46ca\u0b0b", "\u5b47",
        36, 38070, -470906215, -6996936985684540737L, 19212L, true, true, (char) 11305, (char) 47598,
        Double.longBitsToDouble(0x3fdf8b819e5a95b8L), Double.longBitsToDouble(0x3fe624730bd6a1e6L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda6f\udd32\udb0c\udfe4\udb25\udebf\ua713\udafd\udc0b", "\u9e7d\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\ud9b5\uddc2\ud9e5\ude23\udb07\udfbb\ud80c\ude65",
        5, 20812, 1832162051, -4629256577084701706L, 19987L, true, true, (char) 64462, (char) 9942,
        Double.longBitsToDouble(0x3feff3a3314d2203L), Double.longBitsToDouble(0x3fdef99ca1276f4cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 1, 12, 5, 4, "\udadf\ude0e\ud8a4\udea0\ud8b9\udc5e\u47f5\udafd\udc0b", "\u5668\uadad\u63f9", "\udaa7\udc49\uda56\udc7e\udb59\udf35\ud9b5\uddc2\ud9e5\ude23\udb07\udfbb\udb81\udd80\ud83b\udcd8\ud8ed\uddbd\uda06\udd72\udb11\udfe2\ud8a9\udcb2\udbb8\udfc2\ud842\udff9\udb2b\udcb4\uda61\udcaa\uda96\udee0\ud9ab\udda7\ud8db\udd57\ud86e\udd46\ud9c1\uddea\ud938\udfb5\u9706\ud8d1\udd2c\udb64\udc46\ud89e\udc42\ud929\udcf5\u6a85\ud998\udd11\ud8e0\uddc7\uda1b\udd4f\ud8e1\udd61\udbee\udc4a\ud97f\udddb\ud8b5\ude0c\udb7a\ude94\ud8f8\ude9f\ud9f6\udfe8\uda81\udc39\ud8b1\udc51\udb7e\udc10\udbb8\udcf5\uda6a\udc30\ud8f7\udfd1\u8d3e\u8fa1\ud8ee\uddce\ud88d\udde0\uda82\ude2a\ud9ab\ude5c\udbfd\udfb0\ud923\udd22\udb6d\udd3b\uda1c\ude0a\udabd\udf7a\ud894\udfdb\ud991\ude90\udbc7\ude5c\ud9a0\udee7\udb4a\udd5b\uda8a\udfa6\udac5\udf60\ud895\udf71\ud8f0\udc19\ud92d\udf0c\ud845\udcb2\uda68\udf2a\u8a58",
        27, 80821, 1704317316, 7807417762746734535L, 17034L, false, true, (char) 6461, (char) 24056,
        Double.longBitsToDouble(0x3fd915ee9f1342c8L), Double.longBitsToDouble(0x3fe3c4095b161ffbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 12, 12, 5, "\uda40\udc7a\udb11\udcf7\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\udaa4\ude9b\ud870\uddb7\ud9e5\ude23\ud9b3\udfea\udbf0\udcfc",
        48, 20812, 1832162051, 8773455917008012184L, 77068L, true, true, (char) 63111, (char) 46268,
        Double.longBitsToDouble(0x3fee6f5331d158b6L), Double.longBitsToDouble(0x3fe11227685bb7a6L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 4, 4, 5, "\uda40\udc7a\udb11\udcf7\udb25\udebf\udbab\udcf3\udb2f\udfc7\udbdb\udcff\udb21\ude23\udbbc\udc48\udbfa\udef5\ud84c\ude6b", "\ud016\u2fe0\u0ac5\u1281\u4de1\u80a4\u60a6", "\uda06\udd72\udb80\uded8\ud918\udcd0\uda36\udf0a\udbc5\udc8c\udada\udceb\udb95\udd15\ud85e\udcf2\ud818\udf1d\uda15\udfbd\udb89\ude10\uda97\udfe6\ud80a\udd85",
        37, 87576, 512373948, -5724936183456298227L, -63887L, true, true, (char) 10801, (char) 54297,
        Double.longBitsToDouble(0x3feaa0694bc7ef6aL), Double.longBitsToDouble(0x3fc656538f061c64L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 8, 1, "\ud9cb\udcbb\ud8ae\ude92\udb25\udebf\ud88d\udc24\ud86f\udc8c", "\u8b7a\ube63\ub588\ub8de\u20ce\u961f\uba52\ubd91\ua87f\u72c0\ub01f\u277b\uaf8a", "\udb80\uded8\udb05\udc82\uda28\udc72\ud803\udc93\uda32\udc61",
        52, 84921, 570680269, 4966785958967384610L, -77724L, true, false, (char) 62510, (char) 10568,
        Double.longBitsToDouble(0x3fdaac366ee2ed2cL), Double.longBitsToDouble(0x3fef9813e3d7e646L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 10, 10, 0, "\ud9cb\udd00\ud862\udc8d\udb25\udefc\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\ud93b\udee0\uda56\udc31\udac2\udcaa\ud975\ude40\ud9cc\udf39\udb17\ude59\udaa5\ude51",
        39, 20812, 1832162051, 8773455915783275416L, 11532L, false, false, (char) 64462, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53312fdcc0L), Double.longBitsToDouble(0x3fe112276a8a7749L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 14, 14, 12, "\ud84c\udd31\ud97f\udfc3\udb25\udefc\udbab\udcf3\uda7a\ude87", "\ub939\ucccf\u27b6\uc97a\u5108\uc1b5\u2f93\u6794\ucd16\uc2f6\u8e7f\u0b13\u9e14\u9e4a\u4471\u53fa\u8997\u61f0\u38cd\uc4c8\u5e4e\u015f\ua206\u8ae0\ua782\u56f0\u9437\uce20\u5892\u6dd1\u0367\uab32\u618c\ua865\u6ebe\uc36d", "\ud894\udd82\ud806\udfbd\ud816\udf5c\udaa5\udf8f\uda2e\udf69\ud942\udf11\ud995\udfea\ud989\udfed\udaa7\udf68\ud8fd\ude30\ud893\udd87\udadf\udcfa\ud8b1\uddf0\ud943\ude69\ud8a8\uddea\ud819\ude76\udb04\ude0f\uda8e\udef7\uda00\udcde\ud97a\udf35\u02ad\uda17\udda8\udb0c\udcc1\ud919\udf0a\ud83b\udebb\ud98d\udec2\ud841\uddaf\uda40\udeb4\ud804\ude54\uda75\uddef\udbf3\udfd5\ud8ca\udd23",
        16, 56580, 176348287, -7656951969961207648L, -45352L, false, true, (char) 19259, (char) 62860,
        Double.longBitsToDouble(0x3fdb795982a937c6L), Double.longBitsToDouble(0x3fe9a9140f563e35L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 3, 3, 10, "\ud9cb\udd00\udb0c\udfa1\udbff\udf78\ud9d4\udeb0\udb2f\udfc7", "\u9f80\ucccf\u64b5", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51\udbf8\ude7a\ud8ed\uddbd",
        26, 3388, -1712602216, -6392496084827616115L, -97553L, true, false, (char) 52787, (char) 80,
        Double.longBitsToDouble(0x3fed0fe4b021b717L), Double.longBitsToDouble(0x3fe4a227e86806f1L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 12, 3, "\udacf\uddf9\ud800\ude38\ud828\ude0e\uda1e\ude65\udb2f\udfdd", "\u554b\u045d\u8c27", "\ub8c1\udaa7\udde2\ud913\udd23\u841a\uda98\udc2d\udb5e\udf27",
        0, 80467, -825956188, 7869076088117367724L, 44025L, false, false, (char) 34564, (char) 48015,
        Double.longBitsToDouble(0x3fe8f9846d310f29L), Double.longBitsToDouble(0x3fe561454a2244abL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=org.jfree.data.xy.XYSeries:@? |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 0, 12, 3, "\000\udad2\ude88", "\u88e2\u2ded\u7edc\u554b\u9d8c\000\u7bcc\u9ebf\u892c\u06aa\u854e\ud5a7\ud382\u7f02\u3f4d\u5967\u9e4a", "\000\000\000\000",
        -5, -1000, 682216753, 4948104328310495778L, 10319L, true, true, (char) 49244, (char) 45905,
        Double.longBitsToDouble(0x3fc22bec6d5615ccL), Double.longBitsToDouble(0x3fe2c559ddc9f80bL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 13, 13, "\udae0\udded\udb0c\udfe9\ud9dc\udfe4\udb9b\udedf\udb7d\ude08\udae9\udd26\ud97a\udcac", "\u64b5\u6bda\u6e58\u279c\u0679\ub9dd\u91e5\u4de1\u8ee1\u9f71", "\uda06\udd72\udb80\uded8\ud883\udf00\udb23\udd64\udbc5\udc8c\udb6e\udc5f\ud8a8\udf79\ud840\uddb3\ud87d\uddce\udada\udc5b\ud9bf\uddde\uda36\udfe7\udbb4\udf53",
        0, 22980, 429589256, 9025912260925551852L, -87463L, false, false, (char) 60034, (char) 3996,
        Double.longBitsToDouble(0x3fe0230613f77201L), Double.longBitsToDouble(0x3fb0db1a9cb873a0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 13, 0, 1, "\ud890\udfa3\udb0c\udf21\ud95f\udebc\u1b21", "", "",
        -5, -1000, 1459858221, -936748723963563660L, 65199L, true, false, (char) 32676, (char) 30943,
        Double.longBitsToDouble(0x3fe09fb8b0934807L), Double.longBitsToDouble(0x3fc49cde2c0f3b10L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 13, 13, 9, "\ud890\udfa3\udb0c\udf21\ud95f\udebc\u1b21", "", "",
        -5, -1000, 1459858221, -936748723963563660L, 65199L, true, false, (char) 32676, (char) 30943,
        Double.longBitsToDouble(0x3fe09fb8b0934807L), Double.longBitsToDouble(0x3fc48cbe2c0f3b10L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 8, 0, "\ud9cb\udd00\udb0c\udfa1\udb25\udebf\udbab\udcf3\udb2f\udfc7", "\u9f80\ucccf\u50b6", "\udaa7\udc49\uda56\udc7e\ud912\udcd3\uda00\udc43\ud9e5\ude23\udb17\udebb\udaa5\ude51",
        39, 20812, -1573612797, 8733244990073848728L, 11532L, false, false, (char) 64548, (char) 46268,
        Double.longBitsToDouble(0x3fee6f53314d2203L), Double.longBitsToDouble(0x3fe112276893b7a6L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=void |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 4, 6, 3, "\udacf\uddf9\ud800\ude38\ud828\ude0e\uda1e\ude65\udb2f\udfdd", "\u2c02\u045d\ucc32", "\udbb9\udc40\udaa7\udde2\ud913\udd23\udb88\udc1b\ud82d\uded9\ud8f7\uddaf\udb96\ude98\ud93b\udde5\ud8ed\uddbd\uda0d\udd56\ud976\ude95\ud883\udf00\udb23\udd64\u3131\ud895\ude58\ud9bd\udf68\udaf0\udc03",
        18, 63316, 241310242, -421315656924810308L, 19322L, false, true, (char) 17092, (char) 25210,
        Double.longBitsToDouble(0x3fa329ede7320de0L), Double.longBitsToDouble(0x3fc1d7c882276b14L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.xy.XYSeries:@?\0121=null |this=org.jfree.data.xy.XYSeries:@?\012",
        Z.run(T, 2, 5, 1, 4, "\uda6f\udcd4\udb0c\udfe4\udb25\udebf\ua713\udafd\udc0b", "\u9e7d\ucccf\u64b5\uc97a\u7a99\u6986\u8c88\u9f15\ud2cb\u6648\u4535\u70af\u9e20\u60aa\u4471\u7f87\ud1da\u3392\u8e18\u0804\uce90\u2b4a\ucb21\u82a5\u7807\uac32\ucd77\ua46a\u8ee6\u5872\u2e08\u253d\u80fb\ub5ff\u3c7d", "\udbbe\udd6b\ud967\uddfc\ud90f\uddf1\ud8c8\uddfc\ud968\udf2d\ud9bb\uddc9\udbb3\udd67\udb6c\uddb2\ud99a\uddb0\udabe\udc17\udab9\uddca\ud87e\udfbb\udbaa\udf46\ud96f\udedd\udb01\udeb7\udbfa\ude0b\ud8e4\udc9d\uda0d\udd57\ud867\udc8d\udb3b\udc49\ud95c\udcc2\udb0e\udf32\ud949\udce3\ud9c8\uddc8\udb6f\udffa\udb39\ude67\ud922\ude16\udba4\udc8e\udbaf\udeec\udbc3\udea4\ud8d1\ude9b\ud8a3\ude5b\ud911\udf1a\uda8b\udf84\uda86\udf11\udaaf\udc15\udb36\udd66\udbc6\udc0a\udad3\ude58\udbbb\udec3\udaf4\udf0c\udbf9\udd96\ud835\udfdd\ud9db\udc76\udbde\ude03\ud9a1\udfb5\udb10\udfcd\ud96d\udc27\udb11\udd9a\ud969\udf09\ud95f\udc70\ud81e\udd70\udbc8\udf1f\ud915\udd0b\ud9b8\uddf4\ud899\udcc2\ud9c7\udff3\uda18\udf06\udb57\udc38\ud916\udca7\udb13\udd4d\ud867\udf56\uda85\udd52\udb0e\udfc3\udb1b\uddb1\ud965\udfdf\ud915\ude4f\udb84\udeb4\ud92b\udc6b\udb66\udde2\udb10\udd86\udac8\ude97\udb62\udf1a\ud941\udf1a\udb46\udc2a\uda5f\udf95\udaf4\udce6\udbb6\ude86\uda76\ude39\uda40\udefc\ud96b\udfb0\ud974\udf43\udac9\udd8f\ud819\udfae\udaf2\uddb0\ud884\udd45\ud804\udee5\ud8b4\udea4\uda51\udf90\u855d\uda09\udf69\udb21\udd57\udb9b\udc52\udba4\ude36\udb6d\ude16\udb52\udc30\udb98\udc02\ud8a5\udfc7\udbdf\udfda\udb47\udc31",
        33, 73056, -289450828, -7198246330633155435L, -59700L, true, true, (char) 63801, (char) 38770,
        Double.longBitsToDouble(0x3feacc523f79050bL), Double.longBitsToDouble(0x3fc015c4c22c3e80L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|double,double|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|java.lang.Number,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,double|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,double,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|double,java.lang.Number,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|java.lang.Number,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|java.lang.Number,java.lang.Number,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|org.jfree.data.xy.XYDataItem|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|add|org.jfree.data.xy.XYDataItem,boolean|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|clear||new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|clone||new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|createCopy|int,int|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|delete|int,int|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|equals|java.lang.Object|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|getAllowDuplicateXValues||new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|double,double|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
    "M|org.jfree.data.xy.XYSeries|addOrUpdate|java.lang.Number,java.lang.Number|new:org.jfree.data.xy.XYSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
