package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class ValueMarker_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.027364345208437002 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.17603548051479534 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\udb5c\udd33",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 6167,
        Double.longBitsToDouble(0x3fc68854a3df9394L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.5736751104293308 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\ua400\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "", "\udb1a\udcb7",
        44, 69386, 2063112933, -2611448571586655494L, -25803L, false, false, (char) 13182, (char) 5940,
        Double.longBitsToDouble(0x3fe25b8be7ba575dL), Double.longBitsToDouble(0x3fe3df66d8000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.16028360721778578 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udb4d\udcbe\uda76\ude8e\ud9e5\udf06\udb7b\udc4c\udab5\uddd6\udaf9\udfd1\ud951\udcd2\ud8e7\udced\ud904\udfb1\ud89f\udc18\ud9ab\udc17\ud8d6\udd2c\ud9f0\udc03\uda09\udd62\udbda\udc7f\ud8d8\uddc0\ud9fd\udd2c\ud9e2\udf0d\uda94\udd31\udbd8\ude24\udb20\udc6a\uda1f\udf44\ud9ec\udf01\ud851\uddd4\ud989\udff8\udb73\udfe7\ud84d\udc92\ud9c3\ude48", "\u79a6\u34ca\uc5b7\u46c9\u9b5d\ua6cb\u6b05", "\ud95f\ude5f\ud928\udde9\udabf\ude89\ud829\uddbb\ud808\udd72\ud992\udeaa\udbe2\udf74",
        48, 49295, 947270798, 4991060413191350870L, 68627L, false, false, (char) 32988, (char) 9784,
        Double.longBitsToDouble(0x3fc4842c598aeb18L), Double.longBitsToDouble(0x3fea2820edcec2dcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 0, "\udaf2\udf0d\ud896\udf9e\udb2a\udc34\udb7b\udc42\ud957\udd6c\uda75\udce8\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\udac2\udfa1\udb68\udc2e\udb96\udd85", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e", "\udabf\udf13\ud840\udec6\ud805\udf71\ud89f\ude99\udb2a\uddb5\ud9c5\udddb\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13",
        26, 20398, 185598691, -7523265430284765034L, 7467L, false, true, (char) 15799, (char) 29301,
        Double.longBitsToDouble(0x3fb543d83a2820e8L), Double.longBitsToDouble(0x3fdcec2dcfe588deL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 3, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda57\ude2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\udd54\ud842\udf6f\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\ud8c3\udcac\udb24\ude03\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe3\udf44\ud9f8\udd74\ud93d\udf5c\udb35\udfe1",
        57, 33020, 35772167, -4039810169296649501L, 202L, true, false, (char) 17440, (char) 64029,
        Double.longBitsToDouble(0x3fe046193f9732deL), Double.longBitsToDouble(0x3fb5751f3a2820e8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=new org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\udb2c\udc1c\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udaee\ude3b\ud86e\udc11\udb2d\udefa\ud984\udf75\ud84e\udd02\udb29\udc7a\ud920\udeb0\uda55\udfdb\udaad\udf3c", "\u7edf\u64d5\u3489\u7985\ucf68\u04a4\ud267\u023d\ud2ba\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\udbe2\ude18\udbb8\uddf8\ud90a\udce1\uda11\udfb0\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3fef082b30f7e4e5L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udb69\udcd1\ud931\udc4c\ud8d8\udd20\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\udbe2\udcb4\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa",
        45, 43386, -521267366, 8883863768461191605L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fe74eac46538f42L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 0, "\udaf2\udfbb\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\udb25\udeb6\ud8bf\udce6\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\ud9ff\udeed\uda7e\udf1e\ud921\udd5d\udb1d\udfc2\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda89\udf35\ud9ce\udc76", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\u7bd6\ua7b0\u9632\u360d\u2378", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.8976549884961424 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\uda59\udf2c\ud8b5\ude32\uda07\udd58\udbda\udc7f\ud90a\udc26\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud968\uddec", "\u9ccc\u3480\uba75\u7974\uc19e\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c",
        53, 45401, -2067207594, 153601885128865294L, 39955L, true, false, (char) 48452, (char) 22969,
        Double.longBitsToDouble(0x3fecb996f455d47cL), Double.longBitsToDouble(0x3fea2820edcec2dcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.8694504023643276 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\uda64\ude0d\uda75\udcaa\ud974\udd45\uda39\udf4b\uda58\udde2\udb46\udca5\ud9ab\udc17\u3929\uda84\ude04\uda09\udd62\udbb9\uddb5\ud8d8\uddc0\uda77\udcca\ud9ff\ude9a\uda96\uddc7\udbd8\ude24\udb20\udd21\ud990\udce2\uda4e\udcbd\udbd7\ude83\ud891\udfff\ud920\uddcb\uda4a\uddc8\ud9c3\ude48", "\u9ccc\u3480\u669c\u79f4\u97c9\u7aa1\u085d\u2b7c\ua852\u2c87\u178f\u874d\u2297", "\udbe2\udfb2\uda1b\uddf9\uda78\udd99\udb5a\ude05\udb69\udcda\ud834\udf5f\ud86f\udc3a\udab9\udeb1\uda1a\udc5c\udb6f\udfd6\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa\ud93e\ude4b\udbe5\ude5a\ud9c7\udcdf\ud88c\udd92\udabd\udd99\ud9d9\udcf3\uaf36\ud9dd\udece\uda29\udf45\ud9c8\udd89\ud827\ude83\ud9b1\uddbf\uda0e\ude69\ud94c\udcbf\uda48\ude92\ud83c\udf54\ud8f4\udfc8\u0d20\ud909\udfcc\ud89c\udd43\u03fe\ud8a2\udf5f\udb07\uddaf\ud90a\ude7a\ud94c\udebd\ud8ba\udee2\uda52\udcf7\ud8b0\uddc5\ud938\uddae\udb49\ude4c\ud897\udf20\udadb\udc30\udbbe\udfe7\uda14\udfc9\udbba\udea9",
        24, 62007, -1246601115, -4943670746336120229L, 4527L, false, false, (char) 41804, (char) 25812,
        Double.longBitsToDouble(0x3febd289a674c333L), Double.longBitsToDouble(0x3fbe81fb52ddd0e8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.2256174389226453 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d\ud896\udffc\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e", "\u0db9\ub4de\ua487", "\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca",
        14, 72327, 508172380, -5751618074211577001L, 4396L, false, false, (char) 48098, (char) 44874,
        Double.longBitsToDouble(0x3fcce10840ca3eb8L), Double.longBitsToDouble(0x3fb20739aeab1de0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c", "\u8523\uafa1\u4d36\u6ab7\u8679\ub6fe", "\udbda\udc7f\ud8d8\uddc0",
        7, 62474, -2069921673, 2182583751491331542L, 46956L, false, false, (char) 44874, (char) 3369,
        Double.longBitsToDouble(0x3fe35a1a7de8feceL), Double.longBitsToDouble(0x3fdd5c8ca613c842L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.11825886654951223 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "", "", "\udab5\uddd6",
        25, 1713, 62541, -7677331146815879285L, -100000L, false, true, (char) 20624, (char) 32872,
        Double.longBitsToDouble(0x3fbe46368c4acc88L), Double.longBitsToDouble(0x3fd3aaf810efa93aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.0850812314570234 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 5, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.5085570804600044 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 2, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\ud84a\udc70\udab5\udd2d\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb90\udf6a\u6f61\ud8d6\udd2c\uda84\ude04\udb8d\udc04\udbda\udd22\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud980\udf86\ud920\ude89\uda55\udfdb\ud8f1\udd5f", "\u9ccc\u3480\u3489\uabf8\u57a5\u03c3\ud267\u1876\u3cbf\u3a0f\u9632\uc676\u2297\u21d7", "\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1",
        31, 66366, 35763294, -4039810169296649501L, 202L, true, false, (char) 17440, (char) 32836,
        Double.longBitsToDouble(0x3fe046197f9732deL), Double.longBitsToDouble(0x3fb5751f38d820e8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:0.5993806238922542 |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.5993806238922542 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 4, 4, 0, "\u129b\ud896\udf59\udb81\udcd3\udb67\udee4\udab5\uddd6\uda75\udd2e\u5019\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\uda26\udd90\udb72\uddc8\uf800\udb04\udc96\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\u86ae\u6b2e", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa\ud93e\ude4b\udab7\ude5f\uda7e\udf57",
        47, 72622, 649992875, 1972793895971343593L, -6104L, false, false, (char) 19933, (char) 991,
        Double.longBitsToDouble(0x3fe32e20462f2557L), Double.longBitsToDouble(0x3fe3e93a58652bf8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\udae6\udc80\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud823\udf19\ud870\udfba\uda05\udc67\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\udb39\udcd5\uda55\udfdb\uda96\uddd1", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\u86ee\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\ud985\udfc9\ud8a7\udd77\udbd8\udd73\ud892\udec0\udb8e\udf89\udbfc\udf67\ud93b\udcb3\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\ud8ec\udf9f",
        45, 43386, 1153767258, -1780659210952610653L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 0, "\udb0a\udf3d\udaf5\uddd5", "\u4218\u06a2\u892c", "\u7610\u6241",
        41, 11098, -782295006, 1790936256693935229L, 31782L, true, false, (char) 39728, (char) 21212,
        Double.longBitsToDouble(0x3feabd82d8e4bae7L), Double.longBitsToDouble(0x3fee6061e20c7201L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 3, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\ud93a\udc2a\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud909\udf75\uda11\udf8e\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fd571f88ca71fe6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:4.917383193969727E-7 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d", "\ubafa\u0447\000\000\uaf54\u0db9\ub4de\000\u8391\u87ac\"\u3d74\ubdf4\u5a22", "\udbd8\ude24\u25d6",
        57, 77180, 1912707020, 69421016694128640L, 32327L, false, false, (char) 62937, (char) 61087,
        Double.longBitsToDouble(0x3ea0800000000000L), Double.longBitsToDouble(0x3e0280c000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 4, "\udaf2\udf0d\udad2\udeeb\ud8e7\udeeb\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\udab3\udd69\udaff\uddf2\udbda\udc7f\ud893\udc85\udb99\udc65\ud9c2\ude55\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\ub350\u3489\u7985\ucf68\u04a4\ua7ef\u00c4\ua812\u1894\u934e\uc676\u2297", "\udbe8\udca6\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1",
        31, 59406, 35763226, -4039810169296649501L, 202L, true, false, (char) 10768, (char) 43834,
        Double.longBitsToDouble(0x3fdfb5f48f2e65bcL), Double.longBitsToDouble(0x3fb5751f3a2820e8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\udbbf\udc4d\000\000\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u3489\u0d3c\ucf68\u04a4\ud267\u023d\ua86e\uaaf2\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb67\udfda\u94f9\ud834\udf13\ud842\udc20\ud892\udec0\udb8e\udf89\u00f3\000\uda69\ude94\ud889\udd6e\uda11\udfac\ud99f\udd07\ud91f\udf9e\ud93a\udc3c\uda82\udfaa",
        45, 43386, 15603546, -920359773L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fb5c7e200000000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\uda35\ude57\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u3480\u0a40\ucebf\u9ae7\ua5e1\u6650\u65d6\ua86e\u3a0f\u9632\u1218\u0e6e", "\udbe2\udfb2\ud9cf\udcf2\uda35\ude5f\ud8ec\udc1a\u958a\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa\ud93e\ude4b\udab7\ude5f\ud8dd\udd85",
        41, 52227, 649992875, 1972793895971343593L, -6104L, false, false, (char) 28364, (char) 58521,
        Double.longBitsToDouble(0x3fe29c7f9d47d4f6L), Double.longBitsToDouble(0x3fd55024689cb130L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=void |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 5, 5, 0, "\udaf2\udf0d\ud896\udf9e\ud9b7\udd1b\udb78\uddb3\ud85c\udc69\uda5a\udc2d\ud974\udd45\ud93b\udcec\udb7b\udfff\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\ud86e\udd2c\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud93c\uddb0\udae2\udea1\ud9c3\ude48", "\u9ccc\u3480\u3489\u7985\u854a\u3b45\ud267\u1f3d\ua86e\u3a0f\u87aa\u5fa0\u9279", "\ud8a4\udd27\ud9cf\udce4\ud93d\udf5c\ud870\udee4\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\ud96c\udffc\udb09\udeb9\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud85a\udcdb\udb0f\uddee\uda79\ude1d",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 3, 0, "\udaf2\udf0d\ud896\udf9e\ud822\ude4f\udba4\udc79\ud90c\udf36\uda75\udd2e\uda0b\udd8f\udbf2\udf18\u8c17\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud830\udc12\ud93c\ude0d\ud9a3\udef2\ud912\uddf2\uda1f\udf4c\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "", "\udb1a\udcb7",
        44, 35738, 2063112933, -2611448571586655494L, -25803L, false, false, (char) 24847, (char) 5947,
        Double.longBitsToDouble(0x3fe25b8be7ba575dL), Double.longBitsToDouble(0x3fe3df66d8000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "", "\u69c7\ubb10\u0447\u9102", "\000",
        -5, 21295, 0, -782295006L, -100000L, true, true, (char) 44219, (char) 21780,
        Double.longBitsToDouble(0x3fb72127eeb0f250L), Double.longBitsToDouble(0x3fb5ec0b80000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 1, 2, 4, 3, "\udaf2\udf0d\ud8d4\udf9d\ud969\udff3\ud893\uddb0\ud8d1\uddef\udb37\udc4e\ud974\udd45\uda39\udf4b\ua400\udb46\udca5\ud9ab\udc17\ud8ed\udc97\ud977\udd63\uda09\udd62", "\u5a22\u11cf\ub63c", "\uda81\udd74\ud97b\uded6\udbd7\udeaa\ud916\udc0c\ud8db\udf6c\ud8db\udcd7\ud9d9\udd07\ud887\udfa7\ud9c3\udcdb",
        47, 9384, 533554904, 260897871538510738L, 13331L, false, false, (char) 40148, (char) 8744,
        Double.longBitsToDouble(0x3fe6c8378c21406fL), Double.longBitsToDouble(0x3f965e1d496e2540L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 2, 3, 4, "\udaf2\udf0d\ud896\udf9e\udbe2\uddf0\udad0\ude96\uda67\udebe\uda75\udce8\ud974\udd45", "\ub4de\ub990\u5555\u6122\u48de\u147e\u9ea0\u5a22\u11cf\ub63c\u2c42\u1c50\ud198\ud764", "\udac2\udfa1\udb68\udc2e\udac9\ude68\ud878\udc1a\uda44\udcb1\uda01\udc30\udbc2\udffd",
        57, 9370, -1560918130, -3534542954599088758L, -73946L, true, false, (char) 9985, (char) 57815,
        Double.longBitsToDouble(0x3feab32a411a0938L), Double.longBitsToDouble(0x3fe070110ae3c7efL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 0, "", "\uca76", "\u9e62\ud974\udd45",
        7, -1000, -1962999808, 8217342395360671905L, -27175L, true, true, (char) 64767, (char) 21780,
        Double.longBitsToDouble(0x3fb72127eeb0f250L), Double.longBitsToDouble(0x3feabd8170000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 3, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda57\ude2e\u1bee\udb01\udf4f\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda30\udc6f\ud8b1\udec8\ufcd8\ud842\udf6f\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\ud8c3\udcac\ud8d0\uddd9\ud87a\udc1c\ud920\udeb0\ud8a5\udcde\ud91b\ude89", "\u7233\u12dd\ud359\u31f0\ucf68\u04a4\ud267\u023d\ua86e\uce08\u157a\uc25d\u2334\uac34\u091f\u4ea0\ub3bb\u6d5e\u9de6\ua77a\u4d6b\uc98d\u6a81\uc2b9\ubff5\u249f\u2627\u43eb\u74fd\u4652\u1404\ucdf2\u3780\uad4d\u31fd\u855c\u2b05\u0e54\u4ce9\u55d5\uad25\u8d23\u35b8\u7899", "\ud987\ude25\udb3d\uddcd\uda8e\udffc\u72fd\uda4d\udda8\ud9e0\udf32\ud914\udeb5\udb5a\ude05\u3e5c\udbc3\udc3b\ud8b6\udcfd\ud919\udc17\ud887\udc46\udabd\udca8\u15b9\ud977\udd81\ud809\udc49\ud92c\udf0d\u2281\ued5b\ud822\udd30\ud9a2\udc81\ud8e4\udc13\ud831\udd56\udb63\udc5f\ud86b\uddce\ud9d1\udc85\ud89c\ude65\udae6\ude66\udb43\uddaa\ud82b\ude1d\ud872\udf4b\uda60\udfaf\uda06\udeb3\uda54\udfe9\ud824\udd1e\ud9be\udc93\uda3a\udce0\ud8f4\ude0e\udb0d\udf26\ud98b\udfb9\uda88\udee4\udbb0\udd08\ud8b3\ude1c\ud800\udc04\ud946\udf0f\udba7\ude49\udada\udf47\ud958\udd1f\udb6e\udd2d\ud996\udfe9\ud8f1\ude9b\udbac\udd0f\udbe2\ude5b\uda5f\ude3a\udb81\udc42\udbee\udf8c\udbf6\ude25\ud93f\udf83\ud949\udf18\ud9e1\udf0d",
        54, 28363, 750933120, 296964390492505565L, 70305L, false, false, (char) 61359, (char) 54925,
        Double.longBitsToDouble(0x3fd2f7b1e3e83de8L), Double.longBitsToDouble(0x3fe9a1fdb82b3eb7L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\0121=new org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 2, 2, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb26\udf22\ud82b\udd8c\uda75\udd2e\udb2c\udc1c\ud8c8\udf51\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\udaa5\udcc5\udaee\ude3b\ud873\ude29\udb2d\udefa\ud984\udf75\udad9\udf06\ud8f4\ude44\ud920\udeb0\uda55\udfdb\udaad\udf3c", "\u37bc\u3147\ua365", "\ud8a8\ude24\ud8cc\udf39\ud8df\ude1f\ud89f\udd95\ud955\udd3b\ud9a7\udd95\udaaa\udce8\ud8a1\udd38\ueb23\ud89f\ude99\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\udbe2\ude18\udbb8\uddf8\ud90a\udce1",
        44, 91032, -730054761, 296600222708850501L, -63122L, false, false, (char) 8051, (char) 27791,
        Double.longBitsToDouble(0x3fe55e49259926beL), Double.longBitsToDouble(0x3fcd236c0dea61b8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.027364345208437002 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 4, 0, "\udaf2\udf0d\ud896\udf9e\ud969\udff3\udb7b\udc4c\udab5\uddd6\uda75\udd2e\ud974\udd45\uda39\udf4b\uda59\uddb8\udb46\udca5\ud9ab\udc17\ud8d6\udd2c\uda84\ude04\uda09\udd62\udbda\udc7f\ud8d8\uddc0\uda77\udcca\ud9e2\udeab\uda94\udd31\udbd8\ude24\udb20\udd21\uda1f\udf44\uda64\udd9c\udbd7\ude83\ud891\udfff\ud920\udeb0\uda55\udfdb\ud9c3\ude48", "\u9ccc\u9c3f\u9640\uaaf8\ucf68\u04a4\ud267\u023d\ua86e\u3a0f\u9632\uc676\u2297", "\udbe2\udfb2\ud9cf\udcf2\ud93d\udf5c\udb35\udfe1\u94f9\ud834\udf13\ud86f\udc3a\ud892\udec0\udb8e\udf89\udb6f\udfcb\ud919\udff2\uda72\udd47\ud889\udd6e\uda11\udfac\ud99f\udd07\ud9ef\udd06\ud82d\udc93\uda82\udfaa",
        45, 43386, -521267366, -1780660151550448477L, -49415L, true, false, (char) 58344, (char) 18910,
        Double.longBitsToDouble(0x3f9c05661efc9ca0L), Double.longBitsToDouble(0x3fb5c7e2329c7f98L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke,java.awt.Paint,java.awt.Stroke,float",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double",
    "M|org.jfree.chart.plot.ValueMarker|equals|java.lang.Object|new:org.jfree.chart.plot.ValueMarker:double",
    "M|org.jfree.chart.plot.ValueMarker|getValue||new:org.jfree.chart.plot.ValueMarker:double",
    "M|org.jfree.chart.plot.ValueMarker|setValue|double|new:org.jfree.chart.plot.ValueMarker:double",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke,java.awt.Paint,java.awt.Stroke,float",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
