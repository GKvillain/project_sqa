package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class ValueMarker_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3\udb6a\udd9a", "\u4ebc", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1",
        19, 716, 991977714, 3276807881077139456L, 70516L, false, true, (char) 43757, (char) 13572,
        Double.longBitsToDouble(0x3fd0d8ec2a43d90aL), Double.longBitsToDouble(0x3fdd13fea1952ad4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3\udb0e\udcf9", "\u5d8b\u9b73\uac93\uc7d2\ub735\u3f3c", "\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\ud8ae\udd2c\udbc6\udc12\udbe6\udde2\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1\ud8f4\ude09\uda3f\udc48\u446e\ud802\ude16\udb5e\udd39\ud8bd\ude5e\ud9a2\udfb0\uda67\udc23\ud816\udeee\uda32\ude6d\ud860\udfe7\ud8ee\udce5\u0b89\udb2c\uddd8\udb66\udf59\udaac\ude99\udb97\uddb6\ud993\udc7f\udb30\ude17\udb02\udc38\uda02\ude47\udb37\udd54\uda82\udeea",
        27, 59326, 914410856, -2752842075425901825L, -52126L, false, false, (char) 47162, (char) 58234,
        Double.longBitsToDouble(0x3fcc8c8e2e2d0920L), Double.longBitsToDouble(0x3fc5b735cfaa633cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "\udac2\udfc3", "\uc1d0\u4ebc\ua12b\uac93\uc7d2\ubb63\u84c3", "\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\ub1d7\000\ud8e1\udcb1\ud8f4\ude09\u6178\u446e\ud873\udf6f\udb34\udd39\ud8bd\ude5e\ud9a2\udfb0\uda67\udc23\ud816\udeee\uda32\ude6d\015\000\000\ud881\udd9f\ud8f9\udd1a\udb8c\udeb5\udb7f\udeaf\udae6\udd3b\udae6\udcd6\udacf\ude24\ud8ad\udf1a\udb43\udc5b\ud995\uddcd",
        45, 39671, -285074404, -6633176530933439939L, 46778L, false, false, (char) 46147, (char) 38044,
        Double.longBitsToDouble(0x3fe45557c4cea8b6L), Double.longBitsToDouble(0x3fc067b4db30cfa0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 1, "\ud82d\udd43\udb6a\udd02\ud850\udd25\uda43\ude4a\ud985\udc82\ud991\ude35\ud852\udf63", "\u48c3\u9214\u5139\ube5b\ubefa\u8c46\u6370\uc3c9\u295a\uac25\u46a9\uc3dc\ud31c\u67cf\u57c8\ub661\u9068\u9976\u01a5\u3523\u2105\uc8f7\ud38a\ud38e\u987f\u00e2\ub37d\u266c\u4d69\u63f5\u9a91\uce3e\u5c94\ub976\uc13d\ua5d3\ub833\u03a6\uab64\u9260\u9aa1\u27ca\u040d\u8f7c\u20ef\u3f48\u1472\ua9f5\u8cbd\u879e\u845c", "\ud91c\udec3\u5931\ud95b\udd69\uda6d\udf61\ud903\udc83",
        31, 4510, -1470497077, -4756949220095302590L, 95410L, true, true, (char) 22107, (char) 35853,
        Double.longBitsToDouble(0x3fbfffad98087d10L), Double.longBitsToDouble(0x3fdf83799d5e2270L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3\udb6a\udd9a", "\uabac", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d",
        24, 31199, 1659524586, -7178065302324049408L, -50909L, true, false, (char) 45076, (char) 33884,
        Double.longBitsToDouble(0x3fdd79d927c3c470L), Double.longBitsToDouble(0x3fea239300e69076L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "\udac2\udfc3\u00ba", "", "\uda8b\udc17\000",
        25, 262, -1910386, 1734437497842172138L, 99168L, false, false, (char) 0, (char) 62022,
        Double.longBitsToDouble(0x3f35ce46e88bf800L), Double.longBitsToDouble(0x3fdd700007c3c470L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 1, 2, "\ud97f\udfc3\udb1c\udcf7", "\u4d8c", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\ud900\udfbe\udb38\udf09\udab6\udd18\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud911\udd9e\ud98b\udde6\uda04\ude9e\ud8e1\udcb1",
        19, 716, 991977714, 3276807881368902129L, 70516L, false, true, (char) 41276, (char) 13389,
        Double.longBitsToDouble(0x3fd0d8ec2853990aL), Double.longBitsToDouble(0x3fdd1a19c1532ad4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3", "\uc1d0\u4ebc\ua12b\u2bb1\uc7d2\ubb63\u84c3\u616b\u2a3e\u6710\u4504\u6410", "\udbc5\udf6a\uda5c\udddd\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1\ud8f4\ude09",
        51, 55714, 762941288, -855217737241877220L, 43642L, true, true, (char) 31142, (char) 37307,
        Double.longBitsToDouble(0x3fc952ad566a3f98L), Double.longBitsToDouble(0x3fefdd601dfe4306L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3\udb6a\udd9a", "\u4ebc", "\uda8b\udd5c\uda77\uddd7\udab2\udfbe\ud8eb\udfef\ud855\udf22\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e",
        3, 25367, 293558491, -7092480170137341481L, 38052L, false, false, (char) 20690, (char) 8325,
        Double.longBitsToDouble(0x3fe4f76100002d2eL), Double.longBitsToDouble(0x3fdc814cdbd98c2aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 7, "\udb5b\udc40\udaf1\udf39", "\uc9cd", "\uda6f\udc31\udab5\udcf9\ud9c6\uddac\ud938\udf45\udad3\udd24\ud900\udfbe\udb9f\udfa6\udab6\udd86\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\uda13\uddfa\ud8e1\udcb1\ud90b\udccf\u6178",
        13, 37883, 160660890, 3886374163004100686L, -327L, true, true, (char) 15311, (char) 31142,
        Double.longBitsToDouble(0x3fdd13fea5c32ad4L), Double.longBitsToDouble(0x3fe01f20f000534dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3\udb6a\udd9a", "\u4ebc\ua12b\uac93", "\udb1f\udeaf\ud8f4\udd8c\ud855\udf22\ud900\udfbe\udbc3\udfd7\udbed\udd34\u17cb\ud859\ude80\udbc5\udf6a\udafc\udeee\uda9e\udc90\ud9d4\udf63\uda04\ude9e\ud8e1\udcb1\ud8f4\ude09\u6178\u446e\ud802\ude16\udb5e\udd39\ud8bd\ude5e\ud9a2\udfb0\uda67\udc23\udb72\udc3b\ud8b6\udf51\ud860\udfe7\ud8ee\udce5\u0b89\ud9cd\udf28\udb05\udda8\ud805\udff3\ud87c\udc0d\ud8fe\udd5d\ud8d8\udd66\udbc9\udd5d\ud8da\udcb0\udb6e\udee1\udba7\udcfb",
        53, 48528, -889749263, 2388902312872003649L, -33076L, false, false, (char) 55532, (char) 43305,
        Double.longBitsToDouble(0x3fdfb72c88bfa488L), Double.longBitsToDouble(0x3fe2659be9e97f59L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 2, "\ud8c8\udf13\ud96b\udfae", "\u4ebc", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd0b\ud855\udf22\ud900\udfbe\uda8a\ude44\udab6\udd18\udab4\ude7e\ud87e\udf80\udba1\udf79\ud825\udfaf\ud964\udd85\udaea\udc12\uda04\ude9e\ud8e1\udcb1",
        19, 716, 991977714, 3276807881077139456L, 70516L, false, true, (char) 37377, (char) 13572,
        Double.longBitsToDouble(0x3fd538ec2ca92796L), Double.longBitsToDouble(0x3fdd13fe76a350d4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 1, 5, 1, 2, "\udac2\udfc3\udb6a\udd9a", "\u4ebc", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\udae7\udc0d\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1",
        19, 716, 991977714, 3276807881077139456L, 70516L, false, true, (char) 43757, (char) 41160,
        Double.longBitsToDouble(0x3fd0d8ec23e5d90aL), Double.longBitsToDouble(0x3fed835db8ca956aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 2, "\udac2\udfc3\u75ec", "\u4ebc\ua12b\uadc3\u7cbf\u74a1\u84c3\u616b\u4f3d", "\ud9a7\udc39\udacc\ude9d\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\ud8d8\udd5b\ud8e1\udd6a\ud905\udc09\uda53\udc13\ud866\udd4c\ua644",
        32, 34574, -635623089, 3475328982976199347L, 57638L, false, true, (char) 37218, (char) 52705,
        Double.longBitsToDouble(0x3fe7cc7ba0ff2fa6L), Double.longBitsToDouble(0x3fd739cdc7cad8c4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=new org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 5, 2, 6, "\uda94\udec9\udb80\udf9a", "\u8c11", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\uda7c\udfb1\udbe4\udd47\udab6\udd18\udbdf\udd92\udb99\udfd4\udba5\udd6a\udbe6\udde2\ud803\udd10\udaea\udc15\ud8e7\udc50\ud91b\udd30",
        23, 716, 991977714, 4141499009532274688L, -8372L, true, true, (char) 12604, (char) 33484,
        Double.longBitsToDouble(0x3fefc3f925128514L), Double.longBitsToDouble(0x3fd7314ea0333ab6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 2, "\udae0\udfde\udb6a\udd9a", "\u4ebc\ua12b\ua9e8\ub53b", "\ud8f4\udd8c",
        14, 8258, -1015872514, -4167314006651682000L, -87864L, true, false, (char) 33884, (char) 3487,
        Double.longBitsToDouble(0x3fef0f11c3447260L), Double.longBitsToDouble(0x3fccd20ed5122e38L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=void |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 5, 5, 6, "\udb88\ude92\ud9a8\ude62", "\u4ebc", "\udbbb\ude65\udb63\uddef\uda3f\udfe2\udae2\udddd\ud90d\udf18\ud886\uded7\u4392\udab6\udd18\udab4\ude7e\ud859\ude80\ud909\udd0f\udbe6\udde2\udb2f\udda5\udb3a\udcaf\udabd\udc9b\ud8e1\udcb1",
        43, 26652, 991977714, 3276807881077139456L, 70516L, true, false, (char) 18839, (char) 4100,
        Double.longBitsToDouble(0x3fd609069a4266c6L), Double.longBitsToDouble(0x3fe309ff501a8b83L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3\udb6a\udd9a", "\u4ebc\ua12b\u2394\uc7d2\ubb63\u84c3\u616b\u2a3e\u2b26\u4592\u58b8\ua91b\u662e\u81a8\ucd97\u9634\uae8b\ud36f\u9f11\ub6e3\u18e8\u9f05\u8d4d\u00a8\u3523\u2105\u7a75\u1f57\u12e3\u25f7", "\ud915\udc8c\udaa8\uddb1\uda6c\ude9c\uda0f\udcd8\udaac\uddfb\ud9ad\udd85\ud864\ude72\udad3\udd0d\ud81f\ude72\ud934\udcc5\udb79\udc4d\ud896\udd61\ud9f9\udcb0\udbd1\udcd3\uda33\udd2a\udaec\udd52\ud83b\uddbe\uda05\udeb6\u7d7e\ud947\udda1\uda57\udf20\ud8b9\udc99\ud885\udd29\ud910\udd30\udb44\ude9c\ud8a0\udca1\ud8c7\udf49\udbd2\udcff\ud911\uddab\udb0c\udefd\uda09\udffb\udbf6\udda7\ud801\udc35\uda30\udeb5\udba4\ude25\ud8c5\udd97\ud87c\udfab",
        6, 74914, -1245498403, 1206461235664032520L, 3819L, true, true, (char) 32489, (char) 62363,
        Double.longBitsToDouble(0x3fe97a6546a85666L), Double.longBitsToDouble(0x3fd2db4cfe795ebaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:0.9792654106724086 |this=org.jfree.chart.plot.ValueMarker:@?\0121=new org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 4, 2, 7, "\udac2\udfc3\udb6a\udd9a", "\u4ebc\u5349", "\ud898\udeb5\udb9f\udcbf\ud8f4\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\udb86\udc56\udab4\ude7e\udbe9\ude88\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\udac6\udea5\ud9de\udfc7\ud8f4\uddab\u6178\u446e\u8006\ud974\udfac\ud8bd\uddf2\ud9a2\udfb0\ud8eb\uddc6\udbcc\ude29\ud8c5\udf05\ud93f\udf3d\ud8aa\ude97\u0b1f\udb0a\udf68",
        40, 83897, 619948092, 3738901786607989846L, -54326L, true, true, (char) 2864, (char) 20619,
        Double.longBitsToDouble(0x3fef56246a1e24e6L), Double.longBitsToDouble(0x3fbe3bdb02d681c8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "$\udb6a\udce0", "\000", "",
        -5, -1000, 1031009262, -8205044988906057L, 56579L, false, false, (char) 31002, (char) 16384,
        Double.longBitsToDouble(0x3fe23b5218db5739L), Double.longBitsToDouble(0x3fe6e88bf9d79d92L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 3, 3, 1, "\udac2\udfc3\udb6a\udd9a", "\u4ebc", "\ud860\udfa7\udad2\udeaf\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\udaf6\udc58\ud8e1\udcc7",
        19, 716, 991977714, 3276807881077139456L, 70516L, false, true, (char) 43757, (char) 13572,
        Double.longBitsToDouble(0x3fd0d8ec2ec6ef30L), Double.longBitsToDouble(0x3fc974e7bdd4f950L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 2, "\udac2\udfc3\udb6a\udd9a", "\u4ebc", "\udbfa\udfe8\udb66\udccb\ud9a5\udcc8\ud990\udeef\udbab\uddbc\ud8b6\udc12\ud843\ude9b\udab6\udd18\udab4\ude7e\udbf3\udfa2\udab4\udf05\ud8bb\udf13\ud803\udd10\ud985\udd23\uda20\udd15\ud8e1\udcb1",
        19, 716, 991977714, -7546186450091656958L, 18507L, false, true, (char) 49787, (char) 13517,
        Double.longBitsToDouble(0x3fd0d8ec2a43d90aL), Double.longBitsToDouble(0x3fdd1ecea1952ad4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 1, 2, 1, 2, "\udac2\udfc3\udb6a\udd9a", "\u332d", "\uda8b\udd5c\ud9a9\uddf7\ud83d\udf8d\udb74\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\uda9d\udc29\u9080\ud859\ude59\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1",
        19, 871, -1847828238, -7906246076677652059L, 70516L, false, true, (char) 43757, (char) 13572,
        Double.longBitsToDouble(0x3fd0d8ec2a43d90aL), Double.longBitsToDouble(0x3fdd1939b6932ad4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 0, "", "\u3cdd", "\000",
        -2, 53802, 1406420992, 4428151062161185166L, 53066L, true, true, (char) 42594, (char) 53786,
        Double.longBitsToDouble(0x3e7123b521800000L), Double.longBitsToDouble(0x3fcb6ae720000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 2, "\uda32\uddad\ud816\udc4b", "\u4ebc", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\udab6\udd18\udaa4\udf7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1",
        19, 716, 991977714, 3276807881077139456L, 70516L, false, true, (char) 43757, (char) 13572,
        Double.longBitsToDouble(0x3fd0d8ec2643d90aL), Double.longBitsToDouble(0x3fca2509a32a55a8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 2, "\000", "", "",
        28, 41254, -201665006, 6040532203702583296L, 33705L, false, true, (char) 25485, (char) 0,
        Double.longBitsToDouble(0x3dfec30000000000L), Double.longBitsToDouble(0x3fe23b5218db5739L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udac2\udfc3\udb6a\udd9a\udabf\udcbc\uda4c\ude77\ud9aa\ude80\ud991\ude35\udbd0\udfda\ud96b\udf0c\uaf0d\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1\ud8f4\ude09\u6178\u446e\ud802\ude16\udb5e\udd39\ud8bd\ude5e\ud9a2\udfb0\uda67\udc23\ud816\udeee\uda32\ude6d\udb17\ude82\ud8ee\udd38\u0b89\ud806\ude06\udbed\udf30\ud9e8\udc8c\ueff9\udbd1\udf3f\ud906\udc92\ud965\ude65\ud9a6\ude56\udbed\udce7\udb7e\udf32\ud86a\ude27\uda3c\udc07\ud88f\udde1\ud84a\udcd3\udbe1\udffc\ud9d6\udd5f\udaf1\udc96\ud89e\ude71\udaae\udf26\ud8a1\udfe9\ud85e\udc25\ud869\udd28\uda58\udefe\ud909\udc77", "\u1db5\u8bbe\u595f\u98dc\u83d5\u3911\u537c", "\udbec\udcfc\u8066\uda72\udf04\ud91b\udd34",
        0, 29564, 1523874501, -5500755691953021263L, -96815L, true, true, (char) 46080, (char) 51366,
        Double.longBitsToDouble(0x3fd8330440e81056L), Double.longBitsToDouble(0x3fd71178fa8f69ccL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\udbb7\udf72\udb6a\udd9a", "\u4ebc", "\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\udbbd\udcdc\udaa5\udfc4\udad1\udf89\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\udaea\udc15\uda04\ude9e\ud8e1\udcb1\ud8f4\ude09\u6178\u446e\ud802\ude16\udb5e\udd39\ud8bd\ude5e\ud9a2\udfb0\udaca\udc1e\ud800\udf0a\uda32\ude6d\ud98f\udd84\ud8ee\udce5\ud91a\udf2e\uda9e\udfd2\udb38\udcf6\u3bba\ud99e\udf36\udb87\udfde\ud964\uddc8\ueeca\ud8b4\udf67\ud8b4\udd85\udae3\udedd\ud838\ude73\ud94d\uddc5\ud97b\ude12\ud918\udd23\ud8b9\udcfa\udbab\udc3d\udae1\ude45\udbed\ude70\ud9e3\udd0a\udb45\udc8d\udb3f\udeef\ud81d\udc1e\ud9fb\uddd8\udb14\udccf\udb7e\uddbf\ud9a1\udcf3\uda47\udd68\ud80c\ude39\uda58\ude6a\ud809\udc61\ud80d\udcb4\udba4\udfb0\ud969\udccb\ud8c7\udce4\uda67\udd18\uda4a\uddc0\ud980\udca3\ud8b0\udddb\uda18\udf91\ud9ec\ude01\uda5a\udef7\udb90\udd1d\udac7\uddbd\ud861\ude54\udadd\ude43\ud904\udd39\udad7\uddef\udabe\udcd8\ud959\udcf5\ud919\udca6\ud847\udeac\ud9dd\udf90\ud90a\udc7b\uda1a\ude82\udaf9\udc5b\ud9f2\udec8\udb93\ude6f\ud88b\udca1\u5017\uda48\udf36\udbfb\udf9e",
        28, 45390, 1550677467, 3473778900971747699L, 32767L, false, false, (char) 39728, (char) 35996,
        Double.longBitsToDouble(0x3feb2e26f42da7b9L), Double.longBitsToDouble(0x3f74f66a335cac00L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:0.2230394101589548 |this=org.jfree.chart.plot.ValueMarker:@?\0121=java.lang.Double:0.2230394101589548 |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udac2\udfc3\udb0e\udcf9", "\u5d8b\u9b73\uac93\uafcb\ub735\u3f3c", "\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\ud8ae\udd2c\udbc6\udc12\ud9bc\ude62\ud815\udf89\udaea\udc15\uda04\ude9e\ud8e1\udcb1\ud8f4\ude09\uda3f\udc48\u446e\ud802\ude16\udb5e\udd39\ud8bd\ude5e\ud9a2\udfb0\ud883\udf12\ud9d5\udff1\uda38\udfa5\ud860\udfe7\ud8ee\udce5\u0b89\udb2c\uddd8\udb66\udf59\udaac\ude99\udb97\uddb6\ud993\udc7f\udb30\ude17\udaff\udfc6\uda02\ude47\udb37\udd54\uda82\udeea",
        27, 59326, 921750888, -2765404146097097985L, 70858L, false, false, (char) 47162, (char) 58234,
        Double.longBitsToDouble(0x3fcc8c8e2e2d0920L), Double.longBitsToDouble(0x3fc5b735cfaa633cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 0, "\udac2\udfc3\ud82d\udd8f\ud820\udc04\uda4c\ude1d\ud9aa\ude80\ud991\ude35\uda8b\udc17\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\ud900\udfbe\ud85b\uddc4\udab6\udd18\udab4\ude7e\ud859\ude80\udbc5\udf6a\udbe6\udde2\ud803\udd10\ub1d7\uda20\udc4d\udb5b\udd6f\ud87d\udc07\u6178\u446e\ud873\udf6f\udb34\udd39\ud893\ude69\ud9a2\udfb0\uda67\udc23\ud816\udeee\uda32\ude6d", "\000", "\udb8c\udeb5\udb7f\udf74\udae6\udd3b\udae6\udcd6\udacf\ude24\ud8ad\udf1a\udb43\udc5b\ud995\uddcd\uda4c\udf8b\ud988\udc6b\uda86\udf1b\ud8b4\udfaa\ud867\udd7d\ud819\udfcc\ud8f4\udc7c\udb8a\udf06\ud990\udf59\udb4a\udd50",
        53, 44946, -1464434038, 4442419287988662403L, 93772L, true, false, (char) 1164, (char) 33573,
        Double.longBitsToDouble(0x3fe835ecc9a62607L), Double.longBitsToDouble(0x3fea26b871d0dff8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.jfree.chart.plot.ValueMarker:@?\0121=new org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udac2\udfc3", "\uc1d0\u4ebc\ua12b\u2bb1\uc7d2\ubb63\u84c3\u616b\u2a3e\u6710\u4504\u6410", "\ud99c\ude5c\uda5c\udd49\ud803\udd10\udaea\udc15\uda04\ude9e\udaf8\udd1c\ud814\udee0\ud910\ude9a\ud95a\udfbf\ud802\ude16\udbc3\udf4c\ud8d6\uddb2\ud9a2\udfb0\ud99c\udc24",
        53, 33930, -326783731, 4605648740024996305L, -52282L, true, true, (char) 20740, (char) 35179,
        Double.longBitsToDouble(0x3fed6935acc72bb7L), Double.longBitsToDouble(0x3fbb5003efd5e160L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 6, "\udb5b\udcc8\ud92f\udc38\uda10\udfb7\ud9f5\ude07\udbd0\udc1e", "\u56a7\ubb63\u3b01\uae2d\u3072\u2b26\u737f\u5926\ua91b\u1eb9\u93bd\u4e2e\u1158\u0de9\ud28d\u9f11\ub15d\u6948", "\ud9c1\ude2a\udacc\udd68\udbad\udc7b\ud958\udd1e\ud816\udee2\uda30\udcce\ud860\udfe7\ud8ee\udce5\u0b89\ud970\udd3c\udb0b\udeeb\ud85e\udcf2\ud886\udc7e\uda51\udc6e\udb1b\udc0e\uda18\udf60\ud988\udf2d\ud878\uddcf\uda0f\udf93\ud954\udff3\uda9f\udf24\udbe1\udf2d",
        16, 33663, 1342902640, -3854480437825658871L, 79058L, false, false, (char) 25973, (char) 26336,
        Double.longBitsToDouble(0x3fda5bf789d847a8L), Double.longBitsToDouble(0x3fe5f5a468ed8c28L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 2, "\ud9c6\udc91\udb6a\udd96\udabf\udcbc\uda4c\ude77\ud9aa\ude80\ud991\ude35", "\ubb63\u84c3\u616b\u2a3e\u2b26\u64f1\u14c3\u1d77\ub002\u81a8\ucd97\u9634\uae8b\ud36f\u9f11\ub6e3\u18e8\u9f05\u6429\u7731\u0f82", "\udb1e\uddb1\ud8e1\udf2d\ud860\udfe7\ud8ee\udce5\u0b89\ud945\udd19\ud994\uddd4",
        58, 71210, -1990417845, -5047934359651949001L, 33086L, true, true, (char) 47605, (char) 36797,
        Double.longBitsToDouble(0x3fe0bc73583ade98L), Double.longBitsToDouble(0x3fe65f4670ff53c4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.ValueMarker:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 6, "\udb5b\udcc8\ud92f\udc38\uda10\udfb7\ud9f5\ude07\udbd0\udc1e", "\u56a7\ubb63\u3b01\uae2d\u3072\u4d39\u737f\u5926\ua91b\u1eb9\u93bd\u8597\u3dbe\u8762\ud28d\u9f11\ub15d\u6948", "\ud9c1\ude2a\udacc\udd68\udbad\udc7b\ud958\udd1e\ud816\udee2\uda30\udcce\ud860\udfe7\ud8ee\udce5\u0b89\ud970\udd3c\udb0b\udeeb\ud85e\udcf2\ud886\udc7e\uda51\udc6e\udb1b\udc0e\uda18\udf60\ud988\udf2d\ud878\uddcf\uda0f\udf93\ud9c2\ude5e\udac7\ude5d\u287f",
        16, 33663, 1342902640, -3854480437825658871L, 4374L, true, false, (char) 58106, (char) 5291,
        Double.longBitsToDouble(0x3fedc26fb1403813L), Double.longBitsToDouble(0x3fee1f0b6b67c3d2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.plot.ValueMarker:@?\0121=void |this=org.jfree.chart.plot.ValueMarker:@?\012",
        Z.run(T, 2, 5, 5, 2, "\ud9bf\udd61\udb5d\udcad\ud8df\udfbf\uda4c\ude77\ud9aa\ude80\ud991\udd92\ud96e\udda9\uda8b\udd5c\udab5\udcf9\ud83d\udf8d\ud8f4\udd8c\ud855\udf22\udbe1\udf8f\ud85b\udd36\udae7\udc80\udab4\ude7e\ud859\ude80\udb13\uddf1\ud9ae\ude37\ud803\udd10\udbed\ude37\u7a3c\udb43\udff0\ud8f4\ude09\u6178\u446e\ud802\ude16\udbc3\udf4c\ud8d6\uddb2\ud9a2\udfb0\ud99c\udc24\ud816\udeee\uda32\ude6d\ud860\udfe7\ud8ee\udce5\u0b89\udb16\ude2e\udbaa\udca6\ud891\udfee\udb9e\udecb\ud93f\ude08\uda17\uddfa\ud97c\udde2\u5c59\udbd0\udc24\ud9f2\ude1c\udb67\ude78\uda8c\uded6\ua520\udabd\ude43\ud970\udc14\ud8cd\ude08\udb67\udfac\ud965\uddec\udbca\udf18\udbee\udd29\ud875\udcd2\ud90b\udd5b\ud991\udc3f\udab3\udce8\udba0\uddaf\ud94c\udfdc\ud98d\uddc6\ud9e0\udebe", "\ua221\u792f\u4227\u6a4d\ub434\ud2f3\u79fc\u563d\u411c\uae8d\u6259\ud138\u3c39\ua294\u059e\u7885\u29ab\uc816\ub312\ud6b2\u489d\u06ab\ub293\u0f1a\u698d\u1818\u5b3d\ubff6\ubafb\u8c6c\ubd7e\u3750\u58cc\u3df0\u4337\u6a69\u909e\u5f31\u6ef8\ud319\u568a\ud106\u16b6\u5170\u2d81\u0f08\u6b40\u34e0\u524e\u689f\uabaa\ua485\ub6f2\u20b0\u16a2\u1636\u2046\u1613\u45f8\u833b\u0b39", "\uda96\udd1b\ud9d6\udf3d\ud946\udc6a\uda22\udfd1\ud82c\udf53\ub670\uda8c\udfcf\udacc\udf26\udb19\ude6d\udacc\udcd4",
        17, 17814, -1182734265, -2298458196083248141L, 3645L, true, false, (char) 20414, (char) 39746,
        Double.longBitsToDouble(0x3fc5b8eaa730998cL), Double.longBitsToDouble(0x3fb95172a6ca3880L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke,java.awt.Paint,java.awt.Stroke,float",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double",
    "M|org.jfree.chart.plot.ValueMarker|equals|java.lang.Object|new:org.jfree.chart.plot.ValueMarker:double",
    "M|org.jfree.chart.plot.ValueMarker|getValue||new:org.jfree.chart.plot.ValueMarker:double",
    "M|org.jfree.chart.plot.ValueMarker|setValue|double|new:org.jfree.chart.plot.ValueMarker:double",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke,java.awt.Paint,java.awt.Stroke,float",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double,java.awt.Paint,java.awt.Stroke",
    "C|org.jfree.chart.plot.ValueMarker|<init>|double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
