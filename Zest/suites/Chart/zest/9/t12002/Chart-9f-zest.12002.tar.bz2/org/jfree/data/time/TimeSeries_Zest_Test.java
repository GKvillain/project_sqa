package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimeSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u14c2\ub1d9\u4e8c\u0ca4\u5f24\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\uda1c\udc03\ud988\udca5",
        17, 78682, 2056597415, -7826026671508413060L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u13e7\u962a\u8ec8\u14c2\ub1d9\u4e8c\u0ca4\u5f24\u6495\u1f60\u3f95\u161a\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud847\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\uda5e\udd9c\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5\ud834\udf83\uda1c\udc03\ud988\udca5",
        17, 78682, 2056597415, -7826026671508413060L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 13, 11, "\ud889\udd76\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u14c2\ub1d9\u1d33\u6e3d\u6237\ub3f2\u1ec2\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\u3caa\ua140\u6da7", "\ud928\udc3a\udb42\udd5f\uda5a\udffc\ud9ee\udd00\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\udaa5\udf35\uda0b\udddb\uda1c\udc03\udb84\ude1c",
        43, 75401, 472760239, -7826026031558285956L, 18069L, true, false, (char) 49736, (char) 49988,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 7, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u14c2\u8567\000\u0bd9\u5f24\u6495\u1f60\ub1a8\u787b\u054d\uc90f\u3ba4\ubd56\ud5ea\000\000", "\ud928\udc3a\ud838\ude3c\udba2\udeff\u50ff\uda77\udcb7\ud9bb\udc0a\ud88b\udd88",
        19, 53018, -1643071333, 9096600706879081823L, -94191L, false, true, (char) 26800, (char) 55498,
        Double.longBitsToDouble(0x3fd7c9364191a404L), Double.longBitsToDouble(0x3fd355500952ea02L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 11, "\ud889\udd3b\u01b2\uda59\udee4", "\u4be2\u962a\u8ec8\u14c2\ub1d9", "\udb05\udeed\udb7c\udca2",
        37, 30890, -808658532, 8996135234994745544L, -15305L, true, true, (char) 52184, (char) 35951,
        Double.longBitsToDouble(0x3fdb54d8784665c6L), Double.longBitsToDouble(0x3fee6836473cc969L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 15, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8\udb45\udf54\uda91\udd14\ud99e\udddd\ud92b\ude26\ud8a6\udf49\uda7a\udf7f\udb02\udd1a\ud8ab\udf21\udab9\udcce\udb05\udeed\udb7c\udca2\ud8f6\udf6b\uda56\udc5f\udb47\udec4\ud9e6\udcb0\u4e3b\ud84a\udfe8\ud9dc\udf75\ud960\udeed\udbae\udfbd\uda66\udff7\ud8dc\ude60\udb46\udf12\ud92b\ude54\ud844\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\ud9bb\udc0a", "\u0607\u4c88\u0bc5\ua6aa\uc8a5\ua223\u8211\u28f0\ucd7b\u76f9\u026e\u5fe2\u20c5\u1a8e\u44ab\u91be\ua8fa\uce92\u2eeb", "\ud9a0\udc8b\ud940\ude9c\uda42\udfb7\ubcdf\uda6a\udf97\udb23\udd09\ud914\udf30\ud92d\ude3e\udae4\udc9e\udacd\udd36\udbe5\udd11",
        52, 8850, -1905272136, -4463220264429142676L, 69751L, false, false, (char) 8100, (char) 22256,
        Double.longBitsToDouble(0x3fe5935c5627fde7L), Double.longBitsToDouble(0x3fe22a2f21ef56e7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 13, 11, "\ud889\udd3b\ud983\uddb3\udb7b\udd70", "\u4be2\u962a\u8ec8\u89eb\ud097\u835b\u38c8\u9f51\u6495\u1053\ub47c\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud915\ude92\udba2\udeff\ud9ee\udd0b\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\uda1c\udc03\ud988\udca5",
        17, 78682, 2056597415, -4356578203200749795L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4eb9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 3, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u582f\u962a\u8ec8\u14c2\ub1d9\u4e8c\u8799\u5f24\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\ud8bf\udcad\ud8c4\uddc3\uda62\udd6a\udb3d\udc7b\ud9e2\uded5\ud970\udf09\uda1c\udc03\ud988\udca5",
        17, 78682, 2056597415, -7826026671508413060L, 18069L, true, false, (char) 49745, (char) 33865,
        Double.longBitsToDouble(0x3fe89780454a732bL), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 10, 2, "\ud889\udd3b", "\u7ac8\u0852", "\ud8a6\udf49\uda7a\udf7f\udb02\udd1a\ud8ab\udfed\udab9\udcce\udb05\udeed\udb7c\udca2\ud8f6\udf6b\udb94\udcbd\udb47\udec4\ud9e6\udcb0\ud84a\udf36",
        28, 44897, 282888687, -8860345194784553114L, -55933L, true, true, (char) 31299, (char) 52609,
        Double.longBitsToDouble(0x3fe906f1e29998d4L), Double.longBitsToDouble(0x3fedb11fbd094979L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 4, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u14c2\ub1d9\u4e8c\u0be7\u5f24\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\u359b\u58dc\u0efa", "\ud928\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b\uda9a\udde9\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5",
        48, 66015, -1191369771, -6272413329517419086L, -78696L, true, true, (char) 51626, (char) 49736,
        Double.longBitsToDouble(0x3fecc125886ef008L), Double.longBitsToDouble(0x3fd4a879c533b53aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 13, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\ud2ff\u962a\u8ec8\u6444\uc372\u9037\u0ca4\u5f24\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\ud817\udf92\ud895\uddbb",
        17, 78682, 2056597415, -7826026671508413060L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 15, 9, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u14c2\ub1d9\u4e8c\u0ca4\u5f24\u66a0\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\ud9bb\udc0a\uda98\udf4e\uda61\udda3\udb33\udd0e\ud9e2\uded5\uda0b\udd96\uda1c\udc03\ud988\udca5",
        17, 78682, 2056597415, -7826026671508413060L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a", "\udb02\udd1a\ud8ab\udfed\udab9\udcce\udb05\udeed\udb7c\udca2\udb85\uddb3\udb94\udcbd\udb47\udec4\ud9e6\udcb0\ud84a\udf36\u47a1",
        37, 87687, -2062959875, 5564768425091492277L, -92473L, false, true, (char) 30338, (char) 787,
        Double.longBitsToDouble(0x3fed10a4d09b1d05L), Double.longBitsToDouble(0x3fe134f0855f7e3dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 12, 3, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\000\u957b\u8ec8\u14c2\ub1d9\u4e8c\ubfcb\000\000\u1e83\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud844\udd60\udba2\udeff\ud9d6\uddeb\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\uda1c\udc03\ud988\udca5",
        17, 78682, 12199, -7826026899141679748L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 11, 14, 6, "\ud889\udd3b\ud821\udc9d\ud83b\udcf1\udb5e\uddee\uda91\udd14\ud99e\udddd\uda28\ude64\ud8a6\udf49\uda7a\udf7f\ud83c\ude87\udb94\ude21\udab9\udcce\udb05\udeed", "\uaefd\ud0c9\u04fe\u4323\u3ba4\u90e4\ucc23\u297d\u782c\u4582\u442d\uc4d5\uc331\uc917\ua4d8\u353a\ub6ca\ubf06\ucb10\u0607", "\uda1c\udc03\ud988\udca5\udaf7\udc2d\ud928\udd18\ud843\udeb9\ud9dc\udf4a\ud85e\udec6",
        47, 15341, -643345239, 2644007778687410072L, 74774L, true, false, (char) 61943, (char) 56825,
        Double.longBitsToDouble(0x3fe964ada4b407ffL), Double.longBitsToDouble(0x3fc812cc3c8908e8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 13, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2", "\uda7a\udf7f",
        24, 91918, 1490891, -6640276175522281362L, -72222L, false, true, (char) 33057, (char) 11680,
        Double.longBitsToDouble(0x3fe44949e5298acfL), Double.longBitsToDouble(0x3fdefb2265fa21b8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 5, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8\udb5e\uddee\uda91\udd14\ud99e\udddd\ud92b\ude26\ud8a6\udf49\uda7a\udf7f\udb02\udd1a\ud8ab\udfed\udab9\udcce\udb05\udeed\udb7c\udca2\ud8f6\udf6b\udb94\udcbd\udb47\udec4\udbab\udc2b\ud84a\udf36\u47a1\uda00\udc92\ud960\udeed\ud8f1\udc8d", "\u442d\uc4d5\uc331\uc917\ua4d8", "\ud88b\udd88\udb6c\udf4f\udb33\udd57\ud9e2\uded5\udb7d\udc94\uda1c\udc03\ud988\udca5\udaf7\udc2d\ud928\udd18\ud941\udee0\ud9c9\udfce\ud85e\udec6\udb88\uddd5\ud8c1\udc1a\ud858\ude09\uda2e\udd3a\ud837\udea7\udaf6\udd55\ud8c2\udebf\udad0\udd5a\ud890\udf62\ud83e\udf5d\ud91b\uddc5\udb38\udcd0\ud8f3\udd91\ud8b1\ude41\ud972\udcd1\udaeb\udf7c\udacf\udfe2\udbef\ude6d\ud8ae\udd69\ud828\udf82\ud82c\udf30\uda32\udefd\ud81c\udd44\ud8a3\udf72\ud8bd\udd86\uda99\udef5\ud99b\udd64\ud8fb\udd00\uda2f\ude0b\ud866\udfb3\udb20\ude57\ud8ff\udc72\udb3b\udcb4\ud89f\udc30",
        15, 90509, 288730153, -8763531006606975617L, -2737L, false, false, (char) 32932, (char) 38487,
        Double.longBitsToDouble(0x3fec57d7ea201640L), Double.longBitsToDouble(0x3fe3f525a1dcf101L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 9, 11, "\udbcd\uddfa\ud983\ude02\uda8b\uddf8", "\u4be2\u103f\u8ec8\u14c2\ub1d9\u4e8c\ube8b\u5f88\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\u9cea\ua140", "\ud939\udcd9\ud928\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b",
        46, 77934, -1368511223, 1484774614235421602L, 56122L, true, true, (char) 16877, (char) 41543,
        Double.longBitsToDouble(0x3fdb2a8f3f4e7360L), Double.longBitsToDouble(0x3fe1abd4ad7c9364L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 11, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u14c2\ub1d9\u4e8c\u0ca4\u5f24\u6495\u1f60\u03a9\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\u03e0", "\ud92d\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\uda1c\udc03\ud988\udca5\udaf7\udc2d\ud928\udd18",
        10, 1173, -771611268, 6179973090638941493L, -8079L, false, true, (char) 36982, (char) 56550,
        Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL), Double.longBitsToDouble(0x3f81bf2a8ac1ee40L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 13, 11, "\ud889\udd3b\ud97e\udcb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u14c2\ub0cd\u3f68\ud37c\uc6f9\u6495\u1f60\u6a4d\u3891\u75c1\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\udbb9\udee4\ud844\udd60\udba2\udeff\u6101\udba1\udc0d\ud9ba\udf80\udb34\udcf4\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\uda1c\udc03\ud988\udca5",
        17, 78682, 2056597415, -7826026671508413060L, -8079L, false, false, (char) 60195, (char) 30624,
        Double.longBitsToDouble(0x3fe6445a2a9e6f5aL), Double.longBitsToDouble(0x3fead1aca9c26c1fL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 15, 16, 4, "\ud889\udd3b\udaa7\udf45\ud9a3\udc88", "\u4be2\u962a\u0761\u149c\ub1d9\u4e8c\u0ca4\u5f24\ub1a8\uc9d8\ub1a8\u787b\u054d\u8ea7\uaaea\u90e4\u94cc\u1f8b\ub348\u2605\u442d\uc4d5\uc331", "\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb",
        28, 96667, 2117967398, -6550400588797797163L, -75883L, false, true, (char) 32458, (char) 8952,
        Double.longBitsToDouble(0x3fc52ea03c456cdcL), Double.longBitsToDouble(0x3fecc125886ef008L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\u962a\u8ec8\u6720\000\u5509\u0ca4\u5f24\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u0089\000\000\000\000", "",
        4, -1000, 1044131584, -7434212493838196071L, -100000L, false, false, (char) 0, (char) 47103,
        Double.longBitsToDouble(0x3fe134f08000003dL), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 13, 12, 10, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\uc3e5\ubd39\u8ec8\u14c2\u3172\u78d8\u6f16\u8a1a\u6495\u1f60\ub1a8\u7f97\ucd84\ub397\u3ba4\u90e4\ud5ea\ua140\ua6a9", "\ud928\udc13",
        59, 93669, -575021024, -3722271936697374227L, -59387L, true, false, (char) 54841, (char) 36944,
        Double.longBitsToDouble(0x3fdbb7e3d9ab4a30L), Double.longBitsToDouble(0x3fd4fb8f815951e6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 15, 9, "\ud889\udd3b\ud950\udcf5\uda8b\uddf8", "\u50d4\u0ce5\ub08d\u14c2\u433a\u886b\u0ca4", "\ud90c\udc25\udb9a\udd41\uc516\ud9d1\ude29\ud95d\udd22\uda09\ude03\ud9b9\ude16\ud8fb\udf03\udafa\udec8\udbc2\udfca\udb40\uddb2\ud932\udf3c\ud810\udc2a\ud847\udd60\udba2\udeff\ud9ee\udd0b\uda77\udcb7\uda5e\udd9c\uda98\udf4e\udb6c\udfdb\u662b\udadc\udce4\ud9e6\ude33\ud9c8\udd81\udb87\udf89\udbc6\udfd1\ud8eb\udfdf\ud885\udebb\ud9c9\udfce\ud85e\udec6\udb88\udde2\udac7\udd9e",
        47, 46728, -1136529768, -8674882388542794422L, 99225L, true, false, (char) 49370, (char) 25631,
        Double.longBitsToDouble(0x3fd6e59b85a7ad3cL), Double.longBitsToDouble(0x3fd28994d36fbf72L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 11, 4, "\ud889\udd3b\ud983\uddb3\udb1b\udf5f", "\u4be2\u85af\ua30d\u14c2\u8567", "\udb05\udeed",
        -1, 70597, 1205365890, -3473161946476793515L, 95171L, true, true, (char) 35348, (char) 4316,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fa199003cd06c80L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 7, "\ud889\udd3b", "\u0464\u0852\u4be2\u962a\u8ec8\u14c2\u8567\000\u0bd9\u5f24\u6495\u1f60\ub1a8\u787b\u054d\u39c3\u61af\u97b5\ud5ea\000\000\u8b42\u442d\u04d5\ud04c\uc9c1", "\ud9bb\udc0a",
        32, 78029, 486874018, -7056937638112158170L, 23543L, false, false, (char) 32151, (char) 12498,
        Double.longBitsToDouble(0x3feb52e91978f89aL), Double.longBitsToDouble(0x3f9589aa7177bb80L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 14, 0, "", "\u0218", "\000",
        50, 29048, 34516, 60517121845821440L, -63999L, false, false, (char) 1118, (char) 0,
        Double.longBitsToDouble(0x3fd0000002ab9f98L), Double.longBitsToDouble(0x3ecb000000000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 15, 4, "\000\000\uda83\udd01", "\000", "",
        -5, -1000, -258871082, -6334664948796781476L, 31072L, false, false, (char) 18392, (char) 32853,
        Double.longBitsToDouble(0x3fc90f9b180000f0L), Double.longBitsToDouble(0x3fd298acf3df644cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 3, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u1041\u0b25\u8ec8\u14c2\ub1d9\u4e8c\u8799\u25ca\u6495\u1f60\u6382\u787b\u054d\ub9a7\u22c1\ub8e5\ud5ea\u7446\ub329", "\ud928\udc3a\ud988\udfc6\uda82\udc48\ud9f4\udd82\ud8b4\udde7\ud9cc\udd04\ud858\udceb\uda62\udd7f\uda71\udf15\u3531\udace\uded2\uda1c\udc03\ud957\udf6c",
        14, 78682, 2056597415, -7736517629938545905L, 18198L, true, false, (char) 49745, (char) 33865,
        Double.longBitsToDouble(0x3fe89780454a732bL), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 12, 0, 0, "\ud889\udd3b", "\u0464\u0852\u1926\000\u392f\u14c2\000\000\u8fb3\u5f24\u486e\u1f60\ub1a8\u77df\000\u08df\u3ba4\u90e4\ud5ea\u7308\u00a0\000\u7009\uc4d5\uc331\u2f55", "",
        -5, 32920, -1986568091, 2091151018511349915L, -80193L, true, false, (char) 248, (char) 0,
        Double.longBitsToDouble(0x3e48d5ea54000000L), Double.longBitsToDouble(0x3fd7c93640000004L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 10, 5, "\ud889\udcd9\ud983\uddb3\uda8b\uddf8", "\u93d8\u962a\u7eae\u1217\u2e35\u7f08\u8798\u5f24\u0270\u1f60\ub1a8\u7823\u45a6\ub9bd\u3ba4", "\udbe1\ude1c\uda74\udf98\udadb\udcb4\ud939\udc89\uda87\udeaa\udb0e\udfb5\udba2\udedd\ud9ee\udd0b",
        46, 38126, -1604461801, 5784648919615357444L, -9414L, false, true, (char) 16877, (char) 41543,
        Double.longBitsToDouble(0x3fdb2a8f3f4e7360L), Double.longBitsToDouble(0x3fe1abd4afcb70a0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 2, "\ud889\udd3b\ueff0\ud93f\ude53", "\u4be2\u962a\u8ec8\u4b46\ub1d9\u4e8c\u0ca4\u6813\u7204\u1f5e\u3ee8\u787b\u5efc\ub9a7\u75a5\u0901", "\ud940\udc3e\uda61\udeab\ud837\udd07",
        42, 78191, -566481067, -7434211956363894119L, -33906L, true, true, (char) 41043, (char) 49531,
        Double.longBitsToDouble(0x3fe437d6a133c186L), Double.longBitsToDouble(0x3fec0062677854c5L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 12, 2, "\ud889\udd3b", "\ub283", "\ud92b\ude26\ud8a6\udf49\uda7a\udf7f\udb02\udd1a\ud8ab\udfed\udab9\udcce\udb05\udeed\udb7c\udca2",
        31, -1000, -808658532, 8996135234306879688L, -15305L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd00000084665c6L), Double.longBitsToDouble(0x3fc9a0d900000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 4, 4, "", "", "\uda91\udd14",
        51, 35687, -424573753, 5710712573918960758L, -17838L, false, false, (char) 60487, (char) 25438,
        Double.longBitsToDouble(0x3fc0478ac6711f60L), Double.longBitsToDouble(0x3fd55cfcc190f9b0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 13, 11, "\ud8c1\udee8\ud983\uddb3\uda8b\uddf8\ua936\uda5a\ude8a\ud99e\udddd\ud92b\ude26\ud9a1\udd4c\uccf8", "\u0ca4\u5f24\u0d48\u0bfe\ub1a8\u787b\u2b39\u2599\u3ba4\u90e4\u8fff\ua140", "\ud939\udc89\ud928\udc3a\ud844\udd60\udba2\udeff\ud9ee\udd0b",
        46, 77934, 1785605385, 7482598311686642521L, 56122L, true, true, (char) 16877, (char) 41543,
        Double.longBitsToDouble(0x3fdb2a8f394e7360L), Double.longBitsToDouble(0x3fe37334fd7c9364L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 14, 11, "\ud889\udd3b", "\u0464\u0852\u4be2\u962a\u8ec8\u14c2\ub1d9\u4e8c\u0ca4\u5f24\u66a0\u1f60\ub1a8\u44a2\u05a4\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348\u2605\u79d0\u6b73\u9bba\uc917", "\ud8c9\udc57\uda98\udf77\uda61\udda3",
        20, 96667, 2117967398, -6550400588784821035L, -75883L, false, true, (char) 32458, (char) 8952,
        Double.longBitsToDouble(0x3fc52ea03c456cdcL), Double.longBitsToDouble(0x3fecc125886ef008L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 8, 13, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8\udb5e\uddee\ue407", "\ub161", "\ud8ab\udfed\ubfcb\000\000\ud8f6\ude8e\udb94\udcbd\udb47\udec4\ud9e6\udcb0\ud84a\udf36\u47a1\uda00\udc92\udaf6\ude98\udbae\udfbd\uda66\udff7",
        58, 87563, 1260334029, -7049207484032209067L, -92473L, false, true, (char) 59009, (char) 18705,
        Double.longBitsToDouble(0x3fef28a3709beedeL), Double.longBitsToDouble(0x3fe134f0815f7e3dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 4, 12, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\000\u957b\u8ec8\u14c2\ub1d9\u4e8c\ubfcb\000\u1ed0\u1e83\ub1a8\u787b\u9842\u4ac4\u6e3e\ub0c9\u30e0\ua0b8\ub348", "\udb00\ude05\ud83d\udc4d\ud8ae\udefb\uda05\udc05\uda77\udcb7\ud9bb\udc0a\ud88b\udd88\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\ud8c4\uddd7\ud863\ude81",
        31, 78727, 12199, -7826026899141679748L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022c643ce0L), Double.longBitsToDouble(0x3fd99da9d53cdeb4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 16, 16, 11, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\000\u957b\u8ec8\u14c2\ub1d9\u4e8c\ubfcb\000\000\u1e83\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud928\udc3a\ud844\udd60\udba2\udeff\ud9d6\uddeb\uda77\udcb7\ud9bb\udc0a\ud938\udd9f\udb3f\udcf6\udb33\udd57\ud9e2\uded5\uda0b\udd96\uda1c\udc03\ud988\udca5",
        17, 78682, 117452711, -7826026899141679748L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc022a543ce0L), Double.longBitsToDouble(0x3fe4ced4ea9e6f5aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 7, 12, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u2861\u1c14\ua9ab\u136e\ub1d9\ub6d8\ubfc4\u902a\000\u1e83\u6290\ua486\u054d\ub9a7\u3ba4\u90e4\ua04a\u0b8d\ub348", "\ud928\udc3a\ud844\udd60\ud9ee\udc27\ud9d6\uddeb\udb26\udc0f\ud9bb\udc26\ud88b\udd88\udb6c\udfdb\udb4f\udd32\ud9e2\uded5\uda0b\ude60\uda1c\udc03\ud988\udca5",
        17, 78682, 12199, -7826026896843456132L, 18069L, false, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc020e5c3ce0L), Double.longBitsToDouble(0x3fe44695c29e6f12L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 12, 13, 11, "\udb29\udda2\ud9d9\udd92\ud868\udf93\udb4f\udf27\uda91\udd0d\ud99e\udddd\ud986\udc7a\ud8ab\ude67\uda7a\udf7f", "\ucfe5\uaac7\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u896b\ud5b3\ub964\u4f11\uc62b\u0deb\u827b\ud30b\u7a18\u8bfa\u4bea\uaf0f\u7bb5\uac18\ubbdd\uc732\u41a4\uc5c6\ua35b\uc901", "\uda24\ude52\uda94\udd6d\ud947\udd90\ud8bf\udf8b\udb35\udd93\ud8bc\ude37\ud8a6\udcb2\ud8cc\udfec\ud831\uddb3",
        28, 25111, -1858872200, -932256829721383288L, -6814L, false, false, (char) 33889, (char) 7760,
        Double.longBitsToDouble(0x3fe9cb51c01de7e0L), Double.longBitsToDouble(0x3fd9d020ecf9ce60L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 2, 11, "\udbcd\uddfa\ud983\ude02\uda8b\uddf8", "\u4be2\u103f\u8ec8\u14c2\ub1d9\u4e8c\ube8b\u5f88\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u8c74\u90e4\u9cea\ua113", "\ud939\udcd9\ud928\udc3a",
        59, 93669, -1730912480, 2591789258565566390L, -33093L, false, true, (char) 54687, (char) 15414,
        Double.longBitsToDouble(0x3fd5f7e3d9ab4a30L), Double.longBitsToDouble(0x3fd4fb8f8b6551e6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 6, 16, "\udbcd\uddfa", "\u89d4\ud765\u4be2\u103f\u13d5\u3104\uc328\u1f6c\ua30e\u5f88\u6495\u1f60\ub1a8\u2ce1\u054d\ub9a7\u3ba4\u90e4\u9cea\ua140\ub348\u2ac1\u857d\uc4d5\uc331\uc917", "\ud9bb\udc0a\ud96e\udc3a\udb6c\udfdb",
        16, 45829, 2117967398, -6550400588784821035L, 7666L, true, true, (char) 55690, (char) 23290,
        Double.longBitsToDouble(0x3fdbded8a8d43b9eL), Double.longBitsToDouble(0x3fe6fac2dde0bf7cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 1, 11, "\udbcd\uddfa\ud983\ude02\uda8b\uddf8", "\ua8bf\u3057\u3099\u457b\u0271\u6b69\u3df3\u8a3f\u6495\u6256\u8830\u0b9b\u0548\uc7df\u3b76\u90fa\u9cea\u3265\u1969", "\ud928\udc3a\ud844\udd60\udba2\udeff\udb5b\ude24\ud933\ude88\ud9ba\udfbf\ud96e\udc3a",
        19, 52962, -1643071333, 9096600706879081823L, -94191L, false, true, (char) 32599, (char) 45294,
        Double.longBitsToDouble(0x3fd7c93645894ceaL), Double.longBitsToDouble(0x3fde0c4cfd96043aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 15, 15, 16, "\udbcd\uddfa\ud983\ude02\uda8b\uddf8", "\u4be2\u103f\u8ec8\u14c2\ub1d9\u4e8c\ube8b\u5f88\u6495\u1f60\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\u9cea\ua140", "\u3f86\ud938\udc49\ud844\udd60\udba2\udeff\ud9ee\udd0b",
        46, 77934, -1368511223, 1484774614235421602L, 56122L, true, true, (char) 16877, (char) 41543,
        Double.longBitsToDouble(0x3fdb2a8f3f4e7360L), Double.longBitsToDouble(0x3fe1abd4ad7c9364L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 12, 10, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\uc3e5\ubd39\u8ec8\u14c2\u3172\u78d8\u6f16\u8a1a\u6495\u1f60\ub1a8\u7f97\ucd84\ub397\u3ba4\u90e4\ud5ea\ua140\ua6a9", "\ud928\udc13",
        38, -1000, -575078400, -3722271936697374227L, -59387L, true, false, (char) 54841, (char) 61994,
        Double.longBitsToDouble(0x3e40000000000000L), Double.longBitsToDouble(0x3fd4fb8f815951e6L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 11, 12, 12, "\ud82c\udc0d\ud8ed\udd60", "\u57d4\u1041\u0b25\u8ec8", "\ud8ab\udfed\ud9c0\udf28\u81b6\udb7c\udca2\udb51\ude59\udbb6\ude96\udb47\udec4\ud9e6\udcb0\ud84a\udf36\udad3\udf95\uda40\udc92\ud91f\udecd\udaab\udf16\uda66\udfd8\udadb\udcb4\ud939\udc89",
        14, 6910, -364035696, -8442991911537643333L, -51558L, true, true, (char) 9216, (char) 50401,
        Double.longBitsToDouble(0x3fcab4ac9828afe0L), Double.longBitsToDouble(0x3fdb2a8f3f4ff160L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 0, "\ud889\udd3b", "\ub39b\u0892\u1926\000\u392f\u14c2\000\000\u8fb3\u5f24\u486e\u1f60\ub1a8\u77df\000\u08df\u3ba4\u90e4\ud5ea\u7308\u00a0\000\u7009\uc4d5\uc331\u2f55", "",
        -5, 32920, -1986568091, 2091151018285709467L, -80193L, true, false, (char) 248, (char) 0,
        Double.longBitsToDouble(0x3e48efc390000000L), Double.longBitsToDouble(0x3fd7c93640000004L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 0, "\000", "\u6c0d", "\ud946\udc02\udaef\ude77\u86d4\u4900\000\000\000\000",
        42, -1000, 13424896, 0L, 31072L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3df1800000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 13, 11, "\ud8c1\udee8\ud983\uddb3\uda8b\uddf8\ua936\uda5a\ude8a\ud99e\udddd\ud92b\ude26\ud9a1\udd4c\uccf8", "\u0ca4\u5f24\u0d48\u0bfe\ub1a8\u787b\u2b39\u2599\u3ba4\u90e4\u8fff\ua140", "\ud939\udc89\ud928\udc3a\ud844\udd60\udb7f\udf7d\uda8f\udcaf",
        13, -175, 1785605385, 7482598311686642521L, 56122L, true, true, (char) 16877, (char) 41543,
        Double.longBitsToDouble(0x3fdb2a8f394e7360L), Double.longBitsToDouble(0x3fe37334fd7c9364L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 11, 11, 12, "\ud889\udd3b", "\u0464\u0852\u4be2\u962a\u8ec8\u14c2\ud1d9\u4e8c\u0ca4\ud025\ubf94\u1e8b\uaefa\u44a2\u816d\uc763\u8a18\u90e4\ud5ea\ua140\ub348\ub02c\u98f4\ub430\u9b9d\uc917", "\ud8c9\udc57\uda98\udf77\uda6f\udea3",
        20, 28667, 2122873989, -6550400585647481643L, -75883L, false, true, (char) 43466, (char) 45674,
        Double.longBitsToDouble(0x3fac9b437115bc70L), Double.longBitsToDouble(0x3fecc125886ef008L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 12, 12, 16, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u2861\u1c14\ua9ab\u136e\ub1d9\ub6d8\ubfc4\u902a\000\u1e83\u6290\ua486\u054d\ub9a7\u1bb0\u90e4\ua04a\u0b8d\ub348", "\ud928\udc3a\ud844\udd60\ud9ee\udc27\ud9d6\uddeb\udb26\udc0f\ud9bb\udc26\ud88b\udd88\udb6c\udfdb\udb4f\udd32\ud9e2\uded5\uda0b\ude60\uda6f\udfe2\ud9b2\udc41",
        17, 78682, 12199, -7826026896843456132L, 18069L, false, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc020e5c3ce0L), Double.longBitsToDouble(0x3fe44695c29e6f12L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 13, "\ud889\udd3b\ud983\uddb3\uda8b\uddf8", "\u4be2\ubb29\u8ec8\u14c2\ub1d9\u4e8c\u8f9a\uc06c\uc427\u1c3c\ub1a8\u787b\u054d\ub9a7\u3ba4\u90e4\ud5ea\ua140\ub348", "\ud8fd\ude5f\ud844\udd60\udba2\udeff\ud9ee\udd0b\ud86c\uded2\udbe5\udc1a\ud88b\ude52\udb6c\udfdb\udb33\udd57\ud9e2\uded5\uda0b\udd96\uda1c\udc03\udbd2\ude3b",
        25, 66240, 1139171710, -7807834800655293060L, 18069L, true, false, (char) 49736, (char) 33865,
        Double.longBitsToDouble(0x3fbbbc0202c43ce0L), Double.longBitsToDouble(0x3fe81b62fa9e6f5aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addAndOrUpdate|org.jfree.data.time.TimeSeries|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clear||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|equals|java.lang.Object|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
