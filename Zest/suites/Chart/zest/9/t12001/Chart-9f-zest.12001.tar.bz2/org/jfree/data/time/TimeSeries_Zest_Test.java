package org.jfree.data.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class TimeSeries_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\u0327\u81f8\u5091\u374c\u75ed\u657f", "\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud871\udd47\udb28\udc36\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f",
        47, 37966, 384694753, -8102065810795285568L, 20547L, true, false, (char) 10477, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5\ue8cd\udb01\udf40\ufbf9", "\u0327\u2fbf\u5091\uadbb\u75ed\u657f", "\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udd8e\u00d0\000\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f",
        47, 37966, 384694753, -8102065810795285568L, 20547L, true, false, (char) 10477, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9\ud9d9\udce3\udac2\udc9f\udbe0\udcba\ud862\udd86\udbca\udd2c\u5ab0\ud949\udcf6\ud8e3\udfdf\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud871\udd47\udb28\udc36\ud979\udfff\ud84e\udfa7\udaf5\udcf1\ud981\udc91\ud859\udd2f\udb77\udedc", "\u88ce\u94e3\u9166\u59d3\u176c\ua447\u6478\uae0c\u9081\u8558\u9afd\ubbb2\u4d2c\u1c3c\u60b8\u10a4\u5d34\u0d6f\u341b\uc69c\u729d\u10ea\ubbf1\u2b81\u5f47\u25b3\u07f3\u00dc\u69ff\u3e55\u254c\ud6b2\u9980\u4bf3\u5484\ub788\u3c70\uaf41\u5d51\uc772\ubb55\u90c9\ucef1\u6831\u1823\u2fc3\u44ec\u28e8\ub7af\ud619\u9986\u4403", "\ud807\udc66\udb90\udc2b\ud860\udebf\ud85b\udc40\udb42\udf0f\uda39\ude0e\udb75\udef3\udb49\udead\ud816\udf67\ud983\udd35\ud88e\udfac\ud846\ude5b\uda3f\udff0\ud858\udf06\udac1\udc59\udb3a\udf42\udbf3\udf94\uda85\ude54\ud81f\ude45",
        57, 80091, -1292585741, -3512160958498843298L, 56264L, false, false, (char) 29610, (char) 4938,
        Double.longBitsToDouble(0x3fe0e8d3c64dc512L), Double.longBitsToDouble(0x3f8cd4f21cbb1300L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\u0327", "\u5ab0\ud949\udcf6\ud8e3\udfdf\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud9dc\udc04",
        47, 19966, -1290925616, -7487076578560141245L, -81267L, true, true, (char) 61292, (char) 21980,
        Double.longBitsToDouble(0x3fe090b76bc08f8fL), Double.longBitsToDouble(0x3fe482c5a91dc5a5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\ua668\u9c96\u5091\u374c\u75ed\u457f", "\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud871\udd47\udbcf\udea9\uda5b\udedc\ud9e7\udefc\udaff\udc0f\u03fc\ud84a\ude45\udb77\udedc\udac2\udc99",
        11, 67802, 1488303040, -4204841909315032803L, -35479L, false, true, (char) 24020, (char) 39383,
        Double.longBitsToDouble(0x3fea0a51b1e3ffcbL), Double.longBitsToDouble(0x3fdd7002deabca34L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 15, "\udb8a\udd4f\ud98b\udf08\udb21\udc87\ufbf9\ud9ac\udfad\uccee\udac6\uddc3\udb8c\udd42\ud8ce\udceb\ud933\udefd\ud949\udd29\udb8c\udfb3\u66d7\ud8d2\udf24\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud871\udd47\udb28\udc36\udbe6\udc8d\ud84e\udfd2\udafe\udc89\udb56\ude35\ud8ad\uddb9\udb77\udedc\udac2\udc99\ud988\udd85\ud833\udc0c\udae0\uded7", "\u92ee\uc804\u14dc\ucbb1\ubbd8\u9cfd\u54f7\u5434\ua99a\ub476\u25aa\u2965\u4c8e\ub17d", "\ud912\udc38\uda60\udef7\udaf9\udc57\ud80b\udd1b\udb02\udc89\udaa1\udc1a\udadd\ude95\uda26\udf1a\udbc6\udf02",
        38, 69080, 2076287810, 582950211482486386L, -27904L, false, false, (char) 52033, (char) 49532,
        Double.longBitsToDouble(0x3fe752bb375332bfL), Double.longBitsToDouble(0x3fbc858a6ccfc018L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 13, 16, "\ud8b4\ude6f\ud888\ude2d\udb21\udc5f", "\u3d74\u9910\u81f8\u3402\u29be\u75c8\u657f\u339c\ua900\u7246\u5978\ucf4b", "\udb28\udc36",
        6, 57169, -1027809485, 3271002615093414189L, 1842L, true, false, (char) 32932, (char) 34725,
        Double.longBitsToDouble(0x3fd441b35c467e36L), Double.longBitsToDouble(0x3fbf9f6ecb886f10L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 11, 16, "\uda47\udeeb\uda06\udfbf\udb21\udc87\ufbf9", "\u0327\ua0d6\u5091\uc0a5\u7b6e\u981e", "\ua680\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\udbc9\udc73\udaa4\udd37\udac1\uddef\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f",
        14, 96232, -1045539920, -8102065721490002496L, 17791L, true, false, (char) 44268, (char) 15021,
        Double.longBitsToDouble(0x3fced150a232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\udafd\udcf2\ud99e\ude44\ud918\udd84\ufbf9", "\u4800\u1001\u5091\u374c\u75ed\u657f", "\ud96b\ude80\ud9dc\udc04\uda9b\udef2",
        41, 55384, -656338299, 2361743098335969377L, 29505L, false, false, (char) 17231, (char) 48965,
        Double.longBitsToDouble(0x3fd1dc5a546f9534L), Double.longBitsToDouble(0x3f8259c844be5d00L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 15, 7, 3, "\uda34\udd32\ud98b\udf95\udb21\udc87\ufbf9", "\u0327\ud2ba\u5091\u374c\u75ed\u657f", "\ud96b\ude80\ud944\udc17",
        51, 19966, -1290925616, -2818951528767383338L, -81267L, true, true, (char) 12653, (char) 21980,
        Double.longBitsToDouble(0x3fe093076bc08f8fL), Double.longBitsToDouble(0x3fe482c5a91dc5a5L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda44\udef5", "\u2223\u5021\u3d74\u0327\u81f8\u5091\u374c\u75ed\u657f\ub090\ua900\u7246\u5978\ucf4b\u3198", "\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f\u0091.\udbb2\udf3a\udaa9\udf71\ud924\udcfa\uda78\udf1f\ud97f\uddf7\ud8f3\udcdc\ud8fa\udfa6",
        25, 65486, 1245114508, -14857420793716253L, -7438L, true, false, (char) 42268, (char) 7449,
        Double.longBitsToDouble(0x3fdbfec5742d62a6L), Double.longBitsToDouble(0x3fef626ad1b50ec6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 12, 16, "\uda0d\udd7a\000\000\000", "", "\000",
        37, 65996, -1465402107, 1920540023971389696L, -94484L, false, false, (char) 39524, (char) 17957,
        Double.longBitsToDouble(0x3fe42d9870d6d8e1L), Double.longBitsToDouble(0x3fe80806373300abL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 12, 16, "\udba2\ude7f\ud8ca\ude50\udb21\udc87\ufbf9\ud9d9\udce3\u28bb\ud80e\udd98", "\u374c\u75ed\u657f\ub090\ua900\u7246\u5978", "\ud88a\udca2",
        41, 41166, -1146392831, -811528421607923574L, -94379L, false, true, (char) 21980, (char) 50612,
        Double.longBitsToDouble(0x3fee047c7e9058b5L), Double.longBitsToDouble(0x3fd1dc5a546f9534L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 12, 10, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\u0327\u8292\u02a4\u1f2a\u4327\u657f", "\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud871\udd47\udb2d\udd36\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f",
        47, 37966, 384694753, 7606489689473020956L, 20547L, true, false, (char) 10477, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 12, 15, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\u0327\u81f8\u5091\u374c\u75ed\u657f", "\ud96b\ude80\ud9dc\udc04\ud8b7\udcc0\ud9e7\udfbd\ud9c6\udf6a\ud9fb\udccf\ud9f4\udcc2\uda3c\uddf7\udafe\udf96\udb56\ude38\ud859\udd2f",
        47, 37966, 384694753, -8102065813236903232L, 20547L, false, false, (char) 10253, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 10, "\000\000\udb21\udc87\udb2c\ude70", "\000", "",
        22, -1000, -1465402107, 1920540023971389929L, -100000L, false, false, (char) 0, (char) 17749,
        Double.longBitsToDouble(0x3e1adb1c20000000L), Double.longBitsToDouble(0x3fe809063733bbabL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 12, 16, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\ucc94\u81f8\u5091\u374c\u75ed\u657f", "\udbe2\udcdf\ud9dc\udc04\uda9b\udef2\udb7d\udda0\ud8ae\ude47\ud9fb\udeaf\udad3\ude22\ue54e\ud890\ude7f\udb56\uddbb\ud859\udd2f",
        47, 37966, 384694753, 7750604877548829659L, 20547L, true, false, (char) 10477, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 12, 16, "\ud913\udf5d\uda4c\udeda\udb2a\udd87\ufbf9", "\u0327\u81f8\u776d\u37b2\u75ed\u657f", "\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud8ae\udf46\udb27\udff5\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f",
        47, 37966, 384694753, -8102065810795285568L, 20547L, true, false, (char) 10477, (char) 60144,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5", "\uc764\u5021\u3d74", "\ud935\udd5f",
        52, 39725, -1465402107, 1920540023971389929L, -94484L, false, false, (char) 39524, (char) 1829,
        Double.longBitsToDouble(0x3feb93ef80d6d8e1L), Double.longBitsToDouble(0x3fe809063733bbabL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 11, 12, 2, "\uda44\udef5\ud98b\udf95", "\u5021\ubf8e\u9e1c\u81f8\u5091\u374c\u75ed\u657f\ub090\ua900\u0d00\u4590\u90e2\u752a\ub69d\u3427\u7fae", "\udb56\ude38\ud859\udd2f\udb77\udedc\udac2\udc99\udbb2\udf3a\udaa9\udf71\ud924\udcfa\uda78\udf1f\ud97f\uddf7\ud8f3\udcdc\ud8fa\udfa6\uda86\udce1\ud905\udfe4\uda7d\udceb\udb87\udf3d\udb7f\udd65\ud839\udd13\udaac\udef6\ud95f\udeb2\ud9a8\udfec\udb8f\udc4c\udbe4\uddea\uda3c\ude44\uda51\udcb5",
        17, 12480, -337683317, -1761212688230419835L, 27318L, false, true, (char) 34781, (char) 17906,
        Double.longBitsToDouble(0x3fd2dfee811019daL), Double.longBitsToDouble(0x3fe55edf1d16b333L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 13, 16, 16, "\uda44\udef5\ud98b\udeef\udb21\udc87\ufbf9", "\u0327\u81f8\u5091\u3836\u999c\u657f", "\ud817\udfe8\ud931\udcb9\udad3\udc6d\ud8c5\udda4\ud871\udcaf\udb28\udc36\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f",
        47, 54862, 384694753, -8102065810795285568L, 20547L, true, false, (char) 10477, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 12, 16, "\uda44\udef5\ud98b\udf95\ud924\udda8\ufc7c\ud9c9\uddba", "\u408b\uc044\u324e", "\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud91a\udc03\uda9b\udef2\ud8c5\udda4\ud871\udd47\udb28\udc36\ud9c4\udec4\uda90\uddbf\udafe\udf8f\udb56\ude38\uec81\uda4b\udd1c\udac2\udc99\ud97b\uddd9",
        30, 67040, -979016048, -3847717726350697929L, -30642L, false, false, (char) 39351, (char) 48487,
        Double.longBitsToDouble(0x3fea1f93d3dee000L), Double.longBitsToDouble(0x3fefd5f669c9655bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 6, 4, "\uda7b\ude54\ud98b\udf95", "\u1093", "\udbcf\ude95\udbca\udd2c\u5ab0\ud949\udcf6\ud8d2\udedf\ud972\ude8e\u36ab\uda67\ude05\udbb8\udd3f",
        -5, 84502, -1290925616, -2818951531082639124L, -81267L, true, true, (char) 12653, (char) 21980,
        Double.longBitsToDouble(0x3fe090b76bc08f8fL), Double.longBitsToDouble(0x3fe482c5a91dc5a5L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 14, 16, "\uda44\udef5\ud98b\udf95\udb51\uddc0\ufbd9", "\u0177\u81f8\u5091\u643a\u3427\u6056", "\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\ude5d\ud871\udd47\udb28\udc36\ud9c4\udec4\ud904\ude94\ud8e4\udd92\udb56\ude38\ud859\udd2f",
        47, 37966, 384694753, -8102065810795285568L, 20547L, true, false, (char) 10477, (char) 33926,
        Double.longBitsToDouble(0x3fd5a3fd7a4bf354L), Double.longBitsToDouble(0x3fea09c1b9e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 1, 12, 13, 16, "\ua9b0\udb10\udd38\udb19\ude3e\udac4\udc71", "\ua502\u81f8\u5091\u374c\u75ed\u657f", "\ud93f\udf07\ud867\ude7c\ud888\udf50\udb76\udfd5\ud871\udd47\udb28\udc36\ud9c4\udec4\ud84e\udefa\udaea\udd96\udb56\ude38\ud9da\udce5",
        0, 48874, 384694753, -8102022933177781312L, 20547L, true, false, (char) 65124, (char) 25875,
        Double.longBitsToDouble(0x3fced2dbc11a9c04L), Double.longBitsToDouble(0x3fea0964d1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 13, "t", "\ua7bd\u9e5e\u0474\u0327\000\u7bda\u0090\u75ed\u657f\u00fa\000\000\u8e38\ucf4b\u627b", "",
        20, 57168, -1027809536, 3271002615093414189L, -76238L, false, true, (char) 50430, (char) 17231,
        Double.longBitsToDouble(0x3fe482c5a91dc5a5L), Double.longBitsToDouble(0x3e40000390000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 2, 0, "", "\u7e41", "\udadf\udf4e",
        37, 4865, 1540152260, -8406142908360556388L, -42906L, true, true, (char) 24694, (char) 59059,
        Double.longBitsToDouble(0x3fe776b55a16004fL), Double.longBitsToDouble(0x3fdd03c5550b661cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 7, 16, "\uda44\udef5\000\000\ufb94", "\u0327\u81f8", "\ud8ae\uddf3\ud8b4\udedf\ud82e\ude8c\udb1a\udd11\udae3\udebc\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud871\udd47\udb28\udc36\ud9c4\udec4\ud84e\udefa\udafe\udf96\uf78c\000\000\udac2\udc99\udbb2\udf3a\udaa9\udf71\ud924\udcfa\uda78\udf1f\u291d\ud8f3\udcdc\ud8fa\udfa6\udbd6\udedf\uafd8\uf88c\udba1\udff0\udbfa\udc02",
        -2, 46091, 1320739044, 3127513487182820665L, 88767L, false, false, (char) 25194, (char) 27836,
        Double.longBitsToDouble(0x3fba596f155ba930L), Double.longBitsToDouble(0x3fed808d488aa0acL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 4, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9\ud9d9\udce3\udac2\udc9f\udbe0\udcba\ud862\udd86\udbca\udd2c\u5ab0\ud949\udcf6\ud8e3\udfdf\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\ud871\udd47\udb28\udc36\ud979\udfff\ud84e\udfa7\udaf5\udcf1\ud981\udc91\ud859\udd2f\udb77\udedc\ud836\udcb4\udb9f\udcbd\udaa9\udf71\ud924\udcfa\uda78\udf1f\ud94d\uddaa", "\u036e\uae0c\u9081\u8558\u9afd\ubbb2\u4d2c\u1c3c\u60b8\u10a4\u5d34\u0d6f\u341b\uc69c\u729d\u10ea\ubbf1\u2b81\u5f47\u25b3\u07f3\u00dc\u69ff\u3e55\u254c\ud6b2\u9980\u4bf3\u5484\ub788", "\udb53\udfd9\ud9f4\udcc8\uda1f\udc15\udb6c\udce4\ud99b\udd09\udabe\udef1\ud97b\udf55\udb2d\udfb1\ud9be\uddef\uda85\udca3\ud91d\udf35\u55aa\ud8da\udca1\ud90d\udf7d\udb67\udde5\ud89d\udca3\ud807\udc66\udb90\udc2b\ud860\udebf\ud85b\udc40\udb42\udf0f\uda39\ude0e\udb75\udef3\udb49\udead\ud816\udf67\ud983\udd35\ud88e\udfac\ud846\ude5b\uda3f\udff0\ud858\udf06\udac1\udc59\udb45\udef9\udbf3\udf94\uda85\ude54\ud8df\udd7b\uda76\udc2a",
        16, 11259, -817738697, 7687175476748692395L, 45843L, false, false, (char) 3263, (char) 44526,
        Double.longBitsToDouble(0x3feacf3ba47012fbL), Double.longBitsToDouble(0x3fe9e576d7f756feL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 14, 2, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9\ud9d9\udce3\udac2\udc9f\udbe0\udcba\ud862\udd86\udbca\udd2c\u5ab0\udb75\uddfa\ud8e3\udfdf\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud9f8\udf9f\ud997\udf8f\udb24\udde1\ud979\udfff\ud84e\udfa7\udaf5\udcf1\ud981\udc91\ud859\udd2f\udb77\udedc", "\u88ce\u94e3\u9166\u59d3\u176c\u8c20\u6478\uae0c\u9081\u8558\u9afd\ubbb2\u4d2c\u1c3c\u60b8\u10a4\u5d34\u0d6f\u341b\uc69c\u729d\u10ea\ubbf1\u2b81\u5f47\u25b3\u07f3\u00dc\u69ff\u68f9\u254c\ud6b2\u9980\u4bf3\u5484\u06e0\u3c70\uaf41\u5d51\uc772\ubb55\u90c9\ucef1\u6831\u1823\u2fc3\u44ec\u28e8\ub7af\ud619\u9986\u9c03", "\ud9a8\udfac\udb90\udc2b\ud860\udebf\ud85b\udc40\udb42\udf0f\uda39\ude0e\udb75\udef3\udb49\udead\ud816\udf67\ud983\udd35\ud88e\udfac\ud846\ude5b\uda3f\udff0\ud858\udf06\udac1\udc59\udb3a\udf42\udbf3\udf94\uda85\ude54\ud81f\ude45",
        57, 80091, -1292585741, -3512160958498843298L, 56264L, false, false, (char) 29610, (char) 4938,
        Double.longBitsToDouble(0x3fe0e8d3c64dc512L), Double.longBitsToDouble(0x3f8cd4f21cbb1300L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5\ud98b\udf95\ud8d2\udc68\ufbf9", "\u0327", "\u5ab0\ud949\udcf6\ud8e3\udfdf\ud9b2\udf2d\uda23\udd70\ud9c2\uddbd\ud9dc\udc04",
        47, 19966, -1290925616, -7487076578560141245L, -8208L, true, true, (char) 23124, (char) 8547,
        Double.longBitsToDouble(0x3fea9ffe2188fcd7L), Double.longBitsToDouble(0x3fd14d13f9c1c908L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 3, 0, "\ud87e\udef3\ud98b\udf95\udb21\udc87\ud9da\udd23", "\u0327\u81f8\u52a8\u374c\u1269\u657f\u13ad\u1b6d\u597e\ub861\u1e9d\u7503\u9f05\u3ca2", "\udafe\udf96",
        22, 32565, 1279231377, 6628070694618790369L, 52944L, false, false, (char) 61122, (char) 19095,
        Double.longBitsToDouble(0x3fe6d999671ac8b0L), Double.longBitsToDouble(0x3fed6fe62b837106L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 2, 0, "", "\ucda9", "",
        38, 24027, 1242124857, 6614903585603281296L, -82853L, false, false, (char) 8448, (char) 0,
        Double.longBitsToDouble(0x3fe3a7e1feeed6abL), Double.longBitsToDouble(0x3fe0b00279d03c55L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 3, 6, "\uda44\udef5\ud98b\udf95\udb21\udc87\ud9ed\udfc4", "\u0327", "\u5ab0\ud949\udcf6\ud8e3\udfdf\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud9dc\udc04",
        47, 19966, -1290925616, -7487076578560141245L, -81267L, true, true, (char) 6414, (char) 60693,
        Double.longBitsToDouble(0x3fe090b76bc08f8fL), Double.longBitsToDouble(0x3fe482c5a91dc5a5L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 12, 16, "\ud97f\udc32\ud98b\udf95\udb21\udc87\ufbf9", "\u0327", "\udbf6\udc66\uda5d\udfd6\udae5\udf21\ud82e\ude8c\ud9c2\udee5\ud96b\ude07\ud9dc\udc04",
        47, 19966, -1290925616, -7487076580120422333L, -81267L, true, true, (char) 61292, (char) 21980,
        Double.longBitsToDouble(0x3fe090b76bc08f8fL), Double.longBitsToDouble(0x3fe482c5a91dc5a5L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 12, 16, "\ud992\udddd\udadc\uddb0\uda54\udfc5\ud989\udfee\uda63\udfd8\ua3c2\udb0c\udea1\udbcf\ude95\ud8c9\udffc\u5ab0\ud949\udcf6\ud8e3\udfdf", "\u7246\u0e36\u908f\u3198\ub69d\u245f\u4434\u9683\u6f7b\u2d59\u21ca", "\ud930\udc3a",
        28, -144, -1392209561, -2991752321011063341L, -11372L, true, true, (char) 38823, (char) 52360,
        Double.longBitsToDouble(0x3fc991a004a2aebcL), Double.longBitsToDouble(0x3fc8c050a633223cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 12, 11, 16, "\uda47\udeeb\uda06\udfbf\udb21\udc87\ufbf9", "\u032e\ua0d6\u5091\uc0a5\u7b6e\u981e", "\ud943\udc8e\ud94f\udf08\ud97e\udde4\ud8c5\udda4\ud90e\udd8a\udaa4\udcb3\ua975\uda6d\udc1d\ud9da\udc62\udac0\udc00\ud859\udd2f",
        3, 30663, -1045540068, -8102065721490002496L, 17791L, true, false, (char) 44243, (char) 33197,
        Double.longBitsToDouble(0x3fced150a232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 5, "\uda47\udeeb\uda06\udfbf\udb21\udc87\udb8d\ude00", "\u0327\ua0d6\u5091\uc0a5\u7b6e\u981e", "\ua680\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\udbc9\udc73\udaa4\udd37\udac1\uddef\uda84\udef5\udafe\udf96\udb56\ude38\uda10\udccb",
        14, 96232, -1045539920, -8102065721490002496L, 17791L, false, true, (char) 36665, (char) 15021,
        Double.longBitsToDouble(0x3fced150a232a4acL), Double.longBitsToDouble(0x3fea0ccbf1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 8, 3, "\ud902\ude89\ud9d1\udd6b\uda47\udf83\ufbf9", "\u7455\ua167\u5091\u65fb\ubce6\u981e", "\ua680\ud81e\ude25\udab4\udf24\ud8c5\udda4\udbc9\udc73\udb9b\udc92\ud8e2\udd37\uda36\udc81\udafe\udf96\udb56\ude38\ud859\udd2f\udb7c\udf74\ud875\udc27\udb3c\udc03\udaa9\udf86\udb81\udfda\ud8fd\udde2\ud982\udcbb\ud903\udd81\ud8d6\udde3\ud91d\udecd\uafb2\uda7d\udceb\udb87\udf3d\udaff\udef2\ud9f6\udfac\ud8b8\udc90\ud9b6\udf2f\udb8d\udd6c\udbc9\ude7b",
        40, 82950, 744464528, 8260756591546504904L, 51955L, false, false, (char) 5629, (char) 23052,
        Double.longBitsToDouble(0x3fe242f16ef7a087L), Double.longBitsToDouble(0x3fe5bd3b4400d8deL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 10, 1, "\uda34\udd32\ud98b\udf95\udb21\udc87\ufbf9", "\u0327\ud2ba\u5091\u374c\u75ed\u657f", "\uda75\udd85\ud944\udc17",
        51, 19966, -1290925616, -2818951528767383338L, -81267L, true, true, (char) 12648, (char) 2979,
        Double.longBitsToDouble(0x3fec2e763bc08f8fL), Double.longBitsToDouble(0x3fe482c5a91dc5a5L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 0, 0, 0, "\uda44\udef5", "\u2223\u5021\u3d74\u0327\u81f8\u5091\u83be\u75ed\u657f\ub090\ua900\u7246\u5978\ucf4b\u82c6", "\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f\u0091.\udbb2\udf3a\udaa9\udf71\ud924\udcfa\uda78\udf1f\ud97f\uddf7\ud8f3\udcdc\ud8fa\udfa6",
        25, 65486, 1245114508, -14857420793716253L, -7438L, true, false, (char) 42268, (char) 7449,
        Double.longBitsToDouble(0x3fdbfec5742d62a6L), Double.longBitsToDouble(0x3fe0c3bd9273df94L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "t", "\u2223", "\udb0c\udea1\udbcf\ude95\udbca\udd2c\u5ab0\ud949\udcf6\ud8e3\udfdf",
        20, -767, -62951751, -2978028944633149714L, 33584L, true, false, (char) 29111, (char) 36807,
        Double.longBitsToDouble(0x3fe99ddd5f8cc2bcL), Double.longBitsToDouble(0x3fd2d2d641228808L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 5, 14, "\000\010\udb21\udc87\udb2c\ude70", "\u433b", "\ud84f\udef7\000\udb24\ude27\ud920\ude33\ud8e1\ude49\u00b9\000\udae5\udfd2\ud8a0\udd1c\u0900\ud9ca\udea4\ud88c\udf0f\ud825\udeea\udb50\ude0d",
        3, 39814, 1013014136, 6659550960214580557L, 3005L, true, false, (char) 59360, (char) 24206,
        Double.longBitsToDouble(0x3fe6789c1698a15aL), Double.longBitsToDouble(0x3fdc81eb8aea9266L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 4, 4, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\ucc94\u81f8\u5091\u374c\u46ed\u657f", "\udbe2\udcdf\ud8f7\udf52\uda9b\udeae\udb7d\udda0\uda13\ude95\ud9fb\udeaf\udad3\ude22\ue54e\ud890\ude7f\udb56\uddbb\ud859\udd2f",
        47, 37966, 384694753, 7750604877548829659L, 20547L, false, false, (char) 10477, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b567ffcbL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 7, "\ud913\udf5d\uda4c\udeda\ud832\udc5d\ufbe6\ud9d9\udce3\u28bb\udb0c\udea1\udbcf\ude69\udbe9\ude8e\u5b16\ud949\udcf6\ud9b3\uddb8", "\u7246", "\ud8c5\udda4\udb16\udd79\udadb\ude74\ud9c4\udec4\ud84e\udefa\ud8e7\udfbf\uda4b\ude0d\udbe6\udc17\udb81\udeec\ud8fd\udeac\udbb2\udf3a",
        56, 43432, -1791176845, 5401014378695006775L, -30642L, false, false, (char) 39351, (char) 57038,
        Double.longBitsToDouble(0x3fde3ffcbedb1db0L), Double.longBitsToDouble(0x3f86e60aeb62d140L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 2, "\uda44\udef5\ud98b\udf95", "\u5021\ubf8e\u9e1c\ub69a\ub5f2\ubf02\u7ae5\u657f\u7f0d\ua900\ub541\u4590\u90e2\u752a\ub636\u3427\u7fae", "\udb47\ude22\ud859\udd2f\udb77\udedc\udac2\udc99\udbb2\udf3a\udaa9\udf71\ud924\udcfa\uda78\udf1f\ud97f\uddf7\ud8f3\udcdc\ud8fa\udfa6\uda86\udce1\ud905\udfe4\uda7d\udceb\udb87\udf3d\u9219\ud839\udc53\ud809\udfa6\udb8a\udec6\ud9e6\udc4b\ud97f\udc81\udbb5\udc3e\uda3c\ude44\uda51\udcb5",
        17, 12480, -337683317, -1761212688230419835L, 27318L, true, true, (char) 495, (char) 17906,
        Double.longBitsToDouble(0x3fd2dfee8a0619daL), Double.longBitsToDouble(0x3fdddc45d6b75caaL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 13, 16, "\ua9b0\udb10\udd38\udb13\uddba\udac3\udfe5", "\ua502\u81f8\u5091\u374c\u75ed\u657f\uafb7\uc6ea\uaf79\u6fce\u5a39", "\ud812\ude36",
        6, 93337, -1027830477, 3271002616036837779L, -35566L, true, true, (char) 60414, (char) 17231,
        Double.longBitsToDouble(0x3fe9d7c7511db299L), Double.longBitsToDouble(0x3fe2eba1c5c494a4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\0121=java.lang.Boolean:false |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 15, 15, 9, "\ua9b0\udb10\udd38\udb19\ude3e\udac4\udc71", "\ua502\u81f8\u5091\u374c\u75ed\u657f", "\ud93f\udf07\ud867\ude7c\ud888\udf50\udb76\udfd5\ud871\udd47\udae4\udd7c\ud8eb\udf7a\ud84e\udf4f\udaea\udd96\ud81f\udd1c\ud9da\udce2",
        8, 58085, 1609865148, 1625738137207065676L, 20547L, true, false, (char) 16328, (char) 12912,
        Double.longBitsToDouble(0x3fced2dbc11a9c04L), Double.longBitsToDouble(0x3fea0964d1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 12, 12, 10, "\uda44\udef5\ud983\udf95\udb21\udc87\ufbf9\ud9d9\udce3\udac2\udc9f\udbe0\udcba\ud862\udd86\udbca\udd2c\u5ab0\udb75\uddfa\udaba\udc2a\uda99\udc25\uda85\ude6d\ud96b\ude90\ud9dc\udc04\udaac\uddf2\ud9f8\udf9f\ud997\udf8f\udb24\udde1\ud979\udfff\ud84e\udfa7\udaf5\udcf1\ud981\udc91\ud859\udd2f\udb77\udedc", "\u88ce\u94e3\u9166\u59d3\u176c\u8c20\u6478\uae0c\u9081\u8558\u9afd\u5e12\u9e91\u1c3c\u60b8\u10a4\u5d34\u0d6f\u341b\uc69c\u729d\ua422\u3c30\u2b81\u5f47\u25b3\u07f3\u00dc\u4f47\ubf47\ubff6\ud6b2\u9980\u4bf3\u5484\u06e0\u3c70\ubfb0\u08ec\u7011\ubb55\ua604\ucef1\u6831\u1823\u2fc3\u44ec\u28e8\ub158\u1d2b\u0e9d\u9c03", "\ud9a8\udfac\udb90\udc2b\ud860\udebf\ud85b\udc8d\udb42\udf0f\uda39\ude0e",
        3, 72864, -214541272, -6603611192486279593L, -27558L, true, false, (char) 45836, (char) 37468,
        Double.longBitsToDouble(0x3f9fc5fa80cd0ac0L), Double.longBitsToDouble(0x3fe92b1f2cf3635dL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 9, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9\ud9d9\udce3\udac2\udc9f\udbe0\udcba\ud862\udd86\udbca\udd2c\u5ab0\udb75\uddfa\ud8e3\udfdf\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud9f8\udf9f\ud997\udf8f\udb24\udde1\ud979\udfff\ud84e\udfa7\udaf5\udcf1\ud981\udc91\ud859\udd2f\udb77\udedc", "\u88ce\u94e3\u9166\u59d3\u176c\u8c20\u6478\uae0c\u9081\u8558\u9afd\ubbb2\u4d2c\u1c3c\u60b8\u10a4\u5d34\u0d6f\u341b\u3a65\u7ef9\u10ea\ubbf1\u2b81\u58a2\u2576\u07f3\u00c9\u69ff\u68f9\u254c\ud6b2\u9980\u4bf3\u5484\u06e0\u3c70\uaf41\u5d51\uc772\ubb55\u90c9\ucef1\u6831\u1823\u2fc3\u44ec\u28e8\ub7af\ud619\u9986\u9c03", "\ud9a8\udfac\udb90\udc2b\ud860\udeae\ud85b\udc40\udb42\udf0f\uda39\ude0e\udb75\udef3\udb49\udead\ud816\udf67\ud983\udd35\ud88e\udfac\ud846\ude5b\uda3f\udff0\ud858\udf06\udac1\udc59\udb3a\udf42\udbf3\udf94\uda85\ude54\ud81f\ude45",
        3, 15111, -1292585741, 7340614739674596053L, 5880L, false, false, (char) 29610, (char) 4938,
        Double.longBitsToDouble(0x3fe0e8d3c64dc512L), Double.longBitsToDouble(0x3f8cd4f21cbb1300L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=void |this=org.jfree.data.time.TimeSeries:@?\012",
        Z.run(T, 2, 11, 11, 9, "\uda47\udeeb\ud92a\udc02\udb37\udd3c\udb8d\ude00", "\u0327\ua0d6\u5091\uc0a5\u6f88\u980d", "\ua680\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\udbc9\udc73\udaa4\udd37\udac1\uddef\uda84\udef5\udafe\udf96\udb56\ude38\uda10\udccb",
        14, 96232, 1756058544, -8102065536806408768L, 17791L, false, true, (char) 36665, (char) 15021,
        Double.longBitsToDouble(0x3fced150b232a4acL), Double.longBitsToDouble(0x3fe40a08ce59fae1L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 0, "\000\000\udb21\udc87", "\ub935", "\000",
        13, -1000, 6105, -8008270950918299867L, -100000L, false, false, (char) 655, (char) 85,
        Double.longBitsToDouble(0x3e3eb166b8000000L), Double.longBitsToDouble(0x3fdb67a92841a116L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 9, "\ud8c3\udc11\udab6\udfeb\udb21\udc87\udb2b\udd70\ucfb2\ud8d1\udf26\u433b\ud884\udca2\udb00\udfe5\ud84f\udef7\ud8a4\udeb2\udbac\ude55\uda8e\udd0c\udb00\udca7\u00b9\000\ud849\udf77\ud8a0\udd1c\u0900\udae8\udfab\ud800\uddc3\ud8db\ude59\u8e21\u0e0e", "\uc03f\u7963\u7055", "\ud9a6\ude90",
        -1, 11355, 515409304, 5318017496901694837L, 96495L, true, false, (char) 4438, (char) 31235,
        Double.longBitsToDouble(0x3fb40bf6242fbc28L), Double.longBitsToDouble(0x3fec6c972d5dd417L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 13, 16, "\ud82f\udf7e\udaa0\ude3c\udb13\udd82\udbd5\udf0f", "\ua502\u81f8\u5091\u5bb6\u82d3\ubc5a\u1134\uc69d\uaf79\u6fce\u5a39\u5f76\ua47e\u8871\u7fae\u7219\u9e3b\u5611\uacd5\u46f5\u8a92\u1d0e\uafce\u0a1a\ucc7d", "\ud907\uded8",
        44, -268, -1633338139, 5381337219797665299L, 71438L, false, false, (char) 11037, (char) 43894,
        Double.longBitsToDouble(0x3fd5570e851c1e3eL), Double.longBitsToDouble(0x3fbffe2bb49cc640L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.jfree.data.time.TimeSeries:@? |this=org.jfree.data.time.TimeSeries:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 9, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9\ud9d9\udce3\udac2\udc9f\udbe0\udcba\ud862\udd86\udbca\udd2c\u5ab0\udb75\uddfa\ud8e3\udfdf\ud82e\ude8c\udb1a\udd11\ud96b\ude80\ud9dc\udc04\uda9b\udef2\ud9f8\udf9f\ud997\udf8f\udb24\udde1\udb18\udecf\ud8e3\ude76\udaf5\udcf1\ud981\udc91\ud859\udd2f\udb77\udedc", "\u88ce\u94e3\u9166\u59d3\u176c\u8c20\u6478\uae0c\u9081\u8558\u9afd\ubbb2\u4d2c\u1c3c\u60b8\u10a4\u5d34\u0d6f\u341b\u3a65\u7ef9\u10ea\ubbf1\u2b81\u58a2\u2576\u07f3\u00c9\u69ff\u68f9\u254c\ud6b2\u9980\u4bf3\u5484\u06e0\u3c70\uaf41\u5d51\uc772\ubb55\u90c9\ucef1\u6831\u1823\u2fc3\u6249\ucee5\ub7af\ud619\u9986\u9c03", "\ud9a8\udfac\udb90\udc2b\ud860\udeae\ud85b\udc40\udb42\udf0f\uda39\ude0e\udb75\udef3\udb49\udead\ud816\udf67\ud983\udd35\ud88e\udfac\ud846\ude5b\uda3f\udff0\ud858\udf06\udac1\udc59\udb3a\udf42\udbf3\udf94\uda85\ude54\ud81f\ude45\ud8e7\udce8\udac5\uddc8\uda98\udc68\udb8a\udc37\udb4b\udd9a\udb1a\udc3d\ud97d\udd99\ud9a8\udf1e\uda09\ude0b\ud928\udd89\u06a4\ud941\udc93\udb17\udee4\ud9d3\udff6\udbe4\udd96\udbb4\uddba\udaa4\udf94\udb5b\udfdf\ud9b0\udeb5\udb47\ude52\uda54\udd23\ud84e\ude45\ud860\ude90\udad4\uddea\ud93f\udf5c\ud941\uddfd\udad8\udf92\ud97d\ude5f\ud8bf\udc79\ud964\udd11\uf25b\ud95c\udc85\uda13\udfe9\ud87f\udfdb\uda45\ude2e\ud9a1\udc14\uda3b\udc81\udbe8\udeea\ud8ff\udf75",
        22, 15456, -1814526636, 8053984886239786829L, 71877L, true, false, (char) 15962, (char) 40651,
        Double.longBitsToDouble(0x3fd50c574f4176eaL), Double.longBitsToDouble(0x3fb6a183a4bc8350L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 16, "\uda44\udef5\ud98b\udf95\udb21\udc87\ufbf9", "\u0327\u81f8\u5091\u374c\u75ed\u657f", "\ud96b\ude80\ud9dc\udc04\ud884\ude87\ud8c5\udda4\ud871\udd47\udb28\udc36\ud9c4\udec4\ud84e\udefa\udafe\udf96\udb56\ude38\ud859\udd2f",
        47, 5102, 384694589, -8102065810795285568L, 20547L, true, false, (char) 10477, (char) 60038,
        Double.longBitsToDouble(0x3fced2dbc232a4acL), Double.longBitsToDouble(0x3fea0a51b1e3ffcbL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 11, 16, "\uda47\udeeb\uda06\udfbf\udb21\udc87\ufbf9", "\u0327\ua0d6\u3218\uc15e\u7b6e\u981e", "\ua680\ud9dc\udc04\uda9b\udef2\ud8c5\udda4\udbc9\udc73\udaa4\udd37\udac1\uddef\ud84e\udefa\udafe\udf96\udaa1\udf9e\ud859\udd73\udb7c\udf74\ud875\udc27\udb3c\udc03\udaa9\udf86\udb81\udf5b\ud8fd\udde2",
        21, 80863, -596881254, -8465330161906375434L, 29902L, false, false, (char) 64023, (char) 30014,
        Double.longBitsToDouble(0x3fe9c173130648fdL), Double.longBitsToDouble(0x3fa079eec46a2220L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,double,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.RegularTimePeriod,java.lang.Number,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|add|org.jfree.data.time.TimeSeriesDataItem,boolean|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addAndOrUpdate|org.jfree.data.time.TimeSeries|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,double|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|addOrUpdate|org.jfree.data.time.RegularTimePeriod,java.lang.Number|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clear||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|clone||new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|delete|org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|equals|java.lang.Object|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|int,int|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
    "M|org.jfree.data.time.TimeSeries|createCopy|org.jfree.data.time.RegularTimePeriod,org.jfree.data.time.RegularTimePeriod|new:org.jfree.data.time.TimeSeries:java.lang.Comparable",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
