package org.jfree.chart.renderer.category;
import org.junit.Test;
import static org.junit.Assert.*;
public class MinMaxCategoryRenderer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udbab\udf94\udbbd\udc8f",
        52, 79318, -553305516, 8240920416098766740L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442d90ac38L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 11, "\udbc1\udfd4", "\u29a3", "\ud938\udc38\ud824\udc8a\udbae\udeda\ud9a6\udc7a\udbab\udf6b\udbbd\udc8f\ud84e\uded0\ud91f\udceb\ud9ac\udc62\ud9f4\udc39\uda55\udc44\ud9ef\udef8\uda23\udeb8\udbd0\ude29\udb9f\udee1",
        57, 22193, -196992903, -1586021581077455362L, 15483L, true, true, (char) 36848, (char) 2166,
        Double.longBitsToDouble(0x3fd41c97f272423cL), Double.longBitsToDouble(0x3feedec316ee27d5L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\udbc1\udfd4\udb19\ude32\ud990\udcdf\udab5\udef6\uda6d\udfe9\udac3\udffa\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udba4\ude20\udbdf\udfc0\ud99f\udd14\ud977\udc76\ud9ac\udcd4\ud966\udc32\uda55\udc44\udafb\ude2f", "\u7eef\u2bcf\ua88d\u84e6", "\ud917\udda7\udb82\udcf3\udb84\udcab\ud9c8\udf87\u38f0\ud86f\ude96\uda0b\udd8f\ud852\udec9\ud943\udd0b",
        52, 60098, 1041303435, 7477162439388139368L, -16834L, true, false, (char) 55225, (char) 40961,
        Double.longBitsToDouble(0x3fc253c49d0de6a0L), Double.longBitsToDouble(0x3fc4fc52ef18b600L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\udbc1\udfd4", "\u1a71", "",
        47, 64548, 1899560037, -5970088452301776926L, -64966L, false, false, (char) 59732, (char) 32890,
        Double.longBitsToDouble(0x3feca392eb4ec7d4L), Double.longBitsToDouble(0x3fdb2a926088c28eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 12, 11, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfde\uef4d\udbab\udf94\udbbd\udc8f",
        52, 79318, -553305516, 8240920416098766740L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fc8de885b215870L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=0,g=0,b=0] |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 2, 7, 13, "\udbc1\udfd4", "\u7ffa\uca72\u74f0\ud454\u0d1c\u04c5", "\ud8af\udc34\uda43\udf50\ud910\udfe7\ud917\udc73",
        30, 18764, -1457083481, 8769618644851626308L, 20105L, true, true, (char) 2658, (char) 36928,
        Double.longBitsToDouble(0x3fda5b64c5079a44L), Double.longBitsToDouble(0x3feef6777f7b8016L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 11, "\udbc1\udfd4", "\u1a28\ua3c6\u384e", "\ud904\udf4b\udb9a\ude98\udbc1\udd2d\udbbd\udc8f\udb87\udef8\udae6\ude81\ud9ca\uddcb\ud966\udc32\uda55\udc44\ud902\udd71\ud909\ude8c\udbd0\ude29\udb9f\udee1",
        55, 23676, -196992903, 1364614627426943508L, -63148L, true, false, (char) 59522, (char) 17068,
        Double.longBitsToDouble(0x3fd94127f8691c28L), Double.longBitsToDouble(0x3fcf5ed67d2d263cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 7, "\udbc2\udc4b\udb19\ude32\ud829\udcb5\udb81\uddcc\uda5e\udcc0\udac3\udffa\ud96f\udef3\udb7c\udd44", "\ub9d3\ub2bf\u45a3\u6a89\u7b3d\u0901\u9501\u59c6\u9f8a\u9a9b\u7eef\u2bcf\u6fa8\u287b\u03bc\u3e31\uce2a\ub3dc\u4286\uc997\u74f6\u8f7e\uc7a8", "\udb07\udc43\udb5b\udfbb\ud923\ude60\udbc7\uddbf\ud838\udd31",
        30, 40867, -90658863, 1421548700310746743L, -47261L, false, false, (char) 53130, (char) 50699,
        Double.longBitsToDouble(0x3fa6dbb1dcd8b4d0L), Double.longBitsToDouble(0x3fd746e8079d5e52L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfd\ud947\udc68\udb36\udf1b\u17e2\000",
        53, 79318, 84, 13946624L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442190ac38L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 11, "\udbc1\udfd4", "\u1a71\u8781\u74f0\ud454\u3483\u2a96", "\ud8ef\udc88\ud84e\uded0\ud91f\udceb\ud9ac\udc62",
        30, 13524, 1839773169, 7009838191599292740L, 43895L, false, true, (char) 51573, (char) 2601,
        Double.longBitsToDouble(0x3fe642b0e1966703L), Double.longBitsToDouble(0x3fe4ca39506e752bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 7, 6, 11, "\udbc1\udfd4", "\u77cd", "\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udbab\udf94\udbbd\udc8f",
        52, 79318, 1208302164, 8240920416098766740L, -96338L, false, true, (char) 18333, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442d90ac38L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\ud9f4\uddc6", "\u016e\ua3c6\u74f0\ud454\u1d81\u2b1c\ua1fc\ub9d3\u6835\u3f68\u6a89\uce0d\u0901", "\uda75\udf6d\udbd0\ude29\udb9f\udee1\udba2\udf5f\ud8b2\udfcb\udb65\udfc7\ud82e\uded9\ud8b2\udd4c\uda96\udc1f\ud8ca\udf3f\ud8cc\udf16\udacb\udfa5\udb7f\udca7\ud8f9\udc4f\udae6\udccd\udacf\udea5\udb07\udd8a\ud804\udd7c\udb25\udfce\udba0\udf48\uef21\uc415\udace\udc70\ud92f\uddc6\ud984\uddb2\ud9fb\udd2d\udb42\uddf3\ud91e\udee5\ud802\udde4\u3d0d\udabc\udda3",
        26, 36380, 1693573266, -6435279722631615138L, 94556L, false, false, (char) 44322, (char) 23611,
        Double.longBitsToDouble(0x3fe9d183c4a467c1L), Double.longBitsToDouble(0x3fecf909b5707c50L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\014", "\u1a71", "\udb1c\udc2a\uda6b\uddfd\ud85a\udf11",
        9, 33026, 1603526382, -7383501120536030810L, -34464L, false, true, (char) 51234, (char) 39640,
        Double.longBitsToDouble(0x3fd4461471f21e7cL), Double.longBitsToDouble(0x3fde9dc883380172L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 12, 11, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udbab\udf94\ud889\udc95",
        52, 79318, -553305516, 8240920416098766740L, -96338L, false, true, (char) 18386, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442d90ac38L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "", "\u88a3", "\000",
        -5, -1000, 0, -5970088452301776926L, -64966L, false, false, (char) 14932, (char) 57210,
        Double.longBitsToDouble(0x3feca392eb4ec7d4L), Double.longBitsToDouble(0x3fdb2a926288c28eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 7, "\uda51\udc16\ud99f\udfed\ud9d0\udfd5\ud904\udf91\ud9d0\udf22\ud92f\udd89\udb0d\udfb8\udaa2\ude71\uda49\udcb5\uda1b\udff7\udbc1\udd2a\udaea\udc81\udaeb\ude52\udb44\udf77\udaa0\udfd2\udb80\udde1\ud8e1\udc0e\udada\ude86\ud931\udeea\ud9d9\udcb9\udb13\udde9\udb02\udd3e\udb51\ude38\ud9ed\udeb6\udbda\udc72\udbcb\uddb7\ud9af\ude5b\ud86f\ude5f\ud867\udee0\ud8ff\udd75\udbb1\udf77\udb5f\ude96\u4da8\udb60\ude55\ud915\ude44\u00f4\ud9c1\udcd3\uda40\udc1f\ud99c\udec8\uda0c\uddeb\ud98d\uddab\ud885\udd23", "\u1730\u1473\ud434\u7a2b\ud148\u010f\u7493\u79c0\ud4d2\u832c\u39f2\u88cb", "\udafd\udfaa\uda31\udc9b",
        20, 21969, -520874375, -5288265837088855018L, -93520L, true, false, (char) 1636, (char) 34838,
        Double.longBitsToDouble(0x3fe39eb973dc89e0L), Double.longBitsToDouble(0x3fe2e43db3b928deL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 11, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udbab\udf94\udbbd\udc8f",
        52, 42574, 1527513959, 8240919917882560404L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442d90ac3aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 12, 11, "\udac9\udf5e", "\u1a71\u66c6", "\uda6b\uddfd\udaad\udfdc",
        -2, 33026, 1609031406, -7383501119915273818L, 69796L, false, true, (char) 43810, (char) 31320,
        Double.longBitsToDouble(0x3fe695709469ac45L), Double.longBitsToDouble(0x3fede170ad9c5cb9L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=0,g=0,b=0] |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 11, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udbab\udf94\udbbd\udc8f",
        52, 79318, -553305516, 8240920416098766740L, -96338L, false, true, (char) 53572, (char) 22978,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442d90ac38L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 11, "\udae4\udd89", "\u1a71", "\ud822\udcb4\udb51\udc4c\udb5e\udf7c\udae2\ude8b\ud94c\udc1c\ud948\udc06",
        58, 69146, 676430118, 8309867916943478676L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fe4e2e5c8a1694bL), Double.longBitsToDouble(0x3fdc6f442d90ac38L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 13, 14, "\udbc1\udfd4", "\u1a71\ua3c6\uc6b8\u5933\u8850\u5348\u4a0f", "\uda48\udfb4\ud91f\udc4a\ud9ac\udc62\ud966\udc32\udb0c\udff3\uda9f\udec3\uda6e\udfda\udbd0\ude29\udb10\udef0\ud987\ude43\ud9cd\udec8\udb65\udfc7\ud948\udf06",
        55, 39989, -1057136695, 8737626422304248482L, -15389L, true, false, (char) 61901, (char) 56341,
        Double.longBitsToDouble(0x3fe009c79856e03eL), Double.longBitsToDouble(0x3fed29047e8358d5L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\udbc1\udfd4", "\u9822\u666d\u141a\ud454\u736f\ucc95\u24fc\ub9d3\u6835\ub767\u6a89\u7b3d\u0901\u9501\u63c3\u27e9\u027b\ucb6c\ucc1c\u10ae\u4965\ub6eb\u1b09\ub499\ucbc9\u76b4\u16af\uba59\u99f2\ua10b\u3a0a\u839b\uc534\u1733\ua996\u4862\u095d\u80d5\u9afe\u955f\uc16e\u5bcb\u1ac8\u0a6d\u4a50\ud705\u67b0\u742a\u721a", "\ud8d1\udc82\udb86\udca3\udbe9\udda3\uda06\udce6\ud92f\udcc7\uda7a\udf07\ud90f\udd9d\udaa6\udead\ud84b\ude50\udb78\udf22\u72cb\uda2d\udc42\u402c\udab5\udc1d",
        10, 50221, 43947385, -8969857441283835600L, -47804L, false, true, (char) 29885, (char) 30660,
        Double.longBitsToDouble(0x3fb38f3434205ae8L), Double.longBitsToDouble(0x3fe4b4932b887fc2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 1, 11, 11, 15, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udbab\udf94\udb5f\udc80\ud84e\uded0\ud91f\udceb\ud9ac\udc62\ud966\udc32\uda55\udc44\udafb\ude2f\uda75\udf6d\udbd0\ude29\udb9f\udee1\udba2\udf5f\udbdd\uddf0\ud86b\udf88\ud82e\uded9\udb3b\udff1\ud94f\udd22",
        39, 21550, -1983046756, 8495916493870331259L, -52006L, false, true, (char) 48760, (char) 3992,
        Double.longBitsToDouble(0x3fbc053b11684c98L), Double.longBitsToDouble(0x3fe01208ecafe45cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 11, 11, 11, "\udbc2\udc06\udb0b\udd7a", "\ud334\u74f0\ud454", "\uef4d\udbab\udf94\ud8c0\udcae",
        9, 45446, 1201409706, -5397692724191899756L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442dbc5a38L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 1, 11, 12, 11, "\udbc1\udfd4", "\u82dc", "\ud90d\udda1\uda6b\uddfd\udb26\udf58\uda64\udd12\udbab\udfa5\udbbd\udc8f",
        1, 30871, 150677898, 8270157306454658964L, -77138L, false, true, (char) 62523, (char) 43550,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f44224ab4fcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 14, 11, "\udbc1\udfd4\udb19\udec6\udace\ude68", "\u74f0\ud454\u3483\u633b\u30e9\ub917\u6835\u3f68\u6a89\u8ae5\u4e87\u9501\u245f\u0e92\u5651\u9040\u8493\uca64\ub07d\uabd4\u0570\u6598\u440d\uc0bb\uce00\u6070\u23ae\u8ca1\u126b\u028a\u8a27\u6966\uc083\u422a\uad19\u09e6\uce22\uc9bb\u9324\u5d97\u7427\u4793\u822d\u0632", "\udb15\udfb5\udbc7\udfbb\ud941\udd9b\u76e4\ud809\udd5b\udb22\udf75\udb78\udd9b\udb72\udea7\ud944\udc16",
        12, 9862, -484872980, 2864955497402205156L, 71553L, false, true, (char) 14191, (char) 64070,
        Double.longBitsToDouble(0x3fd61ed64e75398cL), Double.longBitsToDouble(0x3fdc7eb21dc52932L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 12, 11, "\udbc1\udfd4", "\000", "\ud938\udc38",
        23, -1000, 0, -368143979166572818L, -100000L, false, false, (char) 0, (char) 39602,
        Double.longBitsToDouble(0x3fd4461471f21e7cL), Double.longBitsToDouble(0x3fcd3b9100000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 11, "\udbc1\udfd4", "\u1a71", "\ud938\udc56\uda5c\udefd\udb13\ude0e\uef96\udbab\udf94\udbbd\udc8f",
        52, 79318, -553305516, 8240920416098766740L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fc9c35581e55f28L), Double.longBitsToDouble(0x3fdc6f442d90ac38L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$2:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 15, 11, "\udbc1\udfd4", "\u5bec", "\ud938\udc38\ud89b\udf1a\udac1\ude67\udad8\udef5\udbab\udf94\udb68\udf25\ud830\udf71\udaf9\udf32\ud9f4\ude8f\ud966\udc35\uda55\udc44\udb62\udfa2\udbf3\ude20\udbd0\ude28\ud8e2\uddd0\udba2\udf5f\ud844\udc40\udb4f\udd4d\udaee\uded4\udaaa\udf86\ud82e\udcb3\ud8d5\udd3b\ud8a5\udcc5\ud840\ude3f",
        7, 25631, 887504165, -5975678745382584720L, -62088L, false, false, (char) 30330, (char) 55915,
        Double.longBitsToDouble(0x3f979c0e13d76640L), Double.longBitsToDouble(0x3fe6c971008820c1L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000", "", "\udac3\udf24\ud938\udc38\uda6b\uddfd\ud947\udc68\udbfa\udf4c\udbab\udf94\udbbd\udc8f\uc8e2\ud90a\udf45\u3a54\ud93d\udebd\uda55\udc44\udafb\ude2f\u00b2\000\udb91\udde8",
        28, 23520, -196992903, 6204858326056476360L, -87191L, true, true, (char) 60903, (char) 2659,
        Double.longBitsToDouble(0x3fdf677b2e8ebff6L), Double.longBitsToDouble(0x3fe5f8296b335874L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 0, 0, 0, "\014", "\u1a71", "\000\uda3b\udc00\ud85a\udeac\ud801\udc00\000\000",
        53, 79318, 0, 8214565719381430164L, -96338L, false, true, (char) 18487, (char) 56553,
        Double.longBitsToDouble(0x3fd9c5cb9000af94L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 12, 11, "\udab3\ude82", "\u1a71", "\ud92d\udd80\uda4c\udf7e\ud85a\udf11\uef4d\udbab\udf94\udbbd\udc8f",
        48, 80355, -553305516, 8385035604903629579L, 34734L, true, true, (char) 46328, (char) 25710,
        Double.longBitsToDouble(0x3fd9f7fb98660008L), Double.longBitsToDouble(0x3feeb1aabec85635L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "\udb5a\udfa1\udb0e\udd76\udac4\udc34\ud979\ude10\uda6d\udfe9\udac3\udffa\ud938\udc38\uda54\udc41\ud85a\udf11\udbf5\udfab\udbab\udf94\udbbd\udc8f\ud84e\uded0\ud91f\udceb\ud9ac\udc62\ud966\udc32\uda55\udc44\udafb\ude2f\ud9ad\udf69\udbd0\ude29\udb9f\udee1\udba2\udf5f\ud86d\udc09\udb66\udc3a\ud82e\uded9\udb76\udf4e\udbd7\udc55\udbc8\udcb9\uda5e\udeb2\udae5\udc8a\ud916\udd73\ud89e\uddcc\udb89\udf53\ud81a\udfd2\uda8f\ude53\ud930\udeed\udb5f\udc99\ud87d\udc04\ud8a5\udca7\udad5\udf2d\ud941\uddce\ud8ef\udd43\ud8c0\ude82\ud863\udf9e\uda61\udcea\ud97c\udc3c\ud9dc\udddd\ud835\udc5c\ud9cd\udff3\ud911\udf76\ud843\udc91\ud891\udd10\udbe6\uddd3\ud9f7\udd04\u1e28\ud878\udcbd\udb5b\udd4b\udaf9\udfa9\ud80f\udce1\ud906\udc32\udb61\udc23\udb55\udc30", "\uce9b\uc93a\u42f4\u4cfa\uac51\u28cd\ud5d2\uadf3\u9ce3\u4376\u2e5e\ud60b\u9cb6\u40ba\ua478\u5c10\u0527\u5409\u0a2d\u9533\ubab6\u09b6", "\ud9a9\udc81\uda97\udd2f\ud8ee\udd3c\udb09\udfc5\ud91a\ude71\udaa1\udcac\ud9eb\udfb2\ud8ee\ude4b\ud8b1\uddf8\udba5\udec9\ud887\uddae\uda2d\udcc6\udb4a\ude2c\udb61\udd3d",
        55, 72489, 1159296321, -8069098924391471354L, 80329L, false, false, (char) 11804, (char) 52048,
        Double.longBitsToDouble(0x3fd5d573516c68feL), Double.longBitsToDouble(0x3fe25a04da75b23fL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 7, "\udbc1\udfd4\udb19\ude32\udace\ude68\udadd\udcf4\ud9f3\ude16\ud883\udc15\uda45\udf51\uda6b\uddfd\uda78\udc00\uef93\uda6b\udcd3\uda63\udc33\ud8ab\udd4a\ud929\udd3f\ud9ac\udc81\udb20\udc2f\ud9c6\udefc\udacd\ude10\uda75\udf6d\udbd0\ude29\udb2a\ude36\ud94a\udec9\ud9bb\udc7d\ud86b\udedf\u6673\uda03\udf84\udb6f\udc00\udbf1\ude92\ud97a\udd2d\udad3\udd30\udaf1\udcfa\udb83\udf31\ud837\udee2\udbd2\udfda\udbb1\udcf6\udb2b\udd16\uda65\udc5f\ud924\udd4b\udba8\uded3\ud9c9\ude1d\uda83\ude11\udb54\udcdd", "\u3a28\u35a7\uc29a\u4a95\u0364\u98eb\u61d9\u16b2\ua331\u0efa\u980b\u48d2\ua626\uad48\u8602\ua688\u7fd7\u118e\u1930", "\ud830\ude6a\ud876\udd57\uda40\udfa5\ub18e\udaef\udd99\ud882\udf75\uda8d\udd59",
        30, 19905, -377456317, -7052501973376973435L, -90576L, true, false, (char) 7476, (char) 56167,
        Double.longBitsToDouble(0x3fbdbf48505b9c50L), Double.longBitsToDouble(0x3fb64b1ebbc8c938L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 11, "", "", "\uda4b\udd45",
        28, 89512, -1928731452, 8158548234313530415L, -91296L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd75df00128e4baL), Double.longBitsToDouble(0x3e2b2a9260000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 13, "\udbc1\udfd4", "\u1a71", "\ud938\udc38\uda6b\uddfd\ud85a\udf11\uef4d\udbab\udf94\udbbd\udc8f",
        52, 79318, -553305516, 8240920416098766740L, -96338L, false, true, (char) 18487, (char) 43633,
        Double.longBitsToDouble(0x3fd9c5cb90f2af94L), Double.longBitsToDouble(0x3fdc6f442d90ac38L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 12, 11, "\udbc1\udfd4", "\u29a3\u5120\u7476\u5c11", "\udb6e\udfff\ud854\udee8\udbbc\udfd5\ud84e\uded0\ud902\udeeb\ud9ac\udc62\ud9f4\udc39",
        57, 94229, -1131455822, 1098334342284261625L, -92831L, false, true, (char) 36365, (char) 50237,
        Double.longBitsToDouble(0x3fe7713eab255fb7L), Double.longBitsToDouble(0x3feadd071510d08cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 7, "\uda1e\udc76\ud895\udcea\udb87\udd6c\uda4a\udc65\udaba\ude73\000", "\u2a96\u64a7\ub9d3\ud709\u3f68\u17b2\u7b3d", "\uda06\udfeb\udbf5\udde8\udbc5\udead\ud9ce\udcf2",
        28, 9907, -723565003, 1435523319380319373L, 46396L, false, true, (char) 61805, (char) 22608,
        Double.longBitsToDouble(0x3fcf7f7d8b7f39e4L), Double.longBitsToDouble(0x3fe4c10223193d68L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 11, "\udac2\udf2f\udb8e\udd0d\uda51\udf5a\udab5\udef6\uda30\udf18\udbd5\udfe1\udb2a\uddf1\ud8e5\udd5d\ud85a\udf11\ud80e\uddad\udb16\ude0a\ud9f6\udffa\uf99d\ud8cd\udf7d\udb7a\udf6f\udace\uddac\ud91d\udd5d\udac2\udf2f\uda75\udf6d\uda6d\udc74\ud9a9\udc3e\uda89\udfe8\ud9e1\udf6f\ud843\udd35\udaea\udc28\ud94a\udcbc\udaad\uddfa\uda63\ude43\ud982\udf24\ud83a\udc90\ud8b4\udff7\ud9ca\udd05\ud934\ude2e\ud93b\udf58\ud8d6\uded2\ud8e2\ude85\udaed\udf49\uda9a\udfa6\ud803\udd07\udb46\udd85\ud87d\udd25\udbbf\udd16\udbea\udf66\udb2c\udd77\udb0a\ude9e\ud84e\ude3f\u56c5\udb47\udfad\udab9\ude1f\uda58\udc71\ud818\ude12\uda50\udd7c\udb54\ude6d\ud83e\udc30\ud950\udfe9\udbbf\ude48\udb87\udcdd\ud958\udeb6\udb7e\udc5a\udadf\udeb0\ud8b7\ude60\ud9a7\udcc3\uda79\udf26\udb07\udd9f\ud93a\udf3a\uda2e\ude84\udb29\udde7\ud948\udc7a\udac1\udd1b\ud8ae\udd9b\uda92\udd53\ud8ca\udd6f\ud940\udf2c\ud8dc\udcbb\ud96f\udcd6\ud8ca\udcfe\udb42\udca3\uda9f\udcfd\udb70\udd95\udad2\udd67\ud89a\udf7b\ud8df\udc4c\ud919\ude8f\ud956\udee4\ud838\udcbb\udb94\ude8b\udb99\udfad\udbb3\udd47", "\u11c7\u27de\u15af\ud50a\u933c\u3f2b\u886e\u8ad3\u1c15\u6696\ua71a\u42bf\u6f1a\u6868\u1b29\u32d0", "\udaa7\uddb6\udb18\ude72\uda6f\udcfb\ud85b\udd7d\ud818\udc99\udb21\uddb1\ud891\udc50\ud900\udc6b\udafb\uddb7\udb18\udd95\ud9f5\udc2a\udbeb\udf0d\uda35\udcd5\udbc3\udc4c\uda0d\ude1f\uda3d\udf05\udb54\udc0a\udae4\ude0c\u5db7\ud8e5\udd5e\ud8d6\udf3e\ud864\udcd4\udb46\udd38\udaff\udc3d\udb34\udd17\ud8f9\uddc4\ud9bf\udc24",
        4, 82506, 1971312421, -3824267871478189625L, -9345L, false, false, (char) 899, (char) 11574,
        Double.longBitsToDouble(0x3fee9ab7613924a0L), Double.longBitsToDouble(0x3fe3d0b35fd20beaL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 11, "\udac2\udf2f\udb8e\udd0d\uda51\udf5a\udab5\udef6\uda30\udf18\udbd5\udfe1\udb2a\uddf1\ud8e5\udd5d\ud85a\udf11\ud80e\uddad\ud8ed\udf54\ud9f6\udfc5\uf99d\ud8cd\udf7d\udb7a\udf6f\udace\uddac\ud91d\udd5d\udac2\udf2f\uda75\udf6d\uda6d\udc74\ud9a9\udc3e\uda89\udfe8\ud9e1\udf6f\ud843\udd35\udaea\udc28\ud94a\udcbc\udaad\uddfa\uda63\ude43\ud982\udf24\ud83a\udc90\ud93c\udc9b\ud9f0\uddfa\udba2\udcf5\ud941\udd40\ud8d6\uded2\ud8e2\ude85\udaed\udf49\uda9a\udfa6\ud803\udd07\udb46\udd85\ud87d\udd25\udbbf\udd16\udbea\udf66\udb2c\udd77\udb0a\ude9e\ud84e\ude3f\u56c5\udb47\udfad\udab9\ude1f\uda58\udc71\ud818\ude12\uda50\udd7c\udb54\ude6d\ud83e\udc30\ud950\udfe9\udbbf\ude48\udb87\udcdd\ud958\udeb6\udb7e\udc5a\udadf\udeb0\ud8b7\ude60\ud9a7\udcc3\uda79\udf26\udb07\udd9f\ud93a\udf3a\uda2e\ude84\udbd7\udd00\ud948\udc7a\udac1\udd1b\ud8ae\udd9b\uda92\udd53\ud8ca\udd6f\ud940\udf2c\ud8dc\udcbb\ud96f\udcd6\ud8ca\udcfe\udb42\udca3\uda9f\udcfd\udb70\udd95\udad2\udd67\ud89a\udf7b\ud8df\udc4c\ud919\ude8f\ud956\udee4\ud838\udcbb\udb94\ude8b\udb99\udfad\udbb3\udd47", "\u7b85\u27de\u15af\ud50a\u933c\u3f2b\u886e\u8ad3\u1c15\u6696\ua71a\u42bf\u6f1a\u6868\u1b29\u32d0\u9322\u2241\u8f18\u6a10", "\ud818\udc99\udb21\uddb1\ud891\udc50\ud900\udc6b\udafb\uddb7\udb18\udd95\ud9f5\udc2a\udbeb\udf0d\uda35\udcd5\udbc3\udc4c\uda0d\ude1f\uda3d\udf05\udb54\udc0a\udae4\ude0c\u5db7\ud8e5\udd5e\ud8d6\udf3e\ud864\udcd4\udb46\udd38\udaff\udc3d\udb34\udd17\ud8f9\uddc4\ud9bf\udc24\uda31\udf6e\ud820\udc7e\uda91\ude11\ud91d\udd81\uda3a\udd75\uda88\udf01\u15f0\udbdd\udff4\ud804\udd7f\ud976\udc2f\uda13\uddfb\ud8d0\ude8b\udb1a\udf2d\uda7f\udc2f\udb06\udf80\udbbd\udc82\uda3f\ude58",
        19, 33256, 926483069, -6819923369008347521L, 63076L, true, false, (char) 41723, (char) 7231,
        Double.longBitsToDouble(0x3fee2cfbe31c8047L), Double.longBitsToDouble(0x3fc735d022532d80L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 9, "\udab8\udfbb\udb3c\udfa0\uda9f\udf10\udab5\udef6\uda6e\udf4c\udac3\udfbd", "\u84da\ua46d\u6fb2\u8370\u413b\u9338\u1931\u6964\u9501\uc05e\u44fe\ua354\u7eef\u2bcf\u5b6f\ud051", "\ud866\udc06\udaf3\uddda\ud888\udf40\ud99c\udde5\ud851\udfc0\ud875\udc8b\udbd5\ude8a\ud9a7\udc90\ud9c8\udfa2\udbc4\udd4f",
        19, 41253, 1482712522, 3360672115127010627L, -67112L, false, false, (char) 12088, (char) 3993,
        Double.longBitsToDouble(0x3fdff541342692baL), Double.longBitsToDouble(0x3fdb6cf5fed84c60L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 11, "\udac2\udf2f\udbb0\udf1f\udaac\udcaf\ud8e3\udc46\uda30\udf43\udbd5\udfe1\udb2a\uddf1\ud8e5\udd5d\ud85a\udf11\ud80e\uddad\ud8ed\udf54\ud9f6\udfc5\uf99d\ud8cd\udf7d\udb7a\udf6f\udace\uddac\ud91d\udd5d\udac2\udf2f\uda75\udf6d\uda6d\udc74\ud9a9\udc3e\uda89\udfe8\ud9e1\udf6f\ud843\udd35\udaea\udc28\ud94a\udcbc\udaad\uddfa\uda63\ude43\ud982\udf24\ud83a\udc90\ud93c\udc9b\ud9f0\uddfa\udba2\udcf5\ud941\udd40\ud8d6\uded2\ud8e2\ude85\udaed\udf49\uda9a\udfa6\ud803\udd07\udb46\udd85\ud87d\udd25\udbbf\udd16\udbea\udf66\udb2c\udd77\udb0a\ude9e\uda39\ude6a\ud803\uddc8\udb36\udc78\udab9\ude1f\uda58\udc71\ud818\ude12\uda50\udd7c\udb54\ude6d\uda1b\udcbd\udb56\udfec\udbbf\ude48\ud84d\udc5f\udb1f\ude56\ud885\udc1d\udadf\udeb0\ud8b7\ude60\ud9a7\udcc3\uda79\udf26\udb07\udd9f\ud9bb\udfbc\uda59\udf33\udbd7\udd00\ud948\udc7a\udac1\udd1b\ud8ae\udd9b\uda92\udd53\ud8ca\udd6f\ud940\udf2c\uda8d\udcf5\udb37\udcfd\ud8ca\udd69\udb42\udca3\uda9f\udcfd\ud8c3\ude5e\udad2\udd67\ud844\udef1\ud8df\udc4c\ud919\ude8f\ud956\udee4\ud838\udcbb\udb94\ude8b\udb99\udfad\udbb3\udd47", "\u7b85\u8ad4\u02ef\ud50a\u933c\u3f2b\u886e\u8ad3\u1c15\u6696\ua71a\u42bf\u6f1a\u6868\u1b29\u32d0\u9322\u2241\u8f18\u6a10", "\ud818\udc99\udb21\uddb1\ud891\udc50\ud900\udc6b\udafb\uddb7\udb18\udd95\ud9f5\udc2a\udbeb\udf0d\uda35\udcd5\udbc3\udc4c\uda0d\ude1f\uda3d\udf05\udb54\udc0a\udae4\ude0c\uda1e\ude19\ud8e5\ude08\ud94a\udef9\ud864\udd51\udb46\udd38\udaff\udc3d\udb34\udd17\ud95a\udff4\uda0f\udd5b\uda31\udf6e\ud820\udc7e\uda91\ude11\ud91d\udd81\uda3a\udd75\uda88\udf01\udbfb\udcef\udbdd\udff4\ud804\udd7f\ud976\udc2f\uda13\uddfb\ud8d0\ude8b\udb1a\udf2d\uda7f\udc2f\udb06\udf80\udbbd\udc82\uda3f\ude58",
        19, 33256, 926483069, -6819923369008347521L, 63076L, true, false, (char) 41723, (char) 7231,
        Double.longBitsToDouble(0x3fee2cfbe31c8047L), Double.longBitsToDouble(0x3fc735d022532d80L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|equals|java.lang.Object|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|drawItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,int|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getGroupPaint||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getGroupStroke||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getIcon|java.awt.Shape,boolean,boolean|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getIcon|java.awt.Shape,java.awt.Paint,java.awt.Paint|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getMaxIcon||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getMinIcon||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getObjectIcon||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|isDrawLines||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|readObject|java.io.ObjectInputStream|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setDrawLines|boolean|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setGroupPaint|java.awt.Paint|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setGroupStroke|java.awt.Stroke|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setMaxIcon|javax.swing.Icon|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setMinIcon|javax.swing.Icon|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|equals|java.lang.Object|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
