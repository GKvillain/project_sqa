package org.jfree.chart.renderer.category;
import org.junit.Test;
import static org.junit.Assert.*;
public class MinMaxCategoryRenderer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\udb5b\udc06\ud847\udfa7\udbac\udf60\uda92\udf7c", "\u34db\u6bbd\u1275\u82ef", "\udba9\uddd8\ud95b\ude94",
        33, 53290, 72144784, 5961910651295197766L, -90047L, false, false, (char) 2117, (char) 612,
        Double.longBitsToDouble(0x3fea6ac323d9f4b5L), Double.longBitsToDouble(0x3fd11d0be21db5a8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 15, 1, "\udb5b\udc06\ud847\udfa7\udbac\udf60\udb65\udf05", "\u5b75\u1a86\u48b1\u82ef", "\udba9\uddd8\ud95b\ude94",
        33, 53290, 72144784, 5961910651851512572L, 83405L, true, false, (char) 16305, (char) 30862,
        Double.longBitsToDouble(0x3fd11d0be21db5a8L), Double.longBitsToDouble(0x3fe423bc8b53caf6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\udb5b\udc06\ud847\udfa7\udbac\udf60\uda92\udf7c", "\u87f7\u6fd5\ube29\u15a3", "\udba9\uddd8\ud99e\udf0d\ud985\udfc6",
        39, -897, 1388115494, 6418027791062802694L, -2681L, true, true, (char) 25570, (char) 63143,
        Double.longBitsToDouble(0x3fe5e338a30e67c9L), Double.longBitsToDouble(0x3fd1675574db2016L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 5, "\udb01\ude46\ud847\udfa7\udbac\udf60\uda4b\uded8", "\u34db\u6bbd\u1275\uc877", "\udba9\ude2d",
        54, 90568, 1028537290, 309859489245099558L, 39526L, true, true, (char) 12525, (char) 56394,
        Double.longBitsToDouble(0x3fbe3435ba6ac320L), Double.longBitsToDouble(0x3feecfa5a911d0beL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 7, 1, "\udb50\udf40\ud903\udfa5\ud8b6\udf65\uda92\udf7c", "\u572a\u6bbd\u1275\u81bf", "\udb63\uddd5\ud95b\ude94",
        1, 91061, 807742567, 5961913155261131334L, 61692L, true, false, (char) 58664, (char) 61957,
        Double.longBitsToDouble(0x3fe26370c3d99579L), Double.longBitsToDouble(0x3fd11d0be21db5a8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 9, "\u520b\udaa6\udf2f\udb5d\udea0\ud925\udf76\ud8b3\udc27\ud80f\udeaf\udb45\udd4b\ud8f0\udca4", "\uc591\ua19d\u1cea\ua737\u8038\u24e3", "\udb5a\ude98\ud89d\ude29",
        41, 57387, 475258589, 8135296423203533628L, 79151L, true, false, (char) 31898, (char) 45484,
        Double.longBitsToDouble(0x3fe24407ef89bb85L), Double.longBitsToDouble(0x3f9bb5d9bb1f71a0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udb5b\udc06", "\ucd88", "\udb70\udc59\uda24\udd26\ud9de\uddd9\000",
        -5, -1000, -957574912, 4878377611078319072L, -44816L, false, false, (char) 48386, (char) 31255,
        Double.longBitsToDouble(0x3fd1f94e2cb55126L), Double.longBitsToDouble(0x3fbb4ef6046f0eb0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 1, "\udb5b\udc06\ud87d\ude2e\udbac\udf60\uda92\udf7c", "\u350a\u6bbd\u1275\u0b4c\u36b6\u4e57", "\udbef\ude7f\udb89\udf66\udb77\udfd0\uda84\udf08\udadb\udf85\udab1\udc32\ud9e4\udf17\ud9b4\udc7c\udbdc\udf4e\ud932\udd62\ud9fd\udc19\ud8d6\udc26\ud8d7\udee0",
        3, 81387, -1464141086, 2907286120291670318L, 93620L, false, false, (char) 30431, (char) 11049,
        Double.longBitsToDouble(0x3fe7fbf6f7bd8a02L), Double.longBitsToDouble(0x3fef62dbd4c8a9f6L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$2:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 1, 8, 10, 1, "\udb5b\udc06\ud847\udfa7\udbac\udf60\uda92\udf7c\udb24\udd97", "\u6bbd\u1275\u82ef\u36b6\u4e57\u5d90\u52d4\u80aa\uc472\u5a06\u2ecc\u53d6\u5a11\uc181\u2d48\ua8ad\u0150\u89eb\ud3d6\u8503", "\udba4\udff0\ud9db\ude22\ud86b\udc4b\ud9aa\udc9b\uda84\udfe2\udb30\udc53\ud89a\udc63\ud85b\uddfe\udbec\udcfa\udbc0\udeab\udaaf\udc79\uf2b4\ud8a9\udff2\ud87e\udca0\udbeb\udd73\uda3c\ude00\uda14\udea0\uda22\ude00\udb1f\uddf0\uda41\udd14\ud90f\udf2b\udaf7\udefa\udb6c\udf6f\ud897\udf38\udb5f\uddc9\uda6d\udea1\u1bc6\ud82f\ude0e\uda0f\udd38\ud8d5\udda9\uda8b\uddf0\udb76\ude49\uda05\udd33\ud861\ude6b\ud812\ude53\ud978\uddea\udbe2\udd1f\u9283\ud9d1\udedf\ud9ac\ude24\ud9ba\udfc7\ud970\udde5",
        29, 5561, -1889564157, 6099222287908815892L, -78767L, false, false, (char) 1765, (char) 13765,
        Double.longBitsToDouble(0x3fef10c22f0b86e9L), Double.longBitsToDouble(0x3fefa44cd40948d7L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 6, 3, 1, "\udb73\ude67\udb88\ude88\u97c1\uda92\udef9", "\u34db\u2746\u7929\u8377\u36b6\u4e57", "\udbef\ude7f\u8754\udbd9\udcb0\ud8c0\udf06\udadb\udf85\udbe6\udf7c\ud828\udff8\udb7c\udde0\udbe4\udea5\ud9f5\uddc2\udaa5\udea2\ud810\udd10\ud8d7\udee0",
        17, 34793, 2005350641, -4318524633598532547L, -46601L, true, true, (char) 14772, (char) 56198,
        Double.longBitsToDouble(0x3fecf83469337a7fL), Double.longBitsToDouble(0x3fd7949943df6960L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 11, 0, 1, "\udaf9\uddd6\ud847\udfa7\udbac\udf60\uda92\udf7c", "_\u6bbd\u1275\u82ef", "\udbc0\udd43\ud95b\ude94",
        33, 14306, 0, 5961910488086440518L, 31072L, true, false, (char) 16305, (char) 30862,
        Double.longBitsToDouble(0x3fd11d0be21db400L), Double.longBitsToDouble(0x3fe9ff9774e45cccL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 11, "\udb5b\udc06\ud847\udfa7\udbac\udf60\ud8d1\udefb", "\u34db\u6bbd\ubd94\u1f8b", "\udba9\uddd8\ud8fc\ude4d",
        35, 53270, 67818515, 5961910651295197862L, -61898L, false, true, (char) 21517, (char) 612,
        Double.longBitsToDouble(0x3fea6ac323d9f4b5L), Double.longBitsToDouble(0x3fd11d0be21db5a8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 13, 15, "\udb5b\udc06\ud847\udfa7\udbac\udf60", "\ud373\u34db\u6bbd\ud1ad\uc4a3\ubc7c\u2fcb\u246c\u3d34\ua95a\u4b3a\u32ad\uc056\u206d\u155b\u6915\u2d48\u458f\u336c\u44ba\u9e4e\ud471\u8ad5\u21e2\uc016\u0342\ud10c\ua975\uae39\ua192", "\udb55\udfb1\ud8bb\udc54\udbfe\ude91\udb8d\udc0c\ud840\udfa0\udafe\ude5e\udadd\udef1\udafa\ude49\udbc8\udd2f\ud847\udfaa\ud838\udcd5\ud889\udd00\uda0b\udc65\udb76\udd2b\udb56\udfdb",
        50, 90708, -1523580914, 4980574910529628408L, 41476L, true, false, (char) 52048, (char) 44231,
        Double.longBitsToDouble(0x3febd564172b39caL), Double.longBitsToDouble(0x3fdf593ae18af0f8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\udb5a\udf3a", "\u858c\u4cf2\ud373\u1160", "\udb71\udeb7\udaa8\udc95",
        17, 5142, 1135835799, 3209583293129309130L, -99962L, false, false, (char) 31255, (char) 226,
        Double.longBitsToDouble(0x3fe2d5449c0000d8L), Double.longBitsToDouble(0x3fc1bc3add356190L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$2:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 14, 1, "\udb5a\udf67\ud847\udfa7\udbac\udf60\uda92\udf7c", "\u0e4a\ud2d2\u1275\u82ef", "\u21ef\uda46\udf93",
        33, 53290, 72144784, 5961910651295197766L, -90047L, false, false, (char) 2117, (char) 612,
        Double.longBitsToDouble(0x3fea6ac323d9f4b5L), Double.longBitsToDouble(0x3fd11d0bef0beba8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 12, 1, "\udb5b\udc06\ud847\udfa7\udbac\udf60\uda92\udf7c", "\u1b11\u6bbd\u1275\u82ef", "\udba9\uddd8\ud95b\ude94",
        33, 53290, 72144784, 5961910651295197766L, -90047L, false, false, (char) 2117, (char) 612,
        Double.longBitsToDouble(0x3fea6ac323d9f4b5L), Double.longBitsToDouble(0x3fd11d0be21db5a8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 11, 0, 0, "", "\u38b6\ucd88\u4cf2\ud373\u34db\u1301", "\udaa8\udc95",
        55, 5142, 1135835799, 3209584256230505418L, -36986L, false, false, (char) 31255, (char) 28161,
        Double.longBitsToDouble(0x3fe2d5449c6d3bd8L), Double.longBitsToDouble(0x3fc1bc3add356190L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$1:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 4, "\udb5b\udc19", "\u492a\u4cf2\ud373\u34db\u0fdc\u1214\u7af0", "\ud821\udece\uda95\udda6\ud9d4\ude32\ud97c\uddbd\ud90e\udcc3\ud890\udd02\udadb\udf83\ud805\ude0f\ud817\ude66",
        17, 89389, 1415901659, -806551997585846675L, 86634L, false, false, (char) 58837, (char) 64600,
        Double.longBitsToDouble(0x3fe5cfcc4dc5e697L), Double.longBitsToDouble(0x3fe50aabbb231cb6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 15, 11, "\udb5b\udc06\ud5a7\udb4a\udeca\ud833\udf29", "\u75d6\u6bbd\ua0ad\u5f98\u36b6\u9156\u6c60\u52d4\u80aa\u1ea0\ua743\ub035\u1d09\u8b08", "\ud90c\udd59\ud900\udd92\udbaf\uddb7",
        27, 91041, -1446016754, -1295366315332572502L, -63297L, true, true, (char) 30937, (char) 58450,
        Double.longBitsToDouble(0x3fb8add77551d850L), Double.longBitsToDouble(0x3f9970b9b6450220L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 11, 11, 1, "\u4684\ud86b\udd8f\udbac\udf60\uda92\udf7c", "\u34db\u6bbd\ub366\u831d", "\udba9\uddd8\ud80d\udf0d",
        17, 53290, 72144784, 5961910651295197766L, -21261L, true, false, (char) 16305, (char) 34578,
        Double.longBitsToDouble(0x3fe4d008b10edad4L), Double.longBitsToDouble(0x3fbc739436d22c30L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 1, "\udbe7\udd55\ud848\udc79\ud920\udc50\uda94\udfa4", "\u34db\u6bbd\u1275\u71a1", "\udba9\uddd8\ud95b\ude94\uda7c\udf65\udb89\udf8e\udb77\udfd0\ud8c0\udf06\udadb\udf85\udbe6\udeb5\udadb\ude71\uda0b\ude0b\udbe4\udea2\ud9f5\uddc2\udaa5\udea2\ud810\udd10\ud8a8\udee9\u40cc\ud867\udd92\ud878\udcd3\udb7d\udfd0\uda8c\udee0\ud9ca\udf17\udacd\udc57\udb29\udd65",
        28, 53884, 2005326610, -4556122971470379609L, 23086L, true, true, (char) 57781, (char) 2657,
        Double.longBitsToDouble(0x3fd1c43ba03caea8L), Double.longBitsToDouble(0x3fccf79503a52f60L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 1, "\udb5b\udc06\ud847\udfa7\udbac\udf60\uda92\udf7c\udbbb\udfb2", "\u6bbd\u1275\u82ef\u36b6\u4e57\u2d90\u52d4\u80aa\u3c56\u2432\ub0f1\u53ea\u5a11\ub4e8\uc8c9\ua8fa\u31a3", "\ud8d7\udee0\uda10\udec4",
        22, 86290, 950114501, 6190533700037313626L, 89591L, true, false, (char) 64825, (char) 51223,
        Double.longBitsToDouble(0x3fed7ee446844337L), Double.longBitsToDouble(0x3fd3589ee91f8b5eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 11, "\udb5b\udc06", "\ucd88\u4cf2\ud373\u34db", "\udac8\ude1a\udaa8\udc95",
        0, 99303, 1135838193, 3209584256230505418L, -36986L, false, false, (char) 31255, (char) 28161,
        Double.longBitsToDouble(0x3fe2d5449c6d3bd8L), Double.longBitsToDouble(0x3fc1bc3add356190L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\ud8f7\udc05\ud847\udfa7\udbac\udf60\uda92\udf7c\udb24\udd97\udabe\udc03\udb70\udc59\uda24\udd26\u14ed\ud87f\uddeb\udab3\ude79\ud837\udf0b\udba9\uddd8\ud95b\ude94\udbef\ude7f\udb89\udf66\udb77\udfd0\ud8c0\udf06\udadb\udf85\udbe6\udeb5\ud828\udff8\udb7c\udde0\udbe4\udea5\ud9f5\uddc2\udaa5\udea2\ud810\udd10\ud8d7\udee0\ud944\udede\udae3\udd3c\uda07\ude0e\ud85a\udd21\udb55\ude99\udb9d\udf8c\ud889\udcd7\udb4a\udca4\ud8b1\udcdb\uda8d\udcf8\uc67f\uda0c\ude31\ud8bf\udeaf\udb2a\udf65\ud8e8\ude59\ubdd9\udad8\udfd3\ud8f6\udd72\ud80f\uddf7\ud8cf\udcd9\ud80e\udef9\uda4b\udff6\ud8f7\udd4c\ud9eb\ude22\udbde\udeef\u434c\udb81\udc36\ud9c2\udd32\ud928\udf32\ud8f1\udc1e\ud9ea\ude07\ud85f\ude25\ud8f4\udfc0\ud828\udcfe\ud97b\udc34\u332c\uda50\ude58\ud974\udfcf\ud969\udc8d\ud94b\udea7\uda1b\udd5d\ud887\udc47\ud8f8\udd68\udbfa\ude13\ud9e5\uded9\ub056\uda40\udeae\ud81c\udf4d\udb6a\udc04\ud95d\udeb9\ud969\udc69\uda38\ude32\udad7\udd91\uda25\udca6\ud955\udff4\uda25\udce6\udab8\udc89\uda14\udc5f\uda63\uddda", "\u110e\u7b5c\uc7f8\ua269\u452b\ua057\u5922\u43a8\u4d58\uc89b\ub9e1\u0b67\u6f35", "\udb24\ude3d",
        16, 6886, 2078853208, -3877332606813805022L, -69047L, false, false, (char) 56315, (char) 64692,
        Double.longBitsToDouble(0x3fea0027129648aeL), Double.longBitsToDouble(0x3fe23933066ef879L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\udb5b\udc06", "\000", "\000",
        41, 3910, 1912602624, 5510154230264748731L, -100000L, false, false, (char) 15104, (char) 5342,
        Double.longBitsToDouble(0x3fe13022624652bcL), Double.longBitsToDouble(0x3fd06591123f29c4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 10, "\udbba\udec7\uda24\udf3b\udbac\udf60\ud8e0\udc82", "\u34db\u6bbd\u51f6\u82ef", "\udba9\uddd8\ud962\udd72",
        21, 59968, 1712464442, -2165852235472555792L, -79921L, true, true, (char) 4019, (char) 6870,
        Double.longBitsToDouble(0x3fb5ea0c5d9c9948L), Double.longBitsToDouble(0x3fe3a4de6d3419b6L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 11, 11, 1, "\udb5b\udc06\ud847\udfa7\udba2\ude1b\uda95\ude86", "\u34db\u6bbd\u1275\u8b86", "\udba9\uddd8\ud98d\udcd8",
        59, 95286, 72144784, 5961910651295197766L, -90047L, false, false, (char) 35055, (char) 612,
        Double.longBitsToDouble(0x3fea6ac323d9f4b5L), Double.longBitsToDouble(0x3fd11d0be61db5a8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udaf9\uddd6", "", "",
        -5, -1000, 0, 2233785415175777117L, -100000L, false, true, (char) 26708, (char) 5342,
        Double.longBitsToDouble(0x3fe1302262fc52bcL), Double.longBitsToDouble(0x3fbe1e8e80000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 15, 1, "\u8d00", "\u00fc", "",
        -5, -1000, 0, 8214565720323784724L, -62826L, true, false, (char) 65426, (char) 0,
        Double.longBitsToDouble(0x3fec81ea7626044cL), Double.longBitsToDouble(0x3fe7e295e4787a3aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\udb5b\udc06\ud847\udfa7\udbac\udf60\uda92\udf7c", "\u34db\u6bbd\u1275\u82ef", "\udba9\uddd8\uda41\udd8f\udbd7\udc7f\udb89\udf66\udb77\udfd0\ud8c0\udf06\udaf1\udc85\udbe6\udeb5\ud828\udff8\udbed\udf39\ud966\udedc\ud9f5\udd67\ud985\uddf1\ud9df\ude53\ud8d7\udedc",
        23, 83905, -1007954091, -5345014252379588509L, 50500L, true, false, (char) 35053, (char) 40229,
        Double.longBitsToDouble(0x3fd27ec0031497c4L), Double.longBitsToDouble(0x3fb8ca31d1292548L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.chart.renderer.category.MinMaxCategoryRenderer$2:@? |this=org.jfree.chart.renderer.category.MinMaxCategoryRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 14, 1, "\ud99e\ude60\ud847\udfa7\udbac\udf60\uda92\udf7c", "\u0e4a\ud2d2\u1275\u82ef\u36b6\u236e\u653c\u18ea\ub483\uc445\u9ca8\ub035\u50ed\u5a1f\uc181\u2d48", "\ud9b4\udea8\udbac\ude04\udaec\uddb6",
        11, 20768, -1849327683, 7343862165034715392L, 35199L, false, true, (char) 23075, (char) 57364,
        Double.longBitsToDouble(0x3fe3329681f86554L), Double.longBitsToDouble(0x3fa512bbadeb8b60L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 15, 11, "\udb5b\udc06\ud87c\udc4a\udb61\udd6b\ud9ea\ude6c\udb98\udede\ud854\ude67\udb1f\uddfd\uda3f\udedf\ud807\udc24\uda9d\udd94\udaa8\udcc2", "\u5337\u80aa\u1ea0\ud3d1\ub035\u1d09\u8b08\u9892\u2d6e\ubfe0\u269f\u0c2f\u11b9\u7848\u311e\u8ba9\u3bd4\u8c4e\u6cbc\uaa92\u60ae\u67ec\uadcb\uce32\u0f96\u95a9\u91f4\u5051\u0156\ua014\u83be\u0851\u2c60\u5eac\uba41\u7c94\u0f5f\u6c5b\u830e\u3795\u997c\u5cf3\u9e54\ua5f3\u7be1\u8e2d\u78ee\u7d27\ucaa6\u674b\u1298\u7716\u931f\u424a\u675c\u1bb4\ucd31\u9385\u1801\ucc0c\u7f2e\ua4db\ub1db\u8048\u5972\ubba3\u5bcb\u6099\u4656\u6f38\u5a43\u2552\u9691\uc4c2\u74f7\u3797\u135e\ubbe6\u0ee0\u6bf0\u60c2\u2882\u7238\u37ce\u4918\u74b5\ua4fa\ud5e2\u1eee\u2e2d\u2bc9\u025f\u6e27\u7092\u9158\uaca2\ua1d4\u1733\u3743\u2160\u7e0c\u9bde\u8946\u11df\u9226\ub526\u05cb\ubce8\uc8f1\u19c9\u179a", "\u84f5\ud8e1\udc9c\udb78\udf64\ud850\udfeb\udbd6\udcb4\udacd\udc7b\udb50\udef7\ud8d0\udc71\ud90c\udc85\ud961\uddbb\udb19\udc53\uda7d\udeb2\udb7a\udd76\ud80d\udd8c\udb6f\udd67\udbd4\udd38\u5401\udb3a\udd88\ud8a4\udd4c\udbc4\udf7d\ud958\uddf2\uda6d\ude03\ud8c0\uded6\ud87a\udee7",
        16, 11600, 645468584, 991337069797570419L, 82534L, true, true, (char) 60816, (char) 14951,
        Double.longBitsToDouble(0x3fda73ae08120a94L), Double.longBitsToDouble(0x3fe0ec59be6f52b3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|equals|java.lang.Object|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|drawItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,int|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getGroupPaint||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getGroupStroke||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getIcon|java.awt.Shape,boolean,boolean|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getIcon|java.awt.Shape,java.awt.Paint,java.awt.Paint|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getMaxIcon||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getMinIcon||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|getObjectIcon||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|isDrawLines||new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|readObject|java.io.ObjectInputStream|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setDrawLines|boolean|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setGroupPaint|java.awt.Paint|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setGroupStroke|java.awt.Stroke|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setMaxIcon|javax.swing.Icon|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|setMinIcon|javax.swing.Icon|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
    "M|org.jfree.chart.renderer.category.MinMaxCategoryRenderer|equals|java.lang.Object|new:org.jfree.chart.renderer.category.MinMaxCategoryRenderer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
