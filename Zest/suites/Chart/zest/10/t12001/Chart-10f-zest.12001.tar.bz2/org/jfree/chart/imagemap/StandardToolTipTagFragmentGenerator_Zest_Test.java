package org.jfree.chart.imagemap;
import org.junit.Test;
import static org.junit.Assert.*;
public class StandardToolTipTagFragmentGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u197a\u6c0f\u8ff1\u17c4\u4142\uc16f\u36d5\ube97\u2d94", "\ud961\udfa9\udb71\udf86\ud96a\udcb9\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82",
        4, 90288, -1253624092, -25249539473314082L, -40947L, true, true, (char) 61441, (char) 30513,
        Double.longBitsToDouble(0x3fafa897d7568db0L), Double.longBitsToDouble(0x3fe64db810c3815cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u6f67\u1c24\u6b7c\uc095\u8ba1\u00af\u136b\u49c7\u8ff1\u17c4\u4142\uc16f\u36d5\ube97\u2d94", "\ud961\udfa9\udb71\udf86\ud9ab\udcd9\000\uaff6\000\000\udb94\uddc9",
        4, 90288, -1253624092, -25249539473342242L, -40947L, true, true, (char) 61441, (char) 30513,
        Double.longBitsToDouble(0x3fafa897d7568db0L), Double.longBitsToDouble(0x3fe005b810c3815cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 0, "\uda8b\udfbd", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u7324\ucaa7\u8ff1\u17c4\u4142\uc16f\u36d5\ube97\ub0d5", "\ud98c\udf2d\udb71\udf86\udad7\uddb0\udafe\udd36\ud80d\ude28",
        1, 99596, 509247929, 6101886574743776272L, 11699L, false, false, (char) 34897, (char) 57479,
        Double.longBitsToDouble(0x3fd378edba9a456aL), Double.longBitsToDouble(0x3fdefb54207ea25eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\udb89\udc36\udaf4\uddd0\udaf6\udeef\udabe\udd68\ud99d\udcb1\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd\udb89\udc36\udaf4\uddd0\udaf6\udeef\udabe\udd68\ud99d\udcb1", "\u6564\u8e4e\u6c0f\u8ff1\u17c4\ud488\uc0df\u36d5\ube97\u2d94\ubd5b\u8dba\u610c\u764a\u6ad0\u85da\u3d6a\u29e1\u6631\u8db2\u2de0\u9130\u681b\u9c32", "\ubaa8\uda93\udf42\ud9a4\udce5",
        35, 19207, -1224555147, -9125257352805347133L, -46980L, true, false, (char) 35610, (char) 27349,
        Double.longBitsToDouble(0x3fe0460fc8b71ca3L), Double.longBitsToDouble(0x3fe7d7685ae09c00L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud80c\ude6d\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud80c\ude6d\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud80c\ude6d", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u197a\u6c0f\u68ab\uaaa0\u15a1\u94c7\uaa24\ud389\u1a38", "\ud961\udfa9\ud9bc\udd4b\ud81a\udd5e\ud8ed\ude1b\ud80d\ude28\u36a5\ud8d1\ude1a\ud984\udf8a",
        39, 99328, -1910900041, -25249659732398370L, -40947L, true, true, (char) 61441, (char) 30513,
        Double.longBitsToDouble(0x3fafa897d7568db0L), Double.longBitsToDouble(0x3fe64db810c3815cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud863\udebd\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud863\udebd", "\uc417", "\udb63\udd45\udaea\udde3\ud9f2\udd34\udbdd\udf57\udbb5\udc95\udbf0\ude5c\udbdb\udd1d\uda04\udfab\ud98c\uddba\ud9ee\udc4e\uda41\udeb4",
        48, 71623, 1207075655, 2647885128045487178L, -5616L, false, false, (char) 22319, (char) 24541,
        Double.longBitsToDouble(0x3f9054aedc966a60L), Double.longBitsToDouble(0x3fed6daa3edeffa6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u6f67\u1b90\u5607\u72e0\u5fa0\uaa62\u197a\u6c0f\u3da7\uc371\u4142\uc16f\u36d5\u0359\u2d94", "\ud957\ude1b",
        39, 30589, 1260815561, -47430518040785072L, 37287L, true, true, (char) 6504, (char) 59959,
        Double.longBitsToDouble(0x3fed6daa3edeff8cL), Double.longBitsToDouble(0x3feaf3c79953c734L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u6f67\u1c24\u0c00\uc095\u8ba1\uba64\u197a\u6c0f\u8ff1\u494c\u98cf\uc16f\u36d5\ube97\u2d94", "\ud961\udfa9\udb71\udf86\ud96a\udcb9\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud8f1\udf8b\udabe\ude7c\udac8\udfa7\udadf\uddfe\ud853\udc05\ubaa8\uda93\udf42",
        38, 98335, 1759238207, -5259424310638112055L, 60596L, true, true, (char) 43276, (char) 50860,
        Double.longBitsToDouble(0x3fea6a01490d058bL), Double.longBitsToDouble(0x3fe6d98687412755L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u88a3", "\udb63\udd45\udaea\udde3\ud9f2\udd34",
        47, 93418, -1227733331, 1704968396507618860L, 58342L, true, true, (char) 30054, (char) 35216,
        Double.longBitsToDouble(0x3fd47f632afe8e82L), Double.longBitsToDouble(0x3fb2892fe66d7980L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 0, "\uda8b\udfbd", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u137a\u6c0f\u8ff1\u17c4\ua087\uc16f\u36d5\u8326\u9380", "\udac8\udffd\udbd1\udec7\ud942\udcf8\udbdb\udf76\udb8b\udec9\ud81a\ude15\ud8ff\udf51\ud8ea\udf8d\ud973\udeb5\ud8f1\udf8b\udab6\ude72\udaf0\udc35",
        23, 21914, -839938705, 5492953242590236077L, -53183L, true, true, (char) 18891, (char) 37407,
        Double.longBitsToDouble(0x3fbead7fcbde3280L), Double.longBitsToDouble(0x3febcfccfc574435L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ubf43\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ubf43", "\u6f7f", "\u33ec\udad7\udda7",
        21, 5267, 707195614, -5273074504128808132L, 70216L, false, false, (char) 58214, (char) 30054,
        Double.longBitsToDouble(0x3fc2c9bf451fd8c8L), Double.longBitsToDouble(0x3fd7f47410dc497eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udbb3\udc48\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 1, 0, "\udbb3\udc48", "\u6f67\u1ecf\u77af\uc094\u8ba1\u6564\u197a\u6c0f\ub126\u17c4\u4142\u2d13\u82ae\ube97\u2d94", "\ud961\udfa9\udb71\udf86\ud96a\udcb9\udae8\udf6c\ud901\udf20\udb33\udfaf\ud88a\udfdf\udbb4\udf82",
        27, 25692, -1253624123, 2677597302867345597L, -40947L, true, true, (char) 61441, (char) 30513,
        Double.longBitsToDouble(0x3fafa897d7568db0L), Double.longBitsToDouble(0x3fe64db810c3815cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\udb89\udc36\udaf4\uddd0\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd\udb89\udc36\udaf4\uddd0", "\u77f8\uc095\u8ba1\u6564\u197a\u6bfb\u6334\u5736\u61f7\u1aee\u36d5\ube97\ud3cb\u8f06\u8dba\u610c\u6c83\u6ad0\u1e67\ucd1d\u29ca\u6631\u8db2", "\udabe\ude7c\udac8\udfa7",
        15, 44494, -1898243757, 2501165987299249485L, 12347L, true, false, (char) 29624, (char) 40438,
        Double.longBitsToDouble(0x3fe52f2a94a39939L), Double.longBitsToDouble(0x3fd5d14340ac0e2eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 0, "\uda8b\udf8b", "\ua12f\u6c0d\u0c00\uc095\u030a\u8929\u197a\u6c0f\u8ff1\u17c4\u4142\uc16f\u36d5\ube97\u2d94", "\ud961\udfa9\udb71\udf86\ud96a\udcb9\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82",
        4, 90288, -1253624092, -25249539473314082L, -40947L, false, false, (char) 7901, (char) 30513,
        Double.longBitsToDouble(0x3fafa897d7568db0L), Double.longBitsToDouble(0x3fe64db810c3815cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud96e\ude2f\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 0, "\ud96e\ude2f", "\u6f67", "\ud9bc\udf5d",
        14, 21283, -1159916693, 3037381190963316397L, 71564L, false, false, (char) 40730, (char) 58214,
        Double.longBitsToDouble(0x3fd295c3d21607f4L), Double.longBitsToDouble(0x3fd47f6b58fe8e82L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\ude95\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 0, "\uda8b\udfbd\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\ude95", "\u8ba1\uae19\u197a\u1b2c\u5351\u7d3c", "\ud9ee\udc4e\uda41\udeb4\ud988\udc89\uda2b\udf11\ud80a\ude86\ud961\udfa9\udb71\udf86\ud96a\udcb9\udafe\udd36\udab8\udd3e\u2dbf\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud8f1\udf8b",
        11, 37676, 2116843093, -4092629266869839533L, -21552L, true, true, (char) 10606, (char) 11856,
        Double.longBitsToDouble(0x3fe64db810c3815cL), Double.longBitsToDouble(0x3fc9443aeb88e53cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udb06\udfdb\ud9d2\udfb8\udaa2\uddc7\udaf6\udeef\udb45\udd48\ud903\udd4a\udb63\udd45\u84c1\udbce\udf2b\udbdd\udf57\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\udb06\udfdb\ud9d2\udfb8\udaa2\uddc7\udaf6\udeef\udb45\udd48\ud903\udd4a\udb63\udd45\u84c1\udbce\udf2b\udbdd\udf57", "\u17c4\u4142\uc16f\u36d5\ube97\u629d\u6c89\u8dba", "\ud96a\udcc1\udbc2\udd38",
        22, 33216, -1136570212, -8256583968077806277L, -48516L, true, true, (char) 28295, (char) 34897,
        Double.longBitsToDouble(0x3fd53c734a6f1db6L), Double.longBitsToDouble(0x3fd4d22b53df6a84L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfc4\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\ud9f2\udd34\udbdd\udf57\udbb5\udc95\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6", "\ube97\u2d94\u57f7\u8dba\ua11e\u6c83\u6ad0", "\udb75\udcbd\ud98f\udd54\udbb4\udf4b\uda0d\ude80\ud8f1\udf8b\udabe\ude7c\udac8\udfa7\udadf\uddfe\ud853\udc05\ubaa8\udbd3\udf42\ud9a4\udce5\udb43\udeb7\udbd3\ude6c\udb56\udd27\ud9c5\uddbd\ud8e7\ude73\udbd6\udc93\u8ad5\udb82\udf22\ud9ff\udc0b\ud914\udd10",
        20, 25594, -1268113000, -8955062294624972837L, -26716L, false, true, (char) 63434, (char) 50746,
        Double.longBitsToDouble(0x3fde9a0f6e578bacL), Double.longBitsToDouble(0x3fe3234c5ae0b7a1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u197a\u6c0f\u00ad\000\000\000\u364f\ube97\u2d94", "",
        8, 72600, -1160559411, 5415161600771849778L, 10436L, true, true, (char) 24541, (char) 16574,
        Double.longBitsToDouble(0x3fe7259a9badb547L), Double.longBitsToDouble(0x3fe6f7fd375e78f3L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\udb89\udc36\udb62\udd08\udb11\udf37\uda3b\udeb8\ud867\udf3c\udb63\udd45\udadd\udf4e\ud9f2\udd34\udbe3\udf34\udbb5\udc95\udbb5\udce2\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd\udb89\udc36\udb62\udd08\udb11\udf37\uda3b\udeb8\ud867\udf3c\udb63\udd45\udadd\udf4e\ud9f2\udd34\udbe3\udf34\udbb5\udc95\udbb5\udce2", "\u30bf\u5fd1\u5570\u2d94\u57a2\u8dba\u5b6b\u8827\u2578\u4d56\u3d6a\u29e1\u6631\u8a9e\u2de0\u9130\u1c8e\u9317\u0e38\u7bdc\u8339\u47ad\u2cb8\u0a28", "\ud9b6\udf52\udb84\udc22\ud9b0\ude2e\udb85\ude20\ud831\ude37\udafe\udf3c\ub49a\udbc8\uddb5\udad3\udc9f\uda40\udc80\udbdf\udf1f\ud8aa\uded9\udab1\udfaf\ufbb9\ud816\udcc1\ud981\udfd4\udb12\udee8\ud804\udfd4\udb8b\udc94\udb9b\udde9\ud860\udf65\udaf5\udd4d\ud876\uded9\udac6\udd67\ud91a\udf91\udafe\udd0a\udbe7\udda4\ud9ed\udd08\udbd7\udc27\udbf5\udf82\ud885\udd48\ud819\ude3a",
        28, 62503, -842356500, 8461889108203022332L, 19057L, false, false, (char) 59734, (char) 24171,
        Double.longBitsToDouble(0x3fb7e4a2b3746ee0L), Double.longBitsToDouble(0x3fe18efce05da043L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\udacc\ude2e\ud8d8\udd2e\ud800\udc68\ud900\udf36\udbdb\udc6f\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\ud993\ude1b\ud979\uddc1\ud828\udf02\udbf7\udd79\ud961\udfa9\udb71\udf86\udb89\udca0\ud827\udd3b\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "\uda8b\udfbd\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\udacc\ude2e\ud8d8\udd2e\ud800\udc68\ud900\udf36\udbdb\udc6f\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\ud993\ude1b\ud979\uddc1\ud828\udf02\udbf7\udd79\ud961\udfa9\udb71\udf86\udb89\udca0\ud827\udd3b", "\u046b\u0118\ud42f\ud5b4\u82bf\uc97b\u0e38\u240d\u8339\ua06f\u8587\u0a28\u6c86\u1ef3\u3cb1\u621d\u35d9\u4f52", "\ud9b3\udc79\ud8fb\udfeb\ud8be\udd8b\uda5d\udce1\udba8\udf96\uda0e\uddbb\udba9\ude4c\uda06\udcae\uda5b\udc86\udae4\udcae\udb31\udf6e\ud894\ude9b\ud9a8\udc6b\udabb\udc1e\uda1e\ude0c\udb7b\udea2\ud9e7\udc09",
        2, 84607, 1319091225, -6813025636595170437L, 45086L, false, true, (char) 60583, (char) 49728,
        Double.longBitsToDouble(0x3fd1d0a3f1c9453eL), Double.longBitsToDouble(0x3fef60fe171ab579L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00a2", "",
        -5, -1000, 1813490565, 4960647412257643L, 49165L, true, true, (char) 169, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e38000000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\000", "",
        46, 34565, -1845493760, -4981804262516919782L, -100000L, false, false, (char) 50177, (char) 3570,
        Double.longBitsToDouble(0x3fd456200000b87aL), Double.longBitsToDouble(0x3fecb2680047f632L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud8bd\udcdc\ud8d5\udc90\udb13\udf40\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\ud9f2\udd34\udaee\uddbe\udb82\ude91\ud9a8\ude49\udbf9\udebb\ud8fe\udcb6\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud8bd\udcdc\ud8d5\udc90\udb13\udf40\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\ud9f2\udd34\udaee\uddbe\udb82\ude91\ud9a8\ude49\udbf9\udebb\ud8fe\udcb6", "\ube97\u2d94\u57f7\u4adb\u610c\u6c83\u6ad0", "\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud8f1\udf8b\udabe\ude7c\udac8\udfa7\udadf\uddfe\ud853\udc05\ubaa8\uda93\udf42\ud9a4\udce5\udb43\udeb7\udbd3\ude6c\udb56\udd27",
        47, 90691, 1767831162, 5682642924771947331L, -11374L, true, true, (char) 10519, (char) 16727,
        Double.longBitsToDouble(0x3fd2739f88e91a12L), Double.longBitsToDouble(0x3fc2fc7578403aa0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda1c\udc41\udb94\udfcb\uda9a\udcff", "\u7bd6\uc095\u8ba1\u6564\u197a\u6c0f\u8ff1\u17c4\u4142\uc16f\u36d5\ube97\u2d94\u57f7\u8dba\u610c\u31d9\ud4a1\u06de\u76da\u22e2\u9a62\u8db2", "\udabe\ude7c",
        53, 87790, -952889506, -8152894855568822985L, -97935L, true, true, (char) 11801, (char) 31947,
        Double.longBitsToDouble(0x3fc87039dabced14L), Double.longBitsToDouble(0x3febe2dd7ae9d23dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\uda32\udf2b\ud983\udd2e\uda6e\udc1a\udac9\udd12\udbb2\udda2\ud995\ude02\ud9d2\udc4b\ud9f2\udd2e\ud810\udfb1\udb7e\udee2\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud8f1\udf8b\udabe\ude7c\udac8\udfa7\udadf\uddfe\udae9\udffa\ubaa8\uda0f\udc9f\uda51\udf17\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\uda8b\udfbd\uda32\udf2b\ud983\udd2e\uda6e\udc1a\udac9\udd12\udbb2\udda2\ud995\ude02\ud9d2\udc4b\ud9f2\udd2e\ud810\udfb1\udb7e\udee2\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud8f1\udf8b\udabe\ude7c\udac8\udfa7\udadf\uddfe\udae9\udffa\ubaa8\uda0f\udc9f\uda51\udf17", "\u9fbc\u4bd7\ud03c\u46a2", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\udb3e\udf6e\udaac\udff5\ud8b3\udc4f",
        10, 90628, -633430829, -1671704972653080084L, -90629L, true, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fe5543b2d5d53daL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda8b\udfbd\udb89\udc36\udafe\udc75\udaf6\udeef\uda3b\uddc3\ud810\udf2a\ud967\udd47\udaea\udde3\ud9f2\udd34\ud919\udf52\ud99f\udc7e\ud9d0\udf42\udbdb\udd1d\ud89d\ude46\ud80d\udcb3\ud9ee\udc4e\uda41\udeb4\ud955\udd90\ud9c0\udf34\uda02\udf76\ud98c\udf2d\ud868\udf01\udad7\udd70\udafe\udd36\ud833\udd1b\udbbb\ude49\ud8d3\udf1c\udbb4\udf82\udafa\uddcb\ud8f1\udfce\udabe\ude7c\udac8\udfa7\udadf\uddfe\ud924\udc06\ud88b\ude15\ud810\udf12\udb3e\udc18\udb43\udeb7\udbb8\udf9f\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 0, "\uda8b\udfbd\udb89\udc36\udafe\udc75\udaf6\udeef\uda3b\uddc3\ud810\udf2a\ud967\udd47\udaea\udde3\ud9f2\udd34\ud919\udf52\ud99f\udc7e\ud9d0\udf42\udbdb\udd1d\ud89d\ude46\ud80d\udcb3\ud9ee\udc4e\uda41\udeb4\ud955\udd90\ud9c0\udf34\uda02\udf76\ud98c\udf2d\ud868\udf01\udad7\udd70\udafe\udd36\ud833\udd1b\udbbb\ude49\ud8d3\udf1c\udbb4\udf82\udafa\uddcb\ud8f1\udfce\udabe\ude7c\udac8\udfa7\udadf\uddfe\ud924\udc06\ud88b\ude15\ud810\udf12\udb3e\udc18\udb43\udeb7\udbb8\udf9f", "\ub7be", "\u8197\udb96\udee1\ud865\udeae\ud98a\udd7c\udab4\udfd8\ud9e7\udf4e\u3acd\ud9b9\udd11\udbe2\udedf\uda45\udc78\ud821\udc50\udba9\udfe8\ud9f9\udead\ud994\udeeb\udb6b\udc65\uda3d\udc82\ud92e\udd0e\ud804\udd9b\ud969\udcb2\u3ddd\udaa4\udc5c\ud99b\udca6\ud811\udee5\udba7\udcee\ud8df\ude55\ud9d3\udd46\uda2b\udfab\u4e00\uda84\udee9\udbe6\udcbf\ud92f\udd6b\ud9aa\ude38\udb44\udec2\ud808\udda3\ud830\udcbe\ud84e\udfa5\udb8e\udd36\ud8a4\udfcd\udabf\udc99\udbc3\udd3a\ud86d\udc72\udaa2\udf21\uda2c\udeac\udad4\ude77\ud859\ude80\udbfc\udf4b",
        38, 94084, 899307371, 3541709396916208429L, -57591L, false, false, (char) 61858, (char) 36776,
        Double.longBitsToDouble(0x3fcd3aec484b9e00L), Double.longBitsToDouble(0x3fdd83330dc437fcL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda9c\udc35\ud939\udf79\ud8c6\udece\udaf6\udeef\ud922\udee3\u1fb6\uda67\udf84\ud928\udc33\ud9ee\udc6b\udbdd\udf57\ud97b\udd72\uda67\udfdb", "\u94c7\uaa24\ud389\ua989\u1b22\017\ub66d", "\ud939\ude39\ud867\ude53\ud817\ude90\uda0a\udce6\udba2\udfe5\ud9f4\udda5",
        4, 18959, -5869423, 8715431602700947294L, 35881L, true, true, (char) 47205, (char) 49211,
        Double.longBitsToDouble(0x3fd7559aa5936e04L), Double.longBitsToDouble(0x3fc8302b8f7ac34cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 0, "\ud80c\ude6d", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u197a\u6c0f\u68ab\uaaa0\u15a1\u94c7\uaa24\ud389\u1a38", "\ud961\udfa9\ud9bc\udd4b\ud81a\udd5e\ud8ed\ude1b\ud80d\ude28\u36a5",
        51, 46001, 1459687299, 9081426286388837047L, -62846L, false, true, (char) 57479, (char) 31762,
        Double.longBitsToDouble(0x3fd4d22b53df6a84L), Double.longBitsToDouble(0x3fafa897d7568db0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud80c\ude5e\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\udb3d\ude58\udbe5\udc73\udbb5\udc95\uda67\udfdb\u296a\uda42\udcbd\udbd2\udd56\ud9d4\udf9e\udace\udf18\udbdb\udc37\ud840\udeb4\udbf4\ude79\ud961\udfa9\ud9bc\udd4b\ud81a\udd5e\ud8ed\ude1b\ud80d\ude28\u36a5\udbb9\udeae\uda61\uddb8\uda47\udc6c\ud94b\udc85\uda91\udc00\udac8\udf8b\udadf\uddfe\ud852\udffb\ubaa8\uda93\udf42\ud9a4\udce5\udb43\udeb7\udba3\ude6c\udb56\udd27\ud995\udc52\ud810\udd28\udab8\udec7\ud901\udf43\uda2f\uddb9\udb89\udf2d\ud8b2\udf11\u318d\ud9e8\ude13\udad9\udd9e\u313a\udb7e\udefb\ud977\udd0e\udaf6\udc83\ud9c8\uddd7\uda75\udd29\udb61\udf5b\udaa1\udc6a\ud81e\udddf\udade\udf01\udb51\udff6\ud93e\udd11\udb1a\udc3c\ud822\udc98\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud80c\ude5e\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\udb3d\ude58\udbe5\udc73\udbb5\udc95\uda67\udfdb\u296a\uda42\udcbd\udbd2\udd56\ud9d4\udf9e\udace\udf18\udbdb\udc37\ud840\udeb4\udbf4\ude79\ud961\udfa9\ud9bc\udd4b\ud81a\udd5e\ud8ed\ude1b\ud80d\ude28\u36a5\udbb9\udeae\uda61\uddb8\uda47\udc6c\ud94b\udc85\uda91\udc00\udac8\udf8b\udadf\uddfe\ud852\udffb\ubaa8\uda93\udf42\ud9a4\udce5\udb43\udeb7\udba3\ude6c\udb56\udd27\ud995\udc52\ud810\udd28\udab8\udec7\ud901\udf43\uda2f\uddb9\udb89\udf2d\ud8b2\udf11\u318d\ud9e8\ude13\udad9\udd9e\u313a\udb7e\udefb\ud977\udd0e\udaf6\udc83\ud9c8\uddd7\uda75\udd29\udb61\udf5b\udaa1\udc6a\ud81e\udddf\udade\udf01\udb51\udff6\ud93e\udd11\udb1a\udc3c\ud822\udc98\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud80c\ude5e\udb89\udc36\udaf4\uddd0\udaf6\udeef\uda3b\uddc3\ud867\udf3c\udb63\udd45\udaea\udde3\udb3d\ude58\udbe5\udc73\udbb5\udc95\uda67\udfdb\u296a\uda42\udcbd\udbd2\udd56\ud9d4\udf9e\udace\udf18\udbdb\udc37\ud840\udeb4\udbf4\ude79\ud961\udfa9\ud9bc\udd4b\ud81a\udd5e\ud8ed\ude1b\ud80d\ude28\u36a5\udbb9\udeae\uda61\uddb8\uda47\udc6c\ud94b\udc85\uda91\udc00\udac8\udf8b\udadf\uddfe\ud852\udffb\ubaa8\uda93\udf42\ud9a4\udce5\udb43\udeb7\udba3\ude6c\udb56\udd27\ud995\udc52\ud810\udd28\udab8\udec7\ud901\udf43\uda2f\uddb9\udb89\udf2d\ud8b2\udf11\u318d\ud9e8\ude13\udad9\udd9e\u313a\udb7e\udefb\ud977\udd0e\udaf6\udc83\ud9c8\uddd7\uda75\udd29\udb61\udf5b\udaa1\udc6a\ud81e\udddf\udade\udf01\udb51\udff6\ud93e\udd11\udb1a\udc3c\ud822\udc98", "\u2a08\u3c30\u296c\u5b5c\u5e1c\u3f4b\u9644\ud2a9\u1e30\u4387\ud2a6\u7b11\u4ff7\ub777\u689e\u4aee\u69f4\u5d7c\u9e90\u49ef\ua873\u6d0e\u7e5c\u73c4\ucf03\ub3d1\u322e\ubd22\u9d67", "\uda20\udcf9",
        31, 61083, 1067339558, 5190920040710994646L, -659L, true, true, (char) 30315, (char) 59091,
        Double.longBitsToDouble(0x3fe7c9969015ac22L), Double.longBitsToDouble(0x3fec1294fc3258c4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u197a\u6c0f\u8ff1\u3cde\u4142\uc16f\u36d5\ube97\u2d94", "\ud961\udfa9\udb71\udf86\ud96a\udcb9\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82",
        4, 90288, -1253624092, -25249539473314082L, -40947L, true, true, (char) 61441, (char) 30513,
        Double.longBitsToDouble(0x3fafa897d7568db0L), Double.longBitsToDouble(0x3fe64db810c3815cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\u197b\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udac9\udd12&amp;\000\000\000\ud810\udfb1\udb7e\udee2\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\000\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\u197b\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udac9\udd12&\000\000\000\ud810\udfb1\udb7e\udee2\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\000\000", "\u9fbc\u00f3\ucbb7\u46a2", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\udb3e\udf6e\udaac\udff5\ud8b3\udc4f",
        10, 90628, -633430829, -1671704972653080084L, -90629L, true, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fe5543b2d5d53daL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\u19d3\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udac9\udd12&amp;\000\000\000\ud810\udfb1\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udbc5\udc99\udabe\udd98\udac8\udfa7\udacd\uded6\ud84f\udebb\ud8a9\udfb4&#092;\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\u19d3\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udac9\udd12&\000\000\000\ud810\udfb1\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udbc5\udc99\udabe\udd98\udac8\udfa7\udacd\uded6\ud84f\udebb\ud8a9\udfb4\\\000", "\u9fbc\u00f3\ucbb7\u46a2", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\udb3e\udf6e\ud908\udddd\ud8b3\udc56",
        10, 90628, -633430829, -1671704972653080084L, -90629L, true, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fe5543b2d5d53daL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda6a\uddc6\ud923\udf56\udbc0\udfe4\ud97f\udfc2\udac9\udd12&amp;\000\000\000\udbee\ude10\udb3d\udf54\ud899\udeb2\udbcb\ude1f\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb62\udf69\ud9e3\uddb3\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud847\udd14\udabe\ude84\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\ud874\udd79\ud831\ude04\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\uda6a\uddc6\ud923\udf56\udbc0\udfe4\ud97f\udfc2\udac9\udd12&amp;\000\000\000\udbee\ude10\udb3d\udf54\ud899\udeb2\udbcb\ude1f\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb62\udf69\ud9e3\uddb3\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud847\udd14\udabe\ude84\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\ud874\udd79\ud831\ude04\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\uda6a\uddc6\ud923\udf56\udbc0\udfe4\ud97f\udfc2\udac9\udd12&\000\000\000\udbee\ude10\udb3d\udf54\ud899\udeb2\udbcb\ude1f\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb62\udf69\ud9e3\uddb3\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\ud847\udd14\udabe\ude84\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\ud874\udd79\ud831\ude04", "\u3b54\u00f3\u26cc\u28d0", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\udb3e\udf6e\udaac\udff5\ud8b3\udc4f",
        10, 90628, -633430829, -1671704973792481300L, -90629L, true, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fd5ac2beffe6182L), Double.longBitsToDouble(0x3fe5543b2d5d53daL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udb44\udd79\ud918\udea7\ud840\udf1f\udb36\udf7e\ud8b1\udd24&quot;\000\000&quot;\ud810\udfb1\udb7e\udf6f\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud901\udd0a\u3728\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\uda4e\uddec\udba0\udd5f\u8700\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\udb44\udd79\ud918\udea7\ud840\udf1f\udb36\udf7e\ud8b1\udd24\"\000\000\"\ud810\udfb1\udb7e\udf6f\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud901\udd0a\u3728\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\uda4e\uddec\udba0\udd5f\u8700\000", "\u9fbc\u00f3\ucbb7\u799d", "\ud89c\udc36\udb84\ude96\udbb3\udc44\ud9e3\udcc3\udb3e\udf6e\udb46\udce0\u4720",
        30, 90628, -633430829, 5177342073578770068L, -90629L, true, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fccab6cb5754d88L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\u19d3\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udb73\udda8&quot;\000\000\uda50\udcc8\ud833\udddf\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\udb2b\udddb\udb4a\udfa5\ud8fb\udcea\ud91f\udfae\ud850\udc2f\u7ff2\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud8e8\udf3a\ud98b\udc6a\udbc5\udc99\udabe\udd98\udac8\udfa7\udacd\uded6\ud84f\udebb\ud8a9\udfb4&#092;\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\u19d3\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udb73\udda8\"\000\000\uda50\udcc8\ud833\udddf\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\udb2b\udddb\udb4a\udfa5\ud8fb\udcea\ud91f\udfae\ud850\udc2f\u7ff2\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud8e8\udf3a\ud98b\udc6a\udbc5\udc99\udabe\udd98\udac8\udfa7\udacd\uded6\ud84f\udebb\ud8a9\udfb4\\\000", "\u9fbc\u00f3\ucbb7\uaf2b", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\udb3e\udf6e\ud908\udddd\ud8b3\udc56",
        10, 90628, -633430829, -1671704972653080084L, -90629L, false, false, (char) 47617, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fe5543b2d5d53daL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udb44\udd79\ud918\udea7\ud840\udf1f\udb36\udf7e\ud80c\ude48\ud8c9\udcf5&lt;\000&quot;\ud810\udfb1\udb7e\udf6f\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud901\udd0a\u3728\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\uda4e\uddec\udba0\udd5f\u8700\uda7a\udf75\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\udb44\udd79\ud918\udea7\ud840\udf1f\udb36\udf7e\ud80c\ude48\ud8c9\udcf5<\000\"\ud810\udfb1\udb7e\udf6f\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud955\udd90\udb4a\udf3c\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud901\udd0a\u3728\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\uda4e\uddec\udba0\udd5f\u8700\uda7a\udf75", "\u9fbc\u00f3\ucbb7\u799d\ucace\u3e1b\u63e2\u6580\u85a9\uc01d", "\u4720\ud99e\udca2\uf89a\ud974\ude99\udbe0\udd6a\ud8c3\udcba",
        24, 24629, 1752578703, 5892447936536561939L, -5793L, true, false, (char) 39103, (char) 50627,
        Double.longBitsToDouble(0x3fe2e10647b6174cL), Double.longBitsToDouble(0x3fd751189f260684L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda8b\udfbd", "\u6f67\u1c24\u0c00\uc095\u8ba1\u6564\u197a\u6c0f\u8ff1\u17c4\u4142\uc16f\u36d5\ube97\u2d94", "\ud961\udfa9\udb71\udf86\ud96a\udcb9\udafe\udd36\ud80d\ude28\uda34\udc25\ud8d1\ude1a\udbb4\udf82",
        4, 90288, -1253624092, -25249539473314082L, -40947L, true, true, (char) 61441, (char) 30513,
        Double.longBitsToDouble(0x3fafa897d7568db0L), Double.longBitsToDouble(0x3fe64db810c3815cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\u19d3\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udac9\udd12&amp;\000\000\ud8c3\udf0d\ud810\udfb1\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud865\udd2b\uda41\uded7\u200a\uda14\udf58\udb6b\udd7d\uda2c\ude81\uda35\uddab\ufbfc\ud941\udeb9\uda9b\udf67\udb6d\udf41\ud9ee\udc69\ud958\ude52\ud98b\udc6a\ud922\udde8\ud8b5\udd15\udae5\uded5\udacd\uded6\udbf7\ude54\ud936\ude82\udb53\udea0\ud811\udd89\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\u19d3\udb3a\udd3c\ud983\udd2e\uda6e\udc1a\udac9\udd12&\000\000\ud8c3\udf0d\ud810\udfb1\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud865\udd2b\uda41\uded7\u200a\uda14\udf58\udb6b\udd7d\uda2c\ude81\uda35\uddab\ufbfc\ud941\udeb9\uda9b\udf67\udb6d\udf41\ud9ee\udc69\ud958\ude52\ud98b\udc6a\ud922\udde8\ud8b5\udd15\udae5\uded5\udacd\uded6\udbf7\ude54\ud936\ude82\udb53\udea0\ud811\udd89", "\u9fbc\u00f3\ucbb7\u46a2\ud7ce\u2371\u61ae\u45d88\u16f5\uc325\u9ccd\uc99c\u4448\u8b09\u7013\ucdaf\u0402\u2574\u6305\u0e5e\u100d\u7157\u746a\u390e\u220c\u7d74\u2067\u5410\u88aa\ud27e\u6b33\u52ad\u3313\u5f0f\ub8c1\ub97b\u785a\u54c9\u512b\u477f\uc0b9", "\udbf1\udd7f\ud89b\udeb7\uda74\udc01\udac6\udf28\ud8c5\udd33\udabd\udd4c\udb89\uddf0\udb8c\udd10\udbba\ude33\u26e8\udb5c\udd6f\udaa2\udd17\ud80b\udd80\uda0d\udc98\ud8e1\udd6f\ud90e\udfbb\udb6b\udd48\udb32\udf02\ud927\ude36\uda17\udfaf\u61fc\ud9c0\ude62\uda20\uddf5\ud891\udedf\udb74\udfeb\ud8ee\udeb5\ud9e7\udf62\u79f8\udaa4\udcfe\ud93a\udd95\udbc3\udda9\uda4e\udeb6\uda60\udf90\ud96a\udc7e\udb5d\udf79\udbdf\ude91\ud9d6\ude21\uda4f\udcc8\udbd9\uddad\ud91e\udd5c\ud805\ude52\udbf5\udecc\ud806\uddf7\ud86b\udd74\ud99f\udfd3\ud9d8\uded7\udb38\udff7\uda34\udc50\udb10\ude2c",
        19, 43911, 1912014149, 5071274172921736799L, -73983L, false, true, (char) 53137, (char) 43517,
        Double.longBitsToDouble(0x3fc77710140b65c8L), Double.longBitsToDouble(0x3fe3455b3dc5e3a6L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud896\ude3f\ud9b9\udd2a\ud983\udd2e\uda6e\udc1a\ud9e1\ude5e&#39;\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud84f\udc55\ud84f\udebb\ud8a9\udfb4\udbff\ude3a\ud973\uddf9\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\ud896\ude3f\ud9b9\udd2a\ud983\udd2e\uda6e\udc1a\ud9e1\ude5e'\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\ud9ee\udc4e\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud84f\udc55\ud84f\udebb\ud8a9\udfb4\udbff\ude3a\ud973\uddf9", "\u9fbc\u07b3\ucc8b\u46a2", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\ud802\udf70\ud908\udddd\ud8b3\udc56",
        46, 90725, -633430829, -1671704972653080084L, -90629L, true, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fec1ff1c55d53daL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud896\ude3f\ud9b9\udd2a\ud94d\udd33\uda6e\udc1a\ud9e1\ude5e&#39;\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\udb6c\udf55\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud9b1\udc95\ud84f\udebb\ud8a9\udfb4\udbff\ude3a\ud973\uddf9\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud896\ude3f\ud9b9\udd2a\ud94d\udd33\uda6e\udc1a\ud9e1\ude5e&#39;\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\udb6c\udf55\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud9b1\udc95\ud84f\udebb\ud8a9\udfb4\udbff\ude3a\ud973\uddf9\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud896\ude3f\ud9b9\udd2a\ud94d\udd33\uda6e\udc1a\ud9e1\ude5e'\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\udb6c\udf55\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud9b1\udc95\ud84f\udebb\ud8a9\udfb4\udbff\ude3a\ud973\uddf9", "\u9fbc\u4bd9\u8608\u470c", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\ud802\udf70\ud908\udddd\ud8b3\udc56",
        46, 90725, -633430829, -1671704972653080084L, -90629L, false, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fec1ff1c55d53daL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\u197b\udb6e\udc96\ud8de\udebd\ud865\uddce\udb6b\udfde&gt;\000\000\000\ud810\udfb1\udb7e\udee2\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud91b\udc26\ud9e9\udde3\ud955\udd90\ud892\udee0\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\000\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\u197b\udb6e\udc96\ud8de\udebd\ud865\uddce\udb6b\udfde>\000\000\000\ud810\udfb1\udb7e\udee2\udbf0\ude5c\udbdb\udd1d\ud8fe\udcb6\ud98c\uddba\ud91b\udc26\ud9e9\udde3\ud955\udd90\ud892\udee0\uda02\udf76\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\000\000", "\u9fbc\u00f3\ucbb7\u46a2", "\udbf5\udc8a\udbd3\ude0a\udb05\udf10\ud9be\udefe\udb3e\udf6e\udaac\udff5\ud8b3\udc4f",
        10, 90628, -633430829, -5562815050701188792L, -90629L, true, false, (char) 60934, (char) 11540,
        Double.longBitsToDouble(0x3fc43857dffde8c8L), Double.longBitsToDouble(0x3fe55136955d53daL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud896\ude3f\ud9b9\udd2a\ud94d\udd33\uda6e\udc1a\ud9e1\ude5e&#39;\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\udb6c\udf55\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud9b1\udc95\ud84f\udebb\ud8a9\udfb4&#092;\ud973\uddf9\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud896\ude3f\ud9b9\udd2a\ud94d\udd33\uda6e\udc1a\ud9e1\ude5e&#39;\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\udb6c\udf55\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud9b1\udc95\ud84f\udebb\ud8a9\udfb4&#092;\ud973\uddf9\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud896\ude3f\ud9b9\udd2a\ud94d\udd33\uda6e\udc1a\ud9e1\ude5e'\u9200\000\ud802\udee2\ud827\uddca\udac8\udf48\ud98d\udfd6\uda99\udcba\ud8fe\udcb6\ud98c\uddba\udb6c\udf55\u9cbc\udb2b\udddb\udb4a\udfa5\uda02\udf76\ud98c\udf2d\uda3f\udc8b\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\ud958\ude52\ud98b\udc6a\udac5\ude99\udabe\udd98\udac8\udfa7\ud9b1\udc95\ud84f\udebb\ud8a9\udfb4\\\ud973\uddf9", "\u9fbc\u4bd9\u8608\u470c", "\udbfe\udda8\udbd3\ude0a\udb05\udf10\ud9be\udefe\ud802\udf70\ud908\udddd\ud8b3\udc56",
        46, 90725, -633430829, -1671704972653080084L, -90629L, false, false, (char) 38657, (char) 6873,
        Double.longBitsToDouble(0x3fe50e15f7ff30c1L), Double.longBitsToDouble(0x3fec1ff1c55d53daL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\u197b\udb6e\udc96\ud8de\udebd\ud865\uddce\udb6b\udfde&gt;\000\000\000\ud810\udfb1\u8175\udbf0\ude01\udbdb\udd1d\ud9c3\udf79\udaa6\udd37\ud91b\udc26\ud9e9\udde3\ud955\udd90\ud892\udee0\uda02\udf76\ud98c\udf2d\udb51\ude63\uda05\ude51\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\ud9c1\udfb0\udafb\udd02\udba0\udd5f\000\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\u197b\udb6e\udc96\ud8de\udebd\ud865\uddce\udb6b\udfde&gt;\000\000\000\ud810\udfb1\u8175\udbf0\ude01\udbdb\udd1d\ud9c3\udf79\udaa6\udd37\ud91b\udc26\ud9e9\udde3\ud955\udd90\ud892\udee0\uda02\udf76\ud98c\udf2d\udb51\ude63\uda05\ude51\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\ud9c1\udfb0\udafb\udd02\udba0\udd5f\000\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\u197b\udb6e\udc96\ud8de\udebd\ud865\uddce\udb6b\udfde>\000\000\000\ud810\udfb1\u8175\udbf0\ude01\udbdb\udd1d\ud9c3\udf79\udaa6\udd37\ud91b\udc26\ud9e9\udde3\ud955\udd90\ud892\udee0\uda02\udf76\ud98c\udf2d\udb51\ude63\uda05\ude51\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\ud9c1\udfb0\udafb\udd02\udba0\udd5f\000\000", "\u9fbc\u00f3\ucbb7\u46a2", "\ud92b\udce4\udba8\uddb1\udb05\udf10\udbf7\ude3d\udb3e\udf6e\udaac\udff5\ud8b3\udc4f",
        10, 90628, -633430829, 129734878223331350L, -99376L, true, true, (char) 62047, (char) 59953,
        Double.longBitsToDouble(0x3fe55136955d53daL), Double.longBitsToDouble(0x3feee47cb0a4563fL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udb44\udd79\ud918\udea7\ud840\udf1f\udb36\udf7e\udb25\udd1e&quot;\000\000&quot;\ud810\udfb1\udb7e\udf6f\ud8ed\udc9a\udbdb\udd1d\ud986\uddc5\udb76\udfc4\uda35\uddc0\uda41\udeb9\ud955\udd90\udb4a\udf3c\ud829\udd72\ud98c\udf2d\u5e0b\u8bb2\udafe\udd36\ud901\udd0a\u2e49\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\uda4e\uddec\ucb13\u870b\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\udb44\udd79\ud918\udea7\ud840\udf1f\udb36\udf7e\udb25\udd1e&quot;\000\000&quot;\ud810\udfb1\udb7e\udf6f\ud8ed\udc9a\udbdb\udd1d\ud986\uddc5\udb76\udfc4\uda35\uddc0\uda41\udeb9\ud955\udd90\udb4a\udf3c\ud829\udd72\ud98c\udf2d\u5e0b\u8bb2\udafe\udd36\ud901\udd0a\u2e49\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\uda4e\uddec\ucb13\u870b\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udb44\udd79\ud918\udea7\ud840\udf1f\udb36\udf7e\udb25\udd1e\"\000\000\"\ud810\udfb1\udb7e\udf6f\ud8ed\udc9a\udbdb\udd1d\ud986\uddc5\udb76\udfc4\uda35\uddc0\uda41\udeb9\ud955\udd90\udb4a\udf3c\ud829\udd72\ud98c\udf2d\u5e0b\u8bb2\udafe\udd36\ud901\udd0a\u2e49\ud8d1\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\udadf\uddfe\uda4e\uddec\ucb13\u870b\000", "\u9fbc\u00f3\ucbb7\u799d", "\udb2d\udfbc\ud963\ude3c\udbb3\udc44\ud9e3\udcc3\udb3e\udf6e\udb46\udce0\u4720",
        30, 90628, -633411676, 5177342073578770068L, 40443L, false, false, (char) 29631, (char) 12692,
        Double.longBitsToDouble(0x3fe14b0297ff3025L), Double.longBitsToDouble(0x3fccab6cb5754d88L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udb52\udf02\ud918\udea7\ud827\udd51\udb36\udf82\ud870\udeb8\ud8c9\udcf5&lt;\000&quot;\ud810\udfb1\ud89f\udee6\ud975\ude13\uda1e\udf76\u5133\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud983\udc66\udb42\udd29\uda02\udecc\ud9f2\ude8a\ud8a3\udea0\ud810\udcf3\udafe\udd36\ud901\udd0a\u3728\ud8db\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\ud9be\udd8f\uda4e\udda5\udba0\udd5f\udaa1\udf79\ud8eb\ude4a\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\udb52\udf02\ud918\udea7\ud827\udd51\udb36\udf82\ud870\udeb8\ud8c9\udcf5&lt;\000&quot;\ud810\udfb1\ud89f\udee6\ud975\ude13\uda1e\udf76\u5133\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud983\udc66\udb42\udd29\uda02\udecc\ud9f2\ude8a\ud8a3\udea0\ud810\udcf3\udafe\udd36\ud901\udd0a\u3728\ud8db\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\ud9be\udd8f\uda4e\udda5\udba0\udd5f\udaa1\udf79\ud8eb\ude4a\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udb52\udf02\ud918\udea7\ud827\udd51\udb36\udf82\ud870\udeb8\ud8c9\udcf5<\000\"\ud810\udfb1\ud89f\udee6\ud975\ude13\uda1e\udf76\u5133\ud98c\uddba\ud9ee\udc4e\uda41\udeb4\ud983\udc66\udb42\udd29\uda02\udecc\ud9f2\ude8a\ud8a3\udea0\ud810\udcf3\udafe\udd36\ud901\udd0a\u3728\ud8db\ude1a\udbb4\udf82\uda0d\ude80\udbc5\udc14\udabe\udd98\udac8\udfa7\ud9be\udd8f\uda4e\udda5\udba0\udd5f\udaa1\udf79\ud8eb\ude4a", "\uc2fd\u00f3\ucbb7\u799d\ucace\u3e1b\u63e2\u6580\u85a9\uc01d", "\ud82e\udc0d\ud83f\ude9b\uf89a\udae3\udc30\udbd7\udfba\ud8c3\udcba",
        51, 4338, 166431906, 5892643868649638163L, -5793L, true, false, (char) 39103, (char) 50627,
        Double.longBitsToDouble(0x3fe2e10647b6174cL), Double.longBitsToDouble(0x3fd75118991e0684L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud8cb\udc90\udbf9\udcaf\uda87\udd24\ud865\uddce\udb6b\udfde&gt;\udb3f\udd5e\udb50\udc82\udae0\udf70\uda9b\ude45\udb55\ude8b\udacd\udc51\udadc\udefd&gt;\ud81a\udefe\ud8fa\udde9\ud9e9\ude5d\udbb1\udcf5\uda21\udf9d\uda02\udeae\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbd0\udf82\uda0d\ude80\ud90d\ude28\udabe\udd98\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\ud81e\udc0e\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud8cb\udc90\udbf9\udcaf\uda87\udd24\ud865\uddce\udb6b\udfde&gt;\udb3f\udd5e\udb50\udc82\udae0\udf70\uda9b\ude45\udb55\ude8b\udacd\udc51\udadc\udefd&gt;\ud81a\udefe\ud8fa\udde9\ud9e9\ude5d\udbb1\udcf5\uda21\udf9d\uda02\udeae\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbd0\udf82\uda0d\ude80\ud90d\ude28\udabe\udd98\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\ud81e\udc0e\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud8cb\udc90\udbf9\udcaf\uda87\udd24\ud865\uddce\udb6b\udfde>\udb3f\udd5e\udb50\udc82\udae0\udf70\uda9b\ude45\udb55\ude8b\udacd\udc51\udadc\udefd>\ud81a\udefe\ud8fa\udde9\ud9e9\ude5d\udbb1\udcf5\uda21\udf9d\uda02\udeae\ud98c\udf2d\udb71\udf86\ufbfc\udafe\udd36\ud80d\ude28\u36a5\ud8d1\ude1a\udbd0\udf82\uda0d\ude80\ud90d\ude28\udabe\udd98\udac8\udfa7\udadf\uddfe\udae9\udffa\udba0\udd5f\ud81e\udc0e\000", "\u9fbc\ud35a\ucbb7\u46a2", "\udbf5\udc8a\udb87\udfde\udb9b\udf1b\ud9be\udefe\udb3e\udf6e\ud90a\uddc4\ud8c8\udc5b",
        5, 5568, -633430993, 1155945363008428293L, -90556L, true, false, (char) 53651, (char) 59269,
        Double.longBitsToDouble(0x3fe2eb64e7ff7a1aL), Double.longBitsToDouble(0x3fe55386955d53daL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator|generateToolTipFragment|java.lang.String|new:org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:",
    "C|org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator|<init>|",
    "M|org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator|generateToolTipFragment|java.lang.String|new:org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
