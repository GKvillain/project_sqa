package org.jfree.chart.imagemap;
import org.junit.Test;
import static org.junit.Assert.*;
public class StandardToolTipTagFragmentGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udadb\udf79", "\ucb09\ub65d\u726d\u9079\u64ac\u3675\u5e55\u09a1\u7757\u00a9\u11ed\uc77c\u488c\u79c1\u39e2\u4652\021\ud48d\u5c74", "\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76",
        16, 26949, -821009593, -1253105919669315123L, 91353L, false, true, (char) 26667, (char) 36532,
        Double.longBitsToDouble(0x3fe4cb432a4af96aL), Double.longBitsToDouble(0x3fe238fde6297462L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udadb\udf79", "\ucb09\u1e5e\u969b\u9079\u64ac\u3675\u5e55\u09a1\u7757\u00a9\u11ed\uc77c\u488c\u79c1\u58b4\u8152\021\ud48d\u5c74", "\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76",
        16, 26949, -821009593, -1253105922135565875L, 37695L, true, false, (char) 3113, (char) 22808,
        Double.longBitsToDouble(0x3fb88cf276a9bef8L), Double.longBitsToDouble(0x3fe4cb432a4af96aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\ud8ef\udfa4", "\ud345\ub65d\u726d\u9079\u64ac\u3675\u5e55\u09a1\u7757\u00a9\u11ed\uc77c\u488c\u79c1\u39e2\u4652\u5a34\u1c46\ua46b", "\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\ud875\udfe2\udbb7\udf22\ud97c\ude38",
        4, 91216, -786786210, -2795659702079279879L, 22346L, false, false, (char) 36532, (char) 4862,
        Double.longBitsToDouble(0x3fe257cb56471fbcL), Double.longBitsToDouble(0x3fe14ba3134dbe24L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udadb\udf79\udad7\udf85\udb89\udea6\ud8d8\udfba\ud982\udecd\ud9b2\udf85\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\udb9e\udd78\udb4e\uded7\u324a\udabe\udc07\ud912\udd04\udb4e\udeb7\udb84\udd5b\ud81a\udd8c\ud850\udfbd\udbc4\udd07\uda13\uded5\udbef\udc9d\uda74\udfff\ud8d1\udf3c\ud965\udcf0\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\udadb\udf79\udad7\udf85\udb89\udea6\ud8d8\udfba\ud982\udecd\ud9b2\udf85\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\udb9e\udd78\udb4e\uded7\u324a\udabe\udc07\ud912\udd04\udb4e\udeb7\udb84\udd5b\ud81a\udd8c\ud850\udfbd\udbc4\udd07\uda13\uded5\udbef\udc9d\uda74\udfff\ud8d1\udf3c\ud965\udcf0", "\u427b\u3538\u3e50\u4c2f\u6969\uc19d\u3c7b\u83b7\u5578\u434b\uc64d\u454b\ub302\u6fae\uc037\ub30e", "\uda03\ude4b\uda23\udf8f\ud931\ude13",
        22, 25500, 514443791, 3437564961640623943L, -69579L, false, true, (char) 39124, (char) 64246,
        Double.longBitsToDouble(0x3fd13cec6a5c2bdeL), Double.longBitsToDouble(0x3fe42846dec998e0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 0, "\udadb\udf79", "\ucb09\ub65d\u726d\u9079\u5613\u862c\u2fc1\u6bed\u244f\u00a9\u11ed\uc77c\u488c\u79c1\u39e2", "\udacc\ude1e\uda30\udfd2\udbef\udcda",
        52, 23829, 1010182500, 6287541708674847998L, -88806L, true, false, (char) 34348, (char) 3113,
        Double.longBitsToDouble(0x3fdea7b2e8c46792L), Double.longBitsToDouble(0x3fe6a9befa996865L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udadb\udf79\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\udadb\udf79\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udadb\udf79", "\ucb09\ub65d\u726d\u9079\u64ac\u3675\u5e55\u09a1\u7757\u00a9\u11ed\uc77c\u488c\u79c1\u39e2\u4652\021\ud48d\u5c74", "\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76",
        16, 26949, -821009593, -1253105919669315123L, 91353L, false, true, (char) 26667, (char) 36532,
        Double.longBitsToDouble(0x3fe4cb432a4af96aL), Double.longBitsToDouble(0x3fe238fde6297462L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udadb\udf79\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 1, 0, "\udadb\udf79", "\ucb09\ub65d\u726d\u9079\uc7a2\uc7d6\u15a0\u09a1\u7757\u00a9\u11ed\uc77c\u488c\u79c1\u39e2\u4652\021\ud48d\u5c74", "\uda40\udeab",
        44, 37383, 134501630, -4566908556123231475L, -88806L, true, false, (char) 34348, (char) 3113,
        Double.longBitsToDouble(0x3fdea7b2e8c46792L), Double.longBitsToDouble(0x3fe6a9befa996865L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udab9\ude26\udad7\udf85\ud9ab\udd41", "\u9272\u902a", "\udb2a\udcf8\ud8ae\udc92\udb93\udd6e\udb83\udc98\ud908\udccd\ud960\udf00\ud964\udd2a",
        2, 5280, -1261592630, 3888902368259897735L, -44424L, true, true, (char) 53816, (char) 48154,
        Double.longBitsToDouble(0x3fddf3c363fcae82L), Double.longBitsToDouble(0x3fd61e510b203f40L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udada\udf9d\udad8\udc20\ud99a\udc95\udaa0\udfb8\udac8\uddeb\ud9ce\udeb2\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07", "\u39e2\u4652\021", "\udbef\udcda\uda88\udc4d\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\udb4c\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\ud9c5\udd36\udaa0\udc2d\ud94d\udda9\ud95a\ude45\ud914\udcf7\udba3\udfac",
        24, 42977, 532464202, 8386465871093741097L, -1440L, false, true, (char) 52154, (char) 52951,
        Double.longBitsToDouble(0x3fef30e91f1b871eL), Double.longBitsToDouble(0x3fd9df208216105cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\ud8f9\udefd", "\ucb09\ub65d", "\ud819\udeaa",
        20, 10528, -1291782302, -9112308086971720288L, -26L, true, true, (char) 42908, (char) 37634,
        Double.longBitsToDouble(0x3fdad048c8c9256cL), Double.longBitsToDouble(0x3fddf3cd49fcae82L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udaee\udc5d\udad7\udf85\ud99a\udc95\ud8d8\udfba\udb91\udecf\uda49\ude86\udac1\udf7d\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb62\udce8\ud873\udfbe\uda0d\ude45", "\u48a2\u935f\u3a33\u4652\021\ud48d\u8a61", "\ud8d5\udc38\ud965\udcf0\ud82d\udf9d\udbc7\udd76\udb4c\udd20\uda7c\udc05\ud87e\udcdb\u0fe8\ucc2b\uda86\udf17\udbde\udc61\ud887\udee6\udb01\udf3c\ud835\udd06\udba3\udfac\udaeb\udcfe\ud9dc\udda5\udb2f\udc28\udb67\udd22\ud82b\udec7\ud812\udca6\udbfc\uddcf\ud91c\udf63\uda2a\udc23\ud8d6\udd3c\udabe\ude8f\uda67\udf12\ud84a\udc7e\ud974\udc19\udad6\udd53\udb31\udf90\ud9fb\uded6\udbe2\udc2d\udaee\udfc0\ud983\udc39\ud98a\ude0f\ud98d\udd78\uda9b\udebd\ud803\udca8\ud890\udea8",
        28, 32272, -1024756888, -4754670661933433835L, 272L, false, false, (char) 25760, (char) 44362,
        Double.longBitsToDouble(0x3fc7b209d6a95b7cL), Double.longBitsToDouble(0x3fdb17a67e7c85d8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda22\udc48\udad7\udf9f\ud99a\udc95\uda17\udd96\udacb\udec5\ud9ce\udeb2\udac1\udfe7\ud8b1\ude97\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "\uda22\udc48\udad7\udf9f\ud99a\udc95\uda17\udd96\udacb\udec5\ud9ce\udeb2\udac1\udfe7\ud8b1\ude97", "\u2128\u5e75\u48df\u6ee5\u09d5", "\ud9a2\udc72\uda0a\udf03\ud8a8\udf4c\ud8a5\udedd\uda30\udfd2\udb5d\udd71\ud8c2\udc77\u246a\ud965\udcff\ud980\udf03",
        50, 10069, 1163143949, -3526209351929031986L, -88806L, true, false, (char) 34348, (char) 39054,
        Double.longBitsToDouble(0x3fdea7b2e8c46792L), Double.longBitsToDouble(0x3fe6a9befa66ef66L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "v", "\ucb09", "\000",
        3, 40663, 0, 2560L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe3ba202772ddc2L), Double.longBitsToDouble(0x3f9ab40000000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udbf1\udf54\udad7\udf85\ud970\udd95\ud8d8\udfba\udac8\uddeb\ud9ce\udeb2\ud9b3\udcbc\ud9c8\udce3\udb08\udcf5\uda16\udf8b\udb24\udee9\ud987\udd0d\ud802\udfc3\u324a\ud946\udedd\ud8da\udc54\ud86f\udd26\ud96a\udef7\udb2e\udd94\udbd2\udf9e", "\u25a9\u511f\u3426\ud0c0\ucd49\u5e7e\u19bf\u3538\u29b4\u7631\u6969\uc19d\u3c7b\u83b7\u5578\u434b\u369a\u0a90\u72cb\u6fe7\uc037\ub5e0\u5ac2\u34eb\u3078\ube8c\u7e0e\uc617\ub093\u4376\u520d\u6a7c\ub46a\u40ec\u8ac6\u13d1K\u4776\u397c\u8b19\uba04\uab12\uba67\u5675\ua595\u720a\u0093\u2f4f\u8c70", "\udadc\udeb3\udbd2\udfd4\u765f\ud8a7\udd40\uda2e\ude12\udb65\udc55\ud870\ude58\ud9a5\ude9f\uda2b\ude38\udb4f\udefa\ud96d\udef2\udbc2\udd01\ud8d4\uddeb\udb6e\udc98",
        49, 87426, 530079441, -2619870425988952282L, 45768L, true, false, (char) 15573, (char) 52140,
        Double.longBitsToDouble(0x3fc0759b505f9b00L), Double.longBitsToDouble(0x3fe4c57fc26e9be4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\ud947\udd78", "\ucb09\ub65d\u726d\u9079\u64ac\u3675\u4954\u09a1\u7757\u00a9\u11ed\uc77c\u488c\u79c1\u39e2\u4652\021\ud48d\u5c74", "\000",
        10, 37383, 134501630, -4566908556546921715L, -88806L, true, false, (char) 34348, (char) 3113,
        Double.longBitsToDouble(0x3fdea7b2e8c46792L), Double.longBitsToDouble(0x3fe6a9bef8000065L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "", "\u9acb\ucb09\ub65d", "\ud9c8\udca3",
        6, 79774, 14424827, 0L, -100000L, false, false, (char) 0, (char) 61050,
        Double.longBitsToDouble(0x3feb96ee101ab4cdL), Double.longBitsToDouble(0x3fd8735f86a7049cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 1, "\udadb\udf79", "\ucb09\u4e94\u6689\u9079\u4e28\ubc1d\ub765\u8741\u341b\u00a9\u11ed\uc77c\u488c\u79c1\u39e2\u8d8a\uc9bd\u8e21\u1588", "\ud8d1\udf3c\udae3\ude79\ud97f\udd12\udbc7\udd76",
        16, 26949, -2030598612, 2093295103396642503L, -75063L, true, false, (char) 40382, (char) 22808,
        Double.longBitsToDouble(0x3fb026113db16570L), Double.longBitsToDouble(0x3fe7e5b9a5d4be11L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 0, "", "", "\udac8\udda6",
        -1, 55640, -1846606048, 19699567582773248L, -100000L, false, false, (char) 70, (char) 5376,
        Double.longBitsToDouble(0x3ea1800000000000L), Double.longBitsToDouble(0x3fe3ba200772ddc2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udadb\udf79\udad7\udf85\udadc\udffb\u781d\ud924\udcaf\ud9ce\udeb2\udac1\udfe7\ud9a4\udec7\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "\udadb\udf79\udad7\udf85\udadc\udffb\u781d\ud924\udcaf\ud9ce\udeb2\udac1\udfe7\ud9a4\udec7", "\u08d5\u7757\u00a9\u11ed\u7b2d\ucd01\u91b8\u1726\u4652\021\u04fb\ua66d\u2eff\u511f\uabd4\u17ed\u14f2", "\udbb7\udf22",
        7, 26542, 684513741, 1817250526856989303L, 91353L, false, false, (char) 26718, (char) 36532,
        Double.longBitsToDouble(0x3fe4cb432a4af96aL), Double.longBitsToDouble(0x3fe238fde6297462L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udadb\udfca\udad7\udf85\ud99a\udc95\ud8d8\udfba\udac8\uddeb\uda94\udcb7\udac1\udfe7\ud9c8\udca3", "\u9d7c", "\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud9a2\udc72\uda0a\udf03\ud8a8\udf48\udacc\ude1e\uda30\udfd2\udbef\udcda",
        52, 41357, 1010182500, 6287541708674847998L, -50822L, false, false, (char) 21173, (char) 45482,
        Double.longBitsToDouble(0x3fe257cb56471fbcL), Double.longBitsToDouble(0x3fe14ba3104ee38dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 1, 1, "\udaee\udc79\udad7\udf85", "\ub65d\u4f9d\u2157\u64ac\u3675", "\ud987\udd0d\ud802\udfc3\u324a\udb18\udd95\ud8c1\udc88\udae5\udcf9\uda60\udcda\uda0a\udf03\ud916\udf3f\udacc\ude1e\uda30\udfd2\udbef\udcda\uda74\udfff",
        5, 31779, -1775521965, 3045053738314456511L, -74585L, false, false, (char) 51317, (char) 21477,
        Double.longBitsToDouble(0x3fe3b8c9c4f9d933L), Double.longBitsToDouble(0x3febc90585ea7b2eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\000\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "\000", "\ucb09", "\udac1\udfe7\ud9c8\udca3\udb39\udd23",
        4, 59395, -1634268469, 4919848052765019453L, 12466L, false, true, (char) 3405, (char) 47156,
        Double.longBitsToDouble(0x3f9ab4cd0006bf00L), Double.longBitsToDouble(0x3fea9c1006e880b4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udadb\udf79\udad7\udf85\udb89\udea6\ud8d8\udfba\ud982\udecd\ud9b2\udf85\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\uda91\udf5f\udb4e\uded7\u324a\udabe\udc07\ud912\udd04\udb4e\udeb7\udb84\udd5b\ud9a5\udf12\ud883\udc5a\udbc4\udd07\uda13\uded5\udbef\udc9d\ud9bc\ude02\ud8d1\udf3c\ud965\udcf0\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\udadb\udf79\udad7\udf85\udb89\udea6\ud8d8\udfba\ud982\udecd\ud9b2\udf85\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\uda91\udf5f\udb4e\uded7\u324a\udabe\udc07\ud912\udd04\udb4e\udeb7\udb84\udd5b\ud9a5\udf12\ud883\udc5a\udbc4\udd07\uda13\uded5\udbef\udc9d\ud9bc\ude02\ud8d1\udf3c\ud965\udcf0", "\u427b\u3538\u3e50\u4c2f\u6969\uc19d\u3c7b\u83b7\uabc7\u6760\u4e9f\u44e7\ub302\u6fae\uc037\u6817", "\uda03\ude4b\uda23\udf8f\ud931\ude13\udae3\udd65\udb9f\udd8b\uda6f\uded7\ud974\udfc2\ud95a\udd71\ub631\uda48\udef2\uda8f\udf17\udaa6\udda7\ud945\udcf9\udba5\ude5d\uda69\uddb3\ud8d5\udc71\uda34\udc31\ud91b\udf0f\udbf7\ude99\ud9b3\ude23\ud800\ude86\ud888\udd96\ud968\ude9c\ud99f\udc24\uda74\ude65\udb22\ude86\ud9d4\udd16\u5bc3\udaf4\udfc6\udb8f\udd9c\uda15\ude1c\udb17\udd33\uda05\ude04\ud973\udd75\ud85b\udee3\uda9f\udd4b\uda00\ude7e\uda1b\udf0f\udad9\udfef",
        52, 54674, -53182530, -4346912193358639548L, -79983L, false, true, (char) 57817, (char) 4464,
        Double.longBitsToDouble(0x3fe39f75a1da09f7L), Double.longBitsToDouble(0x3fc14dd1faa6e460L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud832\udfa5\udb30\udd5e\udb89\ude65\ud8d8\udfba\ud982\udecd\ud87e\udf8b\ud85c\udf3b\udb95\udc5f\udb39\udd23\uda0a\udda3\udb24\udee9\udb9e\udd78\udb4e\uded7\ud9be\udca2\udabd\udf89\ud912\udd04\udb4e\udeb7\udb84\udd5b\ud81a\udd8c\uda03\udf95\udb31\udd9d\uda13\uded5\udbef\udc9d\uda74\udfff\udafd\udf0e\ud965\udcf0\ud8de\udcb3\udbdd\uddef\ud938\udc7c\udbb7\udf22\uda93\udc44\udaa3\udfc4\ucc2b\ud9c5\udd36\udaa0\udc2d\ud887\udee6\ud982\udebb\ud914\udcf7\uda19\uddd6\ud941\udf56\udbbc\udf1b\udb2e\udfef\udb67\udd22\ud932\udcca\uda2c\udfa2\ud9cf\udce3\uda03\ude4b\uda23\udf8f\ud931\ude13\ud9e0\udca3\udb9f\udd89\ud9a9\udc8a\udacc\udeae\ud95a\udd8e\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\ud832\udfa5\udb30\udd5e\udb89\ude65\ud8d8\udfba\ud982\udecd\ud87e\udf8b\ud85c\udf3b\udb95\udc5f\udb39\udd23\uda0a\udda3\udb24\udee9\udb9e\udd78\udb4e\uded7\ud9be\udca2\udabd\udf89\ud912\udd04\udb4e\udeb7\udb84\udd5b\ud81a\udd8c\uda03\udf95\udb31\udd9d\uda13\uded5\udbef\udc9d\uda74\udfff\udafd\udf0e\ud965\udcf0\ud8de\udcb3\udbdd\uddef\ud938\udc7c\udbb7\udf22\uda93\udc44\udaa3\udfc4\ucc2b\ud9c5\udd36\udaa0\udc2d\ud887\udee6\ud982\udebb\ud914\udcf7\uda19\uddd6\ud941\udf56\udbbc\udf1b\udb2e\udfef\udb67\udd22\ud932\udcca\uda2c\udfa2\ud9cf\udce3\uda03\ude4b\uda23\udf8f\ud931\ude13\ud9e0\udca3\udb9f\udd89\ud9a9\udc8a\udacc\udeae\ud95a\udd8e", "\u80fa\u4308\u4d88\u9b12\u57ad\u904c\u3f57", "\udb09\udf03\ud98a\udf84\ud8fc\udf49\udaa2\udd3c",
        50, 37742, 583385491, -1877501911357023399L, 35121L, true, true, (char) 20703, (char) 34892,
        Double.longBitsToDouble(0x3fe53fda7ef41c42L), Double.longBitsToDouble(0x3fbd66d320383a38L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String: title=\"v\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "v", "\u0082", "",
        55, 68848, 138804391, -19129605L, -22109L, true, true, (char) 58240, (char) 35,
        Double.longBitsToDouble(0x3fd0000004ee8808L), Double.longBitsToDouble(0x3feb96ee101ab4cdL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud82c\udd41\uda6e\udfff\ud99a\udc95\ud8d8\udfba\udac8\uddeb\u70db\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\ud9e9\ude6b\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud844\uddc2\ud8f3\udd9f\ud8a8\udf48\udacc\ude1e\uda30\udfd2\udbef\udcda\uda74\udfff\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\udb4c\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\udaca\uddfc\udb93\ude5e\udb75\udfe6\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud82c\udd41\uda6e\udfff\ud99a\udc95\ud8d8\udfba\udac8\uddeb\u70db\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\ud9e9\ude6b\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud844\uddc2\ud8f3\udd9f\ud8a8\udf48\udacc\ude1e\uda30\udfd2\udbef\udcda\uda74\udfff\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\udb4c\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\udaca\uddfc\udb93\ude5e\udb75\udfe6\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud82c\udd41\uda6e\udfff\ud99a\udc95\ud8d8\udfba\udac8\uddeb\u70db\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\ud9e9\ude6b\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud844\uddc2\ud8f3\udd9f\ud8a8\udf48\udacc\ude1e\uda30\udfd2\udbef\udcda\uda74\udfff\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\udb4c\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\udaca\uddfc\udb93\ude5e\udb75\udfe6", "\u369a\u0a90\u8888\u7094\uc037\u231f\u5d1c\u5353\u5e44\u21b2\u18fa\u4074\u5868\u0245\u6cc4\u716b", "\udb94\ude08\udb5b\udf9f",
        17, 70314, 1363610936, 2870394479977347121L, -67732L, true, true, (char) 55740, (char) 17273,
        Double.longBitsToDouble(0x3fedacd25266c798L), Double.longBitsToDouble(0x3fe24c299200aec3L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda47\udf9e\ud95e\udce3\ud99f\udc05\uda21\ude0d\uda04\ude85\ud9f9\udfbd\uda8b\ude93\udbc2\udcf8\ud82a\udd7b\ud9df\udf93\ud88c\uddfc\ud987\udcc9\ud802\udfc3\u324a\ud9dc\udcb7\ud8c0\udfee\udae5\udcf9\uda60\udcda\uda0a\udf03\ud8fd\udc53\udb38\udc5d\uda30\udfd2\uda2f\ude85\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 1, 1, "\uda47\udf9e\ud95e\udce3\ud99f\udc05\uda21\ude0d\uda04\ude85\ud9f9\udfbd\uda8b\ude93\udbc2\udcf8\ud82a\udd7b\ud9df\udf93\ud88c\uddfc\ud987\udcc9\ud802\udfc3\u324a\ud9dc\udcb7\ud8c0\udfee\udae5\udcf9\uda60\udcda\uda0a\udf03\ud8fd\udc53\udb38\udc5d\uda30\udfd2\uda2f\ude85", "\u9648\u01e5\uae53\u78f4\uad5b\u6278\ua63f\u20d2\uc12e\u63aa\u83b7\u01e3\u8f5c\u5dda", "\udbf8\udd37\udb82\udc76\ud869\udf9d\uda2d\udff9\ud9b8\udeb9\udb3e\ude3e\ud85a\ude15\udb1b\ude74\u0181\ud9b4\udc67\udb40\udd56\uda8d\ude54\ud897\udd07\ud840\ude0f\udaf2\udf31\ud9b5\udd9e\udbfc\udc74\udbba\ude6a\udb4e\uded6\udabe\udd70\ud8bf\ude3f\udbf6\udc7c\udb06\udc2c\ud821\ude58\udbce\uded9\ud9d9\udec0\ud842\udcd4\ud89c\udc25\ud918\uddd4\ud8eb\udd19\ud810\udecc\ud825\udc15\udae4\udfbc\uda95\udd57\ud91b\udfc1\uda4d\udc3b\ud96d\udd67\ud848\udf2c\udab7\udf2b\ud948\udc6c\ud91b\udf50\udb45\udf81\ud85a\udec5\ud8ee\udea6\udbfb\udc2c\ud887\ude3a\udbeb\ude95\uda4a\udc4b\ud833\ude0b\uda22\ude7c\u0f5b",
        19, 85826, -793901970, 3715905123533185168L, -17492L, false, true, (char) 51020, (char) 52860,
        Double.longBitsToDouble(0x3fe52394d0bc3850L), Double.longBitsToDouble(0x3fd685990b9a15f6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 0, 0, "\udb6e\uddfd", "\u5de7\u775c\u5de2\u91fa\u64ac\u3675\u5e55\u09a1\u7757\u47d0\u2999\u5ed8\u9998\uc959\uaa65\u3dbf\u0f79\ud48d\u5c74", "\u24f7\ud965\udd6f\ud980\udf03\ud962\udc84",
        15, 7578, -809079511, -7089771039544774438L, 91353L, true, true, (char) 24888, (char) 9588,
        Double.longBitsToDouble(0x3fe7a2b268ad4a6aL), Double.longBitsToDouble(0x3fede313d6290f76L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda5c\udf7a\uda89\udfc5\ud99a\udc95\ud8d8\udfba\udac8\uddeb\u70db\udac1\udfe7\ud9c8\udca3\ud94f\udc2b\uda16\udf8b\ud9e9\ude6b\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud844\uddc2\ud8f3\udd9f\ud8a8\udf48\udacc\ude1e\uda30\udfd2\udbef\udcda\ud9f6\udde0\uda67\ude1e\uda37\udcca\ud9b4\uddd7\udbc7\udd76\udb4c\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\udaca\uddfc\ud818\udebf\ud83d\ude86\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\uda5c\udf7a\uda89\udfc5\ud99a\udc95\ud8d8\udfba\udac8\uddeb\u70db\udac1\udfe7\ud9c8\udca3\ud94f\udc2b\uda16\udf8b\ud9e9\ude6b\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud844\uddc2\ud8f3\udd9f\ud8a8\udf48\udacc\ude1e\uda30\udfd2\udbef\udcda\ud9f6\udde0\uda67\ude1e\uda37\udcca\ud9b4\uddd7\udbc7\udd76\udb4c\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\udaca\uddfc\ud818\udebf\ud83d\ude86\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\uda5c\udf7a\uda89\udfc5\ud99a\udc95\ud8d8\udfba\udac8\uddeb\u70db\udac1\udfe7\ud9c8\udca3\ud94f\udc2b\uda16\udf8b\ud9e9\ude6b\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud844\uddc2\ud8f3\udd9f\ud8a8\udf48\udacc\ude1e\uda30\udfd2\udbef\udcda\ud9f6\udde0\uda67\ude1e\uda37\udcca\ud9b4\uddd7\udbc7\udd76\udb4c\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\udaca\uddfc\ud818\udebf\ud83d\ude86", "\u369a\u0a90\u8888\ubec6\u33c3\u231f\u5d1c\u5353\u5e44\u21b2\u8469\u5352\u68dd\u3336\u6cc4\u716b\u9757\u3463\u072d\u7606\u14b6\u822e\u8d8c\u4fc8\u7f5a\u62db\u1d14\u4de7\u10c2\uc95c\u94db\ub914\uaa00\u90ae\u466b\u0502\uc89c\uccd2\ud7a4\u6abb\ub3d0\u9a90\uc06c\u10d9\u1eb9\uc566\ub0d3\u81d5\u82c6\u38b1\u097d\u4ad3\u2f3a\u4a86\u8112\u0b12\u4b7e\u1419\u641c\uc725\ua901\u8f57\u4a8d\u3fb0\u438c\u166c\ub3aa\u44b0\uaadd\ucc9e\u6cde\u7f3e\u11bb\u27b8\u891e\u2a66\u7fa9", "\ud82f\udd5b\udb5c\ude02\udad8\ude5a\udb92\ude00\udb18\udd3c\ud962\ude79\udb0c\udeec\ud95d\udfc6\udab6\ude34\ud904\udfe3\udbc3\udc71\udb05\udcd1\ud994\udd27\ud801\udffc\udacc\ude07\uba4e",
        30, 80287, 1891606642, 1677152147659487181L, 51169L, true, false, (char) 49721, (char) 26891,
        Double.longBitsToDouble(0x3fcf8656a923dd88L), Double.longBitsToDouble(0x3fe457288bc9a27dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String: title=\"v\u00e5\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "v\u00e5\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23<\udbed\udfea", "\u11ed\u7db5\u0091\u799d\u5cbd\uaef7\u2205\u8375\ubaed\u1f0b", "\ud9e8\udcf6\uc6ee\udbdd\udea5",
        36, -230, 1664810172, 6931549951587164949L, -90079L, true, true, (char) 40189, (char) 30448,
        Double.longBitsToDouble(0x3fd8c79a4aac934eL), Double.longBitsToDouble(0x3fc462daf586194cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\uda37\udcf0\ud96f\udc04\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\uda68\udee8\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\uda37\udcf0\ud96f\udc04\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\uda68\udee8\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\uda37\udcf0\ud96f\udc04\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23<\uda68\udee8", "\u11ed\u7db5\u4286\u7821\u22bf\uaef7\u2205\u8375\ubaed\u1f0b", "\ud9e8\udcf6\uc6ee\udbdd\udea5",
        36, 71676, 1664810172, 6931549951587164949L, -90079L, true, true, (char) 40189, (char) 47600,
        Double.longBitsToDouble(0x3fd8c79ecaac934eL), Double.longBitsToDouble(0x3fc462daf586194cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String: title=\"&#092;\udaa8\udc6b\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\u2bda\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "\\\udaa8\udc6b\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23<\u2bda", "\u11fe\u7db5\u0091\u799d\u5cbd\uaef7\u2205\ud0c0\ubaed\u1f0b", "\ud9e8\udcf6\uc6ee\udbdd\udea5",
        36, 50362, 1664810172, 6931549951587164949L, -90079L, true, true, (char) 42299, (char) 49910,
        Double.longBitsToDouble(0x3fd8c79a4aac934eL), Double.longBitsToDouble(0x3fc462daf586194cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String: title=\"&quot;\u00e5\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "\"\u00e5\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23<\udbed\udfea", "\u11ed\u7db5\u0091\u799d\u9bc4\uaef7\u2205\u8375\u767c\u8c93", "\ud9e8\udcf6\uc6ee",
        39, 75835, 1757905770, 7150305244402012149L, 35935L, false, true, (char) 30261, (char) 57136,
        Double.longBitsToDouble(0x3fde500a705ed04eL), Double.longBitsToDouble(0x3fec8bb201bbc4d1L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String: title=\"&#092;\udaa8\udc6b\ud89e\ude2e\u0082\u6835\ud0d6\udabe\uddc5\ud96c\udc95\udb39\udd23\ud9c8\ude00\ud911\udc2a\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"&#092;\udaa8\udc6b\ud89e\ude2e\u0082\u6835\ud0d6\udabe\uddc5\ud96c\udc95\udb39\udd23\ud9c8\ude00\ud911\udc2a\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\\\udaa8\udc6b\ud89e\ude2e\u0082\u6835\ud0d6\udabe\uddc5\ud96c\udc95\udb39\udd23\ud9c8\ude00\ud911\udc2a", "\u1274\u4c9d\u9766\u799d\u5cbd\uaef7\u223b\ud0c0\ubaed\u1f0b\u5b14\u9f16\u950d\u5ed9\uc37a\u476e\u5ec6\uaa57", "\ud9a3\udd80",
        16, 73817, 799151007, 8765292914745501068L, 10333L, true, true, (char) 23334, (char) 44832,
        Double.longBitsToDouble(0x3fe7b5c1f1d01166L), Double.longBitsToDouble(0x3fe5dc9d8cc6b222L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\016\udaf2\udf4f\ud8f0\ude3d&gt;\u6835\000\udac1\udf01\uda59\udd01\ud8fa\udfb0\udbb4\udec6\u2bda\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\016\udaf2\udf4f\ud8f0\ude3d>\u6835\000\udac1\udf01\uda59\udd01\ud8fa\udfb0\udbb4\udec6\u2bda", "\u58ab\uc39f\u8bc0\u799d\u5cbd\u344d\u2242\ud0c0\ubaed\u15a0", "\ud9e8\udcf6\uc6ee\udbdd\udea5",
        36, 92898, -1745964641, 6976969230742364949L, -68455L, true, true, (char) 42299, (char) 49910,
        Double.longBitsToDouble(0x3fdb179a4aac934eL), Double.longBitsToDouble(0x3fc462daf5874580L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String: title=\"&quot;\u00e5\ud89e\ude2e\u0082\u6835\ud9d6\udf01\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\uf007\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"&quot;\u00e5\ud89e\ude2e\u0082\u6835\ud9d6\udf01\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\uf007\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\"\u00e5\ud89e\ude2e\u0082\u6835\ud9d6\udf01\udac1\udf01\ud96c\udc95\udb39\udd23<\uf007", "\u11ed\u7db5\u0091\u799d\u9bc4\u24c4\uad8f\u8338\u767c\u8c93", "\ud9e8\udcf6\ud9d8\udd16",
        14, 64567, 1757905770, 7150305244402012149L, 35935L, false, false, (char) 55484, (char) 3202,
        Double.longBitsToDouble(0x3fde500a705ed04eL), Double.longBitsToDouble(0x3fec8bb201bbc4d1L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String: title=\"&amp;\u00e5\ud89e\ude2e\u0082\u6835\000\udaa8\udd33\udbc4\udf1c\udb05\udf18\ud89b\udfc9\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "&\u00e5\ud89e\ude2e\u0082\u6835\000\udaa8\udd33\udbc4\udf1c\udb05\udf18\ud89b\udfc9\udbed\udfea", "\u11ed\u7db5\uba0b\u50d2\u9bc4\uaef7\u2205\u8375\u767c\u9605", "\ud9e8\udcf6\uc6ee\udb1e\udc66\ud9f4\udf45\udafc\udd96\uca95\ud8cd\udda0\ud88d\udd09\udb61\udf8a\udb45\ude1e\udb44\ude64\udacd\udfc6\ud9b5\udf05\udb59\udd2f",
        40, 69025, -992920687, 5825839027306942750L, -46212L, true, true, (char) 42320, (char) 5191,
        Double.longBitsToDouble(0x3fe44132ea9e12c8L), Double.longBitsToDouble(0x3fe4c1f33f4c945aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud960\udef2&#39;\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "\ud960\udef2'\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23<\udbed\udfea", "\u11ed\u7db5\u0091\u799d\u9bc4\uaef7\u2205\u8375\u767c\u8c93", "\ud9e8\udcf6\uc6ee",
        39, 75835, 1757905770, 7150305244402012149L, 35935L, false, true, (char) 30261, (char) 57136,
        Double.longBitsToDouble(0x3fde500a705ed04eL), Double.longBitsToDouble(0x3fec8bb201bbc4d1L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\016\udaf2\udf4f\ud8f0\ude3d&gt;\u6835\000\udaa1\udf01\uda59\udd01\ud8fa\udfb0\udbb4\udec6\u2bda\ud987\udd18\udbbd\udc19\uda83\udc7a\ud812\udc78\u8bc0\ud86f\udd02\ud9ca\udced\ueb33\uda31\ude6d\uce2b\ud9da\udce5\udb06\udf00\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\016\udaf2\udf4f\ud8f0\ude3d&gt;\u6835\000\udaa1\udf01\uda59\udd01\ud8fa\udfb0\udbb4\udec6\u2bda\ud987\udd18\udbbd\udc19\uda83\udc7a\ud812\udc78\u8bc0\ud86f\udd02\ud9ca\udced\ueb33\uda31\ude6d\uce2b\ud9da\udce5\udb06\udf00\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\016\udaf2\udf4f\ud8f0\ude3d>\u6835\000\udaa1\udf01\uda59\udd01\ud8fa\udfb0\udbb4\udec6\u2bda\ud987\udd18\udbbd\udc19\uda83\udc7a\ud812\udc78\u8bc0\ud86f\udd02\ud9ca\udced\ueb33\uda31\ude6d\uce2b\ud9da\udce5\udb06\udf00", "\u950d\u4193\uc319\u476e", "\udaf6\ude41\udb45\udf43",
        6, 61473, -739513087, 3422851794628547447L, 17407L, true, false, (char) 39975, (char) 45662,
        Double.longBitsToDouble(0x3fc2ae53e974c348L), Double.longBitsToDouble(0x3fe89110dfdaedb3L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String: title=\"&amp;\u00e5\ud89e\ude2e\u0082\u6835\000\udaa8\udd33\udbc4\udf1c\udb05\udf18\ud89b\udfc9\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"&amp;\u00e5\ud89e\ude2e\u0082\u6835\000\udaa8\udd33\udbc4\udf1c\udb05\udf18\ud89b\udfc9\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "&\u00e5\ud89e\ude2e\u0082\u6835\000\udaa8\udd33\udbc4\udf1c\udb05\udf18\ud89b\udfc9\udbed\udfea", "\u2a0b\u3427\u71dc\ub633\u310d\ua959\u2205\u8375\u767c\u9605", "\ud816\ude6c\uc6f1\udb1e\udc66\ud9f4\udf45\udafc\udd96\uca95\ud8cd\udda0\ud88d\udd09\udb61\udf8a\udb45\ude1e\udb44\ude64\udacd\udfc6\udb30\udd29\udb71\udccb",
        40, 69025, -992920687, 5825839027306942750L, -46212L, true, true, (char) 42320, (char) 5191,
        Double.longBitsToDouble(0x3fec4132ec0c6931L), Double.longBitsToDouble(0x3fe4c1f33f4c945aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud960\udef2&#39;\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud960\udef2&#39;\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud960\udef2'\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23<\udbed\udfea", "\u40e5\uc411\u0091\u799d\u9bc4\uaef7\u2205\u5f4b\u761e\u8c93", "\ud9e8\udcf6\ud8f6\udc30",
        38, 45530, 1755771481, 7150305244402012149L, -69420L, true, false, (char) 57921, (char) 40189,
        Double.longBitsToDouble(0x3fefef11c58c79a4L), Double.longBitsToDouble(0x3fde500a705ed04eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 1, 1, 1, "\udadb\udf79", "\ucb09\u2ddf\ud0fe\u9079\u166f\u3675\u5e55\u09a1\u7757\u00a9\u11ed\uc77c\u488c\u79c1\u39e2\u4652\021\ud48d\u5c74", "\ud8d1\udf3c\ud965\udcf0\udb4e\ude42\udbde\ude0d",
        16, 26949, -821009593, -1253105919669315123L, 91353L, false, true, (char) 26667, (char) 36532,
        Double.longBitsToDouble(0x3fe4cb432a4af96aL), Double.longBitsToDouble(0x3fe238fde6297462L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\ud9b6\udf7f\udad7\udf85\ud99a\udc95\ud8d8\udfba\udac8\uddeb\ud9ce\udeb2\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud9a2\udc72\uda0a\udf03\ud8a8\udf48\udb4c\ude1e\ud868\udd98\udbef\udc2a\uda74\udfff\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\udb76\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\ud9c5\udd36\udaa0\udc2d\ud887\udee6\ud982\udebb\ud914\udcf7\udba3\udfac\udbe5\udcfb\udaa4\ude35\udb2f\udc28\udb67\udd22\udafc\udc30\uafee\udb80\ude1e\uda50\udd53\ud9ce\udee0\udb36\uddbc\ud8ed\uddd5\ud91c\udf76\uda69\uded9\udb7b\udd49\udb64\udee4\ud89f\udc92\ud9f0\ude0c\ua256\uda9a\udf5a\udab4\udc7a\uda46\udf0b\uda79\ude3e\ud9de\udc45\uda2e\udc1b\uda94\ude27\ud98c\udd23\ud8d2\udea8\ud92a\ude74\ud9b2\ude7b\u3e3d\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\ud9b6\udf7f\udad7\udf85\ud99a\udc95\ud8d8\udfba\udac8\uddeb\ud9ce\udeb2\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud9a2\udc72\uda0a\udf03\ud8a8\udf48\udb4c\ude1e\ud868\udd98\udbef\udc2a\uda74\udfff\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\udb76\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\ud9c5\udd36\udaa0\udc2d\ud887\udee6\ud982\udebb\ud914\udcf7\udba3\udfac\udbe5\udcfb\udaa4\ude35\udb2f\udc28\udb67\udd22\udafc\udc30\uafee\udb80\ude1e\uda50\udd53\ud9ce\udee0\udb36\uddbc\ud8ed\uddd5\ud91c\udf76\uda69\uded9\udb7b\udd49\udb64\udee4\ud89f\udc92\ud9f0\ude0c\ua256\uda9a\udf5a\udab4\udc7a\uda46\udf0b\uda79\ude3e\ud9de\udc45\uda2e\udc1b\uda94\ude27\ud98c\udd23\ud8d2\udea8\ud92a\ude74\ud9b2\ude7b\u3e3d\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud9b6\udf7f\udad7\udf85\ud99a\udc95\ud8d8\udfba\udac8\uddeb\ud9ce\udeb2\udac1\udfe7\ud9c8\udca3\udb39\udd23\uda16\udf8b\udb24\udee9\ud987\udd0d\ud802\udfc3\u324a\udabe\udc07\ud912\udd04\ud86f\udd26\ud9a2\udc72\uda0a\udf03\ud8a8\udf48\udb4c\ude1e\ud868\udd98\udbef\udc2a\uda74\udfff\ud8d1\udf3c\ud965\udcf0\ud980\udf03\udbc7\udd76\udb76\udd20\udbb7\udf22\udad4\udc64\uda78\uddc7\ucc2b\ud9c5\udd36\udaa0\udc2d\ud887\udee6\ud982\udebb\ud914\udcf7\udba3\udfac\udbe5\udcfb\udaa4\ude35\udb2f\udc28\udb67\udd22\udafc\udc30\uafee\udb80\ude1e\uda50\udd53\ud9ce\udee0\udb36\uddbc\ud8ed\uddd5\ud91c\udf76\uda69\uded9\udb7b\udd49\udb64\udee4\ud89f\udc92\ud9f0\ude0c\ua256\uda9a\udf5a\udab4\udc7a\uda46\udf0b\uda79\ude3e\ud9de\udc45\uda2e\udc1b\uda94\ude27\ud98c\udd23\ud8d2\udea8\ud92a\ude74\ud9b2\ude7b\u3e3d", "\u61e7\u5b99\u692e\u3013\u3163\u01b3\u5e65\u172b\ucc9c\u2d74\u21bc\u8730\u81a2\ua266\ud521\u24e6\uc83a\u04fb\ub913\u3da8\u33f5", "\udabf\udc5d\ud9ff\udc9a\udbd3\udca3\udaa5\udf29\udbc7\udc9d\udbf1\udc9a\udb00\udf11\uda29\udfcf\ud9ac\ude13\udaa3\ude69\ud967\udf29\udb90\udd03\uda9d\udd30\udb8d\ude33\uda9d\udccc\ud918\udc5f\ud9b2\udc0a",
        23, 78313, -561428292, -8763091720003410697L, -39084L, true, true, (char) 6527, (char) 57892,
        Double.longBitsToDouble(0x3fe5d360765a15baL), Double.longBitsToDouble(0x3fec39dfa6156f35L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String: title=\"v\u00e5\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\udbed\udfea\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 1, 0, 0, 1, "v\u00e5\ud89e\ude2e\u0082\u6835\000\udac1\udf01\ud96c\udc95\udb39\udd23<\udbed\udfea", "\u11ed\u7db5\u0091\u799d\u5cbd\uaef7\u2205\u8375\ubaed\u1f0b", "\ud9e8\udcf6\uc6ee\udbdd\udea5",
        36, -230, 1664810172, 6931549952673841152L, -43756L, true, true, (char) 54171, (char) 40024,
        Double.longBitsToDouble(0x3fb64d80bbdd92f0L), Double.longBitsToDouble(0x3fb259832b6c9ef0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String: title=\"\udb22\udc87&lt;\ud89e\ude2e\u0082\u6835\ud9d6\udf01\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\uf007\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\0121=java.lang.String: title=\"\udb22\udc87&lt;\ud89e\ude2e\u0082\u6835\ud9d6\udf01\udac1\udf01\ud96c\udc95\udb39\udd23&lt;\uf007\" alt=\"\" |this=org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb22\udc87<\ud89e\ude2e\u0082\u6835\ud9d6\udf01\udac1\udf01\ud96c\udc95\udb39\udd23<\uf007", "\u11ed\u7db5\u0091\u799d\u9bc4\u24c4\uad8f\u8338\u767c\u8c93", "\ud9e8\udcf6\ud9d8\udd16",
        14, 64567, 1757905770, 7150305244402012149L, 35935L, false, false, (char) 55484, (char) 3202,
        Double.longBitsToDouble(0x3fde500a705ed04eL), Double.longBitsToDouble(0x3fec8bb201bbc4d1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator|generateToolTipFragment|java.lang.String|new:org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:",
    "C|org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator|<init>|",
    "M|org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator|generateToolTipFragment|java.lang.String|new:org.jfree.chart.imagemap.StandardToolTipTagFragmentGenerator:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
