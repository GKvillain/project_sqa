package org.jfree.data.category;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultIntervalCategoryDataset_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\ub383\ub62b\u76cc\u4e94", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 99530, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 15, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\ub383\ub62b\u76cc\u4e94", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 99530, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\ud8e9\udc80\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udb94\udd95\ud9ff\udd54", "\u1f95\u8073\ub1f3\ub383\ub62b\u76cc\u4e94", "\ud853\udd01\udbc8\udcbd\uda9f\udc82",
        27, 99530, 2118046734, 8938710942689088386L, -44614L, true, false, (char) 25370, (char) 10975,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 7, 7, "\uda27\udeeb\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\ude56\ud8a9\udea5\ud8d2\udeac\udac8\udd11\udb04\udf49\uda0c\udc1a", "\u1f95\u0b96\u907b", "\ud818\ude4b\udac4\udef6\ud9fb\udd8e\ud839\udcf9\uda37\udd54\uda12\udfc4\uda9f\udc82\ud977\udf51\ud8a7\udfa2\uda58\udf7e\ud9cd\udd8d\ud84b\udedc\ud8c8\ude94\udabb\udffc\ud910\udd6c\ud94b\udc36\udb59\ude55\ud87b\uddc8\ud8cd\udffe\uda5d\udffa\udae6\ude65\ud889\udeb1\ud98e\udc34\ud995\udf42\ud9e5\udd2d\udad4\udc17\uda4f\udc14\u4d70\udb89\udd3e\udadc\udc6c",
        8, 75927, 84194895, -5373257314905158937L, -13480L, false, true, (char) 23614, (char) 24277,
        Double.longBitsToDouble(0x3faef828c44497c0L), Double.longBitsToDouble(0x3fc16dfb30d6b75cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 19, 0, "\udbe0\udf28\uda2d\udc62\udbb5\ude48\uda77\udc87\ud845\udda0\uda89\udd95\uda2a\udc41\uda36\udda8\udad0\udf8f\uda00\udc54", "\u3884\u9b03\u29bd\u4611", "\udac4\ude5d",
        57, 17709, -1676099119, -5521618316957249354L, 3997L, false, true, (char) 30873, (char) 57811,
        Double.longBitsToDouble(0x3fbbf45572873ff8L), Double.longBitsToDouble(0x3fabd463161a0df0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 3, 3, "\uda2a\ude32\ud9fc\udf29\ud45c\uda77\udc87\udbc3\ude99\udb18\udd0b\ud848\udd67\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb0d\udc8c\uda04\udd1c\ud9d1\udf5d\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a\ud9f5\ude3b\ud971\udc8e\udbf7\udc92\uda27\ude0e", "\u0342\ucab0\ud33f\u2006\u8005\u3d57\uae92", "\ud9fa\udcd5\ud9c5\udcb3\ud985\udd00\ud996\udcf0\udb3a\udda8\udb2a\udfe6\udb32\ude7e\u25a0\ud82b\udfe5\ud9b2\udce3",
        1, 27476, -330291853, 4216855653538625432L, 82250L, false, true, (char) 61837, (char) 58474,
        Double.longBitsToDouble(0x3f9658597b4da5c0L), Double.longBitsToDouble(0x3fd8a9e8385dad74L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[D:[[[27901.0, 28417.0, 27878.0, 28540.5, 27922.0, 28301.5, 27939.5, 28203.5]]] |a1=[[D:[[[27314.0, 16362.0, 1363.5, 22953.5, 23293.5, 15182.0, 10034.0, 19524.5]]]\012",
        Z.run(T, 1, 1, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\ud594\u8004\u0ad7\ub383\ub62b\u76cc\u4e94\u98b9\u7c7d\u0b69\u7b2f\uc51f\u6c54\ud485\u69ae\u79a3", "\ud8bf\ude9f\ud89a\udd31\ud838\uddb3",
        19, 84857, -1126293261, -670230786499394316L, -59729L, false, true, (char) 21844, (char) 14704,
        Double.longBitsToDouble(0x3fd2c2d99103cb8cL), Double.longBitsToDouble(0x3fe9413d3a49a802L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\u3faa\ucc33\u76cc\u4e94", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 99530, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[[Ljava.lang.Number;:[[[19386]]] |a0=[[Ljava.lang.Number;:[[[19386]]]\012",
        Z.run(T, 1, 5, 3, 9, "\udb03\ude2a\uda9e\uddbb\ud969\udd84\uda77\udc87\ud845\udda0\udbb6\uddeb\ud8dd\ude72\ud8d9\udc1d\udad0\udfb6\ud9d5\udc54", "\u1f95\u4874\u056e\u6f7e\ub611\ua860\u49dd", "\ud9b1\udd51\ud116\ud873\udd80\ud977\udf67\ud9cb\udf14\uda58\udf7e\ud87f\ude57\udb22\udd68\uda6b\udc04\udbf9\uddbd\uda4c\udf5a\udb60\udf07\uda20\udc9b\uda74\udc07\uda37\udf4a\udb73\ude7c\ud9f5\ude88\ud8d2\udfb4",
        13, 19386, -315934069, 2312271330563781351L, -21558L, true, false, (char) 7660, (char) 46882,
        Double.longBitsToDouble(0x3fe846389574c0e5L), Double.longBitsToDouble(0x3f812e85b4a65ac0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[[Ljava.lang.Number;:[[[99530, 0.37659023879498477, 2118046734]]] |a0=[[Ljava.lang.Number;:[[[99530, 0.37659023879498477, 2118046734]]]\012",
        Z.run(T, 1, 5, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\u9a61\ub62b\u76cc\u4e94", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 99530, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1505, (char) 44136,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 13, 12, 14, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\udb29\ude8e\ud845\ude02\uda6a\udea9\ud8d5\udc04\u257d\udad0\udf7e\ud9ff\udd54", "\u0240\u1cf4\ua3dc\ubb3c\ub62b\u76cc\u6352\u4e54\u7c6f\u0b69\u1a93\uc51f\u6c54\ud485\u69ae\u33b6\u7975", "\ud8ac\udcd9\ud838\uddb3\udb64\ude9b\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda2f\udc41\uda09\udc3b",
        39, 84778, -808993170, 1778853682182277668L, 54908L, true, false, (char) 15692, (char) 8451,
        Double.longBitsToDouble(0x3fd5ded86da37380L), Double.longBitsToDouble(0x3feb62f8888082a0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 7, 7, "\uda2a\ude32", "\u00f7\ub955\u4c8d\u361e", "\udb0b\udc61\ud977\uddfc\ud950\udf12\uda4b\udecc\udbde\udefb\udbb5\udcb6\udb49\ude7b\udbbb\udd87\ud9d8\ude54\udac4\udeba",
        32, 17709, -1676099119, -5521618316957249354L, -55394L, false, true, (char) 30873, (char) 22801,
        Double.longBitsToDouble(0x3fbbf45576b83850L), Double.longBitsToDouble(0x3fabd463181a0df0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 7, 7, "\uda8b\udede\ud989\ude84\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud887\udf78\udbf9\udeb2\udad0\udf37\ud9ff\udd54", "\uac07\u8073\u5eb0\u9816\u6174\u433e\u0ec6", "\udb28\udfed\udbc8\udce0\uda9f\udc82\ud977\udf51\udaaf\udc66\uda58\udf7e\ud9cd\udd8d\ud84b\udedc",
        5, 2558, 118118511, -6285056030776669641L, 56553L, true, false, (char) 15271, (char) 11958,
        Double.longBitsToDouble(0x3fe109c00b6ad885L), Double.longBitsToDouble(0x3fe3dc5a7263231aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[D:[[[28116.0, 28239.5, 28134.0, 28217.0, 27725.5, 28320.5, 27833.0, 28500.0]]] |a1=[[D:[[[14355.0, 4171.5, 14243.0, 25251.5, 22778.5, 15183.0, 23736.0, 17695.0]]]\012",
        Z.run(T, 1, 1, 7, 15, "\udbd8\udccf\udbfc\udca2\ud8cb\udd71\ud9a2\uded8\udab7\ude84\ud8aa\udc05\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud950\udf12\uda4b\udecc\udbde\udefb\udbb5\udcb6\udb63\udd6b\ud929\udeaa\udba4\udfdc\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\udb28\udfed\udbc8\udce0\uda9f\udc82\ud977\udf51\ud84b\ude89\udb9d\udc7f\ud919\udc57", "\u7056\u20c7\u6f76\uc577\ub225\u76ce\ub9a0\u8a6e\u408a\ud6df\u5727\u3433\ua7c5", "\udac9\udf6e\udbe5\uddd4\udafd\udef3\ud879\udc4b\ud9a0\udc46\udbfb\udfa1\ud8be\udc18\udbf6\udf66\uda10\udf09\uda3a\udd71\ud9db\udde2\ud8c4\udcbf\uda85\udfac\udbac\udde6\udbbc\uddc2\udba4\uddce\ud829\uddba\udab2\udc0c\udac8\udd7d\ud961\uded5\ud9af\ude06\udab4\udfe7\udaf6\udff1\uda38\udd1a\ud906\udf3e\udb9c\udd19\uda8e\udfcb\ud9a9\ude87\udbc4\udc03\ud9f0\udef8",
        31, 6999, -1363441220, 5847959093291065144L, -24435L, true, true, (char) 8904, (char) 53067,
        Double.longBitsToDouble(0x3fee1f9451226fd7L), Double.longBitsToDouble(0x3feafa4c12bb9f60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 7, 16, "\uda2a\ude32", "\u00f7\ub955\ub149\u2e7e", "\uda0b\ude67\udbe5\udee4\ud950\udf12\uda4b\udecc\ud9dc\udefa\udbb5\udcb6\udb63\udd6b\ud920\udd17\ud9a7\uddf2\ud843\udf52",
        32, 17709, -1978089007, 8385700963909439513L, -18152L, true, true, (char) 10693, (char) 6113,
        Double.longBitsToDouble(0x3fbccf2f8c0d02f8L), Double.longBitsToDouble(0x3fce781af29ef378L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 1, 9, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\udb2a\udec0\ud852\ude7f", "\u4481\u6413\u1fd5\u9248\u7cfb\u93d6\u8073\ub1f3\ub383\ub62b\u76cc\u4e94\u98b9\u7c7d\u0b69\u1a93\ua2b3\u028c\ud485\u69ae\ua33f\u7db4", "\ud8ac\udcd9",
        -1, 31519, -1059606143, -4837392721856242521L, 17709L, false, false, (char) 18937, (char) 6768,
        Double.longBitsToDouble(0x3fcda269b1c07f78L), Double.longBitsToDouble(0x3fe34d369809aa6eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[D:[[[27901.0, 28417.0, 27878.0, 28540.5, 27922.0, 28301.5]]] |a1=[[D:[[[9774.5, 16094.0, 1586.0, 4607.0, 9506.5, 18670.0]]]\012",
        Z.run(T, 1, 1, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b", "\u4c8d\u7dec\u0c94\u242e\u4a75\u920c", "\ud816\udcf7\udbf6\udefb\udb63\udce9\ud85e\udc75\ud834\udcf8\udb7e\udd5f\uda15\udf86",
        24, 17418, 803829060, -4762529222555913580L, -23273L, false, false, (char) 53134, (char) 30873,
        Double.longBitsToDouble(0x3fed343168aed155L), Double.longBitsToDouble(0x3fe6b8385037a8c6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 12, 19, "\uda2a\ude32", "\u0804", "\ud8d5\udca0\uda36\udda8",
        -5, 21488, -906358252, 4539214301495305803L, -48842L, false, true, (char) 70, (char) 22528,
        Double.longBitsToDouble(0x3fd50d62300001e2L), Double.longBitsToDouble(0x3e93000000000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[Ljava.lang.Comparable;:[[\ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a\udbab\udfb0\uda99\udebb\ud90e\udd9e\ub1d1\ud965\udcd0\ud967\udf69\uda09\uddf8\ud95d\udf8f\udb4d\ude70\ud814\udc55\udabb\udc441, \ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a\udbab\udfb0\uda99\udebb\ud90e\udd9e\ub1d1\ud965\udcd0\ud967\udf69\uda09\uddf8\ud95d\udf8f\udb4d\ude70\ud814\udc55\udabb\udc442, \ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a\udbab\udfb0\uda99\udebb\ud90e\udd9e\ub1d1\ud965\udcd0\ud967\udf69\uda09\uddf8\ud95d\udf8f\udb4d\ude70\ud814\udc55\udabb\udc443, \ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a\udbab\udfb0\uda99\udebb\ud90e\udd9e\ub1d1\ud965\udcd0\ud967\udf69\uda09\uddf8\ud95d\udf8f\udb4d\ude70\ud814\udc55\udabb\udc444, \ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a\udbab\udfb0\uda99\udebb\ud90e\udd9e\ub1d1\ud965\udcd0\ud967\udf69\uda09\uddf8\ud95d\udf8f\udb4d\ude70\ud814\udc55\udabb\udc445, \ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a\udbab\udfb0\uda99\udebb\ud90e\udd9e\ub1d1\ud965\udcd0\ud967\udf69\uda09\uddf8\ud95d\udf8f\udb4d\ude70\ud814\udc55\udabb\udc446, \ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a... |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 9, 5, 19, "\uda2a\ude31\ud9fc\udf29\udaac\udcd6\udb0b\udf1e\ud91b\udd7f\uda20\uddf2\ud88c\udcbd\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud8f5\udfcc\ud942\udff8\udb49\ude45\ud95d\udd20\udb1d\ude3e\ud85d\udf9b\ud9a7\uddf2\udac4\ude5e\uda1f\udc7d\ud87f\udcfc\ud8e9\udcac\udbc8\udca8\udbe9\udde8\ud977\udf51\ud8a7\udfa2", "\u5d6e\uc927\u3033\ubba4\u6adf\u2778\u7f3e\ud3bb\u870e\u771d\u08e5\u311e\ua045\u1934\u0f6d\ubd8d\u1fd6\u96d4\ubc0b", "\ud906\ude30\ud850\udf19\ucdd5\udb9e\uddff\udacf\uddbd\udbc2\udec0\ud98d\udf7a\uda1e\udf10\udb68\uddee\udb5c\uded6\u74aa\udbd5\ude7a\udbab\udfb0\uda99\udebb\ud90e\udd9e\ub1d1\ud965\udcd0\ud967\udf69\uda09\uddf8\ud95d\udf8f\udb4d\ude70\ud814\udc55\udabb\udc44",
        13, 29502, -526958575, -849831894975641746L, -30867L, true, true, (char) 25600, (char) 15217,
        Double.longBitsToDouble(0x3fe0157b40115f5eL), Double.longBitsToDouble(0x3fe013000b7b1750L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[99530, 0.37659023879498477, 2118046734]]] |a1=[[Ljava.lang.Number;:[[[0.1638064178766483, 99530, 0.37659023879498477]]]\0121=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[99530, 0.37659023879498477, 2118046734]]] |a1=[[Ljava.lang.Number;:[[[0.1638064178766483, 99530, 0.37659023879498477]]]\012",
        Z.run(T, 2, 7, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ucade\u4fe9\u0462\ub9bf\u4ec8", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 99530, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 15, 0, "", "\u33b4", "\ud971\uddb7\uda7a\udfb2\uda36\udda8",
        41, 82170, 4628, 4539213908519888459L, -49056L, false, true, (char) 35832, (char) 19588,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e2d171000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[89573, 0.3765902471239647]]] |a1=[[Ljava.lang.Number;:[[[42, 0.7522470314902349]]]\012",
        Z.run(T, 1, 7, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda38\udcaa\ud8ed\udd7e\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\ub383\ub62b\u76cc\u4e94", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        42, 89573, -936415390, 8938710766595429230L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0dfad8f58aL), Double.longBitsToDouble(0x3fe812685dd86fbfL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\uda2a\ude32\ud8d4\udf35\udb50\udd49\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54]] |a1=[[Ljava.lang.Number;:[[[99496, 0.23273462234288733, 2118046734]]] |a2=[[Ljava.lang.Number;:[[[0.1638064178766483, 99496, 0.23273462234288733]]]\0121=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[99496, 0.23273462234288733, 2118046734]]] |a1=[[Ljava.lang.Number;:[[[0.1638064178766483, 99496, 0.23273462234288733]]]\012",
        Z.run(T, 2, 19, 7, 7, "\uda2a\ude32\ud8d4\udf35\udb50\udd49\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\u0a9e\u75ac\ub62b\u76cc\u4e94", "\udb28\udfed\udbd8\ude02\uda9f\udc82",
        27, 99496, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 64445, (char) 38855,
        Double.longBitsToDouble(0x3fcdca3f83ce07c4L), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[Category 1, Category 2, Category 3, Category 4, Category 5, Category 6, Category 7, Category 8] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 15, 0, 14, "\uda2a\ude32\uda7d\udcaa\ud9fd\udfea\uda77\udc82\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\u0c1c\u8c64\u65e8\ud42f\u98b9\u7c7d\u0b69\u1a93\ub02b\u6c54\ud485", "\ud84b\udedc\ud834\udc8a\udbc9\udce5\ud8ac\udcd9\ud838\uddb3\udb64\ude9b\ud8a8\ude30\ud89f\udc59",
        53, 61116, 1859124229, -688623718374742414L, 87584L, false, false, (char) 10720, (char) 49506,
        Double.longBitsToDouble(0x3fbc3a718ea40c18L), Double.longBitsToDouble(0x3fefcd82b25ab68fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[57739, 0.1888732052703782, -156050265]]]\012",
        Z.run(T, 1, 7, 7, 7, "\ud837\udf2e\ud9fc\udf29", "\u904b\ua7cf\u90c2\u4481", "\uda6f\uddf5\udae3\udea2\udbf7\udf92\ud9fb\udcd7\udbb5\udcb5\u52bb\uda4f\udd9b\udb33\ude55\udac4\ude5e\udbcd\ude6c\ud8d7\udc9e\udb28\udfed\ud80c\uddc4\udbaa\udd99\uda80\ude63\udb2d\uddf9\ud9cc\udca2\ub549\ud84b\udedc\ud84e\udd50\ud9bf\udd92\uda51\udd9a\udb70\udc1f\ud81b\udd79",
        -5, 57739, -156050265, 497160624628001887L, 685L, true, false, (char) 11253, (char) 34762,
        Double.longBitsToDouble(0x3fc82cff47dd0d54L), Double.longBitsToDouble(0x3fef7f6c4b660ad3L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[Ljava.lang.Number;:[[[0.7094817700533073, 0.6016984763511343]]] |a1=[[Ljava.lang.Number;:[[[0.7094817700533073, 0.6016984763511343]]]\0121=java.lang.Boolean:true |a0=[[Ljava.lang.Number;:[[[0.7094817700533073, 0.6016984763511343]]] |a1=[[Ljava.lang.Number;:[[[0.7094817700533073, 0.6016984763511343]]]\012",
        Z.run(T, 2, 4, 7, 7, "\udb48\udeb7\ud86e\udcc3\ud977\udd7a\uda4d\ude14\ud8b9\udca1\ud8a9\udea5\ud8b0\udd19\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1fe2\u4d27\ub1f3\ub383\u162f\u8bc7\u4ec8\u6acc\u0520\ucf55", "\udad5\ude17\ud939\udee9\udafe\udd73\ud9f4\udc27\ud85a\udc1d\ud834\udc8a\uda95\udeea\udaaa\udeb8\ud814\udd6a\ud9bb\uddd6\ud220\ud8cb\uddc6\uda9f\udc1a\ud99a\udcb8\ud8fb\ude8d\uda58\udc15\ud80b\ude8a\udbda\udc41",
        18, 80034, 1849713179, -9036293245138769255L, 15940L, false, false, (char) 48097, (char) 40630,
        Double.longBitsToDouble(0x3fe6b4131cef96b5L), Double.longBitsToDouble(0x3fe3411d29bf6597L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\uda2a\ude32\ud9fc\udf29\udbe3\udcf2\uda82\udcc6\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54]] |a1=[[Ljava.lang.Number;:[[[]]]\012",
        Z.run(T, 1, 19, 7, 7, "\uda2a\ude32\ud9fc\udf29\udbe3\udcf2\uda82\udcc6\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\u93e1\ub62b\u76c8\u69ca", "\udafc\udd04\udbc8\udce0\uda9f\udc82\uda75\uddc8\ud8a7\udf9d\uda58\udf7e\ud9cd\udd8d",
        4, 81080, -27973722, 507362496643268311L, -79905L, true, false, (char) 39301, (char) 15271,
        Double.longBitsToDouble(0x3fef94286177b30aL), Double.longBitsToDouble(0x3fbccfd8619fffb0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 16, 7, "\udbb3\udd37\ud9fc\udeb3\uda54\udd4b\uda77\udc87\u9dab\ud82b\udf1a\ud8d5\udca0\udaab\udd22\udad0\udfa9\ud9ff\udd54", "\u1f95\u8073\ub1f3\u841b\u3334\uab83\u27ba", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 58432, -628152643, 1531686017036276610L, -3886L, false, false, (char) 2733, (char) 40438,
        Double.longBitsToDouble(0x3fd1524df1bd7e6eL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[[Ljava.lang.Number;:[[[]]] |a0=[[Ljava.lang.Number;:[[[]]]\012",
        Z.run(T, 1, 5, 17, 7, "\uda1e\udd0a\ud9fc\udf29\uda54\udd4b\ud9f2\udde4\udb43\udd98\ud8a9\udea5\udb67\udde8\udb8e\udf68\udad0\udefd\ud9ff\udd54", "\u1f95\u12d9\ub1f3\ub383\u0ff3\u9355\u4ece", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        4, 309, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1727, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3a3dac8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 19, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\ub383\u7ec2\u05e5\u4f2c", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 99530, 1716156015, 8938615066134139778L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd7d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[Ljava.lang.Comparable;:[[\udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc111, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc112, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc113, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc114, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc115, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc116, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc117, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc118, \udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5... |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[0.8899811788343077]]] |a1=[[Ljava.lang.Number;:[[[0.015372890279459428, 0.8899811788343077, 0.015372890279459428]]]\012",
        Z.run(T, 2, 9, 7, 18, "\ud92a\ude32\ud9e1\udd24\uda54\udd4b\ud9a1\ude9b\udb77\udd11\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\udabb\udd72", "\u1f95\ub026\ub13c\ub383\u2626\u8f5f\u0b3f\u5ccc", "\udad2\udf57\ud9cb\ude4d\uda88\udf7d\ud80c\udfa4\ud973\uddab\ud96a\udff3\ud8c3\udc38\ud834\udc8a\udbc9\udce5\udbab\udf99\udb54\ude76\udb4a\udf71\ud87b\uddc8\ud89f\udcfe\uda9f\udc1a\uda3a\udc11",
        9, 67011, -1918246510, 6076582934317440357L, 9548L, false, false, (char) 27213, (char) 21416,
        Double.longBitsToDouble(0x3fec7ab9cf24c39eL), Double.longBitsToDouble(0x3f8f7bd267f65280L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 7, 13, "\ud9fc\udf87\ud819\udf22\uda54\udd4b\ud8e9\udc80\ud845\udda0\ud8a9\udea5", "\u64e6", "\uda84\udf0c\ud9f8\udce0",
        1, 38070, -1220093515, 5483849399585619364L, -67279L, false, true, (char) 50316, (char) 63052,
        Double.longBitsToDouble(0x3fe5d45d950ecb84L), Double.longBitsToDouble(0x3fe42d7153827c51L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 15, 16, "\uda2a\ude32\ud9fc\udf29", "\ub955\u4c8d\u361e\000", "",
        33, 3188, -2133383605, 9050893388656199638L, -4761L, false, false, (char) 39247, (char) 59216,
        Double.longBitsToDouble(0x3fb37844c0000000L), Double.longBitsToDouble(0x3fd00000016d66beL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 10, 16, 16, "\uda2a\ude32\udb11\ude2a\uda54\udd4b\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\ud817\udc43\uda2e\ude3d\ud9cc\udc29", "\u1f95\u8073\ub1f3\ub383\uaa83\u38a4\uae6d\ucabb\u9ffa\u8935\u1a70\uc51f", "\ud9fd\uddd2\uda27\uddb5\ud84b\udedc\ud834\udc8a\ud9c4\udc82\udb7a\udda8\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc43",
        50, 47328, 151190973, 5958703107290381513L, 62086L, true, true, (char) 24435, (char) 53756,
        Double.longBitsToDouble(0x3fde1b80137d68eaL), Double.longBitsToDouble(0x3fd82dbceaddecc2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\ud234\u8073\ub1d0\ub383\ub62b\u76cc\u4e94]] |a1=[Ljava.lang.Comparable;:[[\uda2a\ude32\ud9fc\udf29\uda54\udd4b\udb27\udf7f\ud845\udda0\ud8a9\udea5\ud8e9\udfa0\uda36\udda8\udb94\udd95\ud9ff\udd54, \ud234\u8073\ub1d0\ub383\ub62b\u76cc\u4e94]] |a2=[[Ljava.lang.Number;:[[[53, 0.37659023879498477]]] |a3=[[Ljava.lang.Number;:[[[2118046734, 0.1638064178766483]]]\012",
        Z.run(T, 1, 2, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\udb27\udf7f\ud845\udda0\ud8a9\udea5\ud8e9\udfa0\uda36\udda8\udb94\udd95\ud9ff\udd54", "\ud234\u8073\ub1d0\ub383\ub62b\u76cc\u4e94", "\ud853\udd01\udb3b\uded7\uda9f\udca4",
        53, 99530, 2118046734, 8938710942689088386L, -44614L, true, false, (char) 3370, (char) 10975,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultIntervalCategoryDataset:@? |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 6, 1, 11, "\udaee\udf39", "\u6857\u074c", "\uda36\udda8\udb94\udd95\ud9ff\udd54\udbb3\udc00\uda22\uddc9\ud85c\udf4b\udaa5\udee0\udac4\udf56\udb52\ude62\ud85e\udc75",
        7, 65096, -58606496, 8158400798973805009L, 80296L, true, true, (char) 8174, (char) 40300,
        Double.longBitsToDouble(0x3fe8ce1b818160e6L), Double.longBitsToDouble(0x3fce781af20fcf78L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u1f95\u8073\ub1f3\ub383\ub62b\u75fd\u4e94, \ud853\udd01\udbc8\udcbd\uda50\udd1b, \uda2a\ude32\ud9fc\udf29\uda30\udcd8\ud824\udece\udbf5\udfa1\ud8a9\udea5\ud8d5\udca0\uda44\ude60\udbe8\udeff\ud9ff\udd54]] |a1=[Ljava.lang.Comparable;:[[\ud853\udd01\udbc8\udcbd\uda50\udd1b, \uda2a\ude32\ud9fc\udf29\uda30\udcd8\ud824\udece\udbf5\udfa1\ud8a9\udea5\ud8d5\udca0\uda44\ude60\udbe8\udeff\ud9ff\udd54]] |a2=[[Ljava.lang.Number;:[[[35]]]\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\uda2a\ude32\ud9fc\udf29\uda30\udcd8\ud824\udece\udbf5\udfa1\ud8a9\udea5\ud8d5\udca0\uda44\ude60\udbe8\udeff\ud9ff\udd54]] |a1=[[Ljava.lang.Number;:[[[99530, 0.37659023879498477, 2117999037]]]\012",
        Z.run(T, 2, 2, 3, 0, "\uda2a\ude32\ud9fc\udf29\uda30\udcd8\ud824\udece\udbf5\udfa1\ud8a9\udea5\ud8d5\udca0\uda44\ude60\udbe8\udeff\ud9ff\udd54", "\u1f95\u8073\ub1f3\ub383\ub62b\u75fd\u4e94", "\ud853\udd01\udbc8\udcbd\uda50\udd1b",
        35, 99530, 2117999037, 6925441381100459794L, -44614L, true, false, (char) 25370, (char) 10975,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u1f95\u8073\ub1f3\ub383\ub62b\u76cc\ud38c\u98b9\u7c7d\u89eb\u1a70\uc51f\u6c54\ud485\u69ae\u3144\u26ec\u3755\u600c\ub980\u8ebe, \ud89f\udcfe\uda9f\udc1a\u60f8, \uda2a\ude32\ud9fc\udf29\uda54\udd4b\ud8e9\udc80\ud845\udda0\ud9ac\udf67\ud998\udf58\uda43\ude3c\udb94\udd95\ud8aa\uded0]] |a1=[Ljava.lang.Comparable;:[[\ud89f\udcfe\uda9f\udc1a\u60f8, \uda2a\ude32\ud9fc\udf29\uda54\udd4b\ud8e9\udc80\ud845\udda0\ud9ac\udf67\ud998\udf58\uda43\ude3c\udb94\udd95\ud8aa\uded0, \u1f95\u8073\ub1f3\ub383\ub62b\u76cc\ud38c\u98b9\u7c7d\u89eb\u1a70\uc51f\u6c54\ud485\u69ae\u3144\u26ec\u3755\u600c\ub980\u8ebe]] |a2=[[Ljava.lang.Number;:[[[11, 17771]]]\0121=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[17771, 1308164606, 11]]]\012",
        Z.run(T, 2, 2, 7, 3, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\ud8e9\udc80\ud845\udda0\ud9ac\udf67\ud998\udf58\uda43\ude3c\udb94\udd95\ud8aa\uded0", "\u1f95\u8073\ub1f3\ub383\ub62b\u76cc\ud38c\u98b9\u7c7d\u89eb\u1a70\uc51f\u6c54\ud485\u69ae\u3144\u26ec\u3755\u600c\ub980\u8ebe", "\ud89f\udcfe\uda9f\udc1a\u60f8",
        11, 17771, 1308164606, 6590570337874775346L, 10398L, true, true, (char) 10264, (char) 38110,
        Double.longBitsToDouble(0x3fe933cdbef25490L), Double.longBitsToDouble(0x3fd1c8567e72e604L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\udbe0\udf28\uda2d\udc62\udbb5\ude48\udab2\udff5\uda7d\udfdc\ud97f\ude1e\u5c5a\ud832\udea6\udad0\udf5d\uda00\udc54]] |a1=[[Ljava.lang.Number;:[[[0.8155420677286968, 859, 0.8981095312253812]]] |a2=[[Ljava.lang.Number;:[[[55, 0.8155420677286968, 859]]]\012",
        Z.run(T, 2, 13, 19, 0, "\udbe0\udf28\uda2d\udc62\udbb5\ude48\udab2\udff5\uda7d\udfdc\ud97f\ude1e\u5c5a\ud832\udea6\udad0\udf5d\uda00\udc54", "\u1e4a\uc2a5\u315a\u9f4d\ub50f\ubd9d\u4e93\u0b56\u7c7d\u0b69\ua034\uc30a", "\ud940\ude02\ud876\udf76\ud84b\udf40\uda54\udf9a\udbc9\udce5\udb7e\udf04\ud838\udd2c\udb4b\udccd\ud803\udc15\ud80c\uddcb\uda90\udc11\udb17\udcc7\udba9\udd9f\udb88\udc63\ud9fc\udd81\ud864\ude8d\ud822\udff0\ud97f\udccb\udb8b\udc78\u19dd\ud8b5\ude9e\udb0f\udf45\u359a\udad8\udcca\uda42\ude2a",
        55, 859, 1758907067, -5072983362310506397L, -34311L, false, true, (char) 16763, (char) 61327,
        Double.longBitsToDouble(0x3fea18ebadad05e5L), Double.longBitsToDouble(0x3fecbd50331ad84bL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[[Ljava.lang.Number;:[[[57134, -1511020436, 23]]] |a0=[[Ljava.lang.Number;:[[[57134, -1511020436, 23]]]\0121=[Ljava.lang.Comparable;:[[\ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude991, \ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude992, \ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude993, \ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude994, \ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude995, \ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude996, \ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude997, \ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b... |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 5, 9, 0, "\ud88c\ude24\uda2d\udc62\ud8a9\udc41\uda77\udc87\ud845\udda0\uda89\udd95\uda2a\udc41\uda36\udda8\uafdd\udadb\udc79\uda19\udfab", "\u2c04\u29bd\u4611\u7c24\ubd9d\u135b\u757a\u79bd\u0b88\u1a93\u72f9\u08aa\ud485", "\ud8ba\udf12\udb27\udcf7\uda68\ude6d\udb7e\udf04\ud838\udd2c\ud885\udd0a\ud8a2\udd3c\ud83f\udeb2\udbcf\udcd3\uda1e\udcec\ud8e8\udecb\udbbc\udfcb\udb5b\udf7f\udbc0\udda8\ud83a\udfc2\ud927\udeff\udb24\ude89\uda47\ude99",
        23, 57134, -1511020436, -8738950573941454328L, -94628L, true, true, (char) 21896, (char) 25172,
        Double.longBitsToDouble(0x3fe45e22bf3d6283L), Double.longBitsToDouble(0x3fe26768061f1a04L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[D:[[[27955.5, 28633.5, 27887.0, 28293.5, 28098.5, 28428.0, 27939.5, 28203.5]]] |a1=[[D:[[[18276.5, 19981.0, 12913.0, 13276.5, 4958.0, 20067.0, 14355.0, 7142.0]]]\012",
        Z.run(T, 1, 1, 19, 0, "\uda97\udfe3\uda0e\udd3b\udbb5\ude48\uda77\udc87\ud845\udda0\uda9f\udcce\uda2a\udc41\uda36\udda8\ud9d7\udd72\ud9bb\udfc8\udaee\udc35\udb2d\uddf9\ud9a4\udef2\udbd7\uded5\ud822\ude9d\udba7\udd61\ud9b5\udea8\ucdd8\ud8d1\ude23\udb5e\udc03\ud839\udcf9\udb28\udfed", "\u8ef9\u9c4a\u6512\u67e9\u26ec\u9cf6\u7056\u37fc\u6eef\u2778\u4c0c\u267d\u9663\u51de\u8cd8\uaaff\u5a3a\u3f01", "\udbcd\udda8\ud894\udf79\ud858\udf82\ud9c6\ude7a\udb78\udeed\ud801\udecd\uda7f\udc96\ud97e\ude36\uda54\ude16\uda1e\udc75\ud961\udf1b\udbdb\ude8e\uda20\udcb5\ud9be\udf70\uda6c\uddbe\uda51\udfe8\ud889\udfcd\ud97e\udd3e\uda92\udc9d\ud9f7\ude91\udb51\udcb1\ud8c3\udfad\ud857\udefd\udad4\uddc4\uda16\ude61\ud8cc\udfa8\ud9d6\ude46\udb6b\udc66\ud8a0\udffc\ud8e7\udfdf\udad7\udd7c\uda5c\uddd5\udb97\udf51\u5c08\uda99\udc64\udbda\udf7e\ud84f\udceb\udb0f\udde4\ud8f1\udde5\udb08\udc31\udb0f\udc38\ud9a1\uddfa\ud917\udfc6\ud98b\udf64\udbf3\ude1e",
        36, 55311, 566219767, -1354093408124988858L, -44622L, true, true, (char) 48053, (char) 6283,
        Double.longBitsToDouble(0x3fd5b48c32cdf32eL), Double.longBitsToDouble(0x3fe59ccca2cb2f11L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[Ljava.lang.Number;:[[[0.10919698759175833]]] |a1=[[Ljava.lang.Number;:[[[-1873362479]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 6, 17, "\udbe0\udf28\uda2d\udc62\udbb5\ude48\uda77\udc87\ud845\udda0\uda89\udd95\uda2a\udc41\uda36\udda8\udad1\udce6\uda00\udc54", "\u3884\u9b03\ubf28\u4444", "\udad8\udd55",
        57, 17709, -1873362479, -5521617994834702154L, 3997L, false, true, (char) 30873, (char) 57811,
        Double.longBitsToDouble(0x3fbbf45572873ff8L), Double.longBitsToDouble(0x3fbc6a31963d06f8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 19, 0, "\ud944\udc01\000", "", "\ucf46",
        -5, -1000, -117440512, 19877108645888L, -2406L, false, false, (char) 49227, (char) 62833,
        Double.longBitsToDouble(0x3feb9000064de188L), Double.longBitsToDouble(0x3fdd17138acb3830L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 19, 0, "\udbe0\udf28", "\000\000\000\000\000\000\000\000", "",
        44, -1000, 0, 0L, -63278L, true, false, (char) 12856, (char) 0,
        Double.longBitsToDouble(0x3df6203c80000000L), Double.longBitsToDouble(0x3e403b2e10000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\udbe0\udf28\uda2d\udc62\udbb5\ude48\uda77\udc87\ud845\udda0\uda78\udc45\uda2a\udc41\uda36\udda8\udad0\udf8f\uda00\udc54]] |a1=[[Ljava.lang.Number;:[[[0.11507543607808646]]] |a2=[[Ljava.lang.Number;:[[[-1486425135]]]\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\udbe0\udf28\uda2d\udc62\udbb5\ude48\uda77\udc87\ud845\udda0\uda78\udc45\uda2a\udc41\uda36\udda8\udad0\udf8f\uda00\udc54]] |a1=[[Ljava.lang.Number;:[[[0.11507543607808646]]] |a2=[[Ljava.lang.Number;:[[[-1486425135]]]\012",
        Z.run(T, 2, 3, 19, 0, "\udbe0\udf28\uda2d\udc62\udbb5\ude48\uda77\udc87\ud845\udda0\uda78\udc45\uda2a\udc41\uda36\udda8\udad0\udf8f\uda00\udc54", "\u3884\u9b03\u29bd\u33fe", "\udac4\ude5d",
        57, 40589, -1486425135, -5520855612369858378L, 3997L, false, true, (char) 30873, (char) 57811,
        Double.longBitsToDouble(0x3fbd759572873ff8L), Double.longBitsToDouble(0x3fec95ad4e3cd3a3L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[D:[[[27815.5, 28156.0, 28074.5, 28561.5, 27724.0, 28442.5, 27939.5, 28189.5]]] |a1=[[D:[[[836.5, 22459.0, 4958.0, 7058.5, 27005.5, 18718.5, 7431.5, 24542.0]]]\012",
        Z.run(T, 2, 11, 17, 3, "\ud97f\udc28\udb85\udf53\ud8c8\ude65\uda77\udc6b\ud8c4\udc9f\udb11\udd0b\ud848\udd67\uda36\udda8\ud8b7\udcc1\ud9ff\udd54\udbff\udee4\ud950\udf12\ud98f\uddde\udbde\udedc\udb0d\udc8c\uda04\udd1c\ud9d1\udf5d\ud8bf\udefb\udbe2\udc8c\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f", "\u06b9\uafa6\u26ec\u3755\ud32b\u926d\u3a3f\ubfec\ucee0\uc83f\u0342\ucab0\ud33f", "\ud996\udc9d\udbb7\udeff\ud8c5\udf10\ud8d3\udc87\ud9fa\udcd5\udb8b\ude93\uda45\udcb2\ud882\ude31",
        19, 79476, 512450738, 568417999218621847L, -72683L, true, true, (char) 4159, (char) 13361,
        Double.longBitsToDouble(0x3fecc1d42fe90244L), Double.longBitsToDouble(0x3fef5120c7724a8dL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 3, 11, "\uda2a\ude32\ud9fc\udf29", "\u3a04\u26ee\ub700\u4481", "\udbe5\udee4\ud950\udf12\udb4f\ude4a\udb11\udfba\udb1c\ude0c\uda04\udd1c\ud9d1\udf5d\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\ud8f1\ude10\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a",
        -1, 5584, -2085127194, 4716880911535812993L, 13648L, false, false, (char) 9739, (char) 17394,
        Double.longBitsToDouble(0x3fda5922dae0d392L), Double.longBitsToDouble(0x3fd5935ea4903810L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.util.Collections$UnmodifiableRandomAccessList:[Category 1, Category 2, Category 3, Category 4] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 11, 15, 4, "\uda2a\ude32\ud9fc\udf29", "\u3a04\u26ee\ub700\u4481", "\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb0d\udc8c\uda04\udd1c\ud9d1\udf5d\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a",
        -1, 5584, -2085127194, 4716880913179980161L, -7435L, false, false, (char) 9739, (char) 17394,
        Double.longBitsToDouble(0x3fe52c916d5069c9L), Double.longBitsToDouble(0x3fd59c99b4903810L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[0.7399273661498089]]] |a1=[[Ljava.lang.Number;:[[[0.8986607490297236, 0.7399273661498089, 0.8986607490297236]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 2, 3, "\uda2a\ude32\ud9fc\udf29\ud45c\uda56\ude87\udbc3\ude99\ud95d\udc93\ud874\udff3\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb2a\udc7b\uda04\udd1c\ud9d1\udf5d\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a\ud9f5\ude3b\ud971\udc8e\udbf7\udc92\ud94a\udfe0", "\u0342\ucab0\u760e\u207f\u8005\u0c47", "\ud8d3\udc87",
        9, 23395, 1244860577, -7459944073604325921L, -18697L, false, false, (char) 47691, (char) 10832,
        Double.longBitsToDouble(0x3fe7ad7c27e0ec50L), Double.longBitsToDouble(0x3fecc1d42fe90244L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.util.Collections$UnmodifiableRandomAccessList:[Category 1, Category 2, Category 3, Category 4, Category 5, Category 6, Category 7, Category 8] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 10, 15, 17, "\ud8b1\uddc8\uda26\udc3a\ud45c\udba8\udc1f\ud8c5\udfdd\udb18\udd36\ud848\udd67\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb0d\udc8c\uda04\udd1c\ud9d1\udf5d\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\udb76\udc67\uda96\udc45\ud84b\udedc\ud834\udc8a\ud9f5\ude3b\ud971\udc8e\udbf7\udc92\udbe8\udf7e\udb8e\udef6\udaa1\ude43\ud933\udd9a\ud85a\udcf2\udae0\udfb1\ud85a\udfb7\udbbc\udf43\ud996\udca7\udbb7\udeff\ud866\udc17\ud8d3\udc87\ud9fa\udcd5\ud9c5\udcb3\ud985\udd00\ud996\udcf0\ud841\udc4b\udb2a\udfe6\udb32\ude7e\u25a0\ud913\udc37\ud9eb\uddf9\udb58\uddc5\ud936\udce1\udbf7\udc49", "\u9ab0\u8f2a\uab26\u52cd\u08ad\u8d7c\u6cbc\u75e7\u3064\u763a", "\ud90d\udcf7\udab5\udd4c\ud9b4\ude54\udb40\ude8c\udb8d\ude49",
        45, 68890, -378277911, -5966846721166915931L, 78827L, true, true, (char) 42662, (char) 6402,
        Double.longBitsToDouble(0x3fd9e22a9416b3faL), Double.longBitsToDouble(0x3fdfe6f65af0a49cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 8, 7, 11, "\ud9a9\uddb0\uda8e\udf2a\uda54\uddda\uda77\udc87\ud845\udda0\uda27\udea4\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\ud594\u8004\u8dcf\ua3d5\u5db3\u76cc\u4e94\u98b9\u7c7d\ua0f7\ua751\uc480\u6c54\ub848\uab0e\u79a3", "\udbbc\udf28\ud9c7\ude09\udb53\udd6f",
        36, 84857, -1126293261, -675932853801040652L, 82983L, false, true, (char) 21844, (char) 22425,
        Double.longBitsToDouble(0x3fe7bc695b16bd2cL), Double.longBitsToDouble(0x3fe175561282d359L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[9527, 0.958242828347852, -386033564]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 1, 0, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\ud815\ude98\udafc\udd16\ud9ff\udd54", "\u2d49\u7ff1\u0ad7\ub383\ub62b\u76cc\u4e94\u98b9\u7c7d\u0b69\u7262\u9571\u896b\u32da\u69ae\u1164", "\ud9ad\udf0c\udb37\ude3f",
        19, 9527, -386033564, -4837154419890791257L, -13403L, true, false, (char) 44905, (char) 21844,
        Double.longBitsToDouble(0x3feea9ecdd2c2d99L), Double.longBitsToDouble(0x3fc03cb8cca26a9cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[Ljava.lang.Comparable;:[[\ud8a7\udfa2\uda58\udf7e1, \ud8a7\udfa2\uda58\udf7e2, \ud8a7\udfa2\uda58\udf7e3, \ud8a7\udfa2\uda58\udf7e4, \ud8a7\udfa2\uda58\udf7e5, \ud8a7\udfa2\uda58\udf7e6, \ud8a7\udfa2\uda58\udf7e7, \ud8a7\udfa2\uda58\udf7e8, \ud8a7\udfa2\uda58\udf7e9, \ud8a7\udfa2\uda58\udf7e10, \ud8a7\udfa2\uda58\udf7e11, \ud8a7\udfa2\uda58\udf7e12, \ud8a7\udfa2\uda58\udf7e13, \ud8a7\udfa2\uda58\udf7e14, \ud8a7\udfa2\uda58\udf7e15, \ud8a7\udfa2\uda58\udf7e16, \ud8a7\udfa2\uda58\udf7e17, \ud8a7\udfa2\uda58\udf7e18, \ud8a7\udfa2\uda58\udf7e19, \ud8a7\udfa2\uda58\udf7e20, \ud8a7\udfa2\uda58\udf7e21, \ud8a7\udfa2\uda58\udf7e22, \ud8a7\udfa2\uda58\udf7e23, \ud8a7\udfa2\uda58\udf7e24, \ud8a7\udfa2\uda58\udf7e25, \ud8a7\udfa2\uda58\udf7e26, \ud8a7\udfa2\uda58\udf7e27, \ud8a7\udfa2\uda58\udf7e28, \ud8a7\udfa2\uda58\udf7e29, \ud8a7\udfa2\uda58\udf7e30, \ud8a7\udfa2\uda58\udf7e31, \ud8a7\udfa2\uda58\udf7e32, \ud8a7\udfa2\uda58\udf7e33, \ud8a7\udfa2\uda58\udf7e34, \ud8a7\udfa2\uda58\udf7e35, \ud8a7\udfa2\uda58\udf7e36, \ud8a7\udfa2\uda58\udf7e37, \ud8a7\udfa2\uda58\udf7e38, \ud8a7\udfa2\uda58... |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 9, 11, 7, "\uda2a\ude32\ud904\ude8c\ud830\ude16\udba6\udc77\ud92e\udd09\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\udadf\udd44", "\u1f95\u8073\u4bce\u3faa\ucc33\u76cc\u4e94\u98b9\u7c7d\u0b69\u1a93", "\ud8a7\udfa2\uda58\udf7e",
        59, 42074, -2043854920, 6226169186509123363L, -53633L, false, true, (char) 57802, (char) 39301,
        Double.longBitsToDouble(0x3fce9ed64ca17fa4L), Double.longBitsToDouble(0x3feee3b9bf5668aaL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[[D:[[[]]] |a1=[[D:[[[]]]\012",
        Z.run(T, 1, 1, 0, 0, "", "", "\ud845\udda0",
        29, -1000, 1114930622, 35466701660087730L, -3580L, false, false, (char) 15253, (char) 17777,
        Double.longBitsToDouble(0x3fdb55200000328cL), Double.longBitsToDouble(0x3e250d6230000000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=[[Ljava.lang.Number;:[[[9433, 0.2410805326999319]]] |a0=[[Ljava.lang.Number;:[[[9433, 0.2410805326999319]]]\012",
        Z.run(T, 1, 5, 3, 9, "\udb03\ude2a\uda9e\uddbb\ud969\udd84\uda77\udc87\ud845\udda0\udbb6\uddeb\ud8dd\ude72\ud8d9\udc1d\udad0\udfb6\ud9d5\udc54", "\u8ab5", "\udbe2\udda2\udabe\udcbb\uda26\udd27\uda2a\udd61\ud94f\udeec\ud908\udd58\ud9b1\udd51\ud116\ud8d5\udf7e\uda37\udc13\ud9cb\udf14\uda58\udf7e\ud87f\ude57\udb22\udd68\uda6b\udc04\udbf9\uddbd\uda4c\udf5a\udb60\udf07\uda20\udc9b\uda74\udc07",
        58, 9433, -255197330, 3640721294573385320L, 82531L, true, false, (char) 33515, (char) 25491,
        Double.longBitsToDouble(0x3fcedbba15d300f0L), Double.longBitsToDouble(0x3f812e85b4a65ac0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 15, 19, "", "\000\u00f7\ub955\u4c8d\u3032\u42bdo\u1da8\u920c\u3a05\000", "\000",
        58, 93674, 77306192, 9092040176589895364L, -52229L, false, false, (char) 16549, (char) 23226,
        Double.longBitsToDouble(0x3f8d29558f9f8f80L), Double.longBitsToDouble(0x3fec13e060000000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Comparable;:[[]] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 0, 12, 16, "", "", "\ud83e\udd7f",
        0, 33440, 1107328256, -5166753817801916416L, -100000L, false, false, (char) 48236, (char) 32130,
        Double.longBitsToDouble(0x3e3fcdba30000000L), Double.longBitsToDouble(0x3f49e34000000000L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[]]]\0121=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[]]]\012",
        Z.run(T, 2, 7, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u264b", "\ud9b6\udfb8\uda1c\udc72\uc108\udac4\ude92\ud9d0\udf8d",
        24, 5481, 0, 4645762080844199468L, -23214L, false, false, (char) 53134, (char) 30873,
        Double.longBitsToDouble(0x3fed3431686fd155L), Double.longBitsToDouble(0x3fe6b8385037a8c6L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[Ljava.lang.Number;:[[[]]] |a1=[[Ljava.lang.Number;:[[[]]]\0121=java.lang.Boolean:true |a0=[[Ljava.lang.Number;:[[[]]] |a1=[[Ljava.lang.Number;:[[[]]]\012",
        Z.run(T, 2, 7, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda3d\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ucade\u4fe9\u0462\u61ea\u34ff", "\udb28\udfed\udbc8\udce0\uda9f\udc82\ud977\udf51\ud8a7\udfa2\uda58\udf7e\ud9cd\udd8d",
        4, 81080, -782948442, 507315140333862615L, -79905L, true, false, (char) 39301, (char) 15271,
        Double.longBitsToDouble(0x3fdbc3ef74a0fe3aL), Double.longBitsToDouble(0x3fe04e0593db655cL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\uda2a\ude32\ud9fc\udf29\uda54\udd4b\ud93b\udf80\ud845\udda0\ud8a9\udea5\udb8d\udc9c\uda36\udda8\udad4\udf8f\uda11\udcbc]] |a1=[[Ljava.lang.Number;:[[[62966, 0.6610451989903174]]] |a2=[[Ljava.lang.Number;:[[[46, 0.5535794976346872]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 19, 2, 15, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\ud93b\udf80\ud845\udda0\ud8a9\udea5\udb8d\udc9c\uda36\udda8\udad4\udf8f\uda11\udcbc", "\u1f95\u8073\ucade\ud7fc\u3a8a\uce10\uba9d", "\udb28\udfed\udbc8\udce0\uda9f\udc82\ud977\udf51\ud981\uddc9\uda66\udd7a\ud9a6\udc57\ud84b\udedc",
        46, 62966, 118118470, -6285056032173494217L, 22637L, true, false, (char) 15271, (char) 1795,
        Double.longBitsToDouble(0x3fe5274842daeb52L), Double.longBitsToDouble(0x3fe1b6ec59c27787L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[76490, 0.37659023879498477, 2118046734]]] |a1=[[Ljava.lang.Number;:[[[0.1638064178766483, 76490, 0.37659023879498477]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 0, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0", "\u1e5a\u920c\u3a05\u1f95\u8073\ucade\u4fe9\u0462\ub9bf\u4ec8", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 76490, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.String;:[[\uda2a\ude32\ud8d4\udf35\udb6e\udd18\uda77\udc6a\ud845\udda0\ud8a9\udea5\ud8dc\udfa0\udbfd\ude7f\udb37\udda1\ud9ff\udd54]] |a1=[[Ljava.lang.Number;:[[[80360, 0.9954458045795588]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 5, 7, "\uda2a\ude32\ud8d4\udf35\udb6e\udd18\uda77\udc6a\ud845\udda0\ud8a9\udea5\ud8dc\udfa0\udbfd\ude7f\udb37\udda1\ud9ff\udd54", "\ub323\u8073\u0a9e\u90ab\ub62b\u76cc\u4e94", "\uda3d\udeec\udbd8\ude02\ud8b3\udf0c",
        54, 80360, 2118046966, 8938710941280064386L, 86458L, true, false, (char) 14908, (char) 28153,
        Double.longBitsToDouble(0x3fefdab128f381f1L), Double.longBitsToDouble(0x3fc4f79bdc565ec8L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 14, "\uda2a\ude32\uda7d\udcaa\ud9fd\udfea\uda77\udc82\ud845\udda0\ud8a9\udea5\ud8d5\udca0\uda36\udda8\udad0\udf8f\ud9ff\udd54", "\u1f95\u8073\ub1f3\u0c1c\u8c64\u6bfc\u255d\ua820\u7c7d\u0b69\u1a93\ub02b\u6c54\ud403", "\ud84b\udedc\ud834\udc8a\udbc9\udce5\udba0\ude2e\udb37\udc80\udb29\udf7d\ud8a8\udd84\ud89f\udc59",
        53, 29380, -1529873403, -688624066267093390L, 87584L, false, false, (char) 10720, (char) 49506,
        Double.longBitsToDouble(0x3fbc3a718ea40c18L), Double.longBitsToDouble(0x3fefcd82b25ab68fL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[-799]]] |a1=[[Ljava.lang.Number;:[[[-3, -799, -1886701589], [-799]]]\012",
        Z.run(T, 1, 7, 9, 18, "\uda2a\ude32\uda7d\udcaa\uda2e\udc10\uda9b\udcb3\ud8ea\udfb9", "\u2697\uae67\u1e5a\u011a\uaa0d\u1f95\u8073\ub1f3\ub8d9\u8c64\u65e8\u904e\u98ed\u7c7d\u0b69\u1a93\ub02b\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u982e\ua790\u6482\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\uba57\u60e7\u115c\ua05f\ub3d1\u9444\u871e\uae5b\u9b25\ubbd5\uaa1c\uaf46\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u359a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\ua085\u6df5\uc21d", "\udb80\udf95\ud81b\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd09\ud989\udf53",
        -3, -799, -1886701589, 3481851236174488932L, 74057L, true, true, (char) 56253, (char) 7618,
        Double.longBitsToDouble(0x3fc88fe3f49552b0L), Double.longBitsToDouble(0x3fdd17bfd0845d3aL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Comparable;:[[\uf13a\udb36\udea8, \u1c21\u4c8d\u361e, ]] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 16, 15, 16, "\uf13a\udb36\udea8", "\u1c21\u4c8d\u361e", "",
        -5, 14728, 1056868188, -9162812811190256747L, -100000L, false, false, (char) 19482, (char) 0,
        Double.longBitsToDouble(0x3fd60110009bc226L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 11, 12, 9, "\udadd\udfb2", "\uce4f\u9fc7", "\udbf5\ude88\ud814\udd03\ud812\udf98\udbb3\udc00\uda22\uddc9",
        6, 87946, -1270298824, -5240335449643643911L, 4707L, false, false, (char) 1353, (char) 19437,
        Double.longBitsToDouble(0x3fd60387696cc0aaL), Double.longBitsToDouble(0x3fe2b9b2c2ba9fd0L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 11, 11, 13, "\uda2a\ude32\ud9fc\udf29", "\u3a04\u26ee\ub700\u4481", "\uda0e\udc2e\ud950\udf12\udb4f\ude4a\ud8a7\udcf2\udb1c\ude0c\uda04\udd1c\ud9d1\udf5d\u9ebb\ud8ea\udf30\ud9d0\udf8d\ud839\udcf9\ud8f1\ude10\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\udab6\udcde\ud834\udc8a",
        -1, 5584, -2085127194, 4716880911535812993L, 79256L, false, false, (char) 8146, (char) 20281,
        Double.longBitsToDouble(0x3fd5935ea4903810L), Double.longBitsToDouble(0x3feb8614244de2e0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[Category 1, Category 2, Category 3, Category 4] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.util.Collections$UnmodifiableRandomAccessList:[Category 1, Category 2, Category 3, Category 4] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 15, 15, 4, "\udb14\udcf3\ud9fc\udf29", "\u3a04\u26ee\u36b5\u2f23", "\u5409\ud950\udf12\udab2\udf2f\udbde\udefb\udb0d\udc8c\uda04\udd1c\ud9d1\udf5d\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a",
        -1, 5584, -2085127194, 4716881205237756289L, -7435L, false, false, (char) 9739, (char) 17394,
        Double.longBitsToDouble(0x3fe52c916d5069c9L), Double.longBitsToDouble(0x3fd59c99b4903810L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.lang.Boolean:false |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 8, 8, 15, "\uda2a\ude32\udac8\ude70", "\u3a04\u26ee\ub700\u4481", "\ud832\udcf9\ud950\udf12\udab2\udf2f\udbde\udefb\udb0d\udc8c\uda04\udd1c\ud9d1\udf5d\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d",
        56, 19007, -312523287, -8716213543222528511L, -88750L, true, false, (char) 53134, (char) 30873,
        Double.longBitsToDouble(0x3fe721516d8b7a4bL), Double.longBitsToDouble(0x3fdc4f6c460fab6eL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[Ljava.lang.Number;:[[[]]] |a1=[[Ljava.lang.Number;:[[[]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 2, 3, "\uda2a\ude32\ud9fc\udf29\ud45c\uda56\ude87\udbc3\ude99\ud95d\udc93\ud874\udff3\ud9a8\ude06\udada\udea5\ud9ff\udd54\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb2a\udc7b\uda04\udd1c\ud9d1\udf5d\uda18\udde8\udac4\ude59\ud9d0\udf8d\ud839\udcf9\uda32\udff1\udb6b\udcb5\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a\ud9f5\ude3b\ud971\udc8e\udbf7\udc92\ud8c2\udf1c", "\u0342\ucab0\u760e\u207f\u8005\u0c47\uae92\ua71c\u777a\u34d9\u4c8b\u1092\u59b0\u292b\uc36a\u7ce5\u5e82\u630e\uc8ed\u8e22\u1dd0\u3ba0\uc53b\ud247\u63d8\u8877\uc97b\u96de\u8bc5\u380e\uc8c0\u9f42\ubb4b\u1c8d\uccbc\u0f82\ub8b1\ub2a8\u64b1\u5d20\u26a0\u3b26\u964f\u066e\uc542\ubffd\u9310\u6024\u300d\u6fdb\u6b94\ud6d6\u2354\u41ea\u13d5\u5eb8\uad7d\u90ac\u6b44\u2fe7\uc400\uc5d2\u7f61\u6a85\u3641\u8f91\u4157\u7791\u7fae\u3487\u8a3f\u291c\u83ac\u454e\ua2aa\u0486\u6880\u93d9\u87dd\ud33c\uba49\u27c8\ud6c5\ub788\uaf88\ua947", "\udbbd\ude60\uda05\ude92\ud9ed\udea8\uda66\udcc5\ud84e\udf23\ud80e\ude13\uda5c\udc59\udb1c\uddc6\udb4f\udd07\ud992\udd4a\udb12\ude35\ud8f7\udd6a\ud867\ude41\ud8c7\udfd0\u0c9e\ud8ce\udca4\ud929\udc5f",
        16, 88188, -382809603, -5441282746888649791L, -95055L, true, false, (char) 22633, (char) 29114,
        Double.longBitsToDouble(0x3fe1a64f13acc67aL), Double.longBitsToDouble(0x3fe10f01e9c6c860L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 1, 13, 1, 0, "\u8fa1", "\ucd96", "\000\uda36\udda8",
        9, 8118, 1844055027, -3561386988315605258L, 12260L, true, false, (char) 20525, (char) 3759,
        Double.longBitsToDouble(0x3fb5a81e33549808L), Double.longBitsToDouble(0x3fe15dcbc4aa66f4L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Comparable;:[[\000]] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=[Ljava.lang.Comparable;:[[\0001, \0002, \0003, \0004, \0005, \0006, \0007, \0008, \0009, \00010, \00011, \00012, \00013, \00014, \00015, \00016, \00017, \00018, \00019, \00020, \00021]] |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 0, 9, 5, "\000", "\u2bec", "\uda84\ude28\ud9f0\udcb8\ud8cd\udc8d\ud8ce\udc06\000\ud86f\udc6a",
        21, 37933, 2097152000, -5240501115870213127L, 96608L, false, false, (char) 51576, (char) 8298,
        Double.longBitsToDouble(0x3feba1dc64a3ea18L), Double.longBitsToDouble(0x3fd5b3b435992a9eL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 11, 11, 0, "\uda2a\ude32\ud9fc\udf29\ud84d\udfc7\ud9c4\udca8\udb0d\ude9a\ud8a9\udea5\ud8d5\udca0", "\u1e5a\u920c\u3a05\u1f95\u8073\ucade\u4fe9\u0462\ub9bf\u4ec8", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        5, 76490, 2118046734, 8938710942689088386L, 86458L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 17, 13, "\uda2a\ude32\uda7d\udcaa\uda2e\udc10\uda9b\udcb3\ud8a2\udcb4", "\u2697\uae67\u1e5a\u011a\uaa0d\u1f95\u8073\ub1f3\ub8d9\u8c64\u65e8\u904e\u98ed\u7c7d\u0b69\u1a93\ub02b\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u982e\ua790\u6482\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\u1a57\u6090\u115c\u8e97\u6b52\u9444\u871e\uae5b\u9b25\ubbd5\uaa1c\uaf46\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u359a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\ua085\u6df5\uc21d", "\udb80\udf95\ud81b\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd09\ud989\udf53",
        -3, -799, -1886701589, 3481851236174488932L, 74057L, true, true, (char) 56253, (char) 7618,
        Double.longBitsToDouble(0x3fc88fe3f49552b0L), Double.longBitsToDouble(0x3fdd17bfd0845d3aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[-799]]] |a1=[[Ljava.lang.Number;:[[[-3, -799, -1886701589], [-799]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 9, 18, "\uda2a\ude32\uda7d\udcaa\uda2e\udc10\uda9b\udcb3\ud8ea\udfb9", "\u2697\uae67\u1e5a\u011a\uaa0d\u1f95\u8073\ub1f3\ub8d9\u8c64\u65e8\u904e\u98ed\u7c7d\u0b69\u1a93\ub02b\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u982e\ua790\u6482\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\uba57\u60e7\u115c\ua05f\ub3d1\u9444\ua2ad\uaea9\u9b25\ubbd5\uaa1c\uaf46\ucbf1\u4855\ubce5\ucc03\ud2bb\u9db3\u25a4\u9b2f\ud7ab\uc65d\u359a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\ua085\u6df5\uc21d", "\udb80\udf95\ud81b\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd09\ud989\udf53",
        -3, -799, -1886701589, 3481851236174488932L, 74057L, true, true, (char) 56253, (char) 7618,
        Double.longBitsToDouble(0x3fc88fe3f49552b0L), Double.longBitsToDouble(0x3fdd17bfd0845d3aL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[-799]]] |a1=[[Ljava.lang.Number;:[[[-3, -799, -1886701589], [-799]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 2, 13, "\uda2a\ude32\uda7d\udcaa\uda2e\udc10\uda9b\udcb3\ud8a9\udfb4", "\u2697\uae67\u1e5a\u011a\ua967\u1f95\uad9e\ucbc3\u3dd7\u8c64\u65e8\u904e\u98ed\ud332\u0b69\u1a93\ub02b\u162f\u5361\u92ae\ub05f\ua728\u0981\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u982e\ua790\u6482\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\u1a57\u6090\u115c\u8e97\u6b52\u9444\u871e\uae5b\u9b25\ubbd5\uaa1c\uaf46\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u359a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\u56be\u6df5\uc21d", "\udb80\udf95\ud80c\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd09\ud989\udf53",
        -3, -799, -1886701589, 3481851236174488932L, 74057L, true, true, (char) 56253, (char) 7618,
        Double.longBitsToDouble(0x3fc88fe3f49552b0L), Double.longBitsToDouble(0x3fdd17bfd0845d3aL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u2697\uae67\u1e5a\u011a\uaa0d\u1f95\u8073\ub1f3\ub8d9\u8c1d\u65e8\u904e\u98ed\u7c7d\u0b69\u566d\uafad\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u982e\u4e52\u6485\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\u1a57\u8044\u115c\u8e97\u6b52\u9444\u871e\uae5b\u9b25\ubbd5\u2ca5\ub013\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u7f9a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\u47d7\u6dde\uc21d]] |a1=[Ljava.lang.Comparable;:[[\uda2a\ude32\uda7d\udcaa\ud896\udd65\uda87\udc57\ud8a2\udcb4, \u2697\uae67\u1e5a\u011a\uaa0d\u1f95\u8073\ub1f3\ub8d9\u8c1d\u65e8\u904e\u98ed\u7c7d\u0b69\u566d\uafad\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u982e\u4e52\u6485\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\u1a57\u8044\u115c\u8e97\u6b52\u9444\u871e\uae5b\u9b25\ubbd5\u2ca5\ub013\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u7f9a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\u47d7\u6dde\uc21d]] |a2=[[Ljava.lang.Number;:[[[-3]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 9, 15, "\uda2a\ude32\uda7d\udcaa\ud896\udd65\uda87\udc57\ud8a2\udcb4", "\u2697\uae67\u1e5a\u011a\uaa0d\u1f95\u8073\ub1f3\ub8d9\u8c1d\u65e8\u904e\u98ed\u7c7d\u0b69\u566d\uafad\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u982e\u4e52\u6485\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\u1a57\u8044\u115c\u8e97\u6b52\u9444\u871e\uae5b\u9b25\ubbd5\u2ca5\ub013\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u7f9a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\u47d7\u6dde\uc21d", "\udb80\udf95\ud81b\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd8f\ud989\udf53",
        -3, 28290, -1886670219, 3481851236174488932L, 74057L, true, true, (char) 56183, (char) 7618,
        Double.longBitsToDouble(0x3fc88fe3f49552b0L), Double.longBitsToDouble(0x3fe68bdfe8429a32L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[65554]]] |a1=[[Ljava.lang.Number;:[[[13], [-915365123, 13]]]\0121=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[65554]]] |a1=[[Ljava.lang.Number;:[[[13], [-915365123, 13]]]\012",
        Z.run(T, 2, 7, 7, 18, "\udb97\udf69\ud951\udc83\udb27\udd75\udbd1\udc10\uda60\ude74\udbd0\udc7e\udbdd\udd92\uda27\ude13\udb04\udc10\ud9e8\udf62\ud9cd\udec6\uda68\udf88\udabd\udeb3\udbe6\udc25\udaf7\udcb7\udaff\udcd8\udb57\udf92\ud90c\udd10\udab2\udea8\ud9d0\udfc1\ud839\udcf9\udb28\udfed", "\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u7b0a\u3b7a\u9795\u575c", "\ud83f\ude41\udaa9\udd1e\ud966\udc4c\ud881\udeb5",
        13, 65554, -915365123, 5130473925383392499L, -14844L, true, true, (char) 37371, (char) 40604,
        Double.longBitsToDouble(0x3fe42d463cd6f3f9L), Double.longBitsToDouble(0x3fe3eae56c450a45L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[84264, 0.012008213701713788, -372892050]]] |a1=[[Ljava.lang.Number;:[[[0.46452274178676456, 84264, 0.012008213701713788], [19, 0.46452274178676456]]]\0121=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[84264, 0.012008213701713788, -372892050]]] |a1=[[Ljava.lang.Number;:[[[0.46452274178676456, 84264, 0.012008213701713788], [19, 0.46452274178676456]]]\012",
        Z.run(T, 2, 7, 7, 18, "\udb97\udf69\ud951\udc83\udb27\udd75\udbd1\udc10\uda60\ude74\udbd0\udc7e\udbdd\udd92\uda27\ude13\udb04\udc10\ud902\ude8f\ud817\udd9d\uda68\udf2f\udabd\udeb3\udbe6\udc25\udaf7\udcb7\udaff\udcd8\udb57\udf92\ud90c\udd10\udab2\udea8\ud9d0\udfc1\ud839\udcf9\udb28\udfed", "\u162f\u5361\u92ae\u3144\u5159\u376b\u7056\u20c7\u2c35\u4f7d;\u28bd\u39b0\u8abc\u7b0a\u3b7a", "\uda37\uddff",
        19, 84264, -372892050, 4720806430114222951L, 58999L, true, false, (char) 58442, (char) 54309,
        Double.longBitsToDouble(0x3f8897c3290ed3c0L), Double.longBitsToDouble(0x3fddbabd980e3be8L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 7, 7, "\uda2a\ude32\ud9fc\udf29\uda54\udd4b\uda77\udc87\ud845\udda0\udbb3\udeaa\ud8d5\udca0\uda36\udda8\udb79\ude63\ud9ff\udd54", "\u1f95\u8073\ub1f3\ub383\ub62b\u76cc\u4e94", "\udb28\udfed\udbc8\udce0\uda9f\udc82",
        27, 99530, 2118046734, 8938710942689088386L, 76296L, true, false, (char) 1505, (char) 6398,
        Double.longBitsToDouble(0x3fd81a0df1e781aeL), Double.longBitsToDouble(0x3fc4f79bd3d3dac8L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=[Ljava.lang.Comparable;:[[\ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc431, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc432, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc433, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc434, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc435, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc436, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc437, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc438, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc439, \ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc431... |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=[Ljava.lang.Comparable;:[[\uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf771, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf772, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf773, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf774, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf775, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf776, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf777, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf778, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf779, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf7710, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf7711, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf7712, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf7713, \uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80... |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 9, 9, 16, "\uda2a\ude32\ud87f\uddc1\uda54\udd0f\ud8e9\udc80\ud845\udda0\ud965\udca3\uda37\udfce\u8b43\udbab\ude7c\ud9ac\udf77", "\u71b1\u7273\ub1f3\u8125\u32e9\u38a4\uae6d\ucabb\u9ffa\u8935\u885d\u2e84", "\ud966\udda5\uda35\udc35\ud84b\udedc\ud834\udc8a\ud893\udcea\udb43\udfda\u65a7\udb64\udf52\ud87b\uddc8\ud8aa\udc99\ud9cc\udc91\ud962\uddb5\ud922\udea3\udbea\udc43",
        50, 47328, 151190973, 5958703109991513289L, -73978L, true, false, (char) 498, (char) 32600,
        Double.longBitsToDouble(0x3fde1b80137d68eaL), Double.longBitsToDouble(0x3fd82dbceaddecc2L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=[Ljava.lang.Comparable;:[[\udb9c\udda4\uda84\udf82\udb84\ude35\ud953\uded5\udb99\udf3f\ud85a\udfb7\udbba\udce0\ud935\udc07\ud84b\udcd7\ud879\udc6b\ud905\udf4d\udace\udd32\ud9a3\udf90\udbd1\ude7f\udad0\udce0\ud855\udfa9\ud807\udc83\udaca\udd48\ud9b7\udeba\udac9\ude19\ud801\uddd1\ud9e3\udc85\udbea\ude8e\udbe7\uddb7\ud8cc\udec0\ud9d0\ude921, \udb9c\udda4\uda84\udf82\udb84\ude35\ud953\uded5\udb99\udf3f\ud85a\udfb7\udbba\udce0\ud935\udc07\ud84b\udcd7\ud879\udc6b\ud905\udf4d\udace\udd32\ud9a3\udf90\udbd1\ude7f\udad0\udce0\ud855\udfa9\ud807\udc83\udaca\udd48\ud9b7\udeba\udac9\ude19\ud801\uddd1\ud9e3\udc85\udbea\ude8e\udbe7\uddb7\ud8cc\udec0\ud9d0\ude922, \udb9c\udda4\uda84\udf82\udb84\ude35\ud953\uded5\udb99\udf3f\ud85a\udfb7\udbba\udce0\ud935\udc07\ud84b\udcd7\ud879\udc6b\ud905\udf4d\udace\udd32\ud9a3\udf90\udbd1\ude7f\udad0\udce0\ud855\udfa9\ud807\udc83\udaca\udd48\ud9b7\udeba\udac9\ude19\ud801\uddd1\ud9e3\udc85\udbea\ude8e\udbe7\uddb7\ud8cc\udec0\ud9d0\ude923, \udb9c\udda4\uda84\udf82\udb84\ude35\ud953\uded5\udb99\udf3f\ud85a\udfb7\udbba\udce0\ud935\udc07\ud84b\udcd7\ud879\udc6b\ud905\udf4d\udace\udd32\ud9a3\udf90\udbd1\ude7f\udad0\udce0\ud855\udfa9\ud807\udc83\udaca\udd48\ud9b7\udeba\udac9\ude19\ud801\uddd1\ud9e3\udc85\udbea\ude8e\udbe7\uddb7\ud8cc\udec0\ud9d0\ude924, \udb9c\udda4\uda84\udf82\udb84\ude35\ud953\uded5\udb99\udf3f\ud85a\udfb7\udbba\udce0\ud935\udc07\ud84b\udcd7\ud879\udc6b\ud905\udf4d\udace\udd32\ud9a3\udf90\udbd1\ude7f\udad0\udce0\ud855\udfa9\ud807\udc83\udaca\udd48\ud9b7\udeba\udac9\ude19\ud801\uddd1\ud9e3\udc85\udbea\ude8e\udbe7\uddb7\ud8cc\udec0\ud9d0\ude925, \udb9c\udda4\uda84\udf82\udb84\ude35\ud953\uded5\udb99\udf3f\ud85a\udfb7\udbba\udce0\ud935\udc07\ud84b\udcd7\ud879\udc6b\ud905\udf4d\udace... |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 18, 4, "\ud9b7\udfa7\udb62\udcca\udb21\udf14\uda95\udedc\udb3d\udf1d\ud9ee\ude90\ud8f8\uddff\udab3\udfaa\ud8a8\udc10\ud9aa\udfb6", "\u2836\u8073\u7f74\u5a6b\ud7a7\u1945\u4e94\u98b9\u1cc8\u2c99\u122f\u91b5\ud10d\u4b77\u38bd\uafa6\u12ab\u7f99\u51bb\u808b", "\udb9c\udda4\uda84\udf82\udb84\ude35\ud953\uded5\udb99\udf3f\ud85a\udfb7\udbba\udce0\ud935\udc07\ud84b\udcd7\ud879\udc6b\ud905\udf4d\udace\udd32\ud9a3\udf90\udbd1\ude7f\udad0\udce0\ud855\udfa9\ud807\udc83\udaca\udd48\ud9b7\udeba\udac9\ude19\ud801\uddd1\ud9e3\udc85\udbea\ude8e\udbe7\uddb7\ud8cc\udec0\ud9d0\ude92",
        17, 11644, -1116380530, -6684011769101625698L, 12733L, true, true, (char) 9584, (char) 14266,
        Double.longBitsToDouble(0x3fc8eb9e70106ef0L), Double.longBitsToDouble(0x3fd40d3ec141e6bcL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=java.lang.Integer:-1 |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 13, 13, 0, "\ud94b\udda1\ud8de\udf32\uda60\ude6f\uda77\udc87\ud845\udda0\ud8a9\udea5\ud8d5\udca0\ud815\ude98\ud84c\udfef\udbf0\udfdf", "\u2d49\u7ff1\u625c\ub4ae\ub62b\u7309\u4e94\u98b9\u7c7d\u847e\ubb16\u57ac\u896b\u32da\u69ae\u1164", "\ud9ad\udf0c\ud847\uddc7",
        19, 13415, -1837911261, 6514241798937959555L, -13403L, true, true, (char) 44905, (char) 21844,
        Double.longBitsToDouble(0x3feea9ecdd2c2d99L), Double.longBitsToDouble(0x3fc03cb8cca26a9cL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=[[Ljava.lang.Number;:[[[0.3004519284678977, 0.315692309789124]]] |a0=[[Ljava.lang.Number;:[[[0.3004519284678977, 0.315692309789124]]]\012",
        Z.run(T, 1, 5, 3, 9, "\udb03\ude2a\uda9e\uddbb\ud969\udd84\uda77\udc87\ud845\udda0\udbb6\uddeb\ud8dd\ude72\ud8d9\udc1d\udad0\udfb6\ud9d5\udc54", "\u8ab5", "\udbe2\udda2\udabe\udcbb\uda26\udd27\uda2a\udd61\ud94f\udeec\ud908\udd58\ud9b1\udd51\ud116\ud8d5\udf7e\uda37\udc13\ud9cb\udf14\uda58\udf7e\ud87f\ude57\udb22\udd68\uda6b\udc04\udbf9\uddbd\uda4c\udf5a\udb60\udf07\uda20\udc9b\uda74\udc07",
        58, 9433, -255197330, 3640721294573385320L, -72360L, false, false, (char) 7693, (char) 16610,
        Double.longBitsToDouble(0x3fd33a9ab9b28b4cL), Double.longBitsToDouble(0x3fd4344d848926b8L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultIntervalCategoryDataset:@? |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\0121=org.jfree.data.category.DefaultIntervalCategoryDataset:@? |this=org.jfree.data.category.DefaultIntervalCategoryDataset:@?\012",
        Z.run(T, 2, 6, 6, 7, "\uda2a\ude32\ud88d\udfd2\ud847\udc0c\uda77\udc15\ud845\uddd3\ud8a9\udea5\ud8dc\udfa0\u9581\udb37\udd0f\ud9ff\udd54\uda7e\ude24\ud950\udf12\udb7c\uddbf\udbde\udefb", "\u195f\u7742\ub72b\u98b9\ub97d\u6138\u34ec\u3827\u7887\u1783\u6a96\u3144\u3362\u73a2", "\ud9ac\udedb\uda9b\udd90\ud9e9\uddb3",
        10, 18855, 338138901, 5784889469385051839L, 2270L, true, true, (char) 19207, (char) 63663,
        Double.longBitsToDouble(0x3fe219bb28c090b4L), Double.longBitsToDouble(0x3fe5de422d43d762L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[[Ljava.lang.Number;:[[[0.2539201870812804, 0.7578672805616552, 0.2539201870812804]]]\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u2697\uae67\u1e5a\u011a\ua967\u58db\u829e\ucbc3\u3dd7\u8c64\u65e8\u904e\u98ed\ud332\u0b69\u1a93\ub02b\u162f\u5361\u92ae\ub05f\ua728\u0981\u7056\u20c7\u2c35\u4f7d;\ub6eb\u39b0\u8abc\u982e\u2490\u6482\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\u1a57\u6090\u115c\u8e97\u6b52\u9444\u871e\uae5b\u9b25\ubbd5\uab9b\uafc4\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u359a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\u56be\uc81c\u4d60, \udb7a\uddc0\ud80c\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd09\ud989\udf53\u29fc\udb77\udcbb\ud98c\udd4a\ud8f4\udc99\ud9db\udfbd\ud9b1\udce8\udbad\uddeb, \uda2a\ude32\uda7d\udcaa\uda2e\udc10\uda9b\udcb3\ud8a9\udfb4]] |a1=[Ljava.lang.Comparable;:[[\udb7a\uddc0\ud80c\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd09\ud989\udf53\u29fc\udb77\udcbb\ud98c\udd4a\ud8f4\udc99\ud9db\udfbd\ud9b1\udce8\udbad\uddeb, \uda2a\ude32\uda7d\udcaa\uda2e\udc10\uda9b\udcb3\ud8a9\udfb4]] |a2=[[Ljava.lang.Number;:[[[0.2539201870812804, 0.7578672805616552, 0.2539201870812804], [0.7578672805616552, 0.2539201870812804, 0.7578672805616552]]]\012",
        Z.run(T, 2, 7, 2, 13, "\uda2a\ude32\uda7d\udcaa\uda2e\udc10\uda9b\udcb3\ud8a9\udfb4", "\u2697\uae67\u1e5a\u011a\ua967\u58db\u829e\ucbc3\u3dd7\u8c64\u65e8\u904e\u98ed\ud332\u0b69\u1a93\ub02b\u162f\u5361\u92ae\ub05f\ua728\u0981\u7056\u20c7\u2c35\u4f7d;\ub6eb\u39b0\u8abc\u982e\u2490\u6482\u575c\u980f\u0334\u238b\u5b19\u8686\u2b69\u3cee\u788b\uaa52\ubf3c\u3ee2\u1a57\u6090\u115c\u8e97\u6b52\u9444\u871e\uae5b\u9b25\ubbd5\uab9b\uafc4\ucbf1\u4855\ubce5\ucc03\ud2bb\ub25e\ub79d\u9b2f\ud7ab\uc65d\u359a\u9f79\uc3d2\u7a79\u2149\u16e4\u22c8\ub5fc\u4ea6\u358a\u102a\ub646\ubf9d?\u56be\uc81c\u4d60", "\udb7a\uddc0\ud80c\ude70\ud902\udd53\udbce\udcac\ud853\uddba\ud8c0\udd09\ud989\udf53\u29fc\udb77\udcbb\ud98c\udd4a\ud8f4\udc99\ud9db\udfbd\ud9b1\udce8\udbad\uddeb",
        23, 15110, -1700853889, 6101397574608831781L, 37189L, false, false, (char) 19649, (char) 58260,
        Double.longBitsToDouble(0x3fd0403a74d3bb34L), Double.longBitsToDouble(0x3fe84072e2171083L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u5cbc\u9b03]] |a1=[Ljava.lang.Comparable;:[[\udbe0\udf28\uda0d\udc62\udbb5\ude48\udbf7\udd3e\udbee\uddd7\ud8d8\ude78\ubd5a\uda25\ude9a\udad0\udf8f\uda00\udc54]] |a2=[[Ljava.lang.Number;:[[[0.6889318796017883]]]\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u5cbc\u9b03]] |a1=[Ljava.lang.Comparable;:[[\udbe0\udf28\uda0d\udc62\udbb5\ude48\udbf7\udd3e\udbee\uddd7\ud8d8\ude78\ubd5a\uda25\ude9a\udad0\udf8f\uda00\udc54]] |a2=[[Ljava.lang.Number;:[[[0.6889318796017883]]]\012",
        Z.run(T, 2, 2, 18, 8, "\udbe0\udf28\uda0d\udc62\udbb5\ude48\udbf7\udd3e\udbee\uddd7\ud8d8\ude78\ubd5a\uda25\ude9a\udad0\udf8f\uda00\udc54", "\u5cbc\u9b03", "\ud9b5\udeac\ucdd8\udac4\ude5d",
        57, 21869, 1528349137, -5521618317707661958L, 3997L, false, true, (char) 59801, (char) 33265,
        Double.longBitsToDouble(0x3fe60bbade81f7baL), Double.longBitsToDouble(0x3fe74d165161a0dfL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u0342\ucab0\u760e\u207f\u8005\u0c47]] |a1=[Ljava.lang.Comparable;:[[\u848e\ud917\udde3\ud45c\uda56\ude87\udbc3\ude99\ud95d\udc93\ud874\udff3\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb2a\udc7b\uda04\udd1c\ud85d\udd42\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a\ud9f5\ude3b\udb94\udd1f\udb51\udd91\ud94a\udfe0, \u0342\ucab0\u760e\u207f\u8005\u0c47, \ud8d3\udc87]] |a2=[[Ljava.lang.Number;:[[[0.7399273661498089]]]\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u0342\ucab0\u760e\u207f\u8005\u0c47]] |a1=[Ljava.lang.Comparable;:[[\u848e\ud917\udde3\ud45c\uda56\ude87\udbc3\ude99\ud95d\udc93\ud874\udff3\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb2a\udc7b\uda04\udd1c\ud85d\udd42\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a\ud9f5\ude3b\udb94\udd1f\udb51\udd91\ud94a\udfe0, \u0342\ucab0\u760e\u207f\u8005\u0c47, \ud8d3\udc87]] |a2=[[Ljava.lang.Number;:[[[0.7399273661498089]]]\012",
        Z.run(T, 2, 2, 2, 3, "\u848e\ud917\udde3\ud45c\uda56\ude87\udbc3\ude99\ud95d\udc93\ud874\udff3\uda36\udda8\udad0\udf8f\ud9ff\udd54\udbe5\udee4\ud950\udf12\udab2\udf2f\udbde\udefb\udb2a\udc7b\uda04\udd1c\ud85d\udd42\ud9c6\udc6a\udac4\ude5e\ud9d0\udf8d\ud839\udcf9\uda32\udff1\ud887\udda3\udba4\udc8f\ud845\udc0b\ud9f3\udd99\ud9aa\ude27\ud9b6\udff0\ud84b\udedc\ud834\udc8a\ud9f5\ude3b\udb94\udd1f\udb51\udd91\ud94a\udfe0", "\u0342\ucab0\u760e\u207f\u8005\u0c47", "\ud8d3\udc87",
        9, 23395, -1959587679, -7459944073604325921L, -18697L, false, false, (char) 47691, (char) 10832,
        Double.longBitsToDouble(0x3fe7ad7c27e0ec50L), Double.longBitsToDouble(0x3fecc1d42fe90244L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u5cbc\u9b03]] |a1=[Ljava.lang.Comparable;:[[\udbe0\udf26\uda0d\udc62\udbb5\ude48\udbf7\udd3e\udbee\uddd7\ud8d8\ude78\ud91f\udf91\uda2a\udec7\udad0\udf8f\uda00\udc54]] |a2=[[Ljava.lang.Number;:[[[0.6889318796017883]]] |a3=[[Ljava.lang.Number;:[[[45197]]]\0121=new org.jfree.data.category.DefaultIntervalCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u5cbc\u9b03]] |a1=[Ljava.lang.Comparable;:[[\udbe0\udf26\uda0d\udc62\udbb5\ude48\udbf7\udd3e\udbee\uddd7\ud8d8\ude78\ud91f\udf91\uda2a\udec7\udad0\udf8f\uda00\udc54]] |a2=[[Ljava.lang.Number;:[[[0.6889318796017883]]] |a3=[[Ljava.lang.Number;:[[[45197]]]\012",
        Z.run(T, 2, 2, 18, 12, "\udbe0\udf26\uda0d\udc62\udbb5\ude48\udbf7\udd3e\udbee\uddd7\ud8d8\ude78\ud91f\udf91\uda2a\udec7\udad0\udf8f\uda00\udc54", "\u5cbc\u9b03", "\ud9b5\udeac\ucdd8\udac4\ude5d",
        57, 45197, 1528342665, -5521618317707661958L, 3997L, false, true, (char) 15822, (char) 33327,
        Double.longBitsToDouble(0x3fe60bbade81f7baL), Double.longBitsToDouble(0x3fe74d165161a0dfL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|setCategoryKeys|[Ljava.lang.Comparable;|new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[[D,[[D",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[Ljava.lang.Comparable;,[Ljava.lang.Comparable;,[[Ljava.lang.Number;,[[Ljava.lang.Number;",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[Ljava.lang.String;,[[Ljava.lang.Number;,[[Ljava.lang.Number;",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[[Ljava.lang.Number;,[[Ljava.lang.Number;",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|clone|[[Ljava.lang.Number;|static",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|clone||new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|equal|[[Ljava.lang.Number;,[[Ljava.lang.Number;|static",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|equals|java.lang.Object|new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|generateKeys|int,java.lang.String|new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|getCategoryCount||new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|getCategoryIndex|java.lang.Comparable|new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|getColumnCount||new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|getColumnIndex|java.lang.Comparable|new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|getColumnKey|int|new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|getColumnKeys||new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "M|org.jfree.data.category.DefaultIntervalCategoryDataset|setCategoryKeys|[Ljava.lang.Comparable;|new:org.jfree.data.category.DefaultIntervalCategoryDataset:[[D,[[D",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[[D,[[D",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[Ljava.lang.Comparable;,[Ljava.lang.Comparable;,[[Ljava.lang.Number;,[[Ljava.lang.Number;",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[Ljava.lang.String;,[[Ljava.lang.Number;,[[Ljava.lang.Number;",
    "C|org.jfree.data.category.DefaultIntervalCategoryDataset|<init>|[[Ljava.lang.Number;,[[Ljava.lang.Number;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
