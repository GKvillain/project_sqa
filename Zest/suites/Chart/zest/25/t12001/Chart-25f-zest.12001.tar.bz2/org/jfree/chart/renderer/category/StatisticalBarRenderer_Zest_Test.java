package org.jfree.chart.renderer.category;
import org.junit.Test;
import static org.junit.Assert.*;
public class StatisticalBarRenderer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u6c31\ube86\u18ff\ud063\u21ca\u8eaf\u4174\u1739\uc6e4\u9014", "\udb1e\udea0",
        10, 47914, 898656586, 3170105141109799030L, 369L, false, true, (char) 12681, (char) 10096,
        Double.longBitsToDouble(0x3fe66f43bfa2fe32L), Double.longBitsToDouble(0x3fdb5450607b87beL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 6, 10, "\udb2e\ude24\u064c\ud909\udffc\ud8af\udeea\uda78\udda2\ud980\udc89\ud80a\udec5\ud927\udf68\udaa9\udfb4\uda75\udfd4", "\u76a5\uca86\u989e\u8867\ubb2a\uae40\u6c31", "\udbe8\udff3\ud9ec\uddd5\ud80b\udd84\ud821\udce1\ud8e4\uddfd\ud914\udeac",
        29, 62795, 1388594415, -6065552167020847326L, 6038L, false, false, (char) 51012, (char) 50644,
        Double.longBitsToDouble(0x3fdb5450627b87beL), Double.longBitsToDouble(0x3fe0b147a1bf1aeeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 6, "\udb2e\ude24", "\ud369\u66cc", "\ud927\udf68\u1402",
        2, 10760, 623085331, -5769456871755022162L, -89816L, true, true, (char) 28, (char) 48947,
        Double.longBitsToDouble(0x3fce729ae09d1350L), Double.longBitsToDouble(0x3e25f25220000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 10, 0, 0, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u6c31\ube86\u18ff\ud063\u21ca\u8eaf\u4174\u1739\uc6e4\u9014", "\udb1e\udea0",
        10, 47914, 898656586, 3170105141109799030L, 369L, false, true, (char) 12681, (char) 10096,
        Double.longBitsToDouble(0x3fe66f43bfa2fe32L), Double.longBitsToDouble(0x3fdb5450607b87beL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\uc79e", "\udbe8\udfeb\ud915\udc50\udb76\udd77\uda89\uddda",
        8, 66067, 1154774259, 7833404789519176801L, 20412L, false, false, (char) 10463, (char) 47512,
        Double.longBitsToDouble(0x3feda28f0eab8d92L), Double.longBitsToDouble(0x3fcde28104a94b10L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 0, 7, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\ub671\u5317\u76a5\u688c\u0cbf\u1959\u6e76\u8707\u6c31\ube86\u6bb6\ud063\u21ca\u8e64\u4174\u1739\uc6e4\u9014", "\udb1e\udea0",
        10, 28266, 898655401, 5908293714551060693L, 369L, false, true, (char) 12681, (char) 10096,
        Double.longBitsToDouble(0x3fe66f43bfa2fe32L), Double.longBitsToDouble(0x3fdb5450607b87beL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 3, 9, 7, "\udb68\ude0f\uda7d\udcff\uda27\udfa2\ud89d\udefd\ud893\udf9c\udb22\udd18\u1633\ud927\udee9", "\uc79e\u5317\u76a5\u688c\u0cbf\u557e\uab4d\uae40\u6c31\ube86\u18ff\ud063\u21ca\u0dd3\u416d\u1739\uc6e4\u9014", "\udb1e\udea0",
        10, 47954, 898656716, 3170247832808274038L, 369L, false, true, (char) 12681, (char) 31166,
        Double.longBitsToDouble(0x3fd325735de10ee0L), Double.longBitsToDouble(0x3fdb5decc07b87beL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 2, "\udb2e\ude51\uda1e\uded2\uda26\udd6e\ud89d\ude87\udacb\ude2a\udb11\ude19\ud80a\udec5\uda0c\udfdc\udaa9\udefa\udbf3\udef3\udb3d\udef8\ud904\udd43\ud802\udcd3\udbe8\udfeb\ud915\udc50\udb76\udd77\uda89\uddda\udb28\uddb8\ud92d\udce2\ud97c\udd01\ud809\ude8f\ud8b7\ude91\ud9ec\uddd5\ud8b3\udcd7", "\uc6e4\u9014\u1e69\u3d4b\u2224\u81e9\u8bfe\u08c6\u4df8\u4286\u9e08\uaef6\u0e78\uad6f\u6f91\u23d2\u7171\u0a72\uba86\u6488\uc1b0\u5931", "\ud874\udd90\ud8fe\uddb5\ud995\udc3e\uda31\udec2\ud874\ude07\udba3\udfcc",
        16, 89365, -1784813288, -7268533594524269560L, -6293L, true, true, (char) 23586, (char) 27860,
        Double.longBitsToDouble(0x3fd86ec95f8f90eeL), Double.longBitsToDouble(0x3fe44ae6489db59cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 10, 4, 0, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udbdd\udf51\uda3d\udc2e\udbb7\ude85\uda57\udeaf", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u6c31", "\ud8b7\ude91\ud9ec\uddd5\ud80b\udd84",
        -4, 80620, 1373744601, -8245501905564313941L, -56382L, false, true, (char) 44900, (char) 25716,
        Double.longBitsToDouble(0x3fd00747dfdf58feL), Double.longBitsToDouble(0x3febe0d17724c264L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 10, 5, 2, "\udb2e\ude24", "\ua1ba\u66cc", "\ud927\udf68\ud8ba\udd71\ud902\udece\ud9f8\udc11\ud904\udd43\ud802\udcd3",
        19, 10308, 355719224, 800766838893644037L, 52673L, true, true, (char) 43455, (char) 35982,
        Double.longBitsToDouble(0x3fc404f2776529d4L), Double.longBitsToDouble(0x3feda28f0eab8d92L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 4, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udbc1\ude26\udb11\ude08\ud80a\udec5\ud888\udf39", "\u3f07\u3d9a\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u6c31\ube86\u18ff\ud063\u21ca\u8eaf\u4174\u62fc\u71e4\u9014\u1e69\u6707\u869b\u4484\u8b9b\u08c6\u4df8\u4286\u9e08\u08f6\u8eea\uad6f\u91f4\u64aa\u7171\u0a72\u25d1\u7ad7\u6a13\ua981\uccf1\ud6fa\ud4a6\u76c7\u5292\u0206\u12e8\u9301\u898c\u7867\u4e4b\ua370\u4007\u8942\uad88\ubdc7\ua3f2\u42d8\uba52\ucbd7\u8e5c\uba7e\u1dc7\u9e14\u1a71\ua69a\ubc34\u67db\u24cc\u82c4", "\uda3e\uddb1\ud80f\udeed\udbc4\udf35",
        51, 92805, -1975486160, -3558228684618112893L, -71280L, true, true, (char) 17949, (char) 33978,
        Double.longBitsToDouble(0x3fea14f1b23cc5b0L), Double.longBitsToDouble(0x3fe999aa0ac2e606L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 4, 4, 4, "\uda6f\udf92", "\ud369\u6ddf", "\uda9f\udc04\ud83d\udc0b\ud8f7\udf35\ud8c0\uddcf\udbff\udd60\ud802\udcd3\udbe8\udfeb\ud9f7\udf02\ud81f\udc75\uda4b\udfdb\udb28\uddb8\ud92d\udce2\ud97c\udd01\ud809\ude8f\ud8b7\ude91\ud9ab\udcc2\ud804\udf01\ud96e\udc63\ud998\udcd9\udaf6\udfcb\uda8b\udede\u270b\ud91d\udde5\uda45\udda7\ud9b9\udced\udafe\ude0b\ud8d8\udf6b\uda29\udfb8\ud98b\udf53",
        52, 79940, -1033570436, -7399291988577120736L, -93706L, true, false, (char) 19083, (char) 13297,
        Double.longBitsToDouble(0x3fdf2b226c925fdaL), Double.longBitsToDouble(0x3fe2d7bf70c5e9b2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5", "\u622a\uc79e\u5317", "\ud915\udc50\udb76\udd77\uda89\uddda\uda92\udf0c\ud944\udd9e\ud97c\udd01\ud809\ude8f\ud8b7\ude91\ud9ec\uddd5\ud80b\udd84\ud821\udce1\ud8e4\uddfd\ud914\udeac\uda88\udcf5\ud8b3\udfd9\uda38\udee5\ud9ce\udcf1\ud9b9\udced\udafe\ude0b\ud82d\udc72\udacf\udc6b\ud98b\udf53\ud8d9\udc14\udbf4\udd79\uda3a\udfda\udb40\udd16\udbdd\udcbc\udb41\udeb1\ud956\udfb3\udb9b\ude29\ud932\udcf8\uda26\udce1\ud8ce\udde0\udad3\udd20\u97c3\ud8aa\udecc\ud977\uddb1\udba5\udf4f\uda7a\ude45",
        32, 96129, 650149673, -3137984232095242475L, 85834L, false, false, (char) 16049, (char) 34112,
        Double.longBitsToDouble(0x3feeedc77c9ef4a0L), Double.longBitsToDouble(0x3fe7a85c53302405L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 8, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u6c31\ube86\u18ff\ud063\u21ca\u8eaf\u4174\u1739\uc6e4\u9014", "\udb1e\udea0",
        10, 47914, 898656586, 3170105141109799030L, 61775L, false, true, (char) 12681, (char) 10096,
        Double.longBitsToDouble(0x3fe66f43bfa2fe32L), Double.longBitsToDouble(0x3fdb5450607b87beL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 7, 4, 2, "\udb2e\ude24\udb98\udca6\uda26\udd6e\uda5b\udd3c\udb0c\udf4b\uda72\udf0a\ud80a\udec5\ud927\udfb3\ud818\udc2b\uda75\udfd4\ud8c0\uddcf\ud904\udd43", "\u07bf\u1959\uaa5e\uae40\u6c31\ube86\u18ff\u1f80\u7dc1\u0841\u4174\u1739\uc6e4\u9014\u1f89\u6707\u869b\u4484\u8b9b\u08c6\u4df8\u4286\u9e08\u01b7\u0e80\uad6f\uaa3b\u64aa\u7171\u0aa5\ubfbc\ubac5\u9975\uabfa\u9a0d\u2442\u8ffc\u718c\ucb99", "\ud913\udc59\udb5f\udf38\ud9a1\udfa4\ud9c2\udddf\udab2\udfef\ud956\udf23\udbb5\udc4a",
        17, 80686, -740670894, 8356950234427857013L, -71713L, false, true, (char) 1435, (char) 8155,
        Double.longBitsToDouble(0x3fd65d877d10060aL), Double.longBitsToDouble(0x3fed527278058c7cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=null |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 7, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u79d3\u2364\u074f\u8cc6\u21ca\u09f3\u416c\u1739\uc6e4\u9014", "\udb1e\udea0",
        10, 47914, 898656586, 3170105141109799030L, 369L, false, true, (char) 15929, (char) 51629,
        Double.longBitsToDouble(0x3fc202505e8bf8c8L), Double.longBitsToDouble(0x3fdb5450607b87beL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 7, 8, 2, "\udb2e\ude24", "\uc2e3\u4943", "\ud927\udf68\udabf\udf68\uda18\udcc1\ud8c0\uddcf\ud904\udd43\ud802\udcd3",
        19, 10308, 355719224, 800766838893644035L, 52673L, true, true, (char) 43455, (char) 35982,
        Double.longBitsToDouble(0x3fd4c2793bb21780L), Double.longBitsToDouble(0x3feda28f0eab8d92L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u6c31\ube86\u18ff\ua8a2\u21ca\u8eaf\u4174\u1739\uc6e4\u9014", "\udb1e\udea0",
        10, 47914, 898656586, 3170105141109799030L, -63315L, true, false, (char) 59217, (char) 38198,
        Double.longBitsToDouble(0x3fde4c6cc4cc2286L), Double.longBitsToDouble(0x3fdbd8e3b203f298L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 10, 0, 0, "\udb2e\ude24", "\ud2ad\u66cc", "\ud100\000\000\000\000\u700e",
        -5, -1000, 0, 800514831687551237L, 52673L, true, false, (char) 0, (char) 53899,
        Double.longBitsToDouble(0x3ec2600000000000L), Double.longBitsToDouble(0x3fc6800000023400L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 0, "\udb2e\udd95", "\ud369F", "",
        -5, -1000, -441909248, -4746497477788334317L, -100000L, false, false, (char) 55351, (char) 64101,
        Double.longBitsToDouble(0x3fd050b1c0000056L), Double.longBitsToDouble(0x3df3a20000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 10, 8, 8, "\ud82e\ude83\ud985\udfdc\ud8e0\ude58\udbad\udc2f\udacb\ude0c\udb11\ude19\ud80a\udec5\udb27\udf68", "\uc79e\u5317\u76a5\ubc1a\u0cbf\u1959\uaa5e\uae40\u8dde\u58a4\u191a\ud063\u21ca", "\udab1\udef1\ud828\udd82\uda88\udcf5\uda43\udc11\ud87b\udcd1\udb09\udd74\ud9b9\udced",
        54, 58550, 738097620, 8393927358544855296L, -89636L, true, true, (char) 10096, (char) 51012,
        Double.longBitsToDouble(0x3fe8c7f190b5b040L), Double.longBitsToDouble(0x3fdb2c1840e5e76cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud8a2\udd7c\ud9f8\udea1\u2058\udb6c\udc96\ud958\udc5f", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u4d81\ube86\u18ff\u39df\u54fe\u8eaf\u4174\u469d\u2e0e\u8ffc\u1e69\u3dd2\u93f9\uc59c\u8bf5\u08c6", "\udb1e\udd95\udbf4\udd79\uda3a\udfda\udb40\udd16\udbdd\udcbc\uda37\udcb7\ud956\udfb3\udb9b\ude29\ud838\udf9f\ud9f4\udc66\ud8be\udd1a\udb94\udd19\udbbd\ude89\udad1\udd1a\ud8ea\udce9\ud8cb\udee2\ud87e\udcca\uda6c\udce4\udafb\udd02\udaa7\udf0f\udb4b\udd84\ud9f6\udf4b\udb02\uded0\ud9f0\uddbe\uda89\ude9f\ud976\ude1c\udba5\udf62\udb6e\uded9\ud83e\uddc9\udaf3\udf7e\udb70\udf50\ud987\udc96\udbcc\udf49\udbf8\udd05\ud959\udf2b\ud9d7\udf75\ud913\ude32\ud84c\udd23\ud86c\ude74\udbf6\udfb6\udb11\udedf\uda11\udf00\ud940\ude4c\udb71\udcc5\ud80a\udcb0\ud892\ude43\ud907\udde2\ud880\udda7\udb56\udeff\ud946\ude65\uda9e\udd8b\udb91\udd1c\ud8c4\udec2\udb0b\udd3f\uda20\uded9\ud82f\uddb6\ud8fd\udec7\ud85a\ude99\uda0d\udd9e\udb28\udd48\udb5e\ude9c\uda6d\uddce",
        35, 16512, 1665932712, -3062150072292955126L, -24148L, false, false, (char) 2061, (char) 35389,
        Double.longBitsToDouble(0x3fea50027b66a061L), Double.longBitsToDouble(0x3fef11878da37d19L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb5c\udcde\000\ud927\udf68", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\005\u6c31\ube86\u18ff\000\u206b\u8eaf\u4174\u1739\uc6e4\u9014", "\udb1e\udea0",
        42, -1000, 0, 3170104230576732278L, 369L, false, true, (char) 12681, (char) 10096,
        Double.longBitsToDouble(0x3fe66f43bfa2fe32L), Double.longBitsToDouble(0x3fdb5450607b87beL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 10, "\u022e\u064c\ud909\udffc\ud8af\udeea\uda78\udda2\ud980\udc89\ud80a\udec5\ud927\udf68\udaa9\udfb4\uda75\udfd4", "\u76a5\uca86\u989e\u8867\ubb2a\uae40\u6c31", "\udbe8\udff3\ud9ec\uddd5\ud80b\udd84\ud821\udce1\ud8e4\uddfd\ud914\udeac",
        29, 62795, 1388594415, -6065552167020847326L, 6038L, false, false, (char) 51012, (char) 50644,
        Double.longBitsToDouble(0x3fdb5450627b87beL), Double.longBitsToDouble(0x3fe0b147a1bf1aeeL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 4, 6, 10, "\udb2e\ude24\udae2\udcbb\uda23\udff1\ud8af\ude6b\uda78\udda2\ud980\udcdb\uce46\ud927\udf68\udaa9\udfb4\uda58\udfe5", "\u76a5\uca86\u989e\u8867\ubb2a\uae40\u6c31", "\udbf0\udf01\ud81b\udc1c\ud81f\ude74\ud821\udce1\ud8e4\uddfd\ud828\uddf1\uda82\udf3c\ud8b3\udfd9\uda94\uddcf\ud809\udf7b\ud899\udcaa\ud906\uddea\uda3d\udd3d\ud82d\udc3b\ufb12\ueb0e\udac9\udf49\udbd2\udf4d",
        53, 49899, -30222682, 4973882336067176885L, 83830L, true, true, (char) 10616, (char) 27405,
        Double.longBitsToDouble(0x3fec2f45d9d2115cL), Double.longBitsToDouble(0x3feb6b957642f18fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 10, "\udb2e\ude24\u064c\ud909\udffc\ud8af\udeea\ud840\udda6", "\uacb9", "\ud889\uded1\uda9c\udefd\udb16\udc5d\udabd\uddeb\ud8b3\ude72\u7fc6\udbf4\udf25\ud98d\udd09\ud93e\udf4d\ud8dd\udcd2\ud850\udda3\udbe8\udff3\uda18\udd0b\ud80b\udd84\ud821\udce1\ud8e4\uddfd\udbcd\udda9\udb6a\udf28",
        35, 45415, -1412246415, -3017658996465897195L, 87598L, true, true, (char) 28979, (char) 2805,
        Double.longBitsToDouble(0x3fa04cf36cde8770L), Double.longBitsToDouble(0x3fed17f191b54506L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 10, 0, 8, "\u008f", "\ud2ad\000", "",
        16, -268, -441892510, -4746497477788334317L, -80462L, false, true, (char) 49995, (char) 64101,
        Double.longBitsToDouble(0x3fd050b1c6670856L), Double.longBitsToDouble(0x3fce729ae09d1350L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 7, "\000", "", "",
        -5, -1000, 1628426496, -5231524721091591838L, -100000L, false, false, (char) 0, (char) 12684,
        Double.longBitsToDouble(0x3fac7589b3315330L), Double.longBitsToDouble(0x3fdd09001600004eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 3, "\udab7\udc2b", "\ua1ba\u66cc", "\udbf1\udd6a\ud8ba\udd71\ud902\udece\ud8d5\uddfa\ud904\udd43\ud802\udcd3",
        19, 10308, 355719224, 800766838893644037L, 52673L, true, true, (char) 43455, (char) 35982,
        Double.longBitsToDouble(0x3fe7013c0dcf0fa8L), Double.longBitsToDouble(0x3fe9f31f0efd7f1dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 4, 4, 2, "\udb2e\ude24\ud853\udc4b\udbe5\udf65\ud89d\udefd\udbc1\ude26\udb11\ude08\ud80a\udec5\ud888\udf39", "\u3f07\u3d9a\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u6c31\ube86\u18ff\ud063\u21ca\u8eaf\u4174\u62fc\u71e4\u9014\u1e69\u6707\u869b\u4484\u829c\u0904\u4df8\u4286\u9e08\u08f6\u8eea\uad6f\u91f4\u64aa\u7171\u0a72\u25d1\u7ad7\u6a13\ua981\uccf1\ud6fa\ud4a6\u76c7\u5292\u0206\u12e8\u9301\u898c\u7867\u3f4b\ua370\u4007\u8942\uad88\ubdc7\ua3f2\u42d8\uba52\ucbd7\u8e5c\uba7e\u1dc7\u9e14\u1a71\ua69a\ubc34\u67db\u24cc\u82c4", "\uda67\udea4\ud9af\udeac\udbc4\udf35\ud9e5\ude1f\uda8f\ude1d\uda3c\ude3f\u56f4\u91e9\ud984\ude5a\udb52\udf4a\ud9ec\udf02\udb25\udd6f\ud98c\udf5d\ud821\uddf7\udae6\udc9b\ud910\udfd2\ud99b\udd5f\ud83c\uddab\uda7f\udfd1\uda0a\udfec\uda89\udfca\ud870\udf66\udaa1\udf68\ud201\ud8e8\uddf6\uda50\udedc\uda0e\udfc6\ud8a1\udcdb\udb01\udec5\uda34\ude59\udb86\udd11\uda19\udc73\ud8c5\udc96\ud89d\udf1f\uda0d\udf7b\ud94c\udee8\ud992\udd95\ud8ff\udf34\ud95c\ude55\udab2\udd39\ud969\udfdf\ud889\udde1\uda7d\udc1d\ud83c\ude65\udbc7\udf7e\udb80\ude9b\ud8b6\udf35\uda0d\udfef\ud987\udeae\ud95a\udef6\uda13\ude8c\udbc0\ude86\udb1d\udf19\udb3f\uddc3\udb81\udd4c\ud974\udfab\udaa0\uddb8\udad9\udf49\udbbf\udc65\ud8b1\udc7a\ud9a0\udc43\ud9b8\udda0\ud8d5\udff5\ud9df\udf95\ud999\udfd8\uda09\udf46\ud8f8\udca7",
        -2, 55685, 240648156, 5382272723022586272L, 65147L, true, false, (char) 54758, (char) 27607,
        Double.longBitsToDouble(0x3fe1b58acdca5068L), Double.longBitsToDouble(0x3fec346434a83406L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 4, "\uda45\udedd", "\ud369\u6ddf\u56ee\u8878\u0090\u4807\u7ab0\uc79e\ubdde\u76a5\u688c\uc213\ub5e4\ub2aa\uae40\u6c31\ube86\u18ff\ud063\u3d0c\u3607\u773d\u0db4\u4629\u9dfd\u3321\u2da8\u2152\u4484\u8b9b\u5f3c\u6857\u4286\u4521\u5113\u0e78\u1525\u7828\u6287\u8327\u053c\u1ccb\u5cbd\ucabf\u6c28\u67ae\u2e65\u2f12", "\udb67\ude1e\ud96e\udd0f",
        28, 5181, 1250595395, 4187771293754735599L, -68684L, false, false, (char) 14470, (char) 4842,
        Double.longBitsToDouble(0x3fe40d8c34b008a4L), Double.longBitsToDouble(0x3fcc5db9f1328614L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 10, 10, 10, "\uda80\udc7f", "\u5257\uae3d\u06c0\u5b4b\ud7bb\uc142\u7a57\ua138\ubdde\u76a5\u65c7\uc213\u0c21\ub2aa\uae40\u3f3b\ube86\u18ff\uaeae", "\ud96d\udfb2\uda04\udccf\udaf6\udfcb\uda8b\udede\udba1\udf1b\ud908\ude67",
        53, 93185, 1520291880, 3827022063793502676L, -72319L, true, true, (char) 7506, (char) 21035,
        Double.longBitsToDouble(0x3fe104ca919db777L), Double.longBitsToDouble(0x3fc2c614a25d1a30L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 8, 7, 6, "\ud838\udd17\udb4f\udcdb\ud98a\udd07\ud89d\udefd\udaaf\udfca\ud957\uddfd\uec2a\uda9f\udc04\ud83d\udc0b\ud8f7\udf35\ud9e2\ude5f\ud91f\udf15\udad2\udcfb\udabc\udc72\ud8ad\uddf8", "\uae40\u6c31\u976a", "\udb6f\udc70\ud804\ude70\ud96e\udc63\ud998\udcd9\ud891\udc04\ud8a4\udcbb",
        48, 92236, 1076800767, 3044699910856813154L, 62260L, true, false, (char) 21391, (char) 9704,
        Double.longBitsToDouble(0x3febe0d17724c264L), Double.longBitsToDouble(0x3fe104ca819db777L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 8, 8, 4, "\uda6f\udf92", "\ud369\u6ddf", "\uda9f\udc04\ud83d\udc0b\ud8f7\udf35\ud8c0\uddcf\udbff\udd60\ud8ae\uddc8\ud901\udeb8\ud800\udf12\uda80\udda7\ud892\udd18\ud8f3\udfa5\ud92d\udce2\uda35\udf61\udaca\udd71\udb51\udfa8\ud988\udc4f\udabe\udfe0\ud95a\udf8e\uda06\udc11\udbf9\udef2\uda8b\udede\udbcf\udf2c\ud936\ude74\uda45\udda7\ud9b9\udced\udafe\ude0b\udb93\ude27\ud88f\udd4b\udbbb\udddb",
        21, 79944, -1033570436, 2616713582858939953L, -24798L, false, false, (char) 51821, (char) 13074,
        Double.longBitsToDouble(0x3fdf2b226d5f063aL), Double.longBitsToDouble(0x3fe2d7bd60c5e9b2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 3, 3, 2, "\udb2e\ude24\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\uda72\ude1a", "\uc79e\u5317\u76a5\u688c\u0cbf\u1959\uaa5e\uae40\u79d3\u2364\u074f\u8cc6\u21ca\u79a6\u0bc1\u37b7\uc6e4\u9014", "\udb1e\udea0",
        10, 47914, 898656586, 3154342542414002294L, 369L, false, true, (char) 15929, (char) 10670,
        Double.longBitsToDouble(0x3fc2025fde8bf8c8L), Double.longBitsToDouble(0x3fdb5450607b87beL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 7, 7, 4, "\udb2e\ude26\uda1e\uded2\uda26\udd6e\ud89d\udefd\udacb\ude2a\udb11\ude19\ud80a\udec5\ud927\udf68", "\uc79e\u1bd4\uc2ff\u6386\u0cbf\u1959\uaa5e\uae40\u79d3\u2364\u074f\u8cc6\u21ca\u09f3\u416c\u1739\uc6e4\u9014", "\udb1e\udea0",
        -3, 57190, 562998946, 3170021960478177398L, 369L, false, true, (char) 15929, (char) 27821,
        Double.longBitsToDouble(0x3fc202453e8bf8c8L), Double.longBitsToDouble(0x3fe5aa28303d803dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 5, 5, 4, "\udab7\udc2b", "\ua178\u66cc\ua5d3\ub342\u4abd\u678c", "\ud9b9\udd59",
        9, 41334, -351064692, 1527802433824941363L, -49619L, true, true, (char) 36016, (char) 26902,
        Double.longBitsToDouble(0x3fd5f25d328e644cL), Double.longBitsToDouble(0x3fe05cf446e02781L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 4, "\udb2e\ude24", "\ud369\u66cc\ua9f9\u88ed\uacb9\u85ef\u622a\uc79e\u5317\u76a5\u75cf\uba4d\u1959\ua90a\uae40\ua62e\ube86\u18ff\ud063", "\ud821\udce1",
        30, 42601, -1919805516, 1443498974400234735L, -37936L, false, false, (char) 25491, (char) 44900,
        Double.longBitsToDouble(0x3fb170f3c803a3e8L), Double.longBitsToDouble(0x3fef7d63ff7c1a2eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawHorizontalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawVerticalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|equals|java.lang.Object|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|getErrorIndicatorPaint||new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|getErrorIndicatorStroke||new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|readObject|java.io.ObjectInputStream|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|setErrorIndicatorPaint|java.awt.Paint|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|setErrorIndicatorStroke|java.awt.Stroke|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|writeObject|java.io.ObjectOutputStream|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "C|org.jfree.chart.renderer.category.StatisticalBarRenderer|<init>|",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawHorizontalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawVerticalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
