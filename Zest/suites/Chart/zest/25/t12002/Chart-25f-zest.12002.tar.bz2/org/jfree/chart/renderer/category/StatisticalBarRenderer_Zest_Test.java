package org.jfree.chart.renderer.category;
import org.junit.Test;
import static org.junit.Assert.*;
public class StatisticalBarRenderer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udaab\udfa0\uda94\udf4d", "\u4812\ucde3\u7aaa\ub0d6\ucd4b\u6f23\u5006\u2471\u2666\u2b22\u1e99\u2225\u076a\u62fb\u9415\u2b4b", "\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d",
        4, 71440, 768576777, 633349731631120006L, 90888L, false, false, (char) 37016, (char) 37149,
        Double.longBitsToDouble(0x3fee3a5cccbe6205L), Double.longBitsToDouble(0x3fe187ef83c2de22L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udaab\udfa0\uda94\udf4d", "\u4812\ucde3\u7aaa\ub0d6\ucd4b\u6f23\u5006\u2471\u2666\u2b22\u1e99\u2225\u8e69\u62fb\u9415\u2b4b", "\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d",
        4, 71440, 768576777, 633349731631120006L, 90888L, false, false, (char) 37016, (char) 37149,
        Double.longBitsToDouble(0x3fee3a5cccbe6205L), Double.longBitsToDouble(0x3fe0fda7837369eaL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 6, 11, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\u267c\ud95d\udd6d\udae0\udf7c\udb6e\udfc3", "\ucde3\u7aaa\ub0d6\ucd4b\u6f23\u5006\u2471\u2666", "\ud80e\udc3b\ud87a\uded4\ud987\ude67\udae3\uded8\udb27\ude12\ud808\udeba\ud9f2\udc82\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d\ud816\ude77\udaba\udd88\ud84b\udfbc\uda51\udcbe\udab6\udd99",
        59, 96448, -336822714, -4329748508558373580L, 53787L, true, true, (char) 16554, (char) 32115,
        Double.longBitsToDouble(0x3fc09e60ef523420L), Double.longBitsToDouble(0x3fd80ac24d2f6ff0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2\udb56\udce4\udafa\ude51\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udbfa\udc08\uda94\udf4d\udb6d\ude0b\udb2b\udfd7\ud925\ude5b\udb01\ude76\ud92b\udd84\ud84e\udfd2", "\u5006\u2471\u2666\u2b22\u1e99\u2225\u076a", "\udb27\ude12\ud808\udeba",
        37, 70337, -303653490, -519445526034889873L, 92988L, false, true, (char) 938, (char) 63537,
        Double.longBitsToDouble(0x3fad16e7e8608ca0L), Double.longBitsToDouble(0x3fe42d63b658f9c7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 4, "\udba9\udee2\ud9f9\udc1f\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udaab\udfa0\ud942\udfa7", "\u39ce\u221b\u5cad\u20c2\ucd4b\u6f23\u5006\u2471\u2666\u2b22\u1e99\u2225\u076a\u62fb\u9415\u2b4b\u2260\u75d7", "\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d\ud816\ude77\udaba\udd88\ud84b\udfbc",
        -4, 39110, -104349051, -6847417191564018106L, 44076L, true, true, (char) 57027, (char) 48160,
        Double.longBitsToDouble(0x3fee16f1122bc76fL), Double.longBitsToDouble(0x3fc8b6f2f7b1ed2cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\udad2\uddbf\udb8f\ude8f\udbf7\udc53\ud971\udfad", "\uc806\u7dc0\u5ba1\u4812\ucde3\u7aaa\ub0d6\ucd4b\u6f23", "\ud9f9\udc02\udb96\uddf9",
        13, 99476, -1600069517, 6946697668656414688L, 4924L, false, false, (char) 21443, (char) 51061,
        Double.longBitsToDouble(0x3fe8676f336ff884L), Double.longBitsToDouble(0x3fb2f521b125aa30L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2\udb12\udef5", "\u279f\u60a7\u28ea\ua487", "\uda94\udf4d\udb6d\ude0b\udb2b\udfd7\ud925\ude5b\udb01\ude76\ud92b\udd84\udaf1\udfce\ud95f\ude6e\udb7b\ude15",
        36, 59714, -321917660, -621939453138186340L, -50880L, true, false, (char) 14606, (char) 18588,
        Double.longBitsToDouble(0x3fe58b08958e29e8L), Double.longBitsToDouble(0x3fe8676f337ff8caL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 7, 2, 4, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8bd\udc6a\uda9a\udecb\uda32\ude35\udb06\udf23\ud971\udfad\udaa5\udec9\udaab\udfa0\uda94\udf4d\ud88a\ude59\udb2b\udfe2\ud925\ude5b\udb01\ude76\ud92b\udd84\ud84b\uded2\ud97f\udec7\udb7b\ude15\ud8b6\ude0e\udb6a\udee4\ud9f9\udc02\udb17\udcda\ud909\udcc6\ud80e\udc3b\ud87a\uded4\ud987\ude67\udae3\uded8\udb27\ude12", "\u3bc3\u7d87\u4b80\ucfe7\u27a9\u3bde", "\ud855\ude65\uda51\udcbe\udab6\udd99\ud876\ude27\ud952\udcbe",
        1, 82868, 1268370740, -2650426577548968770L, -92770L, true, false, (char) 50997, (char) 64989,
        Double.longBitsToDouble(0x3fc195b79fd58b3cL), Double.longBitsToDouble(0x3fe7302707b5f321L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 4, "\udba9\uddb8\ud82c\uddf4\udae1\udd69\ud8f0\udd6a\uda5d\ude15\ud836\udec9\udbf6\udfa9\ud971\udfad\udaa5\udec9\udaab\udfa0\uda94\udf4d", "\u4812\ucde3\u7aaa\ub1ac\ucd4b\u6f23\u5006\u2471\u2666\u3967\u1d88\u2160\u076a\u62fb\ub965\u15d1", "\ud8ef\udd29\udbc5\udc7c\udb99\ude66\ud8df\udc1a\uda9d\udfe3\udbd8\ude2d",
        4, 71440, 768576777, 633349731636821638L, 90888L, false, false, (char) 37016, (char) 37149,
        Double.longBitsToDouble(0x3fee3a5cccbe6205L), Double.longBitsToDouble(0x3fe187ef83c2de22L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 10, 11, 4, "\ud972\udf87\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda53\uded0\udb8f\ude8f", "\u6503", "\udb22\udf89\u6fb2",
        55, 76694, 414394225, -6332705032355986416L, -45764L, false, true, (char) 8252, (char) 23085,
        Double.longBitsToDouble(0x3fece6cc86d4cfe5L), Double.longBitsToDouble(0x3fbce40317e50500L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2", "\u61d7\u279f\u60a7\u28ea\ua487\u6503\u5975\uc806\u7dc0\u5ba1\u4812\ucde3", "\uda07\udf8b",
        23, 4608, 2102616554, 6966820339267580161L, 96908L, true, false, (char) 16729, (char) 8263,
        Double.longBitsToDouble(0x3fc76ec998934ba4L), Double.longBitsToDouble(0x3fe6526e92b16112L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 10, 3, 4, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udbd9\udf87\uda94\udf4d", "\u4812\ucde3\u7aaa\ub0d6\ucd4b\u6f23\u5006\u2471\u2666\u2b22\u1e99\u2225\u076a\u62fb\u9415\u2b4b", "\u8880\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d",
        4, 71440, 768576777, 633349731631120006L, 90888L, false, false, (char) 37016, (char) 37149,
        Double.longBitsToDouble(0x3fee3a5cccbe6205L), Double.longBitsToDouble(0x3fe187ef821cde22L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2\ud9f2\udd72\udae1\udd69\udada\udd4a\uda94\udc72", "\u7ee6\u60dc\u5975\uc806\u6997\u01f5\u4812\ucde3\u7aaa\ub0d6\ucd4b\u6f23\u2e8b\u736a\u6a9d\uc22d\u64d4\u7194\u463c\u630a\u64df", "\ud991\udeb2",
        25, 52510, -120942836, -2127255456626329427L, 6400L, false, true, (char) 63537, (char) 18953,
        Double.longBitsToDouble(0x3fe430407a85ac76L), Double.longBitsToDouble(0x3fe2c7ce3e46a0f9L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\uda04\udde1\ud9e2\udefb\udae1\udd69\udbb9\udf4e\ud9da\udf10", "\ua487", "\uda94\udf4d\udb6d\ude0b\udb2b\udfd7\ud925\ude5b\udb01\ude76\ud92b\udd84\ud84e\udfd2\ud97f\udec7\udb7b\ude15",
        36, 49138, -321917660, -621939453138186340L, 4924L, false, false, (char) 5059, (char) 11092,
        Double.longBitsToDouble(0x3fe8676f336ff8caL), Double.longBitsToDouble(0x3fb2f521b220aa30L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 3, 2, 4, "\ud931\udc26\ud8b6\ude61\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f", "\u6503", "\udb6d\ude0b\udb2b\udfd7",
        15, 48802, -399972628, -6332719685595918855L, -81348L, false, true, (char) 8252, (char) 23085,
        Double.longBitsToDouble(0x3fece7baf6d4cfe5L), Double.longBitsToDouble(0x3fbce40305cd0500L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 4, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udab5\ude45\uda95\udc03", "\u4812\ucde3\u7aaa\ub0d6\ucd19\ud71c\u37f8\u2471\u2666\u2b22\u1e99\u2225\u076a\u62fb\u9415\u2b4b", "\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d",
        4, 71440, 757928717, 633349733979930246L, 90888L, false, false, (char) 37016, (char) 62142,
        Double.longBitsToDouble(0x3fe2686cccbe6205L), Double.longBitsToDouble(0x3fe187ef8333301dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "", "", "\000\u1002\udbf7\udc53",
        9, -971, 134217728, -4816081665208085512L, -100000L, false, false, (char) 0, (char) 59392,
        Double.longBitsToDouble(0x3fdf9a81d2db0bdcL), Double.longBitsToDouble(0x3fcb89e23f8a3230L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 8, 10, 4, "\udba9\udee2\ud802\ude63\ud84f\udcc0\ud8f0\udd6a\ud86b\udcfb\ud940\uddc7\u0eb8\udacc\udffa\ud86d\udd0e\udaab\udfa0\uda94\udf4d", "\u4812\ucde3\u7de4\ua3f6\ucd4b\u5be0\u0218\ucedf\u268c\u609f\u1e99\u2225\u076a\u25e7\u61da\u2b4b", "\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d",
        4, 71440, 449154313, 633349834710335110L, 54452L, false, true, (char) 48992, (char) 57027,
        Double.longBitsToDouble(0x3fe187ef83c2de22L), Double.longBitsToDouble(0x3fd111d40f013626L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 4, 2, 4, "\udb99\uddab\udb43\udfe1", "\000\000\000\000", "\uda94\udf0f",
        7, 85067, -451133455, 4569775632663766764L, -5273L, true, false, (char) 18652, (char) 7278,
        Double.longBitsToDouble(0x3fd243318abbd99eL), Double.longBitsToDouble(0x3fece7baf6d4cfe5L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\udba9\udee2\ud9e2\udefb\uc8a4\udbac\udeed\udafd\ude0d\udb8f\udf05\udbf7\udc53\ud971\udfad\uda10\udd3f\uda92\udf85\uda94\udf4d", "\u4812\ucde3\u7aaa\ub0d6\u4956\ub893\u501a\u2471\u2666\u2b22\u1e99\u2225\u076a\u62fb\u9415\u2b4b\u2260\u75d7\u045d\u681a\u6f96\ucfe7\ub3ba\u6f5e\u47da\u2a3a\u7b54\ub6a4\u6383\ubb25\u7db7\u867a\u9d74", "\udba1\udc9e\ud833\udc31\ud8e2\udeb6\u97fc\uda76\udee0\ud9ba\udd16\uda30\udd68\ud93e\udf53\udb92\ude33\ud920\udf5f\ud992\udd25\ud864\ude08\uab8d\ud97c\udd9b\ud8de\udc59\ud91c\udf37\udb5c\udf09\ud999\uddb8\uda8e\udcdf\udb48\udc0f\uda2f\udecd\ud863\ude84",
        56, 51470, 815575934, 3204815445542341516L, 32262L, false, false, (char) 62072, (char) 40605,
        Double.longBitsToDouble(0x3fd33f946cf7411cL), Double.longBitsToDouble(0x3fe89d13c780214cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 4, 6, 6, "\udba9\udee2\ud9e2\udefb\udabf\ude69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\u267c\ud95d\udd6d\udae0\udf7c\udb6e\udfc3", "\ucde3\u7aaa\u029e\u226e\ucbf2\u5006\u2471\u2666", "\ud80e\udc3b\ud87a\uded4\udb09\udf9a\udb75\udcd4\udb27\ude12\ud808\udeba\ud9f2\udc82\ud8ef\udd29\udbc5\udc7c\udb84\udd9c\ud85f\udfb7\ud9c2\ude35\udbf9\udc57\ud816\ude77\udaba\udd88\ud838\udd9b\uda51\udcbe\udab6\udd99",
        59, 96448, -336822714, -4329748508927472332L, -65054L, true, false, (char) 37039, (char) 3486,
        Double.longBitsToDouble(0x3fc652f164c58994L), Double.longBitsToDouble(0x3fd6258171db3068L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 8, 7, 11, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\uda5f\udf36\ud9ab\uddb6\udb69\udf3c\udb62\udde8\ud816\udd39", "\ucde3\u7aaa\ub0d6\ucd4b\u3394\u4fdb\u2471\u2666", "\ud80e\udc3b\ud87a\uded4\ud987\ude67\udae3\uded8\udb27\ude12\ud808\udeba\ud9f2\udc82\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d\ud816\ude77\udaba\udd88\ud84b\udfbc\udb5c\udcc4\udab6\udd99",
        59, 96448, -336822714, -4329748508558373580L, 53787L, true, true, (char) 16554, (char) 32115,
        Double.longBitsToDouble(0x3fc09e60ef523420L), Double.longBitsToDouble(0x3fd80ac24d2f6ff0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 6, 11, "\udba9\udee2\uda81\uddbf\udbfa\ude46\ud9ea\ude7b\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\u267c\ud95d\udd6d\udae0\udf7c\udb6e\udfc3", "\ucde3\ua010\ub0d6\ucd4b\u6f23\u5006\u2471\u2666\u2b22\u1e99\u2225\u076a\u62fb\u9415\u2b4b\u2260\u75d7\u045d\u681a", "\uda9d\udfe3\udbd8\ude2d\udab5\udfa6",
        4, 66897, 147473466, -6019555106791898491L, 44076L, false, false, (char) 23202, (char) 8800,
        Double.longBitsToDouble(0x3fde5a6c51773970L), Double.longBitsToDouble(0x3fc09e60f45f4a94L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 6, 11, "\udba9\udee2", "\u74eb\u279f\u60a7\u28ea\ua487\u4ee9\u317a\u1811\u8378\u5ba1\u5d9e\ucde3", "\u8df9",
        27, 13636, 857247714, -1382625821849653923L, 96908L, true, false, (char) 16729, (char) 8263,
        Double.longBitsToDouble(0x3fc76ec998934ba4L), Double.longBitsToDouble(0x3fe6526e92b16112L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 10, 3, 4, "\udba9\udee2\ud9e2\udefb\udb90\udd2b\ud8f0\udd6a\uda89\udecb\uda3a\udf76\udbf1\udeac\ud971\udfad\udaa8\uddaa\ud970\udfd0\udbeb\udcc0\udb6e\udfc3", "\ucde3\u7aaa\u72db\ucd4b\u24ef\u5006\u2471\u1711", "\udb95\udd0a\ud93a\udd9e\udbb5\udc06\udaba\udc46\udb27\ude12\ud808\udeba\ud9f2\udc82\uda0d\ude1f\uda8e\udd0c\ud9c3\ude5f\ud930\udf08\ud91a\udd30\udbd8\ude2d\ud816\ude77\uda75\udf47\ud8ec\ude73\ud993\udc9b\ud86e\ude41",
        59, 96514, -349063098, -4329748506863874764L, 28778L, false, false, (char) 35744, (char) 51371,
        Double.longBitsToDouble(0x3fdb4d72c7a91a10L), Double.longBitsToDouble(0x3fd80ac24d2f6ff0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 11, "\udba9\udee2\ud8b5\udd47\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\ud90d\ude1e\ud95d\udd6d\udae0\udf7c\udb6e\udfc3", "\ucde3\u7aaa\u38ae\ub264\u46d9\u5006\u2471\u2666", "\ud80e\udc3b\ud87a\uded4\ud987\ude67\udae3\uded8\udb27\ude12\ud808\udeba\ud9f2\udc82\ud8ef\udd29\udbc5\udc7c\ud9b7\udff6\ud849\udca8\uda9d\udfe3\udbd8\ude2d\ud996\udf81\ud956\udfcd\ud872\udf3d\udb2e\udee0\udbc7\udf7d",
        23, 19099, -336822714, -4329748508558373580L, 53787L, true, true, (char) 16554, (char) 53048,
        Double.longBitsToDouble(0x3fc09e732f523420L), Double.longBitsToDouble(0x3fa38a927c36e990L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 6, 0, "", "\uac04", "\ue964",
        4, 77844, 3418880, 3841933633393334127L, -80373L, true, false, (char) 77, (char) 9815,
        Double.longBitsToDouble(0x3fd000000bf3503aL), Double.longBitsToDouble(0x3fd6d85ee1b89e22L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 7, 0, 0, "", "\uac04", "b",
        -5, -1000, 3418880, 313532612608L, -80373L, true, false, (char) 6842, (char) 9815,
        Double.longBitsToDouble(0x3fd00e828bf3503aL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 4, "\udba9\udee2\udb56\udce4\udafa\ude51\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udbfa\udc08\uda94\udf4d\udb6d\ude0b\udb2b\udfd7\ud925\ude5b\ud986\udf6d\ud977\ude00\ud84e\udfd2", "\u5006\u2471\u2666\u2b22\u1e99\u2225\u076a", "\udb27\ude12\ud808\udeba",
        37, 70337, -303653490, -519445526034889873L, 92988L, false, true, (char) 938, (char) 63537,
        Double.longBitsToDouble(0x3fad16e7e8608ca0L), Double.longBitsToDouble(0x3fe42d63b658f9c7L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 0, "\uda47\udea6\ud90a\udd3a\udae1\udd58\ud8f0\udd6a\uda89\udecb\udb8f\udf0d\udbf7\udc53\ud971\udfad\udaca\uddc9\udaab\udfa0\ud949\udc00\ud8db\ude2b\udaef\udc54\ud97b\udc29\ud94b\udd66\uda87\udc20\ud992\udf7e\ud8f4\udf81\udb7b\ude9c\ud8b6\uddd7\udb6a\udee4\ud9f9\udc02\udb17\udcda\uda6f\ude95\ud8eb\udc55\ud882\udcef\ud992\udf40\udae3\uded8\udb27\ude12\ud808\udeba\ud9f2\udc82\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d\ud816\ude77\udaba\udd88\ud8b0\udc4f", "\ubb25\u7db7\u867a", "\udb2c\udd8d\udba7\udd9e\ud833\udce5\uda8e\udc6c\ud87a\udc9f\ud818\udcd4\uda3f\ude25\ud85b\udf9f\ud827\udffb\ud935\ude8e\ud9d2\udf5e\uc02f\ud84e\udeaa\u3e1b\ud9ab\ude07\ud996\udf24\ud969\udea3\uda9b\udd15\ud978\udf43\ud974\ude63\ud86f\udeab\udbb5\udfd1\ud8c5\udfbd\udb28\udc17\ud825\udc8a\ud8aa\udd58\ud8fd\udd4d\u5408\udbdf\udc75\ud8ca\udd0e\udb96\udcc5\udbeb\udf45\udbea\udd17\ucbb8\udaa3\udcca\ud919\udc47\ud97c\udd3e",
        -1, 40561, -450837804, -5982135816620483951L, -59898L, true, false, (char) 48282, (char) 34326,
        Double.longBitsToDouble(0x3fcc6bacc8db765cL), Double.longBitsToDouble(0x3fbf636add65da80L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 0, "\udbba\ude1a\udad5\udc58\udb11\udea2", "\u60a7\u28ea\ua487\u6503\u5975\u869f\u2ea4\ua036\ua2ef\u2f42\u4740\uc9ed\ucd4b\u66b9\u5006\u2471\uad6d\u2b22\uc964\u3985\u1e9a\u03c2\u9835\u2b4b\u2260\u7fd4\ubc21\u4d88\ud6e2\ucfe7\ub3ba\u6f5e\u47da", "\ud91b\udfbb\udab3\ude1b\uda2f\ude83\ud96a\udd65\udb83\udd95\ud9d4\udd21\ud9bc\udf78\udb2c\udd8d",
        16, 76568, -948968510, -5217461762998407995L, 24385L, true, true, (char) 32921, (char) 56643,
        Double.longBitsToDouble(0x3fd514cfef066176L), Double.longBitsToDouble(0x3fc46a44b4b7fc10L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 5, 3, 0, "\udba9\udee2\ud9f9\udc1f\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud964\udd59\udaa5\udf16\udaab\udfa0\ud942\udfa7", "\u2efb\ud59e\u19ba\u20c2\ucd4b\u6f23\u8d7e\u204e\u2666\u2b22\u1e99\ub292\u89f7", "\udb27\ude12\ud808\udeba",
        37, 70393, -303690142, -519444611206855825L, 92988L, false, true, (char) 938, (char) 63537,
        Double.longBitsToDouble(0x3feb84f4a68608caL), Double.longBitsToDouble(0x3fe42d63b658f9c7L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=new org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 10, 10, 9, "\udacb\udcd4\ud9f8\udff2\u9105\udb98\udfa4\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud9d4\ude9e\udaa5\udd59\udae9\udf9f\u5bb2", "\uc26a\u22a4\uc58d\u39b5\ucd4b\u6f23\u5006\u29be", "\ud940\ude41\ud9a7\udc26",
        20, 37001, -193413041, -3248818561101961692L, 93394L, false, true, (char) 29382, (char) 59860,
        Double.longBitsToDouble(0x3fec1ea432f79b11L), Double.longBitsToDouble(0x3fe0634a5908fe18L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=null |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 7, 4, 7, "\udba9\udee2\ud9f9\udc1f\ud9e0\udf0a\ud8f0\ude08\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udaab\udfa0\ud942\udfa7", "\u39ce\u221b\u5cad\u20c2\ucd4b\u6f23\u5006\u2471\u2666\u2b22\u1e99\u2225\u076a\u62fb\u9415\u2b4b\u2260\u5cb5", "\ud924\ude3d\uc8fc\udb1c\udc26\udb55\udc38\ud816\ude77\udaba\udd88\ud84b\udfbc",
        -4, 39110, -104349051, -6847417191564018106L, 44076L, true, true, (char) 57027, (char) 48160,
        Double.longBitsToDouble(0x3fee16f1122bc76fL), Double.longBitsToDouble(0x3fc8b6f2f7b1ed2cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 4, 3, 0, "\udba9\udee2\udbe3\udd2b\udaef\udf3a\ud8f0\udd6a\udb15\udd33\udb6f\udd9d\ud80d\udc4f\ud9f2\udc5f", "\uc806\u7dc0\u5ba1\uc035\ucde3\u2426\ub0d6\ucd4b\u6f23", "\udbb0\udd9e\udb17\udd42\ud909\udcc6\ud80e\udc3b\ud87a\uded4",
        49, 90344, -756424517, 5607656791456545482L, -9262L, false, false, (char) 64124, (char) 5338,
        Double.longBitsToDouble(0x3fddf5421eff00d2L), Double.longBitsToDouble(0x3fd275371ecbc9acL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 0, "", "", "\uda89\udecb",
        13, 39979, 0, 4492903578255491072L, 91496L, true, false, (char) 44817, (char) 65494,
        Double.longBitsToDouble(0x3fe761fb5900e828L), Double.longBitsToDouble(0x3fc8f503a5b617b8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 8, 8, 0, "\uda51\uddb6\udb1c\udff2\ud8e7\udca7\u753d\000\ud9eb\udc36\udb23\udcd8\udb37\udfa5\ud8b7\udca3\uda03\udeca\ud85a\udc99\ud8bc\udcf9\ud837\udffc", "\u8972\u1165\ucc64", "\uda28\udf84\ud989\udf2d\ud870\udd95\udb35\udf8c\udb88\udc47\ud9b1\udf8b\ub474",
        28, 54237, 1296766541, 2006121565821606812L, -31293L, true, true, (char) 2748, (char) 25767,
        Double.longBitsToDouble(0x3fe1944407bbb1d7L), Double.longBitsToDouble(0x3fd7eda169eed94eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 5, 5, 5, "\udba9\udee2\udb56\udce4\udb86\udc55\uda06\ude65\ud819\uddd2\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udbfa\udc08\uda94\udf4d\udb6d\ude0b\udb2b\udfd7\ud925\ude5b\ud83f\udeca\udbd1\udd43", "\u6f23", "\ud9f9\udc02\udb17\udcda\ud9ed\udc72",
        51, 72483, 1617404089, 2759791641932739550L, 95274L, false, true, (char) 44786, (char) 44274,
        Double.longBitsToDouble(0x3feb7fc6544bd486L), Double.longBitsToDouble(0x3fe125a9e0a08889L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 7, 7, 11, "\udba9\udee2\ud989\uddb8\ud9af\ude1a\udb94\udcc7\uda89\udecb\udb14\udcff\udbf7\udc53\ud971\udfad\udaa5\udec9\uda9f\udfa0\ud942\udfa7", "\ub2f9\u226e\u5cad\u20c2\ucd4b\u6f23\u5006\u2471\u2666\u7ba4\u1e99\u2225\u076a\u62fb\u9415\ubb69\u216d\u5c1a", "\ud924\ude3d\udac4\udd05\udb16\udc23\udb55\udc38\ud816\ude77\udaba\udd88\ud84b\udfbc",
        -4, 39110, -1709027707, -6847417191564018018L, 44076L, true, true, (char) 57027, (char) 48160,
        Double.longBitsToDouble(0x3fee16f1122bc76fL), Double.longBitsToDouble(0x3fc8b6f2f7b1ed2cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 2, 3, 3, 3, "\udba9\udee2\ud9c4\uddcb\uda47\ude37\ud8f0\udd7d\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud93b\udcf7\ud8ef\udcf9\udb58\udc48\ud942\udfa7", "\u39ce\u221b\u5cad\u20c2\ucd4b\u17b8\uca78\ua2ec\ucdcc\u2b22\u1e78\u20aa\uba7a\u6029\u6b65\u2b4b\u1a81\u5cce", "\ud988\udfef\ud997\ude9b\udafb\udc7b\udb55\udc38\udbc3\udc78\ud8f7\uddbb\ud84c\udc4e",
        31, 43390, 784843397, 5160867921263879494L, -13524L, false, true, (char) 57027, (char) 15649,
        Double.longBitsToDouble(0x3fdbaa9e054f3e86L), Double.longBitsToDouble(0x3fbe2de5ef63da58L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 7, 2, 4, "\udba9\udee2\ud9e2\udefb\udae1\udd69\ud8f0\udd6a\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\udaa5\udec9\udaab\udfa0\uda94\udf4d", "\u4812\ucde3\u7aaa\ub0d6\ucd4b\u9a3c\u500e\u2471\u2666\ub143\u1e99\u2225\u076a\u62fb\u4a4e\u4d90", "\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d",
        4, 71440, 768576777, 633349731631120006L, 90888L, false, false, (char) 37016, (char) 37149,
        Double.longBitsToDouble(0x3fee3a5cccbe6205L), Double.longBitsToDouble(0x3fe187ef83c2de22L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.renderer.category.StatisticalBarRenderer:@?\012",
        Z.run(T, 1, 7, 1, 1, "\udba9\udee2\ud9e2\udefb\udba8\udf0d\ud8f0\udc30\uda89\udecb\udb8f\ude8f\udbf7\udc53\ud971\udfad\u267c\ud95d\udd6d\udae0\udf7c\udb6e\udfc3", "\ucde3\u7aaa\ub0d6\u3339\u6f23\u5006\u2471\u2666", "\ud80e\udc3b\ud87a\uded4\ud987\ude67\udae3\uded8\udb27\ude12\ud808\udeba\ud9f2\udc82\ud8ef\udd29\udbc5\udc7c\ud8cb\ude9f\ud832\udcdf\uda9d\udfe3\udbd8\ude2d\ud816\ude77\udb9e\uddfb\ud84b\udfbc\uda51\udcbe\udaef\uddd4",
        -4, 96448, -336822714, -4329748506853126860L, -23549L, false, true, (char) 29604, (char) 8203,
        Double.longBitsToDouble(0x3fe1a1a84d74227bL), Double.longBitsToDouble(0x3fe5e39ead5e1fe1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawHorizontalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawVerticalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.category.CategoryDataset,int,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|equals|java.lang.Object|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|getErrorIndicatorPaint||new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|getErrorIndicatorStroke||new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|readObject|java.io.ObjectInputStream|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|setErrorIndicatorPaint|java.awt.Paint|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|setErrorIndicatorStroke|java.awt.Stroke|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|writeObject|java.io.ObjectOutputStream|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "C|org.jfree.chart.renderer.category.StatisticalBarRenderer|<init>|",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawHorizontalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
    "M|org.jfree.chart.renderer.category.StatisticalBarRenderer|drawVerticalItem|java.awt.Graphics2D,org.jfree.chart.renderer.category.CategoryItemRendererState,java.awt.geom.Rectangle2D,org.jfree.chart.plot.CategoryPlot,org.jfree.chart.axis.CategoryAxis,org.jfree.chart.axis.ValueAxis,org.jfree.data.statistics.StatisticalCategoryDataset,int,int|new:org.jfree.chart.renderer.category.StatisticalBarRenderer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
