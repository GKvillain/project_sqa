package org.jfree.data.general;
import org.junit.Test;
import static org.junit.Assert.*;
public class DatasetUtilities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 19, 8, "\udba0\udc6e\udb4e\udc82", "\uc844\u4450\u4c5f\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\ud92f\ude0d",
        -3, 44751, -87639800, -6270966281982149473L, -25543L, true, true, (char) 33057, (char) 54947,
        Double.longBitsToDouble(0x3fe3ff9e6a4452c2L), Double.longBitsToDouble(0x3fcb9b56ad900a74L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 16, "\ud8c8\udfa1\udb4e\udc82", "\u84e8\uba7d\u4c5f\u5f77\u71ae", "\ud935\udf15\udabb\udf41\ud92f\ude0d",
        -3, 88303, -1469569911, 7246328505565215903L, -90665L, true, true, (char) 45824, (char) 3986,
        Double.longBitsToDouble(0x3fe1a1bbeda2165fL), Double.longBitsToDouble(0x3fe1aa12e6a152c2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 19, 8, "\udbf9\udf3a\udb23\udffe", "\uc844\u4450", "\ud808\udf89",
        51, 18384, -913321460, 9016872844342525016L, 98064L, false, true, (char) 2111, (char) 61544,
        Double.longBitsToDouble(0x3fbccf3c4a4bb848L), Double.longBitsToDouble(0x3fe06f62bde1ce5eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 11, 8, "\udba0\udc6e\ud9fc\udeda", "\uc844\u4450\u4c5f", "\ud838\udc66\ud9ef\ude38\ud935\udf15\udaa0\udc41\udba5\ude3b\uda26\ude3c\ud853\udc6c\ud892\udcb9\ud91b\udc0e\u600c\udb53\udf76\ud9ac\udc20\ud8ae\ude20\ub8e5\ud93a\udd3d\udbb5\ude63\uda2c\ude6a\uda99\udc8e\u9a1e\ud92d\udf10\udbee\udde4\uda18\udf5f\ud98c\udc11\ud9c6\udd03\udabc\udc98",
        10, 27931, -1750059436, 6333987958648474060L, -75000L, true, false, (char) 28895, (char) 14328,
        Double.longBitsToDouble(0x3fddce78b846e66cL), Double.longBitsToDouble(0x3fd047e7e7bf7a06L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 19, 8, "\ud8ee\udcf4\udb7b\udd34", "\ub4d2\u1158\u7294\u1de3\u3621", "\ud841\udccd\ud9a2\udc09\ud92f\ude0d",
        17, 35042, -87639586, -6270966284046009185L, -30693L, false, false, (char) 39857, (char) 60950,
        Double.longBitsToDouble(0x3fec68e4a0c9a86fL), Double.longBitsToDouble(0x3fa3f0d6c6469260L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 20, 18, "\ud87d\udfca\udba1\ude3c", "\u0e3d\u4450\u74b4\u5f77", "\ud9ef\ude38\ud9d7\udc65\uda35\udc84\ud885\udfe4",
        46, 41653, 2033974191, -6302141523841499457L, -44754L, false, true, (char) 2030, (char) 60950,
        Double.longBitsToDouble(0x3fe46b7ca0c983a7L), Double.longBitsToDouble(0x3fe15f0d6b6bec59L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 5, 8, "\udba0\udc6e\udb4e\udc82", "\uc844\u4450\u4c5f\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\ud92f\ude0d",
        -3, 66105, -87651064, -6270966281982149473L, -11095L, true, true, (char) 36159, (char) 39842,
        Double.longBitsToDouble(0x3fec6b7ca0c9a86fL), Double.longBitsToDouble(0x3fd27e1ad6d7e84cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 19, 8, "\udba0\udc6e\ud6f7", "\uc844\uc3dd\000", "\ud847\udf8f",
        7, 66078, 1791173111, 2867372072168360472L, -16296L, false, true, (char) 9625, (char) 25715,
        Double.longBitsToDouble(0x3fd497709c1bd8aeL), Double.longBitsToDouble(0x3fde1ce5e55400d8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 14, 17, "\udb92\udfe8\u2835", "\u7680\u43b7\u94ab\u9bf3\u96b0\u36c6\u5525\u56e2\u02ab\u2261\u5680\ud40b", "\ud8d1\udc4a\ud89d\udedc\udb2c\udfec\udb52\udd4e\ub8b3\ud92e\udd37\udbb5\ude63\uda15\udeff\ud8d3\udc74\ud887\udeb0\ud92d\udf10\udbee\udde4",
        31, 93693, 146921692, -2287857158062942586L, 5449L, true, false, (char) 3654, (char) 59775,
        Double.longBitsToDouble(0x3fd195a9af9e1554L), Double.longBitsToDouble(0x3fe4357e13bb5bd1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 19, 8, "\ud932\udc66\udbd8\udce0", "\ua03f\u2c6a\u4c5f\u5f77\u71ae\uc298\ud39b\u2745\u0880\u8ade\u520f\u4b5b\u0ad7\ub63e\u70b0\u7f9c\ud1fc\uba3a\u89a3\u76e8\u47fc\ud4b2\u171c\u096a\u5eb5\u2428\u2895\u9e11\u480b\u3d71\u3119\u6be3\u8574\u72ba\u3b2c\uad53\u9c49\ubd6b", "\ud9de\ude6c\udaec\udf7f\uda99\udd96",
        20, 30832, 758341389, -8433432043057443768L, 3275L, false, true, (char) 20471, (char) 32185,
        Double.longBitsToDouble(0x3fddd91e93fe8c60L), Double.longBitsToDouble(0x3fcb715cf754ed60L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 19, 20, "", "\u8edf\ub316\uc844\u4450", "\ud808\udf89",
        51, 83232, -116385922, 7693029933887189941L, -91873L, false, true, (char) 2091, (char) 9466,
        Double.longBitsToDouble(0x3fbccf000a4bb848L), Double.longBitsToDouble(0x3fe06f62bde1ce5eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 19, 8, "\udba0\udc6e\udb4e\udc82\udbe2\udca5\uda55\udde5\ud822\udf1d\udb84\udea5\ud9c1\udc6b", "\u34ed", "\udaa0\udc41\ud92f\ude0d\uda29\udc7a\ud853\udd24\ud892\udcb9\ud802\udc43\ud8b4\udc28\udb53\udf76\ud9ac\udc20\ud8c2\udf20\udbb2\udce6\ud93a\udd3d\udbb5\ude63\uda15\udeff\udb5a\udd7c\ud853\udeb0\ud92d\udf10\udbee\udde4\udb8d\udc6d\ud980\udfae\ud9c6\udd03\udba1\udeec\ud9f1\udfb3\udbe3\udeff\udb78\udf25\ud856\udcee\uda86\udc16\udaf4\udf4c",
        51, 36218, -534012818, -3995495107922468843L, 87663L, true, false, (char) 53438, (char) 48400,
        Double.longBitsToDouble(0x3febf01cd847b08fL), Double.longBitsToDouble(0x3fb3323f9beb1520L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 8, 13, "\udba0\udc6e\udb4e\udc82", "\uc55d\u4450\u4c5f\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\ud9e1\udf86",
        -3, 56359, -87639800, -6270966281982149473L, -25543L, true, true, (char) 33057, (char) 54947,
        Double.longBitsToDouble(0x3fe3ff9e6a4452c2L), Double.longBitsToDouble(0x3fcb9b56ad900a74L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 19, 8, "\udba0\udc5c\udb4e\udc82\uda0a\udd19\uda20\udfb3\ud822\udf7e", "\u9dc4\u61b5\uc298\u5525\u2745\u0880\u8ade\u520f\u4b5b\u0ad7\ub63e\u4bbc\ud587\ud1fc\u3b3a", "\udbb5\ude63\uda15\udeff\ud8d3\udc74\ud853\udeb0\ud92d\udf10\udbee\udde4\uda18\udf5f\ud98c\udc11\ud9c6\udd03\ud96b\udcb1\ud895\udd44\uda7e\uddd5\u03b4\uda0e\udec6\ud8e8\udea6\udbd5\ude68\udbda\udd4a\ud817\ude33\ud8d6\udf3e",
        14, 22108, -109411743, 4213115981513713133L, -88342L, true, true, (char) 14872, (char) 51164,
        Double.longBitsToDouble(0x3fe4023952ca81d5L), Double.longBitsToDouble(0x3fdedec7080fef9eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 19, 5, "\udba0\udc01\udb4e\udc82", "", "\ud9c1\udc6b",
        44, 36913, 0, -6722748343873693826L, 93461L, false, false, (char) 18487, (char) 36052,
        Double.longBitsToDouble(0x3fd64fac600151f2L), Double.longBitsToDouble(0x3e24977090000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[27614]]]\012",
        Z.run(T, 1, 11, 16, 0, "\udba0\udc6e\udb4e\udc82\udaa5\udf27\ud909\udc55\udac8\udfc2\udb84\uddea\udb50\udc12\udb36\udf34\u0593", "\u2945\u0880\u8ade\u520f\u6c1c\u0ad7", "\ud88a\udf52\ud9ac\udc15\uda8b\udea5",
        21, 27614, -1469111380, -2184913459247161592L, 49924L, true, true, (char) 31268, (char) 5382,
        Double.longBitsToDouble(0x3feab6d5ab6402d5L), Double.longBitsToDouble(0x3fd0787938af66d2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 19, 8, "\udba0\udc6e\udb4e\udc82", "\uc844\u4450\uc953\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\ud92f\ude0d",
        -3, 44751, -88006648, -6270966281982149473L, -80659L, true, false, (char) 48852, (char) 3986,
        Double.longBitsToDouble(0x3fda4377d53ab80cL), Double.longBitsToDouble(0x3fe3ff9e6a4452c2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 16, 8, "\udba0\udc6e\udb4e\udc82\uda0a\udd19\uda7e\uddba\ud822\udf7e\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89\ud847\udf8f\ud9ef\ude38\ud935\udf15\udaa0\udc41\ud92f\ude0d\uda29\udc7a\ud853\udd24\ud892\udcb9\ud802\udc43\ud8b4\udc28", "\u3b3a\u89a3\u76e8\u5977\ud2e5\u171c\ud52e\u5eb5\u2428\u2895\u9e11\uc3f5\u6bdb\u353a", "\ud9c3\udeb1\udb8a\udf93\udbc7\udea4\udaf2\udca4\uda79\udd84\ud88a\udc5f\udbad\udc1b\ud8b8\udea3\ud971\udfc0",
        12, 88653, -608963662, -8905564732753959689L, 66721L, true, true, (char) 56197, (char) 21012,
        Double.longBitsToDouble(0x3fd8c51b9b9880b8L), Double.longBitsToDouble(0x3fa66f16e5a71ce0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 19, "\udba0\udc6e\udb4e\udc82\uda0a\udd19\uda7e\uddba\ud822\udf7e\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89\ud847\udf8f\udb91\udf29\uda82\udd03\udb55\udd10\ud92f\ude0d\uda29\udc7a\udb85\udd7c\udb1e\udd84\ud802\udc43\ud8b4\udc28\udb53\udf76", "\u89a3\u76e8\u12bd\u06a4\u0f0d\u87e2\u5eb5\u8471\u336a\u79ef\u74be\u037a\u6942\u27f5\u242b\u0be2\u78c9\ua742\u5a37\u4a62", "\udafc\udf18\udb84\udd3c\ud804\udcb4\ud82a\udf7f\ud904\udc1c\ud9e9\udedf\ud960\udc7a\ud9b7\udfd7\uda31\udc0b\ud9a5\udd1c\ud892\udcc0\ud921\udf37\ud8bf\udefd\uda23\udfde\udbe5\udfae\uda71\udd7b\ud8db\udcb0\udbcc\ude3c\uda09\udd6a\udac3\ude54\ud843\udf51\ud9b6\ude65\ud8f6\udd60\udb5b\udcde\udab8\udd76\ud966\udf18\u792c\u6fe3\udbc9\udce9\uda43\udf72\ud8eb\udc1c\ud939\udd88\udac5\ude87\ud86b\udf94",
        22, 27360, -599370798, 2361026130816917140L, -34764L, true, false, (char) 64465, (char) 5792,
        Double.longBitsToDouble(0x3fec7fd0d18b02abL), Double.longBitsToDouble(0x3fec942e2eb704a3L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 19, 0, 0, "\000", "\ub316", "\ud9c1\udc6b",
        10, 75537, -1861456359, 790273982464L, -100000L, false, false, (char) 10551, (char) 0,
        Double.longBitsToDouble(0x3fd64000093f51f2L), Double.longBitsToDouble(0x3cd2000000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 19, 8, "\udba0\udc6e\udb4e\udc82", "\uc844\u4450\u4c5f\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\ud92f\ude0d",
        -3, 44751, -87639800, -6270966281982149473L, 49924L, true, false, (char) 19021, (char) 5382,
        Double.longBitsToDouble(0x3fcb9b56ad900a74L), Double.longBitsToDouble(0x3fecd3bbc8fc15a1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 3, 17, "\udba0\udc6e\udb4e\udc82", "\u2319\u443d\u4c5f\u5f77\ubf13", "\ud8d6\udd80\uda9f\udf4c\ud92f\ude0d\udac1\udc67\ud85f\udf52\udb88\uddb5\ud88a\udeb9",
        -5, 67532, -329780833, -3576300051478254623L, -25543L, true, true, (char) 33057, (char) 19363,
        Double.longBitsToDouble(0x3fe3ff9e69bf7514L), Double.longBitsToDouble(0x3fcb95d6aef80a74L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 16, 19, "\ud9ad\ude23\udb4e\udc82", "\uc844\u4450\u4c5f\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\ud92f\ude0d",
        -5, 43651, -87639800, -6270966281982149473L, -25543L, false, false, (char) 25811, (char) 46852,
        Double.longBitsToDouble(0x3fe3ff9e6a445287L), Double.longBitsToDouble(0x3fcb9b56ad900a74L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27778.5, 28530.5, 27960.0, 28168.5, 27775.5, 28398.5]]]\012",
        Z.run(T, 1, 10, 19, 8, "\ud861\udddb\udb4d\udff4", "\uc844\u4450\u4c5f\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\ud92f\ude0d",
        -3, 44751, -87639800, -6270966281982149473L, -25543L, true, true, (char) 33057, (char) 54947,
        Double.longBitsToDouble(0x3fe3ff9e6a4452c2L), Double.longBitsToDouble(0x3fcb9b56ad900a74L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\012",
        Z.run(T, 1, 11, 14, 8, "\ud8bd\udcbc\ud84a\ude31", "\u3d44\u4450\u4c5f\u5f77\u71ae\ucc13\u88bb\u2745\u0880\u8ade\u520f\u4b5b\u0ad7\ub63e\u4bbc\ud587\ud1fc\u3a16\ua3cf", "\uda15\udeff\ud8d3\udc74\ud853\udeb0\ud92d\udf10\ud80e\uddf4\uda15\udddc\ud83b\udce1\ud9c6\udd03\ud886\udc5e\ud8d0\udebd\ud850\udf2f\ud91c\udd6e\ud892\ude0d\ud85f\ude35\ud9be\udcbb\ucd4d\ud8c3\udeda\ud9ff\udc31\ud9cd\udc16\uda48\udd33\ud8c8\udd56\ud867\ude40",
        24, 58816, 1508986362, 5905203502609782076L, 35529L, false, true, (char) 55606, (char) 44271,
        Double.longBitsToDouble(0x3fe78d7b157938e4L), Double.longBitsToDouble(0x3fe6bbb6e195eadaL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27929.0, 28270.0, 27653.0, 28525.5, 27664.0, 28318.5, 28109.5, 28263.5]]]\012",
        Z.run(T, 1, 10, 0, 6, "\udb15\ude85\ud970\udc4f\uda0a\udd19\ud9cf\udd81\udbf5\ude7f\udb7a\udc13\ud9c0\udfd3\udb36\udf34\ud9c5\udd79\uda80\udd8b\ud84a\udea3\ud935\udf15\udaa0\udc41\udbf5\uddd0\udb44\udd10", "\ud63e\u4bbc\u6244\uafc4\u3b3a\u89a3\u1842\u70f8\ud4d8\u171c\ud52e\u39cf\u54e8\ub47f", "\uda62\udd0c\ud83a\udf0b\ud850\udd6d\udbcb\udcff\ud931\udeae\udb99\udf3a\udb57\udc10\ud866\ude15\ud8d4\udc37\udac2\udc1e\udb42\udf77",
        34, 63016, 330941771, 4891038403289510264L, -33665L, true, true, (char) 16184, (char) 56601,
        Double.longBitsToDouble(0x3fed42eb203a5e9fL), Double.longBitsToDouble(0x3fecfa5515ab6a1eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 8, "\udba0\udc6e\udb4e\udc82", "\uc844\u4450", "\ud808\udf89",
        51, -1000, 0, 667612085L, -91873L, false, true, (char) 2091, (char) 9625,
        Double.longBitsToDouble(0x3fbccf000a4bb848L), Double.longBitsToDouble(0x3fe06f62bde1ce5eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[28940, -204637539]]]\012",
        Z.run(T, 1, 11, 19, 8, "\udba0\udc6e\udb4e\udc82", "\ucc60\u4450\u4c5f\u5f77\u71ae", "\ud935\udf15\udaa0\udc41\udb76\udc30\uda29\udd26\ud853\udd24\ud858\udefd\ud831\udeb1\ud8b4\udc28\udb53\udf76\ud9ac\udc20\ud8c2\udf20\ub8e5\ud93a\udd3d\udbb5\ude63\uda15\udeff\uda33\udc7d",
        34, 28940, -204637539, 5963423959427170884L, -17212L, true, true, (char) 9492, (char) 39391,
        Double.longBitsToDouble(0x3fc77ef5cb638154L), Double.longBitsToDouble(0x3fe6b8abe86391f5L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 1, 17, "\udbf2\udfcf\ud92e\udfed\ud9b9\uddca\udb36\ude9d\ud822\udf7e\ud962\udef5\ud988\udeb3\udb36\udf34\ud813\ude8f\ud847\udf8f\uda1c\udecd\udac9\uded6\udb59\udd73\uda43\uddb9\uda52\udcc2\udab9\ude2c", "\ua9a9\ud587\ud1fc\u3b3a\u09ea\u83e1\u9793", "\uda86\ude98",
        29, 95724, 126684866, -6039201111102932655L, -30549L, false, false, (char) 22179, (char) 17625,
        Double.longBitsToDouble(0x3fdd7814dbeb6aa8L), Double.longBitsToDouble(0x3fea0fd1b40c4ce6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 19, 8, "\udbf9\udf3a\udb23\udffe", "\uc844\u4450", "\ud808\udf89",
        51, 86464, -913321472, 9016872844342525016L, 98064L, false, true, (char) 2111, (char) 20847,
        Double.longBitsToDouble(0x3fbccf3c4a4bb848L), Double.longBitsToDouble(0x3fe06f62bde1ce5eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27632.0, 28460.5]]]\012",
        Z.run(T, 1, 10, 19, 8, "\udbf9\udf3a\uda30\ude65", "\uc844\u4450", "\ud810\ude89",
        51, 18384, -913321460, 9016872844342525016L, 98064L, false, true, (char) 2111, (char) 61544,
        Double.longBitsToDouble(0x3fe399e7893d9de3L), Double.longBitsToDouble(0x3fe06f62bde1ce5eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.32174315686223565]]]\012",
        Z.run(T, 1, 11, 19, 8, "\udbf9\udf3a\udb23\udffe", "\uc919\u8f30", "\ud808\udf89\uda10\udc12",
        21, 20540, 2099404308, 1722341362095745495L, 78440L, false, true, (char) 61544, (char) 25956,
        Double.longBitsToDouble(0x3fd497709c1bd8aeL), Double.longBitsToDouble(0x3fe89c8af69b5f75L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 14, 0, "\udbf9\udf3a\ud809\uded1", "\u092a\u4450\u2e8c\u9010\uafde\uc298\u4bbc\u11a0\ub0d0\u38ac\uaff9\u940d\ua2ee\ubfda\u4b92\u68d6\uad40\u3b3a\u8a27\u714e\u1f6e\u3fbe\u4ee8\ucff5\uaf3b\u0c1f\uaff8\u70ba\u599f", "\udb5b\udf3a\ud8a0\udeb9",
        38, 4144, -353385846, -1823268842834302894L, -48721L, true, false, (char) 27396, (char) 23202,
        Double.longBitsToDouble(0x3fb0d7bb2a568338L), Double.longBitsToDouble(0x3fda4a0fe4770378L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.11253717179079203, 26512, 0.9406757914315513]]]\012",
        Z.run(T, 1, 11, 19, 2, "\udb40\udd5d\udb24\udc48", "\uc844\u4450", "\ud808\udf89",
        51, 26512, 902190974, 9016898304908655704L, 98064L, false, true, (char) 2111, (char) 61544,
        Double.longBitsToDouble(0x3fbccf3c706d0048L), Double.longBitsToDouble(0x3fee1a041e0acc3aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 17, 13, "\udac3\udd4a\uda55\udee3\udaf1\uddec\udb43\udf97\udac5\udece", "\u6e06\ua091", "\uda9c\udc0e\udb59\udd73\udb74\udf3c\ud87c\udc77\udb33\udc0e\ud861\udde8\uda30\udce8\uda62\udc68\udb78\udc17\udba1\udfb9\ud8c2\udfc7\ud8c5\udd4f\udaeb\udf3a\ud80c\udfd6\udb32\udd5b\udb76\udd15\uda36\udc9d\udb1b\udf71\udbb9\ude0d\ud8e6\udc97\ud972\udd64\ud823\udced\ud8bc\udc9e\udb20\udfa5\udae7\uddfc\udb2a\udf02\ud9d9\udfbe\ud8e5\udc2c\uda0e\udd80\udbba\udc65\ud876\ude13\uda44\udde2\udba0\udf70\uda1f\ude60\uda19\udcb3\ud940\udd9b\u2bba\ud9f5\udf91\ud847\ude1d\ud939\ude34\uda86\ude33\uda74\udc36\ud977\udc97\uda48\udc06\udad1\udf65\ud8c0\udfc4\uda93\udef3\udad5\udf32\ud8fd\udee3\ud8ff\udc4b\udafd\udc65\u3d06\uda64\udc4e\ud88d\udd20\uda25\uddc9\u5f9e\ud89a\udecb\ud833\udc8d\ud844\udcaf\ud8aa\udd8d\udb47\ude29\udaad\udc68\ud92e\udc93\udb16\udcaf\ud8a8\udfef",
        55, 52633, -933846671, -790356379468720757L, 75061L, true, true, (char) 21974, (char) 3358,
        Double.longBitsToDouble(0x3fd9dbbac1f1f1a8L), Double.longBitsToDouble(0x3fd56dc2e4ed6806L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[4773, 0.3819840977732273]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 18, "\udbf9\udf3a\udb67\uddc0\ud83a\udd21\udb43\udf97\ud822\udf7e\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89\ud847\udf8f\uda1c\udecd\udac9\uded6", "\u3c20", "\udae7\udc2f\udaf9\udf21\uda50\udf32\ud9ac\udc20\ud8c2\udf20",
        18, 4773, 1571242431, 2799903173558962139L, -68352L, true, false, (char) 32845, (char) 39134,
        Double.longBitsToDouble(0x3fd8726d6de1cc06L), Double.longBitsToDouble(0x3fe8a039fe9dbc08L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\000", "[", "",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 0, (char) 32258,
        Double.longBitsToDouble(0x3e45900000000000L), Double.longBitsToDouble(0x3e44830000000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 17, 17, "\ud87d\uddca\udba1\ude3c\ud954\ude0a\ud926\udf8e\udb7c\udccf\uda57\udeda\ud834\udd9b", "\u243b", "\uda35\udc84\ud885\udfe4\ud857\ude0f\udbc4\udc62\uda31\udc67\ud831\udc5b\u8702\udb1c\ude7e\ud83b\udc30\udbfe\udd89\ud928\uddaa",
        24, 17445, 37825899, -5667841226555396076L, 76166L, false, true, (char) 26239, (char) 19844,
        Double.longBitsToDouble(0x3feb61152b4a19caL), Double.longBitsToDouble(0x3fd0c48496f42ed6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 5, 8, "\udba0\udc6e\udb4e\udc82\uda0a\udd19\uda7e\uddba", "\u4c5f", "\ud847\udf8f\ud9ef\ude38",
        18, 38111, 667612085, 2916232593664668457L, 89852L, true, false, (char) 25738, (char) 53842,
        Double.longBitsToDouble(0x3fd450f3171ac364L), Double.longBitsToDouble(0x3fe552c7c38d6f94L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u71ae]] |a1=[Ljava.lang.Comparable;:[[\udba0\udc6e\udb4e\udc82\uda0a\udd19\udb94\udd1c\ud822\udf7e\udb84\udea5]] |a2=[[D:[[[14527.0]]]\012",
        Z.run(T, 1, 9, 5, 8, "\udba0\udc6e\udb4e\udc82\uda0a\udd19\udb94\udd1c\ud822\udf7e\udb84\udea5", "\u71ae", "\ud95b\udcd7\uf93f\uda83\udcd0",
        -3, 66105, -87651064, -6270966281982149473L, -88851L, true, false, (char) 37665, (char) 18744,
        Double.longBitsToDouble(0x3fd27e1ad6d7e84cL), Double.longBitsToDouble(0x3fea5acbd81d2199L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u1173\u437d]] |a1=[Ljava.lang.Comparable;:[[\udba0\udc6e\ud8bd\uddee, \u1173\u437d]] |a2=[[D:[[[27628.0, 28588.5]]]\012",
        Z.run(T, 1, 9, 5, 8, "\udba0\udc6e\ud8bd\uddee", "\u1173\u437d", "\ud808\udf89",
        45, 83050, -116385922, 7693029933887189941L, -70519L, false, true, (char) 2091, (char) 9625,
        Double.longBitsToDouble(0x3fbccf001a4bb848L), Double.longBitsToDouble(0x3fd45413171ac364L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 5, 8, "\udba0\udc6e\udb4e\udc82", "\u74be\u458c\u4c5f;\u71ae", "\ud935\udf15\udb5a\udf18\ud92f\udd66",
        -3, 66105, -87651064, -6270966281982149473L, -11095L, true, true, (char) 36159, (char) 39842,
        Double.longBitsToDouble(0x3fec6b7ca0c9a86fL), Double.longBitsToDouble(0x3fd27e1ad6d7e84cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[64154, 519669477]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 8, "\udba0\udc6e\udb4e\udc82", "\u9941\u4450\u4c5f\u5f77\u71ae\uc298\u5525\u2745\u0880\u8ade\u520f\u9ec5\ub6d6\ub63e\u4bbc\ud575\ua4b2\u6ef3\u64ff\u76e8\u53c4\ud4d8\u171c", "\udb65\udd1f\udb6f\ude70\u3a2e\udac4\udea4\uda2d\udc37",
        30, 64154, 519669477, -674777789139928859L, -74632L, true, true, (char) 20024, (char) 62139,
        Double.longBitsToDouble(0x3fd18a5c14abd8a6L), Double.longBitsToDouble(0x3fe9172029801a25L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 19, 0, 0, "", "", "\000",
        -5, -1000, 0, 9079256846917463577L, 93461L, false, false, (char) 18487, (char) 36052,
        Double.longBitsToDouble(0x3fd64fac693f51f2L), Double.longBitsToDouble(0x3f2e000000000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27728.5, 28173.0, 27702.5, 28502.0, 28030.0, 28638.0, 28049.0, 28303.0]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 12, 8, "\udb92\udfe8\u2835", "\u7680\u43b7\u94ab\uadee\u9704\u36c6\u5525\u56e2\u02ab\u2261\u5680\ud40b", "\ud8d1\udc4a\ud89d\udedc\udb2c\udfec\udb52\udd4e\ub8b3\ud92e\udd37\udbb5\ude63\uda15\udeff\ud8d3\udc74\ud887\udeb0\ud92d\udf10\udbee\udde4",
        31, 93693, 146921692, -2287857158062962042L, 5449L, true, false, (char) 3654, (char) 59775,
        Double.longBitsToDouble(0x3fd195a9af9e1554L), Double.longBitsToDouble(0x3fe4357e13bb5bd1L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27682.5, 28612.5, 27625.0, 28169.5]]]\012",
        Z.run(T, 1, 10, 2, 3, "\udba0\udc6e\udb4e\udc82\ud9fc\ude19\uda7e\uddba\ud8ae\udf04\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89", "\u2745\uc9d0\ucff9", "\ud875\udfb9\ud802\udc43",
        43, 77267, -329780919, -3576300052988256799L, -25543L, true, true, (char) 33057, (char) 54947,
        Double.longBitsToDouble(0x3fe3ff9e684452c2L), Double.longBitsToDouble(0x3fe720636364029dL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.23741249732039538]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.23741249732039538]]]\012",
        Z.run(T, 2, 11, 11, 11, "\udba0\udc6e\udab8\udef8\ud9da\ude6f\udb59\udfb3", "\ucdda", "\udbfe\udeef\uda69\uddba\ud936\udd15\udaa0\udc41\ud92f\ude0d\uda9f\udf40\ud85b\udde5\ud892\udcb9\ud802\udc43\udab2\udebf\ud88a\udf52\ud9ac\udc15\uda8b\udea5\ud973\ude13\uda11\udee0\u37fd\ud98f\udd15\ud94d\ude6c",
        21, 71580, 888108483, -2827621522725289436L, -64572L, false, false, (char) 24567, (char) 17459,
        Double.longBitsToDouble(0x3fce63885fd38e7cL), Double.longBitsToDouble(0x3fe0d7235bfb4ffcL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[23980.5]]]\012",
        Z.run(T, 1, 10, 4, 2, "\u6585\udbc4\ude7f", "\u3838\u4450", "\ubb89",
        -3, 15808, -116385922, 8341548280228541370L, 39199L, false, true, (char) 2091, (char) 40010,
        Double.longBitsToDouble(0x3fc3b13e5ea32488L), Double.longBitsToDouble(0x3fb2cdb26f3f5a00L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27910.0, 28367.5, 27704.5, 28640.0, 27665.5, 28480.0, 27851.5, 28460.0]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 11, "\udb15\ude85\ud970\udc4f\udbf5\udf12", "\u19be\u4bc7\u5f77\u6b19\u2feb\ucbf9\uc845\u25d8\u077f\u2405\ucf1d\u89bb\ud63e\u3322\uc9d9\u5018\u3be5\u89a3", "\uda3c\uddcf\ud8a1\udff0\ud853\udeb0\ud9c7\ude88\ud983\udd6e\ud9b7\udd8c\ud982\udd6c\ud9c1\uddc8\ud9e2\ude0d\ud83a\udf0b\ud850\udd6d\udbcb\udcff\ud931\udeae\udb99\udf3a\udb91\udc58\ud843\udf15\ud8d4\udc37\udac2\udc1e\udb42\udf77\ud88b\udc5c\udb01\udc25\uda45\ude74",
        -5, 46744, -2019930359, -1707705303147043039L, -34522L, true, true, (char) 26569, (char) 63099,
        Double.longBitsToDouble(0x3faac2447816c990L), Double.longBitsToDouble(0x3fe1766cf19d15d6L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[85724]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 20, 4, "\uda49\udf3a\uab74\ud88e\udcd2\udb36\udf3c\ud822\udee5\ud962\udef5\ud97f\udeb3\udb36\udf34", "\u18e6\ua1ed\u4a63\u301f\u3c20\u01e6", "\ud985\udd06\udb53\udf76\ud9ac\udc20\ud8c2\udf20\ud8ce\udfe4\uda13\ude80\udadf\udc21",
        37, 85724, 768822528, -3821030564432896390L, -70666L, true, true, (char) 30360, (char) 49237,
        Double.longBitsToDouble(0x3fe025dd379ad708L), Double.longBitsToDouble(0x3fd98fb40baf029aL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[53189, 0.06683820799264928, -1098910518]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 7, 10, "\udb40\udd5d\ud95b\udcc3\ud814\udc99\udb43\udf97\uda30\udd83\udbed\udc20\ud9cf\udf4c\ud9cb\udfbe\ud975\udd94\u78b8\udb3c\udc49", "\u38ac\u3c20\u27fc\u0599\u893f\u3777", "\udb4b\uddbf\ud8d9\uded4\ud8e0\uddfa",
        51, 53189, -1098910518, -8802769296057585528L, 33477L, true, false, (char) 54917, (char) 5388,
        Double.longBitsToDouble(0x3fb11c4f0d73a0f0L), Double.longBitsToDouble(0x3fe1feb7f440ef21L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[4773, 0.3819840977732273]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 0, "\udbf9\udf3a\udb67\uddc0\ud83a\udd21\ud936\uddcd\ud9d6\ude9d\udb72\udc36\ud9c1\udc6b\udb36\udf34\ud9e8\ude79\ud848\udc52\uda1c\udecd\udac9\uded6", "\u3c20", "\udae7\udc2f\udaf9\udf21\uda50\udf32\ud8c0\udd55\ud8c2\udfce",
        18, 4773, 1571242431, 2799903173558962139L, -68352L, true, false, (char) 32845, (char) 33509,
        Double.longBitsToDouble(0x3fd8726d6de1cc06L), Double.longBitsToDouble(0x3fe8a039fe9dbc08L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[4773, 0.3819840977732273]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[4773, 0.3819840977732273]]]\012",
        Z.run(T, 2, 11, 11, 0, "\udbf9\udf3a\udb67\uddc0\ud83a\udd21\udb43\udf97\ud822\udf7e\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89\ud847\udf8f\uda1c\udecd\udac9\uded6", "\u3c20", "\udae7\udc2f\udaf9\udf21\uda50\udf04\ud9ac\udc20\ud8c2\udf20",
        18, 4773, 1571242431, 2799903173558962139L, -68352L, true, false, (char) 14413, (char) 39134,
        Double.longBitsToDouble(0x3fd8726d6de1cc06L), Double.longBitsToDouble(0x3fe8a039fe9dbc08L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[38912, 0.5624218998646835]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[28074.0, 28474.5, 27848.5, 28189.5, 28035.0, 28546.0, 27628.0, 28588.5]]]\012",
        Z.run(T, 2, 11, 10, 15, "", "\u11e4", "\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89\ud847\udf8f\uda1c\udecd\udac9\uded6\udbcd\udc6e\uda51\uddfc\uda52\udcc2\udab9\ude2c\ud8aa\udf26\udbe0\ude4c\000\000\000\ud8c2\udf13\uda94\udcd6\ud8e8\uddf5\udb9b\udf43\ud8a6\udf64\uda32\udce2\ud977\udc47\udbd1\uded7\000",
        6, 38912, -435986041, 522170096798961428L, 46545L, true, false, (char) 34183, (char) 8992,
        Double.longBitsToDouble(0x3fe1ff5c364f22d6L), Double.longBitsToDouble(0x3feeda28496b8335L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.03933771885931492, 0.3819840977732273]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.03933771885931492, 0.3819840977732273]]]\012",
        Z.run(T, 2, 11, 11, 18, "\ubd56\udb67\uddc0\ud83a\udd21\udb43\udf97\000\udb84\uddc8\ud9c1\udc6b\ud800\udcd8\000\ud847\udf76\uda1c\udecd\udac9\uded6", "\000", "\udae7\udc2f",
        -2, 48496, -329780919, -3576300051129393695L, -100000L, false, false, (char) 30304, (char) 7855,
        Double.longBitsToDouble(0x3fa42412d0000000L), Double.longBitsToDouble(0x3fd8726d6de1cc06L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.769558903977555, 4773]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 19, "\udbf9\udf3a\udb67\uddc0\ud83a\udd21\udb43\udf97\ud822\udf7e\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89\ud847\udf8f\u1a83\uda96\udd0c", "\u87ba", "\udae7\udc2f\udaf9\udf21\ud9f2\udf23\ud9ac\udcc0\ud8c2\udf20",
        18, 4773, 1571242431, 2799903173973791963L, -56184L, false, true, (char) 34909, (char) 1268,
        Double.longBitsToDouble(0x3fe8a039fe9dbc08L), Double.longBitsToDouble(0x3fdbb62dcf39ccf6L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.7912118680415596, 0.6540376088768407, 0.7912118680415596]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 2, "\udbf9\udf3a\udb67\uddc0\uda04\udd26\udb43\udf97\udabb\udcc2\udb84\udea5\ud9c1\udc6b\udb36\udf34\udb06\udf88\ud8e2\udf55\uda11\udfd1\udaef\udc88", "\u3bf9\u27fc\ud5d8\u88e5\u85c4\u4152", "\uda94\udcd6",
        39, 85271, 1994080538, 1258905470438886678L, -16625L, false, false, (char) 31665, (char) 34851,
        Double.longBitsToDouble(0x3fe9519b8d2e4214L), Double.longBitsToDouble(0x3fe4ede0478f5cbcL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.31058993673204816, 0.6983262564160343, 0.31058993673204816]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.31058993673204816, 0.6983262564160343, 0.31058993673204816]]]\012",
        Z.run(T, 2, 11, 11, 0, "\udbf9\udf3a\udb71\udcaf\ud83a\udd21\udb43\udf97\ud822\udf7e\udb84\udea5\ud9c1\udc6b\udb36\udf34\ud808\udf89\ud847\udf8f\uda1c\udecd\udac9\uded6", "\u3c20\u27fc\ud5d8\u88e5\u6b24\u4152\ud1fc\u3b3a\ua166\u0ce2\u88be\u7727\ubc8f\u04db\ua6b7\u431c\u9910\uc321\u3aba\u9786\u0e86\u1744\ua7af\u2395\u9fc7\u551f\u7ba7\u9ae7\u1493\u2e22\u33bd\u479e\u4701\u2de1", "\udba2\udfcc\ud8f2\udff5\ud84f\udc1c\ud8be\udfc4\ud915\udfbb\udb38\udf6a\ud9bf\udda6\udab4\udd98\uda40\ude73\u9f9c\ud8e7\ude41\udb79\udeae\ud9a1\udf7e\udba6\udfcd",
        47, 20737, -27600448, -5688921109839230280L, 86407L, false, false, (char) 22796, (char) 27921,
        Double.longBitsToDouble(0x3fd3e0b49d2ec658L), Double.longBitsToDouble(0x3fe658b04e27d6dbL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 5, 8, "\000", "", "",
        -5, 86536, -1604912936, 0L, -100000L, false, false, (char) 10401, (char) 24584,
        Double.longBitsToDouble(0x3fd64fac693f51f2L), Double.longBitsToDouble(0x3e3a480000000000L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27672.5, 28172.0, 27624.0, 28408.0, 27982.0, 28344.5, 28084.5, 28463.0]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27672.5, 28172.0, 27624.0, 28408.0, 27982.0, 28344.5, 28084.5, 28463.0]]]\012",
        Z.run(T, 2, 10, 10, 8, "\udb28\udc72\udb4e\udc82", "\u7705", "\ud861\udc48\ud800\ude20\udacc\udda1\udb99\ude8e\udbe2\udc58\udaa0\udc41\ud950\udc1d\uda40\udfd7\ud868\udc8e\ud887\udcb9\ud802\udc43\udb38\udfcb\uda32\ude92\uda8c\uddc3\uda4a\udd63\ud8ca\udccb\uda5f\uded5\ud949\udcd3\uda35\udf21\udb80\udfbc\ud8e9\udd9c\udb9c\udf09\uda82\udce8\uda25\udc48\ud9e5\udc22\uf3c3",
        49, 90090, 1541627935, 2231963408287315245L, -29303L, true, false, (char) 22166, (char) 27541,
        Double.longBitsToDouble(0x3fea78d1a57598ecL), Double.longBitsToDouble(0x3fe4e7a0f918a5c1L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.03894682865219323]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 20, "\udb47\udc2b", "\u5c95\u9941\u4450\u4c5f\u5f77\u71ae\uc298\u5525", "\ud92f\ude0d\uda29\udc7a\ud868\udc8e",
        1, 82884, 1006645663, 8577431361947786057L, -88851L, false, false, (char) 2876, (char) 18744,
        Double.longBitsToDouble(0x3fa3f0d6b6b02c00L), Double.longBitsToDouble(0x3fdb39d7437311f4L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[64154, 519669477]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[64154, 519669477]]]\012",
        Z.run(T, 2, 11, 11, 8, "\udba0\udc6e\udb4e\udc82", "\u9941\u4450\u4c5f\u5f77\u71ae\uc298\u5525\u2745\u0880\u8ade\u520f\u9ec5\ub6d6\ub63e\u4bbc\ud575\ua4b2\u6ef3\u64ff\u76e8\u53c4\ud4d8\u171c", "\udb65\udd1f\udb6f\ude70\u3a2e\udac4\udea4\uda2d\udc37",
        30, 64154, 519669477, -674777789139928859L, -74632L, true, true, (char) 20024, (char) 62139,
        Double.longBitsToDouble(0x3fd18a5c14abd8a6L), Double.longBitsToDouble(0x3fe9172029801a25L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\0121=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\012",
        Z.run(T, 2, 11, 11, 11, "\000", "", "\ud91f\udf8b\uda18\udff6\udab5\uddda\u3a1c\udbfe\udeef\uda69\uddba\ud936\udd15\udaa0\udc41\ud92f\ude0d\uda9f\udf40\ud85b\udde5\ud892\udcb9\ud802\udc43\udab2\udebf",
        0, 84070, -2107740659, -9139882214823792890L, 3716L, true, false, (char) 0, (char) 5091,
        Double.longBitsToDouble(0x3fdc37206a6a69deL), Double.longBitsToDouble(0x3fe126c61356dab5L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u5546]] |a1=[Ljava.lang.Comparable;:[[\ud837\udcdf]] |a2=[[D:[[[10891.0]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27848.5, 28189.5, 28035.0, 28500.0, 21130.0, 28070.0, 28347.5, 28006.5]]]\012",
        Z.run(T, 2, 9, 10, 19, "\ud837\udcdf", "\u5546", "\ud9c1\udc6b\udb36\uded8\ua544\udb7c\udda7\udafd\udde6\udb76\udf61\udbe9\ude28\ub22b\uda42\udd4c\uda9e\udf0c\ud8aa\udfa2\udae7\udc2f\udaf9\udf21\ud9f2\udf23\ud9ac\udcc0\ud8c2\udf20",
        29, 93553, 598195993, 3366247317027133163L, 74923L, false, true, (char) 34909, (char) 1268,
        Double.longBitsToDouble(0x3fe8a039fd16346fL), Double.longBitsToDouble(0x3fe52f5cd98b2570L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[5.820958159930001E-10, 4.2249768128499454E-9, 5.820958159930001E-10]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 2, "", "", "",
        -5, -1000, 1703936, -6893321251930991591L, -34464L, false, false, (char) 10804, (char) 0,
        Double.longBitsToDouble(0x3e04002b40000000L), Double.longBitsToDouble(0x3e32256940000000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 0, 2, "\000", "", "",
        56, 86703, -1604912936, -2449958199131187113L, 63188L, true, true, (char) 18014, (char) 45335,
        Double.longBitsToDouble(0x3fbf8a1e28469800L), Double.longBitsToDouble(0x3fe09bb631b058f9L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.07812757790088654]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 2, "", "", "\u009c",
        57, 34215, -1902418599, 141364553580544L, -65684L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fb4002b40000000L), Double.longBitsToDouble(0x3fe2256947b4c68fL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 20, 8, "\ud9a0\udff9\ud9b2\udd75", "\u4625\u355e\ub84c\uc050\u71ae", "\ud935\udf15\udb3a\udceb\udb6d\udd7d",
        -3, 44751, -88753912, -6293767954118968161L, -79535L, true, false, (char) 27711, (char) 53014,
        Double.longBitsToDouble(0x3feb9264a0c92b1aL), Double.longBitsToDouble(0x3fd27e1ada3be84cL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u74be\u547f\u4c5f;\u71ae, \ud935\udf15\udb5a\udf18\udaac\udc19]] |a1=[Ljava.lang.Comparable;:[[\u74be\u547f\u4c5f;\u71ae, \ud935\udf15\udb5a\udf18\udaac\udc19, \ud9c0\udfeb\udb4d\udfd6]] |a2=[[D:[[[14919.0, 10791.5, 9751.5], [14527.0]]]\012",
        Z.run(T, 1, 9, 5, 8, "\ud9c0\udfeb\udb4d\udfd6", "\u74be\u547f\u4c5f;\u71ae", "\ud935\udf15\udb5a\udf18\udaac\udc19",
        2, 59395, -87209875, -1919081667050750726L, -11095L, true, true, (char) 36159, (char) 39842,
        Double.longBitsToDouble(0x3fec6b7ca0a0a86fL), Double.longBitsToDouble(0x3fd27e1aded7e84cL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 17, 18, "\ud87d\udfca\udba1\ude3c\ud954\ude0a\ud857\ude26\ud878\udf89\udb84\udea5\ud986\udcf5\udb36\udee7\uda6b\ude58\ud863\udd56\ud9ef\ude38\ud896\udcd7\ud8cb\udcfa\ud886\udc5c\ud857\ude0f\udbc4\udc62\ud99b\udffc\udab6\udc9d\ud82e\udc26\udba7\udeb0\uda67\uddec\udbd5\udf11\ub8e5\udba0\udc21\udab7\udc40\uda15\udeff\uda22\udd02\ub79e\udaeb\ude18\ud878\udd8b\udbab\udef5\ud8af\uddc3\ud97d\udf10", "\u2a68\u012f\u649d\ua9f6\ua668\u96dc\uc641\u99d7\u28f6\ub3f7\u94fe\u8db9\u0381\u54c7\u51d9\u6b49\u03b7\u3a8e\u8d8f\u9baf\u4d0f\u4f0a\u7ead\u1091\ud430\u28eb\u3d7c\ud7ad\u0459\u9018\u090d\u432b\u1019\u1ac2\u157d\u0e07\ucb3a\ucf4f\uc819\u0cd9\u2803\u23e8\u7cc9\u7389\u65c3\u41c9\u8373\u0562\u8de4\u236e\u879c\ud236\u05d7\u27c0", "\u3af9\ue0c9\udb93\udf90\ud8c5\ude76\uda13\udfed\ud839\udf65\uda25\udd65\ud847\udf3e\ud86f\udd9d\udb49\ude3b\udaa1\uddc4\ud83a\udf05\udae2\udc10\udb0b\udc2d\ud960\udd46\uda84\udf21\uda6b\uddc3\udb65\udedb\u1288\udaba\udcc3\ud84e\udd56\ud868\udd00\uda8c\udf79\ud87f\uddef\u7aef\uda62\udf74\udab6\udc1d\udb9b\ude78\uda0f\ude66\ud93f\udef3\udb02\udc14\uda2d\udc15\udb64\udd31\ud830\udf9a\ud9f3\udf6a\uda67\udcfc\udb47\udcc1\ud855\udc0c\ud99d\udcd9\uda54\uddcd\udb2d\uddbd\ud967\ude53\ud92d\udcfc\ud94f\udc8a\u2928\udadd\udf13\ud907\udc49\ud956\udfe1\ud934\udd60\ud903\udc15",
        42, 57195, 1328901428, 45979127745750659L, -34137L, true, false, (char) 36538, (char) 14564,
        Double.longBitsToDouble(0x3fd4cd7c48ef952aL), Double.longBitsToDouble(0x3fd32945a48c8730L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u7666\ua060\u4c5f;\u71ae\uc298\u5525, \udaac\udc19]] |a1=[Ljava.lang.Comparable;:[[\u7666\ua060\u4c5f;\u71ae\uc298\u5525, \udaac\udc19, \ud9c0\udfeb\udb4d\udfd6]] |a2=[[D:[[[15131.0, 20504.0, 9751.5], [14527.0, 24884.0, 10874.5]]]\012",
        Z.run(T, 1, 9, 5, 8, "\ud9c0\udfeb\udb4d\udfd6", "\u7666\ua060\u4c5f;\u71ae\uc298\u5525", "\udaac\udc19",
        2, 59395, -87209875, -1919081611216175878L, 52562L, true, true, (char) 36266, (char) 39842,
        Double.longBitsToDouble(0x3fec6b7ca0a0a86fL), Double.longBitsToDouble(0x3fdf0a4aded7e8eeL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|calculatePieDatasetTotal|org.jfree.data.pie.PieDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|calculateStackTotal|org.jfree.data.xy.TableXYDataset,int|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|java.lang.Comparable,org.jfree.data.KeyedValues|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|[Ljava.lang.Comparable;,[Ljava.lang.Comparable;,[[D|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|java.lang.String,java.lang.String,[[D|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|java.lang.String,java.lang.String,[[Ljava.lang.Number;|static",
    "M|org.jfree.data.general.DatasetUtilities|createConsolidatedPieDataset|org.jfree.data.pie.PieDataset,java.lang.Comparable,double|static",
    "M|org.jfree.data.general.DatasetUtilities|createConsolidatedPieDataset|org.jfree.data.pie.PieDataset,java.lang.Comparable,double,int|static",
    "M|org.jfree.data.general.DatasetUtilities|createPieDatasetForColumn|org.jfree.data.category.CategoryDataset,int|static",
    "M|org.jfree.data.general.DatasetUtilities|createPieDatasetForColumn|org.jfree.data.category.CategoryDataset,java.lang.Comparable|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
