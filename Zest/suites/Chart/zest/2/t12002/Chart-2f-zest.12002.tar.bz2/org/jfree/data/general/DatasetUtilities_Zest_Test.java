package org.jfree.data.general;
import org.junit.Test;
import static org.junit.Assert.*;
public class DatasetUtilities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.6104044033270319]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u5f02", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574869259114996L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 12, 3, "\ud932\udc2e\ud862\udc2d\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u087c\u5f02", "\udbb4\udc3e\uda9c\udfd0\ud97d\udc8e\ud9b3\ude99",
        22, 16734, -555857594, -131574869259114996L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fdcd0dda167ef8cL), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 1, "\uda4c\udc5b\udafb\udfac\udbd6\udd67\ud965\udf52\ud9b6\uddac\ud969\udcbb\uda51\udc84", "\u1e87\u5e93\u641c\u3077\ua707", "\ud9d1\udff7\ud866\udc9e\ud968\udf6f\ud9b3\ude46",
        22, 16734, 1356745080, -131574869259114996L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 1, "\uda0b\udc1b\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\udb30\udc71", "\u0c8b\u36bb\u641c\u74e8\u5f02\u7a53\u91db", "\ud91a\udfc5\ud9b3\ude99\udb73\udd8f\udb6e\uddc3\uda1c\udf24\udadd\ude0c\ud850\udcaf\udbf3\udc96\udb10\udcf4\ud987\udc18\ud9c4\udd8f\udbfe\udff0\ud9b4\udce3\ud963\udc31",
        47, 28063, 58916102, -1313902153046518147L, 79152L, true, true, (char) 42452, (char) 39058,
        Double.longBitsToDouble(0x3feb18d703c11571L), Double.longBitsToDouble(0x3fe929ec77df3c37L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.6104044033270319]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 0, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u90e5\u4f68\u641c\u74e8\000", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574867111631348L, -2976L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b86400L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u5f02", "\ud909\ude0f\ud95e\udd3a\ud96f\udd2f\uda34\udfba",
        45, 16734, 1356745080, -131574869259114996L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e\ud81f\udfec\ud8c8\udc0a\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\uc965\u3345\u7d4e", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        0, 81645, 1048106930, -6260026891756820894L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.6104044020175934, 0.2708376382666522]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\ub4b4\u74e8\u5f02", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574869259114996L, -3165L, false, false, (char) 16175, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0000000L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 7, 10, "\ud932\udc2e\ud8a9\udcd1\udb52\udeed\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\ub52d", "\udb39\udeab\udb8b\udeb2\ud9a9\udff1\uda73\udcc7",
        22, 16734, 1356745080, -131574866193865204L, -3165L, true, false, (char) 16524, (char) 54140,
        Double.longBitsToDouble(0x3fd02b83f10d93b2L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 13, 1, "\uda12\udc56\ud998\udd2a\ud827\udf6d\ud947\ude71\ud9b6\uddac\ud969\udcbb\uda61\udfc9\ud8c7\udf94\ud9bf\udc01\uda2a\udea9\udb0f\udfeb", "\u5f02\u7a53\u3553\u9c89\u7630\u48bd\u43ba\ua08e\uc71e\u6950\ud330", "\udb10\udcf4\ud987\udc18",
        26, 18128, -138002831, 6230326232842512661L, -94135L, true, true, (char) 31536, (char) 39337,
        Double.longBitsToDouble(0x3fe8707bb7f53f92L), Double.longBitsToDouble(0x3fe668cc2143f96dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.17574987017242338, 0.4650359201544183, 0.17574987017242338]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 0, "\ud879\udc7f\ud8f6\udda5", "\u2d29\u7125\uc210\u11b5\u1f58\u1487\u36b2\u6faf", "\ud809\uddb0\ud8d5\uddc6\udb39\udeab\ud94d\udfb3\ud8fa\uddb5",
        35, 14692, 326764174, 5827175657383955931L, 32679L, false, false, (char) 55888, (char) 38699,
        Double.longBitsToDouble(0x3fc67ef8c45559d8L), Double.longBitsToDouble(0x3fddc3260521d2d8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.8312141862297935, 39253, 0.4171336944926213]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 11, "\ud932\udc2e\udbda\uddc9\uda96\udcdf\ud95b\udeb8\ud9b6\uddac\ud969\udcbb\uda61\udfc9\ud85a\udc5c\ud9bf\udc01\uda2a\udf0f\uda9b\udf6a\udad3\udcbf\ud91e\udc65\ud903\udd2d\ud809\uddb0\ud8d5\uddc6\udba8\udda1\udb88\ude51\ud91a\udfc5\ud9b3\ude99\udb61\udf8f\udb6e\uddc3", "\u36dd\u8b0e\u1d90", "\udbfe\udff0\udb97\uddf4\ud997\uddcb\udbfb\udc0c\ud9bf\ude52\uda7d\ude57\udabc\udda4\ud85c\ude47\ud8bd\udfb3\uda3e\udd5a\ud9f5\udc43\ud86f\udd4a\ud8e9\udd26\ud882\udc8d\ud954\udd17\u6029\ud983\udfac\ud8b5\udf51\uda08\ude36\ud97c\udeab\ud98d\udf00\ud971\udf61\ud84d\udf10\ud8fc\udfcb\udb17\uddbe\ud82b\udce0\udba5\uddcb\udb82\ude0b\uda49\udefd\udaff\udc4e\ud919\udd79\u2c65\ud9d8\udf2c\udb8a\udf62\ud978\udcf9\ud84a\ude51",
        7, 39253, 1692461451, 5573032362464445296L, 16895L, false, true, (char) 18976, (char) 55944,
        Double.longBitsToDouble(0x3fea994e7e3a80c0L), Double.longBitsToDouble(0x3fdab25185f9f31eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.6081799453955591]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e", "\u919d\ucd08", "\ud849\ude5c",
        29, 62715, 227608064, -8741904803580804329L, -32524L, false, true, (char) 50346, (char) 59667,
        Double.longBitsToDouble(0x3fe37635c9f1d2e1L), Double.longBitsToDouble(0x3fc898e95a3bae4cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.6104044033270319]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud955\udebb\ud909\udfb8\u11b5", "\u1dbb\u36b2\u641c\u74f6\u5f02", "\ud959\ude14\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -591324772957986873L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\udb51\ude9f\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u3155", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b7\udc14\udb61\udf8f",
        39, 11080, -30634661, 8674256189893435867L, -81773L, true, false, (char) 14542, (char) 528,
        Double.longBitsToDouble(0x3feaa1d1c2b45617L), Double.longBitsToDouble(0x3fddc5d40f707836L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[41310, 0.7539832903128058]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u1478\u5eda", "\ud991\udeb7\udb8b\udeb2\ud926\udec5\ud9b7\udf95",
        22, 41310, 1356745080, -131574869259114996L, -3165L, true, false, (char) 16406, (char) 9705,
        Double.longBitsToDouble(0x3fe820a190b3f799L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 3, 18, "\uda65\udfc6\ud8a9\udce0\udb14\udf31\ud9d8\udfab\udb1b\udf72\ud823\udd86\uda61\udfa1", "\u5705\uca9c\ub4b4\u74e8\u5f02", "\udb55\udd47\udb8b\udeb2\ud91a\udfc5\ud99f\udf99",
        1, 10358, 1356745029, 1125210905635908694L, -3165L, false, false, (char) 16443, (char) 35453,
        Double.longBitsToDouble(0x3fe3886830b3f7c6L), Double.longBitsToDouble(0x3fe8aab3b1dc3260L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 0, 0, "\ud932\udc2e", "\u919d", "\000\000",
        11, 62715, 227608222, -8741904802809052393L, -100000L, false, false, (char) 50098, (char) 0,
        Double.longBitsToDouble(0x3fe0063000f1d2e1L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 15, 17, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud9c7\udcca\ud9ad\ude62\ud85a\udc14\uda67\uded5\udbf3\udd13\udac2\uddf9\udad3\udcbf\ud91e\udc65\ud903\udd2d\ud809\uddb0\udb89\udd2f\ud898\udfcd\udb8b\udeb2\ud91a\udfc5\ud8e7\udf52\udac4\udf83\udb6e\udd59\udad6\udeda\ud9ad\udd29\uda3f\ude87\udbf3\udc96\udb10\udcf4\ud987\udc18\ud9c4\udd8f\udbfe\udff0\udb97\uddf4\ud997\uddcb\udbfb\udc0c\ud993\udffd\ud901\udf12\uda80\udd0e\uda06\udc55\ud8b7\udc74\ud925\udd53\udb51\ude20", "\u40f9\ua2a5\u06be\u0a21\uaefb\u62ef\u5281\u4583\u99f7\u30fe", "\ud8e1\udc17\uda76\udeb4\uda62\uddc9\ud96f\udf6e\ud8f0\ude54\ud9cc\udc84\ud843\udf76\uda8b\udf7d\udbe3\udd5f\uda85\udd36\ud91d\udcdb\udae0\ude2a\ud9d4\udee9\uda95\udddb\ud93d\udc99\ue940\ud8df\udee1\uda72\ude74\uda82\udf9c\udadc\udf12",
        -4, 95464, -766661426, 5824291099335689611L, 55447L, true, false, (char) 11580, (char) 56402,
        Double.longBitsToDouble(0x3fc9b8eba4c8d5e4L), Double.longBitsToDouble(0x3fc09a6dff85db14L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 4, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u5f02", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        21, 16734, 1356745080, -131574866440542708L, 24995L, true, false, (char) 16406, (char) 53884,
        Double.longBitsToDouble(0x3fe38bec40b3f7c6L), Double.longBitsToDouble(0x3fe8aab3b1dc322eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 17, 1, "\udb2a\udd16\ud8a9\udcd1\ud922\udef5\udad7\udece\uda7b\udc7f\udb74\udc86\ud8f0\ude72", "\u2a74\u36b2\u641c\u74e8\u5f02", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        13, 16734, -1780594312, 1648781343715992085L, 96026L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3895ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.6104044033270319]]]\012",
        Z.run(T, 1, 11, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud8e5\udef6\ud9b6\udd97\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u5f02", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574869259114996L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\ud932\udc2e", "\u919d\u3820", "",
        23, 83489, 885833715, 977569867743887590L, -18336L, false, false, (char) 12819, (char) 29991,
        Double.longBitsToDouble(0x3fdf1d2000000000L), Double.longBitsToDouble(0x3fe477580000367aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 0, "\udbf9\udc7a\uda2b\udf9b", "\ucd61\u7fd0\u61c6\u11b5\u1f58\u1e87\u36b2\u641c\u74e8\u5f02\u7a53\u91db", "\ud91a\udfc5\ud9b3\ude99\udb61\udf8f\udb6e\uddc3\u6e3c\ud9ad\udd3f\uda3f\ude87\udbf3\udc96\udb10\udcf4\ud987\udc18\ud9c4\udd8f\udbfe\udff0\udb97\uddf4\ud997\uddcb",
        8, 64460, -1825206351, 487069340382501035L, -19001L, true, false, (char) 27798, (char) 24931,
        Double.longBitsToDouble(0x3fd5635143f4bdc4L), Double.longBitsToDouble(0x3fea59d1dca67728L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[91015]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\udbcc\udf3f", "\u1e87\u36b2\u641c\u74e8\u5f02\u7a53\u91db\u9c89\u7630\u68f4\uaeba", "\u6e3c\ud9ad\udd3f\uda3f\ude87\udbf3\udc96\udb10\udcf4\ud987\udc18\ud9c4\udd8f\udbfe\udff0\udb97\uddf4\ud997\uddcb\udbfb\udc0c\udbf5\udf4e\ud96f\udcf4\udbe8\udd4d\udbd0\udf68\uda0b\udd40\uda2b\udfeb\udb35\udda9\uda7f\udd03\udb59\udf34\uda18\ude83\udb36\udc3d",
        49, 91015, -1687667613, -2622359122452183310L, -95351L, true, true, (char) 36341, (char) 48590,
        Double.longBitsToDouble(0x3fefe060f114e354L), Double.longBitsToDouble(0x3fd25605d589610aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.20086231862091786, 0.7813391358435482, 0.20086231862091786]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 18, "\u50e1\ud8a9\udccc\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\ubff3\u069e\000\000\000", "\000",
        -5, -1000, 35072, 913966734L, -99909L, false, false, (char) 65118, (char) 28433,
        Double.longBitsToDouble(0x3fc9b5db40bcdf9cL), Double.longBitsToDouble(0x3fe900baee710ddaL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.6104044033270319]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[28036.5, 28477.5, 28077.5, 28481.0, 27765.0, 28618.5, 27841.5, 28468.5]]]\012",
        Z.run(T, 2, 11, 10, 1, "\uda10\ude62\ud84b\udca7\ud827\udf8c\ud95f\udf37\uda23\udfb1\ud969\udcbb\uda61\udfc9", "\u45fa\u36b2\u641c\u69c2\u5e1f", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574869259073780L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 16, 0, "\ud932\udc2e\udb38\udfd1\udb6c\udf82\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9\ud85a\udc5c\ud9bf\udc01\uda2a\udf0f\ud9c7\udd21\udad4\udd54\udb23\udc5b\ud903\udd2d\ud809\uddb0\ud8d5\uddc6\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99\udb61\udf8f\udb6e\uddc3\u6e3c\ud9ad\udd3f\u32dc\ud9ab\uded6\udb29\udf53\ud8cc\uddfc\uda24\udfdf\udbfe\udff0\udb97\uddf4\ud997\uddcb\udbfb\udc0c", "\u3da7\ubeb0\uc57c\u3850", "\ud855\udfba\ud892\udf29\ud89d\uddaa\ud845\ude2a\ud92e\udde9\ud904\udcbb\ud87e\udcc6\ud946\udeb3\uda87\udfdd\u0b8b\udaed\uded2\uda9e\udc82\udb5d\udd6a\ud976\udc42\udb82\udc91\uf6ca\uda67\udc80\udafa\udd0c\ud8bd\udd15\udb67\udf60\udbb5\udd33\uad24\ud942\udeff\ud9e8\udd70\udb8d\udfab\ud955\udc1a\ud879\udfdc\udb19\udf76\udb04\ude15\uda9b\udd0e\ud8e2\udd56\udb25\udfed\uda39\uddfc",
        53, 61512, -1757928639, -4061828650061465178L, -85159L, false, false, (char) 49473, (char) 54243,
        Double.longBitsToDouble(0x3fc5d4aa1af09918L), Double.longBitsToDouble(0x3fdac749be302740L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 16, 3, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud90d\udc16\ud9b6\uddac\ud8d4\udcc0\ud8a2\udee9", "\u1e81\u28c5\u63f4\u74e8\u5f02", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 39263, -1965143688, -131574869259105163L, -3165L, true, false, (char) 60394, (char) 54549,
        Double.longBitsToDouble(0x3fe05a8cb01b0757L), Double.longBitsToDouble(0x3fe8aab3b1dc3260L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\0121=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\012",
        Z.run(T, 2, 11, 11, 5, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud879\udfee\ud969\udcbb", "\u8de3\u641b", "\ud91e\udc65\ud903\udd2d\ud809\uddb0\ud8d5\uddc6\udb39\udeab\udae9\udcd3\udadb\udf52\ud9b3\ude38\udb61\udf8f\udb6e\uddc3\u6e3c\ud9ad\udd3f",
        40, 26293, -1372246339, 4028391582705977391L, 47057L, true, false, (char) 32651, (char) 29756,
        Double.longBitsToDouble(0x3fda2aaf220690faL), Double.longBitsToDouble(0x3fed04737deb7e8dL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[14692, 0.17574987017242338, 913966734]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 12, 0, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u4d95\u36b2\u641c\u74e8\u5f02", "\000\000\ud91a\udfc5",
        35, 14692, 913966734, 5827175747578269019L, -81773L, true, false, (char) 35453, (char) 19531,
        Double.longBitsToDouble(0x3fc67ef8c45559d8L), Double.longBitsToDouble(0x3fddc32607b42718L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[28036.5, 28477.5, 28077.5, 28481.0, 27765.0, 28618.5, 27841.5, 28468.5]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[28036.5, 28477.5, 28077.5, 28481.0, 27765.0, 28618.5, 27841.5, 28468.5]]]\012",
        Z.run(T, 2, 10, 10, 8, "\ud932\udc2e\ud8a9\udcd1\ud88a\udc48\ud984\udce0\udaa7\udfa9\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u5f02", "\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574869259114996L, -3072L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.6104044033270319]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.6104044033270319]]]\012",
        Z.run(T, 2, 11, 11, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\uda18\udc8f\ud9b6\udd93\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u5f02", "\udb39\udeab\udb94\udcb2\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574869259114996L, -3165L, true, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27625.5, 28587.5, 28077.5, 28481.0, 27753.0, 28192.5, 27841.5, 28468.5]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 1, 1, "\ud932\udc2e\ud8a9\udcd1\uda11\udf22\ud8bc\udeef\udbb6\udeac\ud969\udcaa\uda61\udfc9", "\u1e87\u36b2\u4a9b\ucc23\u4d59", "\ud803\udf87\udb8b\udeb2\ud902\udc71\ud9b3\ude99\udb61\udf8f",
        50, 11080, -30645669, -2747998366568186532L, -81773L, true, false, (char) 35453, (char) 19531,
        Double.longBitsToDouble(0x3fc67ef8c45559d8L), Double.longBitsToDouble(0x3fddc3260340ef6cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[32318, 0.17574987017242338, -951416335]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[32318, 0.17574987017242338, -951416335]]]\012",
        Z.run(T, 2, 11, 11, 1, "\ud932\udc2e\ud8a9\udcd1\ud9d8\udcb7\ud991\udf7a\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87", "\ud91e\udc65\ud903\udd2d\ud809\uddb0\ud8d5\uddc6\udb39\udeab",
        51, 32318, -951416335, -1471787830027352434L, 71827L, true, false, (char) 28204, (char) 19531,
        Double.longBitsToDouble(0x3fc67ef8c45559d8L), Double.longBitsToDouble(0x3fddc3260bb3281eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 6, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\u0a3e\udb68\udfbd\udb82\udc1f", "\u4187\ua416\ucb85\u74e8\u5f02\u7a53", "\ud8e0\udc7b\ud86b\uddc8\ud94b\udfe5\udb61\udf8f\udb2d\udda3\u6e9f\ud9aa\udf59\ud953\ude03\ud95d\uddfb\ud873\udd79\uda11\udcde\ud9c4\udd8f\udbfe\udff0\ud898\udded\ud997\uddcb\udbfb\udc0c\udaed\ude0a\ud82d\ude2d\ud817\udcf1\ud897\udd35\ud994\udd38\uda0a\udfcc\ud854\udfb9\ud973\udc1f\udb04\udfb7",
        41, 55898, -236965631, -2894147241715390582L, 55455L, false, true, (char) 43982, (char) 43888,
        Double.longBitsToDouble(0x3fcecaacdb435a88L), Double.longBitsToDouble(0x3fa124e7c50383b0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:org.jfree.data.category.DefaultCategoryDataset@367 |a2=[[Ljava.lang.Number;:[[[]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 1, "\ud94e\udcc3\ud8c0\udf1d\ud96c\udefa", "\u72cd\u5c24\u11b5", "\uda9b\udf6a\udad3\udcbf\ud91e\udc65\udaad\udcc3\ud809\uddd6\ud8d5\uddc6\udb39\udeab\ud91a\udc59\uda17\udc78\ud9b3\ude99\udb61\udf8f\udb6e\uddc3\u6eaf\ud9ad\udd3f\uda3f\ude87\udbf3\udc96\udb4b\ude41\ud98d\ude46\ud974\udeca\udbe6\ude11\udb97\uddf4",
        12, 94773, -509394468, -4315755388138991678L, -55220L, false, true, (char) 15868, (char) 39901,
        Double.longBitsToDouble(0x3fe029d56c108d6bL), Double.longBitsToDouble(0x3fe5f249f8d0879cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.6104044033270319, 0.2708376382666522, 0.6104044033270319]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 0, "\ud932\udc2e\uda21\udd0d\000\000\000\000\uda61\udfc9", "\000\000\u641c\u74e8\u5f02", "\udb39\udeab\udba2\ude1d\u4d4a\ud9b3\ude99",
        31, 16734, 14567800, -144115190215924212L, -100000L, false, false, (char) 16406, (char) 35453,
        Double.longBitsToDouble(0x3fe3886ed0b3f7c6L), Double.longBitsToDouble(0x3fd1556763b864c0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.10817994177341461, 38633]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\000", "\uc951", "",
        -2, 38633, -1618642511, 3804626835837288448L, -32524L, false, true, (char) 3755, (char) 59686,
        Double.longBitsToDouble(0x3fbbb1ae40000000L), Double.longBitsToDouble(0x3fc898e00003ae4cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.10346868996438385]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 13, "\ud932\udc2e", "\uc602\u13fa", "\udb97\uddc0",
        29, 62715, -1248374739, -8741904801517206761L, -32436L, false, true, (char) 3755, (char) 59686,
        Double.longBitsToDouble(0x3fba7cec8f8e9708L), Double.longBitsToDouble(0x3fc898e95a3bae4cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[8544, 0.3508760491133074, -1972079170]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9\ud85a\udc5c\ud9bf\udc01\uda2a\ude40\uda9b\udf6a\uda51\ude34\ud879\udeb3\ud903\udd2d\ud809\uddb0\ud8d5\uddc6\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99\ud86a\ude5c\ud8df\udc49\u6e3c\ud9ad\udd3f\uda3f\ude87\udbf3\udc96\udb10\udcf4\ud987\udc18\ud9c4\udd8f\udbfe\udff0\udb58\ude60\ub51c\udab3\uddb3\uda12\udcc6\udadd\udd33\ud829\udf52\uda3d\udf42\uda54\udfe6\udb0a\udf7f\ud822\udc0e\uda71\ude68\ud99c\udf47\ud8ae\udd62\ud808\udedc\ud8f3\udeb9\udbf9\udcc3\udad8\udc8a", "\uce7b\u89c1\u9d46\u0334", "\ud88d\uddce\ud892\udf17\ud8cf\ude75\udb00\udefa\ud9c2\udf7a\udb51\udff2\ud9ef\udfbc\udb63\udfb4\u0aa4\udaa5\udf20\uda1f\uddf2\uacaf\u9423\ud905\udee9\uda93\udf80\ud83e\udc77\udb52\udde5\ud8b0\udc49\ud882\udc7a\ud86e\ude80\ud965\udf45\uda4f\udcd8\udae5\udf49\ud876\udd97\uda0f\udf4e\udaea\ude13\u739d",
        43, 8544, -1972079170, 4622309874915969641L, -34195L, true, false, (char) 40409, (char) 22785,
        Double.longBitsToDouble(0x3fd674c0d0f90bccL), Double.longBitsToDouble(0x3fde7b74e0c8591aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 13, 1, "\ud871\udc90\ud9bd\udd1b\udbcb\udc09\ud97d\udec4\ud9e7\udea3\ud969\udcbb\uda61\udfc9", "\u0b55\u36b2\u641c", "\ud809\uddb0\ud8d5\uddc6\udb39\udeab\udb8b\udeb2\ud91a\udfc5\ud9b3\ude99\udb86\udf8f\udb6e\uddc3\u6e3c",
        33, 94763, -380338707, -5847214118453921587L, 60544L, true, false, (char) 34937, (char) 32651,
        Double.longBitsToDouble(0x3fddc32602233e82L), Double.longBitsToDouble(0x3fec2eb016b84e19L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 4, "", "", "\ud9b6\uddac",
        34, 43718, 1569276633, -6952016647774486541L, 64838L, true, false, (char) 57937, (char) 38555,
        Double.longBitsToDouble(0x3fd54595a5bf8764L), Double.longBitsToDouble(0x3fd9e5b336c33b16L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 16, 1, "\uda4c\udc5b\udafb\udfac\udbd6\udd67\ud965\udf52\ud9b6\uddac\ud969\udcbb\uda51\udc84", "\u1e87\u5e93\u9c77\u3077\u7594", "\uda13\udea9\uda39\uddf7\ud968\udf82\ud9b3\ude46\ud864\ude51\udba1\udd88\u6e3c",
        29, 19660, -380338707, -5847214118453921587L, 60544L, true, false, (char) 34937, (char) 32651,
        Double.longBitsToDouble(0x3fddc326091ef728L), Double.longBitsToDouble(0x3fbc3f97a1323378L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[78735, 0.6104044167123497]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27939.0, 28139.5, 27629.5, 28491.0]]]\012",
        Z.run(T, 2, 11, 10, 1, "\uda0b\udc1b\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\udba2\udef5", "\u0c8b\u36bb\u641c\u74e8\u5f02\u7a53\u7236", "\uda76\udc07\ud80b\udec6",
        10, 78735, -92751835, 6098024597112142143L, -3165L, true, false, (char) 16406, (char) 4229,
        Double.longBitsToDouble(0x3fe3886ed7e3a1c6L), Double.longBitsToDouble(0x3fe42e0a91371cabL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 13, 1, "\uda0b\udc1b\u3d05\000\ud965\udf16\000\000\000", "", "",
        -5, 25192, -1641075983, 6438731759008006484L, 83789L, false, false, (char) 35537, (char) 13839,
        Double.longBitsToDouble(0x3fe4775c9878367aL), Double.longBitsToDouble(0x3ebe000000000000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.7863676396608587, 0.8045807853640038, 0.7863676396608587]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 1, "\uda0b\udc1b\ud8a9\udcd1\ud96c\udefa\ud965\udf16\udb2b\udffc\ud97e\udf27\udab3\ude4a", "\u9cc6\u574e\u2c10\u5155", "\ud8d5\udde4\udb39\udeab\ud8fe\udf0c\ud856\udcb2\ud99b\ude99\udb73\udd8f\udb6e\uddc3\ud951\ude5f\udadd\ude0c\ud850\udcaf\udbf3\udc96\uda61\udd9c\ud97e\udef8\ud9c4\udd8f\udbfe\udff0\ud9b4\udce3\ud963\udc31",
        47, 28063, 59636998, -8409779663869190742L, -90188L, false, false, (char) 51778, (char) 31026,
        Double.longBitsToDouble(0x3fe929ec77df3c37L), Double.longBitsToDouble(0x3fe9bf2034041bc9L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27955.5, 28401.0, 28060.0, 28501.5, 28016.0, 28163.5]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 9, 0, "\udb4e\ude60\ud8a9\udcd1\udb35\ude7f\ud965\udf16\udab7\udc0b\ud901\udd1c\udb9a\uddbd", "\u90e5\u4f68\u641c\u74e8\u6d6f\u7a54\u91db\u97f0\u3d99\u6978\uaeba\u7a16\uc1f7", "\uda97\ude12\udb68\udedb\udb10\udc37",
        57, 23308, 232420128, -592717644449804109L, 45793L, false, true, (char) 63947, (char) 13594,
        Double.longBitsToDouble(0x3fe882fc3805c9d7L), Double.longBitsToDouble(0x3fe3d8864a8e62b9L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 4, 0, "\000\ud8a9\udccc\ud96c\udefa", "\u295d", "\ud9bf\udc01\ud809\udfff",
        8, 68678, -766967017, 1499070464L, -53656L, true, false, (char) 29991, (char) 23521,
        Double.longBitsToDouble(0x3e4a3bac00000000L), Double.longBitsToDouble(0x3fbe0d9eaada8000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27681.5, 28252.5]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 13, "\ud945\udeac", "\u6db3\u2ab1", "\ud873\udce9",
        32, 85483, 218103808, -8741904803580804329L, 94560L, false, true, (char) 3755, (char) 59686,
        Double.longBitsToDouble(0x3fe37635c9f109e1L), Double.longBitsToDouble(0x3fc898e95a3bae4cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.5126883461705063, 0.05846453984404654, 0.5126883461705063]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[0.5126883461705063, 0.05846453984404654, 0.5126883461705063]]]\012",
        Z.run(T, 2, 11, 11, 20, "\ud995\udd75\udb18\ude18\udbe4\udf2a", "\u7125", "\ud9bf\udc01\uda28\udd0f\ud9e8\udf08\udbdd\udca8\ud9b1\udc55\udb6e\udc57",
        55, 20724, -1223472392, -2902233429021970151L, -44900L, false, false, (char) 23773, (char) 57016,
        Double.longBitsToDouble(0x3fe067f163faf700L), Double.longBitsToDouble(0x3fadef106d363470L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u066d\u862b\u4c68\u75ce\u6ca4]] |a1=[Ljava.lang.Comparable;:[[\uda65\udfc6\ud8a9\udce0\udb14\udef3\ud9d8\udfab\ud88e\udc2c\ub0a6\uda2d\udcaf, \u066d\u862b\u4c68\u75ce\u6ca4]] |a2=[[D:[[[27792.5, 28493.5]]]\012",
        Z.run(T, 1, 9, 10, 16, "\uda65\udfc6\ud8a9\udce0\udb14\udef3\ud9d8\udfab\ud88e\udc2c\ub0a6\uda2d\udcaf", "\u066d\u862b\u4c68\u75ce\u6ca4", "\ud951\udecb",
        -3, 32318, 125775771, -8677548850743736690L, 1723L, false, false, (char) 6242, (char) 14353,
        Double.longBitsToDouble(0x3fcc047b52e0df9cL), Double.longBitsToDouble(0x3fdc037eb462d46cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[39549]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\u5f02]] |a1=[Ljava.lang.Comparable;:[[\uda10\udc89\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud983\udf12\uda61\udfb2\ud85a\udc5c\ud9bf\udc01\uda2a\udf0f\ud828\udfd0]] |a2=[[D:[[[12137.0]]]\012",
        Z.run(T, 2, 11, 9, 19, "\uda10\udc89\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud983\udf12\uda61\udfb2\ud85a\udc5c\ud9bf\udc01\uda2a\udf0f\ud828\udfd0", "\u5f02", "\udb39\uddf7\udb8b\udeb2\uda1f\udc46\ud9b3\uddec\ud978\udd11\ud8d6\udeee\u6e3c\uda96\ude74\uda84\ude97",
        13, 39549, 937933005, 1683510835769031456L, -5971L, true, true, (char) 29706, (char) 29098,
        Double.longBitsToDouble(0x3fe092a9b2f0e53fL), Double.longBitsToDouble(0x3fa445261bc12390L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 17, 19, "\udb2a\udd16\ud8a9\udcd1\ud922\udef5\udad7\udece\uda7b\udc7f\ud836\ude47\udb00\udfd4", "\ud1e6\uac4e\u9823\u74e8\u15c8\u7a53\u91db\u9c89\u7630\u17f4\uaeba\u5918\uc71e\u66df\u020a\ud4f4\ua1bc", "\ud9c4\udd8f\uda5e\uddb5",
        5, 81803, 535945950, -3440109693260887082L, -50211L, false, false, (char) 51125, (char) 15416,
        Double.longBitsToDouble(0x3fd2992e93af955eL), Double.longBitsToDouble(0x3fdd9720d40ad344L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[-24.0]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 0, "\udb38\udd20\ud871\ude2d\ud838\udefc\ud965\udee0\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\ubff3\u069e\000\000\000", "\000",
        -5, -1000, 35072, 913966734L, -99909L, false, false, (char) 65118, (char) 28433,
        Double.longBitsToDouble(0x3fc9b5db40bcdf9cL), Double.longBitsToDouble(0x3fe900baee710ddaL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[49300, 1422210422, 43]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[D:[[[27920.0, 28549.0, 28070.5, 28190.5, 27692.5, 28265.5, 28121.0, 28210.0]]]\012",
        Z.run(T, 2, 11, 10, 1, "\uda10\ude62\ud84b\udca7\ud827\udf8c\ud95f\udf37\uda23\udfb1\ud969\udcbb\uda61\udfc9", "\u45fa\u36b2\u641c\u69c2\u5e1f\u7a53\u91db\u9c89\u7630\u68f4\uaeba\ua08e\uc71e\u6950\ud330\ud7dd\u8b0e\u1d90\u4b0f\ua3df\u3b8b\u34b1\u072d\u84c9\ub6cb\u343e\u0cfa\u20f3\u2a71\u4c60\u0dd6\u770e\u2e9f\ua56f\ud2ea\u3cb2\u40ca\u528b\u1487", "\uda50\udf3a\udb7d\udc6d\ud889\udd03\udbe2\udc94\udb0d\udcff\ud929\udd5e\udae0\udef0\u1888\uda5b\uddb4\ud952\udd53\ud991\udd3c\ud955\udfc2\u08a2\ud9e5\udd28\uda12\ude2b\ud9d1\udef7\ud946\udc77\uda39\udf0a\ud916\udfe6\ud840\udf9f\udab6\udd44\uda20\udfa0\ud84b\ude24\ud85f\udf5c\ud8a7\udfdd\ud972\ude2a\ud805\udd14\ud891\udf9f\ud8ae\udd13\udaed\udc06\ud931\ude61\ud9ba\udce6\ud805\udc2f\udae8\udd0a\ud853\udfa9\udae0\udc7f\uda26\udcdb\udabb\udd26\udaf3\ude88\ud85c\udf97\udb08\uddb7\u0aab\uda3d\udf10\uda3f\udff4\uda53\udf63\udb2e\udec1\ud880\udcb8\u580c\udac2\udd6c\uda36\ude07\ud9bd\udfd5\ud812\ude36\ud8cb\udcae\ud9ae\ude1f\u0911\uda2e\udf0b\udba8\udc90\uda30\uddeb\ud882\ude9e\udbe9\ude67\udba1\uddc3\u3a0d\udace\udcf2\u292b\ud8bf\udebb\ud87a\udd2e7\udb4a\udcbb\ud880\uddad\u4e77\uda5d\udd14\udac1\udc66\ud9de\udc08\ud849\udf0c\udbf3\ude58\ud8e8\ude69\udbdc\ude7d\udb13\udc0b\ud940\uddc7\ud8f1\udff2\ud827\udc3d\ud91a\udf96\ud922\udd65\uda31\udc4c\ud8c8\udc6b\ud9b7\udcfb\u9682\udbe1\ude18\ud992\udd9c\uda60\udf81\ud92d\uddb1\udbb9\udf85\udbd1\ude7a\udbc3\udd7a\ud9df\udfd8",
        43, 49300, 1422210422, 278250672062883700L, -97061L, true, true, (char) 65422, (char) 29721,
        Double.longBitsToDouble(0x3fe2e516350cf451L), Double.longBitsToDouble(0x3fec3b3a69c6c8bcL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[43718, 1569276633, -5]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 0, "\u50e1", "", "",
        -5, 43718, 1569276633, 0L, -2694L, true, true, (char) 64826, (char) 38555,
        Double.longBitsToDouble(0x3e30000000000000L), Double.longBitsToDouble(0x3fe09db8980000b9L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 13, 1, "\uda0b\udc1b\u3d05\000\ud965\udf16\000\000\000", "", "",
        44, 88491, -1641075983, 6438731759008006484L, 83789L, false, false, (char) 35537, (char) 13839,
        Double.longBitsToDouble(0x3fe4775c9878367aL), Double.longBitsToDouble(0x3ebe000000000000L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[20611]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 0, "\u50e1", "", "",
        53, 20611, 1569276633, 0L, -2694L, true, true, (char) 64826, (char) 38555,
        Double.longBitsToDouble(0x3e30000370000000L), Double.longBitsToDouble(0x3fe09db8980000b9L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a2=[[Ljava.lang.Number;:[[[16734, 0.3045072373120171]]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 1, "\ud932\udc2e\ud8a9\udcd1\ud96c\udefa\ud965\udf16\ud9b6\uddac\ud969\udcbb\uda61\udfc9", "\u1e87\u36b2\u641c\u74e8\u5f02", "\udb39\udeab\ud8bb\udeaa\ud91a\udfc5\ud9b3\ude99",
        22, 16734, 1356745080, -131574867933517731L, -3165L, true, false, (char) 16406, (char) 23704,
        Double.longBitsToDouble(0x3fd37d0bec69a08eL), Double.longBitsToDouble(0x3fafbcb2d16a31e0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 1, "\ud932\udc2e\udbd0\udd2b\ud8ec\udd44\ud965\udfb8\ud864\ude89\ud8a5\uddd4\udbea\udd8c\ud85f\udd2a\udba4\ude46\udb8d\udcc5\udb5b\udedc", "\u323b\uabab\u1a30\u8f86\u6f44\u68f4\uaeba\ua08e\uc71e\u0264\u6581", "\uc28d\ud843\ude0e\udb4f\ude59\u1dcf\ud91e\uded7\uc334\udbfb\udc0c\ud9ae\udf64\udb8e\ude5e\udaef\udd99\udb95\udc22\udb2f\udd6e\ud8d1\udef3\udbb7\udd12\ud945\uddc4\ud8d8\udc09\udafa\ude8d\udb12\udc37\ud81f\udca9\ud828\udd19\ud8f6\udf74\uda14\udfc4\ud853\ude8d\uda3f\ude86\uda2e\ude6e\ud949\udd58\ud8ce\ude08\ud9b5\ude46\ud92a\udcfa\ud8c0\udcdb\ud842\ude16\ud9fa\udd46\ud986\udfe0\u08f6\udb82\udebe\ud81b\udcb2\uda63\udd18\uda7e\udf2c\ud8db\uddb0\ud8a4\udf0d\udb7f\udf23\ud8a1\udecd\ud8e1\udeb2\ud8fa\uddec\ud9d1\udcbb\udbf8\udfcb\ud9ae\uddaf\ud8bb\udd8b\ud8f8\uddcc\u2bb6\ua194\udbe6\ude68\uc3e2\ud953\udcc7\uda98\udfb3\udaf3\ude23\uda67\udf81\u24bb\ud81d\udf4a\udb3b\udc1c\ud8c9\udcdf\udab8\ude8e\udb37\udc9d\ud81e\uded0\udab7\udd7e\uda53\udf56\ud835\udd35\ud9b4\ude63\udb8a\udd9a\ud83e\udcfa\ud80c\udedd\ud989\udd65\ud9e5\udd02\uda6b\udf17\udb15\udebb\u0acf\udbbc\udeec\udba0\udc39\uda28\udd2c\uda3e\udf50\ud8d9\uddb8\ud965\udfe4\ud9be\udf63\ud817\udc9c\uda6d\udfba\ud8d5\udee9\ud9c5\udf77\ud958\udef3\ud939\udd03\uda36\uddf9\ud94d\udf5d\udb66\udeb8\udb72\ude42\udace\udc8f\uda72\udfa7\ud9ce\udefa\udb17\udd71\ud967\udc7b\udbbd\ude4c\udbe0\udd54\udbf9\udfc0\ud8a5\udc7e\uda54\udd2b\ud86d\udee6\ud9d2\udd6c\udbd1\udf21\udba6\udf7b\ud85c\uddfc\ud8e7\udfc4\ud825\udc54\udbd0\ude85\ud8f4\udc52\udaed\uddc1\ud96b\udfe0\udbec\udcfe\ud998\ude09\udbe3\udea9\ud82f\udd23\udaed\ude6f\uda56\udc92\udaf9\udde3\uda20\udffb",
        46, 23862, 1046538020, -3352954875516481698L, -96985L, false, true, (char) 55551, (char) 47086,
        Double.longBitsToDouble(0x3fec2cb853094861L), Double.longBitsToDouble(0x3fd64d2324d45440L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 1, "\ud9a6\udc28\udbd0\udd2b\ud8ec\udd44\ud965\udfb8\ud864\ude89\ud8a5\uddd4\udbea\udd8c\ud85f\udd2a\udba4\ude46\udb8d\udcc5\udb5b\udedc", "\u323b\u89b6\u1a30\u8f86\u6f44\u68f4\uaeba\ua08e\uc71e\u0264\u8762", "\uc28d\ud843\ude0e\udb4f\ude59\u1dcf\ud91e\uded7\uc334\udbfb\udc0c\ud9ae\udf64\udb8e\ude5e\udaef\udd99\udb95\udc22\udb2f\udd6e\ud8d1\udef3\udbb7\udd12\ud945\uddc4\ud8d8\udc09\udafa\ude8d\udb12\udc37\ud81f\udca9\ud828\udd19\ud8f6\udf74\uda14\udfc4\ud853\ude8d\uda3f\ude86\uda2e\ude6e\ud949\udd58\ud8ce\ude08\ud9b5\ude46\ud92a\udcfa\ud8c0\udcdb\ud842\ude16\ud9fa\udd46\ud986\udfe0\u08f6\udb82\udebe\ud81b\udcb2\uda63\udd18\uda7e\udf2c\ud8db\uddb0\ud8a4\udf0d\udb7f\udf23\ud8a1\udecd\ud8e1\udeb2\ud8fa\uddec\ud9d1\udcbb\udbf8\udfcb\ud9ae\uddaf\ud8bb\udd8b\ud8f8\uddcc\u2bb6\ua194\udbe6\ude68\uc3e2\ud953\udcc7\uda98\udfb3\udaf3\ude23\uda67\udf81\u24bb\ud81d\udf4a\udbd5\udc4a\uda2f\udd40\udab8\ude8e\udb37\udc9d\ud81e\uded0\uda36\udcfc\uda53\udfa5\ud835\udd35\ud9b4\ude63\udb8a\udd9a\ud83e\udcfa\ud80c\udedd\ud989\udd65\ud9e5\udd02\uda6b\udf17\udb15\udebb\u0acf\udbbc\udeec\udba0\udc39\uda28\udd2c\uda3e\udf50\ud8d9\uddb8\ud965\udfe4\ud9b3\udc63\ud8ac\ude9e\uda6d\udfba\ud8d5\udee9\ud9c5\udf77\ud958\udef3\ud8fb\udd04\uda36\uddf9\ud94d\udf5d\udb66\udeb8\udb72\ude42\udace\udc8f\uda72\udfa7\ud9ce\udefa\udb17\udd71\ud967\udc7b\udbbd\ude4c\udbe0\udd54\udbf9\udfc0\ud8a5\udc7e\uda54\udd2b\ud86d\udee6\ud9d2\udd6c\udbd1\udf21\udba6\udf7b\ud85c\uddfc\ud8e7\udfc4\ud825\udc54\udbd0\ude85\ud8f4\udc52\udaed\uddc1\ud96b\udfe0\udbec\udcfe\ud998\ude09\udbe3\udea9\ud82f\udd23\udaed\ude6f\uda56\udc92\udaf9\udde3\uda20\udffb\ud9fb\uddb9\uda7d\udc51\ud816\uded1\udbfd\ude8f\ud84a\ude40\uda26\udcb3\uda35\uddd4\ud893\udec7\uda43\udd46\uda00\udc3d\u1bc9\u2856\uda1e\udfdf\ud8e4\udc11\udaa9\udc2b\ud8b8\uddeb\ud9cd\udff0\udbf4\ude55\ud8cc\ude8f\udb85\udd96\ub832\uda45\udd04\ud839\udd35\udbcb\uddbb\ud981\uddb1\uda3b\udf74\010\ud9e2\udfa8\udb38\udcc5\udaff\udf72\udaf2\udd7e\udb80\uddcf\udb5a\ude4d\udb99\ude56",
        31, 3528, -1248127495, -3243608293779433524L, 85477L, true, false, (char) 7161, (char) 41506,
        Double.longBitsToDouble(0x3fe818548bb2cd69L), Double.longBitsToDouble(0x3f9dc367ae3b48c0L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\000]] |a1=[Ljava.lang.Comparable;:[[\udb13\ude1f]] |a2=[[D:[[[-24.0]]]\0121=org.jfree.data.category.DefaultCategoryDataset:@? |a0=[Ljava.lang.Comparable;:[[\000]] |a1=[Ljava.lang.Comparable;:[[\udb13\ude1f]] |a2=[[D:[[[-24.0]]]\012",
        Z.run(T, 2, 9, 9, 0, "\udb13\ude1f", "\000", "\ud8ce\udd70",
        17, 72909, 65, 496075750L, -45457L, false, false, (char) 0, (char) 19054,
        Double.longBitsToDouble(0x3fd1b9ef800021e2L), Double.longBitsToDouble(0x3fb344e279a40710L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|calculatePieDatasetTotal|org.jfree.data.pie.PieDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|calculateStackTotal|org.jfree.data.xy.TableXYDataset,int|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|java.lang.Comparable,org.jfree.data.KeyedValues|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|[Ljava.lang.Comparable;,[Ljava.lang.Comparable;,[[D|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|java.lang.String,java.lang.String,[[D|static",
    "M|org.jfree.data.general.DatasetUtilities|createCategoryDataset|java.lang.String,java.lang.String,[[Ljava.lang.Number;|static",
    "M|org.jfree.data.general.DatasetUtilities|createConsolidatedPieDataset|org.jfree.data.pie.PieDataset,java.lang.Comparable,double|static",
    "M|org.jfree.data.general.DatasetUtilities|createConsolidatedPieDataset|org.jfree.data.pie.PieDataset,java.lang.Comparable,double,int|static",
    "M|org.jfree.data.general.DatasetUtilities|createPieDatasetForColumn|org.jfree.data.category.CategoryDataset,int|static",
    "M|org.jfree.data.general.DatasetUtilities|createPieDatasetForColumn|org.jfree.data.category.CategoryDataset,java.lang.Comparable|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateDomainBounds|org.jfree.data.xy.XYDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.category.CategoryDataset,boolean|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset|static",
    "M|org.jfree.data.general.DatasetUtilities|iterateRangeBounds|org.jfree.data.xy.XYDataset,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
