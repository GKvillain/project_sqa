package org.jfree.chart.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class ShapeUtilities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u83ce", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        17, -197, -282346269, -1127308761042059599L, 99605L, true, true, (char) 36267, (char) 24006,
        Double.longBitsToDouble(0x3fe9dfa981fcdfacL), Double.longBitsToDouble(0x3fe9111542fda851L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 14, "\uda67\udc0e", "\uc57f\u52b8\ubabc\u88fe", "\ud90b\udfe2\udb1d\udeb3\ud95d\udcf2\ud934\udd1a\udb49\uddb0\udb18\udc30\ud8dc\udc0a\ud8d6\ude6d\udb9b\ude00\ud8e3\udd4b\udbc0\udf5e\udbd3\udc46\u1034\udbec\ude5b\uda94\udef6\ud806\udccc\ud9a7\udc9b\udb95\udd79\u5d48\ud92e\udcf5\ud89f\uddf7\uda12\udf0c\uda48\udfb2",
        13, 79813, -193562485, 2001208437001543732L, -40653L, false, true, (char) 57728, (char) 63081,
        Double.longBitsToDouble(0x3fe8518254aa40b2L), Double.longBitsToDouble(0x3fc61cbfbe85fed0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb", "\u753f\u7cff\u66d7\u83ce\ub4e5\u8f23\u933a\u8f9d\ua99e\u450b\u6fd8\u3604\ub0f0\u341d\ucc33\ua96a\u518e\u9ba7\u2864\u504d", "\ud89f\uddf7\udbe1\udc74\ud92f\udf6d\ud8bc\udc29\udbdb\udc34\udb26\udc69\ud987\udf4a\ud860\ude26\udb5e\udc9f\uda71\udd72\udb73\udc42\udb79\ude77\ud93e\udf69\ud98a\udde8\udad4\udf98\ud90d\udc3b\udad2\udee3\udbc9\uddc9\udb28\udf83\uda45\ude4e\udbdd\udf14\udb85\uddea\ud8bb\udd74\ud8c7\udcc0",
        52, 51579, -486283719, -8258141347227109249L, -12545L, false, true, (char) 35108, (char) 37176,
        Double.longBitsToDouble(0x3fe3b5583c6f0b38L), Double.longBitsToDouble(0x3fbe6906de3d8588L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 0, 14, 11, "\udade\udf06\ud8f7\udc29\udab3\ude28\ud896\ude5a\ud938\uddbb\ud8b3\uddf2\udb0e\udf48\ud83b\udf80", "\u83ce\u18e2\u8f92", "\ud828\udf67\udb5f\ude04\udb9b\ude70\uda1d\udf88\u889c\udb8f\udca4\ud83f\uddb9\udbec\uddd6\udbf3\ude32\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb75\udc06\ua21b\udae9\udfc2\ud92f\udf19\ud852\udc01\ud8a5\udd39\ud94c\udf2d\ud89f\udfff\u0fe0\udbe7\udc59\ud94a\udd18",
        15, 25220, 1002014455, 7997799705424831044L, 15095L, true, false, (char) 32116, (char) 3892,
        Double.longBitsToDouble(0x3fc60df0fe7a9028L), Double.longBitsToDouble(0x3fe264e0f75a6875L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 6, 1, 0, "\ud9ca\udefc\u9f22\ud92c\udf76\u45f2\ud938\udd84\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u83ce", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        17, -197, -282346269, 719707373233L, 99605L, false, false, (char) 0, (char) 23838,
        Double.longBitsToDouble(0x3fe9dfa98000dfacL), Double.longBitsToDouble(0x3fe8000002fda851L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 19, 1, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u83ce", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        17, -197, -282346269, -1127308761042059599L, 99605L, true, true, (char) 36267, (char) 24006,
        Double.longBitsToDouble(0x3fe9dfa981fcdfacL), Double.longBitsToDouble(0x3fe9111542fda851L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 1, 14, "\udade\udf06\ud8f7\udf29\uda55\udf19\ud979\udcc4\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72\udb89\ude64\ud90b\udfe2\udb1d\udeb3\ud95d\udcf2\ud934\udd1a\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52\udb9b\ude00\uda1d\udf88\ud834\udfe5\udbe7\uddbb\ud9c0\udc31\udbec\ude5b\uda94\udef6\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb75\udc06\ud89f\uddf7\ud9ab\udd99\ud8d4\ude3f\uda04\udfb3\ud81d\ude43\u637d\u6dc1\ud95b\udcc4\udb2c\udf47\udafd\udf50\udbf7\udec5\ud97d\ude6e\ud4dc\udb56\udd42\ud80c\udee6", "\ua41b\u44d1\u74fe\u1a9c\uaa6f\u954a", "\uda34\uded0\uda61\udfc1",
        14, 17907, 1972565395, -6764610227902779740L, 98045L, true, true, (char) 39619, (char) 62646,
        Double.longBitsToDouble(0x3fe21cbe733eb0a4L), Double.longBitsToDouble(0x3fde92d7f3147014L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 20, "\udade\udf06", "\u2d35\u8f52\uc56d\u3e40\uc884", "\udb1d\udeb3",
        29, 98488, -1739297862, 2833226999709702308L, -66589L, true, false, (char) 35281, (char) 31190,
        Double.longBitsToDouble(0x3fe58f82c98791e6L), Double.longBitsToDouble(0x3fb2e197ac0db380L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 1, 15, 0, 1, "\udade\udf06\ud8f7\udc29\udb54\udcff\ud9db\udca7\ud938\ude27\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u83ce", "\udb49\uddb0\udb33\udf30\ud811\ude45\ud8ca\uded2",
        -5, 16465, -2110622759, -1127308761042059599L, 99605L, true, true, (char) 36267, (char) 24006,
        Double.longBitsToDouble(0x3fb78bef1c55b188L), Double.longBitsToDouble(0x3fbe350bfaab1d10L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 14, "\ud97c\ude0f\ud92a\ude83\uda55\udf19\ud87f\udf29\udb52\uddc1\uda07\udcdd\u1344\ud85c\udd72", "\ud117", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        40, -197, -1060324125, 3762421843848969656L, 99605L, true, true, (char) 36267, (char) 59820,
        Double.longBitsToDouble(0x3fe9dfa981fcdfacL), Double.longBitsToDouble(0x3fe9111542fda851L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 20, 3, 14, "\ud8ee\udc9d\u89c7\udb4a\ude56\ud87f\ude43\ud938\uddbb\udb38\udcb8\udab1\udfc1\ud85c\udd72\udb89\ude64\ud90b\udfe2", "\ud1c9\ub5f0\u4221\u887d\u450b\u03d9\u3604\u0e6c\ub3fb\ucb9d\u195e\u518e\ud493\ua1f5", "\udb75\udc06\udbe4\udfb9\udb32\udff5\ud968\udf88",
        44, 67004, -219559820, -8011317477238884521L, 30820L, false, true, (char) 41981, (char) 17884,
        Double.longBitsToDouble(0x3fe8044837a09073L), Double.longBitsToDouble(0x3fe02b9077777800L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 1, 8, 1, 14, "\udade\udf06\ud90a\udc29\ud8cd\udda3\ud928\udf32\ud940\udd24\uda07\udcdd\udb0e\udf48\ud911\ude4b", "\u83ce", "\u724a\uda9f\udc27\ud9e5\udd7a\ud839\ude85",
        51, 56805, -471883939, 5424714263332060815L, 99605L, true, true, (char) 36267, (char) 22468,
        Double.longBitsToDouble(0x3fd3bf5263f8f0acL), Double.longBitsToDouble(0x3fca84550bf7a89cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 11, 4, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u83ce", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        17, -197, -282346269, -1127308761042059599L, 99605L, true, true, (char) 36267, (char) 24006,
        Double.longBitsToDouble(0x3fe9dfa981fcdfacL), Double.longBitsToDouble(0x3fe9111542fda851L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 3, 9, "\udb95\udfa8\udb64\udfd4\ud9ab\udda1\udb3c\udd20\ud8fd\udc8b\ud9bc\udd7a\uda2b\ude81\udaef\udf5d", "\u6b0b", "\udb49\udcf9\udb33\udf30\ud805\udfff",
        35, 13770, -731174005, -666493710155258320L, -18215L, true, false, (char) 40565, (char) 57745,
        Double.longBitsToDouble(0x3fd9a986dc182214L), Double.longBitsToDouble(0x3fe70d0a3b22220cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 2, 5, "\ud858\ude02\udb22\udce6\ud90a\udebb\ud8a7\udfa6\ud938\ude32\ud968\uddce\udb0e\udf48\ud85c\udd72", "\ube1d\uc647", "\udb33\udf30\ud8fb\ude0c\ud809\udc79\ud89f\udc70\udadb\udf93\ud834\udfc3\udbe7\uddbb\u1034\uda88\ude68\ud83f\udc30\ud860\udfcc\udaac\udca0\uda27\udf1f\udbbc\ude5e\uda10\udf5e\ud899\ude09\ud91d\ude5d",
        7, 35515, 497210493, 1306919589036743907L, -735L, false, true, (char) 11802, (char) 39076,
        Double.longBitsToDouble(0x3fe41262ebfb92f1L), Double.longBitsToDouble(0x3fab8ac119064110L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 6, 14, "\udade\udf06\ud8f7\udc29\uda74\udec1\ud87f\udf29\ud938\uddbb\ud879\udeb5\udb0e\udf48\ud85c\udd72", "\ubb2c\ub4e5\ube9e\u3d26\u153e\ucc7c\u450b", "\ud834\udfe5\udbe7\uddbb\u1034\udbec\ude5b\uda94\udef6\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\uba04\ud971\udc50\uda45\uddeb\ud9e1\udce2\ud81f\udccb\udaa6\udd19\ud96b\udfad\udb56\udeaa\ud85a\udf5f\ud931\udef2\ud93e\udce4",
        1, 9978, -1685988857, 1482844227540669972L, -62631L, true, false, (char) 33424, (char) 4513,
        Double.longBitsToDouble(0x3fdc3aeb4eaf9e40L), Double.longBitsToDouble(0x3fe8a170932143c5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u845c\ub4e5\u8f23\u933a\u508b\ucc7c\u450b\u6fd8\u3604\ub0f0\u5bf7\u0c0e\u195e\u518e\u9ba6\u6233\ub94c\u48eb\u9b0f\u8b36\u1a1e\u1bb3\ub587\u4e07\u7807\u9091", "\udb15\udf0e\ud838\udea7\ud966\udfd5\u6979\udbff\ude41\udbbd\udc00\udab1\udf9f",
        21, 51876, -404629664, -2638225303270431778L, -73786L, false, false, (char) 31821, (char) 34706,
        Double.longBitsToDouble(0x3fb78dc6ac840db0L), Double.longBitsToDouble(0x3fe1c75d6dbfdaaaL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 7, 14, "\udb14\udf01\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb\ud885\uddfc\ud8a4\ude73\ud9d3\ude4d", "\uc868", "\udb5e\uddfe\udb33\udf30\ud8dc\udc0a\ud85d\udfa1",
        28, -197, -282346269, -1127308758658384207L, 99605L, true, true, (char) 36267, (char) 24006,
        Double.longBitsToDouble(0x3fe9dfa981fcdfacL), Double.longBitsToDouble(0x3fe9111542fda851L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 1, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\uda7a\uddd9\udb4a\udede\udb69\uddea\ud852\udf4b\udb89\ude64\ud90b\udfe2\udb1d\udeb3\ud95d\udcf2\ud934\udd1a\udb49\uddb0\udb33\udf30\uda3f\udedc\ud8c4\udf4b\ud813\udfd3\uda25\udc88\ud834\udfe5\udbe7\uddbb\u1034\udbec\ude5b\uda94\udef6\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb75\udc06\ud89f\uddf7\u6e31\udac9\uddc6", "\uae76\u9b2b", "\ud9e5\udf30\ud8db\udf9f\udbd6\ude8b\uda9a\ude47\ud9d4\udd8a\ud8a5\udd62\ud820\uded2\ud80c\uddee\udb3b\udd59\uda75\udebf\ud9b5\udcc9\ud9b7\udf4e\udb6b\udf2c\uda1e\udde4\ud8cd\udee4\ud996\udd4f\udb2f\udc82\ud8ab\udd5f\udb95\ude23\u3a9c\uda04\udf0a\ud9aa\udc18\ud861\uddc8\udb5e\udf23\udb92\udc7c\ud8cc\udd9c\ud9bd\udcb1\u7ade\ud930\udffa\udb30\udec1\uda0e\ude8f\ud9f2\udfc8\ud837\udfaa\ud8f7\udfde\udb36\udea2\ud8ef\udc36\udbbf\udd35\ud85c\udd88",
        6, 63446, -731424048, 2253007851504201409L, 24785L, false, true, (char) 15751, (char) 62150,
        Double.longBitsToDouble(0x3fe6b35e47c2dd4bL), Double.longBitsToDouble(0x3fe26617971e21afL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 1, 16, "\udaa7\uded6", "\u84ca\u52b8\ubabc\ua626\u8d97\u0147\u66ed\u8418\ub4e5\ua852\u933a\u5c8b", "\udb9f\udf62\uda1d\udf88\ud834\udfe5\ud927\udf84\udbc0\udf50",
        2, 73603, 1075434757, -1177606013278196195L, 69172L, true, false, (char) 63233, (char) 11866,
        Double.longBitsToDouble(0x3fe8adbdaf5064d7L), Double.longBitsToDouble(0x3fee46e2a160473eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 6, 9, 14, "\udade\udf06", "\u45f2\000\000\u885b\u759a", "\000",
        -5, 84272, 0, -937048889339527003L, -99869L, true, false, (char) 35281, (char) 60883,
        Double.longBitsToDouble(0x3e28791000000000L), Double.longBitsToDouble(0x3fb2e197a82f4b80L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 2, 15, 9, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29", "\u88fe\u759a\u7cff\u66d7\u83ce", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        14, 88440, -271659462, -1127308758520981583L, 99590L, true, true, (char) 36394, (char) 40050,
        Double.longBitsToDouble(0x3fe9dfa981fcdfacL), Double.longBitsToDouble(0x3fd5b346420bb2b4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 13, "\udade\udf06\ud8f7\udc29\uda55\udf19", "\u05ce\u62c1\ubcff", "\udb1d\udeb3",
        29, 98488, 559180730, -937047837072539483L, -97256L, true, false, (char) 35281, (char) 60916,
        Double.longBitsToDouble(0x3fe58f82d68791e6L), Double.longBitsToDouble(0x3fd0bb9114551f20L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 14, 14, "\udade\udf06\ud8f7\udc29\udbee\udd65\ud87f\udecf\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u1a8f", "\udb49\uddb0\udb33\udf30\ud9d5\ude27\ud85b\udca3",
        19, -197, -2032550685, -609789348180226542L, 99605L, true, true, (char) 36267, (char) 24006,
        Double.longBitsToDouble(0x3fe9dfa98518dfacL), Double.longBitsToDouble(0x3fc85fd9795ba248L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 14, "\000", "", "\u177d",
        20, 29326, -1808335681, -8767788232381038552L, 92501L, true, false, (char) 6566, (char) 246,
        Double.longBitsToDouble(0x3fe45d9804e3cceeL), Double.longBitsToDouble(0x3fe547795eb1f05aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 1, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb\uda07\udcdd\udb0e\udf48\udb63\udfba", "\u83ca\ub4e5\ud778\u933a\u508b\ucc7c\u450b\u6fd8\u048b", "\udb59\udc16\uda2e\ude1e\uda94\udef6\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb75\udc06\ud89f\uddf7\udb19\ude4f\uda27\udfa4\ud8ee\ude13\ud800\udeec\ud835\udea6\u179e",
        14, 3744, -1239632933, 4270764994639453555L, -98942L, true, true, (char) 7182, (char) 13606,
        Double.longBitsToDouble(0x3fed311188fbe1d6L), Double.longBitsToDouble(0x3fe2c129545d9510L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 14, 11, "\udade\udf06\ud8f7\udc29\udab3\ude28\ud896\ude5a\ud938\uddbb\ud8b3\uddf2\udb0e\udf48\ud83b\udf80", "\u4832\u2ebf\u8f92", "\ud828\udf67\udb5f\ude04\udb9b\ude70\uda1d\udf88\u889c\udb8f\udca4\ud83f\uddb9\udbec\uddd6\udbf3\ude32\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb75\udc06\ud831\udebf\ud8c6\uddf8\ud92f\udf19\ud852\udc01\uda9c\udc30\ud936\udf2d\ud89f\udfff\u0fe0\udbe7\udc59\ud94a\udd18",
        15, 25140, -189167881, 7997776375162479172L, 15095L, true, false, (char) 32116, (char) 3892,
        Double.longBitsToDouble(0x3fc60df0fe7a9028L), Double.longBitsToDouble(0x3fd4c9c1eab43546L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 6, 1, 0, "", "\u2cbd", "\uda07\udcdd",
        20, 29326, -1808335681, -8767788232381034456L, -48680L, false, true, (char) 4425, (char) 13220,
        Double.longBitsToDouble(0x3fef3fadf0000000L), Double.longBitsToDouble(0x3fe45d9804e3cceeL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 1, 0, "\ud9ca\udefc\u9f22\ud92c\udf76\u45f2\ud938\udd84\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\ua951", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        17, -197, -1549571268, 49692475057L, -31467L, false, false, (char) 0, (char) 23838,
        Double.longBitsToDouble(0x3fe9dfa98000dfacL), Double.longBitsToDouble(0x3fe8000002fda851L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 19, 4, 8, "", "", "\ud938\uddbb",
        49, 37875, 1134462326, -7782219337798873330L, 67798L, false, true, (char) 171, (char) 61183,
        Double.longBitsToDouble(0x3fc4be5fcc000000L), Double.longBitsToDouble(0x3fc06d9ec8000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 13, 14, "\udade\udf06\ud8f7\udf29\uda55\udf19\ud979\udcc4\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72\udb89\ude64\ud90b\udfe2\udb1d\udf3a\ud95d\udcf2\ud85b\udd0d\u4466\udb33\udf21\udba5\uddee\ud806\udd4f\udb9b\uddf8\uda1d\udf88\uda55\udef5\udbe7\uddfb\ud9c0\udc31\udbec\ude5b\ud8f2\udfa4\ud78b\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb74\udf1f\ud89f\uddf7\ud9ab\udd99\ud8d4\ude3f\uda04\udfb3\ud81d\ude43\u637d\udaca\udfbb\ud95b\udcc4\udb2c\udf47\udafd\udf50\udbf7\udec5\ud97d\ude6e\ud4dc\uda96\udc04\ud918\udf50", "\ua41b\u44d1\uc579\u24d3\uaa6f\u954a", "\uda34\uded0\uda61\udfc1",
        14, 17907, 1972565395, -6764610227902779740L, -23860L, true, true, (char) 28255, (char) 26970,
        Double.longBitsToDouble(0x3fe0c1655c4cc06aL), Double.longBitsToDouble(0x3fe21cbe733e6803L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 19, 3, 14, "\udade\udf06\ud8f7\udf29\uda55\udf19", "\ubabc\u88fe\u759a\u7cff\u66d7\u83ce\ub4e5\u8f23\u933a\u508b\ucc7c\u450b\u1c5b\u35d1\u47f0\u341d\ud400\u195e\u518e\u45ab\u6233\ub94c\uaa66\u9ad4\u8b36\u369c\u461b", "\u637d\u6dc1\ud95b\udcc4\uda1c\uddbf\udae8\ude04\udbf7\udec5\ud97d\ude6e\ud4dc\udb56\udd42\udb37\ude67\ud90d\udc94\uda71\uddff\ud9d3\udf9b\ud8cb\udd74\ud856\udd5d\ud81a\ude59\uda54\uddba\ud8e0\udc65\udbeb\udc0a\udb17\udfb7\uda34\udf05\uda48\uddf3\udb8d\udddc\uda8d\ude9b\ud858\udf4d\udac0\udd4e\udaa0\udc26\ud9cd\udf85",
        29, 14875, 632337678, 8966147425323165667L, -88157L, false, false, (char) 54119, (char) 22932,
        Double.longBitsToDouble(0x3fec921a07cc9339L), Double.longBitsToDouble(0x3fe535d032a326f6L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 2, 9, 9, 18, "\udade\udf06\ud8f7\udf29\uda55\udf19\ud979\udcc4\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72\udb89\ude64\ud90b\udfe2\udb1d\udeb3\ud95d\udcf2\ud934\udd1a\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52\udb9b\ude00\uda1d\udf88\ud834\udfe5\udbe7\uddbb\ud9c0\udc31\udbec\ude5b\uda94\udef6\ud8c8\udd6e\ud9fe\udf06\udad4\udc61\ud809\ude9f\udbae\udec5\uda53\udd3f\ud9ab\udd99\ud8d4\ude3f\uda04\udfb3\ud8ec\udeeb\ud9c3\udf6b\uda8a\udd4f\ud95b\udc63\udb2c\udf47\udafd\udf50\udbf7\udec5\ud97d\ude6e\ud4dc\udb56\udd42\ud80c\udee6", "\ua41b\u44d1\ua5e1\u1d30\uaa6f\u954a", "\uda34\uded0\uda61\udfc1",
        14, 17907, 1061614995, -6764610464125981020L, 98045L, true, true, (char) 18408, (char) 62646,
        Double.longBitsToDouble(0x3fe21cbe733eb0a4L), Double.longBitsToDouble(0x3fde92d7f3149814L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 5, 14, "\udade\udf06\ud8f7\udf29\uda55\udf19\ud979\udcc4\ud938\uddbb\udb07\ude3d\udb0b\udc4e\ud85c\udd72\udb89\ude64\ud90b\udfe2\udb1d\udeb3\ud95d\udcf2\ud934\udd1a\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52\udb9b\ude00\uda1d\udf88\ud834\udfe5\udbe7\uddbb\ud9c0\udc31\udbec\ude5b\uda94\udef6\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb75\udc06\ud89f\uddf7\ud9ab\udd99\ud8d4\ude3f\uda04\udfb3\ud81d\ude43\u637d\u6dc1\ud95b\udcc4\udb2c\udf47\udafd\udf50\udbf7\udec5\ud9db\ude1c\ud903\udc4e\udb56\udd42\ud80c\udee6", "\ua41b\u44d1\u74fe\u1a9c\uaa6f\u954a", "\uda34\uded0\uda61\udfc1",
        14, 17907, 1972565395, -6764610227902779740L, 98045L, true, true, (char) 39619, (char) 62646,
        Double.longBitsToDouble(0x3fe21cbe733eb0a4L), Double.longBitsToDouble(0x3fde92d7f3147014L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 16, 0, 14, "\udade\udf06\ud8f7\udf29\udbcd\udef6\ud979\udc40\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72\udb89\ude64\ud90b\udfe2\udb1d\udeb3\ud95d\udcf2\ud934\udd1a\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52\ud9cb\udd77\uda1d\udf88\ud80c\udee5\udbe7\uddbb\ud9c0\udc31\udbec\ude5b\uda94\udef6\ud806\udccc\ud9a7\udc9b\udb95\udd79\ud92d\udd53\udb75\udc06\udb58\udec4\ud987\udc7e\ud8d4\ude3f\uda04\udfb3\ud81d\ude43\u637d\u6dc1\ud95b\udcc4\udb2c\udf47\udafd\udf50\udbf7\udec5\ud97d\ude6e\udb1b\udcae\udbab\udc51\ud80c\udee6", "\ua41b\u44d1\u74fe\u1a9c\u7234\u954a", "\uda34\uded0\uda61\udfc1",
        14, 17907, 1972565395, -6764610227902779740L, 32509L, true, true, (char) 39619, (char) 62646,
        Double.longBitsToDouble(0x3fe21cbe733eb0a4L), Double.longBitsToDouble(0x3fde92d7f3147014L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 0, 3, 9, "\000", "", "",
        0, 63447, 2103744506, -7766950515963949298L, 38962L, true, true, (char) 0, (char) 61428,
        Double.longBitsToDouble(0x3fc4be5fc0000000L), Double.longBitsToDouble(0x3fd1a6cf61176700L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 18, 2, 14, "\ud858\ude02\udb22\udce6\ud90a\udebb\ud8a7\udfa6\uda18\ude81\udb0d\ude62\udb47\udebb\ud85c\udd27", "\u886b\u9245", "\uda75\udec7\ud8fb\ude0c\ud950\udf7c\udb88\udf70\ud8e1\udf14\u0510\udbe7\uddbb\udabf\udf51\uda88\ude68\ud83f\udc30\ud860\udfcc\udaac\udca0\uda27\udf1f\ud9e0\udd8f\udb7f\udf34\ud899\ude09\ud91d\ude5d",
        7, 35515, 497210493, 1306919589036743907L, -735L, false, true, (char) 11802, (char) 39076,
        Double.longBitsToDouble(0x3fe41262ebfb92f1L), Double.longBitsToDouble(0x3fab8ac119064110L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 6, 5, "\uda65\udd93\udb22\udce6\ud90a\udebb\ud8a7\udfa6\ud82b\uddcb\ud877\uddfd\ud9c5\udc97\ud85c\udd72", "\ube1d\uc647", "\ud91f\udf42\ud8fb\ude0c\ud81e\udd10\ud89f\udc70",
        9, 48697, -255082961, -7861316063114989410L, 57060L, true, true, (char) 43738, (char) 58924,
        Double.longBitsToDouble(0x3fd4d61511eb1498L), Double.longBitsToDouble(0x3fc865ccd1f40c6cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 2, 12, 12, 13, "\uff36\udba9\udf54\udb4c\uded3\ud87f\udec0", "\u8051\ub37b\ua712\u66d7\u83ce\ub4e5\u8f23\u7c3a\u508b\ucc7c\u450b\u1954\u05b9\u1309\u341d\u274d\u9fcf\u519d\ud30d\u8e99\u88bc", "\udbc7\udf13\ud923\udd4d\udb64\ude6f\ud829\udc88\ud873\udfe6\ud8fe\udcdf\uda4b\udfe7\udb1d\udee4\ud984\uddb9\uda42\udfae\udb8c\ude2b\ud8be\ude3a\udbcf\uddf7\udb41\udcf9\udb38\uddf1\udb93\udfdb\ud9a5\udca9\udbd4\ude5d\udbba\udd43\ud97d\udf35\uda12\ude90\ud9ab\udc4a\ud813\ude2e\udb9d\udeff",
        23, 49318, 1563474820, -8470969790780800901L, 35335L, false, false, (char) 14104, (char) 28586,
        Double.longBitsToDouble(0x3fea3c30fa2b04eaL), Double.longBitsToDouble(0x3fea2ce92535ad03L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 2, 12, 12, 13, "\udbb7\udf32\udba9\udf54\udb4c\uded3\ud87f\udec0", "\u8051\ub37b\ua712\u66d7\u83ce\ub4e5\u8f23\u7c3a\u508b\ucc7c", "\uda11\udf3d\udacb\udd45\udbe7\uddbb",
        36, 41581, -378473382, -8391009771777739901L, 53947L, true, true, (char) 65375, (char) 53776,
        Double.longBitsToDouble(0x3fb787713af9df70L), Double.longBitsToDouble(0x3fc9523704cab478L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 16, 1, 14, "\udade\udf06\ud8f7\udc29\uda55\udf19\ud87f\udf29\ud938\uddbb\uda07\udcdd\udb0e\udf48\ud85c\udd72", "\u83ce", "\udb49\uddb0\udb33\udf30\ud8dc\udc0a\udb62\ude52",
        17, -197, -282346269, -1127308761042059599L, -80142L, true, false, (char) 58475, (char) 22953,
        Double.longBitsToDouble(0x3fe9111542fda851L), Double.longBitsToDouble(0x3fc38094eed86a04L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 1, 14, "\udbd0\udd45\ud90b\udc8f\udbba\ude8a\ud87f\udeb9\udb52\uddc1\uda07\udcdd\u1344\ud85c\udd72", "\u9390\u6ce2\u7c6e\u5ba0\u4fc5\ucca5\u450b\u6c61\u595c\u31b0\u5c9e\ub41a\ud5eb\u518e\u08fe\u5587\ud5c0\u490e\u8ae0\u473a\u570e\u24bf\u5a93\ubf92\u71f6\u9fa1\u3f93\uc05b\u2db9\u4b8f\u0a9f\u55fc\u0a23\u4cb2\u78a9\u1b80\ud727\u19cf\u616f\u4c53\u0e2f\u7e23\u4312\u95ab\u60de\u3181\u6638\u5a6c\u8163\u8e91\u00f0\u3d39\u73e4\u3572\u2f4a\ucf76\u7b55\u192d\u3486\u2a55\uaf14\u0aa8\uab84\u58e7\u3f05\ubdae\ub905\u5cb8\u4169\u9d8e\u4b96\u8bfa\u9ae4\u2584\u1aa8\ud780\u4e10\u608f\u322b\uaf0d\u6cfd\u4e2d\ubbd7\uae7a\u6bee\u03e5\u53e3", "\uda0f\udd89\ud9e7\uddd6\udaeb\udf69\uda81\udc37\u1703\ud870\udcc6\ud812\udf3d\uda54\udda1\uda41\udd8d\ud89a\udd97\ud803\udeb1\ud939\udc7c\udaa0\udc21\udb88\ude8c\udbfd\udc2b\ubd3f\ud861\udf03\udb18\udd56\uda2e\udd24\udae4\udf12\uda45\udef1\ud9af\uddec\ud89b\udc30\udae8\udf1c\udbc3\udc65\uda20\udf99\ud9e4\udc87\ud939\ude5e\udbdc\udef1\udaf3\udf80\ud850\ude7c\udb19\udc8e\ud96d\udf45\ud9b4\udffc\ud894\udeee\ud97d\uddbb\udacf\udde6\ud88d\udc8d\ud88c\ude3f\udb87\udc4c\ud92a\ude81\ud951\ude88\udb95\udd8e\udab1\uddb4\udb93\udc31\u3c51\ud810\ude35\ud9b8\udefc\udbf4\udcf1\ud80a\uddc9\udbc7\udcd7\udb8d\udc0e",
        29, 59208, -1069342337, -6947173288583100154L, -75846L, false, false, (char) 15300, (char) 43792,
        Double.longBitsToDouble(0x3fe5a32d783a933fL), Double.longBitsToDouble(0x3fe4eb5d61bce0f1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Polygon,java.awt.Polygon|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Shape,java.awt.Shape|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Arc2D,java.awt.geom.Arc2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Ellipse2D,java.awt.geom.Ellipse2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.GeneralPath,java.awt.geom.GeneralPath|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Line2D,java.awt.geom.Line2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|clone|java.awt.Shape|static",
    "M|org.jfree.chart.util.ShapeUtilities|contains|java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|createDiagonalCross|float,float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createDiamond|float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createDownTriangle|float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createLineRegion|java.awt.geom.Line2D,float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createRegularCross|float,float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createTranslatedShape|java.awt.Shape,double,double|static",
    "M|org.jfree.chart.util.ShapeUtilities|createTranslatedShape|java.awt.Shape,org.jfree.chart.util.RectangleAnchor,double,double|static",
    "M|org.jfree.chart.util.ShapeUtilities|createUpTriangle|float|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Polygon,java.awt.Polygon|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Shape,java.awt.Shape|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Arc2D,java.awt.geom.Arc2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Ellipse2D,java.awt.geom.Ellipse2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.GeneralPath,java.awt.geom.GeneralPath|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Line2D,java.awt.geom.Line2D|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
