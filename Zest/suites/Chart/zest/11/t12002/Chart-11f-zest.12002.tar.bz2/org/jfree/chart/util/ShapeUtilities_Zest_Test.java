package org.jfree.chart.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class ShapeUtilities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 18, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\uddc4\udb67\udc12\udaba\ude50\ud8de\udf64\ud8ef\udee8\ud9d7\udf97\ud949\ude22\uda09\udd43\uda11\udd89\udb7c\udf1f\ucafc",
        -3, 59405, -480661128, -8051072319046151802L, -22035L, false, false, (char) 21046, (char) 29984,
        Double.longBitsToDouble(0x3fae0fe6e3443c70L), Double.longBitsToDouble(0x3fea7422784410beL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 18, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415\u282d\ub60c\u27c3\ud356\ud3d9\ub79c\ud71c\u852c\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\uddc4\udb67\udc12\udaba\ude50\ud8de\udf64\ud8ef\udee8\ud9d7\udf97\ud949\ude22\uda09\udd43\uda11\udd89\udb7c\udf1f\ucafc",
        -3, 59405, -480661128, -8051072319046151802L, -22035L, false, false, (char) 31752, (char) 29984,
        Double.longBitsToDouble(0x3fae0fe6e3443c70L), Double.longBitsToDouble(0x3fea7422784410beL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 1, 9, 4, 18, "\ud895\ude12\udb37\udeed\udac2\udfba\udba0\ude00\ud999\udd47\udb68\udc35\uda52\uded5\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud8b0\udf2a\uda41\udc26\ud8d2\udeef", "\u2c7d\uc727\ub08b\u8b5c\u4b94\ud41a\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\udbe5\udd83\uda50\udcfe\uda0f\udcb5\ud85f\udf1e\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\uddc4",
        37, 97347, 1177966401, 96852493747353772L, 46985L, true, false, (char) 30203, (char) 61016,
        Double.longBitsToDouble(0x3fc56f245f36fbbcL), Double.longBitsToDouble(0x3fd78a0840c5c6b2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 16, "\udb1c\udf6a\ud948\udc9d\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\uda7f\ude55\ud8e3\udcf3\uda58\udcc4\uda79\udd28\uda22\udee2\uda94\ude2b\udb85\udc18\ud8fc\uddeb\ud9ea\udd7d", "\u24b4", "\uda6c\udecb\udb4c\udd88",
        28, 6214, -1032687592, 3649691456217395945L, -40162L, true, true, (char) 19420, (char) 1764,
        Double.longBitsToDouble(0x3fd3abf2bfb7e8d4L), Double.longBitsToDouble(0x3fd6ac17e9d26860L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 16, 18, "\udb06\udd65\000\udac2\udfba\udbfe\ude13\udad0\udcff\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u889f\u5407", "\u0096\u674d\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\u342fe\udaba\ude50A\ud891\uded9\ud84d\udee5\ud949\ude22\ud9d9\udc43\uda11\udd89\udb7c\udf1f\uaafc",
        -3, 59405, -480661128, 19378213839311238L, -22035L, false, false, (char) 21046, (char) 31799,
        Double.longBitsToDouble(0x3fae0fe6e0000000L), Double.longBitsToDouble(0x3fea7422784410beL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 12, 4, "\udb06\udd65\udb11\ude44\udac2\udfba\udaa6\udc75\udb6a\udfbb\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud848\udcd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415", "\ud8d9\udc72\ud95b\udfac\uda6c\udecb\ud84c\udde7",
        28, 6214, -1032687592, 3649691456217395945L, -40162L, true, true, (char) 19420, (char) 29177,
        Double.longBitsToDouble(0x3fd363202e02ea54L), Double.longBitsToDouble(0x3fd0ac17e9d2698eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=null\012",
        Z.run(T, 2, 20, 6, 7, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udbd0\udffd\ud8ec\udc16\ud83a\udfd5", "\uc09e", "\ud837\udda5\ud826\udd22\ud8a2\udf8a\ud93f\udff2\ud8ce\udd72\ud95b\udfac",
        43, 71614, 1306406630, -6089103066467766248L, 11337L, true, false, (char) 37671, (char) 53961,
        Double.longBitsToDouble(0x3fe217a119dfdafbL), Double.longBitsToDouble(0x3fe1f70cee896370L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 19, 18, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\ud8da\udc34\ud8d2\udeef", "\u4415\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\udacd\udd04\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\ude1e\udb67\udc12\udaba\ude50\ud8de\udf64\ud8ef\udee8\ud9d7\udf97\ud949\ude22\uda09\udd43\uda11\udd89\udb7c\udf1f\ucafc",
        -3, 59405, -480661128, -8051072319046151802L, -22035L, false, false, (char) 21046, (char) 29984,
        Double.longBitsToDouble(0x3fae0fe6e3443c70L), Double.longBitsToDouble(0x3fea7422784410beL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 18, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud9f5\ude68\ud83a\udfd5\ud9e9\udcfb\uda0a\udeb6\uda41\udc26\ud8bf\udda5\ud90b\udc91\ud9ea\udd67\ud826\udcfa\ud8a2\udf8a\ud93f\udff2\ud8ce\udd72\ud95b\udfac\uda6c\udecb\ud84c\udde7\ud8d3\udc8c\ud982\udd77\ud966\udfa5\ud84e\ude07\udb14\udd3c\uda82\udc06\ud928\udf08\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\ud9bd\udde2\ud92c\udca9\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\uddc4\udb67\udc12\ud976\udd6e\ud8de\udf64\ud8ef\udee8\ud9d7\udf97", "\u5267\u5ac0\u6384\u5b8d\uc6a2\u4783\u4bf5\ua6e5\u8267\u795e\ub030\ubbc4", "\udbe7\udee9\uda4c\udc4a\ud9ef\udebf\ud8b0\udc8e\udbd4\udc22\uda99\ude37\u47fe\u1013\ud8b0\udc5e\udbae\udf9f\ud8a3\udfd6\ud951\udf02\ud9b9\udfef\ud2ba\ud96f\uddce\udbed\ude69\udb32\ude43\uda6c\udcff\ud281\udba4\udf6b\udaf6\udf15\udac4\udee9\udbd9\udda4\ud985\udd67\ud8a6\udc50\udbf0\ude7a\udbc9\ude6c\ud873\udca6\ud851\udfa9",
        19, 70849, 1162191521, -3300444688991474183L, 32576L, false, true, (char) 20926, (char) 32792,
        Double.longBitsToDouble(0x3fd93e34156cd56cL), Double.longBitsToDouble(0x3fbe226e910b9af8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 18, 4, 18, "\udb06\udd65\udb11\ude44\udb35\uddc6\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud82b\uded5\ud9c4\udffb\ud908\udeb5\uda41\udc26\udbd0\udee7", "\ub94a\uc684\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u07cb\u4fab\u59cf\uc91d\u6d52\uaf81\u7eb6\u6ddb\u0268\u413f\u2763\u2582\uabf7\u621d\u5d7f\u09b0\u9475\u8d7e\uc77d\u8e96\ub06b\u1dfc\u4faf\u434aN\u5ac0\u6384\u5b8d\uc6a2\u4783\u4bf5\u4ccf\u5e3c", "\ud922\udcbc\udb1f\ude95\ud850\udea5\udbb4\udcfe\ud96d\uddc6\uda7f\uddda\uda3b\udd93\uda9c\udd4a\udb44\udf3a\ud896\udc8c\udb63\udd05\ud8b1\udf1b\udb1c\udf38\ud92c\udc25\udae1\udc73\ud9bc\ude6a\ud988\udee0\uda3a\ude55\udaaf\ude83\udbe3\ude0a\udaf1\uddb0\ud896\udd21\ud880\udff6\ud8a5\ude06\ud9de\ude55",
        55, 84662, 585915564, 8088596638094722826L, 1870L, false, false, (char) 24711, (char) 45714,
        Double.longBitsToDouble(0x3fdb16319721f1beL), Double.longBitsToDouble(0x3fd21ded3cb33f34L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 17, 18, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u0ced\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u5d1d\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\uddc4\udb67\udc12\udb75\uded6\ud8de\udf64\ud8ef\udee8\ud9d7\udf97\ud949\ude22\uda09\udd43\uda11\udd89\udb7c\udf1f\ucafc",
        25, 59405, -480661128, -8051072319046151802L, -22035L, false, false, (char) 21046, (char) 29984,
        Double.longBitsToDouble(0x3fae0fe6e3443c70L), Double.longBitsToDouble(0x3fea7422784410beL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 18, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\uda74\udfee", "\u4415\uc727\ub08b\u8b5c\u5b0c\ubb4e\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\ude06\udb67\udc12\udb8d\uddd9\uda21\udfcb\ud990\ude7f\ud830\udd49\ud949\ude22\uda09\udd43\uda11\udd89\udab7\udc5c\ud847\udd1f",
        0, 13953, -2141501411, 6718510921259720643L, -22035L, false, false, (char) 21046, (char) 29984,
        Double.longBitsToDouble(0x3fae0fe6e3443c70L), Double.longBitsToDouble(0x3fea7422784410beL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 2, 20, 8, 8, "\udb06\udd65\udaed\udeb2\udac2\udf9e\udba0\ude04\udbe3\udf68\uda01\uded3\udaaf\udfcc\udb90\udc69\ud95f\uddbe\ud9dc\udc35\ud96c\udd27\udade\udd98\ud8d2\udeef", "\u97e6\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda29\udd3c\ud82c\ude04\udbf6\udec2\ud815\ude87\udad3\udf21\udaa7\ude62\uda7e\udf77\udb97\udf90\uda2a\udc41\ud87a\uddc4\udb67\udc12\udaba\ude50\ud8de\udf64\ud8ef\udee8\ud963\udf9d\ud949\udddd\uda09\udd43\uda11\udd89\udb7c\udf1f\ucafc",
        -3, 59405, -480661128, -8051072319314587258L, 84231L, false, false, (char) 1627, (char) 29984,
        Double.longBitsToDouble(0x3fae0fe6e3443c70L), Double.longBitsToDouble(0x3fe757227c08e570L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 18, "\udb06\udd65\udb11\ude44\udab9\udd15\uda66\udea4\udad0\udd63\uda01\uded3\udaf4\uddcf", "\uc0fb\u8358\uc09e\u2029\uc1f7\u916b", "\ud93f\udff2",
        6, 49057, 373240188, 2412627502496941542L, 2376L, true, true, (char) 58766, (char) 25235,
        Double.longBitsToDouble(0x3fe4b044917b194fL), Double.longBitsToDouble(0x3fe217a119dfdafbL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 7, 18, "\udb38\udf4e\udb11\ude44", "\ub641", "\uda89\udfb9\ud830\udc00\udb1d\udf69\ud908\udeb5\udbec\udca8\ud8af\ude49\udbf4\udc27\ud9ea\udd7d\ud826\udcfa\ud8a2\udf8a\ud93f\udff2\ud8ce\udd72\ud95b\udfac\uda6c\udecb\ud84c\udde7\udaea\ude79\ud855\udc0b\ud975\udc9a\uc45a\udb14\udcb4\ud923\udf76\udb5f\udc13\ud80a\udcc8\ud9e9\udc13",
        33, 93614, -1074262391, 1192489877094946779L, -73428L, true, true, (char) 24389, (char) 35357,
        Double.longBitsToDouble(0x3feb2af5d8bbc7a6L), Double.longBitsToDouble(0x3fea08d726294636L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 18, "\udb06\udd65\udb2e\udf44\udac2\udfba\ud81c\ude02\ud8f6\udef7", "\u6d6d\u1342\u663e\u317b\uc09e\u00c3\u3192\u910c\u4415\u6128\ub0ef\u8b5c\u5c87\u62d7\ub79c\u69f3\u84de\u0724\ua312\uc944\uc91d\u8095\u536c\uc261", "\udbf6\udec2\ud92c\udc93",
        -1, 14858, -1156247667, -2722949889487567601L, 43205L, true, false, (char) 29221, (char) 23818,
        Double.longBitsToDouble(0x3fc5802b1155d5acL), Double.longBitsToDouble(0x3fdd796d4deb64b2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 16, 18, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udbdd\udc6e\ud8cb\udd32\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\ud933\udd3e\ud8d2\udeef", "\u4415\uae17\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\ud874\uded8\ud803\udefd\uda91\ude92\ud8b8\udd33\udbd4\udf21\udbee\ude97\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\uddc4\udb67\udc12\udaba\ude50\udb09\udd19\ud8fa\udee9",
        29, 25949, -1302740521, -1735962882086892013L, -57163L, true, true, (char) 20988, (char) 48059,
        Double.longBitsToDouble(0x3fd869044421b48cL), Double.longBitsToDouble(0x3fec681c2e10c41dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 17, 17, 0, "\udb06\udd65\udb11\ude44\ud83f\udcdc\udba0\udea4\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u438f\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\ud44b\u857b\u2b7b\ua9d6", "\uda65\udc34",
        56, 70026, 1167929823, -7102000283555197272L, -22191L, false, false, (char) 25008, (char) 53406,
        Double.longBitsToDouble(0x3fd892b5885f2fceL), Double.longBitsToDouble(0x3feb2af5d8bbc7a6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 19, 13, 13, "\udb06\udd65\udb11\ude44\udbfe\udcf7\udba0\udef6\udad0\udd63\ud874\uded9\udaf4\uddcf\ud900\udd0d\ud9b8\udd84\ud9e9\udcd4\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415\u6d5e\uae1a\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13",
        56, 70026, -509791777, 7165343820592713353L, 8581L, false, true, (char) 25008, (char) 50351,
        Double.longBitsToDouble(0x3fd0fda3685f2fceL), Double.longBitsToDouble(0x3feb2af5d8bbc7a6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 4, 11, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u0724\ua312", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\udbad\ude7a\udb97\udf90\uda1b\udeec\ud87a\uddc4\udb67\udc12\ud9a3\udce7\ud8de\udf64\ud8ef\udee8\ud9d7\udf97\ud949\ude22\uda09\udd43\uda11\udd89\udb7c\udf1f\ucafc",
        49, 59405, -480661128, -8051072319046151802L, -22035L, false, false, (char) 21046, (char) 29984,
        Double.longBitsToDouble(0x3fd3c1fcddbf17feL), Double.longBitsToDouble(0x3fea7422784410beL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 18, "\udb06\udd65\udb11\ude44\ud9e0\udd08\ud9e2\udd3e\ud933\udec3\uda76\udf03\udb65\udf28\ud908\uddf8\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda07\udc26\ud8e6\udc39", "\u4415\uc727\ub08b\u8b5c\ucc80\ud442\uc906\ud0cd\u1c5a\u0724\u8608", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud80e\udf4d\ud845\udd6a\udb97\udf90\udb57\ude6a\ud8a5\ude33\udb67\udc12\udaf3\udd0c\udac1\udfc0\ud8ef\udee8\ud9d7\udf97",
        41, 57479, -404185355, -3606664140856090522L, -40639L, true, false, (char) 12959, (char) 21046,
        Double.longBitsToDouble(0x3fabfc744d654390L), Double.longBitsToDouble(0x3fe1a21e3f4e844fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 12, 10, "\udb3d\udd2b\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb", "\u00c3\u3192\u910c\u4415\uc727\ub08b\u8b5c\ud356\ud3d9\ub79c\u69f3\u84de\u0724\ua312\u4127\uc91d\u8095\u536c\uc261\u6ddb\u1819\u22a5\u1422\u9dc5", "\udb97\udf90\uda05\udcec\ud87a\uddc4",
        37, 97347, 1177966401, -5235409465059350681L, 46985L, true, false, (char) 30203, (char) 61016,
        Double.longBitsToDouble(0x3fc574845f36fbbcL), Double.longBitsToDouble(0x3fd78a0840c5c6b2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 18, "\udb06\udd65\udb11\ude44\ud9b2\udf12\ud9ce\udfe2\ud9a5\udd1d\udb1f\udec3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5", "\u70a5\u910c\u4415\uc727\ub08b\u8b5c\ud356\u7821\u1478\u69f3\u85d2\u0724\u86f8\uc944\uc91d", "\ud81a\udc84\uda38\udc14\udb56\udf7b\udbf6\ude93",
        -4, 41898, 888582884, -7862103380620660277L, 11175L, false, false, (char) 12736, (char) 22699,
        Double.longBitsToDouble(0x3fe7ad92c913e7e8L), Double.longBitsToDouble(0x3fbf337c855d2110L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 2, 8, 12, 7, "\udb42\udf1c\ud903\uddf5\uda68\udfb4\ud981\udebe\uda42\udc3d\udba1\udd64\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef\udbf4\udc27\ud9ea\udd7d\ud826\udcfa\ud8a2\udf8a\ud93f\udff2\ud8ce\udd72\ud95b\udfac\uda6c\udecb\ud84c\udde7\udaea\ude79", "\ua312\uc944\uc91d\u8095\u536c\uc261\u6ddb\u1819\u22a5\u1422\u9dc5\u13c0\u0398\u7501\u09af\u9475\u5c9b\u309a\u4278\ub06b", "\uda09\udd43\uda11\udd89\udb7c\udf1f\udbdb\udf2e\ud966\udc57",
        25, 97872, -1874536350, -2718466057789146608L, 63090L, true, false, (char) 29984, (char) 3081,
        Double.longBitsToDouble(0x3fe1a21e3f4e844fL), Double.longBitsToDouble(0x3fb1042fb54794a8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 20, 14, 18, "\000\ud881\ude3f\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud8cc\uddb3\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\000", "", "",
        -5, -1000, 0, 17732924094504942L, 10837L, true, false, (char) 32256, (char) 37671,
        Double.longBitsToDouble(0x3eb3c00000000000L), Double.longBitsToDouble(0x3fddfdafb47dc33aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 12, 4, 6, "\udb06\udd65\udb2e\udf14", "\u8eea\u135a\u4ca4\u6d6d\u97b3", "\uda41\udc26",
        35, 30440, 1780978492, 1734228420198934207L, -47132L, false, true, (char) 10081, (char) 30385,
        Double.longBitsToDouble(0x3f98ab7fe1784e40L), Double.longBitsToDouble(0x3fe7499536f5e39dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 9, 4, 18, "\uda17\udc26\udb11\ude44\udac2\udfba\uda5b\udf13\udad0\udd63\uda01\uded3\udb24\udf08\ud900\udcef\ud83a\udfd5\ud9e9\udcfb\ud8fe\udfb5\udbc4\udc0a\ud8d2\udeef", "\u4415\uc727\u9ff4\uc573\ud356\ud3d9\ub79c\u691e\u84de\u0724\ua312", "\udb5f\udc13\udba0\udf18\udbe2\uddf2\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\udb6f\udd05\udaa3\udcfc\udb97\udf90\uda1b\udeec\ud87a\uddc4\udb67\udc12\udaba\ude50\ud98c\udd7c\ud8ef\udee8\ud9d7\udf97\ud949\ude22\uda09\udd43\uda11\udd89\udb7c\udf1f\ucafc",
        -3, 2885, -480706107, -8051072319046151802L, 45293L, true, true, (char) 8620, (char) 26912,
        Double.longBitsToDouble(0x3fae0fe6e3443c70L), Double.longBitsToDouble(0x3fea742279ae10beL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 15, "\udbcc\udc28", "", "",
        44, 55685, -173155927, 2522404766251129019L, -38748L, true, false, (char) 13377, (char) 27103,
        Double.longBitsToDouble(0x3fec7b513ebf1811L), Double.longBitsToDouble(0x3fe8a28ac7a00ebdL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 18, 10, "\udb06\udd65\ud823\ude23\ud8d2\udee0\udbd7\udd11\udad0\udd63\uda01\uded3\u139a\u511b\ud83b\udc0d\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u7db5\u6229\ua259\u8b96\u0626", "\udad2\udde8\ud855\udc0b\ud95b\udc77\ud84e\ude07\udb14\udd3c\u8776\udb5f\udc13\ud80a\udcc8",
        51, 55223, 1668311614, -4613921836853108422L, -60426L, true, false, (char) 50351, (char) 24389,
        Double.longBitsToDouble(0x3fa7cbf3f655ebb0L), Double.longBitsToDouble(0x3fc778f4dd046b90L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 0, 0, 3, "\udb06\udd65\uda52\udc05\uda33\ude59\udba0\ude04\udad0\udd63\010\000\ud900\udc64\ud83a\udfd5\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415\u26bf\000\u8abc\ud356\ud3d9\ub79c\u69f3\u84de\u0724\u4f0b", "\udb5f\udc13\ud80a\udcc8\ud9e9\udc13\uda38\udc14\ud896\udc1a\udbf6\udec2\ud92c\udc93\udbf7\udc2b\ud8d4\udc86\u2ce9\udac5\uddc2\000\000\udb5b\udcad",
        57, 2401, 22550228, 8460857061915540565L, -100000L, false, false, (char) 61016, (char) 64717,
        Double.longBitsToDouble(0x3fee6df77978a084L), Double.longBitsToDouble(0x3fb8b8d64c348220L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 19, 3, 11, "\udb06\udd65\udb11\ude44\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud83a\udfd5\ud897\udf53\ud8cc\udfd4\udaec\udece\udb14\udd3d", "\ua6f7\uc727", "\ud926\uddb2\uda6c\udecb\ud84c\udde7\udaea\ude79\ud855\udc0b\ud95b\udc77\ud84e\ude07\udb14\udd3c\ud923\udf76\udb5f\udc13\ud80a\udcc8",
        51, 55223, 1668311614, -4613921836853108422L, -60426L, false, false, (char) 3779, (char) 12513,
        Double.longBitsToDouble(0x3fa7cbf388dadbb0L), Double.longBitsToDouble(0x3fe03d874f41f506L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 6, 10, 13, "\ud895\ude12\udb37\udeed\udb51\udf01\ud88d\ude5b\ud9e8\udf2c\ud95c\udc11\uda52\uded5", "\u663e\u51c6\ub295\u4a7f\u3192\ub5e7", "\ud93f\udff2",
        8, 82622, 64376253, -3437044706386667086L, 2376L, true, true, (char) 10895, (char) 49628,
        Double.longBitsToDouble(0x3fe4b044917b194fL), Double.longBitsToDouble(0x3fea17a1191c264fL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 1, 9, 4, 18, "\ud895\ude12\udb37\udeed", "\u4ab4", "\ud900\udd0d\ud83a\udfd5",
        59, 8584, -886771900, -2186334097492454760L, 33130L, true, false, (char) 22636, (char) 46684,
        Double.longBitsToDouble(0x3fe1fcb939bd9880L), Double.longBitsToDouble(0x3fb8858fef310d80L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 0, 9, 13, "\u6d00", "\000", "",
        -5, -1000, -285122304, 1095216660480L, -100000L, true, false, (char) 27040, (char) 27175,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=java.awt.geom.GeneralPath:@?\012",
        Z.run(T, 2, 9, 15, 9, "\udaf6\udc94\ud8e0\ude7f\ud8bf\uddbe\udb9f\ude4e\uda50\uddb4\ud83c\ude65\ud8aa\ude17\ud99a\udc25\uda58\udcc4\udbe2\udd8c\uda22\ude93\ud9ac\udd29\ud936\ude32\ud803\udd2f\udb0d\udd94", "\ua8e4", "\uda63\udd79\udb6a\udc05\udaea\ude79\ud855\udc0b\ud898\udfd5\u20a6\udb71\udc2d\ud97a\udc44\udab0\uddd0\udaa9\udfb9\ud9e9\udcb0\ud8ae\udc0f\ud896\udc1a",
        17, 882, -1048684581, 3760621593113734377L, 86929L, false, false, (char) 56285, (char) 12320,
        Double.longBitsToDouble(0x3fed45ba6eb1135dL), Double.longBitsToDouble(0x3fe8392019c8d930L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.awt.geom.GeneralPath:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 13, 2, "\uda6a\uddb4\udba6\ude50\ud871\udd14\u174e\udad0\udcff\ud89d\udc1b\ud814\udd7f\uf7b1\ud852\udebc\ud9e9\udcfb\ud908\udeb5\uda41\udc26\udab6\udc23", "\u4cfa\u22b6\u7d2b\u8b5c\ud356\u5213\ucd41\u6999\u84de\u197c\u33d5\ua65b\u7ef5\u0096\u71f0\uc261\ua9db\u1819\u22a5\u1422", "\udbad\ude3d\uda8f\udd6a\ua38d\udbd2\udf82\ud833\udd9a",
        2, 64071, 5773012, 8430738500673125461L, 30970L, false, true, (char) 29600, (char) 20899,
        Double.longBitsToDouble(0x3fb8b8d64d780220L), Double.longBitsToDouble(0x3eb184681c280000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 5, 9, "\ud855\udf7e\ud828\udce3\udac2\udfba\udaa6\udc75\udb6a\udfbb\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud87a\udd60\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef", "\u4415", "\ud8d9\udc72\ud95b\udfac\uda6c\udecb\ud84c\udde7",
        28, 21998, -1032687592, 3649691456217395945L, -40162L, true, true, (char) 19420, (char) 29177,
        Double.longBitsToDouble(0x3fd3632025c6ba54L), Double.longBitsToDouble(0x3fd5379ef9d2698eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 6, 7, "\udb06\udd4d\udb11\ude44\udac2\udfba\udba0\ude04\uda9c\ude09\ud946\udce0\ud94e\udcee\ud8ec\udc16\ud83a\udf96\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud8d2\udeef\udbf4\udc27\ud837\udda5\ud826\udd22\uff85\ud93f\udff2\ud8ce\udd72\ud95b\udfac\uda6c\udecb\udb29\udd15\udafa\udf7c\ud855\ude63\udad1\udc9a", "\uaf1d\u948a\u5392\u0831\ub5cc\u1819\u902b\u6b99\ucc1a\uaa30\u604e", "\ud8fb\udfe1\u7479\udb7e\udec9\udb2c\udc75\udbbc\udcfe\uda16\ude00\ud90d\ude99\udb0f\udffb\ud864\udd98",
        47, 50581, 1211094347, -7653783081913563008L, -56169L, true, true, (char) 26597, (char) 33290,
        Double.longBitsToDouble(0x3fb92b18fa0b30c8L), Double.longBitsToDouble(0x3f8f880a5491c500L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 19, 15, "\udb06\udd65\udb11\ude44\ud879\udc74\udbd9\udef4\udad0\udd63\uda01\uded3\udaf4\uddcf\ud900\udd0d\ud99c\udeb4\ud9e9\udcfb\ud908\udeb5\uda41\udc26\ud968\udc79", "\u4415", "\ud8ce\udd72\ud95b\udfac\udabe\ude55\ud84c\udd39",
        28, 6214, -1032687592, 3649691456217395945L, -40162L, true, true, (char) 19420, (char) 29177,
        Double.longBitsToDouble(0x3fc8c5c9ff6fd3ccL), Double.longBitsToDouble(0x3fd6ade8c9d2698eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 20, 14, 18, "\udada\udf9a\ud881\ude3f\udac2\udfba\udba0\ude04\udad0\udd63\uda01\uded3\udaf4\uddcf\ud8cc\uddb3\udb01\udef8\ud9e9\udcfb\ud908\udeb5\uda41\udc26\000\000\000\000\000\000\000\000\udac8\udc03\ud84c\udde7\u00e6\ud855\udc0b\ud95b\udc77\ud84e\ude07\u00e9\ud923\ude81\udaac\ude9a\udb4d\uddc3\ud9e3\uddd1\uda38\udc14\ud9c3\udc92\u734c\ud983\udcd0\udb74\udc5a\udb40\udd61\ud8ac\ude62\ud842\udd59\udab6\udca2\ud8c2\udfbb\ufecb\udb0a\udedb\ud9bd\udc17\ud860\udc20\uda19\ude20", "\u7dc6\u8626\uc6c5\u1e7a\u5c9c\u214e\u6db7\u70c4\u4e24\u26da\uaeac\u0d9b\u75ea\u7858\u7ceb\u8801\u77f5\u2293\u8793\u2a77\u0c2e\u3ecb\u87db\uc624\u5003\u379f\uc107\u65e1\u0ed1\u5761\ud582\ucd07\uaaa9\u7448\u2c1c\u7257\u057c\uba69\ua55a\u5e90\u37b1\uc3f1\ua3e5\uce53\uce70\u3aaa", "\ud898\udd41\udbac\udcb7\ud8db\udd71\udb14\uded1\ud875\udff2\ud970\ude9f\u83ee\uda74\udf0f\ud9be\udc03\ud8cf\udfba\udaf0\udcb5\udb46\udf99\udb1b\udd9b\uc570\udb2b\udfc3\ud845\udec6\ud9c2\udc57\ud900\udf1c\uda4f\udf6e\udb89\udc97\uda42\udf44\ud852\udf9a\udbe7\udd57\udb81\udd36\uda87\ude8c\udaf1\ude8a\ud9b4\udc98\ud904\ude3b\udac1\ude3d\udadd\udc96\udaf8\udf05\udba1\udf68\udb55\udf57\udb39\udd4e\udba1\udf58\ud9c5\udecc\ud983\udcbe\udbd6\ude7c\ud972\udd35\udbe9\ude3c\uda06\udf7e\ud8fc\udd15\u3e15\udb11\udf5c\ud8c6\ude38\udaa8\udf58",
        -2, 81351, 855427620, 4028567743551907780L, -17623L, false, false, (char) 40751, (char) 26883,
        Double.longBitsToDouble(0x3fed1f817d29542bL), Double.longBitsToDouble(0x3fe8173b54732392L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 20, 4, 16, "\udb06\udf49\ud9f1\uddf2\udac2\udfba\ud886\udcd7\ud809\udcbc\uda12\udc23\uda7f\ude55\ud8e3\udcf3\udafa\udf97\ud9a2\udca5\udae7\udf8d\uda94\ude2b\udb85\udc18\udb34\udc7d\ud9ea\udd7d", "\u24b4\u541c", "\udb4c\udd88\udaea\ude79\ud855\udc0b\ud95b\udc77\ud84e\ude07\udb14\udd3c\ud923\udf76\udb5f\udc13\ud80a\udcc8\ud9e9\udc13",
        33, 93614, -1087659148, -834607142748137509L, 43981L, true, true, (char) 42931, (char) 26925,
        Double.longBitsToDouble(0x3fe91a1a855d4334L), Double.longBitsToDouble(0x3fef8d2ffb6ef89dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Polygon,java.awt.Polygon|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Shape,java.awt.Shape|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Arc2D,java.awt.geom.Arc2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Ellipse2D,java.awt.geom.Ellipse2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.GeneralPath,java.awt.geom.GeneralPath|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Line2D,java.awt.geom.Line2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|clone|java.awt.Shape|static",
    "M|org.jfree.chart.util.ShapeUtilities|contains|java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|createDiagonalCross|float,float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createDiamond|float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createDownTriangle|float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createLineRegion|java.awt.geom.Line2D,float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createRegularCross|float,float|static",
    "M|org.jfree.chart.util.ShapeUtilities|createTranslatedShape|java.awt.Shape,double,double|static",
    "M|org.jfree.chart.util.ShapeUtilities|createTranslatedShape|java.awt.Shape,org.jfree.chart.util.RectangleAnchor,double,double|static",
    "M|org.jfree.chart.util.ShapeUtilities|createUpTriangle|float|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Polygon,java.awt.Polygon|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.Shape,java.awt.Shape|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Arc2D,java.awt.geom.Arc2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Ellipse2D,java.awt.geom.Ellipse2D|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.GeneralPath,java.awt.geom.GeneralPath|static",
    "M|org.jfree.chart.util.ShapeUtilities|equal|java.awt.geom.Line2D,java.awt.geom.Line2D|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
