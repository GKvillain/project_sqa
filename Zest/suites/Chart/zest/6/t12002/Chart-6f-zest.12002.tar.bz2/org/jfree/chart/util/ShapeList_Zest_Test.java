package org.jfree.chart.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class ShapeList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\udb77\udc59\udb22\udcb5\uda7b\uddeb\ud95a\udff8\udace\udecb\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud951\ude36\ud957\uddd1\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u569b", "\ud899\udd40",
        6, 43046, -1365931433, 1423434284474584878L, 70871L, false, true, (char) 18105, (char) 59874,
        Double.longBitsToDouble(0x3fdc3b1dce10702aL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud88d\udeee\ud8af\ude73\ud9f3\udd25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud899\udd9a\udb77\udc59\udb49\udcb0\ud8f9\ude22\ud957\udea0", "\ud39f\u8333\ud7a3", "\ud86d\udc89\ud8de\udd70\ud907\uddb5\ud95a\ude8a\ud957\uddd1\udb2c\uddf8\ud8ec\udddb\ud98b\uddf8\ud93a\uddb7\ud880\udee8",
        39, 41724, 796027730, 2459805928263060351L, 26288L, true, false, (char) 25608, (char) 32837,
        Double.longBitsToDouble(0x3fe53998ddf110d5L), Double.longBitsToDouble(0x3fc5998d7a572ad4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud88d\udeee\ud87f\udf95\uda26\udc25\uda02\udd29", "\ub844\u069e\ua5b6\u2613\u1f9e\u7d81\uc753\ud39f\u8333\ud7a3\ub458\u3c6d\uc92d\uc743\u1c3f\uc111\u1ae1\ubb0b\u714e\ucfcd\u48fc\ubab0\u5739\ub8d2\u8ca4\u0c56\ud041\u117f\u6e4d\u69b4\u488b\u0123\u4310\u1e3e\u7a4e\ubb71\u17fd", "\ud9eb\uddd4\ud899\udd40\ud912\udfba",
        56, 92567, 331419121, -6397276211788669668L, 83934L, true, true, (char) 65387, (char) 36723,
        Double.longBitsToDouble(0x3fe841c0ae6e8975L), Double.longBitsToDouble(0x3fbef3b6ff5a7358L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda73\udc49\udb5d\udf03", "\ub71a\u1c11\u1f9e", "\udb48\udead\ud9c8\udc7a\ud90d\udc4a",
        3, 15854, -977895869, -4294079006779872473L, -14154L, true, true, (char) 45405, (char) 29448,
        Double.longBitsToDouble(0x3fe877dc2ff17100L), Double.longBitsToDouble(0x3fcb35524b533004L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 2, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud84a\udeca\udb64\udf7a\udb22\udcb5\ud98e\udf96\ue8ec\udace\udecb\u60a4\udb48\udead\uadc4\ud90d\udc08\uda75\udc77\udadb\udd76\udb4d\udd18\uda5c\udd18\ud811\udc31\udba0\uddd4\ud8c9\udfeb\udb2c\uddf8\uda1f\uded5\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\uda63\ude3a\udbc4\udfad", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u569b", "\ud899\udd40\ud8a0\udfc1\ud957\ude8e",
        56, 37121, -1489481938, -412188099049069431L, 68633L, true, false, (char) 36767, (char) 53020,
        Double.longBitsToDouble(0x3fe3744baf7b1833L), Double.longBitsToDouble(0x3fb752e2f7786318L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 3, 0, "\ud88d\udeee\ud8af\ude73\ud9f4\udc5e\uda80\udf48\uda9c\udfdd\udb5d\udf03\ud9c3\udf91\udbf1\udc56\udb22\udcb5\uda7b\uddeb\ud95a\udff8\ud84c\udddf\udbb8\udf56\ud812\ude1d\uda56\udc81\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda45\udfd6\udbd0\udddb\ud8e0\ude69\ud966\udfca\ud957\uddd1\ud9d3\udfed\udb80\uddfc\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\ud80d\uddf3\udb59\udf28\uda4d\ude47\ud828\udc77\udbc2\udc89", "\u4310\u1e3e\u7a4e\u3272\u17fd\u569b\u78aa\u86cc\u6ce7\u431a\u652d\u18a9\u758a\u5786\u5654\u68b9\u0bcf\ud172\u9a24\u083c\u3289\u0c2f\u8daa\u06b8\u8cc7\u382b", "\udb88\udc97\ud902\udd25\uda52\udcdc\uf3d6\ud832\udf74",
        21, 60249, -302141486, -5103914509494453369L, 12636L, true, true, (char) 5146, (char) 18845,
        Double.longBitsToDouble(0x3feac9de906cbde2L), Double.longBitsToDouble(0x3fea755356ce9527L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 0, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud88d\uded7\ud8d5\udd62\udb2b\udc35\uda7b\uddeb\ud95a\udff8\udace\udecb\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\udb7a\udf59\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\uda0a\ude80\uda96\udee0\udb2c\udd7e\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\ud89c\ude60\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u569b", "\ud899\udd40",
        6, 43046, -1365931433, -7943359934597935314L, 70871L, false, true, (char) 18105, (char) 59874,
        Double.longBitsToDouble(0x3fdc3b1dce10e82aL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 7, "\ud88d\udeee\uda3a\udc7d\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\udb77\udc59\udb22\udcb5\uda7b\uddeb\ud980\udcbe\ud888\udce4\ud8d1\udf6d\udb48\udead\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud951\ude36\ud957\uddd1\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\udaee\udc49\ud975\udc6a\udb3d\udfcd", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u569b", "\ud899\udd40",
        44, 43046, -1365931433, 1423434284474584878L, 70871L, false, true, (char) 18105, (char) 59874,
        Double.longBitsToDouble(0x3fee1d8ee708dcdbL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 1, 2, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\udb77\udc59\udb22\udcb5\uda7b\uddeb\ud95a\udff8\udace\udecb\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud87e\udead\ud955\udeec\udb2c\uddf8\udb67\uded9\ud9b1\udff8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u569b", "\ud86e\udfa4",
        6, 43046, -1365931433, 1423434284474584878L, 70871L, false, true, (char) 18105, (char) 19048,
        Double.longBitsToDouble(0x3fd0f9762e10702aL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\udb1b\udc33\uda2a\udcda\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\udb77\udc59\udb22\udcb5\uda7b\uddeb\ud95a\udff8\udace\udecb\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\ud970\udf81\uda64\udf8e\ud8e0\ude69\ud951\ude36\ud957\uddd1\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud888\udf7b\udbf3\udca2", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u6c34", "\ud899\udd40\ud912\udfba\ud9d9\udc62\udac9\udd8a\u5f1b\uda5c\uddf2\udabb\udcc5\u1e61\ud901\udf3c\ud8be\udf97\ud86a\ude26\ud856\udd11\uda6c\udc0b\uda3c\udf88\ud9a1\ude6f\ud890\udec1\ud87e\udf41\udb5c\udcbc\ud933\ude2b\ud955\udcf3\udba6\udc91\ud97c\udfc5\ud8c0\udc75\ud806\udcea\ud97d\udcbf\udb50\udf9d\ud9fa\uddda\uda72\udce3\ud820\uddd2\udb49\udd3c\ud855\udca3\ud92e\udeea\udbdd\udd25\ud9df\uddfc\ud87e\uddb1\udab5\udc2c\ud928\udc0e\udb3d\udd2f\ud83b\udc6c\ud973\uddd4\ud8f2\udc0f\uda80\udeca",
        7, 48390, -740243162, 868745244085062040L, 27518L, false, false, (char) 55004, (char) 22471,
        Double.longBitsToDouble(0x3feaeb7d8ddc75e1L), Double.longBitsToDouble(0x3fdfda6b7be2388aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 7, 7, 4, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\udb77\udc59\ud9aa\udc79\udbb0\udf6d\ud9e8\udf2e\udace\udecb\uda0a\udedd\ud8cf\udf98\udb00\udda7\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud951\ude36\ud957\uddd1\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\u2eb4\uc2dd\u30e0", "\ud899\udd40",
        6, 43046, -1365931433, 1423434284474584878L, 70871L, false, true, (char) 18105, (char) 59874,
        Double.longBitsToDouble(0x3fe576dee59e78baL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29", "\ub8d6\u069e\ua5b6\u2613\u1f9e\u7d81\uc753\ud39f\ub2e1\ud7a3\uc008", "\udbd0\ude61\udbed\uded0\ud948\udf11\ud994\udfd0\udb8f\ude50\ud9c7\udcae\ud99c\uddc3\ud90f\ude7b\udb9e\ude26",
        24, 7236, 584946514, 2459699735196666751L, 26288L, true, false, (char) 25608, (char) 32837,
        Double.longBitsToDouble(0x3fe53998d86b14c0L), Double.longBitsToDouble(0x3fd79e7306869decL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 0, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\uda3c\udd5c\u6879\u891e\ud904\udec1\uda29\uddb5\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\udb6b\udea9\uda6f\udf86\ud995\udfe5\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u8e9a", "\ud899\udd40",
        6, 43046, -1365931433, 1423434284474584878L, 70871L, false, true, (char) 18105, (char) 59874,
        Double.longBitsToDouble(0x3fdc3b1dce10702aL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\uda02\uded6\udbac\udfae\u8061", "\u6622\ub8d6\u069e\ua5b6\u2613\u1f9e", "\udb48\udead\ud9c8\udc7a",
        53, 22378, 846194854, -4200030777248293403L, -16484L, false, true, (char) 47345, (char) 16235,
        Double.longBitsToDouble(0x3fe6a6600b527e8eL), Double.longBitsToDouble(0x3fe70916eb7f22f5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 7, "\uda94\ude91\ud886\udf0d\uda46\ude35\uda02\uddc4\uda6a\udc49\udb5d\udf03\ud9c3\udf91\udb45\ude59\udb22\udc9f\uda7b\uddeb\u938d\udab2\ude8f\uda4e\udc23\udbcd\udd9f\udb61\udc09\ud910\udf4a\ud881\udc3c\udbac\udf9e", "\u1c3f\u549f\u7b02\ubb0b\ub94e\uc0ec", "\uda44\uddc8\ud90a\ude49\u0560",
        48, 82719, 1062719084, -2873510344003823708L, -97751L, true, true, (char) 41307, (char) 58341,
        Double.longBitsToDouble(0x3f9808f9d0bf7e00L), Double.longBitsToDouble(0x3fe6a3679a72650fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\ud8fe\udc1a\udb22\udc6e\uda7b\uddeb\ud95a\udff8\udace\udecb\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud951\ude36\ud957\uddd1\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u569b", "\ud899\udd40",
        6, 43046, -1365931433, 1423434284474584878L, 70871L, false, true, (char) 18105, (char) 59874,
        Double.longBitsToDouble(0x3fdc3b1dce10702aL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "", "", "\uda6a\udc49\udb5d\udf03\ud899\udd9a\udb77\udc59\udb49\udcb0\ud8f9\ude22\ud957\udea0",
        54, 33142, 133259830, 174224582001255120L, -64017L, true, false, (char) 49222, (char) 64954,
        Double.longBitsToDouble(0x3fed1bb124366b7fL), Double.longBitsToDouble(0x3fe1e2fe630efb85L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 0, 4, 7, "\ud88d\udeee\ud8af\ude73\ud9f3\udd25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud899\udd9a\udb77\udc59\udb49\udcb0\ud8f9\ude22\ud957\udea0", "\ud39f\u8333\ud7a3", "\ud86d\udc89\ud8de\udd70\ud907\uddb5\ud95a\ude8a\ud957\uddd1\udaf8\ude9e\ud8ec\uddc2\ud98b\uddf8\ud93a\uddb7\ud880\udee8",
        39, 41724, 1736665938, 2459805447226723199L, 26288L, true, false, (char) 25608, (char) 32837,
        Double.longBitsToDouble(0x3fe53998ddf110d5L), Double.longBitsToDouble(0x3fc5998d7a572ad4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud88d\udeee\ud8af\ude73\ud9f3\udd25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud899\udd9a\udb77\udc59\udb49\udcb0\ud8f9\ude22\ud957\udea0", "", "\ud90d\udc4a\ud880\udfe0\udbac\udf9e\ud86d\udc89\ud8de\udd70\ud907\uddb5\ud95a\ude8a\ud957\uddd1\udb2c\uddf8\ud8ec\udddb\ud98b\uddf8\ud93a\uddb7\ud880\udee8\ud827\udcd9\000\udb18\udecb\u1679\uda69\udc92\uda6c\ude27\ud95c\udf37\udbb4\udc89\ud9bd\udf10\udbe7\udf9b\udbb0\uddc4\ud803\udcae\udbd9\udfa4\udb48\udee6\000\ud8c2\udd67\udada\udfe4\ud800\udc5c\ud941\udde3\ud8d2\udf20\ud843\ude7c\uda85\udd2b\udabb\udd19\ud8d3\udc83\udb46\udd4d\udb06\udc52\ud9bc\udcee\udb45\uddc8",
        -3, 86842, 599679602, 5135229745094911902L, -67009L, true, false, (char) 46051, (char) 61660,
        Double.longBitsToDouble(0x3feaf83609e8e410L), Double.longBitsToDouble(0x3fd386fc790b4744L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 0, 0, 0, "\000", "L", "",
        52, -1000, 0, 2103326525L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 0, 0, "b", "", "\000",
        -5, 92624, 1379882968, 894532975647930173L, -6682L, false, false, (char) 71, (char) 25914,
        Double.longBitsToDouble(0x3fe8348a98a60e76L), Double.longBitsToDouble(0x3fb0cc9bdb8f15b0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud88d\udee3\ud8af\ude73", "\ud771\u6622\u4786\u069e\uc952\u841d\u3bd3\u48c3\uc789\ud39f\u8333\ud7a3\u6fcc\u3c6d\uc38c\u4c0d\ucc7c\u0d66\u1ae1\u0520\u503f\ud472\u7e43\u2697", "\udb33\ude1d",
        8, 21743, 1062719084, -2873510345180510104L, -97751L, true, true, (char) 7236, (char) 61071,
        Double.longBitsToDouble(0x3fef888314ac1fc0L), Double.longBitsToDouble(0x3fe4ae55a9f93348L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 2, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud84a\udeca\udb64\udf7a\udb22\udcb5\ud98e\udf96\ue8ec\udace\udecb\u60a4\udb48\udead\uadc4\ud90d\udc08\uda75\udc77\udadb\udd76\udb4d\udd18\uda5c\udd18\ud811\udc31\udba0\uddd4\ud8c9\udfeb\udb2c\uddf8\uda1f\uded5\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\ud814\udd82\ud810\udf99\udbc4\udfad", "\u4242\u1e3e\u7a4e\ubb71\u17fd\u569b\u9623", "\ud8a0\udfc1\ud957\ude8e\udac9\uddf7\u5f1b\uda5c\uddf2\udabb\udcc5\u1e61\ud901\udf3c\ud8be\udf97\ud86a\ude26\ud856\udd11\uda6c\udc0b\ud823\udfdb\ud90b\ude37",
        -5, 56999, -525484977, 4375518046979046495L, -25839L, false, true, (char) 21666, (char) 8106,
        Double.longBitsToDouble(0x3fb6b4ff372caef0L), Double.longBitsToDouble(0x3fe0678715a46cefL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 3, 0, 0, "\ubb54\udadc\udf3f\ud88c\udfab\ud8bf\udc16\uda6a\udc6b\udb5d\udf03\ud80a\udc8a\udb64\udee6\ud9f4\udd92\ud8ff\udc8d\ue8ec\udace\udecb\u60a4\udb48\udead\uadc4\ud90d\udc08\uda75\udc77", "\u9605\u3e3f\u1263\u2c3e\u1e49\ud6c2\u2807\u48fc\ubab0\u765e\ub8f8", "\uda6e\udf92\uda6c\ude27\uda63\uddbd\udbc4\udfad\ua627\udadb\udd9f\udbb0\uddc4\udb99\udd39\u5d09\udba3\udfc3\udb87\ude1e\uda9d\udcc8",
        10, 91717, -124330576, 1304903356427482026L, -74684L, true, false, (char) 48172, (char) 1684,
        Double.longBitsToDouble(0x3fdeb9a700eb447cL), Double.longBitsToDouble(0x3fe910237e4959b4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 7, "\ud88d\udeee\ud8af\ude81\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud84a\udeca\udb64\udf7a\ud996\udcaf\ud98e\udf96\ue8ec\udace\udecb\u60a4\udb48\udead\ud834\ude68\ud929\udd85\uda7e\udcc4\udadb\udd76\udb4d\udd18\uda5c\udd18\ud811\udc31\udba0\uddd4\ud8c9\udfeb\udb2c\uddf8\uda1f\uded5\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\uda63\ude3a\udbc4\udfad", "\u4310\u86d4\u7a37\ubb71\u17fd\u5f08", "\ud899\udd40\ud8a0\udfc1\ud957\ude8e",
        56, 37121, -1489481938, -412188099049069431L, 68633L, true, false, (char) 36767, (char) 53020,
        Double.longBitsToDouble(0x3fe3744baf7b1833L), Double.longBitsToDouble(0x3fe4e87b5eef0c63L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 2, 4, 7, "", "\u1a63\ua696\ud771\u6622\u6a82\u95be\u12b6\u7fbf\000\000", "\ud816\uddb9",
        52, 36130, 852652664, 8357693833727204502L, -16484L, false, true, (char) 47345, (char) 16235,
        Double.longBitsToDouble(0x3f49802c00000000L), Double.longBitsToDouble(0x3fef0916eb7f2222L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 2, 2, 5, "\ud88d\udeee\ud8a3\udfa0\uda26\udc25\uda02\udd29\udb47\ude18\udb81\udf9b\uda60\udecf\udb64\udf7a\udb22\udcb5\ud98e\udf96\ue8ec\udace\udecb\u60a4\udb48\udead\ud9a2\udc1e\ud90d\udc5e\uda75\udc77\udadb\udd76\udb4d\udd18\udae1\udf9d\u22fb\udba0\uddd4\udbf7\ude62\udb2c\uddf8\uda1f\uded5\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\udbb3\udc8b\uda63\uddec\udbc4\udfad", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u0941", "\ud899\udd40\ud8a0\udfc1\ud957\ude8e",
        56, 37121, -1489481938, -412188097174477687L, -6489L, true, false, (char) 36767, (char) 53020,
        Double.longBitsToDouble(0x3fe3744f2f7b1833L), Double.longBitsToDouble(0x3fb752e2f7786318L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 7, 4, 7, "\ud91e\udc6a\ud8af\ude73", "\ud771\ubb36\u6a82\uc81c\uc234\ub7e4\u9888", "\udb48\udead\uadc4\ud90d\udc08",
        5, 9664, 1945927235, -4267058848461557977L, -75131L, true, true, (char) 59317, (char) 27583,
        Double.longBitsToDouble(0x3fe877dc2ff17100L), Double.longBitsToDouble(0x3fcb35524b533004L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Integer:240804362 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 3, 0, "\ud876\uddee\udbc1\ude7c\ud9f4\udc5e\uda78\udded\uda9c\udfdd\udb80\udd03\ud9c3\udf91\ud872\ude96\udb22\udcb5\uda7b\uddeb\ud95a\udff8\u2321\udbdd\udece\ud882\ude3c\uda56\udc61\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda45\udfd6\udbd0\udddb\ud95d\udd67\ud960\udd2d\ud957\uddd1\ud9d3\udfed\udb80\uddfc\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\ud80d\uddf3\udb59\udf28\ud8c4\udd48\ud828\udc77\udb06\udc49", "\u4310\u1e3e\u7a4e\u3272\u17fd\u569b\u78aa\u2c22\u6d29\u431a\u6543\u27c6\u5db8\ud794\u5654\u68b9\u0dbb\u9e6a\u9a24\u083c\u3289\u0c2f\u8daa\u06b8\u8cc7\u382b", "\udb88\udc97\ud902\udd25\uda52\udcdc\uf3d6\ud832\udf74\udae7\udecc\ud81c\udcab\ud90d\udec2\ud977\udc9f\ud9ad\udd7e",
        54, 98100, -1675839695, 870112420317441882L, -3852L, false, true, (char) 9205, (char) 42990,
        Double.longBitsToDouble(0x3fd774273ed1fc82L), Double.longBitsToDouble(0x3fe0a63d5229337bL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 5, 7, "\ud88d\udeee\ud8af\ude73\ud812\udddb\uda8d\uded6\uda53\udfa7\uda0f\uddac\ud88d\uded7\ud822\udc3c\udb2b\udc35\ud823\udd60\ud833\uddb3\uda25\udc85\u6076\udb48\udead\ud9c8\udc7a\ud90d\udc4a\udb72\ude59\udbac\udf9e\uda62\udfd3\udba0\udd28\ud82c\uddb2\uda0a\uddc8\uda96\udee0\udb2c\udd7e\ud81d\uddfb\ud98b\uddf8\udb4c\udf8a\ud880\udee8\uda44\uddc8\ud834\udc9f\u0520\uda44\udd8f\uda69\udca3\udaab\udd87\ud8ea\udd48\ud84d\udd0c", "\u067d\u1e4a\u7a4e\u3928\u17fd\ubba8", "\ud899\udd40\ud912\udfba\uda50\udd95\ud9ae\udcf3",
        -1, 65062, -95970020, -7527374763246669438L, -67551L, true, true, (char) 2845, (char) 42979,
        Double.longBitsToDouble(0x3fbef3b6c3685620L), Double.longBitsToDouble(0x3fda3af1b4294df8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 0, "\ud88d\udeee\ud8af\ude73\ud83e\udd6c\uda29\udd12\udb9e\ude47\uda4f\udea5\ub2a8\ud9f0\udde0\ud839\udc09\udb93\ude5c\uda90\ude71\udb63\udf4a\ud821\ude08\ud893\uddd3\udb80\udfed\udb10\udc20\udb7a\udf59\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\uda0a\ude80\uda96\udee0\udb2c\udd7e\ud931\udc88\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud8c2\udcb4\u0560\u935f\udb70\udc3e\udbc4\udf72\ud95c\udf20\udbc2\udc89", "\u4310\u1e3e\u69d2\ubb71\u17fd\u194c", "\ud899\udd40",
        6, 43046, -800616873, -7965188414390120658L, 70871L, false, true, (char) 4173, (char) 59874,
        Double.longBitsToDouble(0x3fdc3b1dce10e82aL), Double.longBitsToDouble(0x3fe3744bab7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\0121=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 7, 5, 5, "\ud88d\udeee\ud8af\ude73\uda26\udc25\ud87a\uddd3\ud96f\udd59\udb87\udd0f\udb8d\ude88\ud8c8\udd53\udb2b\udc35\uda7b\uddeb\ud95a\udff8\udace\udecb\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\udb7a\udf59\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\uda0a\ude80\uda96\udee0\udb2c\udd7e\udb67\uded9\ud98b\uddf8\udb38\uddb6\udbc8\udeeb\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda31\udc96\ud89c\ude3e\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\u5b55\u17fd\u569b", "\ud899\udd40",
        6, 43046, -1365931433, -7943359934597935314L, 70871L, false, true, (char) 18105, (char) 59874,
        Double.longBitsToDouble(0x3fdc3b1dce10e82aL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\0121=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 1, 1, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda82\ude42\udb5d\udf03\ud9c3\udf91\udb77\udc59\udb22\udcb5\uda7b\uddeb\ud95a\udff8\udace\udecb\uda78\udeeb\udb48\udef9\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\udb70\udf31\ud955\udeec\udb2c\uddf8\udb67\uded9\ud9b1\udff8\udba0\udc6a\udbfd\udfb0\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\ud9f7\udead\ud859\ude75\udbcb\udcaa", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u569b", "\ud86e\udfa4",
        6, 43046, -1365931433, 1423434284474584878L, 70871L, false, true, (char) 18105, (char) 19048,
        Double.longBitsToDouble(0x3fd0f9762e10702aL), Double.longBitsToDouble(0x3fe3744bac7bcedbL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 2, 2, 7, "\ud88d\udef4\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\ud84d\ude9c\udafb\ude15\ub99a\uda40\ude18\uda7b\uddeb\udb38\udf0d\udb21\udce7\udacf\udf12\ud836\udfe5\ud8cd\udfe3\ud90c\udfec\ud881\udc3c\u917c\udbda\uded6\ud843\udf20\ud8e0\ude99\ud87e\udead\ud955\udeec\udb2c\uddf8\udb67\uded9\ud9b1\udff8\udb38\uddb6\ud8e4\udfbf\uda44\uddc8\udb20\udd35\ud974\udc64\udbed\udde3\ud8cc\ude62\udb4a\udd36\ud9e3\udd64\udbc2\udc89", "\u4310\u1e3e\u31e8\u8e5a\ud2d4\u569b", "\ud86e\udfa4",
        -4, 14782, 1557593380, -4557346017600635346L, -10533L, true, true, (char) 6259, (char) 53871,
        Double.longBitsToDouble(0x3fe5c4bb17524b29L), Double.longBitsToDouble(0x3fe3744bada2c5dbL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\0121=new org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 7, 7, 1, "\ud88d\udeee\udb51\ude24\uda31\udfb9\uda02\udd29\uda6a\udc49\udb0d\uddd3\udb2f\udfd4\ud81f\ude95\udb22\udcbc", "\u97da\uadf4\ud39f\u8333\ud7a3\ub485", "\udb78\uddd9\ud8e0\ude69\ud87e\udead\ud955\udeec\udb2c\uddf8\udb67\uded9\ud9b1\udff8\udb38\uddb6\ud880\udee8",
        39, 41724, 1325013842, 106571223408160524L, 26288L, true, false, (char) 25608, (char) 32837,
        Double.longBitsToDouble(0x3fe53998d8daeed5L), Double.longBitsToDouble(0x3febcf3986d46c6eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 2, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9b2\udce9\udb75\udff7\udba9\udf69\uda64\udefb\uda97\ude98\udace\udecb\u60a4\udb48\udead\ud92c\udd6c\udb0c\udcb9\udbfe\ude6b\udb76\udf19\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud87e\udead\ud955\udeec\udb2c\uddf8\udb67\uded9\ud9b1\udff8\udb38\uddb6\ud880\udee8\udb27\udf15\ud9a0\udc35\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e", "\uda9d\udcc8\ud9ae\udd1f\ud9b3\udff8\ud864\udfa4\ud912\udfba\uda98\udc0f\udac9\udd88\u5f1b\uda5c\uddf2\udabb\udcc5\u1e61\ud901\udf3c\ud846\uddfc\udacb\udc1c\ud856\udc5d\uda6c\udc0b",
        59, 15051, 288970839, 7108095015719014930L, -65263L, true, false, (char) 35515, (char) 56476,
        Double.longBitsToDouble(0x3fe52b6fe37fb237L), Double.longBitsToDouble(0x3fcad77fe52ff54cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud9fd\udee6\000\ud9f3\udc59\u194c\udb6a\ude75\udb5d\udf03\ud9c3\udf91\udb77\udc59\000\000\000\000\u680d\000\ud98a\udc24\ud8f4\ude4ab\000\uda61\udc90\ud865\uddeb\000\000\000\000\udb67\udea3\ud9b1\udff8\udb38\uddb6\uda63\udff9\000\udb9b\udf6cR\000\uda69\udc92\uda39\udc27\ud95c\udf37\udbc2\udc89", "\u00fb\u1e3e\u7a4e\ubb71\u17fd\u569b", "\000",
        -5, -1000, 9764864, 1423433250876948480L, 70871L, false, false, (char) 27975, (char) 19048,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e41ef3800000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 7, "\ud968\udef2\ud87b\udfbe\uda26\udc25\uda02\udd29\udb62\udc45\ud95f\udeca\ud9c3\udf91\udb77\udc59\udb22\udcb5\uda7b\uddeb", "\uc753\ud39f\ub2e1\ud7a3\uc008\ub79d\uc92d", "\ud8a3\udedb\ud994\uded5",
        0, 10646, -75134457, 5412985961577972055L, -14540L, false, true, (char) 48829, (char) 11681,
        Double.longBitsToDouble(0x3fe364542d913f57L), Double.longBitsToDouble(0x3fed26c0fd500f3dL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\udb62\udc45\udafe\ude70\ud834\udece\udb77\udc59\udb22\udcb5\uda7b\uddeb\ud95a\udff8\udae2\ude75\u605f\udb48\udead\ud980\udc76\ud90d\udc4a\ud8b5\uded7\udbaa\uddbe\uda80\uded3\udbd0\ude61", "\u1295\u1c8e", "\ud8f3\udf67\udb2e\udc29\ud88e\udcf3\uda5b\udcd7\ud80a\udd03\udb07\udef8\ud98a\udd08\uda6c\ude37\ud95c\udf37\udbc2\udc89\ud9bd\udf10\ud9d3\udcf1",
        1, 77203, -754178233, -1771370486970593457L, 32433L, true, true, (char) 21691, (char) 40456,
        Double.longBitsToDouble(0x3fc33351ec4ad398L), Double.longBitsToDouble(0x3fec5385e85a8788L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 0, 7, "\ud88d\udef1\ud831\ude74\uda26\udc25\ud9be\udd05\uda6a\udc49\udb5d\udf03\ud8cf\ude37\uda3c\udd5c\u6879\u891e\ud8bf\udeac\udbc2\udc90\u60a4\udb4d\udd8f\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\ud888\udd7e", "\u2ff1\ud408\u21bd\u75b5\u714e\u8e8e", "\uda44\udd17\ud90a\ude49\u0560",
        48, 21743, 1062719084, -2873510344003823708L, 92711L, false, true, (char) 57540, (char) 12557,
        Double.longBitsToDouble(0x3fee15074779e724L), Double.longBitsToDouble(0x3fe6a363753fde0fL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 0, "", "", "\uda6a\udc49",
        51, 22484, -323801344, 5950100365910212663L, -99818L, false, false, (char) 0, (char) 65279,
        Double.longBitsToDouble(0x3fdd0c7d80c522a6L), Double.longBitsToDouble(0x3e468c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 5, 7, "\ud85d\udf34\ud8af\ude73\ud946\udeae\uda8d\uded6\uda53\udfa7\uda0f\uddf1\ud88d\uded7\udb32\udec4\udb2b\udc35\ud823\udd60\ud82a\udeb3\uda25\udc85\udb84\udd71\udb48\udead\udbc3\uded8\udbc9\ude3f\uda64\udc86\ud9a3\udd6f\uda62\udfd3\udba0\udd28\ud834\udc9b\uda0a\uddc8\uda96\udee0\udb2c\udd7e\ud81d\uddfb\ud98b\uddf8\udb4c\udf8a\ud90a\uddec\uda44\udd06\ud834\udc9f\ud83e\udf2d\uda44\udd8f\uda69\udca3\udaab\udd87\ud8ea\udd48\ud84d\udd0c", "\u067d\u1e4a\u7a4e\u3928\u17fd\ubba8", "\ud899\udd40\ud953\udc00\ud9f3\ude2f\ud9ae\udcf3",
        43, 35243, -95966626, -7527374763246669438L, -2015L, true, true, (char) 24900, (char) 42979,
        Double.longBitsToDouble(0x3fbef3b6c3685620L), Double.longBitsToDouble(0x3fda3af1b4294df8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 2, 7, "\ud859\uddce\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9b2\udce9\udb75\udff7\udba9\udf69\uda64\udefb\uda2e\udfd0\udad1\udec2\ud8e9\udf09\ud95c\udc8a\ud8e3\udca1\udb0c\udc44\udbfe\ude6b\udb76\udf19\uda80\uded3\udbc5\udd61\ud8e0\ude69\ud87e\udead\ud955\udeec\udb2c\uddf8\udb67\uded9\ud9b1\udff8\udb38\uddb6\ud880\udee8\udb27\udf15\ud9a0\udc35\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u42b4\u1e3e\u7a4e\u19ab\u17fd\u569b\u80bd\u8c28\u734a\u300d\ucb60\u51d6\u8d5a\ud5f4\u5654\u68b9\u0bcf\u6b0f\u5649\u02d9\u32f4\u0c2f\u3585\u828e\ubaed\ua251\u6531\ua0fc\uc97c\u4ae6\ua5b0\u74d5\u4f37\ud351\u1fa8\ud0f4\ube9f\uc0c7\u01be\u294d", "\ud92e\udd9d\udba7\ude89\uda6e\uddd8\ud82e\udd80\ud8c8\udf25\ud955\ude67\udaa3\udd8c\ud8de\udc69\ud8a0\udd1f\ud947\udd6f\udb75\udc70\ud9ac\ude7d\uda95\uddb6\ud816\udd37\uda65\udff6\uda90\uddd4\ud98b\uddbd\udade\udfff\udbc6\udcdc\udb1d\udcd0\ud80b\uddb5\ud99d\udfeb\udb96\udf3d\ud88d\udc67\ud9ef\ude9f\uda51\ude60\uda33\udd5f\ud9ad\uded1\ud8a6\udd4a",
        0, 21800, 1396727648, -6994348670534251010L, -93758L, true, false, (char) 623, (char) 41242,
        Double.longBitsToDouble(0x3fe984b217b7cb7eL), Double.longBitsToDouble(0x3fc68ee23ce25064L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 2, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9b2\udce9\udb75\udff7\udba9\udf69\uda64\udefb\uda97\ude98\udace\udecb\u60a4\udb48\udead\ud92c\udd6c\udb0c\udcb9\udbfe\ude6b\udb76\udf19\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud87e\udead\ud955\udeec\udb2c\uddf8\udb67\uded9\ud9b1\udff8\udb38\uddb6\ud880\udee8\udb27\udf15\ud9a0\udc35\u0560\ud8d1\uddea\uda69\udc92\uda6c\ude27\ud95c\udf37\udb8e\udd2f", "\u4310\u1e3e\u7a4e", "\uda9d\udcc8\ud9ae\udd1f\ud9b3\udff8\ud864\udfa4\ud912\udfba\udb2f\udcbf\udb85\udda6\u5eaa\uda5c\uddf2\udabb\udcc5\u1e61\ud901\udf3c\ud846\uddfc\udacb\udc1c\ud856\udc5d\uda6c\udc0b",
        1, 15051, 288970839, 7108095015719014930L, -65263L, true, false, (char) 35515, (char) 56476,
        Double.longBitsToDouble(0x3fe2936fe37fb237L), Double.longBitsToDouble(0x3fcad77fe52ff54cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 5, 4, "\ud9fd\udee6\000\ud9f3\udc59\u194c\udb6a\ude75\udb5d\udf03\ud9c3\udf91\udb77\udc59\000\000\000\000\u680d\000\ud98a\udc24\ud8f4\ude4ab\000\uda61\udc90\ud865\uddeb\000\000\000\000\udb67\udea3\ud9b1\udff8\udb38\uddb6\uda63\udff9\000\udb9b\udf6cR\000\uda69\udc92\uda39\udc27\ud95c\udf37\udbc2\udc89", "\u00fb\u1e3e\u7a4e\ubb71\u17fd\u569b", "\000",
        -5, -1000, 9764864, 1423433250876948480L, 70871L, false, false, (char) 27975, (char) 19048,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e41ef3800000000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 5, 7, "\ud85d\udf34\ud8af\ude73\ud9d2\ude93\ud87a\ude1d\uda53\udff2\uda0f\uddf1\ud88d\uded7\udb32\udec4\udb2b\udc35\ud823\udd60\ud82a\udeb3\uda25\udc85\udb84\udd71\udb48\udead\udbc3\uded8\udbc9\ude3f\uda64\udc86\ud9a3\udd6f\uda62\udfd3\udba0\udd28\ud834\udc9b\uda0a\uddc8\uda96\udee0\udb2c\udd7e\ud81d\uddfb\ud98b\uddf8\udb4c\udf8a\ud90a\uddec\uda44\udd06\ud834\udc9f\ud81d\udc2d\uda44\udd8f\uda69\udca3\udaab\udd87\ud8ea\udd48\ud84d\udd0c", "\u6b33\ucf54\u7a4e\u3928\u17fd\ubba8", "\ud899\udd40\ud953\udc00\ud9f3\ude2f\ud9ae\udcf3",
        1, 73268, -95963092, -7527374763246669438L, -2015L, true, true, (char) 8004, (char) 63948,
        Double.longBitsToDouble(0x3fbef3b6dc393ff8L), Double.longBitsToDouble(0x3fe2bbc5b214a6fcL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 4, 7, "\ud88d\udeee\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud9c3\udf91\udb77\udc59\udb22\udcb5\uda7b\uddeb\ud95a\udff8\udace\udecb\u60a4\udb48\udead\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud951\ude36\ud957\uddd1\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u4310\u1e3e\u7a4e\ubb71\u17fd\u68d1", "\ud899\udd40\ud912\udfba\ud9d9\udc62\udac9\udd8a\u5f1b\uda5c\uddf2\udabb\udcc5\u1e61\ud901\udf3c\ud8be\udf97\ud86a\ude26\ud856\udd11",
        47, 62374, -410264453, -4303363492577565872L, -26226L, true, false, (char) 14600, (char) 22303,
        Double.longBitsToDouble(0x3fe3f7a5b84cc128L), Double.longBitsToDouble(0x3fe9587edac58455L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 2, 7, "\ud859\uddce\ud8af\ude73\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ud985\udd22\ud8a9\udfb0\ud8fb\udf59\udb56\udc0b\uda2e\udfd0\udad1\udec2\ud8e9\udf09\ud95c\udc8a\ud8e3\udca1\udb0c\udc44\udbfe\ude6b\udb76\udf19\uda80\uded3\udbc5\udd61\ud8e0\ude69\ud87e\udead\ud955\udeec\udb2c\uddf8\udbe6\udcf8\udae9\ude32\udb38\uddb6\ud880\udee8\udb27\udf15\ud9a0\udc35\u0560\udbed\udde3\uda69\udc92\uda6c\ude27\ud95c\udf37\udbc2\udc89", "\u42b4\u1e3e\u7a4e\u19ab\u17fd\u6f22\u80bd\u8c28\u734a\u300d\ucb60\u51d6\u8d5a\u7b4b\u5654\u68b9\u0bcf\u6b0f\u5649\u02d9\u9f35\u0c2f\u3585\u828e\ubaed\ua251\u6531\ua0fc\uc97c\u4ae6\u059b\u1457\u4f37\ud351\u1fa8\u891c\u5c6d\uc917\u01be\ua231", "\ud92e\udd9d\udba7\ude89\udbf3\udeda\ud82e\udd13\ud8c8\udf25\ud955\ude67\udaa3\udd8c\ud8de\udc69\ud8a0\udd1f\ud947\udd6f\udb75\udc70\ud9ac\ude7d\uda95\uddb6\ud816\udd37\uda65\udff6\uda90\uddd4\ud98b\uddbd\udade\udfff\udbc6\udcdc\udb1d\udcd0\ud80b\uddb5\ud99d\udfeb\udb96\udf3d\ud88d\udc67\ud9ef\ude9f\uda51\ude60\uda33\udd5f\ud9ad\uded1\ud8a6\udd4a\udb27\ude1f\udb76\ude98\udbe9\udc47\uda53\udf38\udba7\udf7f\udb55\uddda\udae6\ude1e\ud9b4\udf73\ud824\uddd0\udba2\udff2\ud958\ude4a\udaee\udd81\udb59\udc17\ud93b\udebb\ud85b\ude58\udb20\uddab\ud89a\udd8e\ud875\udd4e\ud9b1\udfe4\ud9f7\ude17\ud903\udf18\udb41\ude9a\uda31\ude4b\ud82e\udd1b\ud9d5\udf08\ud908\udf71\ud81a\udd36\uda94\udcdc\ud87b\udc4d",
        6, 1420, -1132216996, -4481032639708846497L, -17587L, false, false, (char) 41623, (char) 45217,
        Double.longBitsToDouble(0x3fd1bdd04be2f36eL), Double.longBitsToDouble(0x3fe0d13b40ba68c9L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 7, "\ud88d\udeee\uda3a\udc7d\uda26\udc25\uda02\udd29\uda6a\udc49\udb5d\udf03\ub8c7\udb76\udfe4\udb22\udcb5\uda7b\uddeb\ud980\udcbe\udb44\ude02\ud8cf\udcac\ud839\udf08\ud9c8\udc7a\ud90d\udc4a\ud881\udc3c\udbac\udf9e\uda80\uded3\udbd0\ude61\ud8e0\ude69\ud951\ude36\ud957\uddd1\udb2c\uddf8\udb67\uded9\ud98b\uddf8\udb38\uddb6\ud880\udee8\uda44\uddc8\ud90a\ude49\u0560\udbed\udde3\uda69\udc92\udaee\udc49\ud975\udc6a\udb3d\udfcd", "\u4310\u1e3e\u7a4e\ubb71\u2d59\u8818", "\ud899\udd40\udb8f\uddb3\ud9d9\udc62\udac9\udd8a\u5f1b\uda5c\uddf2\udabb\udcc5\u1e61\ud901\udf3c\ud8be\udf97\ud86a\ude26\udb25\uddb0\uda6c\udc0b\uda3c\udf88\udaae\ude15\uda78\udf88\ud8ff\uded0\uad46\ud966\udfb7\udb67\udd2b\udb51\uddb4\uda6d\udfb1\udba2\udcb6\u097a\ud825\uddce\udbb4\udc62\ud910\ude00\uda6e\udc68\ud917\udf4b\udaf1\uddbe\udb84\udc76\udb4b\udfd5\udb06\ude32\ud8e5\udc02\udb11\ude77\ud88f\udf54\ud909\udd57\ud941\udfa5\udb34\udc59\ud9e2\udf20\udada\ude54\udb3e\udd50\ud801\udf51\ud915\udd01\uda6e\udd9c\ud8c6\udf1e\udb91\uded9\ud83d\ude98\uda03\udc42\uda1e\ude7c\ud985\udd4f\ud8c0\uddf6\udb56\ude9f\uda23\uddea\udb88\udec5\ud9c3\udd6b\ud85d\udcc8\ud8ae\udf7a\udb51\udda0\ud8b3\udea0\udaaa\udfc2\udbae\ude88\ud918\ude96\ud955\udcce\udbe0\udefd\ud8e1\udeff\ud89f\udc0f\udb95\udfb6\ud82e\udf50\u369c\ud9e6\ude3d\udbba\ude94\ub0cb\u5d4b\ud8f0\udf4e\udb56\udcef\u309e\ud898\udef2\udaa7\udc62\ud923\ude20\ud9bb\udd39\udb92\udd29\uda53\udc02\udbb3\uddf2\udafa\ude8b\ud934\uddfc\udaec\udf81\ud960\udf23\ud850\udd62\ud8c8\udd8d\udbfe\udce4\udae5\ude44\udae7\udc72\ud91a\udf13\ud8df\udddc\ud985\udc58\ud98c\udffc\uda11\uddb6\ud9a3\udf78\udb41\udde1\uda58\udcd5\udbc5\uded8\ud8fa\udc9c",
        37, 19779, -1141086686, -1743031585405398068L, 37075L, true, false, (char) 26463, (char) 17522,
        Double.longBitsToDouble(0x3feaa60d377c96a9L), Double.longBitsToDouble(0x3fd804277f52c2b8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.util.ShapeList|equals|java.lang.Object|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|clone||new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|getShape|int|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|hashCode||new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|readObject|java.io.ObjectInputStream|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|setShape|int,java.awt.Shape|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|writeObject|java.io.ObjectOutputStream|new:org.jfree.chart.util.ShapeList:",
    "C|org.jfree.chart.util.ShapeList|<init>|",
    "M|org.jfree.chart.util.ShapeList|equals|java.lang.Object|new:org.jfree.chart.util.ShapeList:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
