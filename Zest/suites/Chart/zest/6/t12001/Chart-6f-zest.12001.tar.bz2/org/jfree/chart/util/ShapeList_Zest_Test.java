package org.jfree.chart.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class ShapeList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 4, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03", "\uc6d5\u229b\ube6e", "\u4d68\ud9f3\udfdc\ud892\udf32\udb23\udcc6\ud865\udf57\ud893\udc25\udaae\udfeb\ud8fb\udf23\uda18\udc64\udb3a\udc7d\udb1f\udf23\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\uda77\udfd9\ud9bf\udd2b\udb05\udf6d\udb70\udef7\ud9fe\udce6",
        1, 39393, 223604335, 464809295426199789L, -55563L, false, true, (char) 37310, (char) 474,
        Double.longBitsToDouble(0x3fd66b7b8aec436cL), Double.longBitsToDouble(0x3fe7bf07163d73b3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 4, 1, "\ue5fa\udaee\udc7a\udac5\ude7c\udae0\udfb4\ud93b\udf59\ud918\udc2e\ud8fc\udec3\uda5b\udc66\ud918\ude65\udb62\udcf2\uda37\ude27\udb15\udc42\udac5\udee7\udac2\udc23", "\u175b", "\udab9\ude28\udbe1\udd02\ud961\udd3f",
        41, 85878, -1030804929, -5437240753382784738L, -78845L, true, true, (char) 46492, (char) 25251,
        Double.longBitsToDouble(0x3fd2c7db5f6dd1c0L), Double.longBitsToDouble(0x3fcbdcc532d46000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 2, 0, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\udbec\udda7\udae6\udccb\ud910\udc32\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\ud95e\udec1\ud961\uddbc\ud8e8\udec1\ud891\ude75", "\u92b4\u68de\u4ee6\ud224\u4455\u8e8b\u05c4\u6916\u3950\u242d", "\uda2f\udff5\ud8b0\udecd\ud91a\udd5c\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7",
        51, 28192, -119403683, -2313777384286739756L, 14639L, true, false, (char) 22383, (char) 10889,
        Double.longBitsToDouble(0x3fe7a1e65c27efe0L), Double.longBitsToDouble(0x3f9b5a03b1247b60L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 4, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03\ud8ac\udcef", "\u229b\ube6e\ub1fd\u7f02\u3aed\u48e4\uc5da\u4672\u47da\u62cc\u9b0c\u8a36\u6c07\u1b02\u29d1\u2193\ud3e5\uc939\u5391\u0210\u05bd\u8262\u0550\ucbf3\u3a91\ub63a\u253c\u6b82\u539c\u9702\u2366\ubd23\u23e6\u82d0", "\uda44\udfa0\ud9f4\uddc8\uda21\udf2f\udbea\uddc2\udafe\udf56\ud920\udef5\udb72\udfb6\ud8f1\udf31\udbc4\udd56\uda40\udf99\ud811\udf81\ud945\uddc5\uda46\ude6e\ud97a\ude2f\ud994\uddd6\ud884\ude23\ud84c\uddb6\uda9f\udf46\ud8f0\udfb7\ud85d\udfc6\ud8f6\ude6b\ud8ae\udebb\udb16\udd37\ud800\udc5c\uda0b\udcf0\udb1c\ude93",
        -1, 60236, -710073411, -7050778668535652007L, 75962L, true, true, (char) 15158, (char) 35211,
        Double.longBitsToDouble(0x3fe5c11a5513b1e0L), Double.longBitsToDouble(0x3fe210f66be3c7c9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 7, 3, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud931\udd9f\udbf8\udcfd\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03", "\uc6d5\u229b\ube6e", "\u4d68\ud9f3\udfdc\ud892\udf32\udb23\udcc6\ud865\udf57\ud893\udc25\udaae\udfeb\ud8fb\udf23\uda18\udc64\udb3a\udc7d\udb1f\udf23\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\ud98f\udfe5\ud9bf\udd2b\udb05\udf6d\udb70\udef7\ud9fe\udce6",
        1, 39393, 223604335, 464809295426199789L, -55563L, false, true, (char) 37310, (char) 474,
        Double.longBitsToDouble(0x3fd66b7b8aec436cL), Double.longBitsToDouble(0x3fe7bf07163d73b3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 7, "\ue655\ud95d\udf4f\udb3c\ude34\uda80\udc9b\ud93b\udf3c", "\u19b1\u095e\u5e74\u9fc7\u97fa\u246a\u48e7", "\ud9e0\uddd8",
        25, 72222, -2040167426, -8110531958777859734L, 63968L, true, false, (char) 52455, (char) 13737,
        Double.longBitsToDouble(0x3fea0582bd5dc13eL), Double.longBitsToDouble(0x3fd23308bc080ef8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 4, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\ud9d3\udd03\udab3\udddc\ud9ba\udd56\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\udac0\udec9\ud9de\udcbe\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\ude53\udac6\udf03", "\uc6d5\u229b\ube6e", "\ud82f\udf52\ud9f3\udfdc\ud892\udf32\udb23\udcc6\ud865\udf57",
        12, 95172, 1595019657, -279169719546599451L, 77110L, false, true, (char) 62630, (char) 3589,
        Double.longBitsToDouble(0x3fe37fc92d970d53L), Double.longBitsToDouble(0x3fcda0ce7245b8b4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\uf903\ud87a\uddfd\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8", "\u73d0", "\ud98b\udcd3\udbe1\udd02\ud961\udd3f",
        41, 85878, -1030804929, -5437240753382784738L, -78845L, true, true, (char) 46492, (char) 25251,
        Double.longBitsToDouble(0x3fd2c7db5f6dd1c0L), Double.longBitsToDouble(0x3fcbdcc532d46000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 4, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59", "\u19c7\u095e\u5e74\u9fc7", "\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8",
        25, 72222, -2040167426, -6290488367955038378L, -1730L, true, false, (char) 52455, (char) 13737,
        Double.longBitsToDouble(0x3fea0582bd5dc13eL), Double.longBitsToDouble(0x3fd23308bc080f32L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 1, "\ue6b3\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\uda96\udf99\ud891\udd97\ud80d\udea0\uda75\udee5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\ud970\ude90\ud89a\udc33\ud9f4\udf4a\udbee\udf60\ud9c1\udf32\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\ud979\ude23\ud9e1\udd88\udac6\udf03", "\uc6d5\u229b\ube6e", "\uda16\udd44\ud9f3\udfdc\ud892\udf32\udb23\udcc6\ud931\uddfd\ud893\udc25\udaae\udfeb\udbfb\udec4\uda18\udc64\ud964\udf5b\ud86a\udee7\udab3\udf7c\ud8af\udc14\ud9c5\udcdf\uda77\udfd9\ud9bf\udd2b\udb05\udf6d\udb70\udef7\ud9fe\udce6",
        1, 39393, 223604335, 464809295426199789L, -55563L, false, true, (char) 37310, (char) 474,
        Double.longBitsToDouble(0x3fd66b7b8aec436cL), Double.longBitsToDouble(0x3fe7bf07163d73b3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\u833f\ud93c\udccc\uda2b\udd7b\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\ud982\udff3\ud961\udcf4\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\ud905\udd30\udb57\udce2\ud97c\ude10\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud81e\udf83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\udb32\udfbc\ud87f\ude96\udb0f\ude46\udb30\udcff\ud81c\uddc4\udb18\udeb2\ud8de\udd0a\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03", "\u9e15\u223a\ube6e", "\u4d68\ud9f3\udfdc\ud892\udf32\udb25\udcc6\udbaa\udf7a\udbdd\udda4\udaae\udfeb\ud8fb\udf23\uda18\udc64\udb3a\udc7d\udb1f\udf23\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\uda77\udfd9\ud9bf\udd2b\udb05\udf6d\udb70\udef7\ud9fe\udce6",
        1, 39393, 223604335, 464809295426199789L, 57698L, true, true, (char) 37876, (char) 57131,
        Double.longBitsToDouble(0x3fe7bf07163d73b3L), Double.longBitsToDouble(0x3f8f41bdd76bfbc0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 1, 0, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud855\udc52\ud9cb\udd59\ud981\ude43\ud995\udce3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud9ec\udeba\udbb0\udf69\ud966\udcc1\udba8\udc20\udba9\uddcb\ud9f0\udcf6\ud860\udc17\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud86a\udf37\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\ub7bd\udba0\udcb4\udbed\udc86\ud9f2\udc1e", "\uc6d5\u229b\u19f6", "\ud8a9\udd18\uda21\udd49\ud892\udf32\udb23\udcc6\ud865\udf57\udb6f\ude64\udab9\udde7\ud8fb\udf23\uda18\udc64\udb3a\udc7d\udb1f\udf23\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\uda77\udfd9\ud9bf\udd2b\udb05\udf6d",
        13, 36621, -883727774, -493915255926952337L, 6733L, true, false, (char) 60080, (char) 30190,
        Double.longBitsToDouble(0x3fd95221069dc940L), Double.longBitsToDouble(0x3feff7ce033916a1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 2, 4, 1, "\ue655\ud815\udecc\ud8aa\udd9e\udae0\udfb4\ud93b\udf59\ud918\udc2e\ud9e9\uded2\udb5f\udd36\ud9a8\uddc7\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\udb8d\udec4\ud9cb\udd34\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\udab7\udc69\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9ac\udc54\uda18\udd9c\udab7\udecd\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\ud941\udfa7\ud86b\ude9d\ud97d\udcc8\ud89a\udc24\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\udd30\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03", "\uc6d5\u229b\u345c", "\u4d68\ud9f3\udfdc\ud892\udf32\udb23\udcc6\ud865\udf57\ud893\udc25\udaae\udfeb\ud8fb\udf23\uda18\udc64\udb3a\udc7d\udb1f\udf23\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\uda85\udc9f\ud896\udf0f\udb05\udf6d\udb70\udef7\ud9fe\udce6",
        1, 39393, 223604335, 464809295426199789L, -55563L, false, true, (char) 37310, (char) 474,
        Double.longBitsToDouble(0x3fd66b7b8aec436cL), Double.longBitsToDouble(0x3fe7bf07163d73b3L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 4, 1, "\ue655", "\u5e0c\uaeba\ua526\u4860\u19c7\u095e\u5e74\u9fc7\u9847", "\ud963\udce2\ud8bf\udfbb",
        8, 13835, 980783222, -8762452374499118552L, -100000L, false, false, (char) 0, (char) 52455,
        Double.longBitsToDouble(0x3fd1eb48b68160aeL), Double.longBitsToDouble(0x3fd5dc13e2466116L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 7, 4, 1, "\ue5fa\udaee\udc7a\udac5\ude7c\udae0\udfb4\ud93b\udf59\ud918\udc2e\ud8fc\udec3\uda5b\udc66\ud918\ude65\udb62\udcf2\uda37\ude27\udb15\udc42\udac5\udee7\udac2\udc23", "\u175b", "\ud84f\udd73\udaed\ude30\ud961\udd3f",
        41, 85878, -1030804929, -5437240753382784738L, -78845L, true, true, (char) 46492, (char) 25251,
        Double.longBitsToDouble(0x3fd2c7db5f6dd1c0L), Double.longBitsToDouble(0x3feef7314d1e455bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 2, 4, 1, "\udb56\udc83\udb6c\udd70\udac5\ude7c\udae0\udfb4\ud8e7\uddef\ud906\udd8d\ud8fc\udec3\uda5b\udc66\ud918\ude65\udb62\udcf2\uda37\ude27\ud889\udd7b\udac5\udee7\udac2\udc23", "\u175b", "\udab9\ude28\udbe1\udd02\ud961\udd3f",
        11, 85885, -1030804929, -5437240753373085410L, -78845L, true, true, (char) 46492, (char) 38950,
        Double.longBitsToDouble(0x3fd2c7db5f6dd1c0L), Double.longBitsToDouble(0x3fcbc5c5312c6000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 4, 1, "\ue5fa", "", "\udb52\udc2b\ud8fc\udec3",
        44, 98698, 0, 3456014636197830885L, -100000L, false, false, (char) 57075, (char) 57724,
        Double.longBitsToDouble(0x3ebd500000000000L), Double.longBitsToDouble(0x3feab54599276450L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 0, 0, 1, "\ue5fa", "\u5e0c\uaeba\u2100\u1901\u19c7\u095e\u5357T\000", "",
        -5, -1000, 0, 5838764084769587200L, 17031L, false, false, (char) 39444, (char) 52455,
        Double.longBitsToDouble(0x3fd1eb48b68160aeL), Double.longBitsToDouble(0x3fd5dc13e2466000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 1, 3, 7, "\ue612\udbe6\udc37", "\ub86a", "\uda5b\udc66\ud827\udc02",
        16, 99196, 958357733, -6785119956010254476L, 76045L, false, false, (char) 22485, (char) 1263,
        Double.longBitsToDouble(0x3fdd9584147985e4L), Double.longBitsToDouble(0x3f747acdb3177e80L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 3, 3, 0, "\ud983\udec6", "\ub5c7\uaeba\ua526\u6b56\u19c7\u095e\u5357\u342c\u6bb5\u9cbc\u8170\uac33\ucbd0\u175b\u3dfc\u114d\ud4da\u8ab0\u463a\u2162\ubc69", "\udb3d\udc1b\ud8d2\udeb5\ud930\udc3e\uda8e\udd95\ud8c0\udc42\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud80b\udf1c",
        53, 72509, 518576474, 6423577100969020058L, -54579L, false, true, (char) 44686, (char) 48224,
        Double.longBitsToDouble(0x3fed75528ee9dcdeL), Double.longBitsToDouble(0x3fea26c081bf1e4cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 2, 6, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\uda9b\udd14\u5ce2\ud8cb\udea0\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud9ed\ude6f\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udbd4\ude51\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud885\udd4d\ud85a\udebf\ud8ac\udcef", "\u229b\ube6e\ub1fd\u7f02\u3aed\u48e4\uc5da\u4672\u47da\u62cc\u9b0c\u8a36\u6c07\u1b02\u29d1\u2193\ud3e5\uc939\u5391\u0210\u05bd\u8262\u0550\ucbf3\u3a91\ub63a\u253c\u6b82\u539c\u9702\u2366\ubd23\u23e6\u82d0", "\uda44\udfa0\ud9f4\uddc8\uda21\udf2f\udbea\uddc2\udafe\udf56\ud920\udef5\udb72\udfb6\ud8f1\udf31\udbc4\udd56\uda40\udf99\ud9a6\ude03\ud945\uddc5\uda46\ude6e\ud97a\ude2f\ud994\uddd6\ud884\ude23\ud84c\uddb6\uda9f\udf46\ud8f0\udfb7\ud85d\udfc6\ud8f6\ude6b\ud8ae\udebb\udb16\udd37\ud800\udc5c\uda0b\udcf0\udb1c\ude93",
        -1, 60236, -710073411, 5606751894248119519L, 75962L, true, true, (char) 15158, (char) 35211,
        Double.longBitsToDouble(0x3fe5c11a5113b1e0L), Double.longBitsToDouble(0x3fe210f413e3c7c9L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\udbba\udf72\udbc8\udf78\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03\ud8ac\udcef", "\u229b\ube6e\ub1fd\u7f02\u3aed\u48e4\uc5da\u4672\u47da\u62cc\u9b0c\u8a36\u6c07\u1b02\u29d1\u2193\ud3e5\uc939\u5391\u0210\u05bd\u8262\u0550\ucbf3\u3a91\ub63a\u253c\u6b82\u539c\u9702\u2366\ubd23\u23e6\u82d0", "\uda44\udfa0\ud9f4\uddc8\ud9b0\uddd6\udbea\udda0\udafe\udf56\ud920\udef5\udb72\udfb6\ud8f1\udf31\udbc4\udd56\uda40\udf99\ud811\udf81\ud945\uddc5\uda46\ude6e\ud97a\ude2f\ud994\uddd6\ud884\ude23\ud84c\uddb6\uda9f\udf46\ud8f0\udfb7\ud85d\udfc6\ud8f6\ude6b\ud8ae\udebb\udb16\udd37\ud800\udc5c\uda0b\udcf0\udb1c\ude93\uda9b\udf52\ud93e\ude65\ud9cc\udd3e\udb1d\udc63\ud81b\ude89\uda3b\ude8d\udb9e\udeea\uda45\udc0f\ud888\udd8b\ud9a3\udf04\ud989\ude1d\udabf\udee3",
        51, 56859, 2110378556, 7322803723229288660L, -53483L, false, true, (char) 60902, (char) 15128,
        Double.longBitsToDouble(0x3fe52d191343b924L), Double.longBitsToDouble(0x3fe3da894d3d6c5cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 1, "\ue655\udaf2\udf7a\udabe\udf7a\udae0\udfb4\ud93b\udf59\ud918\udc2e\udb1a\ude7e\ud9c7\udfa6\ud908\udc6c\u7ac7\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8e5\udebb\ud9e0\uddd8\ud9cb\udd59\ud9af\udf76\ud98b\udc5f\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud817\udea0\ud9cf\udc9d\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9a0\udcee\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\ud848\udcf4\ud823\udcef\udbdb\uddab\ud9f3\udd37\uda08\udd7e\udba9\udee0\u7c2b\ud89a\udc33\ud8fb\udc34\udb0f\udecf\ud9c1\udf68\ud8a7\udf8e\ud837\udf69\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9b8\udf09\uda82\udf01\ud8ac\udcef", "\u0d9a\ube6e\ub1fd\u7f02\u3aed\u48e4\uc5da\u4672\u47da\u62cc\u9b0c\u8a36\u6c07\u1b02\u29d1\u2193\ud3e5\uc939\u5391\u9800\u26be\u8223\u0550\ucbf3\u3a91\ub63a\u253c\u6b82\u539c\u2eb4\u7179\u3dc1\u23e6\u82d0", "\uda44\udfa0\ud9f8\uded7\ud914\udc4c\udbea\uddc2\udafe\udf56\ud920\udef5\udb72\udfb6\udbc8\udc1c\ud933\ude74\uda40\udf99\ud811\udf81",
        -3, 76483, -117393475, 8052420093882932098L, 56004L, false, false, (char) 27755, (char) 40808,
        Double.longBitsToDouble(0x3feb15d7579a38d1L), Double.longBitsToDouble(0x3fe8149d6e4ad310L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 1, "\ue655\udaf2\udf7a\uda32\udf57\ud8e3\udc70\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1", "\u58e9\u92b4\u68de\u4ee6\ud224\u83b0\u8e8b\u05c4\u6916\u3950\u5f5d\u97d5\u5a1d\u1d3d\ud18f\ua033\u5563\u89c9\u634e\u9cb8\u7dda\u3a16\u7904\u6212\ua01b\u82ed\u51ab\u4405\u12ce\uacdd\u7557", "\udaf5\ude00\udbe8\udd74\udbf8\ude37\ud82e\udffd",
        0, 24774, -1344327132, -4028703888914609060L, -70295L, false, false, (char) 11856, (char) 62553,
        Double.longBitsToDouble(0x3fc3ebe25f97f080L), Double.longBitsToDouble(0x3fdfa82618eaaf3aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 7, 3, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\ud950\udef9\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud931\udd9f\udbf8\udcfd\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03", "\uc6d5\u229b\ube6e", "\u4d68\ud9f3\udfdc\ud892\udf32\udb23\udcc6\ud865\udf57\ud893\udc25\udaae\udfeb\ud8fb\udf23\uda18\udc64\ud8c8\ude24\udb27\uddae\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\ud98f\udfe5\ud9bf\udd2b\udb05\udf6d\udb70\udef7\ud9fe\udce6",
        1, 39393, 223604335, 464809295426199789L, -49559L, true, false, (char) 35370, (char) 43090,
        Double.longBitsToDouble(0x3fe27962b0ca70b9L), Double.longBitsToDouble(0x3fc3adb3891b945cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\0121=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 7, 3, 1, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\u4f81\ud949\udc6e\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\ud9b1\udf7c\ud847\udcb1\ud8f6\udff4\ud961\udd3f\ud8e8\udec1\ud891\ude75\uda4e\udfc0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\udba9\udd22\ud9f0\udcf6\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud934\udfec\uda8a\udc83\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9b7\udd4b\udb00\udd15\ud9e1\udd49\ud804\udce7\ud931\udd9f\udbf8\udcfd\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03\ud8ac\udcef\udaf5\ude00", "\uc428\ub1fd\u7f02\u3aed\u48e4\uc5da\u4672", "\udaae\udfeb\ud8fb\udf23\uda18\udc64\udb3a\udc7d",
        15, 86901, 1323263595, 790351197335365651L, 92151L, false, true, (char) 43172, (char) 62630,
        Double.longBitsToDouble(0x3fdb1cb53cdff3d0L), Double.longBitsToDouble(0x3fd970d531da0ce6L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 7, "\ue655\uda3f\ude41\ud830\ude4d\ud980\udfac\uda2b\udd37", "\u19b1\u095e\u5e74\u9fc7\u97fa\u246a\u48e7", "\ud9e0\uddd8",
        58, 72222, 777169918, 872439467050774890L, 63968L, true, false, (char) 52455, (char) 13737,
        Double.longBitsToDouble(0x3fea0582bc6dc13eL), Double.longBitsToDouble(0x3fd23308bc080ef8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Integer:238727589 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 3, 7, "\udbfa\udf65\ud937\udc4f\udb3c\ude34\udaf7\ude3c\ud945\udd47", "\u19a7\u095e\u5e74\u9fc7\u97fa\u246a\u48e7", "\uda82\udc6a",
        13, 38350, -2040167426, -8110531958777859734L, -67104L, false, false, (char) 52455, (char) 13737,
        Double.longBitsToDouble(0x3fea0582bd5dc13eL), Double.longBitsToDouble(0x3fd23308bdb9e0f8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 4, 0, "\000", "", "",
        -5, -1000, 0, 9227468800L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e0d9441c0000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud843\udddb\udafd\udd57\ud8bb\uded7\ud88c\udffc\ud93a\udf99\ud918\udc49\ud84a\udd09\ud87a\uddfd\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\u0a88\ud83d\udc65", "\u42ed", "\ud9b0\udde0\udab6\udc02\ud961\udd3f",
        41, 85878, -1030785729, -5437240753382784738L, -78845L, true, true, (char) 20989, (char) 23654,
        Double.longBitsToDouble(0x3fedad7de7b65e8aL), Double.longBitsToDouble(0x3fcbdcc532d46000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ue655\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\uf903\ud87a\uddfd\uda70\udc91\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udb4f\udd9f", "\u73d0", "\ud98b\udcd3\udbe1\udd02\ud881\udd6e",
        41, 97878, -1030751162, 3209670531168567582L, -78845L, true, true, (char) 46492, (char) 57739,
        Double.longBitsToDouble(0x3fd5c07bbf6dd1c0L), Double.longBitsToDouble(0x3fcbdcc532d46000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\0121=org.jfree.chart.util.ShapeList:@? |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udbab\udfcd\ud9ab\ude86\ud8ec\udc26\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\ud8c0\udc86\ud9af\uddb2\uda3b\udcb8\ud886\udf46\u9108\ud8de\udeab\ud8a9\ude43\udafb\udfa6\ud8a6\ude36\udb54\udeb7\udb31\ude12\ud961\udd04\uda96\udf99\ud891\udd97\ud80d\udea0\uda75\udee5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\ud919\udc27\ud897\ude63\ud9ec\udcbd\ud85f\udfcf\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud823\udc83\ud990\udde6\ud8eb\udd40\udb79\ude22\ud86b\ude9d", "\uba9a\u8b47\u3a32\u7904\u6212\ua01b\u82ed\u51ab\u1b6e\ud2b5\ube85\u1e5c\u2de8\u2451\u9a8c\uc7a6\u229b", "\ud888\udd7a\uda16\udd44\udbb7\udfde\ud892\udf32\udb23\udcc6\ud931\uddfd",
        12, 95172, -787345015, -279169717401910470L, 3253L, true, false, (char) 5961, (char) 10935,
        Double.longBitsToDouble(0x3fef2731593d5994L), Double.longBitsToDouble(0x3fed4b785ad2eef1L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\0121=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 2, 5, 0, "\ud9dd\udcce", "\ub5c7\uaeba\ua526\u6b56\ua816\u800b\u5323\u342c\u6bb5\u9cbc\u8170\uac33\ucbd0\u175b\u3dfc\u43cf\ud4da\u8ab0\u463a\u953b\u9d69", "\u9275\ud8c2\udfea\uda5d\ude2e\uda22\udf3d\udb27\udc7b\ud8cb\ude4d\udb99\udc17\ud897\ude30\udbe9\udc31\u9465",
        53, 72509, 518576474, 6423577100969020058L, -54579L, false, true, (char) 61483, (char) 21759,
        Double.longBitsToDouble(0x3fed7553eee9dcdeL), Double.longBitsToDouble(0x3fea26c081bf1e4cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 0, 7, "\ue655\uda3f\ude41\ud830\ude4d\ud980\udfac\uda2b\udd37\ud978\udfbf\udba5\udf84\uda5b\udc50\ud98e\ude61\ud9c3\ude8e\udb13\udf36\udbdf\udf7a\uda1b\udec4\ud9ae\ude98\ud963\udce2\ud8bf\udfbb\udb6d\udf0a\udac4\udf76\udbc8\udfe7\udb61\udeb8\udb79\udfca\ud97d\udc52\uda04\uddc3\ud891\ude17\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud973\udf49\udbca\udd93\uc8e7\uda98\udd6d\ud95a\ude61\uda9c\udf61\ud916\uddff\ud845\udd33\udb28\udd03\uda2f\udf4c\ud8da\udcf5\uda9f\udc1f\ud8ea\udf1b\ud8d0\udefd\udb5b\udf1b\ud941\udfc5\ud92b\udfe3\ud94b\udf1e", "\uac35\uc0ea\u9811\ub0e4\u766b\u9a98\u7087\ub506\ud575\u7671\u3807\u1e3a\u20d1\u3b1e\u4a0f\u60d1\u92ab\u9843\u2e32\u9763\u5446\u22e7\u6da3\u730d\u7b0c\u5f3e", "\ud928\udd36\udae8\udee4",
        4, 42064, 1510108628, -426109862931629760L, 77931L, false, true, (char) 43556, (char) 5966,
        Double.longBitsToDouble(0x3fd02b9d77f4551eL), Double.longBitsToDouble(0x3fd8d044c28bf0e4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 5, 0, "\ud9dd\udcce", "\ub5c7\uc5b5\u8426\u6b56\ua816\u800b\u5323\u342c\u6bb5\u9cbc\u8170\uac33\ucbd0\u175b\u3dfc\u43cf\ud4da\u8ab0\u463a\u953b\u9d69", "\u9275\ud8c2\udfea\uda5d\ude2e\uda22\udf3d\udb27\udc7b\ud8cb\ude4d\u5576\ud897\ude30\udbe9\udc31\uf9b0",
        -5, -1000, 15259994, 6423577100969020058L, -54579L, false, true, (char) 61483, (char) 21759,
        Double.longBitsToDouble(0x3fed7553eee9dcdeL), Double.longBitsToDouble(0x3f4b0206fc793000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 2, 2, 7, "\ue655\uda3f\ude41\ud830\ude4d\ud980\udfac\uda2b\udd37\ud978\udfbf\udba5\udf84\uda5b\udc50\ud98e\ude61\ud9c3\ude8e\udb13\udf36\udbdf\udf7a\uda1b\udec4\ud9ae\ude98\ud963\udce2\ud8bf\udfbb\udb6d\udf0a\udac4\udf76\udbc8\udfe7\udb61\udeb8\udb79\udfca\ud97d\udc52\uda04\uddc3\ud891\ude17\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud973\udf49\udbca\udd93\uc8e7\uda98\udd6d\ud95a\ude61\uda9c\udf61\ud916\uddff\ud845\udd33\udb28\udd03\uda2f\udf4c\ud8da\udcf5\uda9f\udc1f\ud8ea\udf1b\ud8d0\udefd\udb5b\udf1b\ud941\udfc5\ud92b\udfe3\ud94b\udf1e", "\u158f\uc0ea\u9811\ub0e4\u766b\u9a98\u7087\ub506\ud575\u7671\u3807\u1e3a\u20d1\u3b1e\u4a0f\u60d1\u92ab\u9843\u2e32\u9763\u5446\u22e7\u6da3\u730d\u7b0c\u5f3e", "\ud928\udd36\udae8\udee4",
        4, 42064, 1510108628, -426109862931629760L, 77931L, false, true, (char) 43556, (char) 5966,
        Double.longBitsToDouble(0x3fd02b9d77f4551eL), Double.longBitsToDouble(0x3fd8d044c28bf0e4L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 0, 7, "\u0f7c\uda3f\ude41\ud830\ude4d\ud980\udfac\uda2b\udd37\ud978\udfbf\udba5\udf84\uda5b\udc50\ud98e\ude61\ud9c3\ude8e\udb13\udf36\udbdf\udf7a\uda1b\udec4\ud9ae\ude98\ud963\udce2\ud8bf\udfbb\udb6d\udf0a\udac4\udf76\udbc8\udfe7\udb61\udeb8\udb79\udfca\ud97d\udc52\uda04\uddc3\ud891\ude17\ud83d\udea0\udbdc\udf84\ud91d\uddb0\ud89b\udf6f\ud973\udf49\udbca\ude3c\uc8e7\uda98\udd6d\ud95a\ude61\uda9c\udf61\ud9a2\udce4\ud997\udf30\udb52\udd4e\udbbb\udcc4\ud86d\udc2f\uda9f\udc24\ud8ea\udf1b\ud8d0\udefd\udb5b\udf1b\ud941\udfc5\ud92b\udfe3\ud94b\udf1e", "\uac35\uc0ea\u9811\ub0e4\u766b\u9a98\u0f20\ub471\ud575\u7671\u3807\u1e3a\u20d1\u3b1e\u4a0f\u60d1\u92ab\u9843\u2e32\u9763\u5446\u22e7\u6da3\u7e4f\uba9d\u5f3e", "\uda95\udfcc\udbf6\udc9e",
        1, 62954, -1157074120, -426109862931629760L, 77931L, false, true, (char) 43556, (char) 5966,
        Double.longBitsToDouble(0x3fd02b9d77f4551eL), Double.longBitsToDouble(0x3fd8d044c28bf0e4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud9dd\udcce", "\ub5c7\uc5b5\u8426\u6b56\ua816\u800b\u5323\u342c\u2f81\u9cbc\u8170\u465e\ucbd0\u175b\u3dfc\u43cf\ud4da\u8ab0\ud768\u953b\u9d69", "\u9275\ud8c2\udfea\uda5d\ude2e\uda22\udf3d\udb27\udc7b\ud8cb\ude4d\u5576\ud897\ude30\udbe9\udc31\uf9b0",
        -5, -1000, 15259994, 6423577099265280666L, 8154L, false, false, (char) 60971, (char) 29639,
        Double.longBitsToDouble(0x3f4b0206fc793000L), Double.longBitsToDouble(0x3fdefa1c71b59de2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.jfree.chart.util.ShapeList:@?\0121=new org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 7, 7, 5, "\ud94c\uded1", "\ub5c7", "\ud8fc\udec3",
        20, 949, 631490183, 8860334550913121038L, -87519L, false, false, (char) 7471, (char) 53281,
        Double.longBitsToDouble(0x3fdf369ec646a20eL), Double.longBitsToDouble(0x3fdcfec5c4500be4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 5, 5, "\ud9dd\udcce", "\u8ec7\u4ccc", "\uef86\ud86e\udfb3\ud915\udc25",
        35, 70559, 1799671194, -447335774050320038L, 17031L, false, false, (char) 39444, (char) 60903,
        Double.longBitsToDouble(0x3fd6cc2dbf40a6e8L), Double.longBitsToDouble(0x3fd5dc10b2085208L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 2, 7, "\ue655\uda3f\ude41\ud830\ude4d\ud980\udfac\uda2b\udd37\ud978\udfbf\udba5\udf84\uda5b\udc50\ud98e\ude61\ud9c3\ude8e\udb13\udf36\udbdf\udf7a\uda1b\udec4\ud9ae\ude98\ud963\udce2\ud8bf\udfbb\udb6d\udf0a\udac4\udf76\udbc8\udfe7\udb61\udeb8\udb79\udfca\ud97d\udc52\uda04\uddc3\ud891\ude17\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud973\udf49\udbca\udd93\uc8e7\uda98\udd6d\ud95a\ude61\uda9c\udf61\ud916\uddff\ud845\udd33\udb28\udd03\uda2f\udf4c\ud8da\udcf5\uda9f\udc1f\ud8ea\udf1b\ud8d0\udefd\udb5b\udf1b\ud941\udfc5\ud92b\udfe3\ud94b\udf1e", "\u158f\uc0ea\u9811\ub0e4\u766b\u9a98\u7087\ub506\ud575\u7671\u3807\u1e3a\u20d1\u3b1e\u4a0f\u60d1\u92ab\u9843\u2e32\u9763\u5446\u22e7\u6da3\u730d\u7b0c\u5f3e", "\ud928\udd36\udae8\udee4",
        4, 42064, 1510108628, -426109862931629760L, 77931L, false, true, (char) 43556, (char) 5966,
        Double.longBitsToDouble(0x3fd02b9d77f4551eL), Double.longBitsToDouble(0x3fd8d044c28bf0e4L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 5, 5, "\ud8eb\udf8a", "\u8ec7", "\ud84c\udeaa",
        4, 5859, -1449782979, 7984709814324239559L, 79836L, false, true, (char) 26700, (char) 33497,
        Double.longBitsToDouble(0x3fc0dc87b3eab500L), Double.longBitsToDouble(0x3fdcfece34500be4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=null |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 2, 7, "\ue655\uda3f\ude41\uda98\udd00\ud9aa\udd55\uda23\udf8f\ud978\udfe9\udba5\udf84\uda5b\udc50\ud98e\ude61\ud9c3\ude8e\udb13\udf36\udbdf\udf7a\uda1b\udec4\ud9ae\ude98\ud963\udce2\ud8bf\udfbb\udb6d\udf0a\udac4\udf76\udbc8\udfe7\udb61\udeb8\udb79\udfca\ud97d\udc52\uda04\uddc3\ud891\ude17\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud973\udf49\udbca\udd93\uc8e7\uda98\udd6d\ud95a\ude61\uda9c\udf61\ud916\uddff\ud845\udd33\udb28\udd03\uda2f\udf4c\ud8da\udcf5\uda9f\udc1f\ud8ea\udf1b\ud8d0\udefd\udb5b\udf1b\ud941\udfc5\ud92b\udfe3\ud94b\udf1e", "\u158f\uc0ea\u9811\u06d2\u3701\u124f\u7087\ua96d\u2e75\u2df8\u3807\u1e3a\u2104\u3b1e\u4a0f\u60d1\u80ec\u9843\u2e32\u9763\u5446\u22e7\u6da3\u730d\u7b0c\u5f3e", "\ud9f6\udf18\ud928\udf4a",
        0, 42064, 1510108628, -426109862931629760L, 77931L, false, true, (char) 43556, (char) 5966,
        Double.longBitsToDouble(0x3fd02b9d77f4551eL), Double.longBitsToDouble(0x3fd8d044c28bf0e4L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:4699 |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 3, 4, 1, "\ud8b6\udf34\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud93b\udf59\ud918\udc2e\udba5\ude97\uda5b\udc66\ud918\ude65\u7b01\udb13\uded2\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\udbe1\udd02\ud961\udd3f\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\ud880\udfcf\udba9\uddaa\ud9f0\udcf6\ud980\udff6\uf17b\udb80\ude71\ud9cf\ude5f\udb5f\udc00\ud823\udc83\udbdb\uddab\ud8eb\udd40\udb79\ude22\ud86b\ude9d\u7c5b\ud89a\udc33\ud9f4\udf4a\udb0f\udecf\ud9c1\udf68\ud804\udce7\ud83e\udc06\u2b35\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03", "\uc6d5\u229b\ube6e", "\u4d68\ud9f3\udfdc\udb68\ude1e\udade\udfab\ud865\udf57\ud893\udc25\udaae\udfeb\ud8fb\udf23\uda18\udc64\udb3a\udc7d\udb1f\udf23\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\uda77\udfd9\ud9bf\udd2b\udb05\udf6d\udb70\udef7\ud9fe\udce6",
        1, 39393, 223604335, 464809295426199789L, -52491L, false, true, (char) 37310, (char) 474,
        Double.longBitsToDouble(0x3fd66b7b8aec436cL), Double.longBitsToDouble(0x3fe7bf07163d73b3L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 1, 5, 4, 1, "\ud83e\udc57\udaf2\udf7a\ud8bb\uded7\udae0\udfb4\ud8a7\udf4f\ud918\udc2e\ud85e\udc57\uda22\udf25\u48cc\udbee\udf45\uda2b\udd7b\udbdf\udfc7\udac5\udee7\udac1\udfa8\ud963\udce2\ud8bf\udfbb\ud9e0\uddd8\ud9cb\udd59\udbc8\udfe7\ud98b\udcd3\ud982\udff3\ud961\udcf4\ud8e8\udec1\ud891\ude75\ud80d\udea0\uda5d\udde5\ud8bd\udc6c\ud89b\udf8d\ud966\udc39\uda8e\udd95\ud905\udd30\udb57\udce2\ud97c\ude10\ud897\ude30\ud829\ude48\ud9cf\ude5f\udb5f\udc00\ud81e\udf83\udbdb\uddab\ud8eb\udd40\udb79\ude73\ud86b\ude9d\u7c5b\udb32\udfbc\ud87f\ude96\udb0f\ude46\udb90\udc2c\ud81c\uddc4\udb18\udeb2\ud8de\udd0a\uda6c\udef1\uda2b\uddd5\ud9d2\udc07\uda8b\udf4b\u5a75\ud9e6\uddd8\udac6\udf03", "\u9e15\u223a\ube6e", "\u4d68\ud9f3\udfdc\ud892\udf32\udb25\udcc6\udbaa\udf7a\udbdd\udda4\udaae\udfeb\ud8fb\udf23\uda18\udc64\udb3a\udc7d\udb1f\udf23\ud8d5\udfb6\udba6\udf10\ud9c5\udcdf\uda77\udfd9\ud9bf\udd2b\udb05\udf6d\udb70\udef7\ud955\udeec\ud923\udf47\uda42\ude49\ud80f\udf38\ud919\uddf8\ud8a7\udf6b\uda8b\udeea\udb00\udda2\udb8d\udd08\ud9a6\udf00\udacf\udd47\ud992\udd53\ud9f8\udc16\uda4a\udf62\uda44\udfa0\udb9f\udc5e\udb17\udc15\ud846\udf57\ud9e0\uddfb\ud915\udc0d\udb7d\udcb0\ud9f5\udf76\udb87\ude44\uda5c\uded1\ud986\ude50\ud95b\udc7c\ud995\ude4f\udab6\udf0c\udb31\udd84\udac0\udcf1\uda15\udf1a\udb7a\udeb8\u8624\udbe8\udf9e\ud831\udf9e\u7709\ud8ac\udfb6\udbcd\udd1e\udada\udc0f\udb31\ude9a\udb64\ude89\udbdb\udd0f\udad4\ude53\ud840\udd0d\ud82e\ude3e\uda4e\udf81\ud9bb\udf46\ud93c\udc41\ud92b\udec8\udaa0\udf0e\ud836\udd85\ud916\udfb8\uda4f\udfeb\ud901\udd1e\udbb5\udd00\udb48\ude36\ud93d\udf2f\udb31\udea7\udbc4\udea9\ud8e9\udef5\uda92\udd1b\ud8a8\udf9c\uda06\udf52\ud949\uddcd\uda72\udc19\ud99e\udd82\udb6b\udd2d\ud8c1\udc16\ud85a\udcbc",
        48, 67510, -1055986004, -1358937867446991848L, -97472L, false, true, (char) 62038, (char) 6407,
        Double.longBitsToDouble(0x3fcb00a435f66778L), Double.longBitsToDouble(0x3fe45158640fd7deL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.util.ShapeList:@?\0121=void |this=org.jfree.chart.util.ShapeList:@?\012",
        Z.run(T, 2, 5, 5, 5, "\ud9dd\udcce", "\u0a06\u5fbc", "\uef86\ud86e\udfb3\ud915\udc25",
        35, 70559, 1799671194, -447335774050320038L, 91850L, false, true, (char) 7758, (char) 10858,
        Double.longBitsToDouble(0x3fdc8ed7f9d144deL), Double.longBitsToDouble(0x3fe7b98149b13a73L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.util.ShapeList|equals|java.lang.Object|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|clone||new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|getShape|int|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|hashCode||new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|readObject|java.io.ObjectInputStream|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|setShape|int,java.awt.Shape|new:org.jfree.chart.util.ShapeList:",
    "M|org.jfree.chart.util.ShapeList|writeObject|java.io.ObjectOutputStream|new:org.jfree.chart.util.ShapeList:",
    "C|org.jfree.chart.util.ShapeList|<init>|",
    "M|org.jfree.chart.util.ShapeList|equals|java.lang.Object|new:org.jfree.chart.util.ShapeList:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
