package org.jfree.data;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultKeyedValues_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u3a56\ud7c6\u8372\u6703\u00e2\u923d\u6064", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8",
        20, 38360, 1401232212, 5801323610451431438L, -55378L, false, false, (char) 59006, (char) 36337,
        Double.longBitsToDouble(0x3fe725e76880eefaL), Double.longBitsToDouble(0x3fdba6fee879032aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 12, "\ud899\udf3b\ud9d9\udea6\ud8b6\udcd1\ud985\udc42\udbc3\udf1a\ud8c2\udfbd\ud85f\udc0e\u9f72\udbfc\udc00\uda2e\udccc\ud800\udf2c\uda7f\udc4f\u2d43\ud847\udd27\ud949\udd26\ud82a\udd34\ud966\udc98\ud934\udda5\ud8b7\udf7e\ud86e\udde1", "\u3a56\ud6f1\u8372\u6703\u0149\u923d\u6064", "\ud8c1\udf73\udb18\udc33\ud87b\udfd5\udb29\udc8d\udba2\uddfe\ud834\ude6e\ud87c\udfca\ud84b\udde8",
        45, 38360, 642849620, 5801327441562259470L, -55378L, false, false, (char) 47166, (char) 56833,
        Double.longBitsToDouble(0x3fe727aa6880eefaL), Double.longBitsToDouble(0x3fdba6fee345912aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 15, 12, "\u7980", "\u4d6a\u6a1e\u1d17\u4045\ubfcc\u7848", "\uda7f\udc51\udb28\ude11\uda07\udca6\udac7\udcb7\udb22\udfd3\udb4b\udce9",
        2, 96104, 1086666631, -5624805128662883752L, 48377L, true, true, (char) 25838, (char) 38991,
        Double.longBitsToDouble(0x3fd23dec0ba6d642L), Double.longBitsToDouble(0x3f93a09a62171c20L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud9ea\uddca\u9f72\ud9d3\udd53\udba4\ude86\udb6e\udd50\uda7f\udc51\udb00\udf03\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u613b\u2d90\uaabf\u66ff\u3d88\u923d\u6064", "\ud891\ude5b\udb0a\ude13\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8\uda72\udce7\uda56\udcf2\u8040\uda5b\uddd4\uda1b\udc10",
        9, 97474, 107424318, -5019578342099266661L, -24352L, false, true, (char) 6353, (char) 28002,
        Double.longBitsToDouble(0x3fe9e77ca4574506L), Double.longBitsToDouble(0x3fd03193c4321460L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 3, 5, "\ud93e\udc62\uda74\udc28", "\u6a1e\u9fb5\u120d\u8f3c\u76bd\u41be\u621b\u35ec\u65ea", "\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64",
        20, 22137, -2050813352, 4651688329181961929L, 42857L, false, false, (char) 25757, (char) 38991,
        Double.longBitsToDouble(0x3fe29d8602d36b21L), Double.longBitsToDouble(0x3fe68c0e832fd690L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 10, 12, 12, "\ud899\udf3b\ud87c\udf9c\ubc40\ud9fb\udf92\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\ud89d\ude73\udbf6\udf04\ud90c\udc64\ud86e\udde1", "\u3aea\uca90\ua6cc\u6703\u1a4c\u8f65\u6064\u7fca\u6070", "\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8\uda72\udce7\uda56\udcf2\ud83f\udf3e\uda5b\uddd4\uda1b\udc10\ud94e\udd76\ud823\ude72\uda4c\ude9e\ud802\udffd",
        40, 58716, 1877923968, -9109368372809681860L, -8304L, true, false, (char) 63405, (char) 50072,
        Double.longBitsToDouble(0x3fe65f38c1e0f9fcL), Double.longBitsToDouble(0x3fd25ed15a78a74aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 2, 12, "\u8010\uda61\udf6a", "\u6a1e\u1d17\u120d\ub362\u7848\u41be\u621b\u35ec\u020e", "\ud82a\udd34\udac8\udc89\ud8f7\udc6c\ud90c\udc64",
        11, 39001, 2000740952, -3935889816304259330L, 80444L, false, false, (char) 25757, (char) 38991,
        Double.longBitsToDouble(0x3fd23dec0ba6d642L), Double.longBitsToDouble(0x3f93a09a62171c20L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 1, 1, 2, 12, "\ud84c\udf27\uda61\udf87\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud8d7\udd2d\ud82a\udc92\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u3a56\ud7c6\u8372\u6703\u00e2\u923d\u6064", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8",
        20, 38360, 1401232212, 5801323610451431438L, -55378L, false, false, (char) 59006, (char) 36337,
        Double.longBitsToDouble(0x3fe725e76880eefaL), Double.longBitsToDouble(0x3fdba6fee879032aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 12, 2, 18, "\ud899\udf35\uda61\udf6a\ud86a\ude20", "\u1d17\u6761\ub364", "\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1\ud938\udcef\ud84a\udd5f\ud923\udfe4\ud96e\udcbf\udbbd\udf64\udb9a\udc15\uda9a\udc83\ud853\udeef\uda74\udf5e\ud9f5\udddb\ud958\udc20\ud8c1\udf73\udb18\udc33\ud815\udfe2\udab7\ude72",
        -3, 60811, 1537061608, 7666524743587123317L, 89612L, false, true, (char) 41104, (char) 28736,
        Double.longBitsToDouble(0x3fdb2d16d47d52d6L), Double.longBitsToDouble(0x3f98066773774ac0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 2, 12, "\uc365\udbbb\udcd7\ud820\udd14\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\ud945\uddc9\ud9d4\udf69\uda71\udc16\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\ud9a4\uddb7\udaec\udddd\udaf2\udd36\ud926\udfde", "\u3a56\ud7c6\u8372\u6703\u00e2\u8d6f\u91bb\u0d75\u4a04\ub7fa\u44c2\ud031\u08ee\u01ac\u84dc\u66f9\u5dbc\u2233\ubd2e\u0651\u8881\u68b3\ub20b\u0882\u2200\u0d88\uac1c\u76b7\u648d\u4f46\u0981\uba8a\u9d74\u994c\u3978\u5e58", "\ud986\udcd8\udb46\uddd3\ud99b\udfc0\ud951\udd34\uda34\uddcd\udaa0\udef9\ud89f\udcb5\ud8e5\udd10\uda6b\udcc9",
        22, 57021, -1029536970, -4899079769261118698L, 30405L, false, true, (char) 48914, (char) 34778,
        Double.longBitsToDouble(0x3fde7a567bd317e8L), Double.longBitsToDouble(0x3fef32e5f98285fcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 12, 0, 1, "\udb71\udeb7", "\u4d6a\u6a1e\u1d17\u120d\ub362\u7848", "\uda42\udc80",
        16, 37569, 9703, 0L, -100000L, false, false, (char) 0, (char) 57943,
        Double.longBitsToDouble(0x3fd1177409f8e7a2L), Double.longBitsToDouble(0x3fd82b81b0004004L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 1, 3, 7, 7, "\ud813\udedf\uda41\uddd8\ud9ae\udf90\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udad4\ude7e\udb6e\udd50\uda7f\udc51\ud930\udc70\ud861\udee8\ud945\udc9e\ud813\uddc9\udb1d\udc9d\ud902\udf78\ud90c\udc0a\ud9ef\udee3", "\uc78a\ud7c6\u2681\u6703\u00e2\u923d\u6064\u0db7\u1134\u1f37\u44c2", "\udba2\uddfe\ud838\ude6e\ud87b\udfca",
        57, 71702, -771095651, 6018246523983486670L, -23147L, false, true, (char) 54185, (char) 59006,
        Double.longBitsToDouble(0x3fecddd2b0da3c51L), Double.longBitsToDouble(0x3fb351273367bda8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 10, 16, 10, "\ud8d5\uddcc\udb67\udf4d\ud8f4\udea0\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00", "\u35ec\u020e\u41dd\u9ec4\u4e28\u0512", "\ud86e\udde1",
        -2, 33609, 2127685905, -4870557228610343847L, 55091L, true, false, (char) 33777, (char) 15321,
        Double.longBitsToDouble(0x3fdcf63274c89cd6L), Double.longBitsToDouble(0x3fc46b73b5f5aa70L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1\ud938\udcef\ud84a\udd5f\ud923\udfe4\ud96e\udcbf\udbbd\udf64\udb9a\udc15\uda9a\udc83\ud853\udeef\uda74\udf5e\ud9f5\udddb\ud958\udc20\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8\uda72\udce7\uda56\udcf2\u8040\uda5b\uddd4\ud9cb\ude54\ud963\udc7f\udb1f\udc97\uda4c\ude9e\ud802\udffd\ud84d\udfa7\ud8a4\udde3\udaa9\udf18\udb19\ude46\udb08\ude38\udb7c\ude6f\ud89c\udd12\udbef\ude25", "\u7c0f", "\udb79\udc3d\uda4d\udff8\udace\ude52\uda18\udf34\udb66\udc92\ud912\udd8d\ud90f\ude95\ud198\uda5d\udf82\ud8ed\udf45\ud95b\udfa0\udbbd\ude34\udb80\udef7\udbb9\udffe\udac3\udfd4\uda34\udff1",
        14, 88798, 1475985147, 3120683427466738890L, -55554L, true, false, (char) 9901, (char) 50906,
        Double.longBitsToDouble(0x3fd9539a5d98ba04L), Double.longBitsToDouble(0x3fe4e3434624b570L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 1, 5, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\udbc2\udf20\udbad\udda1\udb29\ude3b\ud975\ude19\uda7f\udc51\udb28\ude11\udbea\udce0\udaf1\ude9b\udb79\uddb0\udaba\udc71\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\uacd7\u62dd\uc737\u6703\u00e2\u923d\u8be9\u25b6\ub9b7", "\ud815\udfe2\udb50\ude1d\udba2\udde6\ud834\ude6e\ud8e3\udf3f\ud951\udf74\u2cb8\udb44\udc20\ud80d\udf40\uda5b\uddd4\uda1b\udc10\ud94e\udd76\udb1f\udc97\uda4c\ude9e\u45e3",
        40, 58716, 1877923968, -534454446726753365L, -1140L, true, false, (char) 57344, (char) 23914,
        Double.longBitsToDouble(0x3fc105b23c7c5014L), Double.longBitsToDouble(0x3fe21b8d11eb0cd3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 11, 2, 18, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud82d\ude76\udbc3\udf1a\ud9b5\ude6e\ud843\ude57\u9f72\udbfc\udc00\ud865\udc07\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud97f\udced\ud82a\udd34\udac8\udc89\uda8b\uddcf\udb81\udcfa\udbaa\udded", "\uc15d\ud787\u48c8\u950a\u21ae\u0164\u6064", "\ud8c1\udf73\ud961\udfb7\ud985\udfda\udb50\ude82\udba2\uddfe",
        41, 42433, 1785001891, 4177490512230089640L, 2122L, false, false, (char) 28736, (char) 8992,
        Double.longBitsToDouble(0x3fe1f54b58180667L), Double.longBitsToDouble(0x3fecdb7ab5b944edL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 1, 4, 2, 12, "\udb7d\udf8e\uda84\udd7e\ud8bf\ude73\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89", "\u12d4", "\ud923\udfe4\udb49\udebd\udab7\udef2\udb9a\udc15\uda9a\udc83\ud853\udeef\uda74\udf5e",
        51, 83150, 1797355811, -6874078721601315821L, 11204L, true, true, (char) 6113, (char) 12310,
        Double.longBitsToDouble(0x3feaa69051165385L), Double.longBitsToDouble(0x3f8ca1050d5108c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 1, 5, 13, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\ud9b0\udcea\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud9c2\udcf1", "\u3a56\ud7c6\u8372\u6703\u00e2\u923d\u6064", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud82a\udee9",
        20, 38360, 1401232212, 5801323610451431438L, -58147L, false, false, (char) 59006, (char) 40874,
        Double.longBitsToDouble(0x3fe720589080eefaL), Double.longBitsToDouble(0x3fdba6fee879032aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 13, 2, 12, "\ud899\udf3b\uda61\udf6a\ud96f\ude0a\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9fab\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud976\ude26\ud82a\udd34\ud9b1\udf37\ud804\udf3e\udae2\udcea\ud8d1\udc03", "\u622f\ud7c6\u8372\u6703\u1891\u263e", "\ud958\udc20\ud8c1\udf73",
        -3, 55387, 2008206096, 5503895890702983582L, -36605L, true, true, (char) 24059, (char) 60766,
        Double.longBitsToDouble(0x3fd16538501ca104L), Double.longBitsToDouble(0x3fc16a8166cb95b4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 8, 2, 5, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\ud961\udfae\udbfc\udc84\udba4\ude86\uda81\udff9\ud96c\udc0c\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u3a56\ud7c6\u8372\uc292\u6a3c\u9242\u6064", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8",
        20, 38360, 1401232212, 5801323610451431438L, -55378L, false, false, (char) 59006, (char) 33595,
        Double.longBitsToDouble(0x3feebe41058be592L), Double.longBitsToDouble(0x3fdba6fee941032aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 6, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud839\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\ude43", "\u3a56\ud7c6\u8372\ua546\u00e2\u923d\u6064", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8",
        20, 38360, 1401232212, 5801323610451431438L, 10234L, true, true, (char) 20433, (char) 51066,
        Double.longBitsToDouble(0x3fdba6fee879032aL), Double.longBitsToDouble(0x3fa3b6da5fe38bc0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 15, 15, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\ud819\udcee\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u3a56\ud7c6\u7e4c\u6703\u00e2\u923d\u6064", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\uda6c\udfad\udb94\udcc5\ud834\ude6e\ud87b\udfca\ud84b\udde8",
        20, 38360, 1401232212, 5801280729497948174L, -55378L, false, false, (char) 59006, (char) 36337,
        Double.longBitsToDouble(0x3fe725e76880eefaL), Double.longBitsToDouble(0x3fdba6fee879032aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 1, 14, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud937\ude71\u9f89\udbfc\udc00\udb7d\ude89\udb92\udf1d\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u3a56\ud7c6\uca94\u6703\u00e2\u85e9\uabd6", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8",
        20, 38360, 1401232212, -7024928129205450859L, -55378L, false, false, (char) 59006, (char) 36337,
        Double.longBitsToDouble(0x3fe725e76880eefaL), Double.longBitsToDouble(0x3fdba6fee879032aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 7, 2, 12, "\ud9ac\udd26\uda61\udfba\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\uda6d\udcf6\ud8bb\udfb6\udb06\ude99\udb56\uddd4\ud90e\udda5\udb4b\udc62", "\u3a56\ud7c6\u8372\u6703\ua79b\u64bf\u4e8c", "\ud896\udeec\udb18\udc33\udbf8\udddb\udb4e\uddd9\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8\uda72\udce7\uda56\udcf2\udbab\udfaf\uda47\udf07\uda1b\udc10\ud94e\udd76",
        26, 98726, -1778286913, -4833063734253808924L, -32998L, false, false, (char) 15185, (char) 57154,
        Double.longBitsToDouble(0x3fd08e9908c980e4L), Double.longBitsToDouble(0x3fe2415461862d4bL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 2, 4, "", "\000", "\ud9e3\udc32",
        36, 41625, 0, -2030043136L, -58510L, true, false, (char) 9703, (char) 62208,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 1, 5, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud82d\ude16\udbdb\udc32\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbb0\ude77\udbcd\udf30\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u6823\u89c6\u8372\u674a\u00e2\ua25d\u604b", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8",
        31, 28241, -915118568, 5801413688481763342L, 10158L, true, false, (char) 59006, (char) 36337,
        Double.longBitsToDouble(0x3fe725e71880eefaL), Double.longBitsToDouble(0x3fdba6fee879032aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u73ab", "\000",
        39, 3449, 1672538657, 180635704492032L, -58510L, true, true, (char) 39703, (char) 36111,
        Double.longBitsToDouble(0x3fb35f4988d82030L), Double.longBitsToDouble(0x3fd680c51c2155d2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 2, 12, "\ud899\udf3b\ud9d9\udea6\ud8b6\udcd1\ud985\udc42\udbc3\udf1a\ud8c2\udfbd\ud85f\udc0e\u9f72\udbfc\udc00\uda2e\udccc\ud800\udf2c\uda7f\udc4f\u2d43\ud847\udd27\ud949\udd26\ud82a\udd34\ud966\udc98\ud934\udda5\ud8b7\udf7e\ud86e\udde1", "\u3a56\ud6f1\u8372\u6703\u0149\u923d\u608e", "\ud8c1\udf73\udb18\udc33\ud928\udcca\udb29\udc8d\udba2\uddfe\ud834\ude6e\ud87c\udfca\ud84b\udde8",
        45, 38360, 642849620, 5801327441562259470L, -55378L, false, false, (char) 47166, (char) 56833,
        Double.longBitsToDouble(0x3fe727aa6880eefaL), Double.longBitsToDouble(0x3fdba6fee345912aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=void |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 9, 6, 9, "\ud801\udc0f\ud9ae\uddc6\ud825\udce6\ud9d1\ude38\udbc3\udefd\udb46\udf7f\ud85f\udc0e\udb91\udfec\ud8fb\uddd7\udb96\udfac\ud800\udf2c\uda7f\udc4f\ud84f\udd44\ud847\udd27\ud949\udd26\ud814\udd34\udb9a\udcf2\udad6\udc06\ud8b7\udf12\ud86e\udde1", "\u3a56\ud6f1\u8372", "\ud853\udeef\udaed\udd31\ud9f2\udeae\udb9f\uddc4\ud9f8\udf9e\udbeb\udf11\ud87b\udfd5\udbb1\udc91\ud903\udccf",
        2, 43500, 1792337059, 4149200078047413160L, 87794L, false, false, (char) 28901, (char) 45599,
        Double.longBitsToDouble(0x3fe2fee15dd74267L), Double.longBitsToDouble(0x3fef4dd0c2e4f54dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 9, 5, 16, "\ud899\udf3b\ud9d9\udea6\ud8b6\udcd1\ud985\udc42\udbc3\udf1a\ud8c2\udfbd\ud85f\udc0e\u9f72\udbe9\udff7\udb68\udf78\ud8bd\udcf2\u507b\ud8bc\udff6\ud847\udd27\ud949\udd26\ud82a\udd34\ud966\udc98\ud934\udda5\ud8b7\udf7e\ud86e\udde1", "\u574d\u88c6\u3a96\u6703\u0149", "\uda13\udcdb\ud961\udec5\ud8c1\udf73\udb18\udc33\ud87b\udfd5\udb29\udc8d\udba2\uddfe\ud834\ude6e\ud87c\udfca\ud84b\udde8\udac5\udee1\uda56\udcf2\ud95f\udfdf\ud8f0\ude9b\udb9e\uddee\ud94e\ude1b\uda19\udc94\udb1f\ude27\ud960\uddb8\udbca\udff9\udae2\udf83\ud90f\ude11\udbb8\ude5d\uda3f\ude1f\ud885\udf0e\uda7e\ude35\ud854\udf02\ud8c0\udf04\udad8\udc43\ud8d8\udd48\u5be6",
        47, 55240, -1133500664, 202672404073822418L, -86307L, false, true, (char) 48016, (char) 36350,
        Double.longBitsToDouble(0x3fb0128404396850L), Double.longBitsToDouble(0x3fd088daa636d05aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 9, 3, 14, "\ufd1e\ud9d9\ude74\ud8b6\udcd1\ud985\udc42\udbc3\udf1a\ud9d7\udd68\uda0d\ude9c\ud80d\udebc", "\u3654\u35ea\u3a41\ua0b9\u9ec4\u1c7c\uc6ca\u857d\u770e\u12d4\uc96e\ub101\u3a56\ud6f1\uceb4\u7d77\u0149\uc4c8\ucb4d\u5a4e\u7aad\ub81b\u44c2\u56c5\u435d", "\ud87c\udfca\ud84b\udde8\udac5\udee1\uda56\udcf2\ud80d\udd96\uda5c\udd50\udb23\ude55\ud9f8\udd8d\udb1f\udc97\udb1f\ude27\ud960\uddb8\uda46\udf47\ud8a4\udde3\udaa9\udf18\udbb8\ude75",
        52, 76525, -206199674, 7926742384749838763L, 53144L, false, false, (char) 30924, (char) 471,
        Double.longBitsToDouble(0x3fc50784a76bb768L), Double.longBitsToDouble(0x3fdc40ea6b9c8f3cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 2, 12, "\u0081", "\000\000\u1cdb", "\udbfc\udc00\ua44a\udb6e\udcec",
        19, 81346, 762358265, 7783951171936781026L, -100000L, false, false, (char) 14215, (char) 61005,
        Double.longBitsToDouble(0x3fe2c58f81007740L), Double.longBitsToDouble(0x3fcf8e60160ae06cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 15, 6, "\u0081", "", "",
        -5, -1000, 0, 0L, -31345L, false, false, (char) 43764, (char) 21450,
        Double.longBitsToDouble(0x3fe7136034a78847L), Double.longBitsToDouble(0x3fd1b046e11018a2L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 9, 3, 5, "\u5017\ud9fb\udc64\ud8ec\ude48\ud985\udcf9\ud9a3\udc0a\ud9ac\uddf2\ud9c1\udf17\ud938\udc93", "\u1643", "\udbed\udda5\uda34\udf45\udb22\udfd3\udb4b\udce9\ud818\udd50\udabf\udd61\ud8bb\udc70\ud938\udcef\ud84a\udd5f\ud923\udfe4\uda7e\udd82\udbbd\udfca\udb9a\udc15\ud8c8\udd8a\ud847\uded3\ud984\udc84\ud9f5\udddb",
        41, 94214, -1600496173, -5124572652787741936L, -64794L, true, false, (char) 59082, (char) 33767,
        Double.longBitsToDouble(0x3fecc7032229322cL), Double.longBitsToDouble(0x3fcbb0c92bdc1b04L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=java.lang.Integer:1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 7, 15, 12, "\u7980", "\u4d6a\u6a1e\u1d17\u4045\ubfcc\u02c8\u41be\u621b\u35ec\u020e\u17d4\ube61\u84fc\u19e7\u7fb4\u340c\u244b\u8904\u07af\u3a56\ud7c6\u8372\u6703\u00e2", "\ud9f5\udddb\ud958\udc20\ud8c1\udf73\udb18\udc33\ud815\udfe2\ud94d\udfbd\udaf3\udf26\ud9b5\udf6a\ud9aa\ude6d\uda3e\ude8b\udaaf\udd90\uda88\udf55",
        6, 91374, -409566095, -4711115240089101747L, -72039L, true, false, (char) 29394, (char) 38147,
        Double.longBitsToDouble(0x3fd7402c0047eb12L), Double.longBitsToDouble(0x3f95ce4a0533c780L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=java.lang.Integer:272708708 |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 15, 13, "\u799b\uda64\udcb0\ud8b6\udcb1\ud99f\udfe2", "\u4045", "\ud86f\udd86\ud9f0\uddcb\udb98\udcd5\udb3d\udf1b\uda07\udca6\udac7\udcb7\udb1f\udd51\udb4b\udce9",
        2, 96104, 1086666631, -5624805128662883752L, 48377L, true, true, (char) 25838, (char) 28239,
        Double.longBitsToDouble(0x3fdae98b3456882aL), Double.longBitsToDouble(0x3f93a01262171c20L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 4, 1, 5, "\udaac\udfcc\uda74\udc28", "\ud1c7\u9fb5\u120d\u8f3c\u76bd\u41be\u25f6\u5ec8\u5577\u1fc3\u8b2b\u4e28", "\ud90c\udc64\ud9ca\udd10\ud8bd\ude6a",
        43, 31588, -1028088119, 2350081614496400259L, 72540L, false, false, (char) 6665, (char) 3572,
        Double.longBitsToDouble(0x3fca303a10f3e8c8L), Double.longBitsToDouble(0x3fe0f56da1ec730dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 13, 18, "\ud941\ude9a\uda74\udc28\ud8ca\ude5f\ud985\udc42\uda46\udc29\uda90\udf06\ud843\ude57\ud8b9\udcda\udbc5\ude76\udba4\ude86\udb6e\udd50\uda7f\udc51\u9610\udbe9\udee0\ud949\udd26\ud82a\udd34", "\u008f", "\udb5a\udeec\udba4\uddb1\ud9ee\udf2c",
        2, 63906, 1774930273, -300103684794344248L, -58317L, true, false, (char) 59583, (char) 49483,
        Double.longBitsToDouble(0x3fd3064418263290L), Double.longBitsToDouble(0x3fe35315c3ec468cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 16, 10, "\ud8d5\uddcc\udb67\udf4d\ud8f4\udea0\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\uda55\udc51\u9f72\udbfc\udc00", "\u35ec\u020e\u41dd\u6dc5\u4e28\u0512", "\ud86e\udde1",
        -2, 86065, 2127822107, -4870557228610343847L, 9805L, true, false, (char) 33777, (char) 15321,
        Double.longBitsToDouble(0x3fdcf63274c89cd6L), Double.longBitsToDouble(0x3fc46b73b5f5aa70L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 2, 12, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\udbc2\udf20\udbad\udda1\ud9aa\ude3c\uda3a\udcd8\uda7e\udffc\udb28\ude11\udbea\udce0\udaf1\ude9b\udb79\uddb0\udaba\udc71\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\uacd7\u62dd\uc737\u6703\u00e2\u2b6b\u7ab3\u25b6\ub9b7", "\ud815\udfe2\udb50\ude1d\udba2\udde6\ud834\ude6e\ud86e\ude96\ud951\udf74\u2cb8\udb44\udc20\ud80d\udf40\uda5b\uddd4\uda1b\udc10\ud94e\udd76\udb1f\udc97\udb83\udeba\udad3\udeb8",
        40, 58716, 1877923968, -534454446726753365L, -74566L, false, false, (char) 57509, (char) 23914,
        Double.longBitsToDouble(0x3fc105b23c7c5014L), Double.longBitsToDouble(0x3fe21b8d11eb0cd3L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 8, 8, 12, "\udb7d\udf8e\uda5c\udd7e\ud8bf\ude73\ud985\udc42\udbdd\udce8\ud941\udc58\ud866\ude36\u9f72\udb82\udc03\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\ud82a\udd34\udac8\udc89", "\u12d4", "\ud923\udfe4\udb54\udd88\udab7\udef2\udb9a\udc15\uda9a\udc83\ud853\udeef\uda74\udf5e",
        51, 83150, 1797355811, -6874078721601315821L, 11204L, true, true, (char) 6113, (char) 12310,
        Double.longBitsToDouble(0x3feaa69051165385L), Double.longBitsToDouble(0x3f8ca1050d5108c0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 10, "\ud9c3\ude91\ud926\udf08\ud8b6\udcb1\ud985\udc42\ud999\udd65\ud821\udc94\ud843\ude57\u9ffe\udbfc\udcc8\udba4\ude86\ud9b0\udcea\uda7f\udc51\udb28\ude11\udbe9\udee0\ud949\udd26\udb5b\udd4d\uda72\udc7e\ud86e\udcb7\ud90c\udc64\ud9c2\udcf1", "\uc9bf\ud7c6\uc671\u6703\u67e2\u923d\ub164", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud82a\udee9",
        20, 38360, -510390484, -6666601495022931958L, 4328L, false, false, (char) 59006, (char) 40874,
        Double.longBitsToDouble(0x3fe720589715bd3aL), Double.longBitsToDouble(0x3fdf30ddaab9b5e6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 8, 8, "\ud8e8\udc32\ud974\udf5e\ud8fd\ude2d\ud9a0\udca1\ud85b\udd07\udb8e\udcc7\uda6c\ude52\udac3\udc7f\udb0c\udd1a\udac2\udf7c\udadb\udf4e\ud84c\udd58\ud9f6\ude62\udb5e\udca4\ud949\udd26\ud82a\udd34\udac8\udc89\udac4\ude6b\ud97c\udc60\ud9bf\uddd8", "\u3a56\ud7c6", "\uda9a\udc83\ud9f9\ude01\ud9bb\udd0d\ud9f5\udddb\ud958\udc20\ud8c1\udf73\ud983\udc08\ud815\udfe2\uda77\udfa0\ud8a2\udc47\ud831\ude90\ud87b\udfca\ud82a\udee9\uda72\udce7",
        5, 58212, 1317171478, 4935894371924782312L, -45278L, false, false, (char) 51370, (char) 62444,
        Double.longBitsToDouble(0x3fc01ddf56e9bfb8L), Double.longBitsToDouble(0x3fae40cada938a70L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 4, 5, 12, "\ud899\udf3b\uda61\udf6a\ud96f\ude0a\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9fab\udbfc\udc00\udba4\ude86\udb6e\udd50\uda7f\udc51\udb28\ude11\udbe9\udee0\ud976\ude26\ud82a\udd34\ud9b1\udf37\ud804\udf3e\udae2\udcea\ud8d1\udc03", "\u622f\ud7c6\u33cb\u6737\u1891\u263e", "\ud958\udc20\ud8c1\udf73",
        -3, 55387, 2008206096, 5503895890707871411L, -36605L, true, true, (char) 24098, (char) 62151,
        Double.longBitsToDouble(0x3fd1653851434f04L), Double.longBitsToDouble(0x3fc16ef70419839cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 4, 4, 6, "\ud899\udf3b\uda61\udf6a\ud87b\udc4f\uda80\udca2\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\udb92\ude21\uda97\udc78\udaee\udf0f\ud841\udc9d\uda7f\udc51\udb28\ude11\udbe9\udee0\ud976\ude26\ud82a\udd34\ud9b1\udf37\ud804\udf3e\udae2\udcea\ud8d1\udc03", "\u622f\ud7c6\u8372\u6703\u1891\u263e", "\ud958\udc20\uc96d",
        14, 5883, 655721867, 5503689096617615774L, 98749L, true, true, (char) 24059, (char) 60766,
        Double.longBitsToDouble(0x3fd16538501ca104L), Double.longBitsToDouble(0x3fc16a8166cb95b4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 2, 5, "\uda97\udee1\udbfb\udf36\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\ud961\udfae\ud8a4\udd58\udb54\udf66\uda81\udfc9\ud96c\udc0c\udb28\ude11\udbe9\udee0\ud949\udd26\udb73\udfbe\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\ubf12\ud6fc\u8372\u653d\u206e\u9242\u6064", "\ud886\udc5b\udb60\ude6b\uda68\udfb7\ud8fa\udd88\udba2\uddfe\ud834\ude6e\ud87b\udfca\ud84b\udde8\ud9c2\udff0\uda19\ude1f",
        33, 65222, 1157069011, -3355977542628847182L, 88440L, true, false, (char) 6136, (char) 60189,
        Double.longBitsToDouble(0x3fdba6fee941032aL), Double.longBitsToDouble(0x3fe0dd56f3026be9L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 8, 1, 4, "\udb10\udf4d\u8a02\udb51\udd17\udabc\udf0b\udb96\udc44\udbe8\udfad\ud843\ude57", "\uc1c5\u6237\u35ec", "\ud858\udf23\u1803\udad5\udd0e\000\ud965\udedc\uda7d\udec7\ud82a\ude7b\udb64\udcb8\uda15\udc03\ud8c7\udefd\udae1\ude9d\udaaa\udf17\uf31c\uda29\udceb\ud964\udda9\ud9f1\udde4\ud9ed\udfcd\ud8c9\udfaa\ud936\ude92\ud823\udcce\u8c3c\ud975\udc06\u0a08\ud966\ude1d\uda9b\udef2\ud82d\udf13\udbb9\udc09\udbf7\udc5c\udb62\udd84\uda09\ude27\udae3\udeb3\uda55\udcc0\ud985\udd4c\ud934\udf37\udb5c\uddda\udbb5\udfac\udae7\ude9b\ud82b\udc0f\ud944\udc11\udb91\udf52\udaf5\udcd7\u9c9c\ud8c1\udc8c\ud809\udc7d\udb61\udc0e\ud9b5\udd68\uda14\udccf\ud937\udfc4\u92c1\u5760\udb6a\udc03\ua52d\ud947\ude60\udb02\udffb\uda13\udf7d",
        16, 93194, -545175217, 4526850108861964895L, -71816L, true, false, (char) 7868, (char) 61850,
        Double.longBitsToDouble(0x3fc3c97ebd5b1e58L), Double.longBitsToDouble(0x3fdf9b5b52636194L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=java.lang.Double:0.5936133225278127 |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 14, 9, "\ud801\udc0f\ud9ae\uddc6\uda6e\udf4b\u84e0\udbc3\udefd\ud982\udf7e\ud873\udec3\udb91\udfec\ud8fb\udd57\udb96\udfac\uda82\udcae\udb39\uded0\ud860\uddab\udb03\ude45\uda3a\udcb7\ud814\udc8f\udb9a\udcf2\udafa\udc0e\ud8b7\udf12\ud86e\udde1", "\u3a56\ud6f1\u8372", "\ud853\udeef\udaed\udd31\ud934\udc2d\udb65\udc74\ud9f8\udf9e\udbeb\udf11\ud87b\udfd5\udbae\udd91\ud903\udccf",
        2, 43500, 1792337059, 4149199897658786728L, 87794L, false, false, (char) 28901, (char) 45599,
        Double.longBitsToDouble(0x3fe2fee15dd74267L), Double.longBitsToDouble(0x3fcd37431bdce5acL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 9, 14, 9, "\ud801\udc0f\ud9ae\uddc6\ud825\udce6\ud9d1\ude38\udbc3\udefd\udb46\udf7f\ud85f\udc0e\udb91\udfec\ud8fb\uddd7\udb96\udfac\ud800\udf2c\uda7f\udc4f\ud84f\udd44\udaf2\ude9b\ud8ad\udda2\ud814\udd34\udb9a\udcf2\udad6\udc06\udbef\udf8d\ud88b\udc56", "\u3a56\ud6f1\u8372", "\ud853\udeef",
        46, 60955, -1228928490, 7744833775534913491L, -41469L, true, true, (char) 15676, (char) 60766,
        Double.longBitsToDouble(0x3fd92265101cba24L), Double.longBitsToDouble(0x3fcb488162cb45b4L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 14, 9, "\ud801\udc0f\ud9ae\uddc6\ud825\udce6\ud9d1\ude38\udbc3\udefd\udb46\udf7f\ud85f\udc0e\ud9ae\udedb\ud9fd\udc6a\ud832\udea1\ud940\udcd7\uda91\udd95\ud84f\udd44\ud847\udd27\ud949\udd26\ud814\udd34\udb9a\udcf2\udad6\udc06\ud8b7\udf12\ud86e\udde1", "\u3a56\ud6f1\u8372", "\ud853\udeef\udaed\udd31\ud9f2\udeae\udb9f\uddc4\ud9f8\udf9e\udbeb\udf11\ud87b\udfd5\udbb1\udc91\ud903\udccf",
        57, 43500, -1337443933, 6709851462434423750L, 87794L, false, false, (char) 28901, (char) 45599,
        Double.longBitsToDouble(0x3fe2fee15dd74267L), Double.longBitsToDouble(0x3fef4dd0c2e4f54dL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 3, 8, "\u5017\ud9fb\udc64\ud8ec\ude48\ud985\udcf9\ud9a3\udc0a\ud9ac\uddf2\ud9c1\udf17\ud938\udc93", "\u1643\u7b5f\u24ed\u3ed1\u245c\u84fc\u19e7\u69ea\u5bdb\u3160\u8904", "\uda7e\udd82\udbbd\udfca\udb9a\udc15\ud8c8\udd8d\ud847\uded3\ud984\udc84\ud9f5\udddb\ud91f\ude04\ud8e3\uddd6\udb18\udc33\ud816\udc22\ud86e\udc0d\ud913\uddf0\ud8a2\udd5f\ud9ba\udd4e\udb54\udf02",
        33, 12352, -2042004951, 486917474982238967L, -59938L, true, true, (char) 42180, (char) 33991,
        Double.longBitsToDouble(0x3fc2e240c90386b4L), Double.longBitsToDouble(0x3fe71f52601cdcc8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 2, "\ud941\ude9a\uda74\udc28\ud8ca\ude5f\ud985\udc42\uda46\udc29\uda90\udf06\ud843\ude57\udb69\uddb7\udbfa\udf36\udba4\ude86\udb6e\udd50\uda7f\udc51\u9610\udbe9\udee0\ud949\udd26\ud82a\udd34", "\u008f", "\udb5a\udeec\udba4\uddb1\uda87\udc23",
        22, 51750, 1563190902, -300103036254282552L, -58317L, true, false, (char) 59583, (char) 53245,
        Double.longBitsToDouble(0x3fd3064418263290L), Double.longBitsToDouble(0x3fe35315c3ec468cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 5, 18, "\ud941\ude9a\uda74\udc28\ud8ca\ude5f\ud985\udc42", "\u120d\u8f3c\u76bd\u41be\u621b\u86aa\u6661\u8add\u9ec4\u4e28\u0512\u7fb4\u008f\u12d4\u311e\u5940\uba66\u2e28\u890c\u6703\u3ec4\u8066\u7104\u0d5c\u7c28\u3d4c", "\uda3d\ude4b\ud9d4\udd2e\ud994\udead\uda8f\udd8f\uda57\udef7\ud8c6\udd17",
        34, 39790, -457754752, 7279703112961052570L, -88195L, false, false, (char) 40378, (char) 54877,
        Double.longBitsToDouble(0x3fe0035791da2e90L), Double.longBitsToDouble(0x3fcb8a1be55c2398L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 5, 2, "\udb04\udf82\ud860\udc01", "\u6a1e\u1d17\u120d\u73ad\ub90d\ub0ca\ub389\u3597\u020e", "\udb79\uddb0\udaba\udcc6\udb56\uddd4\ud90c\udc64",
        20, 96657, -1201854381, 8345596251946759676L, -3366L, true, true, (char) 31917, (char) 33777,
        Double.longBitsToDouble(0x3fe07bbd95cf6327L), Double.longBitsToDouble(0x3feb227359537a1bL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 2, 16, "\ud8a9\uddb6\uda61\udf6a\udad7\udcad\udaf1\udc8e\ud911\udfbf\ud9e3\udc6e\ud843\ude57\udbc2\udf20\udbad\udda1\ud9aa\ude3c\uda3a\udcd8\uda7e\udffc\udb28\ude11\udbea\udce0\udaf1\ude9b\udb79\uddb0\udaba\udc71\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u19a4\u9eb9\u5d92\u26fb\u00e2\u2b6b\u7ab3\u4015\u516f", "\u6378\udb50\ude25\ubcee\ud834\ude6e\ud86e\ude96\ud920\ude7d\u2c6e\udb5b\ude20\ud80d\udf40\uda5b\uddd4\udbbd\udd01\ud971\ude80",
        22, 27062, 1147341489, -4832974162710850844L, 46563L, true, false, (char) 36645, (char) 34803,
        Double.longBitsToDouble(0x3fe20c4a5ca6af78L), Double.longBitsToDouble(0x3fe56667f9bf26e7L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 7, 7, 12, "\udba1\udd02\uda88\udf75\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\udbc2\udf20\udbad\udda1\ud9aa\ude3c\uda3a\udcd8\uda7e\udffc\udb28\ude11\udbea\udce0\udaf1\ude9b\udb79\uddb0\udaba\udc71\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\uacd7\u62dd\uc737\u6703\u00e2\u2b6b\u7ab3\u25b6\ub9b7", "\ud815\udfe2\udb50\ude1d\udba2\udde6\ud834\ude6e\ud86e\ude96",
        17, 5043, -766403886, 6018438940527325462L, -23147L, false, true, (char) 54185, (char) 53016,
        Double.longBitsToDouble(0x3fecda231ae4bcedL), Double.longBitsToDouble(0x3fc01ddf520dbfb8L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 17, 7, "\ud899\udf3b\uda61\udf6a\ud8b6\udcb1\ud985\udc42\udbc3\udf1a\ud9e3\udc6e\ud843\ude57\u9f72\udbfc\udc00\udba4\ude86\ud895\udc43\ud936\udd25\udb8c\udc0f\ud8da\udf04\ud8e5\udf55\ud82a\udcd3\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1", "\u3a56\ud7c6\u8372\u00d8\u00e2\u923d\u6064", "\ud8c1\udf73\udb18\udc33\ud815\udfe2\udb50\ude1d\udba2\uddfe\ud961\udc05\ud87b\udfca\ud84b\udde8",
        20, 38360, 1401232212, 5801323610451431438L, -55378L, false, false, (char) 59006, (char) 36337,
        Double.longBitsToDouble(0x3fe725e76880eefaL), Double.longBitsToDouble(0x3fdba6fee879032aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 18, 3, 10, "\ud93e\udc62\udb87\udfd1\ud8ca\ude5f\ud985\udc42\udbc3\udf1a\ud9cd\udf0d\ud843\ude57\ud8b9\udcda\udbc5\ude76\udba4\ude86\udb6e\udd50\uda7f\udc51\u9610\udbe9\udee0\udb22\udf92\ud82a\udd34\udac8\udc89\udb56\uddd4\ud90c\udc64\ud86e\udde1\ud868\udee9\udb5a\udf23\udb7f\udcd2\ud992\udd9a\u8c51\udb9a\udc15\ud8d0\ude00", "\u0db7\u7c28\u3d4c\ub488\u7db4\ud1ba\ub5dd\u9386\u1146\u631e\u1812\ucbda\u720d\u9f05\u24ca\ua5ac\u4f8f\ua423\u3e26\u7b6d\u5651\u5706\u9633\u3924\u9901\ua935\u0616\ua05e\u75a6\u614c\ud0e8", "\ud95f\udc15\ud969\ude2d\u6b39\ud920\udfc6\uda41\ude3f\ud81a\uddb7\ud851\udd4a\ud809\udf97\ud9b8\udfb2\ud9f3\ude46\uda67\udfdf\ud872\udc58\udb99\udf48\ud870\udef1\uda02\ude31\uf039\u256d\ud943\udf66\udb94\udf8a\ud94e\udd77\uda9c\udd88\uda85\udd78\ud8de\udc5b\udb6c\udecd\udae2\udca2\udb00\udd55\ud8b2\ude6f\udb66\udc87\u1168\ua8b2\ud953\udd34\ud8cb\udcc8\udb0c\udcbd\uda74\udc02\udad2\udebb\ud826\udd7b\ud9ca\uddcf\uda1c\udff7\ud993\udfe7\udab0\udf6a\udb4e\udd71\ud872\udf0d\udba1\udea1\udb38\ude7e\udb54\udda1\ud93e\uddf2\uda9e\ude1b\ud98c\ude33\ud9f3\udd6b\uda79\udcfe\udb0b\ude46\ud9ee\udd02\uda1e\udca0\udbda\udc03\udaae\udf35\ue918\udb06\udfd6\u9fe2\uda39\udde8\uda0c\ude38\ud8ff\uddc7\udafc\udfab\ud829\ude9e\ud9dc\uddfc\ud85b\udffe\ud81e\udc54\udbf8\udef4\ud840\ude73\ud835\ude50\uda37\udd97\ud901\ude3e\uc6db\udb5a\udff3\udbf7\udfde\ud8a2\uddba\uda9b\udc75\ud9ca\udc9d\ud9d1\udf46\ud9c1\udc30",
        17, 8834, 315045626, 9198980492188504663L, -95399L, true, false, (char) 53189, (char) 50257,
        Double.longBitsToDouble(0x3fe15e30554b8e89L), Double.longBitsToDouble(0x3fcda8275176d5ccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.DefaultKeyedValues|removeValue|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|removeValue|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|int|new:org.jfree.data.DefaultKeyedValues2D:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues2D:",
    "M|org.jfree.data.DefaultKeyedValues|addValue|java.lang.Comparable,double|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|addValue|java.lang.Comparable,java.lang.Number|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|clear||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|clone||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|equals|java.lang.Object|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getIndex|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getItemCount||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getKey|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getKeys||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getValue|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getValue|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|hashCode||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|removeValue|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|removeValue|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|int|new:org.jfree.data.DefaultKeyedValues2D:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues2D:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
