package org.jfree.data;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultKeyedValues_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\uc91c\u8476\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        49, 16697, 304963465, -5944524056646054007L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb94\udcbc\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\udb08\udf97\uda47\uddf4\udb40\ude6e\ud951\udddd\ud862\udcf4\udbd7\udeb2", "\uc954\u8f8b\u5c19\uc91c\u8476\u4996\u448a\u8a09\u95c4", "\uda71\udcc6\uda98\uddc6\ufb44\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\ud9ef\udda7\ud923\ude0c\ud9b4\udf65",
        14, 9111, 160055079, 2293532709830352777L, -75546L, false, false, (char) 15875, (char) 26356,
        Double.longBitsToDouble(0x3fe4be073fde8425L), Double.longBitsToDouble(0x3fed111a5e8fbcd4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 1, 7, "\ud887\udef1\ud970\udca6\uda53\ude01\ud850\udd2c\udb91\ude43\uda20\ude17\uda8a\udd34\ud83b\ude2c\udb2f\udd20\udb07\udd16\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0", "\u14ba\u088d\u5e82", "\ud81a\uddf1\udbd9\ude96\uda0b\udcff\udad4\udc1b\uda56\udeae\udba9\udc1f\ud895\ude4c\udb66\udecd",
        10, 58446, 1761539803, 8347173362262843951L, 24244L, false, true, (char) 21349, (char) 36832,
        Double.longBitsToDouble(0x3f8e70eb7f30d440L), Double.longBitsToDouble(0x3fb021c724021bb8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 1, 7, "\ud94f\udd65\uda9f\udcbc\udb70\udccf\uda69\udcc4\ud958\udd5d\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud827\udd8d\ud9ce\udd07\uda8a\udfac\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u5211\ub336\uc9ad\u8476\u4996\u448a\u8a09", "\ud9a0\uddeb\udb01\udc0d\udb84\udd1b\ufb4a\uda35\udce2\udbca\udfa1\udbd4\udcfc\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\uda59\udf3a\uda45\udc52\udbea\udd7d",
        -4, 64924, -1943908878, -5944524949999251575L, -43694L, false, false, (char) 9256, (char) 47912,
        Double.longBitsToDouble(0x3fed111a58a593d4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 2, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\ud149\u8476\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\ud9b4\udf94\uda45\udc52\ud9fd\udd63",
        49, 16697, -668115063, -5944524056646054007L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 1, 8, "\ud9c6\udc1a\udaa7\udd72\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34", "\ub686\u313a\u9143\u7da9\ua640\u9f61\u9b6f\u57ba\u088d\u6402\ucaa8\u6e59\u1efe\u05de\u5c2f\uc91c\u8476\u7700\u4518\u8a09\u95c4\u77d0", "\ud946\udd3e",
        47, 20724, 1880579944, 4795176153354358101L, 93723L, true, true, (char) 21635, (char) 47413,
        Double.longBitsToDouble(0x3fe6b86a5f27a380L), Double.longBitsToDouble(0x3feec84c57891fd4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\udb7d\udff2\u683f\udb45\ude88\udb77\ude9e\udb6d\udcac\u3365", "\uc954\u8f8b\u5c19\uc91c\u4851\u9125\ub252\u8a09\u95c4\u77d0\u1b4c\u5f3e", "\ud9bc\udf47",
        4, 8950, 941378901, -4372467410199071236L, -62409L, true, true, (char) 19811, (char) 32605,
        Double.longBitsToDouble(0x3fe6f0916f89ad80L), Double.longBitsToDouble(0x3fe74566cc0ed7d9L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 16, 9, "\ud94f\udd65\ud936\udf3a\ud83c\uddfc\ud964\uded3\udb91\ude8a\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udbac\udd99\ud81f\udf13\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365\ud9ab\udf82\udade\udd31\ud81a\uddf1\udbd9\ude96\udb32\uddf2\udad4\udc1b", "\u448a\u8a09\u95c4\u77d0\u1b4c\u5f3e\u38bc\u1ffd", "\udbd1\udf39\ud9f2\udca3\ud90a\udf48\ud898\udfcb\udb61\udc39\udb80\udd15\u687e\ud9b4\udf65\uda45\udca5\ud9fd\udd63",
        49, 56353, 304963465, -5944524056338991479L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=java.lang.Integer:1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 12, 15, 12, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\udbbb\udf12\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\uc91c\u8476\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\ud938\udf71\u94a5\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        49, 16697, 304963465, -5944524056646054007L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 13, 0, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\ud856\udc08\uda63\udd70\udab5\udcd7\ud987\udfaf\udb00\udf15\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udbc1\udc86\uda52\udf4e\ud916\ude4b\udb18\udcde", "\uc954\u8f8b\u5c19\uc91c\u8476\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\udb80\uddca\udb05\udea5\ud811\ude02\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        49, 16697, 304963465, -5944524056646054007L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe2020777d4471bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 7, "\uda42\udefe\000\udb70\udc5c\ud90f\ude57g\uda0e\udc46\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\ud830\udda9\000\000\000\ud836\udf7a", "\u0d37\u8f8b\u5c19\u6756\u0403\u4996\u448a\u8a09", "\udbe1\ude2f",
        37, 81839, 0, -9079256848778919832L, -80203L, true, false, (char) 31053, (char) 34588,
        Double.longBitsToDouble(0x3e41653400000000L), Double.longBitsToDouble(0x3fbe809d1c576d58L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\ud864\udf78\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c", "\ua656\u9f61\u9b6f\u14ba\u088d\u5e82\ucaa8\u6e59\uc954\u8f8b\u5c19\u5191\u84e5\u4996\u448a\u8a09\u95c4\u77d0\u1b4c\u5f3e\u38bc\u1ffd\u55fe\ucc41\u0a2d\u8fd5\ub823\u0eb5\u7036\u68b8\uaf41\u4ec0\u2b4c\ud535\u7a75\u5192\u2d14\u5517\u7cfb\u9751", "\ud9a6\udf4a\ud9b8\udd17\uda73\udfac\uda34\ude62\udb05\ude70\udb7e\udf91\udb1e\udfe8\ud9c7\udc22\udb15\ude9a\ud9fc\udf90\ud8a0\udfcc\udb2e\udd3a\ud89b\udf3f",
        26, 28696, 536107425, -1319762701988551337L, 56261L, true, false, (char) 9040, (char) 35797,
        Double.longBitsToDouble(0x3fdd30b91398b06cL), Double.longBitsToDouble(0x3fdff56995c236e8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=java.lang.Integer:-1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 12, 9, 8, "\u634a\uda92\udd2f\udb70\udd07\ud90f\ude57\udb91\ude43\uda20\ude17", "\ub4da\ub686\u5de0\u9143\u3e2e", "\udb40\udee5\ud951\udddd\udb45\udc65\ud981\udc8b\ud9ab\udf82\udb77\udced\udab6\udc26\ud8cd\udd87\udb32\uddf2\udad4\udc1b\uda56\udeae\udba9\udc1f\ud895\ude4c\udb66\udecd\udafe\udfb2\ud81b\udfaa\udaf5\udc25\uda71\udc6b\udb9f\udc8a\ufb4a",
        -1, 6361, -222332381, 4043191617691181071L, -79584L, true, false, (char) 47656, (char) 30446,
        Double.longBitsToDouble(0x3fec576d5ad70d4bL), Double.longBitsToDouble(0x3fa3d1c03b0df8c0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 9, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\ud975\ude72\uda8a\udd34\ud860\ude9c\uda43\udc6d\ud9d9\udedd\udae8\udce3\ud829\udc33\ud9b6\ude0f\ud979\udff0\ud844\udeec\ud9ce\udf2d\ud951\uddc6\udb45\udc65\u3365", "\uc954\u8f8b\u9834\uc91c\u8476\u1023\u36a6\u8a09", "\u6906\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udab7\udf0c\ud9f2\udca3\uda57\uddad\udb1e\udfe7\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        18, 16697, 304963465, -5944524056646054007L, 55890L, true, false, (char) 26802, (char) 3736,
        Double.longBitsToDouble(0x3fed808e968fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=org.jfree.data.DefaultKeyedValues:@? |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 7, 5, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57", "\u87e6\ucd14\ub4da\ub686\u5d61", "\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb78\udf65\uda02\udf20\uda28\udf19\ud89d\uddee\uda9e\udf52\udbd9\ude96\udb32\uddf2\udad4\udc1b\uda56\udeae\udba9\udc1f\ud885\udcb9\udb4c\udf50\udafe\udfb2\ud81b\udfaa\u7d0b\uda71\udcc6\udb9f\udc8a\udb0f\udf1b\ud9bc\udf47\ud811\ude03\udbd1\udf39\udbc7\udd8e\uda31\udd00\ud00b\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63\udac9\ude86\ud893\uddb9\ud8be\udc9b\ud847\udc06\u6512\ud8dd\udc8a",
        48, 22080, -2077949289, 2543186899478281122L, -55737L, true, true, (char) 888, (char) 6723,
        Double.longBitsToDouble(0x3febc2699fad4de0L), Double.longBitsToDouble(0x3febe6dcd1f2175eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 12, 8, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udf9c\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\uc91c\u8476\u4996\u448a\u1936", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        53, 16697, 304963465, -5944524056646054007L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 3, 1, 7, "\ud94f\udd65\ud9a5\udecb\udb70\udcc7\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud903\udf04\uda43\udc6d\u87a8\ud871\udf0e\ud95c\ude56\ud95e\ude84\ud979\udff0\udb24\udc42\udb40\udee5\udb52\udff9\ud8b0\ude68\u3365", "\u6c44", "\udbfc\udc24\uda56\udeae\ud857\udfdb\uda12\udcfb\ud896\udd64\ud8e5\uddca\ud81b\udf24\u7d0b\uda71\udcc6\ud8eb\udd94\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\udab9\ude48\u3ec6\uda01\udff5\udbdd\uddb6\ud9cf\udcb8\udb54\udd99\ud877\udede\uda1e\udd36\ud9b1\udc45\udaa8\udffd\udadc\udf87\ud9ac\udc77\ud9b8\udd17\uda73\udfac\ud909\udebd\udaf4\udd70\uda88\udfd6\ud8ee\udecd\uda58\udd84\ud89b\udf1f\u3729\ud97b\udf9a",
        32, 87205, 2047920038, -4423889299824898643L, 99320L, true, true, (char) 27966, (char) 36519,
        Double.longBitsToDouble(0x3fec79958ec554ceL), Double.longBitsToDouble(0x3fa80f3926f1f770L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 14, 7, "\ud979\udf9e\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\uc91c\u8476\u4996\u448a\u4d4a", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a",
        -1, 59944, 1116463950, 4043191591921377295L, -14048L, true, false, (char) 55791, (char) 30446,
        Double.longBitsToDouble(0x3fc15db56b5c3750L), Double.longBitsToDouble(0x3fe93d1c03d9098aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 11, 8, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud8f7\udf57\udb91\ude43\uda20\ude17\uda8a\udd34\ud9e2\udd7d\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\ud8fd\udcaf\udbca\ude6e\ud923\udd5b\uda15\udc6d\u3365", "\uc954\u8f8b\u6d5c\ud18c\u8476\u4996\u9db9\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\udb76\udf44\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udad7\udc54\udb9c\udeef\uda7c\udf08\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        49, 16697, 304963465, -5944524054392402039L, -91572L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5d87f89bL), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 4, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\ud84f\uddc1\udb5b\udf3c\ud8c1\udf48\ud860\uddda\uda43\udc6d", "\u9143\uafc9\ua656\u9f61\u2772\u5cdc\u088d\u5e82\ucaa8", "\udbd9\ude96\udb32\uddf2\udad4\udc1b\uda56\udeae\udba9\udc1f\ud995\ude4c\udb66\udecd\udb2e\udd4a",
        -1, 71835, 1943535091, -6897365983622509932L, -58888L, false, false, (char) 23267, (char) 25415,
        Double.longBitsToDouble(0x3fdfcc3510810e38L), Double.longBitsToDouble(0x3fc0086efc82f73cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 3, 1, 7, "\ud94f\udd65\ud89b\udc42\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\udbeb\udd3d\udb7e\udc5e\udb24\udc42\udb40\udee5\uda71\ude8e\udb2b\udd55\ud894\udf51", "\uc954\u8f8b\u2f94\uc91c\u8276\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a",
        44, 20724, 1880579944, 4795176153354358101L, 40423L, true, true, (char) 3765, (char) 20183,
        Double.longBitsToDouble(0x3fe74563940ed7d9L), Double.longBitsToDouble(0x3fe07ff75a97c0caL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 12, 5, 4, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43", "\ucd14\ub4da", "\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365\ud9ab\udf82",
        54, 59605, 133408287, 137608095863133996L, 61770L, false, false, (char) 25574, (char) 41408,
        Double.longBitsToDouble(0x3fdf368fe45ee7aeL), Double.longBitsToDouble(0x3fe4a5023aac8451L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 14, 7, 17, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\ud839\udf02\ud903\udfce\u7299\udb23\udc00", "\uc954\u8fe9\u6519\uc91c\u8476\u4996\u448a\u8a09", "\u7d0b\ud900\udc0f\udb69\udf33\ud82b\uddb1\ud9bc\udf47\ud811\ude03\udbd1\udf39\u787a\uda11\udc7b\ud907\udee9\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        49, 16697, 1183391816, -5938089328053252215L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 5, 1, 16, "\uda9b\udd6b\ud99f\udd25", "\u646d\u6d93\u6698", "\udabc\udd8f\u4bc4",
        11, 89099, -601616607, 8118504190688511663L, -94298L, false, false, (char) 44212, (char) 39816,
        Double.longBitsToDouble(0x3f9dbe3ac3ec5cc0L), Double.longBitsToDouble(0x3fdd607f3e5803d0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 3, 8, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udaff\udcd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udbb9\ude49\udb15\udc88", "\uc954\u8f8b\u5c19", "\udba9\udc1f\ud895\ude4c",
        27, 92010, -1427796818, 7565755846430760435L, 77516L, false, true, (char) 57846, (char) 21349,
        Double.longBitsToDouble(0x3fd55428b01e7038L), Double.longBitsToDouble(0x3fdfcc3510810e38L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 16, 1, 4, "\ud94f\udd65", "\u9ef6\u0ba5\u6e4c\ucc8e\ucd14\ub4da\ub686\u5d61\u9143\uafc9\ua656", "\ud951\udddd\udb45\udc65\u3365",
        30, 86229, 1659248925, 572984229712421334L, -67347L, true, true, (char) 47278, (char) 61211,
        Double.longBitsToDouble(0x3fe0d18854aed7f3L), Double.longBitsToDouble(0x3fe6dd572df368feL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 2, 10, "\ud927\udfcc\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43", "\u7442\ub4da\ub686\u5d61\u9143\uc3c9\ua656\u9f61\u9b6f\u14ba\uabea\u5e82\ucaa8\u6e59", "\udb32\uddf2\udad4\udc1b\uda56\udeae\udba9\udc1f\ud895\ude4c\ud800\uddbb\ud9fa\udd78\ud9b4\udc63\u14ff\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47",
        4, 1526, 941378901, -4372467410199071236L, -62409L, true, true, (char) 37269, (char) 55102,
        Double.longBitsToDouble(0x3fe6397cff89ad80L), Double.longBitsToDouble(0x3fe745fece1084d9L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 3, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\ud94e\udebc\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb5f\ude9c\udbd9\udeda\ud951\udda8\udb71\udc6c\uda78\udea4", "\u9654\u8f8b\u5c19\uc91c\u09cc\u490c\u4df4\u0ec7", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\ud807\udc48\ud811\ude03\udba1\udedd\ud9f2\udcba\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\ud94d\udf24\u6555\uda45\udc52\ud9fd\udd63",
        49, 16697, 304963465, -6685366195253216937L, -30206L, true, false, (char) 52013, (char) 42105,
        Double.longBitsToDouble(0x3fc9d84358086e48L), Double.longBitsToDouble(0x3fddd49c46e1cb30L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 6, 1, 7, "\ud94f\udd65\uda9f\udc4d\ud92e\udfaf\udb2c\udc72\ud81f\ude94\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb55\udce5\ud951\udddd\udb45\udc65\u3365", "\uc954\u8f8b\u2f05\uc923\u8476\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\ud9e7\udd26\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud99f\udc33",
        22, 16611, 304963465, -5944524056646054007L, -43694L, false, false, (char) 50017, (char) 37001,
        Double.longBitsToDouble(0x3fdd61845d1f7962L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda19\udccf", "\ub4da\ub686\u5d61\u9143\u556a", "\udb40\udee5\u15d1\udb6e\udca6\u3365\ud9ab\udf82\udaf6\udc6c\ud81a\uddf1\udbd9\ude96\udb32\uddf2\udb42\udf11\udba3\udc3e\udba8\udfd8\ud895\ude4c\udb66\udecd\udafe\udfb2\ud81b\udfaa\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a",
        36, 90863, 1116463950, 4043191591921377295L, -79584L, false, false, (char) 47656, (char) 30446,
        Double.longBitsToDouble(0x3fec576d5ad70d4bL), Double.longBitsToDouble(0x3fe93d1c03d9098aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=java.lang.Integer:1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 15, 15, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34", "\ub686\u5d7e\u9143\uafc9\ua656\u9f61\u70ea\u8d14\u088d\u5e82\ucaa8\u6e59\uc954\u8f8b\u5c19\uc91c\u8476\u4996\ud629\u8a09\u0f9a\u77d0", "\uda98\udfbf\udaf1\ude0c\ud9bc\udf47",
        4, 8950, 941378901, -4372467410199071236L, -4646L, false, true, (char) 40993, (char) 58023,
        Double.longBitsToDouble(0x3fe395e451b595bcL), Double.longBitsToDouble(0x3fdf937e1f135b00L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 17, 0, "\ud94f\udd65\udbfc\udefd\ud814\udcde\uda09\udc74\udb91\ude1a\uda20\ude17\uda8a\udd34\ud856\udc8a\ud89e\uddcd\ud895\udd1a\ud8c2\udd49\ud829\udd1f\ud9b6\ude0f\ud979\udff0\udb24\udc42\uda47\udcc8\ud976\udd80\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\uc91c\u8476\u4996\u448a\u8a09", "\udafa\udedf\udb6c\udea8\ud9f1\udc0d\ufb4a\ud9bc\udf47\ud811\ude03\ud812\udffa\ud9f2\udca3\ud9ee\uddb8\ud8ad\udedc\udb61\udc39\udb80\udd15\uda48\udeef\udae5\udc11\uda22\udd61\ud9fd\udd63\udbaf\udfb6\ud893\uddb9\ud892\udca5\ud97a\ude01\ud9f6\udea2\ud8dd\udc8a\udaa8\udffd\ud967\udc4e\ud9a6\udf4a\ud9b8\udd17\uda73\udfac\uda62\ude67\udb05\ude70\uda4f\udc78\udbf9\udfa6\ud8a1\udfc5\udb45\udfe3\ud812\udde0\ud8a6\udd94\udbb9\uddb6\ud8b8\udf27\ud8ed\uddda\udb54\ude85\ud994\ude44\udbe6\udf0a\ud86c\udf5c\udb68\udcd9\ud88d\ude96\uda4e\udeb8\ud8f9\udc53\ud8a3\udfac\udadf\ude11\ud883\ude9b\udbb9\udf98\ud9fc\udca0",
        50, 48882, -1362856688, -2108433819402840371L, -24563L, false, false, (char) 32998, (char) 25032,
        Double.longBitsToDouble(0x3fc3f121353d1ea0L), Double.longBitsToDouble(0x3fe5abd30e17b6ecL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 14, 9, "\ud92a\udda4\uda9f\udc4d\udb70\udccf", "\u2516\u5c4f\u88a3\u4a64", "\ud829\udc33\ud9b6\ude0f",
        24, 69076, 1199720111, 6351795569805760230L, -5412L, true, false, (char) 34903, (char) 2309,
        Double.longBitsToDouble(0x3fdd607f325c03d0L), Double.longBitsToDouble(0x3fa239e3f83de440L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 4, 12, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\udb85\udf3b\uda70\udd6a\uda20\ude17\uda8a\udd34\udb7d\udfad\ud935\udfe4\ud8b7\udd96\udad4\ude8c\ud829\udc33\ud9b6\ude0f\udb07\udc76\uc957\udb40\ude77\ud959\udedd\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\uc90f\u8476\u4996\u848a\u8a09", "\u7d0b\udb38\udc0b\udb7b\uddbf\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud856\udc36\uda11\udc7b\ud88f\ude19\ud88c\udff0\ud990\ude5f\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        49, 20865, 304963337, -5944524056646054007L, -48585L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 16, 1, 7, "\ud94f\udd65", "\u0a07\u2af5\u075c\u5c4f\ucd14\ub4da\u7779\u5dcf\u9143\u4d77\u1d70", "\ud951\udddd",
        -1, 58794, 1715302780, -4739233432924144611L, -67771L, true, false, (char) 40014, (char) 57455,
        Double.longBitsToDouble(0x3fea350f0fea7731L), Double.longBitsToDouble(0x3fe0d18854a0d738L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 3, 6, "", "\u5d86\u2f54\u2af5\u529e\u9da0\ucd14", "\udad4\ude8c",
        42, 60481, -1841039489, 40737764802560L, -100000L, false, true, (char) 44307, (char) 17034,
        Double.longBitsToDouble(0x3f47c7587d8b9800L), Double.longBitsToDouble(0x3f9be19400000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 14, 2, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud950\udd67\udb91\ude43\ud80e\ude6e\ud9bc\ude18\ud8fc\udc07\uda3a\udd5c\udb00\udfd0\uda87\udd70\udafd\udcb6\ud8dd\udd6e\ud979\udff0\uda72\udf65\udb40\udee5\u58b1\ud8d4\udcd8\uda80\udea7\udb24\udee3\udac7\udcc9\ud81a\uddf1\udbd9\ude96\udb9d\udec7\ud9e2\ude7d\uda4a\uddae\ud823\udfae\ud9a0\udc3b\udb66\udecd\udafe\udfb2\ud81b\udfaa\u7d0b\ud88b\udc4b\ud834\udeea", "\uc9e1\u0a19\u8fd5", "\uda3c\udd7d",
        50, 42173, -1082068621, -4111855073443671551L, -9238L, true, true, (char) 42763, (char) 35849,
        Double.longBitsToDouble(0x3fe74566cc0ed7d9L), Double.longBitsToDouble(0x3f81fdd6a5f03280L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 18, 14, "\uda24\uddc7\ud90c\ude85\uda5c\udfc3\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u12f7\u10f4\ud149\u8476\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\udbc0\udf92\ud884\udc5b\udb46\udd0a\ud8b3\udd10\udae9\udc0e\ud9b4\udf94\ud98f\udcb8\ud955\uddd5",
        28, 16697, -668115063, -5944524056646054007L, -43694L, false, false, (char) 49998, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe20207755e471bL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 7, "\ud94f\udd65\udae0\udf4f\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\u04e3\u36cd\u1986\ud149\u25a6\u65a6\u448a\u8a09", "\u7cd3\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf72\udad4\udd5a\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\ud9b4\udf94\uda45\udc52\ud9fd\udd63\udbaf\udfb6\ud893\uddb9\ud8a7\udd30\ud97a\ude01\ud9f6\udea2\ud8dd\udc8a\udac8\udc59\ud967\udc4e\ud9a6\udf4a\ud9b8\udd17\ud8ee\ude8d",
        19, 75200, 78273886, 8242652215361521606L, -82188L, true, true, (char) 7756, (char) 23547,
        Double.longBitsToDouble(0x3fd9fce41eb4fbd2L), Double.longBitsToDouble(0x3fe203b684db35d7L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 17, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\udbd2\udeba\uda43\udc6d\udb00\udfd0\udb66\uddf5\ud829\udd07\ud9b6\ude0f\udadb\udc80\udb24\udc2a\udb40\udee5\udaf7\uddbe\uda78\udf30\u3328\ud830\udd25\udaf6\udc6c\u3761\udbd9\udee8\udb25\udd2c\udbd8\udc7c", "\ua41a\u6f86\u95c4\u77d0\u1b4c\u365d\u355c\u1ffd", "\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\ud852\udd53\ud9b4\udfdb\uda45\udc52\ud9fd\udd63",
        49, 16697, -668115063, -5872466462608126071L, 96782L, false, false, (char) 9507, (char) 51528,
        Double.longBitsToDouble(0x3fed111a5f8fbcd4L), Double.longBitsToDouble(0x3fe20206e55e471bL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 4, 4, 8, "\ud94f\udcb4\uda9f\udc4d\ud9e7\uddac\ud8b2\udcb1\udb91\ude43\udb61\udf90\ud94e\udd6b\ud879\udf70\ud932\udc53\udb03\ude9b\ud933\udf02\ua794\uda96\udd28\ud979\udf98\udb44\udc94\udb40\udee5\ud951\udddd\udb45\udc65\u3365\uda47\udd90", "\u8f8b\ua3b4\uba26\ud7b9\u49d5\u448a\u8a09\u95c4", "\uda71\udcc6\udb9f\udc8a\ufb4a\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udca4\ud9d5\uddef\ud9ad\uddd1",
        14, 67495, 160055079, -1885807745342546039L, 95945L, true, true, (char) 38865, (char) 60259,
        Double.longBitsToDouble(0x3fe20207755e471bL), Double.longBitsToDouble(0x3fde619f42f9c0c2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=java.lang.Double:0.11282401667464603 |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 4, 14, 10, "\ud9e6\ude2a", "\u9ef6\u0ba5\u559c\u5c90\u10aa\u023f\ub686", "\udb0b\udd28\udbcb\udc23\udb24\udc42",
        51, 32733, -533946554, 4294170568396992892L, 48451L, true, false, (char) 25690, (char) 55571,
        Double.longBitsToDouble(0x3fbce208e5d22aa8L), Double.longBitsToDouble(0x3feea265e0ea7731L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 8, 5, 9, "\udbb1\udd4c\uda08\udd38\ud83c\uddfc\ud964\uded3\udb91\ude8a\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udbac\udd99\ud81f\udf13\ud9b6\ude0f\ud91f\ude02\ud8b9\udf37\udb40\udee5\ud951\udddd\udb45\udc65\u3365\ud9ab\udf82\udade\udd31\ud8ff\udc82\u22f9\udb71\udd04\udad4\udc1b", "\u448a\u2184\u95c4\u77d0\u1b4c\u5f3e\u38bc\u1ffd", "\udbd1\udf39\ud9f2\udca3\ud90a\udf48\ud898\udfcb\udb54\udc73\udb6f\udd1c\ud9bb\uded6\ud9b4\udf65\uda45\udca5\u11a8",
        24, 45529, 304963442, -2715774076514306423L, -43749L, false, false, (char) 24956, (char) 46001,
        Double.longBitsToDouble(0x3fed111a5e8fbcd4L), Double.longBitsToDouble(0x3fe69a0776ca2b0fL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 3, 12, "\000\000", "", "",
        25, 18030, -827830442, 4779928787221962831L, 10180L, true, false, (char) 33087, (char) 23627,
        Double.longBitsToDouble(0x3fef1701617c3b97L), Double.longBitsToDouble(0x3fb3598f60edf1d0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1 |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 7, 7, 0, "\udbc9\ude3f\uda94\udfa4\udb60\uddd1\ud90f\ude57\udb91\ude43\ud856\udc08\uda63\udd70\udab5\udcd7\ud987\udfaf\ud944\udc1b\uda4a\ude97\uda24\udf95\ud9b6\ude0f\ud90e\udf1b\udb63\udd1f\udbc1\udc86\uda52\udf4e\ud916\ude4b\udb18\udcde", "\uc954\u2418\u6e04\u2886\u841c\u4996\u448a\u8a09", "\u7d0b\uda71\udcc6\udb9f\udc8a\udb80\uddca\ud9d3\udfd4\ud811\ude02\udbd1\udf39\ud9f2\udca3\uda11\udc7b\ud8ad\udedc\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9fd\udd63",
        49, 16697, 304963465, -3465979655488139383L, 95945L, true, true, (char) 40804, (char) 28757,
        Double.longBitsToDouble(0x3fe202077788361bL), Double.longBitsToDouble(0x3fb35c42730c1ee0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 13, 18, "", "\u5d86", "\000",
        -5, -1000, 99438422, 4779726580161667151L, 62469L, false, false, (char) 18710, (char) 46989,
        Double.longBitsToDouble(0x3fd99db68374c1c2L), Double.longBitsToDouble(0x3fc5813434d00d74L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=java.lang.Boolean:false |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 2, 8, 8, 6, "\udab8\udca4\udb26\ude5d\udb75\udebe\ud85d\udcde\udbe3\udc5c\ud84c\uddbd\uda95\udccb\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\udaa4\ude06\ud979\udff0", "\u14ba\ud78d\uc83c", "\uda9e\udf52",
        7, 21382, -2010917076, -7051651361709473357L, 35277L, false, false, (char) 25574, (char) 41408,
        Double.longBitsToDouble(0x3fdf368fe45ee7aeL), Double.longBitsToDouble(0x3fe345023aac842aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 5, 5, "\udb4c\ude97\uda9f\udc0b\ud9bd\udc17\ud842\udd03", "\u6c82\ucd14\ub4da\ub686\u4261", "\uda9a\udfef\udb24\udc42\udb40\udee5\ud951\udddd\udb2e\ude34\udb55\ude30\uda28\udf07\ud804\udd73\uda9e\udf52\udbab\udfc0\udb25\udd8f",
        7, 79306, -1587002957, 8602928277642416237L, 60594L, true, false, (char) 34545, (char) 34018,
        Double.longBitsToDouble(0x3fe08ace9aac842aL), Double.longBitsToDouble(0x3feb4414734e7017L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.DefaultKeyedValues:@?\0121=void |this=org.jfree.data.DefaultKeyedValues:@?\012",
        Z.run(T, 2, 5, 5, 4, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\uda22\udc43", "\u539a\u49ec", "\ud829\udc33\uda03\udf37\ud979\udfa0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\ud941\udcbe\ud9ab\udf82",
        54, 59605, 133408287, 137608095863133996L, -30170L, false, true, (char) 61211, (char) 26404,
        Double.longBitsToDouble(0x3fc5dae71b6eab94L), Double.longBitsToDouble(0x3fdf368fe45ee7aeL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\012",
        Z.run(T, 1, 12, 5, 2, "\uda42\udefe", "", "",
        19, 2601, -678195970, -3555504675023224600L, -61581L, true, false, (char) 26183, (char) 18710,
        Double.longBitsToDouble(0x3fe57b86f1bd4782L), Double.longBitsToDouble(0x3fe232302800002cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 12, 1, 7, "\ud94f\udd65\uda9f\udc4d\udb70\udccf\ud90f\ude57\udb91\ude43\uda20\ude17\uda8a\udd34\ud860\ude9c\uda43\udc6d\ud9ec\udcb6\udac2\udf38\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\udb40\udee5\ud951\udddd\udb45\udc65\u3365", "\uc954\u8f8b\u5c19\uc91c\uc42b\u498b\u448a\u8a09", "\u7d0b\uda71\udcc6\ud9dd\udce9\udada\ude00\ud9bc\udf47\ud811\ude03\udbd1\udf39\ud923\udd3b\udbba\udf8f\ud8ad\ude2e\udb61\udc39\udb80\udd15\u947e\ud9b4\udf65\uda45\udc52\ud9df\udf63",
        49, 16697, 1707833080, 6669546921769111414L, -43694L, false, false, (char) 50017, (char) 47912,
        Double.longBitsToDouble(0x3fed111a5d3455d4L), Double.longBitsToDouble(0x3feb797ade7bb9beL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.jfree.data.DefaultKeyedValues:org.jfree.data.DefaultKeyedValues@1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 7, "\ud97d\udf94\ud977\udfde\udb70\udd39\ud90f\ude57\udb91\ude43\uda22\udd17\uda8a\udd34\ud860\ude9c\uda43\udc6d\udb00\udfd0\udad4\ude8c\ud829\udc33\ud9b6\ude0f\ud979\udff0\udb24\udc42\ud89b\udd32\ud951\udd4f\uda14\ude1f\ud8ad\udef7", "\u7292\u5972\u57df\uc91c\u313f\u530c\u448a\u8a09\u9003\u77b5\u2aa6\u5f3e\u38bc\u1ffd\u55fe\ucc41\uc914\u8cd9\ub823\u79b4\u7036\u68b8\uaf41\u4ec0\u2b4c\ud535\u7a75\ua577\u7f4b\u413e\u2d73\u3e08\u70ba\u651d\u8fcb\u80d7\ua405\u9b83\uce86\u87b6\u0493\u3d17\ubba5\u4ae0\u76c9\uc7e9\ucf21\u21bf\u4a48\u01ef\u6e3e\u5cf0\u66e4\u4700\u48c7\u5910\u57a4\u4268\ub22b\u0a83\u5327\u5a99\u4f3e\u495c\u9647\ub32e\u45d3\u6b87\u52cb\u52ac\ub336\ucde2\u74c7\u6db6\u7a21\ua8e6", "\ud950\udec3\udbb9\udf21\udb46\udd7e\uda7d\udf2b\uda0e\udecf\ud819\udfd6\ud8ea\ude5c\udb2a\udf71\ud8ee\udfb4\udb85\uddcb\udaac\udfbb\ud845\udfb7\ud809\udda3\u864c\udba0\udd68\ud9ba\udca1\udb86\udf2a\ud934\ude95\u41c7\uda1f\udf20\ud925\udd14\uda63\udc22\udb0e\ude9a\udbba\udfc6\udb0f\udfb0\ud9f2\ude62\ud8c3\ude63\ud99c\udf59\ud90b\udd15\udaca\udf02\uda08\udc77\ud9bf\udf30\ud89a\udd2f\udb24\ude71\uda25\udd3d\udb02\udddb\udb51\udd62",
        17, 73679, 45280235, 567508475081725962L, -82814L, false, false, (char) 64362, (char) 8943,
        Double.longBitsToDouble(0x3fc005951c8f4450L), Double.longBitsToDouble(0x3fe588af3429cff4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.DefaultKeyedValues|removeValue|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|removeValue|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|int|new:org.jfree.data.DefaultKeyedValues2D:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues2D:",
    "M|org.jfree.data.DefaultKeyedValues|addValue|java.lang.Comparable,double|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|addValue|java.lang.Comparable,java.lang.Number|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|clear||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|clone||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|equals|java.lang.Object|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getIndex|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getItemCount||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getKey|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getKeys||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getValue|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|getValue|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|hashCode||new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|removeValue|int|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues|removeValue|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|int|new:org.jfree.data.DefaultKeyedValues2D:",
    "M|org.jfree.data.DefaultKeyedValues2D|removeColumn|java.lang.Comparable|new:org.jfree.data.DefaultKeyedValues2D:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
