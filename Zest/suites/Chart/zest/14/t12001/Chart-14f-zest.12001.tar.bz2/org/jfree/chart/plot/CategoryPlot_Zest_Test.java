package org.jfree.chart.plot;
import org.junit.Test;
import static org.junit.Assert.*;
public class CategoryPlot_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\u01e7\ud97e\ude76\ud91f\udd83", "\u23b0\ubfe2\u158d\u5470\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\uda8e\ude59\udb6b\ude0b\ud929\udce2\udb51\udd2e\udb2b\udc1f\ud85e\udee1\udb1b\udc99\ud826\udd88",
        8, 50786, 234968195, -7057962490745663108L, 90265L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fb3073bcf9de6f8L), Double.longBitsToDouble(0x3fecadb78a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\u01e7\ud97e\ude76\ud91f\udd83", "\u23b0\ubfe2\u158d\u5470\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\uda8e\ude59\udb6b\ude0b\ud929\udce2\udb51\udd2e\udb2b\udc1f\ud85e\udf57\udb1b\udc99\ud826\udd88",
        8, 36450, -821784957, -7057808799635943044L, 90265L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fb3073bcf9de6f8L), Double.longBitsToDouble(0x3fecadb78a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 21, 6, 2, "\u01fe\ud97e\ude76\ud91f\udd83", "\u0794\ubf8b\u158d\u5470\u804d\u0843\u6294\ud3a8\ud527", "\ud998\udc6b\ud8f6\udc0d\uda2e\udcbd\u48fe\udba9\ude7a\uda50\udc5c\ud81a\udc7d\udb1b\udc99\ud826\udd88\ud842\ude5d\ud932\ude23\ud8fd\udd56\ud8f9\udebc",
        -3, 42279, 303198474, 4715336692914881243L, 96684L, true, true, (char) 53894, (char) 22981,
        Double.longBitsToDouble(0x3fece5a84078b7d1L), Double.longBitsToDouble(0x3fc3e13c45274e3cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 14, 10, "\u01e7\ud97e\ude76\ud91f\udd83", "\u23b0\ubfe2\u158d\u5470\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\uda8e\ude59\udb6b\ude0b\ud929\udce2\udb51\udd2e\udb2b\udc1f\ud85e\udee1\udb1b\udc99\ud826\udd88",
        8, 50786, 234968195, -7057962490745663108L, 90265L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fb3073bcf9de6f8L), Double.longBitsToDouble(0x3fecadb78a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 16, 24, 26, "\u81c3\ud97e\ude76\ud91f\udd83", "\u23b0\ud07a\u1622\u5470\u804d\u0843\u6294\ub8e1\ud5c0", "\uda63\udfb2\uda8e\uddf3\udb6b\ude0b\uda1f\udcde\uda04\udc78\udb18\udc1f\ud85e\udee1\udb1b\udc99\udb26\udd29",
        8, 50786, 234968195, -7057962490745663108L, 90265L, false, true, (char) 50250, (char) 24608,
        Double.longBitsToDouble(0x3fb307238f9de6f8L), Double.longBitsToDouble(0x3fecadb78a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\ud987\udd6f\ud9eb\uddee\uda94\ude4c", "\u160c\uc9e2\uac96", "\uda42\ude33\ud899\udf22\ud868\udcc4\udad7\udf0e\udb54\ude24\ud8ad\ude72\ud82d\udd37\uda8e\ude59\udb6b\ude0b\ud929\udce2\udb51\udd2e\udb2b\udc1f",
        -3, 60172, 1196682580, 248931809524052874L, -29214L, false, true, (char) 28153, (char) 57119,
        Double.longBitsToDouble(0x3fde8ce3d5b682e0L), Double.longBitsToDouble(0x3feec20c704c1cefL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 7, 9, "\u01e7\ud96d\udcf0", "\ua0f3\u23b0", "\udb79\udf18\ud815\udd8e\uda19\udc16\ud899\udf22\ud868\udcc4\udad7\udf0e\udb7d\ude24\ud8ad\ude72\ud998\udc6b\uda8e\ude59\ud97f\ude6c\ud8c7\udc80",
        9, 11666, 1570393437, 248262597102792063L, 27882L, true, false, (char) 8835, (char) 28567,
        Double.longBitsToDouble(0x3fcceca2431f1960L), Double.longBitsToDouble(0x3fde8ce3dd436d86L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\u01e7\ud97e\udeea\udb27\udca7", "\uc1fc\ubfe2\u158d\u5470\uba61\u08a6\u6294\ucaa9\ud527\u804c\ua4b0\u2bd7\u1031\u63b9\u5cdf\u6896\u40d9\u3c4d\u46ac\ud542\u2641\u1041\u4d1c\u086b\u0147\u5491\ua5cc\u8b76", "\ud8d7\udc57\udb47\udda4\ud99e\udd39\ud956\udc51\ud85f\uddae",
        52, 16231, 536511529, 819942095111691801L, -20135L, true, false, (char) 39377, (char) 19043,
        Double.longBitsToDouble(0x3fe0bf79749b52adL), Double.longBitsToDouble(0x3fe54959eedc3516L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "", "\u1a0f\u91f9\000\u23b0\ubfe2\u158d\u5470", "\ud899\udf22",
        -4, 8312, -1100005886, 8588777271355075598L, 66824L, true, true, (char) 50919, (char) 29189,
        Double.longBitsToDouble(0x3fd5deee2708bb34L), Double.longBitsToDouble(0x3fd5412694528ea6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\u01e7", "\u91f9\ua0f3", "\u0550\udb79\udf18\ud815\udd8e\uda19\udc16\ud899\udf22\ud868\udcc4\udad7\udf0e\udb54\ude24\ud8ad\ude72\ud998\udc6b\uda8e\ude59\udb6b\udd63\ud9ee\udfa5\udb24\udf92\udb2b\udc1f\ud827\udd66\udaec\udd15\ud826\udd88\ud842\ude5d\uda94\ude14\ud817\udc83\ud8f9\udebc\udb5f\udf70\ud877\udd81\ud8e9\uddd8\ud8bc\uddc3\u6eb8\ud9ef\udd8cL\udb22\udfb1\ud992\udd39",
        26, 3178, -257538893, -2988464212803101658L, 41829L, false, false, (char) 43216, (char) 19596,
        Double.longBitsToDouble(0x3fe6abc371d4c176L), Double.longBitsToDouble(0x3fdc529b20096cc6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\ud835\udd21\ud8b2\udf2f\uda39\uddb0\udb33\uddea\ud950\udc5a\ucfab\u885a\u0550\udb79\udf18", "\uad8b\u7277\u21b7\u5b98\ua508\u2bd7", "\ud929\udce2\ud9ed\udc28\udb2b\udc1f\udb8b\udd89\uda27\udc6d\ud826\uddde\ud842\ude5d\udada\udc88\uda4e\udd58\udac2\udd66\ud928\udcf5\udb00\udcea\ud854\udc6a\ud8bc\uddc3\u6eb8\ud9ef\udd8c\ud91b\udd14\udb5c\udfb8\ud992\udd39\udae2\udf98\uda88\udeb2\uda21\ude9d\udbbb\uddac\ud899\udd76\udaa3\ude7a\uda19\ude0e",
        42, 33200, 445176386, -2881579580069706958L, -23254L, false, false, (char) 38498, (char) 2757,
        Double.longBitsToDouble(0x3fe4602b1ad4712bL), Double.longBitsToDouble(0x3fe3fe6c3520a4a7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 7, 9, "\u01e7\ud97e\ude76\ud91f\udd83", "\u23b0\ubfe2\u158d\u5470\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\uda8e\ude59\udb6b\ude0b\ud929\udce2\udb51\udd2e\ud9d9\udd97\ud85e\udf18\udb1b\udc99\uda7d\udf70",
        29, 11486, -277169866, -7057962492658265732L, 90265L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fb3073bcf9de6f8L), Double.longBitsToDouble(0x3fecadb78a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 16, 17, 10, "\uda32\udd03\udb08\udf8c\ud91f\udcbd\udb33\uddc5\udafc\uded6\ud9ef\ude5c\u885a\u0550\ud8e0\udc8b\ud813\udc3b\uda19\udc16\uda5c\ude23\ud868\udc5e\udad7\udf0e\ud9f2\udedb\ud926\udef0\ud998\udca2\uda8e\ude59\udb6b\ude0b\ud929\udce2\udb51\udd2e\udb2b\udc1f\ud85e\udee1\udb1b\udc99\ud826\udd88\u8e2f\ud91c\udc53\ud934\uded1\ud96f\udf8b\udb5f\udf70\ud877\udd81\ud8e9\uddd8\ud8bc\uddc3\u6eb8\ud9ef\udd8c\ud8d7\udc57\udbd7\udda3\udb18\udf9d", "\u1a9f\ua73a\uaa0c\ud4d0\u0848\ucc06\ube7e\u576a\ua8bd\u97c4\u6a90\u5c71\ud4de\u1cb2\ub0bf", "\uda58\udf34\udaf8\uddb5",
        -5, 31029, 2135690579, 7798514692321015949L, -28177L, true, true, (char) 58714, (char) 38903,
        Double.longBitsToDouble(0x3fee169b0cae2f07L), Double.longBitsToDouble(0x3fc3cd10ae0946ccL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 20, 7, 10, "\u01e7\ud97e\ude76\uda76\ude6d", "\u23b0\ubfe2\u158d\u5470\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\ud892\udd90\ud9d4\udfbe\ud929\udce2\udb51\udd2e\udb2b\udc1f\uda31\udd0b\uda17\udceb\ue46d",
        8, 50786, 234968195, -7057962494429994771L, 90265L, false, true, (char) 50250, (char) 4454,
        Double.longBitsToDouble(0x3fe0cae8a30bd8ffL), Double.longBitsToDouble(0x3fd9599eb40ebf7cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 29, 27, "\u01e7\ud97e\ude76\ud990\udec3\udbd8\ude6b\udb51\udcb0", "\u158d\u3f6f\u7009\u31c3\u994a", "\udb54\ude24\ud8ad\ude9c\ud967\udee4\uda8e\uddb1\udb6b\ude0b\ud929\udce2\udb00\udc2e\uda7c\udd08\u26f0",
        32, 30612, 57959072, 8068747981676958851L, -22556L, true, false, (char) 4528, (char) 56357,
        Double.longBitsToDouble(0x3fe6da0b83ff418bL), Double.longBitsToDouble(0x3fbd883bf105def8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 22, 7, 10, "\udb25\udc84\ud8eb\udfe2\udb45\udc29\u12c2\udafc\ude85\udbd7\udede\ud9be\udc04\uda62\ude7f\udb00\ude94\ud815\udd8e\uda19\udc16\ud899\udf22\ud85e\ude41", "\ud5ca\u432a\u61d8\uac2c\u5cdf\u49a6\u4174\u0db9\ua156\ua732\u16f8", "\ud8fd\udead\ud9b5\udcbb\ud8b7\udc38\ud9c5\udf08\ud8bc\uddc3\u6eb8\ud9ef\udd8c\ud8d7\udceb\udb47\udda4\ud816\udcfc\udad3\udfb6\uda5b\udc31\ud8b1\ude65\u0106\ud9dd\udc61\uda6f\ude19\ud81e\udf1c\udb7e\udfe0\ud844\udeb9\udaa5\uddb8\uda70\udc1a\udb01\udd3f\udbd8\ude9c\ud967\ude8a\ud987\ude8e\ud95f\udd8c\ud866\udd87\ud8de\udee9\ud9b5\uddf9\ud81d\udf99\udaa3\udc60\udbba\udd49\ud86d\udf39\uda85\udeaa\uda91\udc8a\ud828\udd3b\udadc\udf3b\udb31\udf5f\ud8e0\udeaa\udbcd\udd55\ud93d\udfbd\u3450\udb84\ude3c\udb77\udc64\ud821\udea6\ud93c\ude75\udbff\ude7f\udac0\udde0\udb97\udc73",
        42, 7421, -1978087003, 7531349452833158482L, -88936L, false, false, (char) 15707, (char) 9002,
        Double.longBitsToDouble(0x3fc2ceaf3258fb40L), Double.longBitsToDouble(0x3fdc9e4a99aeb7e0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 26, 16, 7, "\ud883\ude68\ud9a2\ude71\ud977\ude03", "\u7ca5\ubfe2\u6e58\ucc24\u804d\u0843\ua63e\u0b07\ud534", "\ud998\udc6b\udaf9\udfdc\udbc8\udfea\ud929\udc8e\udb51\udd2e\udb2b\udc1f\ud85e\udee1\udb1b\udc99\ud826\udd88",
        8, 75402, 1619721594, 7571376806430138658L, 37435L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fb30718b225e6f8L), Double.longBitsToDouble(0x3fe3116f74f0cb30L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 7, 10, "\u01e7\ud97e\ude76\ud91f\udd83", "\u23b0\ubfe2\u426e\ube9e\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\udbe2\udda0\uda04\udfc7\ud954\udec3\udb44\udc74\udb2b\udc1f\ud85e\udee1\udb1b\udc99\ud826\udd88",
        8, 50786, 234968195, -7057962490745663108L, 90265L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fb3073bcf9de6f8L), Double.longBitsToDouble(0x3fecaa5f8a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 21, "\u01e7\ud97e\ude76\ud91f\udd83", "\u23b0\ubfe2\u2b35\u5375\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b",
        40, 93504, 357340065, -5412287043883320030L, -99868L, false, false, (char) 0, (char) 62345,
        Double.longBitsToDouble(0x3fc06dff32083804L), Double.longBitsToDouble(0x3fd7c9e0d1ceca00L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 9, 26, 10, "\u01e7\ud97e\ude76\ud91f\udd83\udb33\uddc5\udafc\uded6\ud9ef\ude5c\u885a\udabb\udfcd\udb62\udf53\ud815\udd8e\ud9d7\udd0c", "\ud590\u6001\u2c21\u2bd7\u1031\u63b9\u5cdf\ucc57\u40d9\u494d\u51ea\ucf36", "\udbe8\udefc\ud8f9\udebc\udb5f\udf70\ud800\udec4\ud86f\udc4c\ud8bc\uddbf\u6eb8\ud9ef\udd8c\udac9\udc4f\udb47\udda4\ud992\udd39\ud94a\udd6b\ud905\udc82\uda0e\uddee\uda4a\udf74\ud99b\udf4d\uda9b\ude3e\uda56\udeb3\udbf3\udf69",
        27, 61268, -921931051, 3233605266709877142L, -45240L, false, false, (char) 23464, (char) 22416,
        Double.longBitsToDouble(0x3fe246ca15d0a46eL), Double.longBitsToDouble(0x3fec02f99fbd03a6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 7, 10, "\ud939\udd5d\udb2f\udd1e\ud89e\udcae", "\u3b70\u76ca\u9539\ud3a7\ud071\u0843\u6294\u75ab\ub6b5", "\ud998\udc6b\ud873\udfcd\udb6b\ude16\ud92d\udf09\ud8f3\uddc1\udb19\udf7d\uda4e\udcfa\udba5\udd64\uda9c\udd76\ud9fd\udf66\ud980\udffb",
        13, 75559, 1695732092, 3483544099166689304L, 38133L, true, false, (char) 5726, (char) 11800,
        Double.longBitsToDouble(0x3fc7190c5da21678L), Double.longBitsToDouble(0x3fe0a80655ce8748L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 22, 10, "\u01e7\ud97e\ude76\ud91f\udd83", "\u23b0\ubfe2\u158d\u5470\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\ud984\udd55\udb6b\udda8\ud929\udce2\udb51\udd2e\udb2b\udc1f\ud85e\udee1\udb1b\udc99\ud826\udd88",
        8, 50786, 234968195, -7057962490745663108L, 90265L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fe4a16f79fa9eb1L), Double.longBitsToDouble(0x3fecadb78a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 7, 10, "\u01e7\ud97e\ude76\ud91f\udd83", "\u65aa\u272f\u1634\u5470\u804d\u0843\u6294\ucaa9\ud527", "\ud998\udc6b\uda8e\ude59\udb6b\ude0b\ud929\udce2\uda47\udfe8\udaef\udc60\u62b4\udb1b\udc99\ud826\udd88",
        8, 50786, 234968195, -7057962490745663108L, 64571L, false, true, (char) 7483, (char) 20178,
        Double.longBitsToDouble(0x3fecadb78a075fbeL), Double.longBitsToDouble(0x3fd5cec7d3b92080L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 16, 25, 10, "\u01e7\ud97e\ude76\ud91f\udd83\udb33\uddc5\udafc\uded6\ud9ef\ude5c", "\u5470\u804d\u0843\u6294\ucaa9\ud527\u804c\ua4b0\u2bd7\u1031\u63b9\u5cdf", "\ud85e\udee1\udb1b\udc99\ud826\udd88",
        8, 50786, 234968195, -7057962490745663108L, 90265L, false, true, (char) 50250, (char) 21862,
        Double.longBitsToDouble(0x3fb3073bcf9de6f8L), Double.longBitsToDouble(0x3fecadb78af85fbeL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 2, 18, 4, "\ud8de\udeb8\ud97e\ude76\ud91f\udd83", "\u23b0\ua7df\u158d\u5470\u1215\u31f1\ub7db\ucaa9\ud527", "\ud998\udc6b\uda8e\ude59\udb6b\ude0b\ud929\udce2\ud96d\ude3b\udb2b\udc1f\ud85e\udf7d\udb1b\udc99\ud826\udd88",
        8, 50786, 234968195, -3711728015989616260L, 66389L, false, true, (char) 50250, (char) 2662,
        Double.longBitsToDouble(0x3fe740be610d6351L), Double.longBitsToDouble(0x3fecadb78a075fbeL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 9, 9, 10, "\u01e7\ud861\udeaa\u9696", "\u23b0\uc912\u158d", "\uc98e\ud899\udf22\ud868\udcc4",
        -3, 85114, 1999730540, 5337165839393564868L, -62207L, false, true, (char) 29189, (char) 15424,
        Double.longBitsToDouble(0x3fec22ecd5541269L), Double.longBitsToDouble(0x3fe14a3a9b8a0374L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 29, 24, "\u01f8\ud97e\ude76\ud91f\udd83\udb33\uddc5\ud9b3\udc71\ud99d\udeff\u87fc\u0550\udb79\udf18\ud815\udd8e\uda19\udc16\ud899\udf22\ud868\udcc4\udad7\udf0e\udb7f\udc40\ud8ad\ude72\udb1f\ude15\ud864\udee5\udbed\ude7d", "\u3849\uaba6\u0295\u9ccc\u2641", "\ud8f9\udebc\udb5f\udf70\ud8ad\ude16\ud89f\ude8e\udade\udcfb\udbdb\udc17\udbdf\udd8c\udb0e\ude9f\ud8fb\udf2e\udb1b\udc17\ud967\udf12\udade\udf31\ue417\udad3\udf5c\udb1b\uded8\ud841\udf7c\uda1c\udf90\udb4f\udfe7\ud9de\udcbc\ud815\udcc3\udae7\udfda\ud819\ude92\ud927\udfb0\ud8eb\udf5b\udb81\udc78\uda42\udd7e\ud8d4\udc88\ud9c9\udc20\ud935\udcaa\ud85b\udcd6\ud852\udc35\ud992\udf2a\udab4\udd26\uda81\udcfe\udac3\ude51\ud94b\ude06\udaf0\udf00\uda17\udcaa\uda88\udeb7\uda3d\udcc4\ud9cb\udf1c\ud846\udded\udaa6\udd5a\ud918\udc64\ud948\udfcd\udb59\udea3\ud81c\ude96\udb4f\udfd1\ud903\ude13",
        15, 65055, 19330811, -2810220368574146324L, -76344L, false, true, (char) 44929, (char) 44101,
        Double.longBitsToDouble(0x3fe4be51cd6f91a7L), Double.longBitsToDouble(0x3fec60af7e953963L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\u01e7\ud97e\ude76\ud91f\udd83", "\000", "",
        50, 4935, 538851890, -2850486680388904563L, -50338L, false, true, (char) 58175, (char) 52692,
        Double.longBitsToDouble(0x3fed437ddba1288eL), Double.longBitsToDouble(0x3fd9c154ca4569c6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 9, "\u01e7", "\ud4b7", "\u885a",
        27, 64571, -1984947065, 2314351244274108853L, 66036L, false, false, (char) 52692, (char) 64354,
        Double.longBitsToDouble(0x3fed0944732dfb30L), Double.longBitsToDouble(0x3fdbe8f22abbddc4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 10, 24, 30, "\u0213\ud805\ude7c\uda0f\udd94\udbbd\udc62\ud8de\udf41\uda03\udc76\u885a", "\u4f1f\u224d\ua007\u45b9\u3cd0\uabac\u1235\uc770\u772a\u7bb8\u7973\ua687\u11f4\u44b0\ua156\ua9dd\ub5c5\ua196\ub268\u9915\u0147\u8d75\ua5cc\u8b76\u9a45\uccf3\u3afc\ub081\ubcb7\u5911\u0d46\u393c\ube58\u8488\uc407\u68e2\u58ac\u531b\u6325\u5360", "\u4e18\udbfe\udc8d\ud8f0\udcd2\ud855\ude22\ud9dd\ude85\ud819\udfec\udaee\uddb4\ud901\udebe\udb2c\udd4a\ud954\udc8b\udb31\udd4e\ud829\udc7e\ud869\udf48\u64b0\udb26\udc83\uda63\ude75\ud9a0\udfe9\udac2\udc17\udabe\udd69\ud9d5\uddb7\ud9fd\udf15\ud889\udebb\uda34\udc75\udb74\udfa8\udb56\udd09\ud9f4\ude86\udbdf\udd89\udb4d\udef3\ud9e7\uddb2\udb54\udcc6\udb60\udded\uda1f\udff0\ud9ef\udc29\ud96b\uddb5\ud954\udd8f\ud821\udca0\udbb3\ude28\udb80\udcb1\uda3c\udc59\u517e\uda28\udc05\uda74\udf9e\ud862\udc6c\ud80f\uddd2\udbf8\ude0a\ud821\udd66\uc51c\u3edc\ud88c\udfcd",
        -2, 11210, 390231163, 3965059154345750473L, 76341L, true, false, (char) 59760, (char) 54542,
        Double.longBitsToDouble(0x3fd8c44eab7350e8L), Double.longBitsToDouble(0x3fc8ae74942d5ac8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 27, 27, 19, "\udab7\udde1\ud85a\ude06\ud962\udde4", "\u25af\u7e93\u752f\u47ea\u5681\u3976\u1b41\u3d2a\u2958\u188e\u0883", "\udb6b\ude0b\ud929\udce2\udb51\udd2e\udb17\udc34\ud8a9\ude1f",
        16, 79276, -894843369, 8068747979446304899L, -84256L, true, true, (char) 57119, (char) 30245,
        Double.longBitsToDouble(0x3fe6da0b9bd8418eL), Double.longBitsToDouble(0x3fea60e77db2bcdfL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 21, 0, 0, "\u01fe", "\u16cf\000", "",
        39, 64571, -1984947065, 63985751687168L, 96608L, false, false, (char) 13920, (char) 30513,
        Double.longBitsToDouble(0x3fee2000078e48bbL), Double.longBitsToDouble(0x3fdbe8c5f746f60cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 17, 25, 4, "\ud88f\udfe3\udaac\uddc8\ud9ec\udcc8", "\u0794\ubf8b\u158d\u5470\u804d\u0843\u6294\u34d8\ua0c1", "\ud998\udc6b\ud8f6\udc0d\uda2e\udcbd\u48fe\ud829\uded7\udb8d\udf35\uda97\uded5\ud864\udff9\udb6b\udd07\uda7a\ude0d\udb64\uddf4\ud8fd\udd56\ud972\udfca",
        -5, 55684, 361618089, 9141863454287005674L, 46330L, false, true, (char) 31584, (char) 25531,
        Double.longBitsToDouble(0x3fece1b52878b7d1L), Double.longBitsToDouble(0x3fc3e13c45274e3cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 2, 0, 0, 24, "", "", "\udafc\uded6",
        56, 65094, 0, 1365424093447330951L, -32160L, false, false, (char) 59647, (char) 203,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fee22508ba86fbbL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\012",
        Z.run(T, 1, 16, 24, 26, "\ud86c\udd02\ud97e\ude76\ud91f\udd83", "\u52e1\ud07a\u1622\u5470\u804d\u0843\u1adf\ub8e1\ud5c0\u804c\ua4b0\u146e\u0fcb\u8613\u3baf\u2b1b\uccd8\u3c4d\ua156\u2191\u2641\u1041\ua6d0\u86d3\u0147\u5491\ua5cc\u8b76\u3d97\ucd69", "\ud992\udd39\ue9c4\ud915\udf29",
        5, 23370, 1095542207, 6255548123283610502L, -5581L, false, true, (char) 32385, (char) 15879,
        Double.longBitsToDouble(0x3fe26b4c1b073e03L), Double.longBitsToDouble(0x3fc8c460a1ad7f74L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\0121=java.lang.Boolean:false |this=org.jfree.chart.plot.XYPlot:@?\012",
        Z.run(T, 2, 10, 26, 2, "\udb93\udeff\ud898\udcf7\udb11\ude22\u12c2\ud9e2\udf95\udaf7\ude3a\udbb3\udf9f\uda62\ude7f\udb36\udfb0\ud8a2\udd2b\uda48\ude13\ud899\udf22\ud85e\ude41\udaa7\udd34\ud9cf\udf56\ud87a\uddfb", "\uac2c\u2635", "\uda2a\ude27\udb1b\udc99\uda77\uddd1",
        15, 62794, 197861725, -7057944963755224708L, 41412L, false, true, (char) 50250, (char) 7081,
        Double.longBitsToDouble(0x3fd8958ebbd35b14L), Double.longBitsToDouble(0x3fd7d1390598b096L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 17, 7, 10, "\u01e7\ud97e\ude76\ud91f\udd83\udb33\uddc5\udafc\uded6\ud9ef\ude82\u885a\u0550\udb79\udf18\ud815\udd8e\uda19\udc16\ud899\udf22\ud868\udcc4\udad7\udf0e\udb54\ude24\ud8ad\ude72\ud87a\ude1d\ud84d\uddbf\udb6b\ude0b\ud929\udce2\udb59\udc2e\udb2b\udc1f\ud85e\udee1\udb1b\udc99\ub788\ud842\ude5d\udbf0\udd2c\ud902\udfcc\ud8f9\udedc\udb5f\udf70\ud877\udd81\ud8e9\uddd8\ud8bc\uddc3\ud807\udf6d\ud9ef\udd8c\ud8d7\udc57\udb47\udda4\ud992\udd39", "\ua467\ucd73\ub10a\ub2c8", "\udbeb\ude6c\ud8cb\udf3d\udb3b\udda8\uda82\udc4a\ud9d5\uddb4\ud871\udd80\udbd7\udcfd\ud8cc\ude32\uda00\udc90\ud87f\udeab\ud8f8\udee3\udbf1\udd2e\uda41\ude71\uda07\udfe5\ud9e3\udf19\ud80c\udce5\ud965\udfc2\ud84f\uddb7\udafe\udf7e\udb72\udc42\ud937\ude70\ud954\udf37\udb50\ude99\ud9c7\ude13\u8967\udb40\udd10\ud935\udd0e\ud8c3\udfd4\ud8b1\udd8b\uda86\ude4b\udaff\udc4f\ud85e\udcaa\ud953\udd42\ud869\udc08\ud952\uddc5\ud9ae\udfa8\uda6c\udd70\u9e8b\udbb8\udce4\ud977\udf32",
        51, 30671, -674643814, -8568448358138164822L, -10957L, true, true, (char) 63722, (char) 17948,
        Double.longBitsToDouble(0x3fefa74586ca4490L), Double.longBitsToDouble(0x3febd14c8018c5b3L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.plot.CategoryPlot:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 10, "\ud987\udd6f\ud9eb\uddee\uda94\ude4c\u769d\udb53\udff8\udbd3\udd9b\udbb1\udc00\ud8af\udfb0\uda82\udc9b\ud9f3\udc3c\ud9c2\ude33\ud899\udee8\ud868\udcc4\udad7\udf0e\udb54\ude24\ud8ad\ude72\ud82d\udd37\uda8e\ude59\udb6b\ude0b\ud929\udce2\udb51\udd2e\ud889\udeaf\ud85e\udee1\udb1b\udc99\ud826\udd88\ud842\ude5d", "\u086b\u0147\u5491\ua5cc\u8b76\u165d\uc5b6\u462b\u905f\u6d24\uaa94\u681d\u5c60\u1434\ucd91\ua9d1\u6f50\u5961\u1a2a\u19f3\u0928\uadd0\u79ea\u72f2\u8406\u8113\ua909\ub3cb\u19f2\u3280\ucfb6\u1c1b\uc761\u3902\u0bc7\ubd54\u734e\uba6d\u188c\u33c6\u4b1c\u139b\u491a\u67d3\u91d1\ubbba\uab42\uc972\u0992", "\uda06\udef8\uda65\udcc6\ud8ec\udc6d\udadf\udcbc\ud819\udcb9\ud920\udfcc\udb59\ude0f\uda59\udd15\uda90\udf3a\uda06\udd1e\ud878\udf43\ud95c\udc11\ud8ce\ude87\ud826\udd06\ud80d\ude1f\uda8d\udcf1\uda75\udca8\u663a\ud9a1\udedd\udb59\udf6e\ud990\udf4f\udbf0\udc16\ud93e\udf08\udbfb\ude9a\ud9c3\udc26\u46f1\udace\uded5\udaa2\udd2b\uda82\udd06\udb1d\ude95\ud954\udd6b\udbe5\ude02\udb49\ude99\uda46\udf54\u58f2\ud843\ude31\udb94\udc05\uda14\ude36\ud861\udd33\ud92e\ude39\udb27\ude01\uda5a\ude2c\ud9b1\udffe\uda70\udeca\u8f51\u485a\ud8d4\udc3e\ud95f\udc60\udbf7\udfd9\uda53\udc71\ud99e\udc03\udbf5\ude09\udba8\udd64\ud813\udcce\ud836\udd0b\udb57\ude73\ud82e\udf74\udb6b\udc01\ud9ec\udcff\udb18\udcea\ud87f\udf77\udb68\udf49\ud949\ude7e\udadc\udd46\ud8d2\udcf6\udbea\udeed\udad4\udfde\ud86a\udff5\ud9d3\udd96\uda6f\ude20\udaa7\uddf3\uda4b\udc23\uda8e\udcf2\ud98e\udcf2\uda20\udcf8\uda0f\udc70\udae6\udc2d\ud8a1\udc3c\u5491\udab8\udea3\uda44\udd01\ud963\uddd9\ud965\udeb6",
        23, 96660, -668017709, 6137283331054466444L, 43149L, false, false, (char) 10992, (char) 9561,
        Double.longBitsToDouble(0x3feba8ecaa47db43L), Double.longBitsToDouble(0x3fd3957e1f043a70L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeDomainMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.CategoryPlot|removeRangeMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.CategoryPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeDomainMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|int,org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer,boolean|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|org.jfree.chart.plot.Marker|new:org.jfree.chart.plot.XYPlot:",
    "M|org.jfree.chart.plot.XYPlot|removeRangeMarker|org.jfree.chart.plot.Marker,org.jfree.chart.util.Layer|new:org.jfree.chart.plot.XYPlot:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
