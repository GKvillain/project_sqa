package org.jfree.chart.axis;
import org.junit.Test;
import static org.junit.Assert.*;
public class Axis_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udacd\udf82\udbd3\udf11\udac4\udc1c\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45",
        -2, 96254, -717782636, 2983953533856873943L, 79695L, false, true, (char) 18971, (char) 29821,
        Double.longBitsToDouble(0x3fe39e6865cbfde2L), Double.longBitsToDouble(0x3feb49059d00143aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\uda77\udd51\ud84a\udcd5\udb1a\udf50\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\udaf6\udf64\udb28\udf8c\udbd7\udfae\udacd\udf82\uda53\udfcb\udab3\uddec\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48ad\ud85c\udd5e\ud925\uddd3\ud8d8\udd92\udaa1\udc6d\ud889\uddc0\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45",
        -2, 96254, -717782636, 115136381562483424L, 79695L, false, true, (char) 18971, (char) 29821,
        Double.longBitsToDouble(0x3fe39e6865cbfde2L), Double.longBitsToDouble(0x3feb49059d00143aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\udbf2\udfae\000\udb1a\udede", "\u1c8d\u6abf\uc526\u008c\u4f20\u97a8\u888b\uc5f8\uc2e7\u180d\u2efb\u7d73", "\uab71\udbd2\udfa8\udac4\udc1c\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77",
        14, 74063, -8049090, 3757264546817048461L, -67636L, false, true, (char) 105, (char) 0,
        Double.longBitsToDouble(0x3f2de90000000000L), Double.longBitsToDouble(0x3fe08c535122bc2dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\udaab\udcab\udb93\ude14\ua86d\ud9d7\udccb", "\u6abf", "\u64a7\udbea\udf0e\ud988\udfd4\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04",
        43, 55616, 1852655917, -4806278199449549975L, 36845L, true, true, (char) 10930, (char) 10684,
        Double.longBitsToDouble(0x3fb55b40e005b528L), Double.longBitsToDouble(0x3fef57a99ddefd03L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 0, "\uda77\udd51\uda4d\udff6\udb1a\udede\ud991\udead", "\000\u35ab\u755c\u4f61", "\ud968\udc37\000\udbe9\udd39\udb9e\udc04\ue7ad\udb10\ude87\udbd7\udfae\udacd\udf82\udbd3\udf11\uda15\udcc4\ud859\udc34\000\ud947\udd02\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ub6dd\000\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45",
        52, 462, -721420288, 2983953533856873943L, 96608L, false, false, (char) 52347, (char) 25935,
        Double.longBitsToDouble(0x3fe8d19808000038L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 4, "\u3f9e\uda4d\udff6\ud989\ude39\ud991\udea5\udb41\udecb\udb09\udd3f\ud969\ude33\udb5d\ude82\udb5a\udf5a\u64a7\udbea\udf0e\ud9af\ude68\ud968\udc37\udbc9\udc0b\udbd1\udf7f", "\u14ec\ucc0d\u2c63\ua4f3\u6ddc\u55f3\u6085", "\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\udab1\udefd\udaed\udcf0\udb4b\udedd\uda85\udf45\udb5d\udcbb\ud899\udda1\ud989\udd20\udaeb\udc26\ud97f\udca6\ud9e2\udc3d\udb11\ude80\ud813\udd1e\udb11\ude11\ud8a7\udd20\uda69\ude56\ud8f7\udd54\ud828\ude53\ud93b\udfb8\ud881\udc9a\ud9bc\udf63\udbd3\udd8c",
        12, 51336, -1881844858, -7432316500021276079L, -56052L, false, false, (char) 54973, (char) 53530,
        Double.longBitsToDouble(0x3fd2590d85ec7580L), Double.longBitsToDouble(0x3fd5074a8bda2246L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\udad0\udf1c", "\ud176\u80c9\u1c8d", "\udb5a\udf5a\udb8d\uddc1\udbea\udf0e\ud988\udfd4\ud9ec\udd2e\udbc9\udc0b",
        37, 24387, -1267605587, 3094045547983358253L, -35337L, false, false, (char) 29583, (char) 58745,
        Double.longBitsToDouble(0x3faddade117553b0L), Double.longBitsToDouble(0x3fc7933ec1679e18L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 1, 8, "\uda77\udd51\uda4d\udfc6\u6e72\ud96f\udd96", "\u6abf\u8f7b\u5c5b\u4f61", "\ud968\udc37\udb78\udcc2\udbe9\udd39\udb92\ude04\ud850\udf39\udb21\udc8f\udbd7\udfae\000\udbd2\udfa8\udac4\udc1c\ud994\ude2a\uda50\udf74\udb88\udd40\uda5c\udf13\u90bc\000\ud907\udd62\ud829\ude3a\udbe1\udfbc\ud875\udc99\ud95d\udef2\uda49\ude96\udafd\ude36\000",
        -5, 94792, 33172, 2983953534209195479L, 79695L, false, false, (char) 5914, (char) 29821,
        Double.longBitsToDouble(0x3fe39e6865cbfde2L), Double.longBitsToDouble(0x3feb49059d00143aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\uda77\udd51\ud9a1\udd60\udb3e\udd35\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud968\udc37\udb8b\ude0c\ud9a0\ude35\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\ud9ce\udde1\udbed\udd81\udac4\udc1c\ud859\udcba\uda50\udf30\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\ud8b7\udf66\uda4e\udfcb\ud96c\ude79\uda43\ude12\udafd\ude36\uda85\udf45",
        21, 96254, -717782636, 2983953533856873943L, -94086L, true, true, (char) 40012, (char) 28786,
        Double.longBitsToDouble(0x3fdab2a9fa002874L), Double.longBitsToDouble(0x3fc6709e8b307f14L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\uda50\udfa8\ud920\udf6d\uda73\udf60\udbf9\udec8\udac4\udc1c\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\ud9d5\udfd3\ud93f\udcf0\ud88a\udd03\ud832\udf0c\udbe1\udfbc\ud890\ude77\ud95d\udef2\udace\udd39\udac7\udd2b\uda85\udf28",
        -2, 96254, -717782636, 2983953533856873943L, 79695L, false, true, (char) 18971, (char) 29821,
        Double.longBitsToDouble(0x3fe39e6865cbfde2L), Double.longBitsToDouble(0x3feb49059d00143aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 8, "\ud8f6\ude96\uda4e\udca4\udb1a\udf50\ud991\udead", "\ua81f\uc526\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udacd\udf82\udbd3\udf11\udac4\udc1c\ud848\udc34\udb6c\udeff\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\udbff\ude85\udbdd\uddbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45",
        -2, 96254, -717782636, -372354089548543426L, 51503L, false, false, (char) 52380, (char) 25935,
        Double.longBitsToDouble(0x3fe8d19809457b38L), Double.longBitsToDouble(0x3fef84d06459e7baL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 10, 1, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf", "\u64a7\udbea\udf0e\ud9f0\udd1e\ud968\udc86\udbc9\udc0b\udbe9\udd7f\ud849\udecf",
        6, 55616, 1852655917, -4806278199449549975L, -94939L, false, true, (char) 10930, (char) 10684,
        Double.longBitsToDouble(0x3fbc44e876eadae0L), Double.longBitsToDouble(0x3fef57a99ddefd03L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.Color:java.awt.Color[r=0,g=0,b=0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 15, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\udb57\udc11", "\u6abf\uc526\u8160\u4f61", "\ud968\udc37\ud829\udd75\udbd6\udf17\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udacd\udf82\udbd3\udf11\ud888\udc1e\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud890\udda4\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45",
        -2, 96254, 1362592148, 6730947453166517719L, -49570L, true, true, (char) 9612, (char) 25935,
        Double.longBitsToDouble(0x3fefd99809454d38L), Double.longBitsToDouble(0x3fe39e6865cbfde2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\uc526\u3177\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud9b2\udf32\udb21\udd6c\udbd7\udfae\udacd\udf82\udbd3\udf11\udac4\udc1c\uda93\udfb6\ud806\udc3c\udb82\udd3a\udbef\udcfb\udaa3\ude3a\ud86c\udfc9\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\udde4\udafd\ude36\uda85\udf45",
        -2, 99599, -717782636, 6738063363559622154L, 79695L, false, true, (char) 5525, (char) 29821,
        Double.longBitsToDouble(0x3fe8b4e065a1df04L), Double.longBitsToDouble(0x3feb4901dd00143aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 2, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud968\udc37\uda59\udf80\ud9cc\udc12\udb9d\udfc2\ud850\udf39\udb21\udc8f\udbd7\udfae\udacd\udf82\udbd3\udf11\udac4\udc1c\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45",
        -2, 96254, -717782636, 2983953533856873943L, 79695L, false, true, (char) 18971, (char) 29821,
        Double.longBitsToDouble(0x3fe39e6865cbfde2L), Double.longBitsToDouble(0x3feb49059d00143aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 8, "\uda68\udfc9\ud91d\udc5e\udb1a\udfcb\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud968\udc37\ud836\udd07\udbe9\udd7f\udba6\udc87\ud850\udf39\udb21\udc8f\udbd7\udfae\udbbc\ude80\udb85\ude2b\udac4\udc1c\ud8d1\udcb6\uda50\udf74\udb1b\udeb1\uda67\udf8b\u48d3\udb2c\ude41\ud889\udfb4\ud9f7\udf35\ud900\udf3b\ud8b1\udddf\ud95d\udef2\uda10\udfdc\udaf7\ude60\uda73\udd51",
        -2, 96254, -952663660, 2983953001280929239L, 97881L, false, false, (char) 52347, (char) 25935,
        Double.longBitsToDouble(0x3f88f403ec1bfb80L), Double.longBitsToDouble(0x3fe49e9daca58328L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead\ud9d4\udcc9\ud92e\udf00\ud995\udca4\udaa5\uddba\udb5a\udf5a\u64a7\udbea\udf0e\uda03\udc71\udb99\ude88\uda5e\udc83\ud817\udd23\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udacd\udf82\udbd3\udf11\udac4\udc1c\u3cb6\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\udb34\udd6c", "\u86e5\u8c13\u06df\u7302\u35e9\u839d\u70b5\ua8af\u79ae\u0596\u3924\u484f\u47f1\ucc8c\u7362\ud41c\ubfbd\ua2ff\u0779\u53ae\u76e9", "\u4e2b\ud854\ude3a\uc9b0\ud95d\udf77\uda79\udd0e\udb0a\udc05\ud898\udc7b\uda84\udc12\ud938\udf30\u4f09\ud95a\udfcd\ud86f\udf49\uda2b\udf7c\uda86\udca4\udaa0\ude07\ud968\ude2a\ud863\udfe6\u6bc7\ud8e6\udd47\u3d72\udb04\udc03",
        19, 93349, -1588528878, 8259689283686629256L, 74354L, false, true, (char) 44685, (char) 15918,
        Double.longBitsToDouble(0x3fe14ed53396f8f9L), Double.longBitsToDouble(0x3feb5599deeae081L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\uda77\udd51\uda4d\udff6\000\027", "", "\udb5a\udf5a\u64a7\udbea\udf0e",
        15, 10025, -1327859530, 2722376795388129019L, -100000L, true, true, (char) 19483, (char) 29583,
        Double.longBitsToDouble(0x3f43b490eed6f000L), Double.longBitsToDouble(0x3fd17553b0000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 8, 8, "\udb3b\udf53\ud9d1\udcb1\udb1a\udf50\ud991\udead\ud9d4\udcc9", "\uc526\u75e8\u4f61\u97a8\u888b\uc5f8\uc2e7\u180d\u7afa\u7e20\u14ec\ucc0d\u2c63\u8504", "\uda50\udf74\udb88\udd40\uda07\udd80",
        -4, 67694, 1532786801, -778077250351009814L, 14749L, true, false, (char) 44478, (char) 31673,
        Double.longBitsToDouble(0x3fec69a125b6d032L), Double.longBitsToDouble(0x3fd94fe9f3ddaa6eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 0, "\u93a8\000\000", "\u7439\u6a19\uc526\u75e8\u4f61\u97a8\u888b\uc5f8\uc9b8\000\ubaf5\u7e20", "\udacd\udf82\udbd3\udf11\udac4\udc1c",
        58, 83957, 3927099, 25596092L, -69280L, true, false, (char) 58653, (char) 27362,
        Double.longBitsToDouble(0x3faea703e0071d50L), Double.longBitsToDouble(0x3fe1f3fc0433ff85L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 6, 1, 8, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\uc562\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udacd\udf82\udbd3\udf11\udac4\udc1c\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45",
        -2, 96254, -717782636, 2983953533856873943L, 79695L, false, true, (char) 18971, (char) 29821,
        Double.longBitsToDouble(0x3fe39e6865cbfde2L), Double.longBitsToDouble(0x3feb49059d00143aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 1, 1, 7, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud968\udc37\udbf9\udc38\ud995\udcbe\udbd1\udc90\udaf0\uddd1\udb16\udf6c\ud9b3\udc0b\ud8d3\ude44\ud9fb\udf56\udae3\udf73\ud859\udcba\uda50\udf74\ud862\uded1\uda69\udf32\u48d3\ud85c\udd5e\ud904\udfc3\ud825\udd8d\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\u163b\uda85\udf45",
        -2, 96254, 2038464916, 5800682860513652808L, -94240L, false, false, (char) 52347, (char) 6992,
        Double.longBitsToDouble(0x3fe426fa5a7dbe08L), Double.longBitsToDouble(0x3fe39e6865cbfde2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 14, "\uda77\udd51\uda4d\udff6\u9549\ud991\udead\ud9d4\udcc9\udaba\udc86\ud8c4\ude89\ud9c5\udd6b", "\u77cd\u6fa7\uc5f8\uc2e7\u8bad\u57a4\u70c1\u2e5c\ucbeb\u2c63", "\ud867\udeba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud861\udf5e\ud925\uddd3\udac1\udd47",
        33, 24911, 277489290, -7261122289105685395L, -67636L, false, true, (char) 44693, (char) 14471,
        Double.longBitsToDouble(0x3fe7f1de940cb3d3L), Double.longBitsToDouble(0x3fe08c535122bc2dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 12, 5, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\uc526\u75e8\u4f61", "\ud87e\udd43\udbc8\udf6f\udbe9\udd7f\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\ud841\udfce\ud929\udeeb\udac4\udc1c\ud859\udcba\uda4f\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\udb81\udc3f",
        5, 96254, -717782636, 2983953533856873943L, 79695L, false, true, (char) 18971, (char) 29821,
        Double.longBitsToDouble(0x3fe39e6865cbfde2L), Double.longBitsToDouble(0x3fd5218b3a0029dcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "\uda77\udd51", "\ud176\u80c9\u1c8d", "\udb5a\udf5a\u64a7\udbea\udf0e",
        15, 10025, -1327859530, 2722376795388129019L, -14812L, false, false, (char) 58745, (char) 41463,
        Double.longBitsToDouble(0x3fd17553b17933ecL), Double.longBitsToDouble(0x3fab00c307113a10L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 8, "\uda77\udd51", "\ud176\u80c9\u1c8d", "\000\u64a7\u247e",
        33, 10025, 14317750, 2722376494740418299L, -56111L, true, true, (char) 35551, (char) 29583,
        Double.longBitsToDouble(0x3fcab3b480000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 8, "\udbf2\udfae\000\udb1a\udede", "\u1c8d\u6abf\uc526\u008c\u4f20\u97a8\u87d2\uc567\uc2e7\u180d\u2efb\u7d73", "\uab71\udbd2\udfa8\udac4\udc1c\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77",
        14, 74063, -8049090, 3757264546817048461L, -67636L, false, true, (char) 105, (char) 0,
        Double.longBitsToDouble(0x3f2de90000000000L), Double.longBitsToDouble(0x3fe08c535122bc2dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 6, 1, 14, "\udbf2\udfae\000\udb1a\udede\ud93f\udea4\ud9f4\udedf", "\uc526\u008c", "\uda65\udf74\udb5b\udd53\udb1d\ude49\uda39\ude08\u2e6c\ud850\ude8c\ud9e2\udfd0\udbf6\udc78\u137e\udbd2\udfa8",
        31, 27581, -1245952043, 6141762253285134615L, -62590L, true, false, (char) 22628, (char) 44478,
        Double.longBitsToDouble(0x3fa9ffc2cbe4c980L), Double.longBitsToDouble(0x3fe2d66d61a68b89L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=org.jfree.chart.util.RectangleInsets:RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 3, 14, 8, "\udb81\ude55\udb22\udca0", "\u80c9\u1c8d\u6abf\uc526\u008c\u4f20\uab36\u888b\uc5f8\uc2e7\u180d", "\udb21\udc8f",
        9, 42889, 1041956864, -5689932251158756730L, -96466L, false, false, (char) 52070, (char) 6923,
        Double.longBitsToDouble(0x3fcfc980e12dcd34L), Double.longBitsToDouble(0x3fef57a99ddefd03L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 8, "\ud843\udf1c\000\udb1a\udede", "\u1c74\u6abf\u0639\uad94\u4ff6\ub7a8\u64ca\u7401\uc2e7\u180d\u1ffc\u7d73", "\uab71\udbd2\udfa8\udac4\udc1c\ud859\udcba\ud9ff\udc80\udb6f\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud92f\udf92\ud864\udc6e\ud890\ude24",
        28, 92827, -8049090, 5126358836329152714L, 55389L, false, false, (char) 5014, (char) 50269,
        Double.longBitsToDouble(0x3fed68fe91000000L), Double.longBitsToDouble(0x3fe08c535122bc2dL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.lang.Double:0.0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 11, 0, "\udbf2\udfae\000\udb1a\udede\ud991\udead\ud9d4\udcc9\ud92e\udf00\ud995\udca4\udaa5\uddba\u008c\u6466\udbea\udf0e\ud988\udfd4\ud968\udc37\udbc9\udc0b\udbe9\udd7f\u2efb\ud850\ude8c\udb21\udc8f\udbc5\udeae\uab71\udbd2\udfa8\udac4\udc1c\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45\udb5d\udcbb\ud899\udda1\uda15\udf0e\ud896\uddf4\000\ud9ce\udf86\udb57\udca0\u8957\udb11\ude11\ud95e\udedc\udb1a\udd4f\ud98f\udd96\udb5b\udd49\udb00\uded7\udab9\udcb2\uda16\udc66\ud8d0\ude6f\ud9d3\ude79\ud93e\udc5c\ud928\udfd1\u3562\ud857\udd6c\u5ebf\ud8cb\udcc1\ud85d\udc2e", "\u6988\ua00e\uc376\u9a42\u7fa9\u9b01\u8176\u6d4f\u4e3c\uaf5e\ua6b0\ua267\u92f8\u0132\ua228", "\udb30\ude2b\udaa2\uded5\ud996\udd27\ud949\udec4\udbed\uddbb\udacf\udf9a\uda0a\udd8a\ud947\udc7e",
        13, 30847, -311817282, -7011975857155984L, 34245L, true, false, (char) 29403, (char) 2297,
        Double.longBitsToDouble(0x3fe8007b1bd21680L), Double.longBitsToDouble(0x3fbe3a4e66b5a8a8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 0, "\udbf2\udfae", "\ud176", "\ud995\udca4",
        40, -860, 398144256, -1752986029630865991L, 61974L, false, false, (char) 0, (char) 57087,
        Double.longBitsToDouble(0x3fe045a3882d2af0L), Double.longBitsToDouble(0x3feb8b7368000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 1, 0, "\000", "", "",
        -5, 9336, 1778945915, 601693565696L, -100000L, false, false, (char) 46757, (char) 218,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fe045a3882d2af0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 7, 6, "\udbf2\udfae\000\uda4e\udc79\ud991\udf00\ud9d4\udcc9\ud9ef\ude42\ud985\udd01\udaa5\uddba\ud83f\udcab\u6466\udbea\udf0e\ud988\udfd4\ud968\ude37\ud961\udc57\udbe9\udd7f\u2efb\udbe6\udff8\ud98f\ude95\ud824\ude85\ud8b4\udc6c\uef29\udac4\udc46\ud859\udcba\uda50\udf74\uda67\udcd1\ud84a\udd3a\uda96\udc0e\uda7a\udcd1\udaaf\ude8f\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\uda85\udf45\udb5d\udcbb\ud879\ude71\udba5\udc7f\ud88f\udd39\000\udabc\udc59\ud885\udd9f\u892b\udb11\ude11\ud823\udc17\udaaf\uddf9\u3877\ud8b7\uddf9\ud96c\udf79\udacd\udc1f\ud991\udfcf\udac7\ude2b\uda19\udf2d\ud831\uddb2\ud803\udd8c\udaeb\udfe4\uda44\ude9e\ud824\udcc4\ud9ac\ude0b\ud835\udeb8\udbfb\ude64\udbc9\ude67\ud854\udc31\ud981\udd53\udb70\uddcf\udbe6\ude01\udbf6\udd47", "\ub9dd\u493d\u6de4\uc822", "\udb4d\udd63\udbaa\udd7b\udb02\udd1d\ud975\udf48\ud92e\udc43\ud920\udea4\udbf9\udeae\udaa3\udcf2\uda47\udec9\uda76\ude9b",
        13, 85260, 1986433730, 2636174427530071673L, 55696L, true, true, (char) 64931, (char) 6671,
        Double.longBitsToDouble(0x3fd45dbba3259c14L), Double.longBitsToDouble(0x3fd43c6d5beb7b38L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 1, 8, "", "\u9ff2\ud176", "\ud994\udffe",
        40, -860, 398131200, -1752986029630865991L, 61974L, false, true, (char) 21698, (char) 57087,
        Double.longBitsToDouble(0x3f8168e200000000L), Double.longBitsToDouble(0x3feb8b7368000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 2, 2, 0, "\udb1b\udec3\ud816\udc19\ud8f6\udf2a\ud991\udead", "\u4088\u35ab\u755c\ub80d", "\ud968\udc37\000",
        32, 24387, 57261, 3093972945856186669L, -35337L, true, false, (char) 27265, (char) 27279,
        Double.longBitsToDouble(0x3e21755000000000L), Double.longBitsToDouble(0x3fc7933ec0d80618L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 8, "\ud8f6\ude96\uda4e\udca4\udb1a\udf50\ud991\udead", "\ub178\uc596\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udacd\udf82\uda99\udcd4\ud9bc\uddb4\u07b9\udb6c\udf36\udb88\udd40\ud973\udfdd\u48d3\ud85c\udd5e\ud925\uddd3\udbff\ude85\udbdd\uddbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\ud960\udf93\udb5d\udcca\ud899\udda1\uda15\udf0e\ub1a0\ud9b9\udd29\udb44\udc1f\uda5b\ude28\u47f0\udb11\ude11\ud9ef\udc23\udbcd\ude5c\udbb8\udf42\udb38\ude81\ud939\uddef\udbd3\udc53\udb27\udd1a\ud964\udd78\uda33\udd9f\ud944\udd29\uda0a\udef5\udbbf\udd29\ud8bd\udfdc\ud968\udd2e\udb4d\udfdc\ud873\udd29\uda4c\udc8c\udbb4\uddad\ud82f\udc87\udbbb\udebf\ud8ca\udd84\ud8da\udd11\ud8f2\udfa8\uda99\udc77\udb57\udeea\ud841\udc0c\udaa4\udfc8\ud9b0\udc12\u1a68\uda1a\udd79\uda42\udff6\ud9de\udc65\ud8c7\udd31\ud904\uddf9\udb64\udf37\uda9a\ude0d\uda25\udcd2\ud8f4\udf4c\udb40\udd1e\udb75\udef0\ud9ae\udc5d\ud80b\udf37\ud814\udc8d\ud892\udf54\ud8b0\udcf7\udb35\udc73\udab0\udd9d\uda75\udc64\ud823\udfd7\udaa6\udc82\udad4\uddb8\ud93f\udc97\ud9d1\uddfb\ud9b8\udfc3\udab1\udca6\uda51\udf48\udb06\udea7\ud8ad\udd1a\udb5d\uddd8\ud96a\ude4b\ud8b7\ude78\uda60\udf27\udacd\ude4a\uda8e\udfc5\ud9df\udfe6\ud9bb\ude61\ud90d\uddf8\uda23\uddba\udb1e\udc51\udbd0\udce1\ud9f5\ude79\ud87a\udf71\ud860\udfc1\udbfb\udd74\ue110\udbd4\udcd2\udba0\uddc8\ud90c\udcdd\ud8bd\udc81\uda86\udeb3\ud80e\ude70\ud90c\ude72\udaae\udd39\udb5e\udf23\ud955\ude06\uda57\udc96\ud806\udc03\udb7a\udd1a\ud81a\udd8e\uda91\udf46\ud981\udc65\udbb3\udd3a",
        10, 42703, 1178920523, 6108028483292548983L, -44710L, false, false, (char) 49039, (char) 10796,
        Double.longBitsToDouble(0x3fe7483f7d2f2326L), Double.longBitsToDouble(0x3fd3f6d5dd898c1aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=null |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 10, 10, 8, "\uda77\udd51\ud93b\udee4\udaec\udd55\uda96\udebd\ud8d8\udf15\uda03\ude2e\ud888\ude5b\ud80c\udcc6\ud91c\uddfd\ud806\udff6\udbea\udf0e\ud9f0\udd1e\ud968\udc86\udbc9\udc0b\udb9e\ude8a\ud91d\udf4b\ud8f8\udd4d\udb21\udc8f\u070e\udacd\udf82\uda81\ude8e\udb1a\ude57\ud859\udcba\uda50\udf74", "\uc28a\ub779\u08b9\ua210\u5c60\ua2aa\u6579\u3c74\ubebc\u6362\u12fb\u42ce\u3ae5\u76bf\u71b4\ud744", "\udb04\udfac\ud828\ude0e",
        41, 49247, -1170625581, -5298596740993912508L, -65436L, false, true, (char) 50224, (char) 55207,
        Double.longBitsToDouble(0x3fe179651c180926L), Double.longBitsToDouble(0x3fb67575c31f1908L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 10, 1, 8, "\uda1c\udca1\uda41\ude39\udb1a\udf50", "\u90f8\u6ad9\uc526\u75e8\u4f61\u97a8\u1bcf\uc647\uc2e7\u180d\u0233\u6096", "\udacd\udf82\udbd3\udf11\udac4\udc1c\ud859\udcba\uda50\udf7f\udaa2\udc6d\uda5c\udfa8\u48d3\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\u56bb",
        11, 61199, -542881406, -7683358675169118753L, -14188L, true, true, (char) 56536, (char) 34597,
        Double.longBitsToDouble(0x3fef768ad63dc008L), Double.longBitsToDouble(0x3fe449cab3ccd136L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 8, 8, 8, "\udb19\udfa1\uda4d\udfcd\u8f5d\uda63\udca4\ud995\ude25\uda76\udf30\ud822\udfed\udaf8\ude8b\udb5a\udf5a\ud805\udfa7\uda7f\udf98\uda02\udc8d\ud968\udc86\udbc9\udc0b\udbc9\udf8c\ud8f2\udda3\ud998\udebc\uda5f\udf9b\udbf8\udc82\udacd\udf82\udbd3\udf8d\udac4\udc1c\ud859\udcba", "\ua4db\uaf7b\u9a6c", "\ud8b5\udc13\udba4\udffb",
        33, 70510, -596914852, 5568767095555225599L, 14811L, false, false, (char) 64290, (char) 41506,
        Double.longBitsToDouble(0x3fc55871f16a9cdcL), Double.longBitsToDouble(0x3fe6f90254dc00c8L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 6, 6, 14, "\uda77\udd51\uda4d\udff6\udb1a\udf50\ud991\udead", "\u6abf\ua27b\u75e8", "\ud9d1\ude4b\ue8aa\ud9f8\ude89\udbe9\udd7f\ud98d\udfb1\ud864\udcc7\udb21\udc8f\udbe9\udf26\udacd\udf82\udbd3\udf11\udac4\udc1c\ud859\udcba\uda50\udf74\udaa2\udc6d\uda0f\ude80\u482e\ud85c\udd5e\ud925\uddd3\ud9f8\udc21\udb64\udf9e\udaad\ude17\uda4d\udedb\ud944\udeaf\uda1c\udd75\ud84d\udd34\udbd0\udce8",
        12, 41066, -188752522, -7009426956663943895L, -49771L, true, false, (char) 38269, (char) 46414,
        Double.longBitsToDouble(0x3febe1d69deada08L), Double.longBitsToDouble(0x3fd20f52bcaad416L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 6, 6, 13, "\uda5e\ude64\uda46\udc92\udb35\udeab\ud991\udead", "\u6abf\uc562\u314c\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\udad5\udf9a\udbd7\udfab\udacd\udf82\ud925\udeba\ud992\udc23\ud859\udcba\uda50\udf74\udb88\udd40\uda5c\udf13\u06f4\ud85c\udd5e\ud925\uddd3\ud829\ude3a\udbe1\udfbc\ud890\ude77\ud9fc\uddbc\uda21\uddad\ue874\ud9e0\ude5e",
        4, 99265, -717782636, 2983953533856873943L, -79274L, false, true, (char) 31858, (char) 42474,
        Double.longBitsToDouble(0x3fbcf3433d5fef10L), Double.longBitsToDouble(0x3fd02dae672b3b10L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 12, 12, 4, "\uda77\udd51\uda4d\udff6", "\u98f0\u2423\ubff4\u035e\u0756\u4f61\u97a8\u888b\u2a1e\uc24b\u180d\u7afa\u7e20\u14ec\ucc0d\uc96c\u968d\u572d\u55f3\u23d0\ua422\u1258\u2122", "\udb5b\udd44\udbe1\udfbc\ud890\ude77\ud954\udef2\udba1\udf23\udafd\ude91\udb81\udc3f\udb5d\udcc2\udb51\ude4d\uda15\udf0e\udaeb\udc5e\ud97f\udca6\ud9e2\udc3d\udb11\ude80\ud813\udd1e\udb11\ude11\ud9ef\udc23\udbcd\ude5c\ud93d\ude44\ud828\ude53\uda89\udf3f\udb30\ude8d\ud9ae\ude1d",
        50, 34520, -1833483375, 5935479527900622674L, 81027L, true, true, (char) 8948, (char) 7825,
        Double.longBitsToDouble(0x3fcdbba83267bd98L), Double.longBitsToDouble(0x3fecee4c6807c654L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 8, "\ud8f6\ude96\uda4e\udca4\udb1a\udf50\ud991\udead", "\ub178\uc596\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udae1\udccc\udb43\udcb7\ud92b\udc3a\ud95b\ude88\udb6c\udf36\udb88\udd40\ud973\udfdd\u48d3\ud85c\udd5e\ud925\uddd3\udbff\ude85\udbdd\uddbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\ud960\udf93\udb5d\udcca\ud9e1\udc84\ud85d\udd6f\ud81c\uddb1\ud9b9\udd29\udb44\udc1f\uda5b\ude28\udb83\udfe8\udb11\ude11\ud9ef\udc23\udbcd\ude5c\udbb8\udf42\udb38\ude81\ud939\uddef\udbd3\udc53\udb27\udd1a\ud964\udd78\uda33\udd9f\ud944\udd29\uda0a\udef5\udbbf\udd29\ud8bd\udfdc\ud968\udd2e\udb4d\udfdc\ud873\udd29\uda4c\udc8c\udbb4\uddad\ud82f\udc87\udbbb\udebf\udb49\ude79\ud8da\udd11\ud8f2\udfa8\uda99\udc77\udb57\udeea\uda13\ude36\udaa4\udfc8\ud9b0\udc12\u1a68\uda1a\udd79\uda42\udff6\ud9de\udc65\ud8c7\udd31\ud904\uddf9\udb64\udf37\uda9a\ude0d\uda25\udcd2\ud8f4\udf4c\udb40\udd1e\udb75\udef0\ud9ae\udc5d\ud80b\udf37\ud814\udc8d\ud892\udf54\ud9d0\udda8\udb35\udc85\udab0\udd9d\uda75\udc64\ud823\udfd7\udaa6\udc82\udad4\uddb8\ud93f\udc97\ud9d1\uddfb\ud9b8\udfc3\udab1\udca6\uda51\udf48\udb06\udea7\ud8ad\udd1a\udb5d\uddd8\ud96a\ude4b\ud8b7\ude78\uda60\udf27\udacd\ude4a\ud9a4\udc10\ud905\udcb9\ud9bb\ude61\ud90d\uddf8\ud987\udfac\udb1e\udc51\udbd0\udce1\ud9f5\ude79\ud87a\udf71\ud860\udfc1\udac7\udf79\ue110\udbd4\udcd2\udba0\uddc8\ud90c\udcdd\ud8bd\udc81\udb8e\ude36\ud80e\ude70\ud90c\ude72\udaae\udd39\udb5e\udf23\ud955\ude06\uda57\udc96\ud806\udc03\udb7a\udd1a\ud81a\udd8e\uda91\udf46\ud981\udc65\udbb3\udd3a",
        10, 42703, 1178920523, 6108028483292548983L, -44710L, false, false, (char) 49039, (char) 10796,
        Double.longBitsToDouble(0x3fe2f3bf7d2f2326L), Double.longBitsToDouble(0x3fd3f6d5dd898c1aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 8, "\ud8f6\ude96\uda4e\udca4\udb1a\udf50\ud991\udead", "\ub178\uc596\u75e8\u4f61", "\ud968\udc37\udbc9\udc0b\udbe9\udd7f\udb9e\udc04\ud850\udf39\udb21\udc8f\udbd7\udfae\udae1\udccc\udb43\udcb7\ud92b\udc3a\ud95b\ude88\udb6c\udf36\udb88\udd40\ud973\udfdd\u48d3\ud85c\udd5e\ud925\uddd3\udbff\ude85\udbdd\uddbc\ud890\ude77\ud95d\udef2\uda43\ude12\udafd\ude36\ud960\udf93\udb5d\udcca\ud9e1\udc84\ud85d\udd6f\ud81c\uddb1\ud9b9\udd29\udb44\udc1f\uda5b\ude28\udb83\udfe8\udb11\ude11\ud9ef\udc23\ud8bb\ude53\udba2\udefc\udb38\ude81\ud939\uddef\udbd3\udc53\udb27\udd1a\ud964\udd78\udb67\udf58\ud944\udd29\uda0a\udef5\udbbf\udd29\ud8bd\udfdc\ud968\udd2e\udb4d\udfdc\udafb\udeed\ud8bc\uddca\ud801\udfc7\ud82f\udc87\udbbb\udebf\udb49\ude79\ud8da\udd11\udbdb\udfde\udaa5\udcee\udb57\udf3f\uda13\ude36\udaa4\udfc8\ud9b0\udc12\udb04\udec7\uda1a\udd79\uda42\udff6\ud9de\udc65\ud8c7\udd31\ud904\uddf9\ud84c\ude88\uda9c\udf91\uda25\udcd2\ud8f4\udf4c\udb40\udd1e\udb75\udef0\ud9ae\udc5d\ud80b\udf37\ud814\udc8d\ud892\udf54\ud9d0\udda8\udb42\udc3c\udab0\uddf3\uda75\udc64\ud823\udfd7\udaa6\udc82\udad4\uddb8\ud8ca\udc07\ud9d1\uddfb\ud9b8\udfc3\udab1\udca6\uda51\udf48\udb06\udea7\ud8ad\udd1a\udb5d\uddd8\ud96a\ude4b\ud8b7\ude78\uda60\udf27\udacd\ude4a\ud9a4\udc10\ud905\udcb9\ud9bb\ude61\ud90d\uddf8\ud9bb\udc64\udb1e\udc51\udbd0\udce1\ud9f5\ude79\ud87a\udf71\ud860\udfc1\udac7\udf79\ue110\udbd4\udcd2\udba0\uddc8\ud90c\udcdd\ud8bd\udc81\udb8e\ude36\ud80e\ude70\ud90c\ude72\udaae\udd39\udb5e\udf23\ud955\ude06\uda57\udc96\ud806\udc03\udb7a\udd1a\ud81a\udd8e\uda91\udf46\ud981\udc65\udbb3\udd3a",
        10, 42703, 1178920523, 6108028483292548983L, -44710L, false, false, (char) 49039, (char) 10796,
        Double.longBitsToDouble(0x3fe2f3bf7d2f2326L), Double.longBitsToDouble(0x3fd3f6d5dd898c1aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.axis.Axis|drawLabel|java.lang.String,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge,org.jfree.chart.axis.AxisState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|addChangeListener|org.jfree.chart.event.AxisChangeListener|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|clone||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|configure||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|draw|java.awt.Graphics2D,double,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|drawAxisLine|java.awt.Graphics2D,double,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|equals|java.lang.Object|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getAxisLinePaint||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getAxisLineStroke||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getFixedDimension||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabel||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelAngle||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelEnclosure|java.awt.Graphics2D,org.jfree.chart.util.RectangleEdge|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelFont||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelInsets||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelPaint||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|drawLabel|java.lang.String,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge,org.jfree.chart.axis.AxisState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.axis.CategoryAxis:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
