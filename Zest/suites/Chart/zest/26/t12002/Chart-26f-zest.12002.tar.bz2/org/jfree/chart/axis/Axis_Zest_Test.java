package org.jfree.chart.axis;
import org.junit.Test;
import static org.junit.Assert.*;
public class Axis_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u524c\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u1375\u9220\uc3ee\u407b", "\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 28168, (char) 20344,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fa79b34b815aac0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e", "\u0086\uabfd", "\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a",
        2, 70246, -1532395383, 1992228760901300805L, 32110L, true, false, (char) 36374, (char) 32001,
        Double.longBitsToDouble(0x3fe8fd98aa945041L), Double.longBitsToDouble(0x3fd1fc8512bc6174L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\ud9f9\udca7\ud92f\udc41\udbf6\udd5a\ud992\udf80\ud8f1\uddb0\udb4e\uded0\udb61\udd3d\ud8e6\ude68\udadb\ude2c\ud97d\udc5e\uda40\ude7f\udaf2\udfc6\u6b27\ud838\udf22\ud811\uddd7\ud883\udd26\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u524c\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\u4d2a\u8c01\u407b\u2da3\ub414\u9c9b\u9d5c\u4495\u5724\u156c\u934e\u9220\uc3ee\ud28e", "\udac2\udccf\udb30\ude03\udbcb\udd33\ud835\udfbd\ud956\udd44",
        34, 83461, 27576746, -7918289837426837538L, -1732L, false, true, (char) 47602, (char) 56366,
        Double.longBitsToDouble(0x3fe008f01f789ea5L), Double.longBitsToDouble(0x3fab4a9af2efa6a0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\ud933\udf86\udae0\udc6f\udb99\ude2a\udb70\udf45\ud8f0\udc2a\udaab\udde3\udaf3\udc2b", "\u1130\u7cef\u9331\ub613\u18ac\u1a88\uc63d\uc094\u6edf\u340f\u98b8\u0fb0\u5d63\u1f2a\u072b\u1925\u6150\ua5d9\u524c\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u2d7c", "\ud90c\udcf6\udabc\udec5\ud938\ude94",
        -4, 56220, -2083399526, 7522524006744386354L, 44926L, true, true, (char) 30165, (char) 1477,
        Double.longBitsToDouble(0x3fce97526d12af58L), Double.longBitsToDouble(0x3feeb64a9c4b43eeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 3, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\ubb48\ud9a9\udd45\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud9c9\udd2a\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud91d\udc10\udb1f\udd86", "\u6798\u60e8\ua5d9\u2cfd\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u1375\u9220\uc3ee\u407b", "\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 28168, (char) 6564,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fa79b34b815aac0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\ud9f6\udd4b\udb25\udc55\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u524c\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u1375\u9220\uc3ee\u407b", "\uda6b\udcdb\ud8db\udffe",
        32, 8526, -861434805, 310444868986683541L, -3034L, true, false, (char) 50865, (char) 50510,
        Double.longBitsToDouble(0x3fead93fb2011e03L), Double.longBitsToDouble(0x3fe3c4f52c0bab7bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udaf1\udcca\udba0\udecb\u13ac\uda30\udd65\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8", "\ud867\udeff\udb56\udf57\ud950\udde3\ud9b4\udd2c\ud870\udd55\uda63\udce7\ud943\udd72\ud8b7\udd08\ud82d\udd85\u95ff\ud90c\udcf6\udabc\udec5\ud938\ude94",
        52, 56163, -2083399526, 7522524006744386354L, 44926L, true, true, (char) 30165, (char) 1477,
        Double.longBitsToDouble(0x3fce97526d12af58L), Double.longBitsToDouble(0x3feeb64a9c4b43eeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6", "\u8d0b\u57be\u15fb\u2b9d\u9bfb\ubf25\u2000\u395f\u8bc0\uc447\u9245\u1130\u52aa\u92f9\ub613\u18ac\u1a88\uc63d\uc094\u6edf\u340f\u98b8\u0fb0\u5d63\u5e2d\u6345\u6798", "\ud842\udfa2\ud867\udeff\udb56\udf57\ud972\udee3\ud9b4\udd2c\uda3e\udc79\uda63\udce7\ud943\udd72\ud8b7\udd08\ud82d\udd85\u95ff",
        28, 83417, -1388583051, 9111862547563569475L, 72102L, false, true, (char) 28705, (char) 48258,
        Double.longBitsToDouble(0x3fee2d028f366e9fL), Double.longBitsToDouble(0x3fce739a33d2ea4cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud9f1\udca1\udbfc\udefc\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud942\udf6a\ud8e0\udda9\udaf3\udc2b", "\u1130\u7cef", "\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b",
        43, 79902, 333302061, 2278973367867024348L, -75513L, true, false, (char) 26411, (char) 54165,
        Double.longBitsToDouble(0x3feda4f772cefed0L), Double.longBitsToDouble(0x3fefe239167eb13eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 12, 14, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\udadc\udc86\uda86\udeb2\uda96\ude6a\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\uda07\uddb0\ud848\ude0e\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u524c\u8f1c\u62a4\uad65\u1cb9\ubcf9\uc139\ua22a\u8c01\u2fa1\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u4bc5\u6591\uc3ee\u407b", "\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 28168, (char) 20344,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fa79b34b815aac0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 2, 11, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\ud865\udd45\udb67\uddb2\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\ud9fc\udd2f\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u9114\u6b08\ua5d9\u524c\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua263\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u0328\u9218\uc3ee\u407b", "\uda6b\udcdb\ud8d8\udd79\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 8200, (char) 22357,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fa79b34b815aac0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udafd\ude51\ud8f6\udd9d\udb17\udeef", "\u6798\u60e8\ua5d9\u524c\u8f1c\u62a4\u56e7\u8d93\u6f71\uc106\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u1375\u9220\uc3ee\u8e8b", "\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 28168, (char) 20431,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fa79b34b815aac0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\uded8\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda06\udf0e\udaab\udd2c\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udc93\ud848\uded1\udbe4\ude4b\udb88\udca8\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud9db\udc0f\ud946\udcd9", "\u6798\u60e8\uad4e\u4169\u8f07\u62a4\u56e0\ud4af\u0ec1\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u2d33\u1375", "\ud9eb\udc3e",
        7, 782, -1164744568, -6064628014827470012L, -74264L, true, true, (char) 2256, (char) 41513,
        Double.longBitsToDouble(0x3fe5a65fe9342c1bL), Double.longBitsToDouble(0x3fec208fb6343e03L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u524c\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u576b\u2a71\u862c\u498e\u35fa", "\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64\ud93a\udd5e\ud9b3\udd4d\udbb1\ude8e\udb13\udd1f\ud8ef\udc44\udb8b\udd7c\udacd\udd29\udaae\uddf7\ud82f\udc44\ud973\ude4a\ud98f\udec3\udb7d\udca4\ud9f8\ude04\udac4\udd87\udb32\ude41\ud8fa\udc83\ud932\udd9d\udb55\udcf6\udba0\udf49\udabe\udda5\ud8eb\udf7b\ud930\ude67\ud8d6\udfa3\udbc4\udfbb\uda88\ude06\ud860\ude94\udb38\udebf\ud94c\udebb\udb79\udfb6\udb2f\udee3\ud96c\ude04\ud8d9\udd69\ud8ff\ude3b\ud83d\uddb9\ud9c2\udf23\ud909\udc13\uda11\ude66\ud890\uddfc",
        39, 21023, -1706782665, 1425098291691260268L, 19042L, true, true, (char) 1384, (char) 35893,
        Double.longBitsToDouble(0x3fd9911053450244L), Double.longBitsToDouble(0x3fe878e3a571cdf5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 8, 4, "\ud8b0\udfaa\udbc6\udeae", "\uabfd\u7edb", "\uda89\uddd2\ud8ff\udd85\udb4f\udd39\udb67\udd13",
        17, 26752, -482910754, -6581588054062542463L, 23316L, false, true, (char) 24638, (char) 36374,
        Double.longBitsToDouble(0x3fdb2774fe3f662aL), Double.longBitsToDouble(0x3feca2820d1fc851L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 6, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u524c\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u8c01\ucb13\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u1375\u9220\uc3ee\u407b", "\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, -1199903966, -16959491645414133L, 79189L, true, false, (char) 28168, (char) 20344,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fe979b34b815a45L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 10, 8, 4, "\ud8ad\ude3e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\ude1d\udb4f\udd39\udb67\udd13\ud9a8\ude27\udb3d\udd48\udae3\udf35\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u8a5b\uac30\u62a4\ub494\u9203\u4453\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\uc13b\u5cbd\u156c\u1375\u5f20\uc3ee\u413b", "\ud92f\udcdd\ud8db\udffe\ud870\udc0b\udb58\udfd6\uda9a\udd46\udbfd\udc37\ud90e\uddb4\udb4f\udde3\udbe1\ude67\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 28168, (char) 20344,
        Double.longBitsToDouble(0x3fea0d4879707f7eL), Double.longBitsToDouble(0x3fa79b34b815aac0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 14, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\udad2\udec8\udaab\ude6e\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\udb2b\uddfe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u4fc0\u60e8\ua5d9\u524c\ud25d\u25c9\u575c\u9cfb\u3885\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\u1375\u9220\uc3ee\u407b", "\uda6b\udcdb\ud8db\udffe\ud870\udc21\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 28168, (char) 20344,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fe4f1eb4fea3addL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e", "\u0086\uabfd\u7edb\u8d0b\u9ead\u15fb\u2b9d\u9bfb\ubf25", "\udaf3\udc2b\u6b27\ud838\udf22\000",
        -5, 22968, 1121097441, 8597172967812957618L, -33804L, true, true, (char) 43544, (char) 55537,
        Double.longBitsToDouble(0x3fe1a09eebdc1fa0L), Double.longBitsToDouble(0x3fece0e25059a3abL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 12, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\udb9a\udfa3\udacc\udfb2\u8ebe\ud8bf\udf67\uda7a\ude08\ud858\uded3\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b57\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udb85\udf5c\ud9b9\ude87\ud85f\udc92\udb1f\udd86", "\u6872\ub180\u8c7b\uae98\u2ab8\u6211\u3f40\ud4af\ubcf9\uc139\ua22a\uc319\ud3ed\uc6e0\u7f20\u66dc\u9d5c\u4495\u5724\u156c\u4449\u3943\uc3ee\u407b\uc6e0\u61a8\uaeaa\u294a\u3a77\u2059\u6a3a", "\udb97\udc9b",
        9, 51353, 901416250, -3747720090165183820L, -35141L, false, true, (char) 43293, (char) 61318,
        Double.longBitsToDouble(0x3fe67c5a0b923303L), Double.longBitsToDouble(0x3feb54207741a90fL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 0, 4, "\uda81\udce8", "\u79a9\uc724", "\ud8db\udf86",
        -3, 91710, 338998281, 3715269624769134315L, -75712L, true, false, (char) 30250, (char) 52713,
        Double.longBitsToDouble(0x3fe265a6b3f2ea9aL), Double.longBitsToDouble(0x3fe70e4ae9ed42d2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=org.jfree.chart.util.RectangleInsets:RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 1, 14, 15, "\ud87c\udd58\udbc6\udeae\ud8e4\udd5f\udb2f\ude51\ud92f\udccd\udbf6\udd5a\ud9bc\udfce\udab8\udcb5\ud933\udf4f\ud80a\udd83\udb74\uddfb\ud894\udef8\ud81f\udcf5\udaab\udde3\ud93f\udd88\ud9c5\udc9d\ud9fa\udcce\ud811\uddd7\ud883\udd09\udb58\udfda\ud848\ude9b", "\ud19a\uc094\u2648\u340f\ucdc1\u250c\u808b\u550c\u072b", "\udbd7\udff1\ud873\udcd0\ud867\udeff\udb56\udf57\ud972\udee3\uda81\ude72\ud839\uddd5\uda32\uddec\ud943\udd72\ud8bd\udd8c\ud861\udfb0\uda36\udfa7\ud844\udf23\ud9ef\udf80\udac8\uded9\udb5c\udfcd\u6efe\uda12\udd48\udbe7\udde0\udb90\udd1b\ud8b0\udf0f\ud9eb\udc3e\udb8e\ude49\uda90\udd5d\uda6b\udcdb\ud8db\udffe\ud870\udc0b",
        31, 10235, 1215234779, -2992013690797118291L, -21623L, true, true, (char) 8908, (char) 462,
        Double.longBitsToDouble(0x3fe76352c86f0ea4L), Double.longBitsToDouble(0x3fde54ae50976958L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 3, 8, 4, "", "\u06a5", "\000",
        -5, -1000, 0, -6091338612753517559L, 14411L, true, false, (char) 60479, (char) 25717,
        Double.longBitsToDouble(0x3fd81a4a948a374aL), Double.longBitsToDouble(0x3fb32d35879754d0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 4, "\ud88a\udd4e\udbc6\ude81\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda6d\udd09\000\000\udb67\udd13\ud8f0\udc2a\ubb48\ud9a9\udd45\udbfa\ude9d\ud838\udf22\ub245\ud883\udcbd\udb0e\udcb9\ud9c9\udd2a\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udcb7\037\000\udaca\ude2b4\u23dc", "", "\u00e5",
        -5, 97120, 0, 5332261957667312941L, -19360L, true, false, (char) 24700, (char) 10693,
        Double.longBitsToDouble(0x3fe000000767f894L), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 3, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\ubb48\ud9a9\udd45\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\uda5b\udf40\ud99d\udc35\udb6f\ude16\udb27\udc71\udb59\udff0\udb35\udc97\ud84b\ude57\udbba\ude4b\udaca\ude58\ud91d\udc10\udb09\udf3c", "\u6798\u60e8\ua5d9\u2cfd\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724", "\udb90\udd1b\ud8b0\udeff\ud9eb\udc3e\udb8e\ude49\uda90\udd5d\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud8b9\uddb5\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64\ud93a\udd5e\ud9b3\udd4d\udac6\udde4\udb20\ude13\ud8ef\udc44\udb8b\udd7c\udacd\udd29\udaae\uddf7\ud82f\udc44\ud966\udc76\ud98f\udec3\udb7d\udca4\udbbf\udd86\udb70\udd5d",
        6, 98976, -942604178, 9062411349974487979L, 90140L, false, false, (char) 16480, (char) 7755,
        Double.longBitsToDouble(0x3fe9aedde5053f3aL), Double.longBitsToDouble(0x3fdbda3b256d32a8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 12, 2, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udaf1\udcca\udba0\udecb\u13ac\uda30\udd65\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8", "\ud867\udeff\udb56\udf57\ud950\udde3\ud9b4\udd2c\ud870\udd55\uda63\udce7\ud943\udd72\ud8b7\udd08\ud82d\udd85\u95ff\ud90c\udcf6\udabc\udec5\ud938\ude94",
        52, 56163, -2083399526, 7522524006744386354L, 44926L, true, true, (char) 30165, (char) 1477,
        Double.longBitsToDouble(0x3fce97526d12af58L), Double.longBitsToDouble(0x3feeb64a9c4b43eeL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jfree.chart.util.RectangleInsets:RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 9, "\ud9fe\udf69\udbfd\udf3d\uda35\udf07\udba2\uddda\ud92e\udfec\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\ud835\udd20\udb36\udc25\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udaf1\udcca\udba0\udecb\udb28\udd7d\uda69\udedb", "\u6edf\u340f\u98b8\u0fb0", "\udb83\udee6",
        40, 27113, -1628505883, -85405990423229746L, -8561L, false, true, (char) 5851, (char) 24700,
        Double.longBitsToDouble(0x3f9029b5cdf21f60L), Double.longBitsToDouble(0x3feb3fc4a5891a77L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.awt.BasicStroke:@? |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.BasicStroke:@? |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 8, 8, 6, "\udaba\udd46\udbc6\udeae\ud972\udea7\uc6e1\ud92f\udccd\udbf6\udd6c\udad6\udc20\ud8db\udf76\ud82b\uddf2\uda96\uded2\udb4f\udd39\udb67\udd13\ud944\udd94\udaab\uddb5\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\udbd5\udfe6\ud875\udcb8\udba0\udecb\u13ac", "\u88c0\u8d8d\u888f\u98b8\u65e9\u5d1f\u6b40\u6aa8\u2c84\u60e8\u44a2\u64da\u8e9f\u62a4", "\ud870\udd55\ud961\udf82\udba4\udc6a\ud805\udc75\ud82d\udd85\u95ff\ud909\udc5e\udabc\udec5\ud938\ude94\udadf\ude29",
        8, 27474, 1751463729, 2402929000958659529L, -37477L, false, true, (char) 1477, (char) 55175,
        Double.longBitsToDouble(0x3fea255eb7d6c953L), Double.longBitsToDouble(0x3fb2d0fb857f7e80L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 1, 3, 4, "\uda97\uddb9\udbc6\udedd\udbca\udf32\uda77\udec6\ud92f\udccd\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb7c\udc13\uda29\udc24\udba9\uddb6\udaab\udde3\uda2d\udca7\u9c87\ud838\udf22\ud811\uddd7\ud883\udd09\udaf1\udcca\udba0\udecb\u13ac\uda30\udd65\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud996\udd99\udb2f\udefc", "\u6798\ub45b", "\ud867\udeff\udb56\udf57\ud950\udde3\ud9b4\udd2c\ud870\udd55\uda63\udce7\ud943\udd72\ud8b7\udd08\uda2b\ude99\u34cb\ud84f\ude73\udb75\udf0a\ud938\ude94",
        52, 56163, -2083399526, 7522524006744386354L, 44926L, true, true, (char) 42453, (char) 1477,
        Double.longBitsToDouble(0x3fce97526d12af58L), Double.longBitsToDouble(0x3feeb64a9c4b43eeL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud95f\udc16\udaf1\udcca\udba0\udecb\u13ac\uda30\udd65\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8", "\ud867\udeff\udb56\udf57\ud950\udde3\ud9b4\udd2c\ud870\udd55\uda63\udce7\ud943\udd72\ud8b7\udd08\ud82d\udd85\u95ff\ud90c\udcf6\udabc\udec5\ud938\ude94",
        52, 56163, -2083399526, 7522472329697880882L, 73839L, true, true, (char) 54267, (char) 1477,
        Double.longBitsToDouble(0x3fce97526d12af58L), Double.longBitsToDouble(0x3feef9c29e549980L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 4, "\udbd3\udedd\udbd8\udfcc\uda35\udf07\ud871\udd42\ud92f\udc15\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udbd3\udfdc\udacb\udc20\ud930\udd72\ud904\udc0d\ud99b\uddff\u9761\ud8d6\ude12\udab3\udfca\ud883\udd09\udaf1\udcca\udba0\udecb\u13ac\uda30\udd65\udb24\udfd9\udbaf\udfa2\ud84d\udffe\udbba\ude4b\udaca\ude58\udb90\udca9\udb1f\udd01", "\u6798\u60e8", "\uda54\udd83\udb56\udf57\ud950\udde3\ud9b4\udd2c\ud870\udd55\uda46\udee7\udb02\udcd1\ud87c\udc78\udb9c\udec6\u95ff\udba1\udd27\ud8d1\udcb9\ud938\udeff",
        58, 56163, -2083399526, 7522685634148363058L, -32618L, false, true, (char) 39633, (char) 12058,
        Double.longBitsToDouble(0x3fdd6c95364687c4L), Double.longBitsToDouble(0x3fe70b47086420d6L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 5, "\ud836\ude43\ud8c4\udd03\ud9f1\udf58\ud94c\ude6e\ud92f\udc88\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\uda96\uded2\udb4f\udd39\ud8de\ude6f\uda73\udfe0\ud8c4\udc50\udaf3\udc2b\ud9bd\udef4", "\u5e36\u24f9\u4e8f\u408d\u1ac4\u9475\u1805\u64bc\uc872\u6922\u0fbb\u2f55\u6b40\u6345\u6798\u20a1\u9988\u524c\u8f1c\u62a4\ua5e6\u1da5\u50c1\u8776", "\ud9e9\udc6b",
        33, 88799, 1855318007, 4917094585580044435L, 96233L, true, true, (char) 64752, (char) 12300,
        Double.longBitsToDouble(0x3fd9ffab990a7f94L), Double.longBitsToDouble(0x3fe9b5af76129ce1L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.lang.Boolean:false |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 6, 6, 7, "\ud916\udc77\ud8dd\udfe8\uda35\udf07\uda77\udec6\ud92f\udccd", "\u57be\u15fb\u2b9d\u9bfb\ubf25\u2000", "\u6b27\ud838\udf22",
        35, 55548, 241040370, 4040308849408273447L, 49729L, false, false, (char) 44393, (char) 32539,
        Double.longBitsToDouble(0x3fd2d0fc546827baL), Double.longBitsToDouble(0x3feee0fd03bb1c4aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\udadc\udc86\uda86\udeb2\udaca\uddc4\udb4f\udd39\udad5\udc9f\uda01\uddc9\udbea\udcc5\ud835\udceb\ud99a\udccb\ud838\udf22\ud811\uddd7\ud883\udd09\udb68\ude81\ud848\ude3b\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud864\udf69\udbc4\udd19\udaca\ude58\ud85f\udc11\ud9ee\uddee", "\u6798\u7a17\ua5d9\u524c\u8f1c\u62a4\uad65\u1cb9\ubcf9\uc139\u3ed9\u12d7\uce2c\u78cc\u7ec5\u66dc\u9d5c\u4495\u5724\u156c\ud4c5\u6591\uc3ee\u8797", "\uda6b\udcdb\ud8a8\udca4",
        56, 8526, -861434805, 310444868466589845L, -74264L, true, true, (char) 2256, (char) 41513,
        Double.longBitsToDouble(0x3fe5a65fe9342c1bL), Double.longBitsToDouble(0x3fe2f13fb20192b9L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 8, 4, "\ue7af", "", "\ubdb8",
        35, 54576, -1065739887, 338952192L, 14411L, false, false, (char) 13912, (char) 25536,
        Double.longBitsToDouble(0x3fd81a4a948a374aL), Double.longBitsToDouble(0x3ecac00000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=null |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 10, 10, 4, "\ud8b0\udf26\ud949\udcab\ud8f6\udcb1\udbfc\udc0e\uda3d\udcb5\ud9ea\udf74\udb76\uddf2\udb0f\udc92\uda89\uddd2\ud953\udd2f\ud84d\udeaa\ud98d\udea7\ud8f0\udc2a", "\ucce4\u9245", "\udb09\udf94\ud848\uded1\udb22\udc57",
        18, 72785, -934158123, 8513823703591930114L, 7404L, false, false, (char) 3385, (char) 6678,
        Double.longBitsToDouble(0x3fe5eb1083cad69fL), Double.longBitsToDouble(0x3fd18e3096fbdea2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 4, "\udb26\udff2\udbc6\udeae\uda35\udf07\uda77\udec6\udb9a\udeb3\udacc\udfb2\u8ebe\ud8bf\udf67\uda7a\ude08\ud858\uded3\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b57\ud838\udf22\ud811\uddd7\ud87b\udf09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udeb7\ud84d\udffe\udb85\udf5c\ud9b9\ude87\ud9b6\udebe\udb1f\udcaa", "\000\ub15f\u8c7b\uae98\u2ab8\u6211\u3f40\ud4af\ubcf9\uc139\ua22a\uc319\ud3ed\uc6e0\u7f20\u66dc\u9d5c\u4495\u5724\u156c\u4449\u5e32\000\000\ubb1b\u61a8\uaeaa\u3e08\000\000\000", "\udb97\udc9b",
        9, 51353, 901416250, -3747720090165183820L, -100000L, false, false, (char) 43293, (char) 61318,
        Double.longBitsToDouble(0x3fe67c5a0b923303L), Double.longBitsToDouble(0x3feb54207741a90fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.chart.util.RectangleInsets:RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 14, 2, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\udb9a\udfa3\udacc\udfb2\u8ebe\ud8bf\udf67\uda7a\ude08\ud858\uded3\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b57\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udb85\udf5c\ud9b9\ude87\ud85f\udc92\udb1f\udd86", "\u6872\ub180\u8c7b\uae98\u2ab8\u6211\u3f40\ud4af\ubcf9\uc139\ua22a\uc319\ud3ed\uc6e0\u7f20\u66dc\u9d5c\u4495\u5724\u156c\u4449\u3943\uc3ee\u407b\uc6e0\u61a8\uaeaa\u294a\u3a77\u2059\u6a3a", "\udb97\udc9b",
        9, 51353, 901416250, -3747720090165183820L, -35141L, false, true, (char) 43293, (char) 61318,
        Double.longBitsToDouble(0x3fe67c5a0b923303L), Double.longBitsToDouble(0x3fec5d687741a90fL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=java.awt.geom.Rectangle2D$Double:java.awt.geom.Rectangle2D$Double[x=0.0,y=0.0,w=0.0,h=0.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 12, 12, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\udb9a\udfa3\udacc\udfb2\u8ebe\ud8bf\udf67\uda7a\ude08\ud858\uded3\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b57\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud91b\ude5a\udad2\udf55\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udb85\udf5c\ud9b9\ude87\ud85f\udc92\udb1f\udd86", "\u6872\ub180\u03e4\ubdb5\u2ab8\u6211\u3f40\ud4af\ubcf9\uc139\ua22a\uc319\ud3ed\uc6e0\u7f20\u66dc\u9d5c\u4495\u5724\u156c\u4449\u3943\uc3ee\u407b\uc6e0\u61a8\uaeaa\u294a\u3a77\u2059\u6a3a", "\udb97\udc6c",
        9, 51353, 901416250, -3747720090165183820L, -35141L, false, true, (char) 43293, (char) 61318,
        Double.longBitsToDouble(0x3fe67c5a0b923303L), Double.longBitsToDouble(0x3feb54207741a90fL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=void |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 1, 1, 0, "\udbbd\udc5b\udbc6\udeae\udb52\uddb1\udbf3\udedb\uda21\udeb7\udbf6\udd5a\ud9c2\udd2e\udab8\udcb5\ud933\udf4f\ud80a\udd83\uda5a\uddce\ud894\udee2\ud81f\udcf5\udaab\udde3\udbe5\udd59\ud9c5\udd3a\ud9fa\udcce\ud811\uddd7\ud883\udd09\uda22\udfdf\ud848\ude9b", "\u9c5b\uc094\u2648\u340f\ucdc1\u250c\u808b\u550c\u072b", "\ud9cf\udd0a\ud873\udc9a\ud867\udeff\udb56\udf57\ud972\ude98\uda81\ude72\ud8f0\udee1\udb73\uddd8\ud8a7\uddf2\udab5\udf57\ud861\udfb0\uda36\udfa7\ud844\udf23\uda0f\uddcb\udac8\uded9\udb5c\udfcd\u6efe\uda12\udd48\udbe7\udde0\udb4e\udd1a\ud8b0\udf0f\ud9eb\udc3e\udb8e\ude49\uda90\udd5d\ud9f2\udc9a\ud8db\udf67\uda8b\udf19",
        41, 1589, -1651227605, -2992014098820584275L, -21623L, true, true, (char) 8908, (char) 462,
        Double.longBitsToDouble(0x3fe1341ac86f0ea4L), Double.longBitsToDouble(0x3fdf481e51508f9eL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00ef", "",
        -5, -1000, 0, -1418250290L, -100000L, false, false, (char) 29311, (char) 3411,
        Double.longBitsToDouble(0x3fc13c60000292a4L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud88a\udd4e\udbc6\udeae\uda35\udf07\uda77\udec6\ud92f\udccd\udbf6\udd5a\ud992\udf80\ud8db\udf86\uda62\udc08\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udb0e\udcb9\ud848\uded1\udbe4\ude4b\uda30\udd29\udb24\udfd9\udbaf\udf4b\udb6e\udeae\udbba\ude28\udaca\ude58\ud85f\udc11\udb1f\udd86", "\u6798\u60e8\ua5d9\u482d\u8f1c\u62a4\u56e7\ud4af\ubcf9\uc139\ua22a\u8c01\u407b\u2da3\u7ec5\u66dc\u9d5c\u4495\u5724\u976b\u1375\u9220\uc3ee\u407b", "\uda6b\udcdb\ud8db\udffe\ud870\udc0b\udb58\udfd6\ud956\udd44\udbfd\udc37\ud90e\uddb4\udb97\udc9b\udbe1\ude0c\u6bd4\uda38\udc64",
        29, 3156, 670472500, 2162611118183653889L, 79189L, true, false, (char) 28168, (char) 20344,
        Double.longBitsToDouble(0x3fea0d4879707f6dL), Double.longBitsToDouble(0x3fa79b34b815aac0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.chart.util.RectangleInsets:RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 5, "\ud9fe\udf69\udbfd\udf3d\uda35\udf07\udba2\uddda\ud92e\udfec\udbf6\udd6c\ud992\udf80\ud8db\udf86\uda7a\ude08\ud835\udd20\udb36\udc25\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\ud838\udf22\ud811\uddd7\ud883\udd09\udaf1\udcca\udba0\udecb\udb28\udd7d\u1aeb\ud843\udd06\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\uda27\udc15\udb1f\udd86\ud943\udc84\udb83\udee6\ud93b\udf52\ud86c\udea6\ud84b\udeb6\ud83b\udef9\ud867\udeff\udb56\udf57\ud950\udde3\ud9b4\udd2c\ud870\udd55\udaa6\udf6a\ud888\udf3b\ud8b7\udd5f\ud82d\udd85\u95ff\ud90c\udcf6\udbaa\udcfd\ud9cb\udf6e\ud89c\uddbe\udaa6\udf02\uda94\ude9a\ud8a3\uddb7\ud800\udfd7\ud918\ude32\ud982\udd01\udb87\udf3e\ud955\udf0c\udb0e\udff9\uda17\udca2\ud973\udf77\udb3d\uddc2\udaf1\udf21\ud971\udc73\ud960\udc07\udaf0\udf66\ud9aa\udff4\ud8db\uddb6\ud80b\udc4b\uda51\udfd4\ud949\udc31\ued87\ud928\udfa8\uda39\udfa1\ud918\ude15", "\u38e0\uce89\u0f57\ua6ff\ud33f\u10ba\u0798\ub135\ud221\u47ce", "\udb87\udd9d\udaeb\udd9f\ud9ff\udc24\ud980\udffc\udb15\udfb5\ud863\ude32\udaba\udc2c\udb2d\udd20\ud852\udf42\uda4a\ude6c\ud886\udca3\udb08\udc30\udab5\udd6e\udb85\udd15\ud88b\ude79\ud8d2\udcea\ud940\uded8\ud8a9\udc8e\ud8c6\udf85\ud822\ude66\ud856\udcf8\udb40\udce4\uda30\udcf8\ud985\udd8d\ud875\udcd1\ud9bc\udc52\ud989\uddbc\ud9f2\udeea\ud82a\udea7\udb11\udd0b\udb2b\udc9e\uda45\udfd1\ud847\udc96\udb9c\udfcd\udac0\ude1b\udb53\udf7e\ud8cd\udc3e\ud92b\udca2\uda2a\udd81\udb97\udcdc\udbd3\udff4\ud916\udf7a\ud8f7\udf37\ud8fc\udee5\uda12\udd55\uda1f\udc65",
        3, 393, 1613874016, -3624188585243542969L, -72803L, true, false, (char) 19896, (char) 13019,
        Double.longBitsToDouble(0x3fd88a9c2d28343eL), Double.longBitsToDouble(0x3fc47d08b1a6c90cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\0121=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0 |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 2, 2, 2, 4, "\ud88a\udd4e\udbf3\uddc6\uda2d\ude9a\uda77\udec6\udaa5\uddcc\udbf6\udd6c\ud992\udf80\uda74\udd32\uda7a\ude16\uda96\uded2\udb4f\udd39\udb67\udd13\ud8f0\udc2a\udaab\udde3\udaf3\udc2b\u6b27\udb24\udf18\ud811\uddd7\udb6e\udc9e\udaf1\udcca\udba0\udecb\u13ac\udb00\udd6d\udb24\udfd9\udbaf\udf4b\ud84d\udffe\udbba\ude4b\udaca\ude58\ud85f\udc11\ud8be\udfb1", "\ucb3d", "\ud842\udfa2\ud867\udeff\ud929\udf3f\ud973\udd2d\ud9b4\udd2c\uda2f\ude35\uda63\udce6\ud943\udd72\ud8b7\udd08\ud82d\udd85\ud801\udecf",
        28, 83417, -1388583051, 9111862547563569475L, 84134L, false, true, (char) 28705, (char) 18027,
        Double.longBitsToDouble(0x3fd0f47a1e6d998aL), Double.longBitsToDouble(0x3fce739a33d2ea4cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud9aa\udd32\udbff\udcd0\uda35\udf07\uda77\udec6\udb21\udc26\udbf6\udcd7\udb2f\udff2\udb25\udca3\udb44\udc20\udbe2\udf27\udb4f\uddb0\ud9c5\udc22\ud91b\udfd8\ud8e0\udda9\udad5\udcc5\ud9cc\udcd6\uda33\udf3a\ud811\uddd7\ud883\udd09\uda20\udec2\ud839\udc8d\uda01\udd3b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud9b4\udc31\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86\ud9b9\ude3d\uda90\ude3e\ud93b\udf52\ud838\udeee\uda4c\udf2c\ud842\udfa2\udb54\udefb\ud8bd\udfa6\udada\udcab\u10fb\udb05\udc51\udbae\udfe4\uda6a\udcda\ud94d\udf69\uda44\udfbd\udbb2\uddc2\ud983\uddc2\uda3d\udf56\ud9c8\udc6d\ud987\udd85\udb7c\udfe7\ud828\udc1e\ud879\udf13\ud8ae\ude0a\ud859\udd93\ud941\udc6d\udb7f\udfc6\ue6d9\udbae\udca7\udbfe\udd4d\ud838\udcc9\ud841\udead\ud8db\udf9e\uda4f\udcb5\ud937\udf0a\uda46\udd60\udbec\udc69\ud93f\udfc2\ud8f5\udf6b\udb6a\udc0e\ud9bf\udfd8\udbc2\uddf4\udafc\udf71\udbcc\udce5\ud8df\udeb5\uda17\ude78\ud9be\ude38\ud88f\udc4d\udb3e\udd52\udacf\ude88\udb9e\udfcc\ud900\udfca\ud847\ude86\uda73\udc7a\ud81e\ude2d\udb02\udf63\ud843\uddd5\udb27\udf24\ud827\udd01\uda93\udcb7\udacf\udeef\udaee\udd36\u2c00\ud974\ude94\ud9ea\ude6d\ud81c\ude35\udbb1\udd41\ud91a\ude72\uda5e\ude2b\uda87\udf6c\udbf5\udc50\udbaa\udf09\ud8fa\udd95\ud836\udf76\udb79\udd72\ud96e\ude4b\ud8ce\ude62\ud8ae\udd61", "\ua8b9\u38ed\u91b9\u8335\ub058\u6771\u035d\u7c5f\ud6dd\u2d61\u97eb\ub1a3\u9738\u5a55\u2d9c\ua1a8\u1626\u0807\u5db3\u87a4\ud03f\u255b\u674e\ua033\u0afa\u5ded\ud50d\u4569", "\udb42\udc24\ud8c2\udc0b\uda27\udf8b\ud3ce\uda7c\udd14\u2d6f\udabc\udd83\udbd5\udd14\udb6d\udc3e\udbf3\udf4c\ud967\udea9\udb7a\udf08\udbcb\udd48\udadb\udd44\udb1a\udcf4\udbe6\uddd8\ud841\udffe\ua5b1\uda36\udd30\udbbc\udc94\ud9ee\ude69",
        25, 68591, 633697865, 6271400780762113313L, 53154L, true, false, (char) 60029, (char) 13471,
        Double.longBitsToDouble(0x3fe9b6dfe0402450L), Double.longBitsToDouble(0x3fa3ee905f665cb0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.awt.Color:java.awt.Color[r=128,g=128,b=128] |this=org.jfree.chart.axis.CategoryAxis:org.jfree.chart.axis.CategoryAxis@0\012",
        Z.run(T, 1, 7, 8, 4, "\ud9aa\udd32\udbff\udcd0\uda35\udf07\uda77\udec6\udb21\udc26\udbf6\udcd7\udb2f\udff2\udb25\udca3\udb44\udc20\udbe2\udf27\udb4f\uddb0\ud9c5\udc22\ud91b\udfd8\ud8e0\udda9\udad5\udcc5\ud9cc\udcd6\uda33\udf3a\ud811\uddd7\ud883\udd09\uda20\udec2\ud839\udc8d\uda01\udd3b\uda30\udd29\udb24\udfd9\udbaf\udf4b\ud9b4\udc31\udbba\ude4b\udaca\ude58\ud85f\udc11\udb1f\udd86\ud9b9\ude3d\uda90\ude3e\ud93b\udf52\ud838\udeee\uda4c\udf2c\ud842\udfa2\udb54\udefb\ud8bd\udfa6\udada\udcab\u10fb\udb05\udc51\udbae\udfe4\uda6a\udcda\ud94d\udf69\uda44\udfbd\udbb2\uddc2\ud983\uddc2\uda3d\udf56\ud9c8\udc6d\ud987\udd85\udb7c\udfe7\uda10\udd73\ud879\udf13\ud8ae\ude0a\ud859\udd93\ud941\udc6d\udb7f\udfc6\ue6d9\udbae\udca7\udbfe\udd4d\ud838\udcc9\ud841\udead\ud8db\udf9e\uda4f\udcb5\ud937\udf0a\ud80d\udf83\uda1f\udc44\ud93f\udfc2\ud8f5\udf6b\udb6a\udc0e\ud9bf\udfd8\udbc2\uddf4\udafc\udf71\udbcc\udce5\ud8df\udeb5\uda17\ude78\ud9be\ude38\ud88f\udc4d\udb3e\udd52\udacf\ude88\udb9e\udfcc\ud900\udfca\ud847\ude86\uda73\udc7a\ud81e\ude2d\udb02\udf63\ud843\uddd5\udb27\udf24\ud827\udd01\udb81\udc11\ud988\udd59\udb2d\udece\ud9cb\ude41\ud974\ude94\ud9ea\ude6d\ud81c\ude35\udbb1\udd41\ud91a\ude72\uda5e\ude2b\uda87\udf6c\u7251\udbaa\udf09\ud8fa\udd95\ud836\udf76\udb79\udd72\ud96e\ude4b\ud8ce\ude62\ud8ae\udd61", "\ua8b9\u38ed\u91b9\u3144\u2218\u8f91\u2427\u1038\ud6dd\u2d61\u97eb\ub1a3\u9738\u5a55\u2d9c\ua1a8\u1626\u0807\u5db3\u87a4\ud03f\u5b5a\u674e\ua033\u0afa\u5ded\u269c\u4569", "\udb42\udc24\ud8c2\udc0b\uda27\udf8b\ud3ce\uda7c\udd14\u2d6f\udabc\udd83\udbd5\udd14\udb6d\udc3e\udbf3\udf4c\ud967\udea9\udb7a\udf08\udbcb\udd48\udadb\udd44\udb1a\udcf4\u4cc2\ud841\udffe\ua5b1\uda36\udd30\udbbc\udc94\ud87f\udf51\ud973\udc6d\udba9\ude57\udb52\udc82\u8ae9\ud8f0\udf1b\udbd7\udd26\uda53\udc62\ud887\udf5f\uda68\ude32\ud9ed\udfa2\ud9b8\udd98\udab0\udc92\udb83\udd59\udb63\ude31\udafc\ude26\udacb\udebc\ud8f2\udd1a\udb42\udecc\ud93f\udd08\udbfc\udc4d\udaca\udcb1\uda68\ude68\udb51\udc96\udbf4\udc0c\udb6e\udde5\ud922\udfba\udad4\udfe2\ud90c\udea1",
        31, 94233, 834380869, -8931390853940262397L, 43358L, false, true, (char) 9344, (char) 43868,
        Double.longBitsToDouble(0x3fc270bd10ee585cL), Double.longBitsToDouble(0x3fec653d7f16ce05L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.chart.axis.Axis|drawLabel|java.lang.String,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge,org.jfree.chart.axis.AxisState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|addChangeListener|org.jfree.chart.event.AxisChangeListener|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|clone||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|configure||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|draw|java.awt.Graphics2D,double,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|drawAxisLine|java.awt.Graphics2D,double,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|equals|java.lang.Object|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getAxisLinePaint||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getAxisLineStroke||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getFixedDimension||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabel||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelAngle||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelEnclosure|java.awt.Graphics2D,org.jfree.chart.util.RectangleEdge|new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelFont||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelInsets||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|getLabelPaint||new:org.jfree.chart.axis.CategoryAxis:",
    "M|org.jfree.chart.axis.Axis|drawLabel|java.lang.String,java.awt.Graphics2D,java.awt.geom.Rectangle2D,java.awt.geom.Rectangle2D,org.jfree.chart.util.RectangleEdge,org.jfree.chart.axis.AxisState,org.jfree.chart.plot.PlotRenderingInfo|new:org.jfree.chart.axis.CategoryAxis:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
