package org.jfree.data;
import org.junit.Test;
import static org.junit.Assert.*;
public class KeyedObjects2D_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u3370\ud747\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 98226, -276076612, -8234863485165746023L, -19694L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f83be99fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u3370\ud747\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 59338, 644784111, -8235057828140922727L, -84206L, true, true, (char) 46136, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f83be99fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\u4292\uda9c\udd4e\ud9ed\udd23", "\ub8d9\u4ad0", "\ud85a\udf02\udaff\udc50\ud8e9\udd46\udac1\udd0d\udac7\udffd\ud962\udd4b\uda55\udea1\udbf6\udf7b\uda8a\udc38\ud98f\udd34\uda9a\ude2d\uda5a\udf3a\uda9a\udfc6\udae6\udc3e\udba3\udd34\uda53\uddb0\ud96f\udf87\ud94b\udef8",
        35, 13345, 2075732704, -3250602558986622030L, -92650L, true, false, (char) 63995, (char) 22843,
        Double.longBitsToDouble(0x3fece4f51186e213L), Double.longBitsToDouble(0x3fe4448a2308cb41L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2", "\000\udae5\udfad\udba3\udd34\uda53\uddb0",
        31, 95868, -1154918335, -6480786338244646176L, -92650L, true, false, (char) 20988, (char) 22843,
        Double.longBitsToDouble(0x3fece4f51186e213L), Double.longBitsToDouble(0x3f42288c232d0400L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\ud846\udd42\ud897\udf2b\uda3e\udee8\udb60\ude63\ud9ed\udd23", "\ub8d9\u4ad0\ua667\ub06e\uc214\u333f\uc628\u7d81\u2dd7\uc36e\u0348\u6c52\u143a\u9b2b\ud745\u0ca0\u646f\u3370\ud747\u23f0\u2270", "\ud84e\udddc\ud92d\udc15\udbc0\udd8a\ud933\udfd0\u06c2\udb7b\udf7d\uda4d\uddd5\ud9e2\udeb2\ud838\udc91\uda82\udf31\ud961\udee6\u800b\ud80f\udc10\ud993\udf7c\u4ea4\ud916\uddfb\udb6e\udf52\u8869\uda26\udd73\udaa9\ude02\uda82\udc38\ud92e\udd4f\uda91\udefc\uda56\uddf0\ud9a3\udd7b\ud99a\udfd3\ud8bd\udc57\udb4e\ude44\udb9a\udf4d\u824e\ud963\udf87\ud91f\udc5c",
        3, 8387, -441867239, -9059154294442641730L, 10892L, false, false, (char) 45536, (char) 23414,
        Double.longBitsToDouble(0x3fe38edccd2901e1L), Double.longBitsToDouble(0x3fe3bb7f14dafaf8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 1, 6, 13, 2, "\ud94c\udcbd\uda8f\ude33\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\ubffb\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u334d\ud765\u0ca0\u646f\u3370\ud747\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 98226, -276076612, -8234863485165746023L, -19694L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f8bd2026L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\uac1c\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\ua1a6\uc0dc\uca39\u2270", "\ud84e\udddc\uda22\ude2a\ud991\udf89\udb30\ude9c\udae9\udec3\udb7f\udc8d\uda4d\uddd5\ud9a7\udc4a\ud838\udc91\uda11\uddd8\ud9a6\udeff\ud8cc\udf6c\udbd6\udcd4\ud993\udfcd\ud974\udd74",
        33, 63557, 552312253, -5973408924380810925L, 90739L, false, true, (char) 53029, (char) 2417,
        Double.longBitsToDouble(0x3feed8641af90e45L), Double.longBitsToDouble(0x3fb9f102fdb14930L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 14, 13, 18, "\uda47\udc2c\uda8b\udceb\ud97f\udcf9\udb7e\udea0\udabb\uddd1\ud9ed\udd23", "\ub8da\ub219\u0111\u773f\u69d7", "\ue88e\ud929\udd2d\ud8c2\udff3\ud92a\udfe7\ud916\udf96\ud817\udefd\ud80b\udd91\ud89c\udcaf\u9d8d\ud939\udef5\ud905\udc25\udba3\udd34\uda53\uddb0\ud96f\udf87\ud907\udcb7\udb2c\udfa7",
        23, 80704, -756854734, -1323939878474651716L, 12487L, false, true, (char) 64496, (char) 39190,
        Double.longBitsToDouble(0x3fe29f109e889144L), Double.longBitsToDouble(0x3fd87cb413ce526aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 20, 10, 6, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u7ea6\u6515\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2\u64ce\u3f69\u6542\u3370\ud747\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 98204, -278970436, -8234863485165746023L, -19694L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706fb3be99fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\uda82\udead", "\ub8d9", "\uda27\udcbb\ud85a\udf02\udaff\udc50",
        23, 45571, 213514726, -3432195243454495967L, 38783L, true, false, (char) 3982, (char) 459,
        Double.longBitsToDouble(0x3fd29a4e6b23f3c0L), Double.longBitsToDouble(0x3fe1596ba2ce3390L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 18, 19, "\ud908\ude3a\uda8b\udc83\ud972\udcff\udb7e\udf28\udabb\uddd1\uaa0f", "\ub8d9\ub94c\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u6429\uc437\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u3370\ud747\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 98226, -276076612, -8253159358651938663L, -19694L, false, true, (char) 40144, (char) 40978,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f83be99fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u3370\ud747\u5e5d\u5c5f", "\ud865\ude08",
        14, 53114, -308253774, -1185740021647809718L, 29312L, false, false, (char) 65086, (char) 45977,
        Double.longBitsToDouble(0x3fe4448a2308cb41L), Double.longBitsToDouble(0x3fd5289c058dc1beL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 14, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\uda92\uddf5", "\ud503\u3d5f\ua667\u934c\u1dd0\u18ec\uc628\u7d81\u2dd7\uc36e\ub8e1\u1eac\ub0e1\u32f2\uc9f3\u2910\u6522\u8d32\u8170\u23f0\u95bd", "\uda94\udd8d\ud820\udf9c",
        24, 86154, 2128896399, 219166029961162191L, 81838L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fee6fec91b989c0L), Double.longBitsToDouble(0x3fcb9479f8edfda8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\uda18\udd76\udbb9\udea2\udabb\uddd1\ud9ed\udd23\ud80e\udd42\ud8f4\udc27\udb80\udd74\ud8dc\uddb5\ud831\udca8\uda3a\udfbb\ud85a\udf02\udaff\udc50\ud8e9\udd46\udac1\udd0d\udac7\udffd\ud962\udd4b\uda55\udea1\udbf6\udf7b\uda8a\udc38\ud863\udd7d\ud9c2\udc03\uda5d\udf4e\uda9a\udfc6\udae6\udc3e\udba3\udd34\uda53\uddb0\ud96f\udf87\ud94b\udef8\ud9dc\ude32\ud84e\udddc\uda22\ude2a\uda11\ude59\udb30\ude22\udae9\udec3\udb7f\udc8d\ud8a4\ude39\uda6a\udf76\uda00\udece\uda11\uddd8\ud9a6\udeff\ud8cc\udf6c\ud80f\udc10\ud993\udf7c\ud974\udd74\ud987\udd85\udae5\udc14\ud9c2\udd52\ud8f2\udcfc\uda55\ude1b\ud90c\ude69\ud9a1\udeb2", "\uc322\u8a44\u34a4\u54fd\u9490\u7a41\ucab2\u694b\u98f0\u45a4\ud3fd\u61a2\u7c87", "\udbf0\ude7a\ud817\udfa9\uda08\udd19\udbd7\ude58\ud8f1\udca8\ud863\udcc5\ud951\udd37\uda81\udf1c\uda2e\udd69\udb89\udfff\ue4b5",
        14, 77420, -542659698, -166236362315249229L, 34909L, false, true, (char) 20144, (char) 59899,
        Double.longBitsToDouble(0x3fe9416b0dc71a42L), Double.longBitsToDouble(0x3feb527bc850dc52L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 1, 2, "\udb15\ude77\uda8b\udcf2\udbb3\ude25\udb7f\udcd0\udabb\uddd1\ud9ed\udd23", "\u9534\u4a57\ua667\u43fc\uc8b1\u2529\uc628\u7d81\ud4d7\uc36e\u5d07\u6b42\u954d\u32f2\u401b\u0ca0\u646f\u3370\ud747\u9c8f\uc264", "\ud84e\udddc\uda22\ude2a",
        24, 98226, -276076612, -8234863485165746023L, 69138L, true, false, (char) 58274, (char) 35529,
        Double.longBitsToDouble(0x3fab666d95207c80L), Double.longBitsToDouble(0x3febcf06f83be93aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 15, 13, 2, "\ud908\ude61", "\u1455\u733b\u15fb\u1834\u78a0\ub8d9\uc55b\ua667\ub2aa\u79df\u33a2\uc628", "\ud8fa\udff9\uda55\udea1\udbf6\udf7b\uda8a\udc38\ud98f\udd34\uda9a\ude2d\uda5a\udf3a\uda9a\udfc6\udae6\udc3e\udba3\udd34\uda7b\udf79\ud96f\udf87\udb59\udeff\ud9b8\udff1\ud98a\udd74\ud923\udcd9\ud992\udc60\udb30\ude9c\udae9\udec3\udb7f\udc8c\ud94a\ude54\ud995\udde6\udac2\udd4a",
        45, 80630, -884928888, -8520534483728860846L, -93403L, false, false, (char) 41572, (char) 16198,
        Double.longBitsToDouble(0x3fe6a13a80b44bd8L), Double.longBitsToDouble(0x3feac85fef5e4be6L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 21, 15, 2, "\udb4b\udf41\udba2\udfb9\ud9d7\udd76\udb7e\udf50\uda36\udf2e\udb52\udc15\u1c39\ud965\udd80\udb80\udd44\ud9a2\udc78\ud90e\udd75", "\u33a2", "\udac7\udffd\uda75\udd36\uda60\udfbd\ud810\udf99\ud931\udf14\ud948\udd3c\udbe1\udd73\uda5a\udf3a\uda9a\udfc6\udae6\udc3e\ud9e9\udd2d\uda53\udd3e\ud922\ude5f\ud944\udec6\ud9b9\udc32\ud86c\udc72\uda91\udf27",
        24, 23570, -742731095, -8234863270417381223L, -66L, false, true, (char) 45977, (char) 54170,
        Double.longBitsToDouble(0x3fe8465a0ddbf2ceL), Double.longBitsToDouble(0x3fe04ed5902be97eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 8, 13, 20, "\ud908\ude3a", "\u16df\u0dea\u0541\u540e\000", "",
        -5, -792, 939524096, 18002102018113536L, -100000L, false, false, (char) 44643, (char) 43351,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe800000099a131L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 15, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u8159\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u3370\ud747\u23f0\u2270", "\ud859\udf83\ud8cd\ude61",
        24, 98226, -276076612, -8234863485165746023L, -3545L, true, true, (char) 45977, (char) 22589,
        Double.longBitsToDouble(0x3fa02a386e0ebbe0L), Double.longBitsToDouble(0x3fe5a7d3603be99fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 8, 2, 1, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\ud8b5\ude8c\ud838\udf10", "\ub8d9\u57d0\u3c21\u7db6\u2068\u819e\u831a\u1f76\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2", "\u47c3\udbd6\udf4f\udb5e\ude1f\uda53\uddb0",
        -3, 74864, -1154896280, 4629875417453270603L, -92650L, true, false, (char) 20988, (char) 22843,
        Double.longBitsToDouble(0x3fdbb8a4930dc4e6L), Double.longBitsToDouble(0x3fec5db4c4390692L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 1, 2, "\ud8e6\udc9c\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u43fc\u6c8c\u33a2\u7e93\u7d81\u2dd7\uc36e", "\ub12a\ud870\ude82\udb15\ude9f\ud927\udc95\udadd\udc86\uda21\udd93\udb7e\udc64\ud803\udcdf",
        21, 11515, -1154918366, -6480786338244646176L, 69038L, false, true, (char) 48723, (char) 54864,
        Double.longBitsToDouble(0x3fd2058dcc9d25daL), Double.longBitsToDouble(0x3fd5a9ea230dc426L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 2, 11, "\ud8d4\udd4c\uda8b\udc83\ud89d\udf5d\udb7e\udedb\udabb\ude2b\ud9ed\udd23", "\ud51e\u4ad0\u0c67\u43fc\u7a79\u308d\u6ff1\u1f0b\u658b\uc36e\u1545\u3293\u7ee2\u496a\u9f8c\u336f\u646f\u3370\ud747\u23f0\u49ae", "\ud84e\udddc\uda22\ude2a",
        44, 98226, -276076612, -1954085830425525981L, 97880L, false, false, (char) 15122, (char) 43482,
        Double.longBitsToDouble(0x3f9d1de002f79560L), Double.longBitsToDouble(0x3fe6e69752d1d7d2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 1, 19, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u3370\ud747\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 98226, -276076612, -8234863485165746023L, -19694L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f83be99fL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 1, 7, 13, 12, "\ud8fd\udd52\ud801\udf53\udbdf\ude6c\udb7e\udf28\udabb\uddd1\ud9ed\udd23\ud82e\udf52\ud86e\udeec\ud889\udd2e", "\u43fc\uc00e\u16ec\u6fc8\u7d81\u2dd7\uc5e2\u37a2\u563d\u61f9\u4ba2\u73b3", "\uda1d\udfac\udba3\udd34",
        28, 82825, -595623004, 4799178577017500779L, -42150L, false, true, (char) 22877, (char) 9727,
        Double.longBitsToDouble(0x3fef9cedb9205832L), Double.longBitsToDouble(0x3fe274976f9c9ea2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 8, 16, 15, "\ud9ee\udf0d", "\u16df\u0dea\u15fb\u1834\u636d", "\ud831\udca8",
        29, 48968, 2134897873, 7734086780215913307L, -12465L, true, true, (char) 24911, (char) 22975,
        Double.longBitsToDouble(0x3fe14920d7c4efc9L), Double.longBitsToDouble(0x3fc3342630a69398L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 1, 9, 13, 10, "\ud908\ude3a\uda8b\udc83\udbe1\udda9\udb7e\udf28\udabb\uddd1\ud8f2\udea6", "\u9829\u4ad0\ua667\ud4fb\u8989\u33a2\uc628\u7d81\u51fd\u8859\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u3370\ud747\u23f0\u883d", "\ud84e\udddc\uda22\ude2a",
        24, 98226, -276076612, 2659989423921080350L, -22245L, false, false, (char) 19647, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f83be99fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 1, 17, 13, 2, "\uda9a\udf06\uda74\ude52\udbe1\udcfb\udb7e\udf28\ud9e2\uddc4\ud9ed\udc7f", "\u8105\uc154\uc7f8\u4426\u7a79\u10f7\u6092\u7d81\uca31\u7c9d\u5726\u336c\ub0e1\u1b3e\ud6ea\uaf96\u646f\u9970\ud747\u32ec\ubdb5", "\ud9a8\ude5b",
        11, 60756, -308253774, 225294038244847764L, 29312L, false, false, (char) 37868, (char) 45977,
        Double.longBitsToDouble(0x3fc11c088f60a298L), Double.longBitsToDouble(0x3fae700824e9aca0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 2, 11, 13, 2, "\ud908\ude3a\udaf2\udf37\udbd0\udc29\ud9f7\udef9\ud9fa\uddc3\ud9ed\udd07", "\ub8d9\u4ad0\ua667\u43fc\u7a79\u33a2\ubdd4\u2ac2\u5f8f\ub498\u831e\u1a86\u26b9\u32f2", "\uda9a\udfc6\udae6\udc3e\udba3\udd34\uda01\udd85",
        31, 95868, -1154918335, -4157930585625501064L, -26752L, false, false, (char) 5638, (char) 45971,
        Double.longBitsToDouble(0x3fe4448a2308cb41L), Double.longBitsToDouble(0x3fd5289c058dc1beL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\udae4\udeff\udb4e\udeeb\ud965\udd80\udb80\udd44\udac4\udda9\ud831\udca8\uda3a\udfbb\ud85a\udf02\udaff\udc50\ud827\udd45", "\uc36e\u5d07\u7fab", "\uda30\udcf7\uda5a\udf3a\ud87c\udc1c\udae6\udc36",
        16, 87670, -1863377389, 4071117327409174593L, 92897L, false, true, (char) 33554, (char) 15270,
        Double.longBitsToDouble(0x3fadf4cf8841cce0L), Double.longBitsToDouble(0x3fb9f408ae9c5668L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\000", "", "\ud9ed\udd23",
        21, -848, 0, 4677214583358272871L, -100000L, false, false, (char) 32306, (char) 54959,
        Double.longBitsToDouble(0x3fd5c1cd0423d190L), Double.longBitsToDouble(0x3fedebd537f8a957L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 15, 17, 2, "\ud908\ude3a\udb6f\udefe\uda52\ude00\udb7e\udf28\udad8\udcd1\u8018", "\u3772\u4ae5\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u32f2\ud765\u0ca0\ubc93\u205a\ud747\u76bd\u2270", "\ud84e\udddc\ud9de\udef3",
        24, 59338, 644784111, -8235057828140922727L, -84206L, true, true, (char) 46104, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f8d699daL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 13, 6, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23\ud80e\udd42\ud965\udd80\udb80\udd44\ud8dc\uddb5\ud831\udca8\uda3a\udfbb\ud82c\udc9c\udaf9\udc03", "\u2dd7\uc36e\u5d07\ud470\ub2d1\u3df1\ud765\u0ca0\u646f\u3370\ud747\u23f0\u2270\u369a\u6eaa\u4c90\u3583", "\ud889\uddbf\ud92a\udd91\uda4d\udd53\ud9e2\udeb2\ud8da\udc41\udbb7\udf54\ud9a6\udeff\ud8cc\udf6c\ud80f\udc10\ud993\udf7c\ud9f4\udd74\ud988\udfe6\udba5\udccd",
        7, 70814, 115471589, -193265524732369040L, 24819L, false, true, (char) 35338, (char) 42672,
        Double.longBitsToDouble(0x3fac8968c370da70L), Double.longBitsToDouble(0x3fd66e3100239b3eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 1, 6, 3, 12, "\uda22\udd9d\u604e\udbe1\udda4\udb7e\udf28\ud82f\uddec\ud9ed\udd23", "\ub8d9\u4ad0\u8edc\ubd50\ua399\u33a2\uc628\u7d81\ud11e\uc438\u97a2\u6b2d\u20bf\u2eda\u8b83\ub95d\u78d3\u507f\u78c2\u40b7\u88a0\u545d\u6eaa\u5ed1\u4b02\u026b\u93c3\u08ce\u4769\u40e4\ud3fa\ud7cb\u7c24\ud636\u21b9", "\ud817\udf8b\uda5e\ude94\ue17e\ud9d4\udf3e\ud905\ude9b\udbd4\uddc7\ud8d4\udf51\ud827\udfbd\udbb9\udd8c\udbca\udd0c\ud823\udd04\ud84f\udde6\udb22\udc52\ud979\udea6\uda9b\udde5\uda3a\ude73\udbe3\udf68\udbb0\uddff\ud905\udfb2\udbfe\udc5f\ud96b\uded9\ud8fb\udd20\ud919\udf30\ud827\udf3a\udbbb\udc31\ud8fe\udc04\uda0d\udf55\ud902\udc67\udb69\ude5f\udaae\udca8\udb3e\udd2d\ud948\udd06\ud85a\udfdf\u57c9\udad1\udec1\ud901\udd94\uda10\udcdc\uda2c\ude9b\ud985\udcdb\ud9a0\ude73\ud987\udd5b\udadd\udd10\ud8d2\udf55\ud914\udf87\udacd\udc93\udbca\ude0b\udbab\ude19\ud9f4\udc61\ua626\udaeb\udc56\udb7e\ude9e\ud913\ude3c\udb9b\udfb8\ud807\ude2c\ud90b\udc92\ud823\ude3b\ud8cb\ude96\uda23\udf61\u2dc4\uda81\ude62\udb70\udcde\ud9d1\udf43\ud9b8\udc91\ud9a6\ude83\ud92a\udc1d\uda6c\ude1e\ud97b\udd2a\udbcb\udcd8\uda25\udcdb\ud896\ude3d\uda0c\udc7f\ud8c5\udd04\udb41\udc5f\udadb\udfd3\uda61\udd5f\ud8a9\udfa6\ud951\ude6d\udb2e\udcec\uab87\udaff\udf38\uda67\udd53\ud90b\udca1\ud979\ude81\udbc9\udddd\ud999\udce2\udaba\udf5a\ud9ab\udf71\udb1b\udc1c\ud9c1\udc00\udab6\ude7f\uda5e\udd1c\ud95d\udffe\uda32\udc2d\udb2e\udd9a\udb2b\udc20\uda01\ude68\udaeb\udc5b\ud94a\ude8e\ud9e8\uddfb\udba1\udd62\udae9\udee8\ud97b\udf31\ud868\udfbb\ud8af\udca1",
        22, 61089, 1071288278, -4149472320441588042L, -99743L, true, true, (char) 17212, (char) 5823,
        Double.longBitsToDouble(0x3fe546343f0c3b7dL), Double.longBitsToDouble(0x3fd423f5677edfc4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 9, 0, "", "", "\udabb\uddd1",
        7, 89112, -310948200, 1508741098211167714L, -100000L, false, true, (char) 11562, (char) 32306,
        Double.longBitsToDouble(0x3feadb5aa15c1cd0L), Double.longBitsToDouble(0x3fe08f4643bd7aa6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!org.jfree.data.UnknownKeyException\012",
        Z.run(T, 2, 8, 19, 2, "\ud94c\udcbd\uda8f\ude33\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\ub8d9\u4ad0\ua667\ubffb\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u5d07\u1eac\ub0e1\u334d\ud765\u0ca0\u646f\u3370\uc10e\u2407\u2270", "\ud84e\udddc\uda22\ude2a",
        43, 62170, -276076612, -8234863486766602599L, -19694L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f8bd2026L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=java.lang.Boolean:false |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 9, 18, "\uda29\ude87\udaaa\udca6\ud954\udfbb\ud8d2\ude7d\udab9\udcd1\ud9ed\udd23", "\ub8da\ub219\u0111\u5905\u6965", "\ue88e\udbd8\udd85\ud860\udcf1\ud8b9\ude8e\ud96b\udd79\ud817\udefd\ud80b\udd91\ud89c\udcaf\uee76\ud8e6\udccb\uda77\udf27\udb53\udc55\uda53\uddb0\ud96f\udf87\ud907\udcb7\udbb6\udfac",
        23, 80704, -756854734, -1323939878474651716L, -53049L, false, true, (char) 64602, (char) 39190,
        Double.longBitsToDouble(0x3fe29f109e889144L), Double.longBitsToDouble(0x3fd87cb413ce526aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 7, 18, "\uda47\udc2c\uda8b\udceb\ud97f\udcf9\udb7e\udea0\udabb\uddd1\ud9ed\udd23", "\u0b18\ub219\u0111\u773f\u69d7", "\ue88e\ud929\udd2d\ud8c2\udff3\ud92a\udfe7\ud916\udf96\ud817\udefd\ud80b\udd91\ud89c\udcaf\u9d8d\udb9f\udcf1\uda8d\udf0d\ud953\udfd3\ud940\udc4d\ud90d\udf80\ud9c8\udf16\udb2c\udfcf",
        23, 92760, -1483123977, -1323940209187133508L, 12487L, false, true, (char) 20783, (char) 39190,
        Double.longBitsToDouble(0x3fe29f109e889144L), Double.longBitsToDouble(0x3fd87cb413ce526aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 2, 8, 8, 13, "\ud908\ude3a\ud8b5\udc38\udbe1\udcfb\udb7e\udf28\ud907\uddd7\ud9ed\udd23", "\ub8d9\u4ad0\ua667\u7ea6\u6515\u33a2\u1763\u45b4\u2dd7\uc36e\u5d07\u1eac\ub0e1\u3e2f\u4967\u34df\u6542\u3370\ud747\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 98204, -278970436, -8234863485165746023L, -19694L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706fb3be99fL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 20, 16, 19, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28", "\u1834\u78a0\ub8d9\u4ad0\u1f67\u7ea6\u6515\u205f\uc628", "\ud962\udd4b\ud809\udf7a\ud87f\udc0b",
        35, 8937, -1061085244, 14579133232916981L, -19573L, false, false, (char) 51110, (char) 5267,
        Double.longBitsToDouble(0x3fb04e1ff94dd948L), Double.longBitsToDouble(0x3fe705307a327bb9L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 20, 7, 6, "\ud908\ude3a\uda8b\udc83", "\u0dea", "\udabc\udfac\u3beb\ud8dc\uddb5\ud831\udca8\ud93d\udf7d\ud85b\ude22\udafe\udfff\ud8e9\udd46\udac1\udd0d\udac7\udffd\ud962\udd4b",
        50, 11240, 605691416, -1168158361711992892L, -42163L, false, true, (char) 37056, (char) 23233,
        Double.longBitsToDouble(0x3fe705307a327bb9L), Double.longBitsToDouble(0x3fda64799d2221a2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 20, 12, "\u8b68\udad8\uddab\uda05\udcd6\ud86b\udfa2\ud9e3\udc2a\uda82\udead", "\ub8d9", "\uda98\udc42\ud85a\udf02\udaff\udc50",
        29, 45571, 213514726, 3278660782536786733L, 38783L, true, false, (char) 21133, (char) 27005,
        Double.longBitsToDouble(0x3fd29a4e6b23f3c0L), Double.longBitsToDouble(0x3fe1596ba2ce3390L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "", "\000\000\000\000\u0221\u78e7\ub8d9\u4ad0\ub567", "\u00d1",
        -5, 18088, 0, -3432195244832063488L, -100000L, true, false, (char) 201, (char) 41216,
        Double.longBitsToDouble(0x3fd000000001f3c0L), Double.longBitsToDouble(0x3d79800000000000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 18, 20, "\udb15\ude77\uda8b\udcf2\udbb3\ude25\udb7f\udcd0\udabb\uddd1\ud9ed\udd23", "\u9534\u4a57\ua667\u43fc\uc8b1\u2529\u60d2\u0f95\ud4d7\uc36e\u5d07\u6b42\u954d\u9ad9\u2047\u0ca0\u646f\u3370\ub348\u9c8f\uc264", "\ud84e\udddc\uda22\ude2a",
        24, 39658, 1384034338, -8234863141568362343L, 69138L, true, false, (char) 58274, (char) 35529,
        Double.longBitsToDouble(0x3fab666d95207c80L), Double.longBitsToDouble(0x3febcf06f83be93aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 1, 2, "\udb15\ude77\uda8b\udcf2\udbb3\ude25\udb7f\udcd0\udabb\uddd1\ud9ed\udd23", "\u9534\u4a57\ua667\ua447\uc8b1\u2529\uc628\u42fb\ud4ff\uc36e\u5d07\uc05a\u9610\u32f2\u56ca\u2cf7\u2f33\u14b7\ud6c2\u9c93\uc264", "\ud84e\udddc\uda22\ude2a",
        27, 76430, -276076612, -8234863485165746023L, 69138L, true, false, (char) 58274, (char) 35529,
        Double.longBitsToDouble(0x3fab666d95207c80L), Double.longBitsToDouble(0x3febcf06f83be93aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 20, 9, "\udb15\ude77\uda8b\udcf2\ud94c\udf30\ud8fe\udfd3\udabb\uddd1\uda6e\udc1e", "\u9534\u4a57\ua667\u8dd2\u7877\uaf1b\u08be\u05d4\u2019O\u772d\u262f\u6da5\ub19f\uc059\ub4bf\u843e\u3390\ud747\u0fa4\u4993\u369a\u6eaa\u4c90\u30c2\ud411\u3db9\u526b\u63d7\u59ea\u01a3\u4220\u6541\u4d5e\ua576\u60b1\u0c18", "\udb4c\uddeb\udba2\udde4\udbcd\udcbb\uda31\udcf6",
        -1, 45318, 1643140751, -4784604348590234637L, -79534L, true, true, (char) 63647, (char) 6473,
        Double.longBitsToDouble(0x3fe1e8b2fe779064L), Double.longBitsToDouble(0x3fdb2fd556de4c9eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 21, 4, "\udb15\ude77\uda8b\udcf2\udbb3\ude25\udb7f\udcd0\udabb\uddd1\ud9ed\udd23", "\u015b\u4a57\uca67\u43fc\u335d\u4855\u2aae\u7d81\ud4d7\uc36e\u5d07\u6b42\u954d\u32f2\u401b\u0ca0\ub8ed\u3370\ud747\u9c8f\uc264", "\ud84e\udead\uda22\ude2a\ud991\udf89\udb30\ude9c\udae9\udec3",
        24, 70513, -1829897952, 8937981886324333287L, -71842L, false, false, (char) 282, (char) 23641,
        Double.longBitsToDouble(0x3fadf49d587912c0L), Double.longBitsToDouble(0x3fd652a4db56af40L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 0, 15, "\udb4b\udf41\udba2\udfb9\udbe7\ude5e\udb7e\udf36\udb16\udf7d\uda92\udeb7\u1b70\ud965\udd80\uda28\udf18\ud9a2\udc78\ud8f5\udc75", "\u74d0\u8950\ub613\u2e28\ucb5c\u734d\uc95a\ub5ab\ua72c\u2af2\u0ca0\u4f63\u67b3\u7653\u05ea\u5cfb", "\ud86f\udda8\ud9fb\udccf\ud996\udf35\ud9ba\udea1\ud83e\udc0d\ud815\udc29\u2161\ud9bf\udfc8\uda5f\ude27\ud9e4\udf8e\udaff\udddf\udb29\udfcf",
        35, 53787, -377614839, -5458257010815998989L, 56890L, false, false, (char) 13398, (char) 36289,
        Double.longBitsToDouble(0x3fd5e607f67cd250L), Double.longBitsToDouble(0x3fdf3ba7d503caaeL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=java.lang.Boolean:false |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 2, 11, 9, 2, "\ud908\ude3a\udaf2\udf37\udbd0\udc29\ud9f7\udef9\ud9fa\uddc3\ud9ed\udd07", "\ub8d9\u4ad0\ua667", "\udaff\udc50\udb9a\udd03",
        41, 69133, -1272734078, -1628088759643293704L, 7049L, false, true, (char) 27721, (char) 8464,
        Double.longBitsToDouble(0x3fd91f97b4565ae8L), Double.longBitsToDouble(0x3fe4c19c8613a9eeL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=void |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 2, 20, 20, 14, "\ud908\ude3a\udb5c\udf1c\ud98b\udc1a\udb94\udf3e\udad8\udcd1\u8018", "\u3772\u4ae5\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u0d08\u8580\ua736\u32f2\ud765\ub18b\ua973\u205a\ud747\u7e93\u0f6c", "\udae0\udde0\ud9de\udef3",
        24, 59338, 644761583, -6474632558461203186L, -35736L, false, true, (char) 51238, (char) 23216,
        Double.longBitsToDouble(0x3fd87657c2b805f4L), Double.longBitsToDouble(0x3fd58f004148e642L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\0121=java.lang.Boolean:false |this=org.jfree.data.KeyedObjects2D:org.jfree.data.KeyedObjects2D@367\012",
        Z.run(T, 2, 9, 9, 9, "\udb6c\udff2\ud916\udfc9\uda52\ude00\udb71\ude62\udad8\udd1a\u8018\ud80e\udd29\ud92e\udc03\ud9f3\ude1f\ud8aa\udc40\ud9b6\uddaa\udac4\udf3a\ud85a\udeba\udb6d\ude58\ud8e9\udd46\ud958\ude16\udb40\udee2\ud962\udd4b\ud9ff\udc17\ud8d8\uddb2\ud9a0\udfb3\ud98f\uddd8\uda9a\ude2d\uda5a\udf3a\ud9ea\udd1a\udae1\udd28\udba3\udd34", "\u369a\u6eaa\u057b\ubd8b", "\udb30\ude32\udb52\udfcc\uda4d\uddd5\ud9e2\udeb2\ud8da\udc41",
        53, 32110, -884928866, -8520533942562981550L, -83830L, true, true, (char) 50781, (char) 37150,
        Double.longBitsToDouble(0x3fe7c11b0fec680eL), Double.longBitsToDouble(0x3fde281889104ca2L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=org.jfree.data.KeyedObjects2D:@? |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 8, 19, "\u8b68\udad8\uddab\uda05\udcd6", "\ud03b\uc58f\u4a1d\u183c\u4a55\u4655\u503e\u7a50", "\ud842\uddee\udbc8\udca5\ud9a7\udf4a\udaf0\udc03\ud92d\udd01\uda8a\udc3f\ud8b6\udd27\ud891\udf07\ud802\udf2c\udad3\ude87\udae5\udf7f\ud952\udd07\udb8f\udf1c\uda6c\udfeb\udbba\udc3a\udaf3\udc5d",
        35, 74133, -1163911403, 3818735256430100559L, -53880L, true, true, (char) 39971, (char) 61011,
        Double.longBitsToDouble(0x3fc420dd35eb9318L), Double.longBitsToDouble(0x3fb33fa94efbd5f0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 13, 2, "\ud908\ude3a\uda8b\udc83\udbe1\udcfb\udb7e\udf28\udabb\uddd1\ud9ed\udd23", "\u67f6\u4ad0\ua667\u43fc\u7a79\u33a2\uc628\u7d81\u2dd7\uc36e\u29f0\u1eac\ub0e1\u32f2\ud765\u0ca0\u646f\u9395\ud72c\u23f0\u2270", "\ud84e\udddc\uda22\ude2a",
        24, 98206, -276076612, -8234863485165746023L, -19694L, false, true, (char) 45977, (char) 40908,
        Double.longBitsToDouble(0x3fe8465a095289c0L), Double.longBitsToDouble(0x3fe63706f83be99fL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 20, 12, "\u8b68\udad8\uddab\uda05\udcd6\ud86b\udfa2\ud9e3\udc2a\uda82\udead", "", "",
        55, 32121, 945409968, 9169316546646900467L, 32634L, false, false, (char) 12461, (char) 31021,
        Double.longBitsToDouble(0x3fe0fb263629241aL), Double.longBitsToDouble(0x3fee2196484c0931L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 20, 12, "\udbe1\udff1\udbdf\udc8e\uda05\udcd6\ud86b\udfa2\ud9e3\udc2a\uda82\udead\udbd5\udde5\ud965\uddc7\udb80\udd44\ud8dc\uddb5", "\u7a79\u33a2", "\udbff\ude08\ud9a7\udf4a\udaf0\udc03\ud92d\udd01\uda8a\udc3f\ud8b6\udd27\uda9e\udc4e\ud8b2\udd78\uda41\udd61\udb76\udd2d\ud914\udd0d\udaf8\udc62\uda9f\udd05\ud8fe\udf20\ud96f\ude5b\uaa7f\ud067\uda00\udf6c\uda19\ude89\ud845\udf66\ud8e1\udea0\ud9d4\udc14\ud8f0\ude42\ud8ca\udd41\udb07\udc52\ud9c3\udc45\udbbd\udc12\udae7\udd3d\udb26\udecc\udbe9\udc60\ud9ea\udf40\uda38\udea2\uced8\ud871\udcaa\ud81e\uddf9\udb82\udf8e\ud92f\udd05\ud894\udcb7\uda03\udf96\udbdf\udc19\ud9f1\udf53\u2778\ud88e\ude70\uda5a\udfed\udb5a\udd0a\udaaa\udf8c\ud9a4\udd82\udb53\udf46\ud9c6\udce9\ud981\ude9e\uda61\udeb9\uda60\udee3\uda03\udc08\ud830\udc13\udbd2\udf00\udb0f\udf95\udb22\udecd\udbff\udd47\ud96a\udc98\ud97c\udcfd\udb0b\udc70\ud858\ude11\u934f\ud8e4\ude57\ud939\udf3b\ud96e\udfd3\uda80\udfa0\ud83e\ude68\udbce\uddcd\u0864\ud85a\ude03\ud841\udfd9\udbf3\udc73\ud9be\udd22\uda81\udda7\ud90a\udc07\ud849\uddb0\ud8e0\udd95\ud871\udf48\ud884\udf48\ud8d4\udfac\udb78\udccb\ud8d7\udcf0\ud98e\ude12\ud8a6\udfa9\ud966\udfbd\ud8c4\ude6e\udbc7\ude9d\ud86a\udfc8\udb99\udd5e\ud80d\udf69\udb8a\uddab\udb52\udead\udb2d\udfd4\udbfb\udf17\uda84\udfb8\uda2c\udcdb\ud800\udcc7\ud8f6\udcfb\udb92\udfe3\ud8c1\udc52\ud9aa\udf98\udb6d\udfde\ud981\ude43\ud9ca\uddfa\udb2e\udc61\ud877\udea9\uda83\uddff\udbfc\ude69\udb08\uddc7\udafc\ude68\uda7c\udcd4\udb8b\udd90\uda5c\udfd5\uda7c\udf85\udbb8\udf6e\ud862\ude3c\ud8b8\udd5b",
        22, 86078, -588370214, 8788938756552172152L, -47164L, true, true, (char) 7591, (char) 8438,
        Double.longBitsToDouble(0x3fef7346e73dd6abL), Double.longBitsToDouble(0x3fe8c63cde4014fdL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 20, 0, "", "", "\ud9e3\udc2a\uda82\udead\udbbe\udd41",
        36, 2161, 1088998882, 5893159567665712081L, -72517L, false, true, (char) 12629, (char) 12461,
        Double.longBitsToDouble(0x3fe88a90e61f64c6L), Double.longBitsToDouble(0x3fe14920d7c432c9L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 0, 15, "\u8b68\udad8\uddab\uda4d\udcce", "\u18b0\uc58f\u4a1d\u183c\u4a55\u3067\u4882\ua10f", "\ud842\uddee\udbc8\udca5\ud9a7\udf4a\udaf0\udc03\ud92d\udd01\uda8a\udc3f\ud8b6\udd27\ud891\udf07\ud9c8\ude09\udad3\ude76\udae5\udf7f\ud952\udd07\udb8f\udf1c\uda7e\ude43\udbba\udc3a\udaf3\udc5d",
        0, 74133, -1723326476, 9179709614632665L, -53880L, true, true, (char) 39971, (char) 47699,
        Double.longBitsToDouble(0x3fd806e8e96558d8L), Double.longBitsToDouble(0x3fd10326a3b65eb4L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 6, 0, "", "", "\ud9e3\udc2a\uda82\udead\udbbe\udd41",
        36, 2161, 1088998882, 5893159567665713105L, -72517L, false, true, (char) 12629, (char) 12461,
        Double.longBitsToDouble(0x3fe88a90e61f64c6L), Double.longBitsToDouble(0x3fe14920d7c432c9L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.jfree.data.KeyedObjects2D:@?\0121=void |this=org.jfree.data.KeyedObjects2D:@?\012",
        Z.run(T, 2, 7, 2, 19, "\u8b68\udad8\uddab\uda4d\udcce", "\u18b0\uc58f\u4a1d\u183c\u4a55\u3067\u4882\ua10f", "\ud842\uddee\udbc8\udca5\ud9a7\udf4a\udaf0\udc03\ud92d\udd01\uda8a\udc3f\ud8b6\udd27\ud891\udf07\ud9c8\ude09\udad3\ude76\udae5\udf7f\ud952\udd07\udb8f\udf1c\uda7e\ude43\udbba\udc3a\udaf3\udc5d",
        0, 74133, -1723326476, 9179709614632665L, -53880L, true, true, (char) 39971, (char) 47699,
        Double.longBitsToDouble(0x3fd806e8e96558d8L), Double.longBitsToDouble(0x3fd10326a3b65eb4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jfree.data.KeyedObjects2D|getObject|int,int|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getObject|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeColumn|int|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeColumn|java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeObject|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeRow|int|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeRow|java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|addObject|java.lang.Object,java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|clone||new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|equals|java.lang.Object|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getColumnCount||new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getColumnIndex|java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getColumnKey|int|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getColumnKeys||new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getRowCount||new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getRowIndex|java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getObject|int,int|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|getObject|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeColumn|int|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeColumn|java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeObject|java.lang.Comparable,java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeRow|int|new:org.jfree.data.KeyedObjects2D:",
    "M|org.jfree.data.KeyedObjects2D|removeRow|java.lang.Comparable|new:org.jfree.data.KeyedObjects2D:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
